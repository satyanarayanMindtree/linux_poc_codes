/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        telnet.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    04.02.2007 SentLength initialised to zero since it is always checked {1}
    21.05.2009 SentLength used as echo result to avoid particular lengths being interpreted incorrectly by TCP {2}
    03.02.2010 Protect TELNET mode check when called by a non-TELNET socket {3}
    24.03.2011 Use TCP_WINDOW_UPDATE event to kick off stalled TCP flow  {4}
    24.03.2011 Interpret a regeneration with zero data length as a probe request {5}
    26.03.2011 Pass the destination port to the user listener on connection request {6}
    26.03.2011 Automatically accept a repeated connection request without disturbing the application {7}

*/



//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"

#ifdef USE_TELNET



#define OWN_TASK   0



#define TELNET_STATE_FREE      0
#define TELNET_STATE_RESERVED  1
#define TELNET_STATE_CONNECTED 2

static const CHAR cDeleteInput[] = {DELETE_KEY, ' ', DELETE_KEY};


static TELNET *ptrTELNET = 0;

static int fnTELNETListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen);

static TELNET *fnGetTelnetSession(USOCKET Socket)
{
    TELNET *TELNET_session = ptrTELNET;
    int i;

    if (!TELNET_session) {
        return 0;
    }

    for (i = 0; i < NO_OF_TELNET_SESSIONS; i++) {                        // initialise sockets for each possible session
        if (TELNET_session->Telnet_socket == Socket) {
            return TELNET_session;
        }
        TELNET_session++;
    }
    return 0;                                                            // the socket is not a telnet socket
}

extern USOCKET fnStartTelnet(unsigned short usTelnetPortNumber, unsigned short usIdleTimeout, unsigned short usMaxWindow, UTASK_TASK wakeOnAck, int (*listener)(USOCKET, unsigned char, unsigned char *, unsigned short) )
{
    TELNET *TELNET_session = ptrTELNET;

    if (!ptrTELNET) {                                                    // when called, the user defined number of TELNET sockets will be created
        int i;
        ptrTELNET = TELNET_session = (TELNET*)uMalloc(NO_OF_TELNET_SESSIONS * sizeof(TELNET)); // get memory for socket administration

        for (i = 0; i < NO_OF_TELNET_SESSIONS; i++) {                    // initialise sockets for each possible session
            TELNET_session->Telnet_socket = -1;                          // mark unused
            TELNET_session++;
        }
    }

    TELNET_session = fnGetTelnetSession(-1);                             // get a free telnet socket
    if (!TELNET_session) {
        return -1;                                                       // no free socket found
    }

    TELNET_session->Telnet_socket = fnGetTCP_Socket(TOS_MINIMISE_DELAY, usIdleTimeout, fnTELNETListener);
    TELNET_session->fnApp = listener;
    TELNET_session->usTelnetPortNumber = usTelnetPortNumber;
    TELNET_session->usMaxWindow = usMaxWindow;
    TELNET_session->wakeOnAck = wakeOnAck;
    fnTCP_Listen(TELNET_session->Telnet_socket, usTelnetPortNumber, usMaxWindow);
    return TELNET_session->Telnet_socket;
}

static QUEUE_TRANSFER fnSendNeg(TELNET *TELNET_session, unsigned char ucAnswer, unsigned char ucOption)
{
    unsigned char ucNegotiation[3];
    ucNegotiation[0] = TELNET_IAC;
    ucNegotiation[1] = ucAnswer;
    ucNegotiation[2] = ucOption;

    return (fnSendBufTCP(TELNET_session->Telnet_socket, (unsigned char *)ucNegotiation, sizeof(ucNegotiation), (TCP_BUF_SEND | TCP_CONTENT_NEGOTIATION)));
}


// We handle one negotiation parameter here. If we send something in response we signal this
// change the return value.
//
static unsigned char fnTelnetNegotiate(TELNET *TELNET_session, unsigned char *ucIp_Data, unsigned short usLen, int *iReturn)
{
    if (usLen >= 2) {                                                    // we assume a negotation sequence is complete in one frame
        unsigned char ucNegotiateLength = 2;                             // most negotiation parameter lengths are 2 more bytes long
        unsigned char ucNegotationToSend = 0;
        QUEUE_TRANSFER Negotiation_sent = 0;

        switch (*ucIp_Data++) {                                          // which command / negotiation type is it?
        case TELNET_DO:
            if (TELNET_ECHO == *ucIp_Data) {
                if (TELNET_WILL_ECHO & TELNET_session->usTelnetMode) {   // have we just suggested we echo?
                    TELNET_session->usTelnetMode |= TELNET_DO_ECHO;      // mark we will be doing echos
                    TELNET_session->usTelnetMode &= ~TELNET_WILL_ECHO;   // ensure we only answer once
                }
                else if (!(TELNET_session->usTelnetMode & TELNET_DO_ECHO)) {  // if we are not changing, don't respond
                    TELNET_session->usTelnetMode |= TELNET_DO_ECHO;      // the other end has accepted that we perform echoing (or is requesting we do so)
                    ucNegotationToSend = TELNET_WILL;
                }
            }
            else if (TELNET_BINARY == *ucIp_Data) {
                ucNegotationToSend = TELNET_WILL;                        // we accept binary mode
            }
            else {
                ucNegotationToSend = TELNET_WONT;                        // we respond to all other dos with wont
            }
            break;

        case TELNET_DONT:
            if (TELNET_ECHO == *ucIp_Data) {                             // we should not perform echoing
                TELNET_session->usTelnetMode &= ~TELNET_DO_ECHO;
                if (TELNET_session->usTelnetMode & TELNET_WONT_ECHO) {
                    TELNET_session->usTelnetMode &= ~TELNET_WONT_ECHO;
                    break;
                }
            }
            ucNegotationToSend = TELNET_WONT;                            // we are obliged to respond to don't with won't
            break;

        case TELNET_WILL:
            if (TELNET_BINARY == *ucIp_Data) {
                Negotiation_sent |= fnSendNeg(TELNET_session, TELNET_DO, *ucIp_Data);
                TELNET_session->usTelnetMode |= TELNET_BINARY_MODE;      // we have completed the handshake to binary mode
                TELNET_session->usTelnetMode &= ~TELNET_DO_ECHO;
            }
            else {
                ucNegotationToSend = TELNET_DONT;                        // we respond to all other wills with don't
            }
            break;

        case TELNET_WONT:
            ucNegotationToSend = TELNET_DONT;                            // we are obliged to respond to won't with don't
            break;

        default:
            return 0;
        }
        if (ucNegotationToSend != 0) {
            Negotiation_sent |= fnSendNeg(TELNET_session, ucNegotationToSend, *ucIp_Data);
        }
        if (Negotiation_sent != 0) {
            *iReturn = APP_SENT_DATA;                                    // mark that we have sent TCP data
        }
        return ucNegotiateLength;                                        // length or found negotiation command
    }
    return 0;
}

extern int fnTelnet(USOCKET Telnet_socket, int iCommand)
{
    TELNET *TELNET_session = fnGetTelnetSession(Telnet_socket);

    if (!TELNET_session) {
        return APP_ACCEPT;                                               // not found, simply return accepted by application
    }

    switch (iCommand) {
    case GOTO_ECHO_MODE:
//        fnSendNeg(TELNET_session, TELNET_WILL, TELNET_ECHO);	//ARMD0230  //removing garbage data
        TELNET_session->usTelnetMode |= TELNET_WILL_ECHO;                // mark that we want to echo
        return APP_SENT_DATA;

    case LEAVE_ECHO_MODE:
        fnSendNeg(TELNET_session, TELNET_WONT, TELNET_ECHO);
        TELNET_session->usTelnetMode |= TELNET_WONT_ECHO;                // mark that we wont to echo
        return APP_SENT_DATA;

    case PASSWORD_ENTRY:
        TELNET_session->usTelnetMode |= PASSWORD_ENTRY_MODE;
        break;

    case CLEAR_TEXT_ENTRY:
        TELNET_session->usTelnetMode &= ~PASSWORD_ENTRY_MODE;
        break;

    case TELNET_ASCII_MODE:
        TELNET_session->usTelnetMode &= ~(TELNET_RAW_SOCKET | TELNET_BINARY_MODE);
        break;

    case TELNET_RAW_MODE:
        TELNET_session->usTelnetMode |= TELNET_RAW_SOCKET;
        break;

    case TELNET_RAW_RX_IAC_ON:
        TELNET_session->usTelnetMode |= TELNET_SEARCH_RX_IAC;
        break;

    case TELNET_RAW_RX_IAC_OFF:
        TELNET_session->usTelnetMode &= ~TELNET_SEARCH_RX_IAC;
        break;

    case TELNET_RAW_TX_IAC_ON:
        TELNET_session->usTelnetMode |= TELNET_STUFF_TX_IAC;
        break;

    case TELNET_RAW_TX_IAC_OFF:
        TELNET_session->usTelnetMode &= ~TELNET_STUFF_TX_IAC;
        break;

    case TELNET_RESET_MODE:
        TELNET_session->usTelnetMode = 0;
        break;
    }
    return 0;
}

static void fnResetTelnetSession(TELNET *TELNET_session)
{
    TELNET_session->ucState = TELNET_STATE_FREE;
    TELNET_session->usTelnetMode = 0;
}

extern void fnStopTelnet(USOCKET TelnetSocket)
{
    TELNET *TELNET_session = fnGetTelnetSession(TelnetSocket);

    if (!TELNET_session) {
        return;
    }

    fnReleaseTCP_Socket(TelnetSocket);                                   // we close the sockets so that Telnet socket is effectively dead.
    fnResetTelnetSession(TELNET_session);
    TELNET_session->Telnet_socket = -1;
}

// This routine filters out double IAC occurances in the input data stream and interprets TELNET commands
//
static unsigned short fnHandleIAC(TELNET *TELNET_session, unsigned char *ucData, unsigned short usLength, int *iReturn)
{
    unsigned char *ptrInput = ucData;
    unsigned char *ptrOutput = ucData;
    unsigned short usFF_found = TELNET_session->usTelnetMode & TELNET_BIN_RX_IAC; // get original state
    unsigned short usInputLength = usLength;

    TELNET_session->usTelnetMode &= ~TELNET_BIN_RX_IAC;

    while (usInputLength--) {
        if ((usFF_found == 0) || (*ptrInput != TELNET_IAC)) {
            if (*ptrInput == TELNET_IAC) {                               // either first of a double pair or a command sequence
                usFF_found = TELNET_BIN_RX_IAC;                          // we don't copy the IAC (yet), but mark that we have foud a starting one
                ptrInput++;                                              // jump over
                usLength--;                                              // removed
            }
            else {
                if (usFF_found != 0) {                                   // probably an IAC
                    unsigned char ucNegLength;
                    usFF_found = 0;
                    if ((!(TELNET_session->usTelnetMode & TELNET_RAW_SOCKET)) && ((ucNegLength = fnTelnetNegotiate(TELNET_session, ptrInput, usLength, iReturn)) != 0)) {
                        usLength -= ucNegLength;
                        ptrInput += ucNegLength;                         // jump over IAC command sequence
                        usInputLength -= (ucNegLength - 1);
                        continue;                                        // continue after treatment and removal of IAC
                    }
                    else {
                        usLength++;
                        *ptrOutput++ = TELNET_IAC;                       // insert the IAC, which doesn't belong to a command sequence
                    }
                }
                *ptrOutput++ = *ptrInput++;                              // transfer the input stream to output
            }
        }
        else {                                                           // sequence of 2 x IAC is a special case
            ptrInput++;
            *ptrOutput++ = TELNET_IAC;                                   // add only 1 x IAC to buffer
            usFF_found = 0;
        }
    }
    TELNET_session->usTelnetMode |= usFF_found;                         // updata reception state to flag if we have part of a IAC sequence
    return usLength;                                                    // length of input after any IAC (negotiation) removal
}

extern int fnCheckTelnetBinaryTx(USOCKET Socket)
{
    TELNET *TELNET_session = fnGetTelnetSession(Socket);
    if (TELNET_session == 0) {                                           // {3} not a TELNET socket
        return 0;
    }
    if (TELNET_session->usTelnetMode & (TELNET_STUFF_TX_IAC | TELNET_BINARY_MODE)) {
        return 1;
    }
    return 0;
}


// Telnet client/server standard call back
//
static int fnTELNETListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen)
{
    TELNET *TELNET_session = fnGetTelnetSession(Socket);
    int iReturn = APP_ACCEPT;

    if (!TELNET_session) {
        return -1;
    }

    switch (ucEvent) {
    case TCP_EVENT_CONREQ:                                               // session request received on the TCP port
        if (TELNET_session->ucState == TELNET_STATE_CONNECTED) {         // a request for connection to a connected session is always rejected
            return APP_REJECT;
        }
        else if (TELNET_session->ucState != TELNET_STATE_RESERVED) {     // {7} if the connection is reserved it means that we already received a SYN and our SYN + ACK was probably lost, so accept without disturbing the application
            if (APP_REJECT == TELNET_session->fnApp(Socket, TCP_EVENT_CONREQ, ucIp_Data, usPortLen)) { // {6} if the application wants to refuse the connection it is done here
                return APP_REJECT;                                       // cause a RST to be sent and the TCP connection to be terminated
            }    
            TELNET_session->ucState = TELNET_STATE_RESERVED;             // reserve the session if the socket is available
        }
        break;                                                           // accept, which causes a SYN + ACK to be returned

    case TCP_EVENT_CONNECTED:                                            // TCP connection has been established
        TELNET_session->ucState = TELNET_STATE_CONNECTED;
        return (TELNET_session->fnApp(Socket, TCP_EVENT_CONNECTED, ucIp_Data, usPortLen));

    case TCP_EVENT_ABORT:
        fnTCP_Listen(Socket, TELNET_session->usTelnetPortNumber, ptrTELNET->usMaxWindow); // set back to listening state
        fnResetTelnetSession(TELNET_session);
        TELNET_session->fnApp(Socket, TCP_EVENT_ABORT, ucIp_Data, usPortLen);
        // fall through intentionally
    case TCP_EVENT_CLOSE:
        return (TELNET_session->fnApp(Socket, TCP_EVENT_CLOSE, ucIp_Data, usPortLen));    

    case TCP_EVENT_CLOSED:
        TELNET_session->fnApp(Socket, TCP_EVENT_CLOSED, ucIp_Data, usPortLen);
        fnResetTelnetSession(TELNET_session);
        fnTCP_Listen(Socket, TELNET_session->usTelnetPortNumber, ptrTELNET->usMaxWindow); // set TCP port back to listening state
        break;

#ifdef SUPPORT_PEER_WINDOW
    case TCP_EVENT_PARTIAL_ACK:                                          // possible ack to a part of a transmission received
        if (TELNET_session->wakeOnAck) {
            uTaskerStateChange(TELNET_session->wakeOnAck, UTASKER_ACTIVATE); // wake application so that it can continue with queued receive data
        }

        if (fnSendBufTCP(Socket, 0, usPortLen, TCP_BUF_NEXT)) {          // send next buffered (if waiting)
            return APP_SENT_DATA;
        }
        break;
#endif

    case TCP_EVENT_ACK:
        if (TELNET_session->wakeOnAck) {
            uTaskerStateChange(TELNET_session->wakeOnAck, UTASKER_ACTIVATE); // wake application so that it can continue with queued receive data
        }

        if (fnSendBufTCP(Socket, 0, 0, TCP_BUF_NEXT)) {                  // send next buffered (if waiting)
            iReturn = APP_SENT_DATA;                                     // mark that data has been transmitted
        }

        iReturn |= TELNET_session->fnApp(Socket, TCP_EVENT_ACK, 0, 0);   // let application also handle ack

        if (iReturn & APP_REQUEST_CLOSE) {                               // if application request a close
            fnTCP_close(Socket);                                         // terminate the connection
            return APP_REQUEST_CLOSE;
        }
        break;

    case TCP_EVENT_REGENERATE:
        if (usPortLen == 0) {                                            // {5} if there is no data to be repeated interpret as probe request
            fnSendBufTCP(Socket, 0, 0, (TCP_BUF_NEXT | TCP_BUF_SEND));   // cause probe to be sent
            break;
        }
        if (fnSendBufTCP(Socket, 0, 0, TCP_BUF_REP) != 0) {              // repeat send buffered
    #ifdef SUPPORT_PEER_WINDOW 
            fnSendBufTCP(Socket, 0, 0, (TCP_BUF_NEXT | TCP_BUF_KICK_NEXT)); // kick off any following data as long as windowing allows it
    #endif
            return APP_SENT_DATA;
        }
        break;

    case TCP_EVENT_DATA:
        if ((!(TELNET_session->usTelnetMode & TELNET_RAW_SOCKET)) || (TELNET_session->usTelnetMode & (TELNET_SEARCH_RX_IAC))) { // in RAW socket mode we ignore Telnet contents unless specifically activated
            if (((usPortLen = fnHandleIAC(TELNET_session, ucIp_Data, usPortLen, &iReturn)) != 0) && (TELNET_session->usTelnetMode & TELNET_DO_ECHO)) { // if we are doing echo
                QUEUE_TRANSFER SentLength = 0;                           // {1} initialise to zero since it is always checked
                if (TELNET_session->usTelnetMode & PASSWORD_ENTRY_MODE) {
                    if (*ucIp_Data == DELETE_KEY) {
                        SentLength = fnSendBufTCP(Socket, (unsigned char *)cDeleteInput, 3, TCP_BUF_SEND); // allow our separation character or delete to pass
                    }
                    else if (*ucIp_Data == ':') {
                        SentLength = fnSendBufTCP(Socket, ucIp_Data, 1, TCP_BUF_SEND); // allow our separation character
                    }
                    else {
                        SentLength = fnSendBufTCP(Socket, (unsigned char *)"*", 1, TCP_BUF_SEND); // don't echo input but send a star (password entry)
                    }
                }
                else {
                    SentLength = fnSendBufTCP(Socket, ucIp_Data, usPortLen, TCP_BUF_SEND); // {2} perform echo of input 
                }
                if (SentLength) {
                    iReturn = APP_SENT_DATA;
                }
            }
        }
        return (iReturn | TELNET_session->fnApp(Socket, TCP_EVENT_DATA, ucIp_Data, usPortLen)); // pass the received data on to the TELNET application

    #ifdef SUPPORT_PEER_WINDOW 
    case TCP_WINDOW_UPDATE:                                              // {4} the peer is informing of a change in its receiver window size
        if (fnSendBufTCP(Socket, 0, 0, (TCP_BUF_NEXT | TCP_BUF_KICK_NEXT)) != 0) { // kick off any following data as long as windowing allows it
            return APP_SENT_DATA;
        }
    #endif
        break;
    }
    return iReturn;
}
#endif
