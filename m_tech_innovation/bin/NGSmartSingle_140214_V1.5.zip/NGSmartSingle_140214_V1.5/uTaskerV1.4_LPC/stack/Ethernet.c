/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        Ethernet.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    01.03.2007 EthernetStats array made conditional on USE_IP_STATS      {1}
    14.03.2007 Added RARP reception support                              {2}
    15.03.2007 Added VLAN support                                        {3}
    09.06.2008 Allow variable uNetwork protocol                          {4}
    10.01.2010 Add IPV6                                                  {5}
    27.08.2010 Limit to optionally handling only one reception at a time {6}
    06.09.2010 Add rx offload support                                    {7}
    25.08.2011 Modify optional handling of one reception frame at a time to operate without queued events and control
              maximum number of frames handled each pass                 {8}
    10.11.2011 Quit initialisation if the Ethernet configuration fails   {9}

*/


//#include "config.h"
#include "type.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "serial.h"



#ifdef ETH_INTERFACE

#define OWN_TASK                 TASK_ETHERNET

QUEUE_HANDLE Ethernet_handle    = NO_ID_ALLOCATED;

#ifdef USE_IP_STATS                                                      // {1}
    static unsigned long EthernetStats[sizeof(ETHERNET_STATS)/sizeof(unsigned long)] = {0};
#endif

#ifdef ETHERNET_RELEASE_AFTER_EVERY_FRAME                                // {8}
    static const unsigned char ucEMAC_RX_INTERRUPT = EMAC_RX_INTERRUPT;
#endif

extern void fnTaskEthernet(TTASKTABLE *ptrTaskTable)
{
#if !defined ETHERNET_RELEASE_AFTER_EVERY_FRAME                          // {8} no queue used
    QUEUE_HANDLE PortIDInternal = ptrTaskTable->TaskID;                  // queue ID for task input
    unsigned char ucInputMessage[MEDIUM_MESSAGE];                        // reserve space for receiving messages
#elif defined ETHERNET_RELEASE_LIMIT
    int iMaxRxFrames = ETHERNET_RELEASE_LIMIT;                           // allow the task to handle up to this many reception frames before yielding
#endif
    ETHERNET_FRAME rx_frame;
    signed char cEthernetBuffer;

    if (Ethernet_handle == NO_ID_ALLOCATED) {
        ETHTABLE ethernet;

        fnGetEthernetPars();                                             // we get the network parameters before configuring

        ethernet.Task_to_wake  = OWN_TASK;
        ethernet.Channel       = 1;
        ethernet.usMode        = network.usNetworkOptions;
        ethernet.usSizeRx      = LAN_BUFFER_SIZE;
        ethernet.usSizeTx      = LAN_BUFFER_SIZE;
        ethernet.ucEthTypes    = (ARP | IPV4);
        ethernet.usExtEthype   = 0;
#ifdef USE_IPV6                                                          // {5}
        ethernet.usMode |= CON_MULTICAST;                                // configure multicast when using IPV6
#else
        uMemcpy(ethernet.ucMAC, &network.ucOurMAC[0], MAC_LENGTH);
#endif
        Ethernet_handle = fnOpen(TYPE_ETHERNET, FOR_I_O, &ethernet);     // open the channel with defined configuration
        if (Ethernet_handle == NO_ID_ALLOCATED) {                        // {9} if the hardware configuration failed
            return;                                                      // stop any further activity - the developer can catch this here and identify the cause in the hardware-specific initialisation (usually due to PHY not being detected)
        }
    }
#if !defined ETHERNET_RELEASE_AFTER_EVERY_FRAME                          // {8}
    while (fnRead(PortIDInternal, ucInputMessage, HEADER_LENGTH)) {     // check input queue
        switch (ucInputMessage[MSG_SOURCE_TASK]) {
        case INTERRUPT_EVENT:
            while ((cEthernetBuffer = fnEthernetEvent(&ucInputMessage[MSG_INTERRUPT_EVENT], &rx_frame)) >= 0)
#else
            while ((cEthernetBuffer = fnEthernetEvent((unsigned char *)&ucEMAC_RX_INTERRUPT, &rx_frame)) >= 0)
#endif
            {
#ifdef IP_RX_CHECKSUM_OFFLOAD                                            // {7}
                if (rx_frame.frame_size == 0) {                          // reception is invalid IPv4/v6 frame so discard
                    fnFreeBuffer(Ethernet_handle, cEthernetBuffer);      // free up the receiver buffer since we have completed
                    continue;
                }
#endif
#if defined USE_IP || defined USE_IPV6
    #ifdef SUPPORT_VLAN
                if (vlan_active) {                                       // if VLAN mode active, accept only frames to our identifier
                    if ((rx_frame.ptEth->ethernet_frame_type[0] != (unsigned char)(TAG_PROTOCOL_IDENTIFIER  >> 8)) 
                        || (rx_frame.ptEth->ethernet_frame_type[1] != (unsigned char)(TAG_PROTOCOL_IDENTIFIER))
                        || ((rx_frame.ptEth->ucData[0] & 0x0f) != (unsigned char)((vlan_vid >> 8) & 0x0f)) 
                        || (rx_frame.ptEth->ucData[1] != (unsigned char)vlan_vid)) {
                        fnFreeBuffer(Ethernet_handle, cEthernetBuffer);  // free up the receiver buffer since we reject the frame
                        continue;
                    }
                    else {
                        unsigned char *ptrTo = (unsigned char *)rx_frame.ptEth + (2*MAC_LENGTH + (VLAN_TAG_LENGTH - 1));
                        unsigned char *ptrFrom = (unsigned char *)rx_frame.ptEth + (2*MAC_LENGTH - 1);
                        while (ptrFrom >= (unsigned char *)rx_frame.ptEth) {
                            *ptrTo-- = *ptrFrom--;                       // shift the header to overwrite the VLAN tag, resulting in filtered frame
                        }
                        rx_frame.ptEth = (ETHERNET_FRAME_CONTENT*)((unsigned char *)rx_frame.ptEth + VLAN_TAG_LENGTH);
                    }
                }
    #endif
    #ifdef USE_IPV6                                                      // {5}
                if ((rx_frame.ptEth->ethernet_frame_type[1] == (unsigned char)(PROTOCOL_IPv6)) && (rx_frame.ptEth->ethernet_frame_type[0] == (unsigned char)(PROTOCOL_IPv6 >> 8))) { // check for IPV6
                    fnHandleIPV6(&rx_frame, 0);
                    fnFreeBuffer(Ethernet_handle, cEthernetBuffer);      // free up the receiver buffer since we have completed
                    continue;
                }
    #endif
#endif
#if defined USE_IP
                // Note that we check whether it is probably an ARP message by looking only at the second byte in the protocol field
                // This is for efficiency - only call ARP routine when it is probable that it is an ARP (the ARP routine then only checks first byte in type field
                if (rx_frame.ptEth->ethernet_frame_type[0] == (unsigned char)(PROTOCOL_IPv4 >> 8)) {
                    if ((rx_frame.ptEth->ethernet_frame_type[1] != (unsigned char)PROTOCOL_ARP) 
    #ifdef USE_RARP                                                      // {2}
                        && (rx_frame.ptEth->ethernet_frame_type[1] != (unsigned char)PROTOCOL_RARP) 
    #endif
                        || (!fnProcessARP(&rx_frame))) {                 // if (R)ARP, handle it
                        unsigned short usIPLength;
                        unsigned short usTotalLength;

                        if ((usIPLength = fnHandleIP(&rx_frame, &usTotalLength)) != 0) { // if IP handle it
                            switch (rx_frame.ptEth->ucData[IP_PROTOCOL_OFFSET]) { // valid IP frame
    #ifdef USE_ICMP
                            case IP_ICMP:
                                fnHandleICP(&rx_frame.ptEth->ucData[usIPLength], (IP_PACKET *)&rx_frame.ptEth->ucData, (unsigned short)(usTotalLength - usIPLength));
                                break;
    #endif
    #ifdef USE_IPV6                                                      // {5}
                            case IP_6TO4:
                                fnHandleIPV6(&rx_frame, usIPLength);
                                break;
    #endif
    #ifdef USE_UDP
                            case IP_UDP:
                                fnHandleUDP(usIPLength, (IP_PACKET *)&rx_frame.ptEth->ucData);
                                break;
    #endif
    #ifdef USE_TCP
                            case IP_TCP:
                                fnHandleTCP(&rx_frame.ptEth->ucData[usIPLength], (IP_PACKET *)&rx_frame.ptEth->ucData, (unsigned short)(usTotalLength - usIPLength));
                                break;
    #endif
    #ifdef USE_IGMP
                            case IP_IGMPV2:
                                fnHandleIGMP(2, (unsigned short)(usIPLength - IP_MIN_HLEN), (IP_PACKET *)&rx_frame.ptEth->ucData, (unsigned short)(usTotalLength - usIPLength));
                                break;
    #endif
                            default:
                                break;                                   // invalid
                            }
                        }
                    }                                                    // end if not ARP
                }                                                        // end if PROTOCOL IP V4
    #ifdef SUPPORT_DISTRIBUTED_NODES
        #ifdef VARIABLE_PROTOCOL_UNETWORK                                // {4}
                else if ((rx_frame.ptEth->ethernet_frame_type[0] == uc_uNetworkProtocol[0]) && (rx_frame.ptEth->ethernet_frame_type[1] == uc_uNetworkProtocol[1])) {
                    fnHandle_unet(rx_frame.ptEth->ucData);
                }
        #else
                else if ((rx_frame.ptEth->ethernet_frame_type[0] == (unsigned char)(PROTOCOL_UNETWORK>>8)) && (rx_frame.ptEth->ethernet_frame_type[1] == (unsigned char)(PROTOCOL_UNETWORK))) {
                    fnHandle_unet(rx_frame.ptEth->ucData);
                }
        #endif
    #endif
#elif defined SUPPORT_DISTRIBUTED_NODES
    #ifdef VARIABLE_PROTOCOL_UNETWORK                                    // {4}
                if ((rx_frame.ptEth->ethernet_frame_type[0] == uc_uNetworkProtocol[0]) && (rx_frame.ptEth->ethernet_frame_type[1] == uc_uNetworkProtocol[1])) {
                    fnHandle_unet(rx_frame.ptEth->ucData);
                }
    #else
                if ((rx_frame.ptEth->ethernet_frame_type[0] == (unsigned char)(PROTOCOL_UNETWORK>>8)) && (rx_frame.ptEth->ethernet_frame_type[1] == (unsigned char)(PROTOCOL_UNETWORK))) {
                    fnHandle_unet(rx_frame.ptEth->ucData);
                }
    #endif
#endif
                fnFreeBuffer(Ethernet_handle, cEthernetBuffer);          // free up the reception buffer since we have completed working with it
#ifdef ETHERNET_RELEASE_AFTER_EVERY_FRAME                                // {6}
    #if defined ETHERNET_RELEASE_LIMIT                                   // {8}
                if (--iMaxRxFrames >= 0) {                               // if the task has not yet handled the maximum number of frames allow it to continue running
                    continue;
                }
    #endif
                uTaskerStateChange(OWN_TASK, UTASKER_ACTIVATE);          // schedule the task to check the input once more after allowing other tasks to run
                return;                                                  // quit for the moment
#endif
            }                                                            // end while frames waiting
#if !defined ETHERNET_RELEASE_AFTER_EVERY_FRAME                          // {8}
            break;

        default:
            break;
        }
    }
#endif
}

#ifdef USE_IP_STATS
extern void fnIncrementEthernetStats(unsigned char ucStat)
{
    EthernetStats[ucStat]++;
    if (ucStat <= LAST_RX_COUNTER) {
        EthernetStats[TOTAL_RX_FRAMES]++;
    }
    else if (ucStat <= LAST_TX_COUNTER) {
        EthernetStats[TOTAL_TX_FRAMES]++;
    }
}

extern unsigned long fnGetEthernetStats(unsigned char ucStat)
{
    return EthernetStats[ucStat];                                        // return the specified value
}

extern void fnTxStats(unsigned char ucProtType)
{
    unsigned char ucCounter;
    switch (ucProtType) {                                                // set counter according to protocol being sent
    case IP_UDP:
        ucCounter = SENT_UDP_FRAMES;
        break;

    case IP_TCP:
        ucCounter = SENT_TCP_FRAMES;
        break;

    case IP_ICMP:
        ucCounter = SENT_ICMP_FRAMES;
        break;
#ifdef USE_IPV6
    case HEADER_TYPE_ICMPV6:
        ucCounter = TRANSMITTED_ICMPV6_FRAMES;
        break;
#endif

    default:
        EthernetStats[TOTAL_TX_FRAMES]++;                                // we have sent a frame with a protocol which is not specifically counted
        return;
    }
    fnIncrementEthernetStats(ucCounter);
}

extern void fnRxStats(unsigned char ucProtType)
{
    unsigned char ucCounter;
    switch (ucProtType & ~FOREIGN_FRAME) {                               // set counter according to protocol being received
    case IP_UDP:
        ucCounter = RECEIVED_UDP_FRAMES;
        break;

    case IP_TCP:
        ucCounter = RECEIVED_TCP_FRAMES;
        break;

    case IP_ICMP:
        ucCounter = RECEIVED_ICMP_FRAMES;
        break;

#ifdef USE_IPV6
    case HEADER_TYPE_ICMPV6:
        ucCounter = RECEIVED_ICMPV6_FRAMES;
        break;
#endif
    default:
        EthernetStats[UNSUPPORTED_PROTOCOL_FRAMES]++;                    // we have received a frame with a protocol which is not specifically supported
        EthernetStats[TOTAL_RX_FRAMES]++;
        return;
    }
    if (ucProtType & FOREIGN_FRAME) {
        ucCounter += (SEEN_FOREIGN_ICMP_FRAMES - RECEIVED_ICMP_FRAMES);  // set index to foreign counters
    }
    fnIncrementEthernetStats(ucCounter);
}


extern void fnDeleteEthernetStats(void)
{
    uMemset(EthernetStats, 0, sizeof(EthernetStats));
}
#endif

#endif
