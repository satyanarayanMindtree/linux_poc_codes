/* -*- mode: C; c-file-style: "gnu"; Code: iso-9660-2 -*- */
/*! \mainpage SNMP (snmp agent)
 *
 * \section intro_sec Intro
 * This code realize snmjp agent functions for uTasker operation system
 *
 * \section add_modules Conpilation
 * This files is needed for properly work:
 * - snmp.c, snmp.h (source code of the agent)
 * .
 */

/** \file snmp.c
 *
 * \brief  SNMP agent for uTasker
 *
 * Supported MIBs:
 * - ART-MIB
 * .
 *
 *
 * @Author          Artem Fedko
 *
 * @Date            26-03-2007
 *
 * @Version 	    0.0.1 (26-03-2007) first version
 *
 */

#include "config.h"

#ifdef USE_SNMP

#ifdef _WINDOWS
  #include "../WinSim/WinSim.h"
#endif

/**
*                 local function prototype declarations
*/

static int           fnSNMPListner(USOCKET socket, unsigned char uc, unsigned char *ucIP, unsigned short us, unsigned char *data, unsigned short us2);
//static void          fnSendSNMP(unsigned char ucDHCP_message);
void fnSendSNMPTrap(unsigned char ucTrap, unsigned char ucSpecificCode);


/**
*                          local definitions
*/

#define SNMP_ERROR_NO_ARP_RES        20
#define SNMP_ERROR_TIMEOUT           21
#define SNMP_ERROR_GENERAL           22
#define SNMP_OPCODE_ERROR            23

#define OWN_TASK                 TASK_SNMP

#define SNMP_BUFFER             (300)                                    // adequate for the largest SNMP message we send

#define SNMP_STATE_INIT              0                                   // SMTP states
#define SNMP_STATE_CLOSED            1

#define SNMP_NUM_RETRIES   5

/**
*                             constants
*/



/**
*                       local structure definitions
*/

typedef struct stUDP_MESSAGE
{     
    UDP_HEADER       tUDP_Header;                                         // reserve header space
    unsigned char    ucUDP_Message[SNMP_BUFFER];
} UDP_MESSAGE;


/**
*                     global variable definitions
*/

static USOCKET       SNMPSocketNr = -1;                                  // UDP socket

unsigned char sysContact[MAX_STR_LEN];
static unsigned char  ucSNMP_state = SNMP_STATE_INIT;
unsigned char UARTsend;
unsigned char UARTsend_flag = 0;
static unsigned char ucTrapCnt = 0;
IICTABLE tIICParameters;

static unsigned char ucSNMPRetries;

unsigned char ucIP_SNMP_Manager[IPV4_LENGTH];

static const unsigned char ucSNMPV1[] = {ASNInteger, 0x01, SNMPV1};

//unsigned char ucIP_SNMP_Manager[IPV4_LENGTH] = {192,168,2,204};
//unsigned char ucIP_SNMP_Manager[IPV4_LENGTH] = {192,168,1,5};
//unsigned char ucIP_SNMP_Manager[IPV4_LENGTH] = {192,168,3,198};
static const CHAR cSNMP_enterprise[] = {0x2b, 6, 1,4,1,4,1,2,15};
static int  fnRetry(void);

static void fnSNMP_error(unsigned char ucError)
{
    //fnTCP_close(SMTP_TCP_socket);                                        // close connection on error
    ucSNMP_state = SNMP_STATE_CLOSED;
//    fnUserCallback(ucError, 0);
}


void fnSNMP(TTASKTABLE *ptrTaskTable)
{    
    QUEUE_HANDLE PortIDInternal = ptrTaskTable->TaskID;                  // queue ID for task input
    unsigned char ucInputMessage[SMALL_QUEUE];                           // reserve space for receiving messages

    if ( fnRead( PortIDInternal, ucInputMessage, HEADER_LENGTH )) {      // check input queue
        if ( ucInputMessage[ MSG_SOURCE_TASK ] == TASK_ARP) {
            fnRead( PortIDInternal, ucInputMessage, ucInputMessage[MSG_CONTENT_LENGTH]);  // read the contents
            if (ARP_RESOLUTION_FAILED == ucInputMessage[ 0 ]) {
                if (fnRetry()) {                                         // SNMP manager could not be resolved - try a few times before informing listener 
                    fnSNMP_error(SNMP_ERROR_NO_ARP_RES);
                }
            }
            else if (ARP_RESOLUTION_SUCCESS == ucInputMessage[ 0 ]) {
                ucSNMPRetries = 0;                                       // the first request was lost due to ARP resolution
                fnRetry();                                               // the ARP resolution was successful - now start fresh
            }
        }
    }
	if ((network.ucOurIP[0]!=0)&&(ucTrapCnt)){
		fnRetry();
	}

}

// Call this function to start SNMP
//
extern int fnStartSNMP(void)
{
	
    if ((SNMPSocketNr >= 0) || ((SNMPSocketNr = fnGetUDP_socket(TOS_MINIMISE_DELAY, fnSNMPListner, (UDP_OPT_SEND_CS | UDP_OPT_CHECK_CS))) >= 0)) {
        fnBindSocket(SNMPSocketNr, SNMP_CLIENT_PORT);
        //cMasterTask = cTask;

//		uStrcpy((char *)sysContact,"Na derevniu dedushke");
        return SNMPSocketNr;                                                       // OK
    }    
    return NO_UDP_SOCKET_FOR_SNMP;                                       // error
}

///////////////////////////////////////////////////////////////////
// Community and rights check.
///////////////////////////////////////////////////////////////////
char check_pass(char *pass){

	if (!uStrcmp((char *)pass, (char *)&temp_pars->temp_parameters.snmp_admin[0])) return RW;
	if (!uStrcmp((char *)pass, (char *)&temp_pars->temp_parameters.snmp_user[0])) return RO;

	return 0;
}

char asn_compare_oid(const struct asn_oid *o1, const struct asn_oid *o2)
{
	unsigned long i;

	for (i = 0; i < o1->len && i < o2->len; i++) {
		if (o1->subs[i] < o2->subs[i])
			return (-1);
		if (o1->subs[i] > o2->subs[i])
			return (+1);
	}
	if (o1->len < o2->len)
		return (-2);
	if (o1->len > o2->len)
		return (+2);
	return (0);
}

/**
 *  Supportet MIBs
 */

struct mibs mib_tab[] = {{1,0x2b,NULL,NULL}, 
					{2,0x06,																	NULL,NULL}, 
					{3,		0x01,																NULL,NULL}, 
					{4,			0x02,															NULL,NULL}, 
					{5,				0x01,														NULL,NULL}, 
					{6,					0x01,													NULL,NULL}, 
					{7,						0x01,												NULL,NULL}, 
					{8,							0x00,											get_sysDescr,NULL}, 
					{7,						0x02,												NULL,NULL}, 
					{8,							0x00,											NULL,NULL}, 
					{7,						0x03,												NULL,NULL}, 
					{8,							0x00,											NULL,NULL}, 
					{7,						0x04,												NULL,NULL}, 
				//	{8,							0x00,											get_MIB_data,set_MIB_data}, 
					{4,			0x04,															NULL,NULL}, 
					{5,				0x01,														NULL,NULL}, 
					{6,					0x62,													NULL,NULL}, 
				//	{7,						0x00,												get_UART,set_UART}, 
					{6,					0x63,													NULL,NULL}, 
				//	{7,						0x00,												get_ADC_data,set_ADC_data}, 
					{6,					0xab,													NULL,NULL}, 
					{7,						0x57,												NULL,NULL}, 
					{8,							0x01,											NULL,NULL}, 
					{9,								0x05,										NULL,NULL}, 
					{10,								0x03,									NULL,NULL}, 
					{11,									0x01,								NULL,NULL}, 
					{12,										0x02,							NULL,NULL}, 
					{13,											0x01,						get_RetLasCurr_A,NULL}, 
					{13,											0x02,						get_RetLasCurr_B,NULL}, 
					{12,										0x07,							NULL,NULL}, 
					{13,											0x01,						get_RetLasOptPow_A,NULL}, 
					{13,											0x02,						get_RetLasOptPow_B,NULL},
					{10,								0x05,									NULL,NULL}, 
					{11,									0x01,								NULL,NULL}, 
					{12,										0x02,							NULL,NULL}, 
					{13,											0x01,						get_OptRecPow_B,NULL}, 
					{13,											0x02,						get_OptRecPow_A,NULL}, 
					{10,								0x0b,									NULL,NULL}, 
					{11,									0x01,								NULL,NULL}, 
					{12,										0x07,							NULL,NULL}, 
					{13,											0x01,						get_fnRFPortReverseAttenuationControl,set_fnRFPortReverseAttenuationControl}, 
					{13,											0x02,						get_fnRFPortReverseAttenuationControl,set_fnRFPortReverseAttenuationControl}, 
					{10,								0x0d,									NULL,NULL}, 
					{11,									0x01,								NULL,NULL}, 
					{12,										0x05,							NULL,NULL}, 
					{13,											0x00,						get_ReceiverABSwitch,set_ReceiverABSwitch}, 
					{10,								0x0e,									NULL,NULL}, 
					{11,									0x00,								get_LinePowerVoltage1,NULL}, 
					{10,								0x13,									NULL,NULL}, 
					{11,									0x01,								NULL,NULL}, 
					{12,										0x02,							NULL,NULL}, 
					{13,											0x01,						get_DCPowVolt_10,NULL}, 
					{13,											0x02,						get_DCPowVolt_05,NULL}, 
					{13,											0x03,						get_DCPowVolt_24,NULL}, 
					{6,					0xd7,													NULL,NULL}, 
					{7,						0x3b,												NULL,NULL}, 
					{8,							0x01,											NULL,NULL}, 
					{9,								0x01,										NULL,NULL}, 
					{10,								0x01,									get_fnAGCSetting,set_fnAGCSetting}, 
					{10,								0x02,									get_fnAGCSetting,set_fnAGCSetting}, 
					{9,								0x02,										NULL,NULL}, 
					{10,								0x00,									get_fnRCGSetting,set_fnRCGSetting}, 
					//{9,								0x03,										NULL,NULL}, 
					//{10,								0x01,									get_fnIngressSwitchSetting,set_fnIngressSwitchSetting}, 
					//{10,								0x02,									get_fnIngressSwitchSetting,set_fnIngressSwitchSetting}, 
					{9,								0x04,										NULL,NULL}, 
					{10,								0x01,									get_fnAttenuatorSetting,set_fnAttenuatorSetting}, 
					{10,								0x02,									get_fnAttenuatorSetting,set_fnAttenuatorSetting}, 
					{10,								0x03,									get_fnAttenuatorSetting,set_fnAttenuatorSetting}, 
					{10,								0x04,									get_fnAttenuatorSetting,set_fnAttenuatorSetting}, 
					{9,								0x05,										NULL,NULL}, 
					{10,								0x00,									get_fnEqualizerSetting,set_fnEqualizerSetting}, 
					{0,0,NULL,NULL}}; 


static unsigned char *fnGetASN1_length(unsigned char *ucData, unsigned short *usStructureLength)
{
    unsigned short usLength = *ucData++;                                     
    if (usLength & 0x80) {                                               // is length spread over several bytes?
        usLength &= ~0x80;                                               // the number of byte 
        switch (usLength) {
        case 1:
            usLength = *ucData++;
            break;
        case 2:
            usLength = *ucData++;
            usLength <<= 8;
            usLength |= *ucData++;
            break;
        default:                                                         // assume structure length of greater than 64k are invalid
            usLength = 0;
            break;
        }
    }
    *usStructureLength = usLength;
    return ucData;
}

static unsigned short fnFormatFrame(unsigned char *ucData, unsigned short usLength, unsigned char ucPDU_type)
{
    unsigned char *ucFrameStart = ucData;
    unsigned short usFrameLength = usLength;
    unsigned short usObjectLength;
    unsigned char ucType;
    while (usLength--) {
        ucType = *ucData++;
        if ((ucType == ASNSequence) || (ucType == ucPDU_type)) {
            usLength--;
            if (*ucData & 0x80) {                                        // two byte length - we maintain this format
                ucData++;
                *ucData++ = (unsigned char)(usLength >> 8);
                *ucData++ = (unsigned char)(usLength);
                usLength -= 2;
            }
            else {                                                       // single byte length
                if (usLength > 0x7f) {
                    *ucData++ = 0x82;                                    // length as two bytes
                    usLength -= 2;
                    uMemcpy((ucData + 2), ucData, usLength);             // shift contents
                    *ucData++ = (unsigned char)(usLength >> 8);          // add two byte length
                    *ucData++ = (unsigned char)(usLength);
                    usFrameLength += 2;
                    return (fnFormatFrame(ucFrameStart, usFrameLength, ucPDU_type)); // reitterate with new frame and increased length
                }
                else {
                    *ucData++ = (unsigned char)usLength;                 // maintain format
                }
            }
        }
        else {
            fnGetASN1_length(ucData, &usObjectLength);
            if (usObjectLength > 0x7f) {
                ucData += (3 + usObjectLength);
                usLength -= 3;
            }
            else {
                ucData += (1 + usObjectLength);
                usLength--;
            }
            if ((!usObjectLength) || (usObjectLength > usLength)) {
                if (usLength != 0) {
                    return 0;                                            // serious formatting error. Quit to avoid fatal consequences.
                }
            }
            usLength -= usObjectLength;
        }
    }
    return usFrameLength;
}

static unsigned short fnAddTimeStamp(unsigned char *ptrBuffer)
{
    unsigned long ulHundredths = uTaskerSystemTick;
    *ptrBuffer++ = ASNTimeStamp;
    *ptrBuffer++ = sizeof(unsigned long);                                // content length
    ulHundredths *= TICK_RESOLUTION;
    ulHundredths /= 100;                                                 // up time in 100th of second
    *ptrBuffer++ = (unsigned char)(ulHundredths>> 24);
    *ptrBuffer++ = (unsigned char)(ulHundredths>> 16);
    *ptrBuffer++ = (unsigned char)(ulHundredths>> 8);
    *ptrBuffer   = (unsigned char)(ulHundredths);
    return (sizeof(unsigned long) + 2);
}


static int fnGenerateTrap(unsigned char ucTrap, unsigned char ucSpecificCode)
{
//	unsigned char position;
//  const unsigned char ucTestTime[] = {0x43, 0x04, 0x00, 0x0b, 0x97, 0xf8}; // dummy time stamp 
    const unsigned char ucTestObj[] = {0x2b, 6, 1,2,1,2,1,0};
    const unsigned char ucTestObj_d1[] = {0x2b, 6, 1,4,1,0xd7,0x3b,1,10};
    const unsigned char ucTestObj_sys_descr[] = {0x2b, 6, 1,2,1,1,1,0};
//    const unsigned char serial[] = {'0','1', '2', '3', 0};
    unsigned short usLength = 0;
    UDP_MESSAGE UDP_Message;
    UDP_Message.ucUDP_Message[0] = ASNSequence;
    UDP_Message.ucUDP_Message[1] = 0;                                    // place holder for length to be added
    uMemcpy(&UDP_Message.ucUDP_Message[2], ucSNMPV1, sizeof(ucSNMPV1));
    usLength = sizeof(ucSNMPV1) + 2;
    UDP_Message.ucUDP_Message[usLength++] = ASNOctetString;
    UDP_Message.ucUDP_Message[usLength] = uStrlen((char *)&temp_pars->temp_parameters.snmp_user[0]);
	uStrcpy((char *)&UDP_Message.ucUDP_Message[usLength+1], (char *)&temp_pars->temp_parameters.snmp_user[0]);
    usLength += UDP_Message.ucUDP_Message[usLength]+1;
    UDP_Message.ucUDP_Message[usLength++] = ASNSNMPTrap;
    UDP_Message.ucUDP_Message[usLength++] = 0;                           // place holder for length to be added
    UDP_Message.ucUDP_Message[usLength++] = ASNObjectIdentifier;
//	UDP_Message.ucUDP_Message[usLength]=sizeof(cSNMP_enterprise);
//  uMemcpy(&UDP_Message.ucUDP_Message[usLength+1], cSNMP_enterprise, UDP_Message.ucUDP_Message[usLength]);
	UDP_Message.ucUDP_Message[usLength]=sizeof(ucTestObj_d1);
    uMemcpy(&UDP_Message.ucUDP_Message[usLength+1], ucTestObj_d1, UDP_Message.ucUDP_Message[usLength]);
    usLength += UDP_Message.ucUDP_Message[usLength]+1;
    UDP_Message.ucUDP_Message[usLength++] = ASNIPAddress;
    UDP_Message.ucUDP_Message[usLength++] = IPV4_LENGTH;    
    uMemcpy(&UDP_Message.ucUDP_Message[usLength], &network.ucOurIP[0], IPV4_LENGTH);
    usLength += IPV4_LENGTH;
    UDP_Message.ucUDP_Message[usLength++] = ASNInteger;
    UDP_Message.ucUDP_Message[usLength++] = 1;                           // one byte
    UDP_Message.ucUDP_Message[usLength++] = ucTrap;
    UDP_Message.ucUDP_Message[usLength++] = ASNInteger;
    UDP_Message.ucUDP_Message[usLength++] = 1;                           // one byte
    UDP_Message.ucUDP_Message[usLength++] = ucSpecificCode;
    usLength += fnAddTimeStamp(&UDP_Message.ucUDP_Message[usLength]);
    // No object - NULL
	if ((ucTrap==SNMP_COLDSTART)||(ucTrap==SNMP_WARMSTART)){
		UDP_Message.ucUDP_Message[usLength++] = ASNSequence;
		UDP_Message.ucUDP_Message[usLength++] = 0;
		UDP_Message.ucUDP_Message[usLength++] = ASNSequence;
		UDP_Message.ucUDP_Message[usLength++] = 0;
		UDP_Message.ucUDP_Message[usLength++] = ASNObjectIdentifier;

		UDP_Message.ucUDP_Message[usLength]=sizeof(ucTestObj_sys_descr);
		uMemcpy(&UDP_Message.ucUDP_Message[usLength+1], ucTestObj_sys_descr, UDP_Message.ucUDP_Message[usLength]);
		usLength += UDP_Message.ucUDP_Message[usLength]+1;

		UDP_Message.ucUDP_Message[usLength++] = ASNOctetString;
		UDP_Message.ucUDP_Message[usLength] = MAC_LENGTH;
		uMemcpy(&UDP_Message.ucUDP_Message[usLength+1], network.ucOurMAC, UDP_Message.ucUDP_Message[usLength]);
		usLength += UDP_Message.ucUDP_Message[usLength]+1;
	}
    usLength = fnFormatFrame(UDP_Message.ucUDP_Message, usLength, ASNSNMPTrap);

	if (!usLength) {
        usLength = (UDP_Message.ucUDP_Message[1] + 2);
    }

    return (fnSendUDP(SNMPSocketNr, ucIP_SNMP_Manager, SNMP_MANAGER_PORT, (unsigned char *)&UDP_Message.tUDP_Header, usLength, OWN_TASK) < usLength);
}
typedef struct stTrapList {
    unsigned char ucTrapType;
    unsigned char ucTrapSpecificCode;
}
TRAP_LIST;

#define TRAP_QUEUE_LENGTH 3

TRAP_LIST trap_list[TRAP_QUEUE_LENGTH] = {0};

static void fnResendSNMPTrap(void)
{
    if (fnGenerateTrap(trap_list[0].ucTrapType, trap_list[0].ucTrapSpecificCode) == 0) {                      
        int iTrapQueue = 1;                                              // frame could be delivered this time so delete it from the queue
        while (--ucTrapCnt != 0) {                                       // any further in queue are also sent now
            fnGenerateTrap(trap_list[iTrapQueue].ucTrapType, trap_list[iTrapQueue].ucTrapSpecificCode);
            iTrapQueue++;
        }
    } 
}


// List of traps waiting to be sent (list is used only when manager is being resolved)
//
static void fnEnterTrap(unsigned char ucTrap, unsigned char ucSpecificCode)
{
    if (ucTrapCnt >= TRAP_QUEUE_LENGTH) {
        return;                                                          // no space left - drop trap message
    }
    trap_list[ucTrapCnt].ucTrapType = ucTrap;
    trap_list[ucTrapCnt].ucTrapSpecificCode = ucSpecificCode;
    ucTrapCnt++;
}

// Resend a filed trap frame - usually due to ARP resolve
//
static int fnRetry(void)
{
    if (ucSNMPRetries < SNMP_NUM_RETRIES) {
        ucSNMPRetries++;
        fnResendSNMPTrap();                                              // try again
    }
    else {                                                               // last timeout - resolution failed
        ucSNMPRetries = 0;
        ucTrapCnt = 0;                                                   // cancel any trap sin teh queue bbecause there is no manager available
        return 1;                                                        // we give up
    }
    return 0;                                                            // OK - repetition attempted
}


// The SNMP listner function for SNMP port
//
static int fnSNMPListner(USOCKET SocketNr, unsigned char ucEvent, unsigned char *ucIP, unsigned short usPortNr, unsigned char *data, unsigned short usLength)
{
//    unsigned char SNMP_data[40];

    UDP_MESSAGE tUDP_Message;                                            // message space
	char access;
    unsigned short Length = 0;
//	int temp;
	unsigned char *l_ver;
	unsigned char *l_pass;
	unsigned char *l_rid;
	unsigned char *l_Cn;
	unsigned char *l_Cp;
	unsigned char *Cn;
	unsigned char *Cp;
	unsigned char *l_errstat;
	unsigned char *l_errid;
	unsigned char *l_mib;
	unsigned char *l_data;
	unsigned char *l4;
	unsigned char *l7;
	unsigned char *l8;
	unsigned char *dataType;
	unsigned char *PDU;
	unsigned char err_n=0;
 			 char pass[MAX_PASS_LEN];
//	unsigned char *MIB=0;
//	unsigned char SNMP_STATE;
	mtypes	mdata;
	unsigned char err=0; 
	unsigned char oid_i=0;
	static volatile unsigned long ttt=0;
	volatile unsigned long ppp;

	struct asn_oid poid;
	struct asn_oid soid;

//    unsigned char *ucBuf = tUDP_Message.ucUDP_Message;                   // insert to message content

//    uMemset(ucBuf, 0, SNMP_BUFFER);                                      // ensure message contents cleared
	uMemset(poid.subs, 0, ASN_MAXOIDLEN);                                // ensure message contents cleared
	uMemset(mdata.data, 0, MAX_STR_LEN);                                 // ensure message contents cleared
	uMemset(pass, 0, MAX_PASS_LEN);
//    System mib_system;

	if (SocketNr != SNMPSocketNr) return NOT_SNMP_SOCKET;                // not our socket so ignore
	
	if (*data != ASNSequence) return 0;

	l_ver=(data+3);
	l_pass=(l_ver+2+*l_ver);

	uMemcpy(pass,(l_pass+1),*(unsigned char *)l_pass);

	if (!(access=check_pass(pass))) {
		return 0;
	}

	PDU=(l_pass+1+*l_pass);
	l4=(PDU+1);
    l_rid=(l4+2);
	if (*PDU==ASNGetBulkRequestPDU){
		l_Cn = (l_rid+2+*l_rid);
		Cn = (l_Cn+1); 
		l_Cp = (l_Cn+*l_Cn+2);
		Cp = (l_Cp+1);
		l7=(l_Cp+2+*l_Cp);
	}
	else{
		l_errstat=(l_rid+2+*l_rid);
		l_errid=(l_errstat+2+*l_errstat);
		l7=(l_errid+2+*l_errid);
	}
	l8=(l7+2);
	l_mib=(l8+2);
	dataType=(l_mib+1+*l_mib);
	l_data=(dataType+1);

	poid.len=*l_mib;
	uMemcpy(poid.subs,(l_mib+1),poid.len);
	
	while (mib_tab[oid_i].len){
		soid.len = mib_tab[oid_i].len;
		soid.subs[(mib_tab[oid_i].len-1)]=mib_tab[oid_i].obj;

		if (!asn_compare_oid(&soid, &poid)) break;
		oid_i++;
	}
	
	if (!mib_tab[oid_i].len){
		err=noSuchName;
		err_n++;
	}
	else{
		ppp=uTaskerSystemTick;
		if ((ppp-ttt)>2){ 
			get_Ampl_reg(&areg,&rt_regs);
			ttt=uTaskerSystemTick;
		}
		switch (*PDU) {
			case ASNGetNextRequestPDU:
				do {

					oid_i++;
					soid.len = mib_tab[oid_i].len;
					soid.subs[(mib_tab[oid_i].len-1)]=mib_tab[oid_i].obj;

				} while ((!mib_tab[oid_i].func_get)&&(mib_tab[oid_i].len));

				if (!mib_tab[oid_i].len){
					err=noSuchName;
					err_n++;
				}
				else err=mib_tab[oid_i].func_get(&mdata,&soid);
				break;

			case ASNGetRequestPDU:
				if (!mib_tab[oid_i].func_get){
					err=noSuchName;
					err_n++;
				}
				else err=mib_tab[oid_i].func_get(&mdata,&soid);
				break;

			case ASNSetRequestPDU:
				if (!mib_tab[oid_i].func_get){
					err=noSuchName;
					err_n++;
				}
				else{ 
					if (access<0){
						err=noAccess;
						err_n++;
					}
					else{
						if (!mib_tab[oid_i].func_set){
							err=readOnly;
							err_n++;
						}
						else{ 
							mdata.type=*dataType;
							uMemcpy(&mdata.data,(data+22+*l_pass+*l_ver+*l_rid+*l_errstat+*l_errid+*l_mib),*l_data);
							mdata.len=*l_data;
							err=mib_tab[oid_i].func_set(&mdata,&soid);
						}
					}
				}
				break;

			default:
				err=genErr;
				err_n++;
		}
	}



///*
	tUDP_Message.ucUDP_Message[Length++]=ASNSequence;
	tUDP_Message.ucUDP_Message[Length++]=0;
//-----------
	tUDP_Message.ucUDP_Message[Length++]=ASNInteger;
	tUDP_Message.ucUDP_Message[Length++]=*l_ver;
	uMemcpy(&tUDP_Message.ucUDP_Message[Length],(l_ver+1), *l_ver);
	Length+=*l_ver;
	tUDP_Message.ucUDP_Message[Length++]=ASNOctetString;
	tUDP_Message.ucUDP_Message[Length++]=*l_pass;
	uMemcpy(&tUDP_Message.ucUDP_Message[Length],pass,*l_pass);
	Length+=*l_pass;
	tUDP_Message.ucUDP_Message[Length++]=ASNGetResponsePDU;
	tUDP_Message.ucUDP_Message[Length++]=0;
	//-----------
	tUDP_Message.ucUDP_Message[Length++]=ASNInteger;
	tUDP_Message.ucUDP_Message[Length++]=*l_rid;
	uMemcpy(&tUDP_Message.ucUDP_Message[Length],(unsigned char *)(l_rid+1),*l_rid);
	Length+=*l_rid;
	tUDP_Message.ucUDP_Message[Length++]=ASNInteger;
	tUDP_Message.ucUDP_Message[Length++]=1;
	tUDP_Message.ucUDP_Message[Length++]=err;
	tUDP_Message.ucUDP_Message[Length++]=ASNInteger;
	tUDP_Message.ucUDP_Message[Length++]=1;
	tUDP_Message.ucUDP_Message[Length++]=err_n;
	tUDP_Message.ucUDP_Message[Length++]=ASNSequence;
	tUDP_Message.ucUDP_Message[Length++]=0;
	//------------------------
	tUDP_Message.ucUDP_Message[Length++]=ASNSequence;
	tUDP_Message.ucUDP_Message[Length++]=0;
	//-------------------------
	tUDP_Message.ucUDP_Message[Length++]=ASNObjectIdentifier;
	if (!err){
		tUDP_Message.ucUDP_Message[Length++]=soid.len;
		uMemcpy(&tUDP_Message.ucUDP_Message[Length],soid.subs,soid.len);
		Length+=soid.len;
		tUDP_Message.ucUDP_Message[Length++]=mdata.type;
		if (mdata.type==ASNOctetString){
			tUDP_Message.ucUDP_Message[Length++]=uStrlen((char *)&mdata.data);
			uStrcpy((char *)&tUDP_Message.ucUDP_Message[Length],(char *)&mdata.data);
			Length+=uStrlen((char *)&mdata.data);
		}

		if (mdata.type==ASNInteger){
			tUDP_Message.ucUDP_Message[Length++]=mdata.len;
			if (mdata.len){ 
				uMemcpy((signed char *)&tUDP_Message.ucUDP_Message[Length],(signed char *)&mdata.data,mdata.len);
				Length+=mdata.len;
			}

		}
	}
	else{
		tUDP_Message.ucUDP_Message[Length++]=*l_mib;
		uMemcpy(&tUDP_Message.ucUDP_Message[Length],l_mib+1,*l_mib);
		Length+=*l_mib;
		tUDP_Message.ucUDP_Message[Length++]=ASNNull;
		tUDP_Message.ucUDP_Message[Length++]=0;
	}
	
	Length = fnFormatFrame(tUDP_Message.ucUDP_Message, Length, ASNGetResponsePDU);

	fnSendUDP(SNMPSocketNr, ucIP, usPortNr, (unsigned char *)&tUDP_Message.tUDP_Header, Length, OWN_TASK);

    return 0;
}

extern void fnSendSNMPTrap(unsigned char ucTrap, unsigned char ucSpecificCode)
{
    if ((ucTrapCnt != 0) || (fnGenerateTrap(ucTrap, ucSpecificCode))) {  // is manager presently being resolved
        fnEnterTrap(ucTrap, ucSpecificCode);                             // frame could not be delivered on first attempt (usually due to ARP resolution being started) - enter in the trap list in preparation for repeat attempt(s)
    }
}

#endif
