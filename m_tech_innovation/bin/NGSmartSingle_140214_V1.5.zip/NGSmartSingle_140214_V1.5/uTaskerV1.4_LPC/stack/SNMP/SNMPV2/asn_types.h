#ifndef ASN_TYPES_H
#define ASN_TYPES_H

typedef unsigned char uint8_t;
typedef char int8_t;
typedef unsigned int u_int;
typedef unsigned char u_char;
typedef unsigned short uint16_t;
//typedef unsigned int uint32_t;
typedef int int32_t;
typedef unsigned long uint64_t;
typedef long int64_t;
//typedef unsigned int size_t;
typedef unsigned long u_long;

#ifndef NULL
#define NULL 0
#endif

#define INT32_MAX 0x7fffffffL
#define INT32_MIN (-INT32_MAX - 1L)
#define UINT32_MAX (0x7fffffffUL * 2UL + 1UL)

#endif
