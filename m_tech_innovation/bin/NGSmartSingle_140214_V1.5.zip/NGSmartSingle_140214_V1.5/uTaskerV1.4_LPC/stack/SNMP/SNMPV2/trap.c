#include "config.h"
#include "../../Applications/uTaskerV1.3/utils.h"
#include "../../Applications/uTaskerV1.3/app_params.h"
#include "../Communication/alarms.h"
#include "asn_types.h"
#include "asn1.h"
#include "snmp.h"
#include "trap.h"

#define OWN_TASK TASK_TRAP

#define SNMP_BUFFER 512

#define E_TIMER_TRAP_INIT_DELAY 179

typedef struct stUDP_MESSAGE
{
    UDP_HEADER       tUDP_Header;                                         // reserve header space
    unsigned char    ucUDP_Message[SNMP_BUFFER];
} UDP_MESSAGE;

enum trap_task_state {
	TASK_INIT, 
	TASK_COLDSTART,
	TASK_IDLE,
};
static enum trap_task_state task_state = TASK_INIT;

// reserved space for responce UDP frame
static struct stUDP_MESSAGE respUdp;

// reserve space for trap PDU and ASN
static struct snmp_pdu pdu;
static struct asn_buf resp_b;

static char buf[17]; // buffer for MAC formatting

const struct asn_oid oid_sysUpTime = {8, {1,3,6,1,2,1,1,3}};
const struct asn_oid oid_snmpTrapOID = {10, {1,3,6,1,6,3,1,1,4,1}};
const struct asn_oid oid_coldStart = {10, {1,3,6,1,6,3,1,1,5,1}}; 

static int req_id = 0;

static USOCKET snmp_trap_socket = -1;

static void snmp_send_coldtart_trap(void);
static int fnTrapSocketListener(USOCKET SocketNr, unsigned char ucEvent, unsigned char *ucIP, unsigned short usPortNr, unsigned char *data, unsigned short usLength);

// This trap-sending task 
void fnTrapTask(TTASKTABLE *p_task_table) {
    QUEUE_HANDLE port_ID_internal = p_task_table->TaskID;                // queue ID for task input
    unsigned char uc_input_message[SMALL_QUEUE];                         // reserve space for receiving messages

	// initialize UDP socket for SNMP traps
	if (task_state == TASK_INIT) {
		if (snmp_trap_socket == -1) {
			snmp_trap_socket = fnGetUDP_socket(TOS_MINIMISE_DELAY, fnTrapSocketListener, UDP_OPT_SEND_CS | UDP_OPT_CHECK_CS);
		}
		if (snmp_trap_socket >= 0) {
			fnBindSocket(snmp_trap_socket, SNMP_MANAGER_PORT);
			task_state = TASK_COLDSTART;
		} else {
			fnDebugMsg("SNMP: cannot allocate trap socket, trap functionality disabled\r\n");
		}
	}

    if (fnRead(port_ID_internal, uc_input_message, HEADER_LENGTH)) {
		switch (uc_input_message[MSG_SOURCE_TASK]) {
			case TIMER_EVENT:
				fnDebugMsg("SNMP: resending last trap to ");
				display_ip(snmp_trap_dst, TRAIL_CR);
				fnSendUDP(snmp_trap_socket, snmp_trap_dst, SNMP_MANAGER_PORT, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, OWN_TASK);					break;

			case TASK_ARP:
				fnRead(port_ID_internal, uc_input_message, uc_input_message[MSG_CONTENT_LENGTH]); // read the contents
				if (uc_input_message[0] == ARP_RESOLUTION_FAILED) {
					fnDebugMsg("SNMP: ARP failed for ");
					display_ip(snmp_trap_dst, 0);
					fnDebugMsg(", retry in 60s\r\n");
					uTaskerMonoTimer(OWN_TASK, (CLOCK_LIMIT)(60*SEC), E_TIMER_TRAP_INIT_DELAY);
				} else if (uc_input_message[0] == ARP_RESOLUTION_SUCCESS) {
					fnDebugMsg("SNMP: ARP ok for ");
					display_ip(snmp_trap_dst, TRAIL_CR);
					fnDebugMsg("SNMP: resending last trap to ");
					display_ip(snmp_trap_dst, TRAIL_CR);
					fnSendUDP(snmp_trap_socket, snmp_trap_dst, SNMP_MANAGER_PORT, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, OWN_TASK);	
				}
				break;
		}
    }
}

static int fnTrapSocketListener(USOCKET SocketNr, unsigned char ucEvent, unsigned char *ucIP, unsigned short usPortNr, unsigned char *data, unsigned short usLength)
{
	return 0;
}

static const struct asn_oid oid_scteHmsTree = {8, {1,3,6,1,4,1,5591,1}};
static const struct asn_oid oid_commonPhysAddress = {11, {1,3,6,1,4,1,5591,1,3,2,7}};
static const struct asn_oid oid_commonLogicalID = {11, {1,3,6,1,4,1,5591,1,3,1,1}};
static const struct asn_oid oid_alarmLogInformation = {12, {1,3,6,1,4,1,5591,1,2,3,1,2}};

void snmp_send_hms_alarm_trap(int alarm_idx) {
	// first coldStart should be sent
	uMemset(&pdu, 0, sizeof(pdu));
	uStrcpy(pdu.community, parameters->snmp_trap_community);

	// for legacy reason send V1 trap
	pdu.version = SNMP_V1;
	pdu.type = SNMP_PDU_TRAP;
	pdu.enterprise = oid_scteHmsTree;
	pdu.generic_trap = 6;
	pdu.specific_trap = 1;
	uMemcpy(pdu.agent_addr, network.ucOurIP, 4);
	pdu.time_stamp = uTaskerSystemTick * 5;

	pdu.bindings[0].var = oid_commonPhysAddress;
	pdu.bindings[0].var.subs[pdu.bindings[0].var.len++] = 0;
	pdu.bindings[0].syntax = SNMP_SYNTAX_OCTETSTRING;
	pdu.bindings[0].v.octetstring.len = 6;
	pdu.bindings[0].v.octetstring.octets = (unsigned char*)&network.ucOurMAC[0];

	pdu.bindings[1].var = oid_commonLogicalID;
	pdu.bindings[1].var.subs[pdu.bindings[1].var.len++] = 0;
	pdu.bindings[1].syntax = SNMP_SYNTAX_OCTETSTRING;
	pdu.bindings[1].v.octetstring.len = uStrlen(parameters->logicalID);
	pdu.bindings[1].v.octetstring.octets = (unsigned char*) parameters->logicalID;
	
	pdu.bindings[2].var = oid_alarmLogInformation;
	pdu.bindings[2].var.subs[pdu.bindings[2].var.len++] = alarm_idx;
	pdu.bindings[2].syntax = SNMP_SYNTAX_OCTETSTRING;
	pdu.bindings[2].v.octetstring.octets = alarm_encode_entry(alarm_idx, &pdu.bindings[2].v.octetstring.len);
	
	pdu.nbindings = 3;

	resp_b.asn_cptr = respUdp.ucUDP_Message;
	resp_b.asn_len = SNMP_BUFFER;

	if (snmp_pdu_encode(&pdu, &resp_b) == SNMP_CODE_OK && snmp_trap_socket != -1) {
		fnSendUDP(snmp_trap_socket, snmp_trap_dst, SNMP_MANAGER_PORT, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, OWN_TASK);	
		fnDebugMsg("SNMP: HMS alarm trap sent\r\n");
	} else {
		fnDebugMsg("SNMP: HMS alarm could not be sent\r\n");
	}
}

void snmp_send_hms_coldstart_trap() {
	uMemset(&pdu, 0, sizeof(pdu));
	uStrcpy(pdu.community, parameters->snmp_trap_community);

	// for legacy reason send V1 trap
	pdu.version = SNMP_V1;
	pdu.type = SNMP_PDU_TRAP;
	pdu.enterprise = oid_scteHmsTree;
	pdu.generic_trap = 6;
	pdu.specific_trap = 0;
	uMemcpy(pdu.agent_addr, network.ucOurIP, 4);
	pdu.time_stamp = uTaskerSystemTick * 5;

	pdu.bindings[0].var = oid_commonPhysAddress;
	pdu.bindings[0].var.subs[pdu.bindings[0].var.len++] = 0;
	pdu.bindings[0].syntax = SNMP_SYNTAX_OCTETSTRING;
	pdu.bindings[0].v.octetstring.len = 6;
	pdu.bindings[0].v.octetstring.octets = (unsigned char*)&network.ucOurMAC[0];

	pdu.bindings[1].var = oid_commonLogicalID;
	pdu.bindings[1].var.subs[pdu.bindings[1].var.len++] = 0;
	pdu.bindings[1].syntax = SNMP_SYNTAX_OCTETSTRING;
	pdu.bindings[1].v.octetstring.len = uStrlen(parameters->logicalID);
	pdu.bindings[1].v.octetstring.octets = (unsigned char*) parameters->logicalID;
	
	pdu.nbindings = 2;

	resp_b.asn_cptr = respUdp.ucUDP_Message;
	resp_b.asn_len = SNMP_BUFFER;

	if (snmp_pdu_encode(&pdu, &resp_b) == SNMP_CODE_OK && snmp_trap_socket != -1) {
		fnSendUDP(snmp_trap_socket, snmp_trap_dst, SNMP_MANAGER_PORT, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, OWN_TASK);	
		fnDebugMsg("SNMP: v1 coldStart trap sent\r\n");
	} else {
		fnDebugMsg("SNMP: v1 coldStart trap could not be sent\r\n");
	}
}



void snmp_send_trap(const struct asn_oid *trap_oid, struct snmp_value* val) {
	uMemset(&pdu, 0, sizeof(pdu));
	uStrcpy(pdu.community, parameters->snmp_trap_community);

	// We send only v2c traps
	pdu.version = SNMP_V2c;
	pdu.type = SNMP_PDU_TRAP2;
	pdu.request_id = req_id++;
	pdu.error_index = 0;
	pdu.error_status = SNMP_ERR_NOERROR;

	pdu.bindings[0].var = oid_sysUpTime;
	pdu.bindings[0].var.subs[pdu.bindings[0].var.len++] = 0;
	pdu.bindings[0].syntax = SNMP_SYNTAX_TIMETICKS;
	pdu.bindings[0].v.uint32 = uTaskerSystemTick * 5;

	pdu.bindings[1].var = oid_snmpTrapOID;
	pdu.bindings[1].var.subs[pdu.bindings[1].var.len++] = 0;
	pdu.bindings[1].syntax = SNMP_SYNTAX_OID;
	pdu.bindings[1].v.oid = *trap_oid;

	pdu.nbindings = 2;

	if (val != 0) {
		pdu.bindings[pdu.nbindings++] = *val;
	}

	resp_b.asn_cptr = respUdp.ucUDP_Message;
	resp_b.asn_len = SNMP_BUFFER;

	if (snmp_pdu_encode(&pdu, &resp_b) == SNMP_CODE_OK && snmp_trap_socket != -1) {
		fnSendUDP(snmp_trap_socket, snmp_trap_dst, SNMP_MANAGER_PORT, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, OWN_TASK);	
	}
}


