#ifndef TRAP_H_
#define TRAP_H_

#include "asn1.h"
#include "snmp.h"

#define SNMP_TRAP_QUEUE_SIZE 10

typedef struct snmp_trap_q_item {
	struct asn_oid* trap_oid;
	struct snmp_value val;
} snmp_trap_q_item_t;

void snmp_send_hms_alarm_trap(int alarm_idx);
void snmp_send_hms_coldstart_trap();

#endif
