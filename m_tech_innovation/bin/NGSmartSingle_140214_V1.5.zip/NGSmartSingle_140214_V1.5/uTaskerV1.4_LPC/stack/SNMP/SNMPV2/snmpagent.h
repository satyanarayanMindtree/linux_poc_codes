/*
 * Copyright (c) 2001-2003
 *	Fraunhofer Institute for Open Communication Systems (FhG Fokus).
 *	All rights reserved.
 *
 * Author: Harti Brandt <harti@freebsd.org>
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Begemot: bsnmp/lib/snmpagent.h,v 1.13 2004/08/06 08:46:56 brandt Exp $
 *
 * Header file for SNMP functions. This requires snmp.h to be included.
 */
#ifndef SNMP_AGENT_H_
#define SNMP_AGENT_H_

#include "snmp.h"

extern int fnSNMPStart(void);

/* result values of high-level agent functions */
enum snmp_ret {
	/* OK, generate a response */
	SNMP_RET_OK	= 0,
	/* Error, ignore packet (no response) */
	SNMP_RET_IGN	= 1,
	/* Error, generate response from original packet */
	SNMP_RET_ERR	= 2
};


/*
 * The TREE
 */
enum snmp_node_type {
	SNMP_NODE_LEAF = 1,
	SNMP_NODE_COLUMN
};

enum snmp_op {
	SNMP_OP_GET 	= 1,
	SNMP_OP_GETNEXT,
	SNMP_OP_SET,
	SNMP_OP_COMMIT,
	SNMP_OP_ROLLBACK,
};

#define SNMP_NODE_CANSET	0x80	/* SET allowed */

typedef int (*snmp_op_t)(struct snmp_value *, u_int, enum snmp_op);

typedef struct snmp_node {
	struct asn_oid oid;
	enum snmp_node_type type;	/* type of this node */
	enum snmp_syntax syntax;
	snmp_op_t	op;
} snmp_node_t;

#endif
