/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:       UDP.c
    Project:    Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    08.04.2007 Don't send destination unreachable to subnet broadcast (with new SUPPORT_SUBNET_BROADCAST) {1}
    06.09.2010 Optimise reception code when the device performs rx offloading {2}

*/        

//#include "config.h"    
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


#ifdef USE_UDP                                                           // If we want to use UDP

#define UDP_STATE_FREE          0                                        // this must be zero
#define UDP_STATE_CLOSED        1
#define UDP_STATE_OPENED        2


/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */

static UDP_TAB *tUDP = 0;

// An application can obtain an UDP socket by calling this function
//
extern USOCKET fnGetUDP_socket(unsigned char ucTOS, int (*fnListener)(USOCKET, unsigned char, unsigned char *, unsigned short, unsigned char *, unsigned short), unsigned char ucOpts)
{
    UDP_TAB *ptrUDP;
    USOCKET udpSocket = 0;

    if (!tUDP) {                                                         // automatically get heap space on first call 
        tUDP = (UDP_TAB*)uMalloc(sizeof(UDP_TAB)*UDP_SOCKETS);           // get UDP table space (our malloc zeroes it)
    }

    ptrUDP = tUDP;

    if (!fnListener) {
        return NO_LISTENER_DEFINED;                                      // the application must define a listener function
    }

    while (udpSocket < UDP_SOCKETS) {
        if (ptrUDP->ucState == UDP_STATE_FREE) {                         // search for the next free socket
            ptrUDP->ucState       = UDP_STATE_CLOSED;                    // initialise socket structure
            ptrUDP->ucServiceType = ucTOS;
            ptrUDP->usLocalPort   = 0;
            ptrUDP->ucOptions     = ucOpts;
            ptrUDP->fnListener    = fnListener;
            return udpSocket;                                            // socket 0.. max-1 returned
        }
        ptrUDP++;
        udpSocket++;                                   
    }
    return NO_FREE_UDP_SOCKETS;                                          // no free UDP sockets
}

// This routine is called to find the corresponding open UDP socket
//
static USOCKET fnFindOpenSocket(unsigned short usDestinationPort)
{
    UDP_TAB *ptrUDP = tUDP;
    USOCKET udpSocket = 0;

    if (!ptrUDP) {
        return UDP_NOT_INITIALISED;
    }

    while (udpSocket < UDP_SOCKETS) {
        if ((ptrUDP->ucState == UDP_STATE_OPENED) && (ptrUDP->usLocalPort == usDestinationPort)) {
            return udpSocket;
        }
        udpSocket++;
        ptrUDP++;
    }
    return NO_UDP_LISTENER_FOUND;                                        // no open socket for this port found
}

// The client/server can call this to release a socket which is no longer required
//
extern USOCKET fnReleaseUDP_socket(USOCKET cSocketHandle)
{
    UDP_TAB *ptrUDP = tUDP;
    
    if ((!ptrUDP) || ( cSocketHandle > UDP_SOCKETS )) {
        return INVALID_SOCKET_HANDLE;
    }

    ptrUDP += cSocketHandle;
    uMemset(ptrUDP, 0x00, sizeof(UDP_TAB));                              // clear no longer used socket structure

    return (cSocketHandle);                                              // this socket has just been freed
}

// After the client/server has obtained a socket it can bind it using this function
//
extern USOCKET fnBindSocket(USOCKET SocketHandle, unsigned short usLocalPort)
{
    UDP_TAB *ptrUDP = tUDP;
    
    if ((!ptrUDP) || ( SocketHandle > UDP_SOCKETS )) return INVALID_SOCKET_HANDLE;

    if (usLocalPort == 0) {
        return(INVALID_LOCAL_PORT);                                      // a local port with number zero is not allowed
    }
    
    ptrUDP += SocketHandle;                                              // bind the port by setting its local port number
    ptrUDP->ucState = UDP_STATE_OPENED;
    ptrUDP->usLocalPort = usLocalPort;
    return (SocketHandle);
}


const unsigned char ucIP_UDP_TYPE[] = {0x00, IP_UDP};

// This is called when a UDP frame has been received
//
extern void fnHandleUDP(unsigned short usIP_HeaderLength, IP_PACKET *received_ip_packet)
{
    UDP_HEADER received_udp;
    USOCKET Socket;
    unsigned char *icp_data = (unsigned char *)received_ip_packet;
    
    icp_data += usIP_HeaderLength;

    received_udp.usSourcePort       = ((*icp_data++) << 8);
    received_udp.usSourcePort      |= *icp_data++;

    received_udp.usDestinationPort  = ((*icp_data++) << 8);
    received_udp.usDestinationPort |= *icp_data++;

    received_udp.usLength           = ((*icp_data++) << 8);
    received_udp.usLength          |= *icp_data++;

    if (received_udp.usLength < UDP_HLEN) {
        return;                                                          // frame too short to be a valid UDP frame so ignore it
    }

    received_udp.ucCheckSum         = ((*icp_data++) << 8);
    received_udp.ucCheckSum        |= *icp_data++;

    if ((Socket = fnFindOpenSocket(received_udp.usDestinationPort)) < 0) { // try to find an open socket with the destination port to handle the received message
#ifdef USE_ICMP
    #ifdef ICMP_DEST_UNREACHABLE
        #ifdef SUPPORT_SUBNET_BROADCAST
        if (!fnSubnetBroadcast(received_ip_packet->destination_IP_address, &network.ucNetMask[0], IPV4_LENGTH)) // {1}
        #else
        if (uMemcmp(received_ip_packet->destination_IP_address, cucBroadcast, IPV4_LENGTH)) 
        #endif
        {                                                                // don't send destination unreachable to broadcast messages
            ICMP_ERROR tICMP_error;                                      // Send ICMP here to inform that no open destination port exists in our system

            tICMP_error.ucICMPType = DESTINATION_UNREACHABLE;            // add ICMP header type 
            tICMP_error.ucICMPCode = PORT_UNREACHABLE;                   // add ICMP header code
            uMemset(&tICMP_error.ucICMPCheckSum, 0, sizeof(tICMP_error.ucICMP_variable) + sizeof(tICMP_error.ucICMPCheckSum)); // zero rest of header

            // we are expected to report the complete IP header plus the start of the IP datagram which was received
            uMemcpy(&tICMP_error.tCopy_IP_header, &received_ip_packet->version_header_length, usIP_HeaderLength + REPORTING_LENGTH_UDP_UNREACHABLE);
            fnSendICMPError(&tICMP_error, (unsigned short)((REPORTING_LENGTH_UDP_UNREACHABLE + ICMP_ERROR_HEADER_LENGTH) + usIP_HeaderLength)); 
        }
    #endif
#endif
        return;
    }
    else {
        UDP_TAB *ptrUDP = tUDP;                                          // we have a receiver socket for this UDP frame
        ptrUDP += Socket;
#if !defined IP_RX_CHECKSUM_OFFLOAD || defined _WINDOWS                  // {2}
        if ((ptrUDP->ucOptions & UDP_OPT_CHECK_CS) && (received_udp.ucCheckSum != 0)) {
            unsigned char ucTemp[2];                                     // we check its check sum
            unsigned short usCheckSum = 0;

            usCheckSum = fnCalcIP_CS(0, received_ip_packet->destination_IP_address, IPV4_LENGTH);// do it firstly to IP pseudo header
            usCheckSum = fnCalcIP_CS(usCheckSum, received_ip_packet->source_IP_address, IPV4_LENGTH);
            usCheckSum = fnCalcIP_CS(usCheckSum, (unsigned char *)ucIP_UDP_TYPE, sizeof(ucIP_UDP_TYPE));
            ucTemp[0] = (unsigned char)((received_udp.usLength)>>8);
            ucTemp[1] = (unsigned char)(received_udp.usLength);
            usCheckSum = fnCalcIP_CS(usCheckSum, ucTemp, sizeof(received_udp.usLength));    

            if (fnCalcIP_CS(usCheckSum, (icp_data - 8), received_udp.usLength) != 0xffff) {
    #ifndef _WINDOWS                                                     // avoid potential UDP checksum offload problem when simulating
                return;                                                  // ignore bad check sums
    #endif
            }    
        }
#endif
        // Pass the received frame contents to the listener
        //
        ptrUDP->fnListener(Socket, UDP_EVENT_RXDATA, received_ip_packet->source_IP_address, received_udp.usSourcePort, icp_data, (unsigned short)(received_udp.usLength-UDP_HLEN));
    }
}

// The client/server call this routine to send a UDP message. The caller ensures that the transmit buffer contains UDP header space
//
extern signed short fnSendUDP(USOCKET SocketHandle, unsigned char *dest_IP, unsigned short usRemotePort, unsigned char *ptrBuf, unsigned short usDataLen, UTASK_TASK OwnerTask)
{
    UDP_TAB *ptrUDP = tUDP;
    unsigned char *ptrData;

    if (SocketHandle > UDP_SOCKETS) {
        return INVALID_SOCKET_HANDLE;
    }
    if (!(uMemcmp(dest_IP, cucNullMACIP, IPV4_LENGTH))) {
        return(INVALID_DEST_IP);
    }
    if (!usRemotePort) {
        return INVALID_REMOTE_PORT;
    }

    usDataLen += UDP_HLEN;
    
    if (usDataLen > UDP_SEND_MTU) {
        usDataLen = UDP_SEND_MTU;                                        // if the user tries to send messages larger that possible we simply shorten them
    }
    
    ptrUDP += SocketHandle;

    if (ptrUDP->ucState != UDP_STATE_OPENED) {
        return SOCKET_CLOSED;
    }

    if (!ptrUDP->usLocalPort) {
        return ZERO_PORT;
    }

    ptrData = ptrBuf;                        
    
    *ptrBuf++ = (unsigned char)((ptrUDP->usLocalPort) >> 8);             // put header into user buffer
    *ptrBuf++ = (unsigned char)ptrUDP->usLocalPort;
    *ptrBuf++ = (unsigned char)(usRemotePort >> 8);
    *ptrBuf++ = (unsigned char)usRemotePort;
    *ptrBuf++ = (unsigned char)((usDataLen ) >> 8);
    *ptrBuf++ = (unsigned char)(usDataLen);
    *ptrBuf++ = 0;                                                       // checksum space
    *ptrBuf   = 0;
    
    if (ptrUDP->ucOptions & UDP_OPT_SEND_CS) {                           // calculate checksum if needed    
        unsigned char  ucTemp[2];
        unsigned short usCheckSum = 0;

        usCheckSum = fnCalcIP_CS(0, &network.ucOurIP[0], IPV4_LENGTH);   // do it firstly to IP pseudo header
        usCheckSum = fnCalcIP_CS(usCheckSum, dest_IP, IPV4_LENGTH);
        usCheckSum = fnCalcIP_CS(usCheckSum, (unsigned char *)ucIP_UDP_TYPE, sizeof(ucIP_UDP_TYPE));
        ucTemp[0] = (unsigned char)((usDataLen)>>8);
        ucTemp[1] = (unsigned char)(usDataLen);
        usCheckSum = fnCalcIP_CS(usCheckSum, ucTemp, sizeof(usDataLen));    
    
        if ((usCheckSum = ~fnCalcIP_CS(usCheckSum, ptrData, usDataLen)) == 0) {
            usCheckSum = 0xffff;                                         // avoid zero as checksum since this signifies no check sum, it is equivalent to 0x0000
        }

        ptrBuf--;
        *ptrBuf++ = (unsigned char)(usCheckSum >> 8);                    // save checksum in correct place
        *ptrBuf   = (unsigned char)(usCheckSum);    
    }        
    return (fnSendIP(dest_IP, IP_UDP, TOS_NORMAL_SERVICE, MAX_TTL, ptrData, usDataLen, OwnerTask, SocketHandle));
}

#ifdef ICMP_DEST_UNREACHABLE
 
// ICMP reports if a destination reports that a UDP port was not reachable
//
extern void fnReportUDP(unsigned short usSourcePort, unsigned short usDestPort, unsigned char ucEvent, unsigned char *ucIP)
{
    USOCKET udpSocket;

    if ((udpSocket = fnFindOpenSocket(usSourcePort)) >= 0) {             // find the (open) socket which sent the UDP message
        UDP_TAB *ptrUDP = tUDP + udpSocket;                              // get socket details

        (void)ptrUDP->fnListener(udpSocket, ucEvent, ucIP, usDestPort, 0, 0); // inform the event to the server/client 
    }
}
#endif                                                                   // end UDP ICMP reporting

#endif                                                                   // end UDP support
