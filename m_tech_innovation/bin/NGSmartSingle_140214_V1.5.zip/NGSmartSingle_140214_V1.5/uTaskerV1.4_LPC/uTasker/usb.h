/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        usb.h
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    20.09.2008 Add USB host defines                                      {1}
    23.11.2009 Remove little-endian macros and padding defined to driver.h since the same is required for SD cards and other general use
    13.03.2010 Add mass storage                                          {2}
    21.03.2010 Add ENDPOINT_TERMINATE_TRANSMISSION                       {3}
    21.03.2010 Correct REQUEST_ENDPOINT_STANDARD value                   {4}
    22.02.2011 Add CBW_MODE_SENSE_6                                      {5}
    25.01.2012 Add HID mouse defines                                     {6}

*/

#ifndef _USB_
#define _USB_

#ifdef _CODE_WARRIOR_CF                                                  // ensure no padding in structs in this file
    #pragma pack(1) 
#endif

#define ENDPOINT_PAIR(x, y)          ()

#define USB_SPEC_VERSION_2_0     0x0200                                  // V2.0
#define USB_SPEC_VERSION_1_1     0x0110                                  // V1.1
#define USB_SPEC_VERSION_1_0     0x0100                                  // V1.0

// Packet Identifiers (PIDs)
//
#define SOF_PID   0x05                                                   // token packets
#define SETUP_PID 0x0d
#define IN_PID    0x09
#define OUT_PID   0x01

#define DATA0_PID 0x03                                                   // data packets
#define DATA1_PID 0x0b

#define ACK_PID   0x02                                                   // handshake packets
#define NAK_PID   0x0a
#define STALL_PID 0x0e
                                                                         // special packets
#define PRE_PID   0x0c                                                   // note PRE is the only packet which doesn't have an EOP at the end!


#define UNICODE_ENGLISH_LANGUAGE           0x0409

// Standard USB descriptor type values
//
#define STANDARD_DEVICE_DESCRIPTOR         0x0100
#define STANDARD_CONFIG_DESCRIPTOR         0x0200
#define STANDARD_STRING_DESCRIPTOR         0x0300                        // optional
#define STANDARD_INTERFACE_DESCRIPTOR      0x0400
#define STANDARD_ENDPOINT_DESCRIPTOR       0x0500

#define DEVICE_QUALIFIER_DESCRIPTOR        0x0600                        // USB2.0


#define TYPE_AND_DIRECTION_MASK            0xe0
#define STANDARD_DEVICE_TO_HOST            0x80

typedef struct _PACK stUSB_DEVICE_DESCRIPTOR
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bcdUSB[2];                                    // version of USB specification
    unsigned char          bDeviceClass;                                 // class code
    unsigned char          bDeviceSubClass;                              // sub-class code
    unsigned char          bDeviceProtocol;                              // protocol code
    unsigned char          bMaxPacketSize0;                              // EP0 FIFO size
    unsigned char          idVendor[2];                                  // vendor ID
    unsigned char          idProduct[2];                                 // product ID
    unsigned char          bcdDevice[2];                                 // release number
    unsigned char          iManufacturer;                                // string index for manufacturer
    unsigned char          iProduct;                                     // string index for product
    unsigned char          iSerialNumber;                                // string index for serial number
    unsigned char          bNumConfigurations;                           // number of possible configurations
} USB_DEVICE_DESCRIPTOR;

// USB Class Codes
//
#define DEVICE_CLASS_AT_INTERFACE                        0,0,0           // class defined at interface level
#define DEVICE_CLASS_AUDIO                               1,0,0           // Audio Device Class
#define DEVICE_CLASS_COMMUNICATION_AND_CONTROL           2,0,0           // Communication and Communication Device Class Control
#define DEVICE_CLASS_HID                                 3,0,0           // Human Interface Device Class
#define DEVICE_CLASS_PHYSICAL                            5,0,0           // Physical Device Class
#define DEVICE_CLASS_STILL_IMAGING                       6,1,1           // Still Imaging Device Class
#define DEVICE_CLASS_PRINTER                             7,0,0           // Printer Device Class
#define DEVICE_CLASS_MASS_STORAGE                        8,0,0           // Mass Storage Device Class
#define DEVICE_CLASS_FULL_SPEED_HUB                      9,0,0           // Hub Device Class
#define DEVICE_CLASS_HIGHSPEED_HUB_SINGLE_TT             9,0,1           // Hub Device Class 
#define DEVICE_CLASS_HIGHSPEED_HUB_MULTIPLE_TTS          9,0,2           // Hub Device Class
#define DEVICE_CLASS_COMMUNICATION                       0xa,0,0         // Communication Device Class
#define DEVICE_CLASS_SMART_CARD                          0xb,0,0         // Smart Card Device Class
#define DEVICE_CLASS_CONTENT_SECURITY                    0xd,0,0         // Content Security Device Class
#define DEVICE_CLASS_VIDEA                               0xe,0,0         // Video Device Class
#define DEVICE_CLASS_PERSONAL_HEALTHCARE                 0xf,0,0         // Personal Healthcare Device Class
#define DEVICE_CLASS_DIAGNOSTICS_DEVICE                  0xdc,0,0        // USB2 Compliance Device
#define DEVICE_CLASS_WIRELESS_CONTROLLER_BLUETOOTH_PROG  0xe0,1,1        // Bluetooth Programming Interface
#define DEVICE_CLASS_WIRELESS_CONTROLLER_UWB_RADIO_CONT  0xe0,1,2        // UWB Radio Control Interface
#define DEVICE_CLASS_WIRELESS_CONTROLLER_REMOTE_NDIS     0xe0,1,3        // Remote NDIS
#define DEVICE_CLASS_WIRELESS_CONTROLLER_HOST_WIRE       0xe0,2,1        // Host Wire Adapter Control/Data Interface
#define DEVICE_CLASS_WIRELESS_CONTROLLER_DEVICE_WIRE     0xe0,2,2        // Device Wire Adapter Control/Data Interface
#define DEVICE_CLASS_WIRELESS_CONTROLLER_DEVICE_WIRE_ISO 0xe0,2,3        // Device Wire Adapter Isochronous Interface
#define DEVICE_CLASS_MISC_ACTIVE_SYNC_DEVICE             0xef,1,1        // Active Sync Device
#define DEVICE_CLASS_MISC_PALM_SYNC_DEVICE               0xef,1,2        // Palm Sync Device
#define DEVICE_CLASS_MISC_INTERFACE_ASSOCIATION_DESC     0xef,2,1        // Interface Association Descriptor
#define DEVICE_CLASS_MISC_WIRE_ADAPTER_MULTIFUNC         0xef,2,2        // Wire Adapter Multifunctional Peripheral Programming Interface
#define DEVICE_CLASS_MISC_CABLE_BASED_ASSOCIATION_FWORK  0xef,3,1        // Cable Based Association Framework
#define DEVICE_CLASS_APP_DEVICE_FIRMWARE_UPGRADE         0xfe,1,1        // Device Firmware Upgrade
#define DEVICE_CLASS_APP_IRDA_BRIDGE                     0xfe,2,0        // IRDA Bridge Device
#define DEVICE_CLASS_APP_USB_TEST_MEASUREMENT            0xfe,3,0        // USB Test and Measurement Device
#define DEVICE_CLASS_APP_USB_TEST_MEASUREMENT_USB488     0xfe,3,1        // USB Test and Measurement Device conforming to USBTMC USB488
#define DEVICE_CLASS_VENDOR_SPECIFIC                     0xff,0,0        // Vendor Specific Device Class

#define VENDOR_SPECIFIC_ENTRY                            0xff

typedef struct _PACK stUSB_DEVICE_QUALIFIER_DESCRIPTOR
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bcdUSB[2];                                    // version of USB specification
    unsigned char          bDeviceClass;                                 // class code
    unsigned char          bDeviceSubClass;                              // sub-class code
    unsigned char          bDeviceProtocol;                              // protocol code
    unsigned char          bMaxPacketSize0;                              // EP0 FIFO size
    unsigned char          bNumConfigurations;                           // number of possible configurations
    unsigned char          bReserved;                                    // reserved for future extensions
} USB_DEVICE_QUALIFIER_DESCRIPTOR;

typedef struct _PACK stUSB_CONFIGURATION_DESCRIPTOR
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          wTotalLength[2];                              // 
    unsigned char          bNumInterface;                                // 
    unsigned char          bConfigurationValue;                          // 
    unsigned char          iConfiguration;                               // string index for configuration
    unsigned char          bmAttributes;                                 // 
    unsigned char          bMaxPower;                                    // maximum current consumption in 2mA units
} USB_CONFIGURATION_DESCRIPTOR;

typedef struct _PACK stUSB_INTERFACE_DESCRIPTOR
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bInterfaceNumber;                             // 
    unsigned char          bAlternateSetting;                            // 
    unsigned char          bNumEndpoints;                                // number of endpoints in addition to EP0
    unsigned char          bInterfaceClass;                              // 
    unsigned char          bInterfaceSubClass;                           // 
    unsigned char          bInterfaceProtocol;                           // 
    unsigned char          iInterface;                                   // string index for interface
} USB_INTERFACE_DESCRIPTOR;

typedef struct _PACK stUSB_HID_DESCRIPTOR                                // HID descriptor
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bcdHID[2];                                    // HID class specific release number
    unsigned char          bCountryCode;                                 // Hardware target country
    unsigned char          bNumDescriptors;                              // Number of HID class descriptors to follow
    unsigned char          bReportDescriptorType;                        // Report Descriptor Type
    unsigned char          wItemLength[2];                               // Total Length of Report Descriptor
} USB_HID_DESCRIPTOR;

typedef struct _PACK stUSB_CDC_FUNCTIONAL_DESCRIPTOR_HEADER              // CDC function descriptor - header
{
    unsigned char          bFunctionLength;                              // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bDescriptorSubtype;                           // HEADER_FUNCTION_DESCRIPTOR
    unsigned char          bcdCDC[2];                                    // CDC specification release number
} USB_CDC_FUNCTIONAL_DESCRIPTOR_HEADER;

typedef struct _PACK stUSB_CDC_FUNCTIONAL_DESCRIPTOR_ABSTRACT_CONTROL    // CDC function descriptor - adstract control
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bDescriptorSubtype;                           // ABSTRACT_CONTROL_FUNCTION_DESCRIPTOR
    unsigned char          bmCapabilities;
} USB_CDC_FUNCTIONAL_DESCRIPTOR_ABSTRACT_CONTROL;

typedef struct _PACK stUSB_CDC_FUNCTIONAL_DESCRIPTOR_UNION               // CDC function descriptor - union
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bDescriptorSubtype;                           // USB_CDC_FUNCTIONAL_DESCRIPTOR_UNION
    unsigned char          bControlInterface;
    unsigned char          bSubordinateInterface;
} USB_CDC_FUNCTIONAL_DESCRIPTOR_UNION;

typedef struct _PACK stUSB_CDC_FUNCTIONAL_DESCRIPTOR_CALL_MAN            // CDC function descriptor - union
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bDescriptorSubtype;                           // USB_CDC_FUNCTIONAL_DESCRIPTOR_CALL_MAN
    unsigned char          bmCapabilities;
    unsigned char          bDataInterface;
} USB_CDC_FUNCTIONAL_DESCRIPTOR_CALL_MAN;

#define CS_INTERFACE       0x24
#define CS_SENDPOINT       0x25

// Descriptor SubTypes
//
#define HEADER_FUNCTION_DESCRIPTOR                            0
#define CALL_MAN_FUNCTIONAL_DESCRIPTOR                        1
#define ABSTRACT_CONTROL_FUNCTION_DESCRIPTOR                  2
#define UNION_FUNCTIONAL_DESCRIPTOR                           6

#define USB_CDC_FUNCTIONAL_DESCRIPTOR_HEADER_LENGTH           5
#define USB_CDC_FUNCTIONAL_DESCRIPTOR_CALL_MAN_LENGTH         5
#define USB_CDC_FUNCTIONAL_DESCRIPTOR_ABSTRACT_CONTROL_LENGTH 4
#define USB_CDC_FUNCTIONAL_DESCRIPTOR_UNION_LENGTH            5


typedef struct _PACK stUSB_ENDPOINT_DESCRIPTOR
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          bEndpointAddress;                             // direction and address of endpoint
    unsigned char          bmAttributes;                                 // endpoint attributes
    unsigned char          wMaxPacketSize[2];                            // endpoint FIFO size
    unsigned char          bInterval;                                    // polling interval in ms
} USB_ENDPOINT_DESCRIPTOR;

typedef struct stUSB_ENDPOINT_DESCRIPTOR_ENTRIES
{
    const USB_ENDPOINT_DESCRIPTOR *ptrActiveEndpoint;
    unsigned short usMaxEndpointLength;
} USB_ENDPOINT_DESCRIPTOR_ENTRIES;

#define IN_ENDPOINT                     0x80
#define OUT_ENDPOINT                    0x00

#define ENDPOINT_CONTROL                   0
#define ENDPOINT_ISOCHRONOUS               1
#define ENDPOINT_BULK                      2
#define ENDPOINT_INTERRUPT                 3
#define ENDPOINT_TERMINATE_TRANSMISSION 0x40                             // pseudo attribute so that this endpoint sends a zero frame on buffer termination
#define ENDPOINT_DISABLE                0xff

// USB2.0 extended attributes for isochronous endpoints
//
#define NO_SYNCHRONISATION                 0
#define ASYNCHRONOUS_SYNCHRONISATION    0x04
#define ADAPTIVE_SYNCHRONISATION        0x08
#define SYNCHRONOUS_SYNCHRONISATION     0x0c

// USB2.0 extended attributes for use
//
#define DATA_ENDPOINT_USE                      0
#define EXPLICIT_FEEDBACK_ENDPOINT_USE      0x10                         // isochronous feedback endpoints must use NO_SYNCHRONISATION
#define IMPLICIT_FEEDBACK_DATA_ENDPOINT_USE 0x20                         // isochronous feedback endpoints must use NO_SYNCHRONISATION


#define USB_CLASS_COMMUNICATION_CONTROL    2
#define USB_CLASS_HID                      3
#define INTERFACE_CLASS_MASS_STORAGE       8                             // {2}
#define INTERFACE_CLASS_HUB                9
#define INTERFACE_CLASS_COMMUNICATION_DATA 0x0a

#define USB_SUBCLASS_BOOT_INTERFACE        1

#define USB_INTERFACE_PROTOCOL_NONE        0
#define USB_INTERFACE_PROTOCOL_KEYBOARD    1                             // only meaningful for boot interface
#define USB_INTERFACE_PROTOCOL_MOUSE       2                             // only meaningful for boot interface
#define USB_ABSTRACT_LINE_CONTROL_MODEL    2

#define ATAPI_CD_DVD_DEVICE                2                             // {2}
#define QIC157_TAPE_DEVICE                 3
#define USB_FLOPPY_INTERFACE               4                             // UFI
#define ATAPI_REMOVABLE_MEDIA              5
#define GENERIC_SCSI_MEDIA                 6

#define CBI_WITH_COMMAND_COMPLETION_INTERRUPT_TRANSFER    0x00           // {2}
#define CBI_WITHOUT_COMMAND_COMPLETION_INTERRUPT_TRANSFER 0x01
#define BULK_ONLY_TRANSPORT                               0x50



typedef struct _PACK stUSB_SETUP_HEADER
{
    unsigned char bmRequestType;
    unsigned char bRequest;
    unsigned char wValue[2];
    unsigned char wIndex[2];
    unsigned char wLength[2];
} USB_SETUP_HEADER;

typedef struct _PACK stUSB_STRING_DESCRIPTOR
{
    unsigned char          bLength;                                      // descriptor size in bytes
    unsigned char          bDescriptorType;                              // device descriptor
    unsigned char          unicode_string_space[2];                      // first unicode location
    // Variable length
    //
} USB_STRING_DESCRIPTOR;

#define REMOTE_WAKEUP_SUPPORTED        0x20
#define SELF_POWERED                   0x40
#define ATTRIBUTE_DEFAULT              0x80                              // must always be set

#define STANDARD_DEVICE_DESCRIPTOR_LENGTH    0x12
#define DEVICE_QUALIFIER_DESCRIPTOR_LENGTH   0x0a
#define DESCRIPTOR_TYPE_ENDPOINT_LENGTH      0x07
#define DESCRIPTOR_TYPE_CONFIGURATION_LENGTH 0x09
#define DESCRIPTOR_TYPE_INTERFACE_LENGTH     0x09
#define DESCRIPTOR_TYPE_HID_LENGTH           0x09 

#define DESCRIPTOR_TYPE_DEVICE         0x01
#define DESCRIPTOR_TYPE_CONFIGURATION  0x02
#define DESCRIPTOR_TYPE_STRING         0x03
#define DESCRIPTOR_TYPE_INTERFACE      0x04
#define DESCRIPTOR_TYPE_ENDPOINT       0x05
#define DESCRIPTOR_DEVICE_QUALIFIER    0x06

#define MAJOR_USB_VERSION              1                                 // index to major version
#define MINOR_USB_VERSION              0                                 // index to minor version

#define REQUEST_DEVICE_STANDARD        0x00                              // bmRequestType.Recipient == Device, bmRequestType.Type == Standard
#define REQUEST_DEVICE_VENDOR          0x40                              // bmRequestType.Recipient == Device, bmRequestType.Type == Vendor
#define REQUEST_INTERFACE_STANDARD     0x01                              // bmRequestType.Recipient == Interface, bmRequestType.Type == Standard
#define REQUEST_INTERFACE_CLASS        0x21                              // bmRequestType.Recipient == Interface, bmRequestType.Type == Class
#define REQUEST_ENDPOINT_STANDARD      0x02                              // {4}
#define REQUEST_ENDPOINT_OTHER         0x03

#define USB_REQUEST_GET_STATUS         0                                 // request field
#define USB_REQUEST_CLEAR_FEATURE      1
#define USB_REQUEST_SET_FEATURE        3
#define USB_REQUEST_SET_ADDRESS        5
#define USB_REQUEST_GET_DESCRIPTOR     6
#define USB_REQUEST_SET_DESCRIPTOR     7
#define USB_REQUEST_GET_CONFIGURATION  8
#define USB_REQUEST_SET_CONFIGURATION  9
#define USB_REQUEST_GET_INTERFACE      10
#define USB_REQUEST_SET_INTERFACE      11
#define USB_REQUEST_SYNCH_FRAME        12

#define ENDPOINT_STATUS_STALLED        0x0001

// Communication Device Class
//
#define SET_LINE_CODING                0x20
#define GET_LINE_CODING                0x21
#define SET_CONTROL_LINE_STATE         0x22
  #define CDC_DTR                      0x01                              // bitmap values in wValue
  #define CDC_RTS                      0x02

typedef struct _PACK stCDC_PSTN_LINE_CODING
{
    unsigned char          dwDTERate[4];                                 // data terminal rate in bits per second
    unsigned char          bCharFormat;                                  // stop bits
    unsigned char          bParityType;                                  // parity
    unsigned char          bDataBits;                                    // data bits
} CDC_PSTN_LINE_CODING;

#define CDC_PSTN_1_STOP_BIT   0
#define CDC_PSTN_1_5_STOP_BIT 1
#define CDC_PSTN_2_STOP_BITS  2

#define CDC_PSTN_NO_PARITY    0
#define CDC_PSTN_ODD_PARITY   1
#define CDC_PSTN_EVEN_PARITY  2
#define CDC_PSTN_MARK_PARITY  3
#define CDC_PSTN_SPACE_PARITY 4

#define CDC_PSTN_5_DATA_BITS  5
#define CDC_PSTN_6_DATA_BITS  6
#define CDC_PSTN_7_DATA_BITS  7
#define CDC_PSTN_8_DATA_BITS  8
#define CDC_PSTN_16_DATA_BITS 16

// HID
//
#define DESCRIPTOR_TYPE_HID      0x21
#define DESCRIPTOR_TYPE_REPORT   0x22
#define DESCRIPTOR_TYPE_PHYSICAL 0x23

#define HID_GET_REPORT        0x01                                       // mandatory
#define HID_GET_IDLE          0x02
#define HID_GET_PROTOCOL      0x03                                       // mandatory only for boot devices
#define HID_SET_REPORT        0x09
#define HID_SET_IDLE          0x0a                                       // silence a particular report on the interrupt IN pipe, with optional expiration time 
#define HID_SET_PROTOCOL      0x0b                                       // mandatory only for boot devices


extern void *fnGetUSB_config_descriptor(unsigned short *usLength);
extern void *fnGetUSB_device_descriptor(unsigned short *usLength);
extern unsigned char *fnGetUSB_string_entry(unsigned short usStringRef, unsigned short *usLength);

// Mass Storage
//

#define BULK_ONLY_MASS_STORAGE_RESET       0xff                          // {2}
#define GET_MAX_LUN                        0xfe

typedef struct _PACK stUSB_MASS_STORAGE_CBW                              // command block wrapper
{
    unsigned char          dCBWSignature[4];                             // signature is 0x43425355 "USBC"
    unsigned char          dCBWTag[4];                                   // tag associating this CBW with the CSW response
    unsigned char          dCBWDataTransferLength[4];                    // the number of bytes the host expect to transfer in the data-transfer stage
    unsigned char          dmCBWFlags;                                   // specifies the direction of the data-transfer stage
    unsigned char          dCBWLUN;                                      // LUN that the command block is directed to (4 bits valid)
    unsigned char          dCBWCBLength;                                 // the length of the command block in bytes (1..16)
    unsigned char          CBWCB[16];                                    // the command block for the device to execute
} USB_MASS_STORAGE_CBW;

#define CBW_IN_FLAG              0x80

#define CBW_OperationCode        0

#define UFI_FORMAT_UNIT          0x04
#define UFI_INQUIRY              0x12
#define UFI_START_STOP           0x1b
#define UFI_MODE_SENSE_6         0x1a
#define UFI_MODE_SELECT          0x55
#define UFI_MODE_SENSE           0x5a
#define UFI_PRE_ALLOW_REMOVAL    0x1e
#define UFI_READ_10              0x28
#define UFI_READ_12              0xa8
#define UFI_READ_CAPACITY        0x25
#define UFI_READ_FORMAT_CAPACITY 0x23
#define UFI_REQUEST_SENSE        0x03
#define UFI_REZERO_UNIT          0x01
#define UFI_SEEK_10              0x2b
#define UFI_SEND_DIAGNOSTIC      0x1d
#define UFI_TEST_UNIT_READY      0x00
#define UFI_VERIFY               0x2f
#define UFI_WRITE_10             0x2a
#define UFI_WRITE_12             0xaa
#define UFI_WRITE_AND_VERIFY     0x2e

typedef struct _PACK stCBW_TEST_UNIT_READY                               // 0x00
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumber_EVPD;
} CBW_TEST_UNIT_READY;

typedef struct _PACK stCBW_REQUEST_SENSE_DATA                            // 0x03
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumber;
    unsigned char          ucRes0[2];
    unsigned char          ucAllocationLength;
} CBW_REQUEST_SENSE_DATA;

typedef struct _PACK stCBW_RETURN_SENSE_DATA
{
    unsigned char          ucValid_ErrorCode;
    unsigned char          ucRes0;
    unsigned char          ucSenseKey;
    unsigned char          ucInformation[4];
    unsigned char          ucAdditionalSenseLength_10;
    unsigned char          ucRes1[4];
    unsigned char          ucAdditionalSenseCode;
    unsigned char          ucAdditionalSenseCodeQualifier;
    unsigned char          ucRes2[4];
} CBW_RETURN_SENSE_DATA;

#define VALID_SENSE_DATA         0x80
#define CURRENT_ERRORS           0x70
#define SENSE_LENGTH_10          10

// Sense keys
//
#define SENSE_NO_SENSE           0x00
#define SENSE_RECOVERED_ERROR    0x01
#define SENSE_NOT_READY          0x02
    #define DESC_MEDIUM_NOT_PRESENT  0x3a
#define SENSE_MEDIUM_ERROR       0x03
#define SENSE_HARDWARE_ERROR     0x04
#define SENSE_ILLEGAL_REQUEST    0x05
#define SENSE_UNIT_ATTENTION     0x06
#define SENSE_DATA_PROTECTION    0x07
#define SENSE_BLANK_CHECK        0x08
#define SENSE_VENDOR_SPECIFIC    0x09
#define SENSE_ABORTED_COMMAND    0x0b
#define SENSE_VOLUME_OVERFLOW    0x0d
#define SENSE_MISCOMPARE         0x0e

typedef struct _PACK stCBW_INQUIRY_COMMAND                               // 0x12
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumber_EVPD;
    unsigned char          ucPageCode;
    unsigned char          ucReserved0;
    unsigned char          ucAllocationLength;
} CBW_INQUIRY_COMMAND;

typedef struct _PACK stCBW_INQUIRY_DATA
{
    unsigned char          ucPeripheralDeviceType;
    unsigned char          ucRMB;
    unsigned char          ucISOversion_ECMAversion_ANSIversion;
    unsigned char          ucResponseDataFormat;
    unsigned char          ucAdditionalLength;
    unsigned char          ucReserved0[3];
    unsigned char          ucVendorInformation[8];
    unsigned char          ucProductIdentification[16];
    unsigned char          ucProductRevisionLevel[4];
} CBW_INQUIRY_DATA;

#define DEVICE_TYPE_FLOPPY           0x00
#define DEVICE_TYPE_NONE             0x1f
#define RMB_REMOVABLE                0x80
#define RMB_FIXED                    0x00
#define RESPONSE_FORMAT_UFI          0x01

typedef struct _PACK stCBW_MODE_SENSE_6                                  // 0x1a {5}
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumber_DBD;
    unsigned char          ucPC_PageCode;
    unsigned char          ucSubpageCode;
    unsigned char          ucAllocationLength;
    unsigned char          ucControl;
} CBW_MODE_SENSE_6;

#define MODE_SENSE_6_DBD                     0x08                        // don't return block descriptors when set
#define MODE_SENSE_6_PAGE_CONTROL_CURRENT    0x00
#define MODE_SENSE_6_PAGE_CONTROL_CHANGEABLE 0x40
#define MODE_SENSE_6_PAGE_CONTROL_DEFAULT    0x80
#define MODE_SENSE_6_PAGE_CONTROL_SAVED      0xc0
#define MODE_SENSE_6_PAGE_CODE_CACHING       0x08
#define MODE_SENSE_6_PAGE_CODE_ALL_PAGES     0x3f



typedef struct _PACK stMODE_PARAMETER_6
{
    unsigned char          ucModeDataLength;
    unsigned char          ucMediumType;
    unsigned char          ucWP_DPOFUA;
    unsigned char          ucBlockDescriptorLength;
  //BLOCK_DESCRIPTOR       blockDescriptor;                              // there can be a list of descriptors
} MODE_PARAMETER_6;

#define PAR6_WRITE_PROTECTED 0x80
#define PAR6_DPO_FUA         0x10



typedef struct _PACK stCBW_FORMAT_CAPACITIES                             // 0x23
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumber;
    unsigned char          ucReserved0[5];
    unsigned char          ucAllocationLength[2];
} CBW_FORMAT_CAPACITIES;

typedef struct _PACK stCAPACITY_DESCRIPTOR
{
    unsigned char          ucNumberOfBlocks[4];                          // total number of addressable blocks for the descriptor's media type
    unsigned char          ucDescriptorCode;
    unsigned char          ucBlockLength[3];                             // length in bytes for each logical block
} CAPACITY_DESCRIPTOR;

#define DESC_CODE_UNFORMATTED_MEDIA      0x01
#define DESC_CODE_FORMATTED_MEDIA        0x02
#define DESC_CODE_NO_CARTRIDGE_IN_DRIVE  0x03

typedef struct _PACK stCBW_READ_CAPACITY                                 // 0x25
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumberRelAdr;
    unsigned char          ucLogicalBlockAddress[4];
    unsigned char          ucReserved0[2];
    unsigned char          ucPMI;
} CBW_READ_CAPACITY;

typedef struct _PACK stCBW_READ_CAPACITY_DATA
{
    unsigned char          ucLastLogicalBlockAddress[4];
    unsigned char          ucBlockLengthInBytes[4];
} CBW_READ_CAPACITY_DATA;

typedef struct _PACK stCBW_READ_10                                       // 0x28
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumberRelAdr;
    unsigned char          ucLogicalBlockAddress[4];
    unsigned char          ucReserved0;
    unsigned char          ucTransferLength[2];
} CBW_READ_10;

typedef struct _PACK stCBW_READ_12                                       // 0xa8
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumberRelAdr;
    unsigned char          ucLogicalBlockAddress[4];
    unsigned char          ucTransferLength[4];
} CBW_READ_12;

typedef struct _PACK stCBW_WRITE_10                                      // 0x2a
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumberRelAdr;
    unsigned char          ucLogicalBlockAddress[4];
    unsigned char          ucReserved0;
    unsigned char          ucTransferLength[2];
} CBW_WRITE_10;

typedef struct _PACK stCBW_WRITE_12                                      // 0xaa
{
    unsigned char          ucOperationCode;
    unsigned char          ucLogicalUnitNumberRelAdr;
    unsigned char          ucLogicalBlockAddress[4];
    unsigned char          ucTransferLength[4];
} CBW_WRITE_12;


typedef struct _PACK stCBW_CAPACITY_LIST
{
    unsigned char          ucReserved0[3];
    unsigned char          ucCapacityListLength;
    CAPACITY_DESCRIPTOR    capacityDescriptor;                           // there can be a list of descriptors
} CBW_CAPACITY_LIST;



typedef struct _PACK stUSB_MASS_STORAGE_CSW                              // command status wrapper
{
    unsigned char          dCBWSignature[4];                             // signature is 0x53425355 "USBS"
    unsigned char          dCBWTag[4];                                   // tag originally received from the host
    unsigned char          dCSWDataResidue[4];                           // the difference in the number of bytes processed or the difference between the requested and number of bytes sent
    unsigned char          bCSWStatus;                                   // status
} USB_MASS_STORAGE_CSW;

#define CSW_STATUS_COMMAND_PASSED    0x00
#define CSW_STATUS_COMMAND_FAILED    0x01
#define CSW_STATUS_PHASE_ERROR       0x02


// Host                                                                  {1}
//
typedef struct _PACK stUSB_HOST_DESCRIPTOR
{
    unsigned char          bmRecipient_device_direction;                 // descriptor size in bytes
    unsigned char          bRequest;                                     // request type
    unsigned char          wValue[2];                                    // 
    unsigned char          wIndex[2];                                    // 
    unsigned char          wLength[2];                                   // length that can be accepted
} USB_HOST_DESCRIPTOR;


#ifdef _CODE_WARRIOR_CF                                                  // disable
    #pragma pack(0) 
#endif

// USB messages
//
#define E_USB_ACTIVATE_CONFIGURATION      0xfe                           
#endif
