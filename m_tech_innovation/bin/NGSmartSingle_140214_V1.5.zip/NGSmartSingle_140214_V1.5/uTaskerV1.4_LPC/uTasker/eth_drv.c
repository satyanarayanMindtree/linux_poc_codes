/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        eth_drv.c
   Project:     Single Chip Embedded Internet
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************

   15.03.2007 VLAN transmission support added                            {1}
   07.05.2007 Added STR91XF support                                      {2}
   30.07.2007 Added LPC23XX support
   18.11.2007 Added LM3SXXXX support                                     {3}

*/


/* =================================================================== */
/*                           include files                             */
/* =================================================================== */


//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


#ifdef ETH_INTERFACE		


/* =================================================================== */
/*                          local definitions                          */
/* =================================================================== */



/* =================================================================== */
/*                       local structure definitions                   */
/* =================================================================== */


/* =================================================================== */
/*                 local function prototype declarations               */
/* =================================================================== */


/* =================================================================== */
/*                             constants                               */
/* =================================================================== */


/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */


/* =================================================================== */
/*                      local function definitions                     */
/* =================================================================== */


/* =================================================================== */
/*                      global function definitions                    */
/* =================================================================== */

ETHERNETQue *eth_tx_control;
ETHERNETQue *eth_rx_control;

// standard entry call to driver - dispatches required sub-routine
//
static QUEUE_TRANSFER entry_eth(QUEUE_HANDLE channel, unsigned char *ptBuffer, QUEUE_TRANSFER Counter, unsigned char ucCallType, QUEUE_HANDLE DriverID)
{
#ifdef _LM3SXXXX                                                         // {3}
    #define ETH_BUFF_COPY(a,b,c) uMemcpy(a,b,c)
#else
    #define ETH_BUFF_COPY(a,b,c) uMemcpy(a,b,c)
#endif
    ETHERNETQue *ptTTYQue;
    unsigned short rtn_val = 0;

    // special case for ethernet write - note that we do not protect interrupts since it is not necessary here.
    if (ucCallType == CALL_WRITE) {
        ptTTYQue = (struct stETHERNETQue *)(que_ids[DriverID].output_buffer_control); // set to output control block
        if (ptBuffer) {                                                  // data being passed
#if !defined (_HW_NE64)                                                  // {2}
            if ((Counter) && (Counter < (ptTTYQue->ETH_queue.buf_length - ptTTYQue->ETH_queue.chars)))
#else
            if ((Counter) && (ptTTYQue->ETH_queue.chars < ptTTYQue->ETH_queue.buf_length))
#endif
            {

                if (ptTTYQue->ETH_queue.chars == 0) {                    // first part of a frame
#if !defined (_HW_NE64)                                                  // {2}{3}
                    ptTTYQue->ETH_queue.put = fnGetTxBufferAdd(0);       // get next buffer space
#endif
#ifndef _LM3SXXXX                                                        // {3}
                    if (fnWaitTxFree() != 0) {                           // wait for a short time if the buffer is not free
                        return 0;                                        // the buffer is busy and remains so for a long time so abort
                    }
#endif
    #ifdef SUPPORT_VLAN                                                  // {1}
                    if (vlan_active) {                                   // VLAN tag on first write - it is assumed that only normal Ethernet frames are sent
                        unsigned char ucVLAN_tag[VLAN_TAG_LENGTH];
                        ETH_BUFF_COPY(ptTTYQue->ETH_queue.put, ptBuffer, (2*MAC_LENGTH)); // copy MAC addresses
                        ptTTYQue->ETH_queue.put += (2*MAC_LENGTH);
                        ptBuffer += (2*MAC_LENGTH);
                        ucVLAN_tag[0] = (unsigned char)(TAG_PROTOCOL_IDENTIFIER>>8);
                        ucVLAN_tag[1] = (unsigned char)(TAG_PROTOCOL_IDENTIFIER);
                        ucVLAN_tag[2] = (unsigned char)(vlan_vid >> 8);
                        ucVLAN_tag[3] = (unsigned char)vlan_vid;
                        ETH_BUFF_COPY(ptTTYQue->ETH_queue.put, ucVLAN_tag, VLAN_TAG_LENGTH); // copy VLAN tag
                        ptTTYQue->ETH_queue.put += VLAN_TAG_LENGTH;
                        ptTTYQue->ETH_queue.chars = (2*MAC_LENGTH + VLAN_TAG_LENGTH);
                        Counter -= (2*MAC_LENGTH);
                    }
    #endif
                }
                ETH_BUFF_COPY(ptTTYQue->ETH_queue.put, ptBuffer, Counter); // copy since buffers are linear
                ptTTYQue->ETH_queue.put += Counter;
                ptTTYQue->ETH_queue.chars += Counter;
                return (Counter);
            }
            return 0;
        }
        else {
#if !defined (_HW_NE64)                                                  // {2}{3}
            unsigned short ucTxLength = ptTTYQue->ETH_queue.chars;
            ptTTYQue->ETH_queue.chars = 0;
            return (fnStartEthTx(ucTxLength, ptTTYQue->ETH_queue.put));  // this causes frame to be sent
#else
            return (fnStartEthTx(ptTTYQue->ETH_queue.chars, ptTTYQue->ETH_queue.put)); // this causes frame to be sent
#endif
        }
    }

    uDisable_Interrupt();                                                // disable all interrupts

    switch ( ucCallType ) {
    case CALL_CLOSE:                                                     // close a driver channel and de-allocate its memory
        break;

    case CALL_READ_LINEAR:
        ptTTYQue = (struct stETHERNETQue *)(que_ids[DriverID].input_buffer_control); // set to input control block
        while (Counter--) {
            ptTTYQue = ptTTYQue->NextTTYbuffer;
        }
        *(unsigned char **)ptBuffer = ptTTYQue->ETH_queue.QUEbuffer;     // set pointer to data
        rtn_val = ptTTYQue->ETH_queue.chars;                             // return the number of characters in the input buffer
        break;

    case CALL_FREE:
        ptTTYQue = (struct stETHERNETQue *)(que_ids[DriverID].input_buffer_control); // set to input control block
        fnFreeEthernetBuffer(Counter);
#if !defined _LPC23XX && !defined _LPC17XX && !defined _LM3SXXXX && !defined _STM32
        while (Counter--) {
            ptTTYQue = ptTTYQue->NextTTYbuffer;
        }
#endif
        ptTTYQue->ETH_queue.chars = 0;
        break;

    default:
        break;
    }
    uEnable_Interrupt();                                                 // enable interrupts
    return (rtn_val);
}


// Open the Ethernet interface
//
extern QUEUE_HANDLE fnOpenETHERNET(ETHTABLE *pars, unsigned short driver_mode)
{
    QUEUE_HANDLE DriverID;
    int iRxBuffers = 0;
    void *new_memory;
    ETHERNETQue *ptEthQue = 0;
    QUEUE_TRANSFER (*entry_add)(QUEUE_HANDLE channel, unsigned char *ptBuffer, QUEUE_TRANSFER Counter, unsigned char ucCallType, QUEUE_HANDLE DriverID) = entry_eth;

    if (NO_ID_ALLOCATED != (DriverID = fnSearchID(entry_add, pars->Channel))) { // check to see whether this interface has already been opened
        return DriverID;
    }
    else {
        if (NO_ID_ALLOCATED == (DriverID = fnSearchID (0, 0))) {         // get next free ID
            return (NO_ID_ALLOCATED);                                    // no free IDs available
        }
    }

    --DriverID;                                                          // convert to array offset

  //que_ids[ucDriverID].ulEntryAddress = 0;                              already clear since from heap
  //que_ids[ucDriverID].input_buffer_control = 0;
  //que_ids[ucDriverID].output_buffer_control = 0;

#if defined(SUPPORT_DISTRIBUTED_NODES) && defined (UPROTOCOL_WITH_RETRANS)
    fnInitUNetwork();
#endif
    fnConfigEthernet(pars);                                              // configure the physical device
                                                                         // we need to configure it before getting all buffer resources
                                                                         // since some internal buffer addresses depend on parameters
    while (iRxBuffers < fnGetQuantityRxBuf()) {                          // configure the new driver and its queue(s)
                                                                         // define Receiver
                                                                         // allocate memory for the driver queue and set up structures
        if (NO_MEMORY == (new_memory = uMalloc(sizeof(struct stETHERNETQue)))) {
            return (NO_ID_ALLOCATED);                                    // failed, no memory
        }
        if (ptEthQue) {
            ptEthQue->NextTTYbuffer = new_memory;
            ptEthQue = ptEthQue->NextTTYbuffer;
        }
        else {
            que_ids[DriverID].input_buffer_control = new_memory;
            ptEthQue = (struct stETHERNETQue *)(que_ids[DriverID].input_buffer_control);
            eth_rx_control = ptEthQue;
        }
      //ptEthQue->NextTTYbuffer = 0;
      //ptTTYQue->opn_mode = 0;
        ptEthQue->ETH_queue.get = ptEthQue->ETH_queue.put = ptEthQue->ETH_queue.QUEbuffer = fnGetRxBufferAdd(iRxBuffers);
        ptEthQue->ETH_queue.buf_length = pars->usSizeRx;
        if (pars->Task_to_wake) {
            ptEthQue->wake_task = pars->Task_to_wake;
        }
        que_ids[DriverID].CallAddress = entry_add;
        iRxBuffers++;
    }

                                                                         // define transmitter
    if (NO_MEMORY == (new_memory = uMalloc(sizeof(struct stETHERNETQue)))) { // allocate memory for the driver queue and set up structures
        return (NO_ID_ALLOCATED);                                        // failed, no memory
    }
    que_ids[DriverID].output_buffer_control = new_memory;

    ptEthQue = (struct stETHERNETQue *)(que_ids[DriverID].output_buffer_control);
    eth_tx_control = ptEthQue;
    ptEthQue->ETH_queue.put = ptEthQue->ETH_queue.get = ptEthQue->ETH_queue.QUEbuffer = fnGetTxBufferAdd(0);
    ptEthQue->ETH_queue.buf_length = pars->usSizeTx;
  //ptEthQue->opn_mode = 0;

    que_ids[DriverID].CallAddress = entry_add;

    if (0 == que_ids[DriverID].CallAddress) {
        return(NO_ID_ALLOCATED);                                         // call was not valid
    }
    else {                                                               // fill general structure entries
        que_ids[DriverID].qHandle = pars->Channel;
        return(DriverID+1);                                              // return the allocated ID - begins with 1 ... MAX
    }
}

#endif
