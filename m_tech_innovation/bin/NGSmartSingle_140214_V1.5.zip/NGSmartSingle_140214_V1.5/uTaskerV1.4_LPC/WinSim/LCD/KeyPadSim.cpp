/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        KeyPadSim.cpp
   Project:     Single Chip Embedded Internet
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************
   02.11.2009 Remove pressed key filtering and add display of keypad LEDs // {1}
   01.05.2010 Add local define _EXCLUDE_WINDOWS_

*/

#include <windows.h>
#define _EXCLUDE_WINDOWS_
#include "config.h"

#ifdef SUPPORT_KEY_SCAN

extern void fnDisplayKeypadLEDs(HDC hdc);

#define KEYPAD "keypad.bmp"


extern HWND ghWnd;

static int cxDib, cyDib;
static RECT kb_rect;
static BITMAPFILEHEADER *pbmfh = 0;
static BITMAPINFO *pbmi = 0;
static BYTE *pBits;
#if KEY_COLUMNS == 0
    #undef KEY_COLUMNS
    #define KEY_COLUMNS  VIRTUAL_KEY_COLUMNS
    #undef KEY_ROWS
    #define KEY_ROWS VIRTUAL_KEY_ROWS
#endif
static int iKeyStates[KEY_COLUMNS][KEY_ROWS] = {0};

extern void fnInitKeyPad(RECT &rt, int iOrigWidth, int iMaxTop)
{
    HANDLE hFile;
	DWORD dwFileSize, dwHighSize, dwBytesRead;	                     // load  a picture of the keypad
    hFile = CreateFile(KEYPAD, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
    if (hFile != INVALID_HANDLE_VALUE) {
        dwFileSize = GetFileSize(hFile, &dwHighSize);
	    if (pbmfh = (BITMAPFILEHEADER *)malloc(dwFileSize)) {
		    ReadFile(hFile, pbmfh, dwFileSize, &dwBytesRead, NULL);
	    }
	    CloseHandle (hFile);
	    pbmi = (BITMAPINFO *)(pbmfh + 1);
	    pBits = (BYTE *) pbmfh + pbmfh->bfOffBits;
	    if (pbmi->bmiHeader.biSize == sizeof(BITMAPCOREHEADER)) {
		    cxDib = ((BITMAPCOREHEADER *)pbmi)->bcWidth;
		    cyDib = ((BITMAPCOREHEADER *)pbmi)->bcHeight;
	    }
	    else {
		    cxDib = pbmi->bmiHeader.biWidth;
		    cyDib = abs(pbmi->bmiHeader.biHeight);
	    }
    }

    if ((iOrigWidth + cxDib + 20) >  rt.right) {                         // adjust main windows size to suit
        rt.right = (iOrigWidth + cxDib + 20);
    }
    if ((iMaxTop + cyDib + 75) > rt.bottom) {
        rt.bottom = (iMaxTop + cyDib + 75);
    }
}


extern void DisplayKeyPad(HWND hwnd, RECT rt, RECT refresh_rect)
{
    int x, y, i, j, iKeyWidth, iKeyHeight, iKeySizeX, iKeySizeY;
    if (NULL == hwnd) {
        return;
    }

    HDC hdc = GetDC(hwnd);
    
    if (pbmfh) {
    #ifdef KEYPAD_LEDS
        extern void fnConfigureKeypad_leds(RECT kb_rect);
    #endif
		SetDIBitsToDevice(hdc, rt.left, rt.top, cxDib, cyDib, 0,0,0, cyDib, pBits, pbmi, DIB_RGB_COLORS);
        kb_rect.left = rt.left;
        kb_rect.top  = rt.top;
        kb_rect.right = kb_rect.left + cxDib;
        kb_rect.bottom = rt.top + cyDib;
    #ifdef KEYPAD_LEDS                                                   // {1}
        fnConfigureKeypad_leds(kb_rect);
    #endif
	}

  //if ((refresh_rect.right < rt.left) || (refresh_rect.bottom < rt.top)) return; // {1}

    iKeyWidth = cxDib / KEY_COLUMNS;                                     // display pressed keys
    iKeyHeight = cyDib / KEY_ROWS;
    iKeySizeX = (iKeyWidth/4);
    iKeySizeY = (iKeyHeight/ 4);
    for (i = 0; i < KEY_COLUMNS; i++) {
        x = kb_rect.left + iKeyWidth/2 + i*iKeyWidth;                    // mid point of each key
        y = kb_rect.top + iKeyHeight/2;
        for (j = 0; j < KEY_ROWS; j++) {
            if (iKeyStates[i][j]) {                                      // if key presently pressed
                MoveToEx (hdc, x - iKeySizeX, y - iKeySizeY, NULL);
                LineTo(hdc, x + iKeySizeX, y - iKeySizeY);
                LineTo(hdc, x + iKeySizeX, y + iKeySizeY);
                LineTo(hdc, x - iKeySizeX, y + iKeySizeY);
                LineTo(hdc, x - iKeySizeX, y - iKeySizeY);
            }
            y += iKeyHeight;
        }
    }
#ifdef KEYPAD_LEDS                                                       // {1}
    fnDisplayKeypadLEDs(hdc);
#endif
    ReleaseDC(hwnd, hdc);
}


static void fnKeyDetected( int iColumn, int iRow,int iPressRelease)
{
    // The new state is entered into the keypad structure
    //
    if (iPressRelease == 2) {
        iKeyStates[iColumn][iRow] ^= 1;                                  // toggle present state
    }
    else {
        iKeyStates[iColumn][iRow] = iPressRelease;                       // set on or off
    }
}

extern void fnsetKeypadState(char **ptr)
{
    *ptr++ = (char *)&iKeyStates;
}

extern int fnCheckKeypad(int x, int y, int iPressRelease)
{
    int iRow, iColumn = 0;
    int iSizeX, iSizeY;

    if (x < 0) {
        memset(iKeyStates, 0, sizeof(iKeyStates));
		InvalidateRect(ghWnd, &kb_rect, FALSE);
        return KEY_CHANGED;
    }

    // Check whether the mouse was on a key
    //
    if (x < kb_rect.left) {
        return 0;
    }
    if (y < kb_rect.top) {
        return 0;
    }
    if (x > kb_rect.right) {
        return 0;
    }
    if (y > kb_rect.bottom) {
        return 0;
    }
    if (iPressRelease > 2) {
        return 1;                                                        // check on whether in keypad area
    }

    x -= kb_rect.left;
    y -= kb_rect.top;

    iSizeX = cxDib/KEY_COLUMNS;

    while (iColumn < KEY_COLUMNS) {                                      // Which key is it ?
        if (x < iSizeX) {                                                // row found
            iRow = 0;
            iSizeY = cyDib/KEY_ROWS;
            while (iRow < KEY_ROWS) {
                if (y < iSizeY) {                                        // column found too
                    fnKeyDetected(iColumn, iRow, iPressRelease);
		            InvalidateRect(ghWnd, &kb_rect, FALSE);
                    return KEY_CHANGED;
                }
                iRow++;
                iSizeY += cyDib/KEY_ROWS;
            }
        }
        iColumn++;
        iSizeX += cxDib/KEY_COLUMNS;
    }
    return 0;
}

#endif
