/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:      WinSimMain.cpp
    Project:   uTasker project
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    18.01.2007 Correct array size                                        {1}
    26.01.2007 Increase ucDoList[10000]; to ensure no overrun {2} and OVERLAPPED data structure in fnSendSerialMessage
              made static {3} to ensure that it stay in scope during the complete write operation.
    13.02.2007 Solve GDI memory leak {4} / Improve LCD refresh           {5}
    15.09.2007 Add M5222X support
    15.09.2007 Add Luminary LM3SXXXX support
    22.09.2007 Add M5221X support
    21.10.2007 Add Enumeration test support                              {6}
    02.11.2007 Add RTS modem control support                             {7}
    13.11.2007 Add port simulator                                        {8}
    25.12.2007 Extended UART support to 4 channels                       {9}
    26.12.2007 Add LPC21XX support
    08.01.2008 Ethernet code made conditional on Ethernet availability   {10}
    28.04.2008 Add shift key monitor and negative toggle (for ADC use)   {11}
    17.06.2008 Remove TA port for 64 pin M5222X and M5221X               {12}
    19.06.2008 Add USB disconnect support                                {13}
    19.06.2008 USB state display added                                   {14}
    19.06.2008 fnInjectUSB() added                                       {15}
    13.08.2008 Add M5225x support                                        {16}
    19.09.2008 Add USB host support                                      {17}
    08.12.2008 Add file select dialogue on simulation files              {18}
    09.12.2008 Read in and save user files                               {19}
    17.12.2008 Add _LM3S3748 / _LM3S3768 / _LM3S3748 / _LM3S5732 support {20}
    24.12.2008 Add SAM7X ADC                                             {21}
    17.01.2009 Add _LM3S2110 support                                     {22}
    18.01.2009 call new intermediate _main() instead of main(). This protects thread operation for reliability {23}
    03.02.2009 Change strcpy to STRCPY to remove VS2008 waring           {24}
    03.02.2009 Add port injection support for M5223X                     {25}
    24.02.2009 Change UART channel configuration to UART_MODE_CONFIG     {26}
    27.02.2009 Correct Port DD on 80pin M5223X devices                   {27}
    06.03.2009 Add _LM3S9B95 support                                     {28}
    17.03.2009 Extend virtual COM support range (using option SIM_COM_EXTENDED) {29}
    17.03.2009 Correct UART3 reception                                   {30}
    25.03.2009 Add M521XX configuration                                  {31}
    27.03.2009 Add M521X configuration                                   {32}
    01.04.2009 Add Luminary ADC                                          {33}
    26.04.2009 Add AVR32                                                 {34}
    05.05.2009 Add graphic LCD support - SUPPORT_GLCD/SUPPORT_OLED/SUPPORT_TFT {35}
    24.06.2009 Ensure port text is deleted when mouse moved from port area{36}
    19.07.2009 Put script file open in a protected region                {37}
    03.08.2009 Add _LM3S2139 support                                     {38}
    15.08.2009 Avoid refreshing complete screen when IP changes          {39}
    24.09.2009 Correct TA on 64 pin Add M521XX                           {40}
    09.10.2009 GLCD_COLOR independently controls LCD
    22.10.2009 Add additional 4 UARTS                                    {41}
    22.10.2009 Correct the handling of IP configuration display reception{42}
    02.11.2009 Add display of keypad LEDs                                {43}
    04.11.2009 Don't delete LCD when redrawing                           {44}
    18.11.2009 Add AVR32 AT32UC3B support                                {45}
    03.12.2009 Add LPC17XX support                                       {46}
    30.01.2010 Add Flexis32 support                                      {47}
    13.02.2010 Add SAM7S                                                 {48}
    23.02.2010 Add LPC214X                                               {49}
    19.04.2010 Add M5282 types in MAPBGA 256                             {50}
    10.04.2010 Adapt PORT_CHANGE message to support more ports           {51}
    13.05.2010 Adapt PORT_CHANGE message to support more ports           {52}
    21.05.2010 Add M520X                                                 {53}
    20.06.2010 Add STM32                                                 {54}
    13.07.2010 Add _LM3S9B90 support                                     {55}
    05.08.2010 Add SUPPORT_TOUCH_SCREEN support                          {56}
    12.10.2010 Add SAM7SExxx                                             {57}
    22.12.2010 Add Kinetis                                               {58}
    25.01.2011 Don't update the value of port input simulation so that a change causes a port refresh {59}
    30.01.2011 Add LPC213x                                               {60}
    11.06.2011 Correct TA on M521x                                       {61}
    17.06.2011 Add M523X                                                 {62}
    19.06.2011 Add _AT32UC3C 144 pin                                     {63}
    14.07.2011 K40 pin change                                            {64}
    19.07.2011 Add SLCD simulation support                               {65}
    25.07.2011 Correct _M5221X UA port on 64 pin package                 {66}
    31.07.2011 Extend to 6 internal UARTs                                {67}
    03.08.2011 Increase width of IP display field to handle DHCP and zero-config text {68}
    20.09.2011 Add AVR32 UC3C bit map                                    {69}
    11.10.2011 Distinguish between Kinetis parts and packages            {70}
    31.10.2011 Add STM32 extended support                                {71}
    14.11.2011 Add LPC1788 support                                       {72}
    26.11.2011 Add SAM3 support                                          {73}
    24.12.2011 Add Kinetis K61 and K70                                   {74}
    12.01.2012 Add STM32 USB                                             {75}
    12.01.2012 Add STM32 F4 image                                        {76}

    */

#include "stdafx.h"
#define _EXCLUDE_WINDOWS_
#include "config.h"
#include "resource.h"
#include "WinSim.h"
#include "WinPcap.h"
#include <sys/stat.h>

#if _VC80_UPGRADE>=0x0600
    #include <share.h>
    #define STRCPY strcpy_s 
    #define STRCAT strcat_s 
#else
    #define STRCPY strcpy
    #define STRCAT strcat
#endif

#define MAX_LOADSTRING 100

// Global variables
//
HINSTANCE hInst;                                                         // present instance
TCHAR szTitle[MAX_LOADSTRING];
TCHAR szWindowClass[MAX_LOADSTRING];
HWND ghWnd = NULL;

// Prototypes
//
ATOM                MyRegisterClass( HINSTANCE hInstance );
BOOL                InitInstance( HINSTANCE, int );
LRESULT CALLBACK    WndProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK    About( HWND, UINT, WPARAM, LPARAM );
#ifdef ETH_INTERFACE                                                     // {10}
    LRESULT CALLBACK  SetNIC( HWND, UINT, WPARAM, LPARAM );
#endif
LRESULT CALLBACK    CardReset( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK    CardWatchdogReset( HWND, UINT, WPARAM, LPARAM );

#include "WinSim.h"
#include "Fcntl.h"
#include "io.h"
#if defined SUPPORT_LCD || defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE // {35}{65}
    #include "lcd/lcd.h"
#endif

static HPEN   hPen;
static HPEN   hRedPen;
static HPEN   hGrayPen;
static HBRUSH hGreenBrush;
static HBRUSH hRedBrush;
static HBRUSH hGrayBrush;

#ifdef ETH_INTERFACE                                                     // {10}
    extern int iRxActivity, iTxActivity;                                 // LAN activity display
    static int iLastRxActivity = 0, iLastTxActivity = 0;
#endif

#ifdef SUPPORT_KEY_SCAN
    extern void fnInitKeyPad(RECT &rt, int iOrigWidth, int iMaxTop);
    extern void DisplayKeyPad(HWND hwnd, RECT rect, RECT refresh_rect);
    extern int  fnCheckKeypad(int x, int y, int iPressRelease);
#endif

#ifdef SUPPORT_TOUCH_SCREEN                                              // {56}
    extern int fnPenDown(int x, int y, int iPenState);
#endif

#include <commdlg.h>                                                     // {18}

static TCHAR szEthernetFileName[MAX_PATH+1] = {0};
static TCHAR szPortFileName[MAX_PATH+1] = {0};

static TCHAR szEthernet[] = TEXT("Wireshark files (*.pcap)\0*.PCAP\0") \
                            TEXT("Ethereal files (*.eth)\0*.ETH\0");
static TCHAR szPortSim[]  = TEXT("uTasker port sim (*.sim)\0*.SIM\0");



extern int main(int argc, char *argv[]);                                 // our link to the embedded code
static int _main(int argc, char *argv[]);                                // {23}
static int iQuit = 0;

static int iShiftPressed = 0;                                            // {11}
static int iInputChange = 0;

#ifdef ETH_INTERFACE
    static int iUserNIC = -1;
#endif

static int iLastPort = -1;
static int iPrevPort = -1;
static int iLastBit;
static int iPrevBit = -1;

#define TOGGLE_PORT    0
#define POSSIBLE_PORT  1
#define PORT_LOCATION  2

#ifdef _HW_NE64
    #ifdef _EXE
        #define CHIP_PACKAGE "ne64.bmp"
    #else
        #define CHIP_PACKAGE "..//..//..//Hardware//NE64//GUI//ne64.bmp"
    #endif
    #define PORT_FIRST_LINE 280
    #define PORT_DISPLAY_LEFT 180
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {174,85,221,140};
#endif
#if defined _HW_SAM3                                                     // {73}
    #if defined _SAM3NX
        #ifdef _EXE
            #define CHIP_PACKAGE "atsam3n.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//SAM3//GUI//atsam3n.bmp"
        #endif
        #define PORT_FIRST_LINE 260
    #elif defined _SAM3SX
        #ifdef _EXE
            #define CHIP_PACKAGE "atsam3s.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//SAM3//GUI//atsam3s.bmp"
        #endif
        #define PORT_FIRST_LINE 260
    #elif defined _SAM3UX
        #ifdef _EXE
            #define CHIP_PACKAGE "atsam3u.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//SAM3//GUI//atsam3u.bmp"
        #endif
        #define PORT_FIRST_LINE 320
    #endif
    #define PORT_DISPLAY_LEFT 85
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {227,234,274,289};

    #define USB_LEFT   224
    #define USB_TOP    186
    #define USB_RIGHT  276
    #define USB_BOTTOM 206
#endif
#if defined _HW_SAM7X
    #if defined _HW_SAM7S                                                // {48}
        #ifdef _EXE
            #define CHIP_PACKAGE "atmelsam7s.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//SAM7X//GUI//atmelsam7s.bmp"
        #endif
        #define PORT_FIRST_LINE 260
        #define PORT_DISPLAY_LEFT 85
        #define START_PORTS_X (PORT_DISPLAY_LEFT)
        #define PORT_TEXT_LENGTH 8
        static  RECT rect_LAN_LED = {227,234,274,289};

        #define USB_LEFT   224
        #define USB_TOP    186
        #define USB_RIGHT  276
        #define USB_BOTTOM 206
    #elif defined _HW_SAM7SE                                             // {57}
        #ifdef _EXE
            #define CHIP_PACKAGE "atmelsam7se.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//SAM7X//GUI//atmelsam7se.bmp"
        #endif
        #define PORT_FIRST_LINE 320
        #define PORT_DISPLAY_LEFT 85
        #define START_PORTS_X (PORT_DISPLAY_LEFT)
        #define PORT_TEXT_LENGTH 8
        static  RECT rect_LAN_LED = {227,234,274,289};

        #define USB_LEFT   110 
        #define USB_TOP    91
        #define USB_RIGHT  180
        #define USB_BOTTOM 117
    #else
        #ifdef _EXE
            #define CHIP_PACKAGE "atmelsam7x.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//SAM7X//GUI//atmelsam7x.bmp"
        #endif
        #define PORT_FIRST_LINE 320
        #define PORT_DISPLAY_LEFT 85
        #define START_PORTS_X (PORT_DISPLAY_LEFT)
        #define PORT_TEXT_LENGTH 8
        static  RECT rect_LAN_LED = {227,234,274,289};

        #define USB_LEFT   155 
        #define USB_TOP    91
        #define USB_RIGHT  205
        #define USB_BOTTOM 111
    #endif
#endif
#ifdef _HW_AVR32                                                         // {34}
    #ifdef _AT32UC3B                                                     // {45}
        #ifdef _EXE
            #define CHIP_PACKAGE "atmelavr32B.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//AVR32//GUI//atmelavr32B.bmp"
        #endif
        #define PORT_FIRST_LINE 280
        #define USB_LEFT   253 
        #define USB_TOP    116
        #define USB_RIGHT  303
        #define USB_BOTTOM 136
    #else
        #ifdef _AT32UC3C                                                 // {69}
            #ifdef _EXE
                #define CHIP_PACKAGE "atmelavr32c.bmp"
            #else
                #define CHIP_PACKAGE "..//..//..//Hardware//AVR32//GUI//atmelavr32c.bmp"
            #endif
        #else
            #ifdef _EXE
                #define CHIP_PACKAGE "atmelavr32.bmp"
            #else
                #define CHIP_PACKAGE "..//..//..//Hardware//AVR32//GUI//atmelavr32.bmp"
            #endif
        #endif
        #define PORT_FIRST_LINE 320
        #define USB_LEFT   277 
        #define USB_TOP    95
        #define USB_RIGHT  338
        #define USB_BOTTOM 119
    #endif
    #define PORT_DISPLAY_LEFT 85
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {227,234,274,289};
#endif
#ifdef _M5223X
    #define PORT_TEXT_LENGTH 8
    #if defined _M5222X
        #ifdef _EXE
            #define CHIP_PACKAGE "M5222X.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//M5222X.bmp"
        #endif
        #define USB_LEFT   180 
        #define USB_TOP    96
        #define USB_RIGHT  230
        #define USB_BOTTOM 116
    #elif defined _M521X_SDRAM                                           // {50}
        #ifdef _EXE
            #define CHIP_PACKAGE "m5216.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//m5216.bmp"
        #endif
    #elif defined _M520X                                                 // {53}
        #ifdef _EXE
            #define CHIP_PACKAGE "m5208.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//m5208.bmp"
        #endif
        static  RECT rect_LAN_LED = {282,63,333,118};
        #undef PORT_TEXT_LENGTH
        #define PORT_TEXT_LENGTH 13
    #elif defined _M523X                                                 // {62}
        #ifdef _EXE
            #define CHIP_PACKAGE "m5235.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//m5235.bmp"
        #endif
        static  RECT rect_LAN_LED = {282,63,333,118};
        #undef PORT_TEXT_LENGTH
        #define PORT_TEXT_LENGTH 13        
    #elif defined _M523X                                                 // {62}
        #ifdef _EXE
            #define CHIP_PACKAGE "m5282.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//m5282.bmp"
        #endif
        #undef PORT_TEXT_LENGTH
        #define PORT_TEXT_LENGTH 13
        static  RECT rect_LAN_LED = {282,63,333,118};
    #elif defined _M52XX_SDRAM                                           // {50}
        #ifdef _EXE
            #define CHIP_PACKAGE "m5282.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//m5282.bmp"
        #endif
        #define DOUBLE_COLUMN_PORTS
        #define SECOND_PORT_COLUMN_OFFSET  170
        static  RECT rect_LAN_LED = {282,63,333,118};
    #elif defined _M521XX                                                // {31}
        #ifdef _EXE
            #define CHIP_PACKAGE "M521XX.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//M521XX.bmp"
        #endif
    #elif defined _M521X                                                 // {32}
        #ifdef _EXE
            #define CHIP_PACKAGE "M521X.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//M521X.bmp"
        #endif
    #elif defined _M5221X
        #ifdef _EXE
            #define CHIP_PACKAGE "M5221X.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//M5221X.bmp"
        #endif
        #define USB_LEFT   180 
        #define USB_TOP    96
        #define USB_RIGHT  230
        #define USB_BOTTOM 116
    #elif defined _M5225X
        #ifdef _EXE
            #define CHIP_PACKAGE "kirin3.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//kirin3.bmp"
        #endif
        #define USB_LEFT   225 
        #define USB_TOP    111
        #define USB_RIGHT  275
        #define USB_BOTTOM 131
        static  RECT rect_LAN_LED = {229,207,276,262};
    #else
        #ifdef _EXE
            #define CHIP_PACKAGE "M5223X.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//M5223X//GUI//M5223X.bmp"
        #endif
        static  RECT rect_LAN_LED = {173,85,220,140};
    #endif
    #if defined _M52XX_SDRAM                                             // {50}
        #define PORT_FIRST_LINE 250
        #define PORT_DISPLAY_LEFT 100
    #elif defined _M520X                                                 // {53}
        #define PORT_FIRST_LINE 250
        #define PORT_DISPLAY_LEFT 166
    #elif defined _M523X                                                 // {62}
        #define PORT_FIRST_LINE 240
        #define PORT_DISPLAY_LEFT 163
    #else
        #define PORT_FIRST_LINE 280
        #define PORT_DISPLAY_LEFT 187
    #endif
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
#endif
#ifdef _FLEXIS32                                                         // {47}
    #ifdef ETH_INTERFACE
        #ifdef _EXE
            #define CHIP_PACKAGE "flexis32eth.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//Flexis32//GUI//flexis32eth.bmp"
        #endif
    #else
        #ifdef _EXE
            #define CHIP_PACKAGE "flexis32.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//Flexis32//GUI//flexis32.bmp"
        #endif
    #endif
    static  RECT rect_LAN_LED = {173,85,220,140};
    #define PORT_FIRST_LINE 280
    #define PORT_DISPLAY_LEFT 184
    #define START_PORTS_X (PORT_DISPLAY_LEFT + 9)
    #define PORT_TEXT_LENGTH 8
#endif
#ifdef _STR91XF
    #ifdef _EXE
        #define CHIP_PACKAGE "str91xf.bmp"
    #else
        #define CHIP_PACKAGE "..//..//..//Hardware//STR91XF//GUI//str91xf.bmp"
    #endif
    #define PORT_FIRST_LINE 320
    #define PORT_DISPLAY_LEFT 185
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {301,85,348,140};
#endif
#ifdef _STM32                                                            // {54}
    #if defined ST_VALUE                                                 // value line
        #ifdef _EXE
            #define CHIP_PACKAGE "stm32f100.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//STM32//GUI//stm32f100.bmp"
        #endif
        #define PORT_FIRST_LINE   270
        #define PORT_DISPLAY_LEFT 149
    #else                                                                // connectivity line
        #if defined _STM32F4XX                                           // {76}
            #ifdef _EXE
                #define CHIP_PACKAGE "stm32f407.bmp"
            #else
                #define CHIP_PACKAGE "..//..//..//Hardware//STM32//GUI//stm32f407.bmp"
            #endif
        #else
            #ifdef _EXE
                #define CHIP_PACKAGE "stm32f107.bmp"
            #else
                #define CHIP_PACKAGE "..//..//..//Hardware//STM32//GUI//stm32f107.bmp"
            #endif
        #endif
        #define PORT_FIRST_LINE   320
        #define PORT_DISPLAY_LEFT 154
    #endif
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {303,84,350,139};
    #define USB_LEFT   (294)                                             // {75}
    #define USB_TOP    (159)
    #define USB_RIGHT  (346)
    #define USB_BOTTOM (179)
#endif
#if defined _LPC17XX                                                     // {46}
    #ifdef _EXE
        #define CHIP_PACKAGE "LPC17XX.bmp"
    #else
        #define CHIP_PACKAGE "..//..//..//Hardware//LPC17XX//GUI//LPC17XX.bmp"
    #endif
    #define USB_LEFT   229
    #define USB_TOP    85
    #define USB_RIGHT  281
    #define USB_BOTTOM 105
    #define PORT_FIRST_LINE 290
    #define PORT_DISPLAY_LEFT 70
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 9
    static  RECT rect_LAN_LED = {229,163,276,203};
#endif
#if defined _KINETIS                                                     // {58}
    #ifdef ETH_INTERFACE                                                 // {70}
        #ifdef _EXE
            #define CHIP_PACKAGE "kinetis_lan.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//Kinetis//GUI//kinetis_lan.bmp"
        #endif
    #else
        #ifdef _EXE
            #define CHIP_PACKAGE "kinetis.bmp"
        #else
            #define CHIP_PACKAGE "..//..//..//Hardware//Kinetis//GUI//kinetis.bmp"
        #endif
    #endif
    #define USB_LEFT   334
    #define USB_TOP    75
    #define USB_RIGHT  386
    #define USB_BOTTOM 95
    #define PORT_FIRST_LINE 290
    #define PORT_DISPLAY_LEFT 70
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 9
    static  RECT rect_LAN_LED = {332,189,402,241};
#endif
#ifdef _LPC23XX
    #if defined _LPC21XX
        #ifdef _EXE
        #define CHIP_PACKAGE "LPC21XX.bmp"
        #else
        #define CHIP_PACKAGE "..//..//..//Hardware//LPC23XX//GUI//LPC21XX.bmp"
        #endif
        #define USB_LEFT   229
        #define USB_TOP    101
        #define USB_RIGHT  281
        #define USB_BOTTOM 121
    #elif defined _LPC24XX
        #ifdef _EXE
        #define CHIP_PACKAGE "LPC24XX.bmp"
        #else
        #define CHIP_PACKAGE "..//..//..//Hardware//LPC23XX//GUI//LPC24XX.bmp"
        #endif
        #define USB_LEFT   229
        #define USB_TOP    85
        #define USB_RIGHT  281
        #define USB_BOTTOM 105
    #else
        #ifdef _EXE
        #define CHIP_PACKAGE "LPC23XX.bmp"
        #else
        #define CHIP_PACKAGE "..//..//..//Hardware//LPC23XX//GUI//LPC23XX.bmp"
        #endif
        #define USB_LEFT   229
        #define USB_TOP    85
        #define USB_RIGHT  281
        #define USB_BOTTOM 105
    #endif
    #define PORT_FIRST_LINE 280
    #define PORT_DISPLAY_LEFT 70
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 9
    static  RECT rect_LAN_LED = {228,160,275,200};
#endif
#ifdef _LM3SXXXX
    #ifdef _EXE
        #ifdef _LM3S10X
            #define CHIP_PACKAGE "lm3s10x.bmp"
        #else
            #ifdef DEVICE_WITHOUT_ETHERNET
                #define CHIP_PACKAGE "lm3sxxxx.bmp"
            #else
                #define CHIP_PACKAGE "lm3sxxxxEth.bmp"
            #endif
        #endif
    #else
        #ifdef _LM3S10X
            #define CHIP_PACKAGE "..//..//..//Hardware//LM3SXXXX//GUI//lm3s10x.bmp"
        #else
            #ifdef DEVICE_WITHOUT_ETHERNET
                #define CHIP_PACKAGE "..//..//..//Hardware//LM3SXXXX//GUI//lm3sxxxx.bmp"
            #else
                #define CHIP_PACKAGE "..//..//..//Hardware//LM3SXXXX//GUI//lm3sxxxxEth.bmp"
            #endif
        #endif   
    #endif
    #ifdef _LM3S10X
        #define PORT_FIRST_LINE 225
    #else
        #define PORT_FIRST_LINE 295
    #endif
    #define PORT_DISPLAY_LEFT 187
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {228,205,275,260};
    #ifdef DEVICE_WITHOUT_ETHERNET
        #define USB_LEFT   226 
        #define USB_TOP    213
        #define USB_RIGHT  276
        #define USB_BOTTOM 233
    #else
        #define USB_LEFT   173 
        #define USB_TOP    83
        #define USB_RIGHT  223
        #define USB_BOTTOM 102
    #endif
#endif
#ifdef _RX6XX
    #ifdef _EXE
        #define CHIP_PACKAGE "atmelavr32.bmp"
    #else
        #define CHIP_PACKAGE "..//..//..//Hardware//AVR32//GUI//atmelavr32.bmp"
    #endif
    #define PORT_FIRST_LINE 320
    #define USB_LEFT   277 
    #define USB_TOP    95
    #define USB_RIGHT  338
    #define USB_BOTTOM 119
    #define PORT_DISPLAY_LEFT 85
    #define START_PORTS_X (PORT_DISPLAY_LEFT)
    #define PORT_TEXT_LENGTH 8
    static  RECT rect_LAN_LED = {227,234,274,289};
#endif

#if defined SUPPORT_LCD || defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE // {35}
    #define DEVICE_X_POS 9
#else
    #define DEVICE_X_POS 2
#endif

#ifdef SERIAL_INTERFACE                                                  // if we have a serial port we simulate it here
    static HANDLE fnConfigureSerialInterface(char cCom, DWORD com_port_speed, UART_MODE_CONFIG Mode); // {26}
    static HANDLE sm_hComm0 = INVALID_HANDLE_VALUE;
    static HANDLE sm_hComm1 = INVALID_HANDLE_VALUE;
    static HANDLE sm_hComm2 = INVALID_HANDLE_VALUE;
    static HANDLE sm_hComm3 = INVALID_HANDLE_VALUE;                      // {9}
    static HANDLE sm_hComm4 = INVALID_HANDLE_VALUE;                      // {67}
    static HANDLE sm_hComm5 = INVALID_HANDLE_VALUE;
    #if NUMBER_EXTERNAL_SERIAL > 0                                       // {41}
        static HANDLE sm_hCommExt_0 = INVALID_HANDLE_VALUE;
        static HANDLE sm_hCommExt_1 = INVALID_HANDLE_VALUE;
        static HANDLE sm_hCommExt_2 = INVALID_HANDLE_VALUE;
        static HANDLE sm_hCommExt_3 = INVALID_HANDLE_VALUE;
    #endif
    static DWORD fnCheckRx(HANDLE m_hComm, unsigned char *pData);
    static DWORD fnSendSerialMessage(HANDLE m_hComm, const void* lpBuf, DWORD dwCount);
    static void fnProcessRx(unsigned char *ptrData, unsigned short usLength, int iPort);
#endif
static void fnProcessKeyChange(void);
static void fnProcessInputChange(void);
static void fnSimPortInputToggle(int iPort, int iPortBit);

#define UTASKER_WIN_WIDTH  500

#if defined SUPPORT_LCD || defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE // {35}
    #define UTASKER_WIN_LCD_WIDTH (22 * LCD_CHARACTERS)
#else
    #define UTASKER_WIN_LCD_WIDTH 0
#endif

#if defined _HW_SAM7X
    #if defined _HW_SAM7S                                                // {48}
        #define UTASKER_WIN_HEIGHT 400
    #elif defined _HW_SAM7SE                                             // {57}
        #define UTASKER_WIN_HEIGHT 500
    #else
        #define UTASKER_WIN_HEIGHT 475                                   // {21}
    #endif
#elif defined _HW_SAM3                                                   // {73}
    #if defined _SAM3UX
        #define UTASKER_WIN_HEIGHT 480
    #else
        #define UTASKER_WIN_HEIGHT 440
    #endif
#elif defined (_LPC23XX)
    #ifdef _LPC21XX
        #ifdef _LPC214X                                                  // {49}
            #define UTASKER_WIN_HEIGHT 420
        #else
            #define UTASKER_WIN_HEIGHT 395
        #endif
    #else
        #define UTASKER_WIN_HEIGHT 500
    #endif
#elif defined _LPC17XX
    #define UTASKER_WIN_HEIGHT 500
#elif defined (_LM3SXXXX) && defined (_LM3S10X)
    #define UTASKER_WIN_HEIGHT 395
#elif defined (_STR91XF) && !(defined CHIP_80_PIN)
    #define UTASKER_WIN_HEIGHT 600
#elif defined (_M5223X)
    #ifdef _M5225X                                                       // {16}
        #define UTASKER_WIN_HEIGHT 672
    #else
        #define UTASKER_WIN_HEIGHT 612
    #endif
#elif defined _AT32UC3B
    #define UTASKER_WIN_HEIGHT 440
#elif defined _STM32
    #define UTASKER_WIN_HEIGHT  (381 + (24 * PORTS_AVAILABLE))           // {71}
#else
    #define UTASKER_WIN_HEIGHT 580
#endif

static unsigned long ulPortStates[PORTS_AVAILABLE]     = {0};
static unsigned long ulPortFunction[PORTS_AVAILABLE]   = {0};
static unsigned long ulPortPeripheral[PORTS_AVAILABLE] = {0};

static TEXTMETRIC Port_tm;

static RECT present_windows_rect;
static RECT present_ports_rect;

#define PORT_LINE_SPACE 20
#define PORT_NAME_LENGTH 8

#if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X // {32}
static int fnJumpPort(int i)
{
    switch (i) {
    case 2:                                                              // jump LD port
        return 1;
    #if !defined _M521X                                                  // {32}
    case 6:                                                              // jump TD port
        return 1;
    #endif
    case 11:                                                             // jump GP port
        return 1;
    }
    return 0;
}
#endif

static void fnDisplayPorts(HDC hdc)
{
    extern unsigned long fnGetPortMask(int iPortNumber);
    int i, y;
    unsigned long ulBit;
#ifdef _HW_NE64
    unsigned long ulMSB = 0x00000080;
    #ifdef CHIP_80_PIN
        unsigned long ulPortMask = 0xff;
    #else
        unsigned long ulPortMask = 0x00;
    #endif
#endif
#ifdef _STM32                                                            // {54}
    unsigned long ulMSB = 0x00008000;
    unsigned long ulPortMask = 0;
#endif
#if defined _HW_SAM3                                                     // {73}
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0;
#endif
#if defined _HW_SAM7X
    #ifdef _HW_SAM7S                                                     // {48}
        #ifdef CHIP_48_PIN
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0xffe00000;
        #else
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0;
        #endif
    #elif defined _HW_SAM7SE                                             // {57}
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0;
    #else
    unsigned long ulMSB = 0x40000000;
    unsigned long ulPortMask = 0;
    #endif
#endif
#if defined _HW_AVR32                                                    // {34}
    #if defined _AT32UC3B                                                // {45}
    unsigned long ulMSB = 0x80000000;
        #ifdef CHIP_48_PIN
    unsigned long ulPortMask = 0xf0000000;
        #else
    unsigned long ulPortMask = 0x00000000;
        #endif
    #elif defined _AT32UC3C                                              // {63}
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0xc0060000;
    #else
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0x80000000;
    #endif
#endif
#if defined _RX6XX
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = 0x80000000;
#endif
#if defined _LM3SXXXX
    unsigned long ulMSB = 0x80;
    #if defined _LM3S10X
    unsigned long ulPortMask = 0xc0;
    #elif defined _LM3S2110                                              // {22}
    unsigned long ulPortMask = 0x80;
    #else
    unsigned long ulPortMask = 0;
    #endif
#endif
#ifdef _STR91XF
    unsigned long ulMSB = 0x00000080;
    #ifdef CHIP_80_PIN
        unsigned long ulPortMask = 0xff;
    #else
        unsigned long ulPortMask = 0x00;
    #endif
#endif
#if defined _LPC23XX || defined _LPC17XX
    #undef PORT_NAME_LENGTH
    #define PORT_NAME_LENGTH 9
    #ifdef _LPC21XX
        unsigned long ulMSB = 0x80000000;
        #ifdef _LPC214X                                                  // {49}
        unsigned long ulPortMask = 0x0d000000;                           // P0.24, P0.26 and P0.27 not available
        #elif defined _LPC213X                                           // {60}
        unsigned long ulPortMask = 0x01000000;                           // P0.24 not available
        #else
            #if (defined LPC2101 || defined LPC2102 || defined LPC2103) && (defined PLCC44)
        unsigned long ulPortMask = 0x04000000;                           // P0.26 not available in LPCC44 housing
            #else
        unsigned long ulPortMask = 0;
            #endif
        #endif
    #else
        unsigned long ulMSB = 0x80000000;
        #if defined DEVICE_144_PIN || defined _LPC24XX
        unsigned long ulPortMask = 0;
        #elif defined _LPC17XX && defined DEVICE_80_PIN                  // {46}
        unsigned long ulPortMask = 0x99b87030;
        #else
        unsigned long ulPortMask = 0x80007000;
        #endif
    #endif
#endif
#if defined KINETIS_K61 || defined KINETIS_K70                           // {74}
    #undef PORT_NAME_LENGTH
    #define PORT_NAME_LENGTH 9
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask;
#elif defined _KINETIS                                                   // {58}
    #if defined KINETIS_K10
        #define KINETIS_DEVICE 0
    #elif defined KINETIS_K20
        #define KINETIS_DEVICE 1
    #elif defined KINETIS_K30
        #define KINETIS_DEVICE 2
    #elif defined KINETIS_K40
        #define KINETIS_DEVICE 3
    #elif defined KINETIS_K50
        #define KINETIS_DEVICE 4
    #elif defined KINETIS_K51
        #define KINETIS_DEVICE 5
    #elif defined KINETIS_K52
        #define KINETIS_DEVICE 6
    #elif defined KINETIS_K53
        #define KINETIS_DEVICE 7
    #elif defined KINETIS_K60
        #define KINETIS_DEVICE 8
    #endif
    #if defined DEVICE_80_PIN
        #define KINETIS_PACKAGE 0
    #elif defined DEVICE_100_PIN
        #define KINETIS_PACKAGE 1
    #elif defined DEVICE_121_PIN
        #define KINETIS_PACKAGE 2
    #else
        #define KINETIS_PACKAGE 3
    #endif
    const unsigned long _kinetis_ports[10][4][5] = {                 // {70}
        {                                                            // K10
            {                                                        // 80/81 pin package
                0xfff00fc0, 0xfff0f3f0, 0xfffcf000, 0xffffff00, 0xfff0ffc0,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff00fc0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xf8f0ff80,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff003c0, 0xff00f030, 0xffe00000, 0xffff0000, 0xf8f0ff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0000, 0xe0f0e000,// ports A..E
            },
        },
        {                                                            // K20
            {                                                        // 80/81 pin package
                0xfff00fc0, 0xfff0f3f0, 0xfffcf000, 0xffffff00, 0xffffffc0,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff00fc0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xf8ffff80,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff003c0, 0xff00f030, 0xffe00000, 0xffff0000, 0xf8ffff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0000, 0xe0ffe000,// ports A..E
            },
        },
        {                                                            // K30
            {                                                        // 80/81 pin package
                0xfff00fc0, 0xfff0f3f0, 0xfffcf000, 0xffff0300, 0xffffffc0,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff00fc0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xf8ffff80,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff003c0, 0xff00f030, 0xffe00000, 0xffff0300, 0xf8ffff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0300, 0xe0ffe000,// ports A..E
            },
        },
        {                                                            // K40
            {                                                        // 80/81 pin package
                0xfff00fc0, 0xfff0f3f0, 0xfffcf000, 0xffff0300, 0xffffffc0,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff00fc0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xf8ffff80,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff003c0, 0xff00f030, 0xffe00000, 0xffff0300, 0xf8ffff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0300, 0xe0ffe000,// ports A..E
            },
        },
        {                                                            // K50
            {                                                        // 80/81 pin package
                0xfff3ffe0, 0xfff0f3f0, 0xfffcf000, 0xffffff00, 0xffffffff,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff30fe0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xffffffc0,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff00bc0, 0xff00f030, 0xfff00000, 0xffff0000, 0xfffff000,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0000, 0xefffe000,// ports A..E
            },
        },
        {                                                            // K51
            {                                                        // 80/81 pin package
                0xfff3ffe0, 0xfff0f0f0, 0xfffff000, 0xffffff00, 0xffffffff,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff30fe0, 0xff00f070, 0xfff8f000, 0xffffff00, 0xffffffc0,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff00bc0, 0xff00f030, 0xfff00000, 0xffff0000, 0xffffff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0300, 0xefffe000,// ports A..E
            },
        },
        {                                                            // K52
            {                                                        // 80/81 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,  // ports A..E
            },
            {                                                        // 100 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,// ports A..E
            },
            {                                                        // 121 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0000, 0xefffe000,// ports A..E - only 144 pin available
            },
        },
        {                                                            // K53
            {                                                        // 80/81 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,  // ports A..E
            },
            {                                                        // 100 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,// ports A..E
            },
            {                                                        // 121 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0300, 0xefffe000,// ports A..E - only 144 pin available
            },
        },
        {                                                            // K60
            {                                                        // 80/81 pin package
                0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff, 0xffffffff,  // ports A..E - not available in 80 pin package
            },
            {                                                        // 100 pin package
                0xfff00fc0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xf8ffff80,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff003c0, 0xff00f030, 0xffe00000, 0xffff0000, 0xf8ffff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0000, 0xe0ffe000,// ports A..E
            },
        },
        {                                                            // K70
            {                                                        // 80/81 pin package
                0xfff00fc0, 0xfff0f3f0, 0xfffcf000, 0xffffff00, 0xffffffc0,  // ports A..E
            },
            {                                                        // 100 pin package
                0xfff00fc0, 0xff00f1f0, 0xfff80000, 0xffffff00, 0xf8ffff80,// ports A..E
            },
            {                                                        // 121 pin package
                0xdff003c0, 0xff00f030, 0xffe00000, 0xffff0000, 0xf8ffff80,// ports A..E
            },
            {                                                        // 144 pin package
                0xc0f00000, 0xff00f000, 0xfff00000, 0xffff0000, 0xe0ffe000,// ports A..E
            },
        },
    };
    #undef PORT_NAME_LENGTH
    #define PORT_NAME_LENGTH 9
    unsigned long ulMSB = 0x80000000;
    unsigned long ulPortMask = _kinetis_ports[KINETIS_DEVICE][KINETIS_PACKAGE][0];
#endif
#if defined _M5223X
    unsigned long ulMSB = 0x00000080;
    #if defined _M52XX_SDRAM                                             // {50}
    signed char cPorts[] = "PORT  A vvvvvvvv";
    #elif defined _M520X                                                 // {53}
    signed char cPorts[] = "PORT ?ECH     vvvvvvvv";
    #elif defined _M523X                                                 // {62}
    signed char cPorts[] = "PORT A?DR     vvvvvvvv";
    #else
    signed char cPorts[] = "PORT QS vvvvvvvv";
    #endif
    #if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X //{32}
        #ifdef CHIP_64_PIN
        unsigned long ulPortMask = 0xf0;
        #else
        unsigned long ulPortMask = 0x80;
        #endif
    #elif defined _M52XX_SDRAM                                           // {50}
        unsigned long ulPortMask = 0x00;
    #elif defined _M520X                                                 // {53}
        unsigned long ulPortMask = 0x00;
        #undef PORT_NAME_LENGTH
        #define PORT_NAME_LENGTH 13
    #elif defined _M5225X                                                // {16}
        unsigned long ulPortMask = 0x90;
    #elif defined _M523X                                                 // {62}
        unsigned long ulPortMask = 0x1f;
        #undef PORT_NAME_LENGTH
        #define PORT_NAME_LENGTH 13
    #else
        #if defined CHIP_80_PIN
        unsigned long ulPortMask = 0xf0;
        #else
        unsigned long ulPortMask = 0x80;
        #endif
    #endif
#elif defined _FLEXIS32
    #undef PORT_NAME_LENGTH
    #define PORT_NAME_LENGTH 9
    unsigned long ulMSB = 0x00000080;
    signed char cPorts[PORT_WIDTH + PORT_NAME_LENGTH] = "PORT PTA";
    unsigned long ulPortMask = 0x00;
#else
    #if defined (_STR91XF)
    char cPorts[PORT_WIDTH + PORT_NAME_LENGTH] = "GPIO 0  ";
    #elif defined (_LPC23XX) || defined _LPC17XX
    signed char cPorts[PORT_WIDTH + PORT_NAME_LENGTH] = "P0.31..0 ";
    #elif defined _HW_AVR32                                              // {34}
    signed char cPorts[PORT_WIDTH + PORT_NAME_LENGTH] = "PORT 0  ";
    #else                                                                // SAM7X
    signed char cPorts[PORT_WIDTH + PORT_NAME_LENGTH] = "PORT A  ";
    #endif
#endif
    unsigned char ucPortWidth = PORT_WIDTH;
    char cPortDetails[200];
    HGDIOBJ hFont = GetStockObject(SYSTEM_FIXED_FONT);
    SetTextColor(hdc, RGB(127,0,0));
    SelectObject(hdc, hFont);
    GetTextMetrics(hdc, &Port_tm);

    present_ports_rect = present_windows_rect;
    present_windows_rect.top += PORT_FIRST_LINE;
    present_ports_rect.top = present_windows_rect.top;
    present_windows_rect.left = PORT_DISPLAY_LEFT;
    for (i = 0; i < PORTS_AVAILABLE; i++) {
#if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X // {32}
        if (fnJumpPort(i)) {
            goto _jump_entry;
        }
#elif defined _STM32 || defined LPC1788 || defined _HW_SAM3 || defined KINETIS_K61 || defined KINETIS_K70 // {72}{73}{74}
        ulPortMask = fnGetPortMask(i);                                   // {71}
#elif defined _HW_SAM7X                                                  // {21}
    #if defined _HW_SAM7S                                                // {48}
        if (i == 1)
    #elif defined _HW_SAM7SE                                             // {57}
        if (i == 3)
    #else
        if (i == 2)
    #endif
        {
            ucPortWidth = 4;
            cPorts[0] = 'A';
            cPorts[1] = 'D';
            cPorts[2] = 'C';
            memset(&cPorts[3], ' ', (sizeof(cPorts) - 3)); 
        }
    #if defined _HW_SAM7SE                                               // {57}
        else if (i == 2) {
            ulPortMask = 0xff000000;
        }
    #endif
#elif defined _LM3SXXXX && (PORTS_AVAILABLE != _PORTS_AVAILABLE)         // {33} ADC is seperate from GPIO
        if (i == (PORTS_AVAILABLE - 1)) {
            ulPortMask = (0xff << ADC_CHANNELS);
            cPorts[0] = 'A';
            cPorts[1] = 'D';
            cPorts[2] = 'C';
            memset(&cPorts[3], ' ', (sizeof(cPorts) - 3)); 
        }
#endif
        ulBit = ulMSB;
        for (y = 0; y < ucPortWidth; y++) {                              // draw each port state
            if (ulPortMask & ulBit) {
                cPorts[y + PORT_NAME_LENGTH] = '-';                      // bit with no function
            }
            else {
                if (ulPortPeripheral[i] & ulBit) {
                    if (ulPortStates[i] & ulBit) {
                        cPorts[y + PORT_NAME_LENGTH] = 'P';              // used for peripheral function ('1' state)
                    }
                    else {
                        cPorts[y + PORT_NAME_LENGTH] = 'p';              // used for peripheral function ('0' state)
                    }
                }
                else {
                    if (ulPortFunction[i] & ulBit) {                     // defined as an output
                        if (ulPortStates[i] & ulBit) {
                            cPorts[y + PORT_NAME_LENGTH] = '1';
                        }
                        else {
                            cPorts[y + PORT_NAME_LENGTH] = '0';
                        }
                    }
                    else {
                        if (ulPortStates[i] & ulBit) {                   // display the input state
                            cPorts[y + PORT_NAME_LENGTH] = '^';
                        }
                        else {
                            cPorts[y + PORT_NAME_LENGTH] = 'v';
                        }                                      
                    }
                }
            }
            ulBit >>= 1;
        }
        ulPortMask = 0;
#if defined _STR91XF
    #ifdef CHIP_80_PIN
        switch (cPorts[5]) {
        case '0':
            ulPortMask = 0xff;
            break;
        case '6':
            ulPortMask = 0xff;
            break;
        case '7':
            ulPortMask = 0xff;
            break;
        case '8':
            ulPortMask = 0xff;
            break;
        }
    #endif
#endif
#if defined _KINETIS && !(defined KINETIS_K61 || defined KINETIS_K70)    // {70}{74}
        ulPortMask = _kinetis_ports[KINETIS_DEVICE][KINETIS_PACKAGE][i + 1];
#endif
#if defined _HW_AVR32                                                    // {34}
    #if defined _AT32UC3B                                                // {45}
        if (cPorts[5] == '0') {
            ulPortMask = 0xfffff000;
        }
    #endif
    #ifdef CHIP_100_PIN
        if (cPorts[5] == '1') {
            ulPortMask = 0xffffffc0;
        }
    #endif
        if (cPorts[5] == '2') {
    #if defined _AT32UC3C                                              // {63}
            ulPortMask = 0x80000000;
    #else
        #ifdef CHIP_100_PIN
            ulPortMask = 0xffffffff;
        #else
            ulPortMask = 0xffffc000;
        #endif
    #endif
        }
#endif
#if defined _LM3SXXXX
        switch (cPorts[5]) {
    #ifdef _LM3S10X
        case 'B':
            ulPortMask = 0xf0;
            break;
    #endif
    #if defined _LM3S1968 || defined _LM3S1958 || defined _LM3S5732      // {52}
        case 'C':
            ulPortMask = 0xf0;
            break;
    #endif
        case 'D':
    #if !defined _LM3S3748 && !defined _LM3S3768 && !defined _LM3S9B95 && !defined _LM3S9B90 // {20}{28}{55}
        #if defined _LM3S5732
            ulPortMask = 0xe0;
        #elif defined _LM3S2110                                          // {22}
            ulPortMask = 0xfc;
        #else
            ulPortMask = 0xf0;
        #endif
    #endif
            break;
        case 'E':
    #if !defined _LM3S1968 && !defined _LM3S1958 && !defined _LM3S3748 && !defined _LM3S3768 && !defined _LM3S2139 // {20}{38}{52}
        #if defined _LM3S9B95 || defined _LM3S9B90                       // {28}{55}
            ulPortMask = 0xc0;
        #elif defined _LM3S2110                                          // {22}
            ulPortMask = 0xf8;
        #else
            ulPortMask = 0xf0;
        #endif
    #endif
            break;
        case 'F':
    #if !defined _LM3S1968 && !defined _LM3S1958 && !defined _LM3S3748 && !defined _LM3S3768 && !defined _LM3S2139 // {20}{38}{52}
        #if defined _LM3S9B95 || defined _LM3S9B90                       // {28}{55}
            ulPortMask = 0x7c;
        #else
            ulPortMask = 0xfc;
        #endif
    #endif
            break;
        case 'G':
    #if defined _LM3S1968 || defined _LM3S1958 || defined _LM3S2139      // {38}{52}
            ulPortMask = 0xf0;
    #elif defined _LM3S3748 || defined _LM3S3768                         // {20}
            ulPortMask = 0xe0;
    #elif defined _LM3S2110                                              // {22}
            ulPortMask = 0xfc;
    #endif
            break;
    #ifdef _LM3S9B90
        case 'H':
            ulPortMask = 0xf8;
            break;
    #endif
    #if PORTS_AVAILABLE >= 9                                             // {28}
        case 'I':
            cPorts[5]++;                                                 // jump port I to go to J
            break;
    #endif
        }
#endif
#ifdef _M5223X
        switch (cPorts[6]) {
    #if defined _M520X                                                   // {53}
        case 'U':
            cPorts[6] = 'E';
            cPorts[7] = ' ';
            cPorts[8] = ' ';
            cPorts[9] = ' ';
            cPorts[10] = ' ';
            ulPortMask = 0xf1;            
            break;
        case 'S':
            if (cPorts[5] == 'C') {
                cPorts[5] = 'F';
                cPorts[6] = 'E';
                cPorts[7] = 'C';
                cPorts[8] = 'I';
                cPorts[9] = '2';
                cPorts[10] = 'C';
            }
            else {
                cPorts[5] = 'T';
                cPorts[6] = 'I';
                cPorts[7] = 'M';
                cPorts[8] = 'E';
                cPorts[9] = 'R';
                ulPortMask = 0x6d;
            }
            break;
        case 'A':
            cPorts[5] = 'Q';
            cPorts[6] = 'S';
            cPorts[7] = 'P';
            cPorts[8] = 'I';
            cPorts[9] = ' ';
            cPorts[10] = ' ';
            ulPortMask = 0xf0;
            break;
        case 'I':
            cPorts[5] = 'I';
            cPorts[6] = 'R';
            cPorts[7] = 'Q';
            cPorts[8] = ' ';
            cPorts[9] = ' ';
            cPorts[10] = ' ';
            break;

    #elif defined _M523X                                                 // {62}
        case '?':
            cPorts[6] = 'D';
            ulPortMask = 0x0f;
            break;

        case 'D':
            if (cPorts[5] == 'A') {
                cPorts[5] = 'B';
                cPorts[6] = 'S';
                cPorts[7] = ' ';
                cPorts[8] = ' ';
                ulPortMask = 0x00;
            }
            else {
                cPorts[5] = 'T';
                cPorts[6] = 'I';
                cPorts[7] = 'M';
                cPorts[8] = 'E';
                cPorts[9] = 'R';
                ulPortMask = 0xfc;            
            }
            break;

        case 'S':
            if (cPorts[5] == 'B') {
                cPorts[6] = 'U';
                cPorts[7] = 'S';
                cPorts[8] = 'C';
                cPorts[9] = 'T';
                cPorts[10] = 'L';
                ulPortMask = 0x01;
            }
            else if (cPorts[5] == 'Q') {
                cPorts[5] = 'S';
                cPorts[6] = 'D';
                cPorts[7] = 'R';
                cPorts[8] = 'A';
                cPorts[9] = 'M';
                ulPortMask = 0x00;
            }
            else {
                cPorts[5] = 'D';
                cPorts[6] = 'A';
                cPorts[7] = 'T';
                cPorts[8] = 'A';
                cPorts[9] = 'H';
                ulPortMask = 0x00;
            }
            break;

        case 'U':
            cPorts[5] = 'C';
            cPorts[6] = 'S';
            cPorts[7] = ' ';
            cPorts[8] = ' ';
            cPorts[9] = ' ';
            cPorts[10] = ' ';
            ulPortMask = 0x00;
            break;

        case 'A':
            if (cPorts[9] == 'H') {
                cPorts[9] = 'L';
                if (cPorts[5] == 'D') {
                    ulPortMask = 0xf0;
                }
            }
            else {
                cPorts[5] = 'F';
                cPorts[6] = 'E';
                cPorts[7] = 'C';
                cPorts[8] = 'I';
                cPorts[9] = '2';
                cPorts[10] = 'C';
                ulPortMask = 0xf8;
            }
            break;

        case 'E':
            cPorts[6] = 'T';
            cPorts[7] = 'P';
            cPorts[8] = 'U';
            cPorts[9] = ' ';
            cPorts[10] = ' ';
            ulPortMask = 0x01;
            break;

        case 'T':
            cPorts[5] = 'I';
            cPorts[6] = 'R';
            cPorts[7] = 'Q';
            cPorts[8] = ' ';
            ulPortMask = 0xe0;
            break;

        case 'R':
            cPorts[5] = 'Q';
            cPorts[6] = 'S';
            cPorts[7] = 'P';
            cPorts[8] = 'I';
            ulPortMask = 0xc0;
            break;

        case 'I':
            cPorts[5] = 'U';
            cPorts[6] = 'A';
            cPorts[7] = 'R';
            cPorts[8] = 'T';
            cPorts[9] = 'H';
            break;
    #endif
        case 'Q':
            cPorts[5] = 'D';
            cPorts[6] = 'D';
            break;
    #if !defined _M523X
        case 'T':
            if ('A' == cPorts[5]) {
    #if defined _M5225X                                                  // {16}
                cPorts[5] = 'D';
                cPorts[6] = 'D';
        #ifndef CHIP_144_PIN
                ulPortMask = 0xff;
        #endif
    #elif defined _M52XX_SDRAM                                           // {50}
                cPorts[5] = 'N';
                cPorts[6] = 'Q';
                ulPortMask = 0x000000e4;
    #else
                cPorts[5] = 'G';
                cPorts[6] = 'P';
        #if defined CHIP_80_PIN                                          // {27}
                ulPortMask = 0xff;
        #endif
    #endif
            }
    #if defined _M52XX_SDRAM                                             // {50}
            else if ('Q' == cPorts[5]) {
                cPorts[5] = 'S';
                cPorts[6] = 'D';
                ulPortMask = 0x000000f0;
                ulMSB = 0x00000008;
                ucPortWidth = 4;
            }
    #endif
            else {
                cPorts[5] = 'A';
                cPorts[6] = 'N';
    #if defined _M5225X                                                  // {16}
                ulPortMask = 0x55;
    #elif defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X //{32}
        #ifdef CHIP_64_PIN
                ulPortMask = 0x6d;
        #else
                ulPortMask = 0x01;
        #endif
    #else
        #ifdef CHIP_80_PIN
                ulPortMask = 0xe0;
        #else
                ulPortMask = 0x80;
        #endif
    #endif
            }
            break;
    #endif

        case 'O':
    #ifdef _M5225X                                                       // {16}
            cPorts[5] = 'N';
            cPorts[6] = 'Q';
            ulMSB = 0x00000008;
            ucPortWidth = 4;
    #else
            cPorts[5] = 'L';
            cPorts[6] = 'D';
        #ifdef CHIP_80_PIN
            ulPortMask = 0x6d;
        #else
            ulPortMask = 0x01;
        #endif
    #endif
            break;

    #if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X //{32}
        case 'P':
            cPorts[5] = 'N';
            cPorts[6] = 'Q';
            ulMSB = 0x00000008;
            ucPortWidth = 4;
        #if defined CHIP_64_PIN && !defined _M521XX && !defined _M521X   // {12}{40}{61}
            ulPortMask = 0x0f;
        #endif
            break;

        case 'U':
            cPorts[5] = 'D';
            cPorts[6] = 'D';
            break;
    #endif

    #if !defined _M523X
        case 'E':
    #if defined _M5225X                                                  // {16}
            if (cPorts[5] == 'D') {
                cPorts[5] = 'T';
                cPorts[6] = 'E';
        #ifndef CHIP_144_PIN
                ulPortMask = 0xff;
        #endif
            }
    #elif defined _M52XX_SDRAM                                           // {50}
            if (cPorts[5] == 'D') {
                cPorts[5] = 'E';
                cPorts[6] = 'H';
            }
            else if (cPorts[5] == 'S') {
                cPorts[5] = 'T';
                cPorts[6] = 'A';
                ulPortMask = 0x000000f0;
                cPorts[12] = ' ';
                cPorts[13] = ' ';
                cPorts[14] = ' ';
                cPorts[15] = ' ';
            }
            else if ('T' == cPorts[5]) {
                cPorts[5] = 'U';
                cPorts[6] = 'A';
            }
    #elif defined _M520X                                                 // {53}
            if (cPorts[5] == '?') {
                cPorts[5] = 'F';
            }
            else if (cPorts[5] == 'B') {
                cPorts[5] = 'C';
                cPorts[6] = 'S';
                ulPortMask = 0xf0;
            }
            else if (cPorts[8] == 'H') {
                cPorts[8] = 'L';
                ulPortMask = 0xf0;
            }
            else if (cPorts[8] == 'L') {
                cPorts[5] = 'B';
                cPorts[6] = 'U';
                cPorts[7] = 'S';
                cPorts[8] = 'C';
                cPorts[9] = 'T';
                cPorts[10] = 'L';
                ulPortMask = 0xf0;
            }
            else if (cPorts[8] == 'I') {
                cPorts[5] = 'U';
                cPorts[6] = 'A';
                cPorts[7] = 'R';
                cPorts[8] = 'T';
                cPorts[9] = ' ';
                cPorts[10] = ' ';
                ulPortMask = 0xf0;
            }
    #else
            if (cPorts[5] == 'T') {
                cPorts[5] = 'U';
                cPorts[6] = 'A';
            }
            else {
                cPorts[5] = 'N';
                cPorts[6] = 'Q';
                ulMSB = 0x00000008;
                ucPortWidth = 4;
            }
    #endif
            break;
    #endif

    #if defined _M5225X                                                  // {16}
        case 'F':
            if (cPorts[5] == 'T') {
        #ifndef CHIP_144_PIN
                ulPortMask = 0xff;
        #else
                ulPortMask = 0x10;
        #endif
            }
            break;

        #ifndef CHIP_144_PIN
        case 'G':
            if (cPorts[5] == 'T') {
                ulPortMask = 0xff;
            }
            break;
        #endif
    #endif

    #if defined _M52XX_SDRAM                                             // {50}
        case 'I':
            if ('E' == cPorts[5]) {
                cPorts[6] = 'L';
                ulPortMask = 0x000000c0;
            }
            else {
                cPorts[6] = 'J';
            }
            break;

        case 'K':
            cPorts[5] = 'D';
            cPorts[6] = 'D';
            break;

        case 'M':
            cPorts[5] = 'A';
            cPorts[6] = 'S';
            ulPortMask = 0x00000001;
            break;

        case 'S':
            cPorts[5] = 'N';
            cPorts[6] = 'Q';
            break;

        case 'R':
            cPorts[5] = 'Q';
            cPorts[6] = 'A';
            ulPortMask = 0x000000f0;
            break;
        case 'B':
            if ('Q' == cPorts[5]) {
                ulPortMask = 0x00000080;
            }
            else if ('T' == cPorts[5]) {
                ulPortMask = 0x000000f0;
            }
            break;
    #elif !defined _M520X && !defined _M523X                                                // {53}
        case 'R':
            cPorts[5] = 'T';
            cPorts[6] = 'A';
            cPorts[12] = ' ';
            cPorts[13] = ' ';
            cPorts[14] = ' ';
            cPorts[15] = ' ';
            ulMSB = 0x00000008;
            ucPortWidth = 4;
            break;

        case 'B':
            if ('T' == cPorts[5]) {
                cPorts[6] = 'C';
        #if defined CHIP_80_PIN || (defined CHIP_64_PIN && !defined _M5221X) // {32}{66}
                ulPortMask = 0xff;
        #endif
            }
        #if defined CHIP_80_PIN || defined CHIP_64_PIN || defined CHIP_81_PIN
            else if ('U' == cPorts[5]) {
                ulPortMask = 0xff;                                       // UC not available
            }
        #endif
            break;
    #endif

        case 'C':
    #if defined _M52XX_SDRAM                                             // {50}
            if ('Q' == cPorts[5]) {
                cPorts[5] = 'Q';
                cPorts[6] = 'S';
                ulPortMask = 0x000000c0;
            }
            else if ('T' == cPorts[5]) {
                ulPortMask = 0x000000f0;
            }
    #else
            if ('U' == cPorts[5]) {
                ucPortWidth = 4;
                ulMSB = 0x08;
        #if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X //{32}
                ulPortMask = 0xfc;
        #elif defined  _M5225X                                           // {16}
            #if defined CHIP_144_PIN
                ulPortMask = 0xf8;
            #else
                ulPortMask = 0xfc;
            #endif
        #endif
            }
    #endif
            break;

    #if !defined _M523X
        case 'D':
            if ('U' == cPorts[5]) {
                cPorts[5] = 'A';
                cPorts[6] = 'S';
                ucPortWidth = 8;
                ulMSB = 0x80;
    #if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X //{32}
        #ifndef CHIP_100_PIN
                ulPortMask = 0xff;
        #endif
    #elif defined _M5225X                                                // {16}
        #ifndef CHIP_144_PIN
                ulPortMask = 0xff;
        #endif
    #else
        #ifdef CHIP_80_PIN
                ulPortMask = 0xf7;
        #endif
    #endif
            }
    #if defined _M52XX_SDRAM                                             // {50}
            else if (cPorts[5] == 'T') {
                ulPortMask = 0x000000f0;
            }
    #endif
    #if defined _M5222X || defined _M5221X || defined _M5225X || defined _M521XX // {16}
            else {
                cPorts[5] = 'U';
                cPorts[6] = 'A';
            }
    #endif
            break;
    #endif
        }
#endif
#if defined _LPC23XX || defined _LPC17XX && (!defined _LPC24XX || defined DEVICE_180_PIN) && !defined LPC1788 // {72}
        switch (cPorts[1]) {
    #if defined _LPC24XX
        #ifdef DEVICE_180_PIN
        case '1':
            ulPortMask = 0xccc0c000;
            break;
        case '2':
            ulPortMask = 0xf87f0000;
            break;
        case '3':
            ulPortMask = 0x00f00000;
            break;
        #endif
    #else
        case '0':
        #if defined _LPC17XX && defined DEVICE_80_PIN                    // {46}
            ulPortMask = 0x082338ec;
        #elif defined _LPC214X || defined _LPC213X                       // {49}{60}
            ulPortMask = 0x0000ffff;                                     // P1.00 .. P1.15  not available
        #else
            ulPortMask = 0x000038ec;
        #endif
            break;
        case '1':
        #if defined _LPC17XX && defined DEVICE_80_PIN                    // {46}
            ulPortMask = 0xfffff800;
        #else
            ulPortMask = 0xffffc000;
        #endif
            break;
        case '2':
        #ifdef DEVICE_144_PIN
            ulPortMask = 0xf87fff00;
        #else
            #if defined _LPC17XX && defined DEVICE_80_PIN                    // {46}
            ulPortMask = 0xffffffff;
            #else
            ulPortMask = 0xf9ffffff;
            #endif
        #endif
            break;

        case '3':
        #ifdef DEVICE_144_PIN
            ulPortMask = 0x0cff0000;
        #else
            ulPortMask = 0xcfffffff;
        #endif
            break;
    #endif
        }
#endif      
        DrawText(hdc, (const char*)cPorts, (PORT_WIDTH + PORT_NAME_LENGTH), &present_windows_rect, 0);
        present_windows_rect.top += PORT_LINE_SPACE;

#if defined _M5222X || defined _M5221X || defined _M521XX || defined _M521X // {32}
_jump_entry:
#endif
#if defined _HW_NE64                                                     // Ports A,B,E,G,H,J,K,L,S,T
        switch (cPorts[5]) {
        case 'A':
            cPorts[5] = 'B';
    #ifdef CHIP_80_PIN
            ulPortMask = 0xff;
    #endif
            break;
        case 'B':
            cPorts[5] = 'E';
    #ifdef CHIP_80_PIN
            ulPortMask = 0xec;
    #endif
            break;
        case 'E':
            cPorts[5] = 'G';
    #ifdef CHIP_80_PIN
            ulPortMask = 0x80;
    #endif
            break;
        case 'G':
            cPorts[5] = 'H';
            ulPortMask = 0x80;
            break;
        case 'H':
            cPorts[5] = 'J';
            ulPortMask = 0x30;            
            break;
        case 'J':
            cPorts[5] = 'K';
    #ifdef CHIP_80_PIN
            ulPortMask = 0xff;
    #endif
            break;
        case 'K':
            cPorts[5] = 'L';
    #ifdef CHIP_80_PIN
            ulPortMask = 0xe0;
    #else
            ulPortMask = 0x80;
    #endif
            break;
        case 'L':
            cPorts[5] = 'S';
            break;
        case 'S':
            cPorts[5] = 'T';
            ulPortMask = 0x0f;
            break;
        case 'T':
            cPorts[1] = 'A';
            cPorts[2] = 'D';
            cPorts[3] = '7';
            cPorts[4] = '-';
            cPorts[5] = '0';
            break;
        }
#elif defined _FLEXIS32
        if (cPorts[7] == 'H') {
            cPorts[7] = 'J';
        }
        else {
            cPorts[7]++;                                                 // numerous ports
        }
    #if defined CHIP_48_PIN
        if (cPorts[7] == 'E') {
            ulPortMask = 0xc0;
        }
        else if (cPorts[7] >= 'F') {
            ulPortMask = 0xff;
        }
    #elif defined CHIP_64_PIN
        if (cPorts[7] == 'G') {
            ulPortMask = 0xf0;
        }
        else if (cPorts[7] == 'J') {
            ulPortMask = 0xfc;
        }
        else if (cPorts[7] >= 'H') {
            ulPortMask = 0xff;
        }
    #else
        if (cPorts[7] == 'J') {
            ulPortMask = 0xc0;
        }
    #endif
#else
    #if defined (_M5223X)
        #if !defined _M520X && !defined _M523X                                              // {53}
        cPorts[6]++;                                                     // numerous ports..
        #endif
        #ifdef DOUBLE_COLUMN_PORTS                                       // {50}
        if (i == (PORTS_AVAILABLE/2)) {                                  // display the second half of port starting at top again
            present_windows_rect.left = PORT_DISPLAY_LEFT + SECOND_PORT_COLUMN_OFFSET;
            present_windows_rect.top = present_ports_rect.top;
        }
        #endif
    #elif defined (_LPC23XX) || defined _LPC17XX
        cPorts[1]++;
    #else
        cPorts[5]++;                                                     // ports A and B
    #endif
#endif
    }
    present_windows_rect.left = 15;                                      // display Port details
    if (present_windows_rect.top < present_windows_rect.bottom - 20) {
        present_windows_rect.top = present_windows_rect.bottom - 20;
    }
    cPortDetails[sizeof(cPortDetails) - 1] = 0;
    memset(cPortDetails, ' ', sizeof(cPortDetails) - 1);
    if (iLastPort >= 0) {
        fnSetPortDetails(cPortDetails, iLastPort, iLastBit, ulPortStates, ulPortFunction, ulPortPeripheral, sizeof(cPortDetails)-1);
    }
    SetTextColor(hdc, RGB(0,0,255));
    SelectObject(hdc, hFont);
    i = strlen(cPortDetails);
    memset(&cPortDetails[i], ' ', (sizeof(cPortDetails) - 1 - i));
    DrawText(hdc, cPortDetails, (sizeof(cPortDetails) - 1), &present_windows_rect, 0);
}


// Support mouse click to toggle input state / hover to display port details
//
static int fnToggleInput(int x, int y, int iCheck)
{
#ifdef DOUBLE_COLUMN_PORTS
    int iPortColumn = 0;
#endif
    int iPortBit = 0, iPort;
    int iSizeX, iSizeY;
    int iStartPortY = PORT_FIRST_LINE;

    x -= (PORT_TEXT_LENGTH * Port_tm.tmAveCharWidth);

    if (x < START_PORTS_X) {                                             // check whether the mouse was on a port
        iLastPort = -1;
        return 0;
    }
    if (y < iStartPortY)  {
        iLastPort = -1;
        return 0;
    }
    x -= START_PORTS_X;
    if (x > (PORT_WIDTH * Port_tm.tmAveCharWidth))  {
#ifdef DOUBLE_COLUMN_PORTS                                               // {50}
        x -= SECOND_PORT_COLUMN_OFFSET;
        if ((x < 0) || (x > (PORT_WIDTH * Port_tm.tmAveCharWidth))) {
            iLastPort = -1;
            return 0;
        }
        iPortColumn = ((PORTS_AVAILABLE + 1)/2);                         // possibly in second port column
#else
        iLastPort = -1;
        return 0;
#endif
    }
#ifdef DOUBLE_COLUMN_PORTS                                               // {50}
    if (y > (iStartPortY + (((PORTS_AVAILABLE + 1)/2) * PORT_LINE_SPACE)))  {
        iLastPort = -1;
        return 0;
    }
#else
    if (y > iStartPortY + (PORTS_AVAILABLE * PORT_LINE_SPACE))  {
        iLastPort = -1;
        return 0;
    }
#endif
    if (iCheck == POSSIBLE_PORT) {
        return 1;
    }

    y -= (iStartPortY);

    iSizeX = Port_tm.tmAveCharWidth;

    while (iPortBit < PORT_WIDTH) {                                      // which input ?
        if (x < iSizeX) {                                                // port row found
#ifdef DOUBLE_COLUMN_PORTS
            iPort = iPortColumn;
#else
            iPort = 0;
#endif
            iSizeY = PORT_LINE_SPACE;
            while (iPort < PORTS_AVAILABLE) {
                if (y < iSizeY) {                                        // port bit column found too
#if defined _M5223X && (defined _M5222X || defined _M5221X || defined _M521XX) // compensate for 2 dummy ports
                    if (iPort >= (_PORT_GP - 2)) {
                        iPort += 3;
                    }
                    else if (iPort >= (_PORT_TD - 1)) {
                        iPort += 2;
                    }
                    else if (iPort >= _PORT_LD) {
                        iPort += 1;
                    }
#elif defined _M5223X && defined _M521X
                    if (iPort >= _PORT_LD) {
                        iPort += 1;
                        if (iPort >= _PORT_GP) {
                            iPort += 1;
                        }
                    }
#endif
                    iLastPort = iPort;
                    iLastBit  = iPortBit;
                    if (PORT_LOCATION == iCheck) {
                        return 0;
                    }
                    fnSimPortInputToggle(iPort, iPortBit);
                    return INPUT_CHANGED;
                }
                iPort++;
                iSizeY += PORT_LINE_SPACE;
            }
        }
        iPortBit++;
        iSizeX += Port_tm.tmAveCharWidth;
    }
    return 0;
}

#ifdef ETH_INTERFACE
static void fnDisplayLAN_LEDs(HDC hdc, RECT refresh_rect)
{
    HBRUSH hBrush;

    if ((refresh_rect.right < rect_LAN_LED.left) || (refresh_rect.bottom < rect_LAN_LED.top)) {
        return;
    }
    SelectObject(hdc, hPen);                                             // select the pen style

    // draw a box with rx and tx LEDs. If active red, or else white
    // RoundRect(hdc, rect_LAN_LED.left, rect_LAN_LED.top, rect_LAN_LED.right, rect_LAN_LED.bottom, 10, 10);
    if (iLastRxActivity) {
        hBrush = hGreenBrush;                                            // {4}
    }
    else {
        hBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
    }
    SelectObject(hdc, hBrush);                                           // select the brush style for the first LED
    Rectangle(hdc, rect_LAN_LED.left+2, rect_LAN_LED.top+27, rect_LAN_LED.left + 2 + 10, rect_LAN_LED.top + 27 + 8);
    if (iLastTxActivity) {
        hBrush = hRedBrush;                                              // {4}
    }
    else {
        hBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
    }
    SelectObject(hdc, hBrush);                                           // select the brush style for the second LED
    Rectangle(hdc, rect_LAN_LED.left+34, rect_LAN_LED.top+27, rect_LAN_LED.left + 34 + 10, rect_LAN_LED.top + 27 + 8);
}
#endif

#ifdef USB_INTERFACE                                                     // {14}
static int iUSBEnumerated = 0;
static int iUSB_state_changed = 0;
#define USB_CIRCLE_RADIUS 4
const POINT lUSB[] = {
    {(USB_LEFT + USB_CIRCLE_RADIUS), (USB_TOP + (USB_BOTTOM - USB_TOP)/2)},
    {USB_RIGHT,(USB_TOP + (USB_BOTTOM - USB_TOP)/2)},
    {(USB_RIGHT - 2*USB_CIRCLE_RADIUS),((USB_TOP + (USB_BOTTOM - USB_TOP)/2) - USB_CIRCLE_RADIUS/2)},
    {(USB_RIGHT - 2*USB_CIRCLE_RADIUS),((USB_TOP + (USB_BOTTOM - USB_TOP)/2) + USB_CIRCLE_RADIUS/2)},
    {USB_RIGHT,(USB_TOP + (USB_BOTTOM - USB_TOP)/2)},
};
const POINT lUSB2[] = {
    {(USB_LEFT + (4*(USB_RIGHT - USB_LEFT)/5)), (USB_BOTTOM - USB_CIRCLE_RADIUS/2)},
    {(USB_LEFT + (3*((USB_RIGHT - USB_LEFT)/5))), (USB_BOTTOM - USB_CIRCLE_RADIUS/2)},
    {(USB_LEFT + ((USB_RIGHT - USB_LEFT)/2)), (USB_TOP + (USB_BOTTOM - USB_TOP)/2)},
    {(USB_LEFT + ((USB_RIGHT - USB_LEFT)/4)), (USB_TOP + (USB_BOTTOM - USB_TOP)/2)},
    {(USB_LEFT + (2*((USB_RIGHT - USB_LEFT)/5))), (USB_TOP + USB_CIRCLE_RADIUS/2)},
    {(USB_LEFT + (3*((USB_RIGHT - USB_LEFT)/5))), (USB_TOP + USB_CIRCLE_RADIUS/2)},
};
const POINT lCheck[] = {
    {USB_LEFT, USB_TOP},
    {USB_RIGHT,USB_TOP},
    {USB_RIGHT,USB_BOTTOM},
    {USB_LEFT,USB_BOTTOM},
    {USB_LEFT,USB_TOP},
};

static const RECT rect_USB_sign = {USB_LEFT,USB_TOP,USB_RIGHT,USB_BOTTOM};

extern "C" void fnChangeUSBState(int iNewState)
{
    iUSBEnumerated = iNewState;
    iUSB_state_changed = 1;                                              // ensure sign is refreshed
    InvalidateRect(ghWnd, &rect_USB_sign, FALSE);
}

static void fnDisplayUSB(HDC hdc, RECT refresh_rect)                     // {14}
{
    if ((refresh_rect.right < rect_USB_sign.left) || (refresh_rect.bottom < rect_USB_sign.top)) {
        if (!iUSB_state_changed) {
            return;
        }
    }
    iUSB_state_changed = 0;
    if (iUSBEnumerated) {                                                // draw a USB sign
        SelectObject(hdc, hRedPen);
        SelectObject(hdc, hRedBrush);
    }
    else {
        SelectObject(hdc, hGrayPen);
        SelectObject(hdc, hGrayBrush);
    }
    RoundRect(hdc, USB_LEFT, ((USB_TOP + ((USB_BOTTOM - USB_TOP)/2)) - USB_CIRCLE_RADIUS), (USB_LEFT + 2*USB_CIRCLE_RADIUS), ((USB_TOP + ((USB_BOTTOM - USB_TOP)/2)) + USB_CIRCLE_RADIUS), (2*USB_CIRCLE_RADIUS), (2*USB_CIRCLE_RADIUS));
    RoundRect(hdc, (USB_LEFT + (3*((USB_RIGHT - USB_LEFT)/5))), USB_TOP, (USB_LEFT + USB_CIRCLE_RADIUS + (3*((USB_RIGHT - USB_LEFT)/5))), (USB_TOP + USB_CIRCLE_RADIUS), (USB_CIRCLE_RADIUS), (USB_CIRCLE_RADIUS));
    Rectangle(hdc, (USB_LEFT + (4*(USB_RIGHT - USB_LEFT)/5)), USB_BOTTOM, ((USB_LEFT + (4*(USB_RIGHT - USB_LEFT)/5)) + USB_CIRCLE_RADIUS), (USB_BOTTOM - USB_CIRCLE_RADIUS));

    Polyline(hdc, lUSB, (sizeof(lUSB)/sizeof(POINT)));
    Polyline(hdc, lUSB2, (sizeof(lUSB2)/sizeof(POINT)));
}
#endif

static char szIPDetails[100] = "IP x.x.x.x : yy-yy-yy-yy-yy-yy";
static char szProjectName[100] = "PROJECT";
static void fnDoDraw(HWND hWnd, HDC hdc, PAINTSTRUCT ps, RECT &rect)
{
    TCHAR szHello[MAX_LOADSTRING];
    static int nInit = 0;
    static BITMAPFILEHEADER *pbmfh = 0;
    static BITMAPINFO *pbmi = 0;
    static BYTE *pBits;
    static int cxDib, cyDib;
    int posx = 0;
    int iStrLen = 0;
    int iWindowsWidth;
    
    RECT rt;
    HGDIOBJ hFont = GetStockObject(SYSTEM_FIXED_FONT);
    GetClientRect( hWnd, &rt );
    present_windows_rect = rt;                                         // present window size
    LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
    iStrLen = strlen(szHello);
    iWindowsWidth = (UTASKER_WIN_WIDTH - rt.left)/2;
    rt.left += 30;
    DrawText( hdc, szHello, iStrLen, &rt, 0 );
    rt.top += 18;
    iStrLen = strlen(szIPDetails);
    DrawText( hdc, szIPDetails, iStrLen, &rt, 0 );

    rt.top += 18;
    rt.bottom += 36;
    SetTextColor(hdc, RGB(255,0,0));
    SelectObject(hdc, hFont);
    iStrLen = strlen(szProjectName);
    DrawText( hdc, szProjectName, iStrLen, &rt, 0 );
    rt.left = 0;

    if (!nInit) {
        HANDLE hFile;
        DWORD dwFileSize, dwHighSize, dwBytesRead;                         // load  a picture of the device
        hFile = CreateFile(CHIP_PACKAGE, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
        if (hFile != INVALID_HANDLE_VALUE) {
            dwFileSize = GetFileSize(hFile, &dwHighSize);
            if (pbmfh = (BITMAPFILEHEADER *)malloc(dwFileSize)) {
                ReadFile(hFile, pbmfh, dwFileSize, &dwBytesRead, NULL);
            }
            CloseHandle (hFile);
            pbmi = (BITMAPINFO *)(pbmfh + 1);
            pBits = (BYTE *) pbmfh + pbmfh->bfOffBits;
            if (pbmi->bmiHeader.biSize == sizeof(BITMAPCOREHEADER)) {
                cxDib = ((BITMAPCOREHEADER *)pbmi)->bcWidth;
                cyDib = ((BITMAPCOREHEADER *)pbmi)->bcHeight;
            }
            else {
                cxDib = pbmi->bmiHeader.biWidth;
                cyDib = abs(pbmi->bmiHeader.biHeight);
            }
        }

        nInit = 1;
    }
    if (pbmfh) {
        posx = iWindowsWidth - cxDib/2;
        SetDIBitsToDevice(hdc, posx, 60, cxDib, cyDib, 0,0,0, cyDib, pBits, pbmi, DIB_RGB_COLORS);
    }
#ifdef ETH_INTERFACE
    fnDisplayLAN_LEDs(hdc, rect);
#endif
#ifdef USB_INTERFACE
    fnDisplayUSB(hdc, rect);
#endif
    fnDisplayPorts(hdc);
    rt.left += (iWindowsWidth * 2);

#if defined SUPPORT_LCD || defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE // {35}
    rt.top = DisplayLCD(hWnd, rect);                                     // re-draw the LCD {5}
    #ifdef SUPPORT_KEY_SCAN
    rt.top += 15;
    #endif
#endif
#ifdef SUPPORT_KEY_SCAN
    DisplayKeyPad(hWnd, rt, rect);
#endif
}

#ifdef KEYPAD_LEDS                                                       // {43}

typedef struct stKEYPAD_LED
{
    COLORREF _led_0_colour;                                              // RGB colour of LED when port drives '0'
    COLORREF _led_1_colour;                                              // RGB colour of LED when port drives '1'
    RECT     _led_pos_size;                                              // LED rectangle referenced to the keypad
    unsigned long _led_port;                                             // port controlling the LED
    unsigned long _led_port_bit;                                         // port line controlling the LED
} KEYPAD_LED;

static const KEYPAD_LED _keypad_leds[KEYPAD_LEDS] = {
    KEYPAD_LED_DEFINITIONS                                               // project specific LED definitions
};

typedef struct stKEYPAD_LED_SIM
{
    HBRUSH led_0_colour;                                                 // brush colour of LED when port drives '0'
    HBRUSH led_1_colour;                                                 // brush colour of LED when port drives '1'
    RECT     led_pos_size;                                               // LED rectangle referenced to the keypad
    unsigned long led_port;                                              // port controlling the LED
    unsigned long led_port_bit;                                          // port line controlling the LED
} KEYPAD_LED_SIM;

static KEYPAD_LED_SIM keypad_leds[KEYPAD_LEDS] = {0};

extern void fnConfigureKeypad_leds(RECT kb_rect)
{
    static int iInit = 0;
    if (iInit == 0) {
        int led = 0;
        while (led < KEYPAD_LEDS) {
            keypad_leds[led].led_0_colour = (HBRUSH)CreateSolidBrush(_keypad_leds[led]._led_0_colour);
            keypad_leds[led].led_1_colour = (HBRUSH)CreateSolidBrush(_keypad_leds[led]._led_1_colour);
            keypad_leds[led].led_pos_size.bottom = _keypad_leds[led]._led_pos_size.bottom + kb_rect.top;
            keypad_leds[led].led_pos_size.top = _keypad_leds[led]._led_pos_size.top + kb_rect.top;
            keypad_leds[led].led_pos_size.left = _keypad_leds[led]._led_pos_size.left + kb_rect.left;
            keypad_leds[led].led_pos_size.right = _keypad_leds[led]._led_pos_size.right + kb_rect.left;
            keypad_leds[led].led_port = _keypad_leds[led]._led_port;
            keypad_leds[led].led_port_bit = _keypad_leds[led]._led_port_bit;
            led++;
        }
        iInit = 1;                                                       // initialisation only performed once
    }
}


extern void fnDisplayKeypadLEDs(HDC hdc)
{
    int led = 0;
    while (led < KEYPAD_LEDS) {
        if (ulPortFunction[keypad_leds[led].led_port] & keypad_leds[led].led_port_bit) { // only draw LEDs when the port is an output
            if (ulPortStates[keypad_leds[led].led_port] & keypad_leds[led].led_port_bit) {
                SelectObject(hdc, keypad_leds[led].led_1_colour);        // select the brush style for the '1' LED
            }
            else {
                SelectObject(hdc, keypad_leds[led].led_0_colour);        // select the brush style for the '0' LED
            }
            Rectangle(hdc, keypad_leds[led].led_pos_size.left, keypad_leds[led].led_pos_size.top, keypad_leds[led].led_pos_size.right, keypad_leds[led].led_pos_size.bottom);
        }
        led++;
    }
}

#endif

static void fnPortDisplay(unsigned long ulPortValue, unsigned long ulPortDirection, unsigned long ulPeripheral, unsigned char ucPortNumber)
{
    if ((ulPortStates[ucPortNumber] != ulPortValue) || (ulPortFunction[ucPortNumber] != ulPortDirection) || (ulPortPeripheral[ucPortNumber] != ulPeripheral)) {
        ulPortStates[ucPortNumber] = ulPortValue;
        ulPortPeripheral[ucPortNumber] = ulPeripheral;
        ulPortFunction[ucPortNumber] = ulPortDirection;
#if defined SUPPORT_LCD ||  defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR // {35}
        present_ports_rect.right = (UTASKER_WIN_WIDTH - 68);             // don't cause LCD update (when LCD is to the right of the ports)
#endif
        InvalidateRect(ghWnd, &present_ports_rect, FALSE);
        UpdateWindow( ghWnd );
    }
}

unsigned long fnGetValue(unsigned char *ptr, int iLen)
{
    unsigned long ulValue = 0;

    while (iLen--) {
        ulValue <<= 8;
        ulValue |= *ptr++;
    }

    return ulValue;
}


// Get the NIC to be used from the NIC.ini file
//
static int fnGetUserNIC(void)
{
    int iFileIni;
    int iNIC = -1;
#if _VC80_UPGRADE<0x0600
    iFileIni = _open("NIC.ini", (_O_BINARY | _O_RDWR));
#else
    _sopen_s(&iFileIni, "NIC.ini", (_O_BINARY | _O_RDWR), _SH_DENYWR, _S_IREAD);
#endif
    if (iFileIni >= 0) {
        signed char cNIC;
        if (_read(iFileIni, &cNIC, 1) > 0) {
            if (cNIC != 0) {
                cNIC -= '0';
                iNIC = cNIC;
            }
        }
        _close(iFileIni);        
    }
    return iNIC;
}

#include <sys/stat.h>

#ifdef ETH_INTERFACE
// Save preferred NIC
//
static void fnSaveUserSettings(void)
{
    int iFileIni;

#if _VC80_UPGRADE<0x0600
    iFileIni = _open("NIC.ini", (_O_BINARY | _O_TRUNC  | _O_CREAT | _O_RDWR ), _S_IREAD | _S_IWRITE );
#else
    _sopen_s(&iFileIni, "NIC.ini", (_O_BINARY | _O_TRUNC  | _O_CREAT | _O_RDWR ), _SH_DENYWR, _S_IREAD | _S_IWRITE );
#endif

    if (iFileIni >= 0) {
        signed char cNIC = (signed short)iUserNIC + '0';
        if (iUserNIC < 0) {
            cNIC = 0;
        }
        _write(iFileIni, &cNIC, 1);
        _close(iFileIni);        
    }
}
#endif


// Load user file paths or set defaults if it doesn't exist
//
static void fnLoadUserFiles()                                            // {19}
{
    int iFileIni;
    CHAR *filePath;
#if _VC80_UPGRADE<0x0600
    iFileIni = _open("userfiles.ini", (_O_BINARY | _O_RDWR));
#else
    _sopen_s(&iFileIni, "userfiles.ini", (_O_BINARY | _O_RDWR), _SH_DENYWR, _S_IREAD);
#endif
    if (iFileIni >= 0) {                                                 // if file exists
        filePath = szEthernetFileName;
        while (_read(iFileIni, filePath, 1) > 0) {
            if (*filePath++ == 0) {
                break;
            }
        }
        filePath = szPortFileName;
        while (_read(iFileIni, filePath, 1) > 0) {
            if (*filePath++ == 0) {
                break;
            }
        }
        _close(iFileIni);        
    }
    else {
        STRCPY(szEthernetFileName, "ethernet.eth");                      // default - for compatibility {24}
        STRCPY(szPortFileName,     "port.sim");                          // default - for compatibility {24}
    }
}

static void fnSaveUserFiles()
{
    int iFileIni;

#if _VC80_UPGRADE<0x0600
    iFileIni = _open("userfiles.ini", (_O_BINARY | _O_TRUNC  | _O_CREAT | _O_RDWR ), _S_IREAD | _S_IWRITE );
#else
    _sopen_s(&iFileIni, "userfiles.ini", (_O_BINARY | _O_TRUNC  | _O_CREAT | _O_RDWR ), _SH_DENYWR, _S_IREAD | _S_IWRITE );
#endif

    if (iFileIni >= 0) {
        _write(iFileIni, szEthernetFileName, (strlen(szEthernetFileName) + 1));
        _write(iFileIni, szPortFileName, (strlen(szPortFileName) + 1));
        _close(iFileIni);        
    }
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow )
{
    MSG msg = {0};
    HACCEL hAccelTable;
#ifdef SERIAL_INTERFACE
    int iRxSize;
    unsigned char ucRxBuffer[1000];
#endif
    unsigned char ucDoList[10000];                                       // {2}
    char *doList[2];                                                     // {1}
    int iAction;

    SYSTEMTIME st;

    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadString(hInstance, IDC_ETHERNET1, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    GetLocalTime(&st);
    doList[0] = (char *)&st;
    doList[1] = szProjectName;

    main(INITIALISE_OP_SYSTEM, doList);

    STRCAT(szTitle, " - ");
    STRCAT(szTitle, szProjectName);

#if defined SUPPORT_LCD
    LCDinit(LCD_LINES, LCD_CHARACTERS);
#elif defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE // {35}{65}
    LCDinit(0, 0);
#endif

    if (!InitInstance(hInstance, nCmdShow)) {
        return FALSE;
    }

    hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_ETHERNET1);


    doList[0] = (char *)ucDoList;
    memset(ucDoList, 0x00, sizeof(ucDoList));

    fnLoadUserFiles();                                                    // {19}

    while (!iQuit) {                                                      // main message loop
        if(::PeekMessage(&msg, NULL, 0,0,PM_NOREMOVE)) {
            GetMessage(&msg, NULL, 0, PM_NOREMOVE);
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

#ifdef SERIAL_INTERFACE
        if (sm_hComm0 != INVALID_HANDLE_VALUE) {
    #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastStat0 = 0;
            DWORD lpModemStat0;
            GetCommModemStatus(sm_hComm0, &lpModemStat0);
            if (lpModemStat0 != lpModemLastStat0) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat0;
                ptr[1] = (char *)&lpModemLastStat0;
                _main(MODEM_COM_0, ptr);
                lpModemLastStat0 = lpModemStat0;                         // set the new CTS state for reference
            }
    #endif
            while ((iRxSize = fnCheckRx(sm_hComm0, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, 0);     // if we have received something from the serial port (UART0), process it here
            }
        }
    #if NUMBER_SERIAL > 1
        if (sm_hComm1 != INVALID_HANDLE_VALUE) {
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastStat1 = 0;
            DWORD lpModemStat1;
            GetCommModemStatus(sm_hComm1, &lpModemStat1);
            if (lpModemStat1 != lpModemLastStat1) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat1;
                ptr[1] = (char *)&lpModemLastStat1;
                _main(MODEM_COM_1, ptr);
                lpModemLastStat1 = lpModemStat1;                         // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hComm1, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, 1);     // if we have received something from the serial port (UART1), process it here
            }
        }
    #endif
    #if NUMBER_SERIAL > 2
        if (sm_hComm2 != INVALID_HANDLE_VALUE) {
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastStat2 = 0;
            DWORD lpModemStat2;
            GetCommModemStatus(sm_hComm2, &lpModemStat2);
            if (lpModemStat2 != lpModemLastStat2) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat2;
                ptr[1] = (char *)&lpModemLastStat2;
                _main(MODEM_COM_2, ptr);
                lpModemLastStat2 = lpModemStat2;                         // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hComm2, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, 2);     // if we have received something from the serial port (UART2), process it here
            }
        }
    #endif
    #if NUMBER_SERIAL > 3
        if (sm_hComm3 != INVALID_HANDLE_VALUE) {                         // {9}
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastStat3 = 0;
            DWORD lpModemStat3;
            GetCommModemStatus(sm_hComm3, &lpModemStat3);
            if (lpModemStat3 != lpModemLastStat3) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat3;
                ptr[1] = (char *)&lpModemLastStat3;
                _main(MODEM_COM_3, ptr);
                lpModemLastStat3 = lpModemStat3;                         // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hComm3, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, 3);     // {30} if we have received something from the serial port (UART3), process it here
            }
        }
    #endif
    #if NUMBER_SERIAL > 4
        if (sm_hComm4 != INVALID_HANDLE_VALUE) {                         // {67}
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastStat4 = 0;
            DWORD lpModemStat4;
            GetCommModemStatus(sm_hComm4, &lpModemStat4);
            if (lpModemStat4 != lpModemLastStat4) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat4;
                ptr[1] = (char *)&lpModemLastStat4;
                _main(MODEM_COM_4, ptr);
                lpModemLastStat4 = lpModemStat4;                         // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hComm4, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, 4);     // if we have received something from the serial port (UART4), process it here
            }
        }
    #endif
    #if NUMBER_SERIAL > 5
        if (sm_hComm5 != INVALID_HANDLE_VALUE) {                         // {67}
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastStat5 = 0;
            DWORD lpModemStat5;
            GetCommModemStatus(sm_hComm5, &lpModemStat5);
            if (lpModemStat5 != lpModemLastStat5) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat5;
                ptr[1] = (char *)&lpModemLastStat5;
                _main(MODEM_COM_5, ptr);
                lpModemLastStat5 = lpModemStat5;                         // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hComm5, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, 5);     // if we have received something from the serial port (UART4), process it here
            }
        }
    #endif
    #if NUMBER_EXTERNAL_SERIAL > 0                                       // {41}
        if (sm_hCommExt_0 != INVALID_HANDLE_VALUE) {
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastExtStat0 = 0;
            DWORD lpModemStat;
            GetCommModemStatus(sm_hCommExt_0, &lpModemStat);
            if (lpModemStat != lpModemLastExtStat0) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat;
                ptr[1] = (char *)&lpModemLastExtStat0;
                _main(MODEM_EXT_COM_0, ptr);
                lpModemLastExtStat0 = lpModemStat;                       // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hCommExt_0, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, NUMBER_SERIAL); // if we have received something from the serial port (UART0), process it here
            }
        }
        if (sm_hCommExt_1 != INVALID_HANDLE_VALUE) {
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastExtStat1 = 0;
            DWORD lpModemStat;
            GetCommModemStatus(sm_hCommExt_1, &lpModemStat);
            if (lpModemStat != lpModemLastExtStat1) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat;
                ptr[1] = (char *)&lpModemLastExtStat1;
                _main(MODEM_EXT_COM_1, ptr);
                lpModemLastExtStat1 = lpModemStat;                       // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hCommExt_1, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, (NUMBER_SERIAL + 1)); // if we have received something from the serial port (UART0), process it here
            }
        }
        if (sm_hCommExt_2 != INVALID_HANDLE_VALUE) {
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastExtStat2 = 0;
            DWORD lpModemStat;
            GetCommModemStatus(sm_hCommExt_2, &lpModemStat);
            if (lpModemStat != lpModemLastExtStat2) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat;
                ptr[1] = (char *)&lpModemLastExtStat2;
                _main(MODEM_EXT_COM_2, ptr);
                lpModemLastExtStat2 = lpModemStat;                       // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hCommExt_2, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, (NUMBER_SERIAL + 2)); // if we have received something from the serial port (UART0), process it here
            }
        }
        if (sm_hCommExt_3 != INVALID_HANDLE_VALUE) {
        #ifdef SUPPORT_HW_FLOW
            static DWORD lpModemLastExtStat3 = 0;
            DWORD lpModemStat;
            GetCommModemStatus(sm_hCommExt_3, &lpModemStat);
            if (lpModemStat != lpModemLastExtStat3) {
                char *ptr[2];
                ptr[0] = (char *)&lpModemStat;
                ptr[1] = (char *)&lpModemLastExtStat3;
                _main(MODEM_EXT_COM_3, ptr);
                lpModemLastExtStat3 = lpModemStat;                       // set the new CTS state for reference
            }
        #endif
            while ((iRxSize = fnCheckRx(sm_hCommExt_3, ucRxBuffer)) != 0) {
                fnProcessRx(ucRxBuffer, (unsigned short)iRxSize, (NUMBER_SERIAL + 3)); // if we have received something from the serial port (UART0), process it here
            }
        }
    #endif
#endif

        if (iInputChange) {
            if (KEY_CHANGED & iInputChange) {
                fnProcessKeyChange();
            }
            if (INPUT_CHANGED & iInputChange) {
                fnProcessInputChange();
            }
            iInputChange = 0;
        }
#ifdef ETH_INTERFACE
        if (((iRxActivity > 0) != iLastRxActivity) || ((iTxActivity > 0) != iLastTxActivity)) {
            iLastRxActivity = (iRxActivity > 0);
            iLastTxActivity = (iTxActivity > 0);
            InvalidateRect(ghWnd, &rect_LAN_LED, FALSE);                 // redraw new LAN activity state
        }
        if (iRxActivity) {
            --iRxActivity;
        }
        if (iTxActivity) {
            --iTxActivity;
        }
#endif
        Sleep(TICK_RESOLUTION);                                          // we sleep to simulate the basic tick operation

#ifndef BOOT_LOADER
        fnDoPortSim(0, 0);                                               // if we are playing back port simulation script, do it here {8}
#endif
        
        if (iAction = _main(TICK_CALL, doList)) {
            unsigned char *doPtr = (unsigned char *)doList[0];           // windows has to perform some action(s) for the embedded system

            if (RESET_SIM_CARD == iAction) {
                break;
            }
            if (RESET_CARD_WATCHDOG == iAction) {
                break;
            }
#ifdef MULTISTART
            else if (RESTART == iAction) {
                _main(INITIALISE_OP_SYS_2, doList);                
            }
#endif

            while (*doPtr) {
                switch (*doPtr++) {
#ifdef SERIAL_INTERFACE
    #if NUMBER_EXTERNAL_SERIAL > 0                                       // {41}
        #ifdef SERIAL_PORT_EXT_0
                case OPEN_PC_EXT_COM0:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode));
                    if (sm_hCommExt_0 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hCommExt_0);                      // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hCommExt_0 = fnConfigureSerialInterface(SERIAL_PORT_EXT_0, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
        #endif
        #ifdef SERIAL_PORT_EXT_1
                case OPEN_PC_EXT_COM1:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr+1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr+1+sizeof(ulSpeed), sizeof(Mode));
                    if (sm_hCommExt_1 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hCommExt_1);                      // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hCommExt_1 = fnConfigureSerialInterface(SERIAL_PORT_EXT_1, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
        #endif
        #ifdef SERIAL_PORT_EXT_2
                case OPEN_PC_EXT_COM2:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode));
                    if (sm_hCommExt_2 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hCommExt_2);                      // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hCommExt_2 = fnConfigureSerialInterface(SERIAL_PORT_EXT_2, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
        #endif
        #ifdef SERIAL_PORT_EXT_3
                case OPEN_PC_EXT_COM3:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode));
                    if (sm_hCommExt_3 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hCommExt_3);                      // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hCommExt_3 = fnConfigureSerialInterface(SERIAL_PORT_EXT_3, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
        #endif
    #endif
                case OPEN_PC_COM0:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode)); // {26}
                    if (sm_hComm0 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hComm0);                          // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hComm0 = fnConfigureSerialInterface(SERIAL_PORT_0, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
                case OPEN_PC_COM1:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode)); // {26}
                    if (sm_hComm1 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hComm1);                          // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hComm1 = fnConfigureSerialInterface(SERIAL_PORT_1, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
    #ifdef SERIAL_PORT_2
                case OPEN_PC_COM2:
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode)); // {26}
                    if (sm_hComm2 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hComm2);                          // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hComm2 = fnConfigureSerialInterface(SERIAL_PORT_2, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
    #endif
    #ifdef SERIAL_PORT_3
                case OPEN_PC_COM3:                                       // {9}
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode)); // {26}
                    if (sm_hComm3 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hComm3);                          // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hComm3 = fnConfigureSerialInterface(SERIAL_PORT_3, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
    #endif
    #ifdef SERIAL_PORT_4
                case OPEN_PC_COM4:                                       // {67}
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode)); // {26}
                    if (sm_hComm4 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hComm4);                          // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hComm4 = fnConfigureSerialInterface(SERIAL_PORT_4, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
    #endif
    #ifdef SERIAL_PORT_5
                case OPEN_PC_COM5:                                       // {67}
                    {
                    unsigned long ulSpeed = fnGetValue(doPtr + 1, sizeof(ulSpeed));
                    UART_MODE_CONFIG Mode = (unsigned short)fnGetValue(doPtr + 1 + sizeof(ulSpeed), sizeof(Mode)); // {26}
                    if (sm_hComm5 != INVALID_HANDLE_VALUE) {
                        CloseHandle(sm_hComm5);                          // if we have an open port we want to reconfigure it - so close it
                    }
                    sm_hComm5 = fnConfigureSerialInterface(SERIAL_PORT_5, ulSpeed, Mode); // try to open com since the embedded system wants to use it
                    }
                    break;
    #endif

                case MODEM_SIGNAL_CHANGE:                                // {7}
                    {
                        unsigned char ucComPort = (unsigned char)fnGetValue(doPtr + 1, 1); // port to be changed
                        unsigned char ucRTS_enable = (unsigned char)fnGetValue(doPtr + 2, 1);// state
                        DCB dcb;
                        HANDLE sm_hComm;

                        switch (ucComPort) {
                        case 0:
                            sm_hComm = sm_hComm0;
                            break;
                        case 1:
                            sm_hComm = sm_hComm1;
                            break;
                        case 2:
                            sm_hComm = sm_hComm2;
                            break;
                        case 3:
                            sm_hComm = sm_hComm3;                        // {9}
                            break;
                        }
                        if (sm_hComm != INVALID_HANDLE_VALUE) {
                            GetCommState(sm_hComm, &dcb);                // get the present com port settings
                            if (ucRTS_enable != 0) {
                                dcb.fRtsControl = 1;
                            }
                            else {
                                dcb.fRtsControl = 0;
                            }
                            SetCommState(sm_hComm, &dcb);                // set the new state
                        }
                    }
                    break;

                case SEND_PC_COM0:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data UART 0 over COM
                    fnSendSerialMessage(sm_hComm0, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_COM1:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data UART 1 over COM
                    fnSendSerialMessage(sm_hComm1, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_COM2:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data UART 2 over COM
                    fnSendSerialMessage(sm_hComm2, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_COM3:                                       // {9}
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data UART 3 over COM
                    fnSendSerialMessage(sm_hComm3, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_COM4:                                       // {67}
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data UART 4 over COM
                    fnSendSerialMessage(sm_hComm4, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_COM5:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data UART 5 over COM
                    fnSendSerialMessage(sm_hComm5, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

    #if NUMBER_EXTERNAL_SERIAL > 0                                       // {41}
                case SEND_PC_EXT_COM0:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data Ext UART 0 over COM
                    fnSendSerialMessage(sm_hCommExt_0, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_EXT_COM1:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data Ext UART 1 over COM
                    fnSendSerialMessage(sm_hCommExt_1, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_EXT_COM2:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data Ext UART 2 over COM
                    fnSendSerialMessage(sm_hCommExt_2, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;

                case SEND_PC_EXT_COM3:
                    {
                    unsigned long ulLength = fnGetValue(doPtr + 1, sizeof(ulLength)); // we send embedded system serial data Ext UART 3 over COM
                    fnSendSerialMessage(sm_hCommExt_3, (const void *)fnGetValue(doPtr + 1 + sizeof(ulLength), sizeof(const void *)), ulLength);
                    }
                    break;
    #endif

                case SET_COM_BREAK_0:
                    SetCommBreak(sm_hComm0);
                    break;

                case CLR_COM_BREAK_0:
                    ClearCommBreak(sm_hComm0);
                    break;

                case SET_COM_BREAK_1:
                    SetCommBreak(sm_hComm1);
                    break;

                case CLR_COM_BREAK_1:
                    ClearCommBreak(sm_hComm1);
                    break;

                case SET_COM_BREAK_2:
                    SetCommBreak(sm_hComm2);
                    break;

                case CLR_COM_BREAK_2:
                    ClearCommBreak(sm_hComm2);
                    break;

                case SET_COM_BREAK_3:                                    // {9}
                    SetCommBreak(sm_hComm3);
                    break;

                case CLR_COM_BREAK_3:                                    // {9}
                    ClearCommBreak(sm_hComm3);
                    break;
#endif
                case IP_CHANGE:                                          // update IP configuration
                    {
                        unsigned char *ucInputPointer = doPtr;           // {42}
                        unsigned char ucStrLength = (unsigned char)fnGetValue(ucInputPointer++, sizeof(ucStrLength));
                        RECT ip_string;
                        char *ptrIpConfig = &szIPDetails[3];
                        memset(&szIPDetails[3], ' ', (sizeof(szIPDetails) - 4)); // {68}
                        szIPDetails[sizeof(szIPDetails) - 1] = 0;
                        while (ucStrLength--) {
                            /*if (ucStrLength == 0) {
                                fnGetValue(ucInputPointer++, 1);         // {68}
                            }
                            else {*/
                                *ptrIpConfig++ = (unsigned char)fnGetValue(ucInputPointer++, 1);
                            //}
                            
                        }
                        ip_string.bottom = 40;                           // {39}
                        ip_string.left = 0;
                        ip_string.right = 450;                           // {68}
                        ip_string.top = 1;
                        InvalidateRect(ghWnd, &ip_string, FALSE);        // ensure IP text is updated
                    }
                    break;

                case DISPLAY_PORT_CHANGE:
                    {
                        unsigned char ucNumberOfPorts = (unsigned char)fnGetValue(doPtr, sizeof(ucNumberOfPorts));
                        unsigned long ulPort, ulPortDDR, ulPeripheral;
                        unsigned short usPortOffset = 1;
                        unsigned char ucPortNumber = 0;
                      //ucNumberOfPorts /= (3 * sizeof(unsigned long));  // {51}
                        while (ucNumberOfPorts--) {                      // for each port
                            ulPort = fnGetValue(doPtr + usPortOffset, sizeof(ulPort));
                            usPortOffset += sizeof(ulPort);
                            ulPortDDR = fnGetValue(doPtr + usPortOffset, sizeof(ulPort));
                            usPortOffset += sizeof(ulPortDDR);
                            ulPeripheral = fnGetValue(doPtr + usPortOffset, sizeof(ulPeripheral));
                            usPortOffset += sizeof(ulPeripheral);
                            fnPortDisplay(ulPort, ulPortDDR, ulPeripheral, ucPortNumber++);
                        }
                        doPtr += ((*doPtr * 3 * sizeof(unsigned long)) + 1); // {51}
                        continue;
                    }
                    break;

                default:
                    memset(ucDoList, 0x00, sizeof(ucDoList));
                    break;
                }
                doPtr += (*doPtr + 1);
            }
            memset(ucDoList, 0x00, sizeof(ucDoList));
        }
#ifdef ETH_INTERFACE                                                     // {10}
        fnDoEthereal(0, 0);                                              // {18} if we are playing back ethereal files, inject frames here
#endif
#ifdef USB_INTERFACE
        fnInjectUSB(0,0,0);                                              // inject any queued USB data
#endif
    }

    if (!iQuit) {                                                        // was break due to reset?
        if (iAction == RESET_CARD_WATCHDOG) {
            DialogBox(hInst, (LPCTSTR)IDD_WATCHDOG, ghWnd, (DLGPROC)CardWatchdogReset);
        }
        else if (iAction == RESET_SIM_CARD) {
            DialogBox(hInst, (LPCTSTR)IDD_RESET, ghWnd, (DLGPROC)CardReset);
        }
    }

    _main(EXITING_CALL, 0);                                              // save the present FLASH file system to a file so that it can be returned on next use
#ifdef ETH_INTERFACE                                                     // {10}
    fnSaveUserSettings();
#endif
    fnSaveUserFiles();                                                   // {19}
    return msg.wParam;
}

static void fnProcessRx(unsigned char *ptrData, unsigned short usLength, int iPort)
{
    char *ptr[2];

    ptr[0] = (char *)&usLength;
    ptr[1] = (char *)ptrData;

    switch (iPort) {
    case 0:
        _main(RX_COM0, ptr);
        break;

    case 1:
        _main(RX_COM1, ptr);
        break;
#if NUMBER_SERIAL > 2
    case 2:
        _main(RX_COM2, ptr);
        break;
#endif
#if NUMBER_SERIAL > 3
    case 3:                                                              // {9}
        _main(RX_COM3, ptr);
        break;
#endif
#if NUMBER_SERIAL > 4
    case 4:                                                              // {67}
        _main(RX_COM4, ptr);
        break;
#endif
#if NUMBER_SERIAL > 5
    case 5:                                                              // {67}
        _main(RX_COM5, ptr);
        break;
#endif
#if NUMBER_EXTERNAL_SERIAL > 0                                           // {41}
    case NUMBER_SERIAL:
        _main(RX_EXT_COM0, ptr);
        break;

    case (NUMBER_SERIAL + 1):
        _main(RX_EXT_COM1, ptr);
        break;

    case (NUMBER_SERIAL + 2):
        _main(RX_EXT_COM2, ptr);
        break;

    case (NUMBER_SERIAL + 3):
        _main(RX_EXT_COM3, ptr);
        break;
#endif
    }
}

// UART injection for script based simulator                             {8}
//
extern void fnInjectSerial(unsigned char *ptrInputData, unsigned short usLength, int iPortNumber)
{
    if (ptrInputData == 0) {                                             // not data injection
        char *ptr[2];
        ptr[0] = (char *)iPortNumber;
        ptr[1] = (char *)0;
        switch (usLength) {
        case UART_BREAK_CONDITION:                                       // break condition
            _main(SIM_UART_BREAK, ptr);
            break;
        case UART_CTS_ACTIVATED:                                         // CTS change - active
            ptr[1] = (char *)MS_CTS_ON;
        case UART_CTS_NEGATED:                                           // CTS change - disabled
            _main(SIM_UART_CTS, ptr);
            break;
        }
        return;
    }

    if (usLength != 0) {
        fnProcessRx(ptrInputData, usLength, iPortNumber);
    }
}

static void fnProcessRxSPI(unsigned char *ptrData, unsigned short usLength, int iPort)
{
    char *ptr[2];

    ptr[0] = (char *)&usLength;
    ptr[1] = (char *)ptrData;

    switch (iPort) {
    case 0:
        _main(RX_SPI0, ptr);
        break;

    case 1:
        _main(RX_SPI1, ptr);
        break;
    }
}


// SPI injection for script based simulator                              {8}
//
extern void fnInjectSPI(unsigned char *ptrInputData, unsigned short usLength, int iPortNumber)
{
    if (usLength != 0) {
        fnProcessRxSPI(ptrInputData, usLength, iPortNumber);
    }
}

// Inject a simulated USB OUT message                                    {15}
//
extern void fnInjectUSB(unsigned char *ptrInputData, unsigned short usLength, int iPortNumber)
{
    char *ptr[3];
    ptr[0] = (char *)iPortNumber;
    ptr[1] = (char *)usLength;
    ptr[2] = (char *)ptrInputData;
    _main(SIM_USB_OUT, ptr);
}

extern void fnsetKeypadState(char **ptr);

static void fnProcessKeyChange(void)
{
#ifdef SUPPORT_KEY_SCAN 
    char *ptr[1];

    fnsetKeypadState(ptr);

    _main(KEY_CHANGE, ptr);
#endif
}


static int iChangedPort;
static int iChangedBit;

static void fnProcessInputChange(void)
{
    char *ptr[2];

    ptr[0] = (char *)&iChangedPort;
    ptr[1] = (char *)&iChangedBit;

    if (iShiftPressed != 0) {                                            // {11}
        _main(INPUT_TOGGLE_NEG, ptr);
    }
    else {
        _main(INPUT_TOGGLE, ptr);
    }
}

static void fnSimPortInputToggle(int iPort, int iPortBit)
{
    iChangedPort = iPort;
    iChangedBit  = iPortBit;
}

extern void fnInjectPortValue(int iPort, unsigned long ulMask, unsigned long ulValue) // {8}
{
#if defined _M5223X                                                      // {25}
    unsigned long ulPortInputs = ((~ulPortFunction[iPort] | ulPortPeripheral[iPort]) & ulMask); // handle only ports which are inputs or peripherals
    unsigned long ulBit = 0x00000080;
    #if !defined _M520X && !defined _M523X                               // {53}
    switch (iPort) {
    case _PORT_TA:
    case _PORT_TC:
    #if !defined _M5225X
    case _PORT_TD:
    #endif
    case _PORT_UA:
    #if defined _M52XX_SDRAM                                             // {50}
    case _PORT_TB:
    #else
    case _PORT_AS:
    case _PORT_UB:
    case _PORT_UC:
    #endif
        ulPortInputs &= 0x0f;
        ulBit >>= 4;                                                     // 4 bit port
        break;
    }
    #endif
#elif defined _HW_SAM7X
    #if defined _HW_SAM7S || defined _HW_SAM7SE                          // {48}{57}
    unsigned long ulPortInputs = ((~ulPortFunction[iPort] | ulPortPeripheral[iPort]) & 0xffffffff); // handle only ports which are inputs or peripherals
    unsigned long ulBit = 0x80000000;
    #else
    unsigned long ulPortInputs = ((~ulPortFunction[iPort] | ulPortPeripheral[iPort]) & 0x7fffffff); // handle only ports which are inputs or peripherals
    unsigned long ulBit = 0x40000000;
    #endif
#elif defined _LM3SXXXX
    unsigned long ulPortInputs = ((~ulPortFunction[iPort] | ulPortPeripheral[iPort]) & 0xff); // handle only ports which are inputs or peripherals
    unsigned long ulBit = 0x80;
#else
    unsigned long ulPortInputs = ((~ulPortFunction[iPort] | ulPortPeripheral[iPort]) & 0xffffffff); // handle only ports which are inputs or peripherals
    unsigned long ulBit = 0x80000000;
#endif
    int iPortBit = 0;

    while (ulPortInputs) {
        if (ulBit & ulMask) {
            if ((ulPortStates[iPort] & ulBit) != (ulValue & ulBit)) {    // if this bit is to be changed
                fnSimPortInputToggle(iPort, iPortBit);
                fnProcessInputChange();
              //ulPortStates[iPort] ^= ulBit;                            // update reference value locally - {59} don't update so that it causes a refresh
            }
        }
        iPortBit++;
        ulPortInputs &= ~ulBit;
        ulBit >>= 1;
    }
}

#ifdef ETH_INTERFACE                                                     // {10}
extern void fnInjectFrame(unsigned char *ptrData, unsigned short usLength)
{
    char *ptr[3];

    ptr[0] = ( char *)&usLength;
    ptr[1] = ( char *)ptrData;
    ptr[2] = 0;

    if (usLength <= MAX_ETHERNET_BUFFER) {
        _main(RX_ETHERNET, ptr);                                            // send this to the ethernet input
        if (ptr[2]) {
            iRxActivity = 2;                                                // cause activity LED blinking
        }
    }
}
#endif

ATOM MyRegisterClass( HINSTANCE hInstance )
{
    WNDCLASSEX wcex;

    wcex.cbSize = sizeof(WNDCLASSEX); 

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = (WNDPROC)WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, (LPCTSTR)IDI_ETHERNET1);
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = (LPCSTR)IDC_ETHERNET1;
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

    return RegisterClassEx(&wcex);
}


BOOL InitInstance( HINSTANCE hInstance, int nCmdShow )
{
    HWND hWnd;
    RECT rt = {0, 0, 0, 0};
#if defined SUPPORT_LCD || defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE || defined (SUPPORT_KEY_SCAN) // {35}{65}
    int iLCD_Bottom = 0;
#endif

    rt.right = UTASKER_WIN_WIDTH;
    rt.bottom = UTASKER_WIN_HEIGHT;

#if defined SUPPORT_LCD || defined SUPPORT_GLCD  || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR || defined SLCD_FILE // {35}{65}
    #ifdef _M5225X
    iLCD_Bottom = fnInitLCD(rt, UTASKER_WIN_HEIGHT, (UTASKER_WIN_WIDTH + 70));
    #else
    iLCD_Bottom = fnInitLCD(rt, UTASKER_WIN_HEIGHT, UTASKER_WIN_WIDTH);
    #endif
#endif
#ifdef SUPPORT_KEY_SCAN
    fnInitKeyPad(rt, UTASKER_WIN_WIDTH, iLCD_Bottom);
#endif 

    hInst = hInstance;
    hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, rt.right, rt.bottom, NULL, NULL, hInstance, NULL);

    if (!hWnd) {
        return FALSE;
    }

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    ghWnd = hWnd;
    return TRUE;
}

static OPENFILENAME ofn;

// Select the file to be opened
//
static BOOL fnOpenDialog(HWND hWnd, int iType)
{
    static CRITICAL_SECTION cs;
    BOOL bInitialised = 0;
    BOOL bReturn = 0;
    memset(&ofn, 0, sizeof(OPENFILENAME));
    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = hWnd;
    ofn.nMaxFile  = MAX_PATH;
    ofn.nMaxFileTitle  = MAX_PATH;
    ofn.nFilterIndex = 1;
    ofn.hInstance = hInst;
    ofn.Flags = OFN_NOCHANGEDIR;

    if (bInitialised == 0) {
        InitializeCriticalSection(&cs);                                  // start of critical region
        bInitialised = 1;
    }
    EnterCriticalSection(&cs);                                           // {37} protect from task switching
    switch (iType) {
    case 0:
        ofn.lpstrInitialDir = "Ethereal";
        ofn.lpstrFile   = szEthernetFileName;
        ofn.lpstrFilter = szEthernet;
        ofn.lpstrDefExt = TEXT ("eth");
        bReturn = GetOpenFileName(&ofn);
        break;
    case 1:
        ofn.lpstrInitialDir = "Simulation Files";
        ofn.lpstrFile   = szPortFileName;
        ofn.lpstrFilter = szPortSim;
        ofn.lpstrDefExt = TEXT ("sim");
        bReturn = GetOpenFileName(&ofn);
        break;
    }
    LeaveCriticalSection(&cs);
    return bReturn;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
#ifdef SUPPORT_TOUCH_SCREEN                                              // {56}
    static int iPenDown = 0;
#endif
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;
    RECT rt;
    LPRECT rect = &rt;

    switch( message ) 
    {
        case WM_CREATE: 
#ifdef ETH_INTERFACE                                                     // {10}
            iUserNIC = fnGetUserNIC();
            fnWinPcapSelectLAN(iUserNIC);                                // select the NIC according to the user setting         
#endif
            hPen = (HPEN)CreatePen(0,0, RGB(180,180,180));               // create a pen with the colour for drawing the LAN LEDs {4}
            hGreenBrush = (HBRUSH)CreateSolidBrush(RGB(0,255,0));
            hRedBrush =  (HBRUSH)CreateSolidBrush(RGB(220,0,0));
#ifdef USB_INTERFACE
            hRedPen = (HPEN)CreatePen(0,(USB_CIRCLE_RADIUS/2), RGB(220,0,0));
            hGrayBrush =  (HBRUSH)CreateSolidBrush(RGB(140,140,140));
            hGrayPen = (HPEN)CreatePen(0,(USB_CIRCLE_RADIUS/2), RGB(140,140,140));
#endif
            break;

        case WM_SIZE:
            break;

        case WM_MOUSEMOVE:
#ifdef SUPPORT_TOUCH_SCREEN                                              // {56}
            if (iPenDown != 0) {
                if (fnPenDown(LOWORD(lParam), HIWORD(lParam), iPenDown) != 0) {  // check whether pen stays down on touch screen
                    SetCursor(LoadCursor(NULL, IDC_UPARROW));
                }
                else {
                    iPenDown = 0;
                }
                break;
            }
#endif
#ifdef SUPPORT_KEY_SCAN
            if (fnCheckKeypad(LOWORD(lParam), HIWORD(lParam), 3)) {
                SetCursor(LoadCursor(NULL, IDC_CROSS));
            }
#endif
            if (fnToggleInput(LOWORD(lParam), HIWORD(lParam), POSSIBLE_PORT)) {
                fnToggleInput(LOWORD(lParam), HIWORD(lParam), PORT_LOCATION);
            }
            else if (iLastPort != iPrevPort) {                           // {36} check whether mouse moves away from port area
                iPrevPort = iLastPort;
                RECT port_detail = present_ports_rect;
                port_detail.top = (port_detail.bottom - 70);             // just update the port detail line
                InvalidateRect(ghWnd, &port_detail, FALSE);              // update ports to see now details
            }
            if ((iLastPort != iPrevPort) || (iLastBit != iPrevBit)) {    // change of port bit detected
                iPrevPort = iLastPort;
                iPrevBit = iLastBit;
                if (iLastPort >= 0) {
                    RECT port_detail = present_ports_rect;
                    port_detail.top = (port_detail.bottom - 70);         // just update the port detail line
                    InvalidateRect(ghWnd, &port_detail, FALSE);          // update ports to see now details
                }
            }
            break;


        case WM_LBUTTONDOWN:
            iInputChange = fnToggleInput(LOWORD(lParam), HIWORD(lParam), TOGGLE_PORT);
#ifdef SUPPORT_TOUCH_SCREEN                                              // {56}
            if (fnPenDown(LOWORD(lParam), HIWORD(lParam), 0) != 0) {     // check whether pen down on touch screen
                SetCursor(LoadCursor(NULL, IDC_UPARROW));
                iPenDown = 1;
                break;
            }
#endif
        case WM_RBUTTONDOWN:
#ifdef SUPPORT_KEY_SCAN
            if (message == WM_RBUTTONDOWN) {
                iInputChange |= (wmEvent = fnCheckKeypad(LOWORD(lParam), HIWORD(lParam), 2)); // toggle
            }
            else {
                iInputChange |= (wmEvent = fnCheckKeypad(LOWORD(lParam), HIWORD(lParam), 1)); // set
            }
            if (wmEvent) {
                SetCursor(LoadCursor(NULL, IDC_CROSS));
            }
#endif
            break;


        case WM_LBUTTONUP:
#ifdef SUPPORT_TOUCH_SCREEN                                              // {56}
            if (iPenDown != 0) {
                fnPenDown(LOWORD(lParam), HIWORD(lParam), -1);           // pen removed
            }
            iPenDown = 0;
#endif
#ifdef SUPPORT_KEY_SCAN
            iInputChange |= wmEvent = fnCheckKeypad(LOWORD(lParam), HIWORD(lParam), 0);
            if (wmEvent) {
                SetCursor(LoadCursor(NULL, IDC_CROSS));
            }
#endif
            break;

        case WM_KEYDOWN:
            if (0x10 == wParam) {                                        // shift key down {11}
                iShiftPressed = 1;
            }
#ifdef SUPPORT_KEY_SCAN
            else if (VK_ESCAPE == wParam) {                              // ESC key pressed
                iInputChange = fnCheckKeypad(-1, -1, 0);
            }
#endif
            break;

        case WM_KEYUP:
            if (0x10 == wParam) {                                        // shift key up {11}
                iShiftPressed = 0;
            }
            break;


        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            switch( wmId ) 
            {
                case IDM_ABOUT:
                    DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
                    break;

                case IDM_EXIT:
                    DestroyWindow( hWnd );
                    break;

                case ID_TEST_RX:
                    _main(SIM_TEST_RX_0, 0);
                    break;

                case ID_TEST_R1:
                    _main(SIM_TEST_RX_1, 0);
                    break;

                case ID_TEST_R2:
                    _main(SIM_TEST_RX_2, 0);
                    break;

                case ID_TEST_R3:                                         // {9}
                    _main(SIM_TEST_RX_3, 0);
                    break;

                case ID_TEST_R4:                                         // {41}
                    _main(SIM_TEST_RX_4, 0);
                    break;

                case ID_TEST_R5:
                    _main(SIM_TEST_RX_5, 0);
                    break;

                case ID_TEST_EXT_R0:
                    _main(SIM_TEST_EXT_RX_0, 0);
                    break;

                case ID_TEST_EXT_R1:
                    _main(SIM_TEST_EXT_RX_1, 0);
                    break;

                case ID_TEST_EXT_R2:
                    _main(SIM_TEST_EXT_RX_2, 0);
                    break;

                case ID_TEST_EXT_R3:
                    _main(SIM_TEST_EXT_RX_3, 0);
                    break;

                case ID_TEST_ENUMERATION:                                // {6}
                    _main(SIM_TEST_ENUM, 0);
                    break;

                case ID_USB_DISCONNECT:                                  // {13}
                    _main(SIM_TEST_DISCONNECT, 0);
                    break;

                case ID_USB_CONNECTLOWSPEEDDEVICE:                       // {17}
                    _main(SIM_TEST_LOWSPEED_DEVICE, 0);
                    break;

                case ID_USB_CONNECTFULLSPEEDDEVICE:                      // {17}
                    _main(SIM_TEST_FULLSPEED_DEVICE, 0);
                    break;

                case ID_PORTSIMULATOR_OPENSCRIPT:                        // {8}
                    if (fnOpenDialog(hWnd, 1) == 0) {                    // {18} select the file to be opened
                        break;                                           // file not found or user has quit selection
                    }
                    // fall through to simulate
                case ID_PORTSIM_REPEATLASTSCRIPT:                        // {18}
#ifndef BOOT_LOADER
                    fnDoPortSim(1, szPortFileName);                      // open a port script file and play it back
#endif
                    break;

#ifdef ETH_INTERFACE                                                     // {10}
                case ID_ETHEREAL:
                    if (fnOpenDialog(hWnd, 0) == 0) {                    // {18} select the file to be opened
                        break;                                           // file not found or user has quit selection
                    }
                    // fall through to start simulation
                case ID_WIRESHARK_REPLAYLASTFILE:                        // {18}                                                    
                    fnWinPcapStopLink(hWnd);                             // we close any open NIC so that the two sources do not conflict with another
                    fnDoEthereal(1, szEthernetFileName);                 // we load an ethereal file and play it back through our code
#endif
                    break;
#ifdef SLCD_FILE                                                         // {65}
                case ID_SLCD_SHOWALLSEGMENTS:                            // turn on all SLCD segments to verify SLCD display
                    LCDinit(2, 0);
                    break;

                case ID_SLCD_RELEASESEGMENTS:                            // leave show all segments mode
                    LCDinit(1, 0);
                    break;
#endif
                case ID_LAN_NIC:
#ifdef ETH_INTERFACE                                                     // {10}
                    DialogBox(hInst, (LPCTSTR)IDD_NIC, hWnd, (DLGPROC)SetNIC);
#endif
                    break;

                default:
                    return DefWindowProc( hWnd, message, wParam, lParam );
            }
            break;

        case WM_PAINT:
            if (GetUpdateRect(hWnd, rect, FALSE)) {
                hdc = BeginPaint (hWnd, &ps);
                fnDoDraw(hWnd, hdc, ps, rt);                             // we do user specific stuff here
                EndPaint( hWnd, &ps );
            }
            break;

        case WM_DESTROY:
            DeleteObject(hPen);                                          // {4} destroy objects on termination
            DeleteObject(hGreenBrush);
            DeleteObject(hRedBrush); 
            DeleteObject(hGrayBrush);
            iQuit = 1;
            PostQuitMessage( 0 );
            break;

        default:
            return DefWindowProc( hWnd, message, wParam, lParam );
   }
   return 0;
}

LRESULT CALLBACK About( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    switch( message )
    {
        case WM_INITDIALOG:
                return TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;
    }
    return FALSE;
}

LRESULT CALLBACK CardReset( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    switch( message )
    {
        case WM_INITDIALOG:
                return TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;
    }
    return FALSE;
}

LRESULT CALLBACK CardWatchdogReset( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    switch( message )
    {
        case WM_INITDIALOG:
                return TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;
    }
    return FALSE;
}

#ifdef ETH_INTERFACE                                                     // {10}
LRESULT CALLBACK SetNIC( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    HWND pulldown;
    static int iactive = 0;
    static int iNewSelection = 0;

    switch( message ) {
        case WM_INITDIALOG:                                              // add the NICs to the drop down list, then select the active one
            pulldown = GetDlgItem(hDlg, IDC_COMBO1);
            iNewSelection = iactive = fnShowNICs(pulldown);
            if (iactive < 0) {
                SendMessage(pulldown, CB_SETCURSEL, 0, (LPARAM) 0); 
            }
            else {
                SendMessage(pulldown, CB_SETCURSEL, iactive+1, (LPARAM) 0);          
            }
            SetFocus(pulldown);
            return TRUE;

        case WM_COMMAND:
            switch (LOWORD(wParam)) {
            case IDC_COMBO1:
                switch (HIWORD(wParam)) {
                case CBN_SELCHANGE:
                   pulldown = GetDlgItem(hDlg, IDC_COMBO1);
                   iNewSelection = SendMessage(pulldown, CB_GETCURSEL, 0, (LPARAM) 0); 
                   iNewSelection--;
                   break;
                }
                break;

            default:
                switch (LOWORD(wParam)) {
                case IDCANCEL:
                    EndDialog(hDlg, LOWORD(wParam));
                    return TRUE;

                case IDOK: 
                    if (iNewSelection != iactive) {
                        if (iUserNIC < 0) {
                            iactive = iNewSelection;
                            fnWinPcapClose();                            // close present adapter
                            fnWinPcapSelectLAN(iNewSelection);
                            fnWinPcapOpenAdapter();
                        }
                        iUserNIC = iNewSelection;
                    }
                    EndDialog(hDlg, LOWORD(wParam));
                    return TRUE;
                }
                break;
            }
            break;
    }
    return FALSE;
}
#endif

#ifdef ETH_INTERFACE                                                     // {10}
extern void fnReactivateNIC(void)
{
    fnWinPcapSelectLAN(iUserNIC);
    fnWinPcapOpenAdapter();
}
#endif

#ifdef SERIAL_INTERFACE

static DWORD fnCheckRx(HANDLE m_hComm, unsigned char *pData)
{
    DWORD dwBytesRead = 0;
    _OVERLAPPED ol = {0};

    ReadFile(m_hComm, pData, 100, &dwBytesRead, &ol);

    return dwBytesRead;
}


static void fnSetComPort(HANDLE m_hComm, DWORD dwBaud, UART_MODE_CONFIG Mode) // {26}
{
    DCB dcb;

    GetCommState(m_hComm, &dcb);                                         // get the present com port settings

    if (dwBaud < 250) {                                                  // often the speed can not be set accurately enough for windows to understand it - se we help out a bit here
        dwBaud = 110;
    }
    else if (dwBaud <400) {
        dwBaud = 300;
    }
    else if (dwBaud < 800) {
        dwBaud = 600;
    }
    else if (dwBaud < 1400) {
        dwBaud = 1200;
    }
    else if (dwBaud < 2800) {
        dwBaud = 2400;
    }
    else if (dwBaud < 5400) {
        dwBaud = 4800;
    }
    else if (dwBaud < 12000) {
        dwBaud = 9600;
    }
    else if (dwBaud < 16000) {
        dwBaud = 14400;
    }
    else if (dwBaud < 22000) {
        dwBaud = 19200;
    }
    else if (dwBaud < 44000) {
        dwBaud = 38400;
    }
    else if (dwBaud < 64000) {
        dwBaud = 57600;
    }
    else {
        dwBaud = 115200;
    }

    dcb.BaudRate = dwBaud;                                               // set the baud rate

    if (Mode & RS232_EVEN_PARITY) {
        dcb.Parity = EVENPARITY;
    }
    else if (Mode & RS232_ODD_PARITY) {
        dcb.Parity = ODDPARITY;
    }
    else {
        dcb.Parity = NOPARITY;
    }
    if (CHAR_7 & Mode) {
        dcb.ByteSize = 7;
    }
    else {
        dcb.ByteSize = 8;
    }

    if (TWO_STOPS & Mode) {
        dcb.StopBits = TWOSTOPBITS; 
    }
    else if (ONE_HALF_STOPS & Mode) {
        dcb.StopBits = ONE5STOPBITS;
    }
    else {
        dcb.StopBits = ONESTOPBIT;
    }

    dcb.fDsrSensitivity = FALSE;                                         // setup the flow control 

    dcb.fOutxCtsFlow = FALSE;
    dcb.fOutxDsrFlow = FALSE;
    dcb.fOutX = FALSE;
    dcb.fInX = FALSE;

    if (Mode & RTS_CTS) {
        dcb.fOutxCtsFlow = TRUE;                                         // enable flow control on the COM port for higher accuracy
        dcb.fRtsControl = 0;                                             // disable the RTS line when starting with HW flow control
    }

    SetCommState(m_hComm, &dcb);                                         // set the new state
}

static HANDLE fnConfigureSerialInterface(char cCom, DWORD com_port_speed, UART_MODE_CONFIG Mode) // {26}
{
    // We send simulation messages over serial interface and receive from serial interface.
    // Call CreateFile to open up the comms port
    char cPort[60];
    char cComPort[4] = {0};
    HANDLE m_hComm;
    COMMTIMEOUTS Timeouts;
    #ifdef SIM_COM_EXTENDED                                              // {29}
    unsigned char ucCom = (unsigned char)cCom;
    if (ucCom == 0x00) {
        return INVALID_HANDLE_VALUE;
    }
    STRCPY(cPort, "\\\\.\\COM");
    if (ucCom >= 10) {
        unsigned char ucHundreds = (ucCom/100);
        if (ucHundreds != 0) {            
            unsigned char ucTens;
            ucCom -= (ucHundreds * 100);
            ucTens = (ucCom/10);
            ucCom -= (ucTens * 10);
            cComPort[0] = (ucHundreds + '0');
            cComPort[1] = (ucTens + '0');
            cComPort[2] = (ucCom + '0');
            cComPort[3] = 0;
        }
        else {
            unsigned char ucTens = (ucCom/10);
            ucCom -= (ucTens * 10);
            cComPort[0] = (ucTens + '0');
            cComPort[1] = (ucCom + '0');
            cComPort[2] = 0;
        }
    }
    else {
        cComPort[0] = (ucCom + '0');
        cComPort[1] = 0;
    }
    STRCAT(cPort, cComPort);
    #else
    STRCPY(cPort, "\\\\.\\COM");
    cComPort[0] = cCom;
    cComPort[1] = 0;
    STRCAT(cPort, cComPort);
    #endif
    m_hComm = CreateFile(cPort, (GENERIC_READ | GENERIC_WRITE), 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED , NULL);
    if (m_hComm == INVALID_HANDLE_VALUE) {
        return m_hComm;
    }

    if (com_port_speed > 115200) {                                       // limit COM speed to max supported by interface
        com_port_speed = 115200;
    }
    fnSetComPort(m_hComm, com_port_speed, Mode);                         // we have successfully opened the com port as defined

    ZeroMemory(&Timeouts, sizeof(COMMTIMEOUTS));                         // set read and write time outs: in this case reads and writes are performed immediatly and returns without blocking
    Timeouts.ReadIntervalTimeout = MAXDWORD;
    Timeouts.ReadTotalTimeoutMultiplier = 0;
    Timeouts.ReadTotalTimeoutConstant = 0;
    Timeouts.WriteTotalTimeoutMultiplier = 0;
    Timeouts.WriteTotalTimeoutConstant = 0;

    if (!SetCommTimeouts(m_hComm, &Timeouts)) {
        printf(TEXT("Failed in call to SetCommTimeouts\n"));
    }

    return m_hComm;
}

static DWORD fnSendSerialMessage(HANDLE m_hComm, const void *lpBuf, DWORD dwCount)
{
    DWORD dwBytesWritten = 0;
    static _OVERLAPPED ol = {0};                                         // {3}

    WriteFileEx(m_hComm, lpBuf, dwCount, &ol, 0);

    return dwBytesWritten;
}
#endif

// Intermediate call to ensure that the calling thread waits on other active threads
//
static int _main(int argc, char *argv[])                                 // {23}
{
    int iRtn;
    while (WAIT_WHILE_BUSY == (iRtn = main(argc, argv))) {
        Sleep(1);                                                        // yield temporarily until other threads have completed their work
    }
    return iRtn;
}

#if defined SUPPORT_LCD || defined SUPPORT_GLCD || defined SUPPORT_OLED || defined SUPPORT_TFT || defined GLCD_COLOR // {35}
extern void fnRedrawDisplay(void)
{
    InvalidateRect(ghWnd, NULL, FALSE);                                  // {44}
}
#endif

