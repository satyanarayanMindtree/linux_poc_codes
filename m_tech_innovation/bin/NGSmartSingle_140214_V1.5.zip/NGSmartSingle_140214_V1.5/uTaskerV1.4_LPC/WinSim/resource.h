//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by uTasker.rc
//
#define IDC_MYICON                      2
#define IDD_ETHERNET1_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDD_NIC                         104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_ETHERNET1                   107
#define IDI_SMALL                       108
#define IDC_ETHERNET1                   109
#define IDR_MAINFRAME                   128
#define IDC_CURSOR1                     130
#define IDC_CURSOR2                     138
#define IDD_DIALOG1                     141
#define IDD_RESET                       143
#define IDD_WATCHDOG                    144
#define IDC_CURSOR3                     145
#define IDC_CURSOR4                     152
#define IDC_CURSOR5                     155
#define IDC_CURSOR6                     156
#define IDC_COMBO1                      1000
#define ID_TEST_TX                      32771
#define ID_TEST_RX                      32772
#define ID_TEST_RX_PING                 32773
#define ID_TEST_ARP                     32774
#define ID_DEBUG_TST                    32775
#define ID_DEBUG_ARPA                   32776
#define ID_TEST_NEW_MAC                 32777
#define ID_TEST_NEW_IP                  32778
#define ID_TEST_IPCONFIG                32779
#define ID_TEST_FRONT                   32780
#define ID_TESTS_SPI_RX                 32781
#define ID_TEST_SPI_INT                 32782
#define ID_SERVER_POP3                  32783
#define ID_WEB_START                    32784
#define ID_TEST_RST                     32785
#define ID_TESTS_UDP_RX                 32786
#define ID_DEBUG_DEL                    32787
#define ID_ETH_FILE                     32788
#define ID_VIP_ACK                      32789
#define ID_VIP_LCD_CMD                  32790
#define ID_VIP_LCD_TXT                  32791
#define ID_VIP_CHECKSUM                 32792
#define ID_VIP_ACK_ON                   32793
#define ID_VIP_EVENT                    32794
#define ID_VIP_CHECK_KEYS               32795
#define ID_VIPPANEL_SETPATTERN          32796
#define ID_VIPPANEL_READDRAM            32797
#define ID_POWER_UDP                    32798
#define ID_POWER_SER                    32799
#define ID_ETHEREAL                     32800
#define ID_LAN_NIC                      32801
#define ID_TEST_R1                      32802
#define ID_TEST_R2                      32803
#define ID_TEST_ENUMERATION             32804
#define ID_TEST_R3                      32805
#define ID_PORTSIMULATOR_OPENSCRIPT     32806
#define ID_USB_DISCONNECT               32807
#define ID_USB_CONNECTLOWSPEEDDEVICE    32808
#define ID_USB_CONNECTFULLSPEEDDEVICE   32809
#define ID_WIRESHARK_REPLAYLASTFILE     32810
#define ID_PORTSIM_REPEATLASTSCRIPT     32811
#define ID_TEST_R4                      32812
#define ID_TEST_R5                      32813
#define ID_TEST_R6                      32814
#define ID_TEST_EXT_R0                  32814
#define ID_TEST_R7                      32815
#define ID_TEST_EXT_R1                  32815
#define ID_SLCD_SHOWALLSEGMENTS         32816
#define ID_SLCD_RELEASESEGMENTS         32817
#define ID_TEST_EXT_R2                  32818
#define ID_TEST_EXT_R3                  32819
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        163
#define _APS_NEXT_COMMAND_VALUE         32820
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
