/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        app_hw_lpc23xx.h
    Project:     uTasker Demonstration project
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    16.08.2009 Add key scan matrix and direct connection                 {1}
    02.10.2009 Move "../../Hardware/LPC23XX/LPC23XX.h" include from types.h to this file, after detailed chip defines {2}
    08.10.2009 Remove check of PLL rules when PLL is disabled            {3}
    11.10.2009 Add Samsung GLCD configuration                            {4}
    15.10.2009 Add additional ST SPI FLASH devices                       {5}
    16.10.2009 Add NUMBER_EXTERNAL_SERIAL when serial interface active   {6}
    06.11.2009 Add TICK_INTERRUPT()                                      {7}
    24.12.2009 Add SD-card interface                                     {8}
    26.01.2010 Add SD-card controller interface                          {9}
    23.02.2010 Add LPC21xx SD card configuration                         {10}
    23.02.2010 Move part configuration to LPC23XX.h
    23.02.2010 Add LPC2148 configuration                                 {11}
    06.03.2010 Add SST FLASH configuration                               {12}
    06.03.2010 Remove parameters from SPI based file system              {13}
    16.03.2010 Add EXCEPTION_STACK_SIZE                                  {14} - removed 04.06.2011
    09.06.2010 Add _DP83848                                              {15}
    11.08.2010 Add PRIORITY_ADC and SUPPORT_ADC/TOUCH_HW_TIMER for LPC24xx touch screen  {16}
    14.02.2011 Add MONITOR_PERFORMANCE support                           {17}
    07.04.2011 Add GET_SDCARD_WP_STATE()                                 {18}
    17.02.2012 Add USB macros for signalling USB and controlling HID mouse {19}

    Application specific hardware configuration
*/

#if defined _LPC23XX && !defined __APP_HW_LPC23XX__
#define __APP_HW_LPC23XX__

#ifdef _WINDOWS
    #define _SIM_PORTS fnSimPorts()
#else
    #define _SIM_PORTS
#endif

//#define _DEBUG_CODE_                                                   // temporarily disable watchdog to aid in debugging

#define LPC23XX_WORKAROUND_MAM_ON                                        // utilise workaround due to memory accelerator errata

//#define DISABLE_PLL                                                    // use this to define operation at oscillator/RC frequency
//#define USE_RC_OSCILLATOR                                              // run from internal RC rather than crystal source
//#define USE_32K_OSCILLATOR                                             // run from 32kHz crystal
#ifdef _LPC21XX
    #ifdef OLIMEX_LPC_P2148
        #define CRYSTAL_FREQ    12000000                                 // crystal or clock input frequency (10 to 25MHz)
        #define PLL_MUL         5                                        // 1..32
        #define PLL_USB_MUL     4                                        // value required to generate 48MHz USB clock
        #define USB_POST_DIVIDE 1                                        // 0, 1, 2 or 3 (divide 1, 2, 4 or 8)
    #else
        #define CRYSTAL_FREQ    14745600                                 // crystal or clock input frequency (10 to 25MHz)
        #define PLL_MUL         4                                        // 1..32
    #endif
    #define POST_DIVIDE         1                                        // 0, 1, 2 or 3 (divide 1, 2, 4 or 8)

    #define PLL_OUTPUT_FREQ_INT (CRYSTAL_FREQ*PLL_MUL)
    #if !defined DISABLE_PLL                                             // rules for setting the PLL frequency
        #if CRYSTAL_FREQ < 10000000 || CRYSTAL_FREQ > 25000000           // note that the LPC2101/2/3 can use a crystal in the range 1MHz..25MHz,, but only when neither the PLL nor the Boot loader is used.
            #error Clock frequency out of range: must be between 10 and 25MHz
        #endif
        #if POST_DIVIDE > 3
            #error Divider value must be 0,1,2 or 3 (0 = 2, 1 = 4, 2 = 8, 3 = 16)
        #endif
        #if PLL_MUL < 1 || PLL_MUL > 32
            #error Multiplier value must be between 1 and 32
        #endif
        #if ((PLL_OUTPUT_FREQ_INT * (2 << POST_DIVIDE)) < 156000000) || ((PLL_OUTPUT_FREQ_INT *(2 << POST_DIVIDE)) > 320000000)
            #error PLL range invalid: intermediate frequency not within 156 and 320MHz range
        #endif
        #if defined LPC2104 || defined LPC2105 || defined LPC2106 || defined OLIMEX_LPC_P2148
            #if (PLL_OUTPUT_FREQ_INT < 10000000) || (PLL_OUTPUT_FREQ_INT > 60000000)
                #error CPU speed invalid: not within 10 and 60MHz range
            #endif
        #else
            #if (PLL_OUTPUT_FREQ_INT < 10000000) || (PLL_OUTPUT_FREQ_INT > 70000000)
                #error CPU speed invalid: not within 10 and 70MHz range
            #endif
        #endif
    #endif
    #ifdef USB_INTERFACE
        #define USB_PLL_FREQ_INT (CRYSTAL_FREQ * PLL_USB_MUL)
        #if (CRYSTAL_FREQ * PLL_USB_MUL) != 48000000
            #error USB PLL is not configured to generate 48.0MHz !!
        #endif
        #if ((48000000 * (2 << USB_POST_DIVIDE)) < 156000000)
            #error USB PLL range invalid: intermediate frequency not within 156 and 320MHz range (too low)
        #elif ((48000000 * (2 << USB_POST_DIVIDE)) > 320000000)
            #error USB PLL range invalid: intermediate frequency not within 156 and 320MHz range (too high)
        #endif
    #endif
#else
    #if defined USE_RC_OSCILLATOR
        #define CRYSTAL_FREQ           IRC_FREQUENCY
    #elif defined USE_32K_OSCILLATOR
        #define CRYSTAL_FREQ           32768
    #else
        #define CRYSTAL_FREQ           12000000                          // crystal or clock input frequency (1 to 24MHz)
    #endif
    #define OSC_DIVIDE      1                                            // 1..255
    #define PLL_MUL         12                                           // 1..32768
    #define POST_DIVIDE     4                                            // 1..256

    // Rules for setting the frequency
    // The input can be divided by between 1 and 256
    // The PLL input must be in the range 32kHz to 50MHz
    // The PLL can multiply by between 1 and 32768
    // The PLL frequency must be in the range 275MHz and 550MHz
    // The output frequence is equal to (2 * PLL_MUL * CRYSTAL_FREQ) / (OSC_DIVIDE * POST_DIVIDE)
    // The compiler throws an error if any setting is out of range
    // WARNING. For low clock inputs (like 32k) there are some other restrictions and so the data sheet must be carefully studied!

    // ERRATA - PLL. Devices '-' and 'A' may not operate at above 60MHz from FLASH!! Also the PLL output is restricted to 288MHz!!

    #define PLL_OUTPUT_FREQ_INT ((2*CRYSTAL_FREQ*PLL_MUL)/OSC_DIVIDE)

    #if CRYSTAL_FREQ < 1000000 || CRYSTAL_FREQ > 24000000
        #error Clock frequency out of range: must be between 1 and 24MHz
    #endif
    #if !defined DISABLE_PLL                                             // {3}
        #if CRYSTAL_FREQ/OSC_DIVIDE < 32000 || CRYSTAL_FREQ/OSC_DIVIDE > 50000000
            #error Clock frequency out of range: PLL input frequency must be within 32kHz and 50MHz
        #endif
        #if ((((CRYSTAL_FREQ)/OSC_DIVIDE) * PLL_MUL * 2) < 275000000) || ((((CRYSTAL_FREQ)/OSC_DIVIDE) * PLL_MUL * 2) > 550000000)
            #error PLL range invalid: intermediate frequency not within 275 and 550MHz range
        #endif

        // Check that the USB frequency can be generated from PLL output
        #if PLL_OUTPUT_FREQ_INT != 288000000 && PLL_OUTPUT_FREQ_INT != 384000000 && PLL_OUTPUT_FREQ_INT != 480000000
            #error USB Clock frequency out of range: must be exactly 48MHz!!
        #endif
        // Check that the CPU speed is not too high
        #if (PLL_OUTPUT_FREQ_INT/POST_DIVIDE) > 72000000
            #error CPU clock speed too high!!!
        #endif
    #endif
#endif

#define _HW_TIMER_MODE                                                   // support additional timer mode to allow period and PWM signals

#if defined SDCARD_SUPPORT                                               // {8}
    #if defined _LPC24XX || defined LPC2378FBD144                        // optionally selected SDIO controller mode of operation for chips that support it
        #define SD_CONTROLLER_AVAILABLE                                  // these parts contain an SD/MMC controller which is used as preference when SD-card support is enabled
        #define SD_CONTROLLER_DMA                                        // select DMA support for reading and writing data (this must be before the HW header include). Always enable DMA for higher interface speed since SW latency can otherwise cause errors
    #endif
#endif


//#include "../../Hardware/LPC23XX/LPC23XX.h"                              // {2}
#include "LPC23XX.h"                              // {2}

// TICK timer configuration
//
//#define TICK_TIMER_1
//#define TICK_TIMER_2
//#define TICK_TIMER_3

#if defined TICK_TIMER_1
    #define TICK_PCLKSEL             PCLKSEL0
    #define TICK_CLK_SPEED           PCLK_TIMER1_CCLK_8
    #define TICK_TIMER_POWER         PCTIM1
    #define TICK_TCR                 T1TCR
    #define TICK_PR                  T1PR
    #define TICK_IR                  T1IR
    #define TICK_MR0                 T1MR0
    #define TICK_MCR                 T1MCR
    #define TICK_TCR                 T1TCR
    #define TICK_TIMER_INT           INTERRUPT_TIMER1
#elif defined TICK_TIMER_2
    #define TICK_PCLKSEL             PCLKSEL1
    #define TICK_CLK_SPEED           PCLK_TIMER2_CCLK_8
    #define TICK_TIMER_POWER         PCTIM2
    #define TICK_TCR                 T2TCR
    #define TICK_PR                  T2PR
    #define TICK_IR                  T2IR
    #define TICK_MR0                 T2MR0
    #define TICK_MCR                 T2MCR
    #define TICK_TCR                 T2TCR
    #define TICK_TIMER_INT           INTERRUPT_TIMER2
    #if (defined LPC2101 || defined LPC2102 || defined LPC2103)          // 16 bit timers on this device so add prescaler to avoid overlow
        #define TICK_TIM_PRESCALE    32
    #endif
#elif defined TICK_TIMER_3
    #define TICK_PCLKSEL             PCLKSEL1
    #define TICK_CLK_SPEED           PCLK_TIMER3_CCLK_8
    #define TICK_TIMER_POWER         PCTIM3
    #define TICK_TCR                 T3TCR
    #define TICK_PR                  T3PR
    #define TICK_IR                  T3IR
    #define TICK_MR0                 T3MR0
    #define TICK_MCR                 T3MCR
    #define TICK_TCR                 T3TCR
    #define TICK_TIMER_INT           INTERRUPT_TIMER3
    #if (defined LPC2101 || defined LPC2102 || defined LPC2103)          // 16 bit timers on this device so add prescaler to avoid overlow
        #define TICK_TIM_PRESCALE    32
    #endif
#else                                                                    // default to timer 0 for TICK use
    #define TICK_PCLKSEL             PCLKSEL0
    #define TICK_CLK_SPEED           PCLK_TIMER0_CCLK_8
    #define TICK_TIMER_POWER         PCTIM0
    #define TICK_TCR                 T0TCR
    #define TICK_PR                  T0PR
    #define TICK_IR                  T0IR
    #define TICK_MR0                 T0MR0
    #define TICK_MCR                 T0MCR
    #define TICK_TCR                 T0TCR
    #define TICK_TIMER_INT           INTERRUPT_TIMER0
#endif

#ifdef MONITOR_PERFORMANCE
    #define INITIALISE_MONITOR_TIMER() POWER_UP(PCTIM1); T1PR = 179; T1TCR = COUNTER_ENABLE; // power up and enable the timer counting at 10us rate (72MHz and PCLK/4)
    #ifdef _WINDOWS                                                      // reset the count value content when simulating
        #define EXECUTION_DURATION()   T1TC; T1TCR = (COUNTER_ENABLE | COUNTER_RESET); T1TC = 0; T1TCR = (COUNTER_ENABLE) //  read the timer value register and then reset it for next duration
    #else
        #define EXECUTION_DURATION()   T1TC; T1TCR = (COUNTER_ENABLE | COUNTER_RESET); T1TCR = (COUNTER_ENABLE) //  read the timer value register and then reset it for next duration
    #endif
#endif


#define TICK_INTERRUPT()                                                 // {7} user callback from system TICK

//#define SUPPORT_RTC                                                    // support real time clock

// Memory set up for this target
//
#define FLASH_GRANULARITY          FLASH_GRANULARITY_LARGE               // smallest sector which can be erased independently
#define MAX_SECTOR_PARS            ((FLASH_GRANULARITY - (2*FLASH_LINE_SIZE))/FLASH_LINE_SIZE) // the number of user bytes fitting into first parameter block


// SPI FLASH system setup
//
#if defined SPI_FILE_SYSTEM && !defined FLASH_FILE_SYSTEM 
    #define EEPROM_32K                                                   // Device size used
#else
    #define FILES_ADDRESSABLE                                            // file system is addressable (doesn't have to be retrieved)
#endif

#ifdef EEPROM_16K
    #define EEPROM_PAGE_SIZE 64                                          // defined by device

    #define FILE_GRANULARITY (1024)                                      // File made up of 1k byte FLASH blocks
    #define FILE_SYSTEM_SIZE (16*FILE_GRANULARITY)                       // 16k reserved for file system (including parameter blocks)
#endif
    #ifdef EEPROM_32K
    #define EEPROM_PAGE_SIZE 64                                          // defined by device

    #define FILE_GRANULARITY (1024)                                      // File made up of 1k byte FLASH blocks
    #define FILE_SYSTEM_SIZE (32*FILE_GRANULARITY)                       // 32k reserved for file system (including parameter blocks)
#endif
#ifdef EEPROM_64K
    #define EEPROM_PAGE_SIZE 128                                         // respect larger page size in SPI EEPROM

    #define FILE_GRANULARITY (2*1024)                                    // File made up of 2k byte FLASH blocks
    #define FILE_SYSTEM_SIZE (32*FILE_GRANULARITY)                       // 64k reserved for file system (including parameter blocks)
#endif

//#define SPI_FLASH_MULTIPLE_CHIPS                                       // activate when multiple physical chips are used
#define CS0_LINE            PORT0_BIT14                                  // CS0 line used when SPI FLASH is enabled
#define CS1_LINE            PORT0_BIT17                                  // CS1 line used when extended SPI FLASH is enabled
#define CS2_LINE            PORT0_BIT18                                  // CS2 line used when extended SPI FLASH is enabled
#define CS3_LINE            PORT0_BIT19                                  // CS3 line used when extended SPI FLASH is enabled
#define CS_SET_PORT         FIO0SET
#define CS_CLR_PORT         FIO0CLR
#define SPI_CS0_PORT        FIO0PIN
#define SPI_CS1_PORT        FIO0PIN
#define SPI_CS2_PORT        FIO0PIN
#define SPI_CS3_PORT        FIO0PIN

#define PCSSP_X             PCSSP1                                       // use SSP1
#define SSPCR0_X            SSP1CR0
#define SSPCR1_X            SSP1CR1
#define SSPCPSR_X           SSP1CPSR
#define SSPDR_X             SSP1DR
#define SSPSR_X             SSP1SR

#define CONFIGURE_SPI_PINS()        PINSEL0 |= (PINSEL0_P0_8_MISO1 | PINSEL0_P0_9_MOSI1 | PINSEL0_P0_7_SCK1); // MOSI, MISO and SCK pins enabled - on SSP1
// Alternative possibilities for SSP1 on LPC2378 only
//#define CONFIGURE_SPI_PINS()        PINSEL0 |=(PINSEL0_P0_12_MISO1 | PINSEL0_P0_13_MOSI1 | PINSEL0_P0_7_SCK1); PINSEL3 |= PINSEL3_P1_31_SCK1;


#define SET_SPI_FLASH_MODE()                                             // {12} dummy for compatibility
#define REMOVE_SPI_FLASH_MODE()                                          // {12} dummy for compatibility
                                                                         
#ifdef SPI_FLASH_ST                                                      // ST SPI FLASH used
  //#define SPI_FLASH_STM25P05                                           // the available ST chips
  //#define SPI_FLASH_STM25P10
    #define SPI_FLASH_STM25P20
  //#define SPI_FLASH_STM25P40
  //#define SPI_FLASH_STM25P80                                               
  //#define SPI_FLASH_STM25P16                                               
  //#define SPI_FLASH_STM25P32                                               
  //#define SPI_FLASH_STM25P64
  //#define SPI_FLASH_STM25P128

    #if defined SPI_FLASH_STM25P05                                       // 64k {5}
        #define SPI_FLASH_PAGES             (1*256)                          
    #elif defined SPI_FLASH_STM25P10                                     // 128k
        #define SPI_FLASH_PAGES             (2*256)
    #elif defined SPI_FLASH_STM25P20                                     // 256k
        #define SPI_FLASH_PAGES             (4*256)
    #elif defined SPI_FLASH_STM25P40                                     // 512k
        #define SPI_FLASH_PAGES             (8*256)
    #elif defined SPI_FLASH_STM25P80                                     // 1M
        #define SPI_FLASH_PAGES             (16*256)
    #elif defined SPI_FLASH_STM25P16                                     // 2M
        #define SPI_FLASH_PAGES             (32*256)
    #elif defined SPI_FLASH_STM25P32                                     // 4M
        #define SPI_FLASH_PAGES             (64*256)
    #elif defined SPI_FLASH_STM25P64                                     // 8M
        #define SPI_FLASH_PAGES             (128*256)
    #elif defined SPI_FLASH_STM25P128                                    // 16M
        #define SPI_FLASH_PAGES             (256*256)
    #endif
    #define SPI_FLASH_PAGE_LENGTH 256
    #ifdef SPI_DATA_FLASH
        #define SPI_FLASH_SECTOR_LENGTH (16*SPI_FLASH_PAGE_LENGTH)       // sub-sector size of data FLASH
    #else
        #define SPI_FLASH_SECTOR_LENGTH (256*SPI_FLASH_PAGE_LENGTH)      // sector size of code FLASH
    #endif
    #define SPI_FLASH_BLOCK_LENGTH  SPI_FLASH_SECTOR_LENGTH
#elif defined SPI_FLASH_SST25                                            // {12}
  //#define SPI_FLASH_SST25VF010A                                        // the supported SST chips
  //#define SPI_FLASH_SST25LF020A
  //#define SPI_FLASH_SST25LF040A
  //#define SPI_FLASH_SST25VF040B
  //#define SPI_FLASH_SST25VF080B
    #define SPI_FLASH_SST25VF016B
  //#define SPI_FLASH_SST25VF032B

    #if defined SPI_FLASH_SST25VF010A                                    // 1Mbit (128k)
        #define SST25_A_VERSION
        #define SPI_FLASH_PAGES             (32)
    #elif defined SPI_FLASH_SST25LF020A                                  // 2Mbit (256k)
        #define SST25_A_VERSION
        #define SPI_FLASH_PAGES             (64)
    #elif defined SPI_FLASH_SST25LF040A                                  // 4Mbit (512k)
        #define SST25_A_VERSION
        #define SPI_FLASH_PAGES             (128)
    #elif defined SPI_FLASH_SST25VF040B                                  // 4Mbit (512k)
        #define SPI_FLASH_PAGES             (128)
    #elif defined SPI_FLASH_SST25VF080B                                  // 8Mbit (1M)
        #define SPI_FLASH_PAGES             (256)
    #elif defined SPI_FLASH_SST25VF016B                                  // 16Mbit (2M)
        #define SPI_FLASH_PAGES             (512)
    #elif defined SPI_FLASH_SST25VF032B                                  // 32Mbit (4M)
        #define SPI_FLASH_PAGES             (1024)
    #endif

    #define SPI_FLASH_SUB_SECTOR_LENGTH  (4*1024)                        // sub-sector size of SPI FLASH
    #define SPI_FLASH_HALF_SECTOR_LENGTH (32*1024)                       // half-sector size of SPI FLASH
    #define SPI_FLASH_SECTOR_LENGTH      (64*1024)                       // sector size of SPI FLASH (not available on A-versions)

    #define SPI_FLASH_PAGE_LENGTH        SPI_FLASH_SUB_SECTOR_LENGTH     // for compatibility - smallest erasable block
    #define SPI_FLASH_BLOCK_LENGTH       SPI_FLASH_SUB_SECTOR_LENGTH     // for compatibility - file system granularity
#else                                                                    // AT45DBxxx 
  //#define SPI_FLASH_AT45DB011                                          // define the ATMEL type used here
  //#define SPI_FLASH_AT45DB021
  //#define SPI_FLASH_AT45DB041
  //#define SPI_FLASH_AT45DB081
  //#define SPI_FLASH_AT45DB161
    #define SPI_FLASH_AT45DB321
  //#define SPI_FLASH_AT45DB642
  //#define SPI_FLASH_AT45XXXXD_TYPE                                     // specify that a D-type rather than a B/C type is being used

    #if defined SPI_FLASH_AT45DB642                                      // define whether used in power of 2 mode or not
        #define SPI_FLASH_PAGE_LENGTH 1056                               // standard page size (B-device only allows 1056)
      //#define SPI_FLASH_PAGE_LENGTH 1024                               // size when power of 2 mode selected (only possible on D-device)
        #define SPI_FLASH_PAGES             (32*1024)                    // 8Meg part
    #elif defined SPI_FLASH_AT45DB321 || defined SPI_FLASH_AT45DB161
        #define SPI_FLASH_PAGE_LENGTH 528                                // standard page size (B/C-device only allows 528)
      //#define SPI_FLASH_PAGE_LENGTH 512                                // size when power of 2 mode selected (only possible on D-device)
        #if defined SPI_FLASH_AT45DB161
            #define SPI_FLASH_PAGES         (8*1024)                     // 2Meg part
        #else
            #define SPI_FLASH_PAGES         (16*1024)                    // 4Meg part
        #endif
    #else
        #define SPI_FLASH_PAGE_LENGTH 264                                // standard page size (B-device only allows 264)
      //#define SPI_FLASH_PAGE_LENGTH 256                                // size when power of 2 mode selected (only possible on D-device)
        #if defined SPI_FLASH_AT45DB011
            #define SPI_FLASH_PAGES         (512)                        // 128k part
        #elif defined SPI_FLASH_AT45DB021
            #define SPI_FLASH_PAGES         (1024)                       // 256k part
        #elif defined SPI_FLASH_AT45DB041
            #define SPI_FLASH_PAGES         (2*1024)                     // 512k part
        #elif defined SPI_FLASH_AT45DB081
            #define SPI_FLASH_PAGES         (4*1024)                     // 1Meg part
        #endif
    #endif

    #define SPI_FLASH_BLOCK_LENGTH (8*SPI_FLASH_PAGE_LENGTH)             // block size - a block can be deleted
    #define SPI_FLASH_SECTOR_LENGTH (64*4*SPI_FLASH_PAGE_LENGTH)         // exception sector 0a is 2k and sector 0b is 62k
#endif

#define SPI_DATA_FLASH_0_SIZE   (SPI_FLASH_PAGES*SPI_FLASH_PAGE_LENGTH) 
#define SPI_DATA_FLASH_1_SIZE   SPI_DATA_FLASH_0_SIZE 
#define SPI_DATA_FLASH_2_SIZE   SPI_DATA_FLASH_0_SIZE
#define SPI_DATA_FLASH_3_SIZE   SPI_DATA_FLASH_0_SIZE
#ifdef SPI_FLASH_MULTIPLE_CHIPS
    #define SPI_FLASH_DEVICE_COUNT  4
    #if SPI_FLASH_DEVICE_COUNT >= 4
        #define SPI_DATA_FLASH_SIZE     (SPI_DATA_FLASH_0_SIZE + SPI_DATA_FLASH_1_SIZE + SPI_DATA_FLASH_2_SIZE + SPI_DATA_FLASH_3_SIZE)
        #define CONFIGURE_CS_LINES()    FIO0SET = (CS0_LINE | CS1_LINE | CS2_LINE | CS3_LINE); FIO0DIR |= (CS0_LINE | CS1_LINE | CS2_LINE | CS3_LINE); _SIM_PORTS
    #elif SPI_FLASH_DEVICE_COUNT >= 3
        #define SPI_DATA_FLASH_SIZE     (SPI_DATA_FLASH_0_SIZE + SPI_DATA_FLASH_1_SIZE + SPI_DATA_FLASH_2_SIZE)
        #define CONFIGURE_CS_LINES()    FIO0SET = (CS0_LINE | CS1_LINE | CS2_LINE); FIO0DIR |= (CS0_LINE | CS1_LINE | CS2_LINE); _SIM_PORTS
    #else
        #define SPI_DATA_FLASH_SIZE     (SPI_DATA_FLASH_0_SIZE + SPI_DATA_FLASH_1_SIZE)
        #define CONFIGURE_CS_LINES()    FIO0SET = (CS0_LINE | CS1_LINE); FIO0DIR |= (CS0_LINE | CS1_LINE); _SIM_PORTS
    #endif
#else
    #define SPI_DATA_FLASH_SIZE         SPI_DATA_FLASH_0_SIZE
    #define CONFIGURE_CS_LINES()        FIO0SET = CS0_LINE; FIO0DIR |= CS0_LINE; _SIM_PORTS
#endif


#define SPI_FLASH_START        (FLASH_START_ADDRESS + SIZE_OF_FLASH)     // SPI FLASH starts immediately after FLASH

#define SW_UPLOAD_FILE()       (*ucIp_Data == 'H') && (*(ucIp_Data+1) == 'S') && (*(ucIp_Data+2) == '.')  && (fnSPI_Flash_available() != 0)


// FLASH based File System setup
//
#ifdef FLASH_FILE_SYSTEM
    #if defined SPI_FILE_SYSTEM                                          // this is a test setup for external SPI FLASH, with the parameters at the end of internal FLASH
        #define uFILE_START (SPI_FLASH_START)                            // {13} FLASH location at 2 parameter blocks short of end of internal FLASH
        #define FILE_SYSTEM_SIZE (32*FILE_GRANULARITY)                   // 512k reserved for file system (plus parameter blocks)
    #else
        #ifdef _LPC21XX
            #define uFILE_START (FLASH_START_ADDRESS + FLASH_SECTOR_11_OFFSET)// FLASH location at 88k start
            #define SUB_FILE_SIZE    (FILE_GRANULARITY / 4)              // 2k sub file sizes
            #define FILE_GRANULARITY (1*FLASH_GRANULARITY_LARGE)         // each file a multiple of 8k
            #define FILE_SYSTEM_SIZE (4*FLASH_GRANULARITY_LARGE)         // 32k reserved for file system
        #elif defined _LPC24XX || defined _336K_FILE_SYSTEM_SPACE
            #define uFILE_START (FLASH_START_ADDRESS + FLASH_SECTOR_12_OFFSET)// FLASH location at 160k start
            #define SUB_FILE_SIZE    (FILE_GRANULARITY / 8)              // 4k sub file sizes
            #define FILE_GRANULARITY (1*FLASH_GRANULARITY_LARGE)         // each file a multiple of 32k
            #define FILE_SYSTEM_SIZE ((10*FLASH_GRANULARITY_LARGE) + (4*FLASH_GRANULARITY_SMALL)) // 336k reserved for file system
        #else
            #define uFILE_START (FLASH_START_ADDRESS + FLASH_SECTOR_12_OFFSET)// FLASH location at 160k start
            #define SUB_FILE_SIZE    (FILE_GRANULARITY / 8)              // 4k sub file sizes
            #define FILE_GRANULARITY (1*FLASH_GRANULARITY_LARGE)         // each file a multiple of 32k
            #define FILE_SYSTEM_SIZE ((5*FLASH_GRANULARITY_LARGE) + (4*FLASH_GRANULARITY_SMALL)) // 176k reserved for file system
/*
            #define uFILE_START (FLASH_START_ADDRESS + FLASH_SECTOR_17_OFFSET)// FLASH location at 320k start
            #define SUB_FILE_SIZE    (FILE_GRANULARITY / 8)              // 4k sub file sizes
            #define FILE_GRANULARITY (1*FLASH_GRANULARITY_LARGE)         // each file a multiple of 32k
            #define FILE_SYSTEM_SIZE ((5*FLASH_GRANULARITY_LARGE) + (4*FLASH_GRANULARITY_SMALL)) // 176k reserved for file system
            */
        #endif
    #endif
#endif


#define SAVE_COMPLETE_FLASH                                              // when simulating, save complete flash contents and not just the file system contents


#ifdef USE_PARAMETER_BLOCK
    #if defined _LPC21XX && !defined _LPC214X
            #define PARAMETER_BLOCK_GRANULARITY     FLASH_GRANULARITY_SMALL
            #define PARAMETER_BLOCK_SIZE    PARAMETER_BLOCK_GRANULARITY  // use the smallest size for the device (the parameter block must be positioned in appropriate sectors)
            #define PARAMETER_BLOCK_START   FLASH_SECTOR_9_OFFSET        // 72k
            #ifdef USE_PAR_SWAP_BLOCK
                #define PAR_BLOCK_SIZE  (2*PARAMETER_BLOCK_SIZE)
            #else
                #define PAR_BLOCK_SIZE  (1*PARAMETER_BLOCK_SIZE)
            #endif
    #else
        #define PARAMETER_BLOCK_GRANULARITY     FLASH_GRANULARITY_SMALL
        #define PARAMETER_BLOCK_SIZE    PARAMETER_BLOCK_GRANULARITY      // use the smallest size for the device (the parameter block must be positioned in appropriate sectors)
        #define PARAMETER_BLOCK_START   FLASH_SECTOR_26_OFFSET           // 496k
        #ifdef USE_PAR_SWAP_BLOCK
            #define PAR_BLOCK_SIZE  (2*PARAMETER_BLOCK_SIZE)
        #else
            #define PAR_BLOCK_SIZE  (1*PARAMETER_BLOCK_SIZE)
        #endif
    #endif
#else
    #define PAR_BLOCK_SIZE  (0)
#endif


#define USB_DOWNLOAD_FILE              "z"

#if defined OLIMEX_LPC_P2148                                                 
    #define USB_PUP                     PORT0_BIT31
    #define ENABLE_DPLUS_PULLUP()       _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, USB_PUP, 0)
    #define ENABLE_DMINUS_PULLDOWN()
#endif


#if defined SDCARD_SUPPORT                                               // {8}
    #if defined SD_CONTROLLER_AVAILABLE                                  // {9}
        // Set maximum speed
        //
        #ifdef SD_CONTROLLER_DMA
          //#define SET_SPI_SD_INTERFACE_FULL_SPEED() MCIClock = (MCI_CLK_WideBus | MCI_CLK_Bypass | MCI_CLK_PwrSave | MCI_CLK_Enable | 0); // bypass the dividers to achieve maximum speed - 18MHz from 72MHz clock - this however tends to be too fast for the DMA controller to keep up!
            #define SET_SPI_SD_INTERFACE_FULL_SPEED() MCIClock = (MCI_CLK_WideBus | MCI_CLK_PwrSave | MCI_CLK_Enable | 0); // 9MHz operation from 72 MHz PLL
        #else                                                            // when DMA is not being used the maximum speed is restricted by the rx FIFO's need to clear its buffers adequately fast during block reception
            #define SET_SPI_SD_INTERFACE_FULL_SPEED() MCIClock = (MCI_CLK_WideBus | MCI_CLK_PwrSave | MCI_CLK_Enable | ((PCLK/4/2/4000000 - 1)));
        #endif
        #define POWER_UP_SD_CARD()    MCIPower = MCI_PWR_Ctrl_PowerOn
        #define POWER_DOWN_SD_CARD()  MCIPower = MCI_PWR_Ctrl_PowerOff;

        #define SET_SD_CS_HIGH()                                         // CS not used in SD controller mode
        #define SET_SD_CS_LOW()

        // Configure polarity of power control pin and the SD card SDIO interface for the board
        //
        #ifdef KEIL_MCB2300
            #define CONFIGURE_SDCARD_INTERFACE()  SCS |= MCIPWR; \
                                                  PINSEL1 |= (PINSEL1_P0_22_MCIDATA0 | PINSEL1_P0_21_MCIPWR | PINSEL1_P0_20_MCIMD | PINSEL1_P0_19_MCICLK); \
                                                  PINSEL4 |= (PINSEL4_P2_13_MCIDAT3 | PINSEL4_P2_12_MCIDAT2 | PINSEL4_P2_11_MCIDAT1);
        #elif defined OLIMEX_LPC2478_STK
            #define CONFIGURE_SDCARD_INTERFACE()  SCS |= MCIPWR; \
                                                  PINSEL2 |= (PINSEL2_P1_5_MCIPWR | PINSEL2_P1_3_MCICMD | PINSEL2_P1_2_MCICLK | PINSEL2_P1_6_MCIDAT0 | PINSEL2_P1_7_MCIDAT1 | PINSEL2_P1_11_MCIDAT2 | PINSEL2_P1_12_MCIDAT3);
        #endif
        #define GET_SDCARD_WP_STATE() 0                                  // {18} write protection disabled (change to read switch is required)
    #elif defined _LPC21XX && !defined OLIMEX_LPC_P2148                  // {10} LPC21xx configuration
        // Configure to suit SD card SPI mode at between 100k and 400k
        //
        #define SPI_CS1_0                  PORT0_BIT7
        #define INITIALISE_SPI_SD_INTERFACE() POWER_UP(PCSSP0); \
        PINSEL0 |= (PINSEL0_P0_5_MISO | PINSEL0_P0_6_MOSI | PINSEL0_P0_4_SCK); \
        _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, SPI_CS1_0, SPI_CS1_0); \
        SSP0CR1 = 0; SSP0CPSR = 2; \
        SSP0CR0 = (FRS_FREESCALE_SPI | DSS_8_BIT | ((((SSP_CLOCK/2 + 300000/2)/300000) - 1) << SSP_SCR_SHIFT)); \
        SSP0CR1 = SSP_SSE

        #define ENABLE_SPI_SD_OPERATION()
        #define SET_SD_CARD_MODE()

        // Set maximum speed
        //
        #define SET_SPI_SD_INTERFACE_FULL_SPEED() SSP0CR0 = (FRS_FREESCALE_SPI | DSS_8_BIT | ((((SSP_CLOCK/2 + 6000000/2)/6000000) - 1) << SSP_SCR_SHIFT))
        #ifdef _WINDOWS
            #define WRITE_SPI_CMD(byte)    SSP0DR = (unsigned char)byte; SSP0DR = _fnSimSD_write((unsigned char)byte)
            #define WAIT_TRANSMISSON_END() while (!(SSP0SR & SSP_RNE)) { SSP0SR |= SSP_RNE; } SSP0SR &= ~SSP_RNE
            #define READ_SPI_DATA()        (unsigned char)SSP0DR
        #else
            #define WRITE_SPI_CMD(byte)    SSP0DR = (unsigned char)byte
            #define WAIT_TRANSMISSON_END() while (!(SSP0SR & SSP_RNE)) {}
            #define READ_SPI_DATA()        (unsigned char)SSP0DR
        #endif

        #define POWER_UP_SD_CARD()                                       // apply power to the SD card if appropriate
        #define POWER_DOWN_SD_CARD()                                     // remove power from SD card interface
        #define SET_SD_DI_CS_HIGH()  _SETBITS(0, SPI_CS1_0)              // force DI and CS lines high ready for the initialisation sequence
        #define SET_SD_CS_LOW()      _CLEARBITS(0, SPI_CS1_0)            // assert the CS line of the SD card to be read
        #define SET_SD_CS_HIGH()     _SETBITS(0, SPI_CS1_0)              // negate the CS line of the SD card to be read

        #define GET_SDCARD_WP_STATE() 0                                  // {18} write protection disabled (change to read switch is required)
    #else
        // Configure to suit SD card SPI mode at between 100k and 400k
        //
        #ifdef OLIMEX_LPC_P2148
            #define SPI_CS1_0                  PORT0_BIT20
            #define INITIALISE_SPI_SD_INTERFACE() POWER_UP(PCSSP0); \
            PINSEL1 |= (PINSEL1_P0_18_MISO1 | PINSEL1_P0_19_MOSI1 | PINSEL1_P0_17_SCK1); \
            _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, SPI_CS1_0, SPI_CS1_0); \
            SSP0CR1 = 0; SSP0CPSR = 2; \
            SSP0CR0 = (FRS_FREESCALE_SPI | DSS_8_BIT | ((((SSP_CLOCK/2 + 300000/2)/300000) - 1) << SSP_SCR_SHIFT)); \
            SSP0CR1 = SSP_SSE
        #else
            #define SPI_CS1_0                  PORT0_BIT14
            #define INITIALISE_SPI_SD_INTERFACE() POWER_UP(PCSSP1); \
            PINSEL0 |= (PINSEL0_P0_8_MISO1 | PINSEL0_P0_9_MOSI1 | PINSEL0_P0_7_SCK1); \
            _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, SPI_CS1_0, SPI_CS1_0); \
            SSP1CR1 = 0; SSP1CPSR = 2; \
            SSP1CR0 = (FRS_FREESCALE_SPI | DSS_8_BIT | ((((SSP_CLOCK/2 + 300000/2)/300000) - 1) << SSP_SCR_SHIFT)); \
            SSP1CR1 = SSP_SSE
        #endif

        #define ENABLE_SPI_SD_OPERATION()
        #define SET_SD_CARD_MODE()

        // Set maximum speed
        //
        #ifdef OLIMEX_LPC_P2148
            #define SET_SPI_SD_INTERFACE_FULL_SPEED() SSP0CR0 = (FRS_FREESCALE_SPI | DSS_8_BIT | ((((SSP_CLOCK/2 + 6000000/2)/6000000) - 1) << SSP_SCR_SHIFT))
            #ifdef _WINDOWS
                #define WRITE_SPI_CMD(byte)    SSP0DR = (unsigned char)byte; SSP0DR = _fnSimSD_write((unsigned char)byte)
                #define WAIT_TRANSMISSON_END() while (!(SSP0SR & SSP_RNE)) { SSP0SR |= SSP_RNE; } SSP0SR &= ~SSP_RNE
                #define READ_SPI_DATA()        (unsigned char)SSP0DR
            #else
                #define WRITE_SPI_CMD(byte)    SSP0DR = (unsigned char)byte
                #define WAIT_TRANSMISSON_END() while (!(SSP0SR & SSP_RNE)) {}
                #define READ_SPI_DATA()        (unsigned char)SSP0DR
            #endif
        #else
            #define SET_SPI_SD_INTERFACE_FULL_SPEED() SSP1CR0 = (FRS_FREESCALE_SPI | DSS_8_BIT | ((((SSP_CLOCK/2 + 6000000/2)/6000000) - 1) << SSP_SCR_SHIFT))
            #ifdef _WINDOWS
                #define WRITE_SPI_CMD(byte)    SSP1DR = (unsigned char)byte; SSP1DR = _fnSimSD_write((unsigned char)byte)
                #define WAIT_TRANSMISSON_END() while (!(SSP1SR & SSP_RNE)) { SSP1SR |= SSP_RNE; } SSP1SR &= ~SSP_RNE
                #define READ_SPI_DATA()        (unsigned char)SSP1DR
            #else
                #define WRITE_SPI_CMD(byte)    SSP1DR = (unsigned char)byte
                #define WAIT_TRANSMISSON_END() while (!(SSP1SR & SSP_RNE)) {}
                #define READ_SPI_DATA()        (unsigned char)SSP1DR
            #endif
        #endif

        #define POWER_UP_SD_CARD()                                       // apply power to the SD card if appropriate
        #define POWER_DOWN_SD_CARD()                                     // remove power from SD card interface
        #define SET_SD_DI_CS_HIGH()  _SETBITS(0, SPI_CS1_0)              // force DI and CS lines high ready for the initialisation sequence
        #define SET_SD_CS_LOW()      _CLEARBITS(0, SPI_CS1_0)            // assert the CS line of the SD card to be read
        #define SET_SD_CS_HIGH()     _SETBITS(0, SPI_CS1_0)              // negate the CS line of the SD card to be read

        #define GET_SDCARD_WP_STATE() 0                                  // {18} write protection disabled (change to read switch is required)
    #endif
#endif



// Serial interfaces
//
#ifdef SERIAL_INTERFACE
    #define WELCOME_MESSAGE_UART   "\r\n\nHello, world... LPC2XXX\r\n"
    #define NUMBER_EXTERNAL_SERIAL 0                                     // {6}
    #define NUMBER_SERIAL   (UARTS_AVAILABLE)                            // the number of physical queues needed for serial interface(s)
    #define SIM_COM_EXTENDED                                             // COM ports defined from 1..255
    #define SERIAL_PORT_0   7                                            // if we open UART channel 0 we simulate using this COM port on the PC
    #define SERIAL_PORT_1   3                                            // if we open UART channel 1 we simulate using this COM port on the PC
    #define SERIAL_PORT_2   11                                           // if we open UART channel 2 we simulate using this COM port on the PC
    #define SERIAL_PORT_3   12                                           // if we open UART channel 3 we simulate using this COM port on the PC

    #if defined OLIMEX_LPC_P2103
        #define DEMO_UART        0                                       // use UART 0
    #elif  defined OLIMEX_LPC_P2148 || defined OLIMEX_LPC2378_STK
        #define DEMO_UART        0                                       // use UART 1
    #else
        #define DEMO_UART        0                                       // use UART 0
      //#define PPP_UART         1                                       // use UART 1 for PPP
    #endif
    #define MODBUS_UART_0        0
    #define MODBUS_UART_1        1
    #define MODBUS_UART_2        2
    #define MODBUS_UART_3        3
  //#define SUPPORT_HW_FLOW                                              // enable hardware flow control support
    #if defined LPC2103 || defined LPC2102 || defined LPC2101
        #define TX_BUFFER_SIZE   (512)                                   // the size of RS232 input and output buffers
        #define RX_BUFFER_SIZE   (32)
    #else
        #define TX_BUFFER_SIZE   (3*1024)                                // the size of RS232 input and output buffers
        #define RX_BUFFER_SIZE   (64)
    #endif

    #ifndef _LPC21XX
      //#define UART1_PORT2                                              // set for alternative pin uses - TXD1 and RXD1 on P2.0 and P2.1 rather than TXD1 on P0.15 and RXD1 on P0.16
      //#define UART2_PORT2                                              // TXD2 and RXD2 on P2.8 and P2.9 rather than TXD2 and RXD2 on P0.10 and P0.11
      //#define UART3_PORT0_HIGH                                         // TXD3 and RXD3 on P0.25 and P0.26 rather than TXD3 and RXD3 on P0.0 and P0.1
      //#define UART3_PORT4                                              // [only LPC24XX] TXD3 and RXD3 on P4.28 and P4.29 rather than TXD3 and RXD3 on P0.0 and P0.1
    #endif

    #ifdef SUPPORT_HW_FLOW                                               // define the ports for RTS/CTS use
        #define RTS_0_PORT_SET     FIO0SET
        #define RTS_0_PORT_CLR     FIO0CLR
        #define RTS_0_PIN          PORT0_BIT6
        #define RTS_0_PORT_DDR     FIO0DIR
        #define RTS_0_PORT         PORT_0

        #define RTS_1_PORT_SET     FIO0SET
        #define RTS_1_PORT_CLR     FIO0CLR
        #define RTS_1_PIN          PORT0_BIT7
        #define RTS_1_PORT_DDR     FIO0DIR
        #define RTS_1_PORT         PORT_0

        #define RTS_2_PORT_SET     FIO0SET
        #define RTS_2_PORT_CLR     FIO0CLR
        #define RTS_2_PIN          PORT0_BIT5
        #define RTS_2_PORT_DDR     FIO0DIR
        #define RTS_2_PORT         PORT_0

        #define RTS_3_PORT_SET     FIO0SET
        #define RTS_3_PORT_CLR     FIO0CLR
        #define RTS_3_PIN          PORT0_BIT4
        #define RTS_3_PORT_DDR     FIO0DIR
        #define RTS_3_PORT         PORT_0

        #define CTS_0_PIN          PORT2_BIT0                            // CTS can be defined on ports 0 and 2 due to their interrupt capabilitieds
        #define CTS_0_PORT_DDR     FIO2DIR
        #define CTS_0_PORT         PORT_2
        #define CTS_0_STATE        FIO2PIN
        #define CTS_0_INT_PRIORITY 5

        #define CTS_1_PIN          PORT2_BIT1
        #define CTS_1_PORT_DDR     FIO2DIR
        #define CTS_1_PORT         PORT_2
        #define CTS_1_STATE        FIO2PIN
        #define CTS_1_INT_PRIORITY 5

        #define CTS_2_PIN          PORT2_BIT2
        #define CTS_2_PORT_DDR     FIO2DIR
        #define CTS_2_PORT         PORT_2
        #define CTS_2_STATE        FIO2PIN
        #define CTS_2_INT_PRIORITY 5

        #define CTS_3_PIN          PORT2_BIT3
        #define CTS_3_PORT_DDR     FIO2DIR
        #define CTS_3_PORT         PORT_2
        #define CTS_3_STATE        FIO2PIN
        #define CTS_3_INT_PRIORITY 5
    #endif
#else
    #define TX_BUFFER_SIZE   (256)
    #define RX_BUFFER_SIZE   (256)
#endif


#define SUPPORT_TIMER                                                    // support hardware timer interrupt configuration
#if defined MODBUS_RTU && !defined SUPPORT_TIMER
    #define SUPPORT_TIMER                                                // MODBUS required HW timer in RTU mode
#endif

#define _TIMER_INTERRUPT_SETUP  TIMER_INTERRUPT_SETUP

#define MODBUS0_TIMER_CHANNEL    1
#define MODBUS1_TIMER_CHANNEL    2
#define MODBUS2_TIMER_CHANNEL    3
#define MODBUS3_TIMER_CHANNEL    2

#define SUPPORT_EXTERNAL_INTERRUPTS                                      // support code for external interrupts
    #define SUPPORT_EINT0                                                // enable individual external interrupts
    #define SUPPORT_EINT1
    #define SUPPORT_EINT2
    #define SUPPORT_EINT3                                                // note that EINT3 is shared with GPIO interrupts
//#define SUPPORT_PORT_INTERRUPTS                                        // support code for port interrupts

// I2C Interface
//
#ifdef IIC_INTERFACE
    #define OUR_IIC_CHANNEL           0                                  // use IIC0 for demo
    #define NUMBER_IIC                CHIP_HAS_IIC                       // I2C interfaces available
  //#define I2C1_PORT0_HIGH                                              // set this with LPC23XX to move IIC1 pins from P0.0/P0.1 to P0.19 and P0.20
#endif

// LAN interface
//
// !! Warning. If using chips from the first LPC23XX series (not at least revision A) do not set more than 4 RX buffers.
// !! The first chips do not operate correctly if the value is set to 5 or above.
// If only newer chips are in use it is suggested to use 7 rx buffers and 3 tx buffers (the buffers reside in the 16k Ethernet RAM)
#define LAN_BUFFER_SIZE           1536                                   // LPC23XX has ample space for full tx buffer
#ifdef _LPC24XX
    #define LAN_RX_BUF_COUNT          7                                  // rx buffer space defined to be 7 times the full buffer
    #define LAN_TX_BUF_COUNT          3
#else
    #define LAN_RX_BUF_COUNT          4                                  // rx buffer space defined to be 4 times the full buffer
    #define LAN_TX_BUF_COUNT          6
#endif

#ifdef USE_BUFFERED_TCP                                                  // if using a buffer for TCP to allow interractive data applications (like TELNET)
    #define TCP_BUFFER            2800                                   // size of TCP buffer (with USE_BUFFERED_TCP) - generous with LPC23XX
    #define TCP_BUFFER_FRAME      1400                                   // allow this max. TCP frame size
#endif

#ifdef USE_HTTP
    #define HTTP_BUFFER_LENGTH    1400                                   // we send frames with this maximum amount of payload data - generous with LPC23XX
#endif

#ifdef USE_FTP                                                           // specify FTP support details
    #define FTP_WELCOME_RESPONSE         "220 Welcome LPC2XXX FTP.\r\n"
    //                                        ^^^^^^^^^^^^^^^^^^^^          customise the FTP welcome here
#endif

#define USB_FIFO_INTERMEDIATE_BUFFER                                     // FIFO mode of operation but with an intermediate buffer

//#define USB_DMA_RX                                                     // if the processor supports USB DMA operation enable it for reception (OUT)
//#define USB_DMA_TX                                                     // if the processor supports USB DMA operation enable it for transmission (IN)

// Special support for this processor type
//
//#define DMA_MEMCPY_SET                                                 // memcpy and memset functions performed by DMA (if supported by processor - uses one DMA channel)
//#define RUN_LOOPS_IN_RAM                                               // allow certain routines with tight loops to run from SRAM where it is generally faster than from FLASH - uses slightly more SRAM


// Global Hardware Timer setup
//
#ifdef GLOBAL_TIMER_TASK
    #define HW_TIM_RES    1                                              // 1ms resolution: M5223X limit is about 19 minutes at 60MHz (1ms setting)
#endif



// Interrupt priorities [highest is 0.. lowest is 15]
//
#define ETHERNET_INTERRUPT_PRIORITY 1
#define USB_PRIORITY                2
#define TICK_INTERRUPT_PRIORITY     3
#define UART0_INTERRUPT_PRIORITY    4
#define UART1_INTERRUPT_PRIORITY    5
#define UART2_INTERRUPT_PRIORITY    6
#define UART3_INTERRUPT_PRIORITY    7
#define PRIORITY_HW_TIMER           8
#define PRIORITY_ADC                9                                    // {16}
#define IIC0_INTERRUPT_PRIORITY     10
#define IIC1_INTERRUPT_PRIORITY     11
#define IIC2_INTERRUPT_PRIORITY     12
#define PRIORITY_TIMERS             13
#define RTC_INTERRUPT_PRIORITY      14




// Ports
//
#ifdef _LPC21XX
    #define ACTIVATE_WATCHDOG()        WDTC = ((PCLK / 4) * 2); WDCLKSEL = WD_CLOCK_PCLK; WDMOD = (WDEN | WDRESET); WDFEED = 0xaa; WDFEED = 0x55; // watchdog enabled to generate reset on 2s timeout
    #define ENABLE_LED_PORT()
    #ifdef USE_MAINTENANCE
        #define INIT_WATCHDOG_LED()                                      // let the port set up do this (the user can disable blinking)
    #else
        #define INIT_WATCHDOG_LED()    _CONFIG_PORT_OUTPUT(0, (BLINK_LED))
    #endif
    #if defined OLIMEX_LPC_P2103                                         // Olimex prototype board
        #define FIRST_USER_PORT         26
        #define DEMO_LED_1             (PORT0_BIT26 >> FIRST_USER_PORT)
        #define DEMO_LED_2             (PORT0_BIT27 >> FIRST_USER_PORT)
        #define DEMO_LED_3             (PORT0_BIT28 >> FIRST_USER_PORT)
        #define DEMO_LED_4             (PORT0_BIT29 >> FIRST_USER_PORT)
        #define DEMO_USER_PORTS        (DEMO_LED_1 | DEMO_LED_2 | DEMO_LED_3 | DEMO_LED_4)
        #define BLINK_LED              ((DEMO_LED_1 << FIRST_USER_PORT) | PORT0_BIT2)
        #define BLINK_LED_OUTPUT_STATE  FIO0SET
        #define DEMO_LED_PORT_CLR       FIO0CLR
        #define DEMO_LED_PORT_SET       FIO0SET
        #define DEMO_LED_DDR            FIO0DIR
        #define DEMO_LED_PORT           FIO0PIN
        #define INIT_WATCHDOG_DISABLE()   FIO0DIR &= ~(PORT0_BIT15);     // ensure input
        #define WATCHDOG_DISABLE()        (!(FIO0PIN & PORT0_BIT15))     // pull this input down to disable watchdog
        #define TOGGLE_WATCHDOG_LED()     _TOGGLE_PORT(0, (BLINK_LED))
    #elif defined OLIMEX_LPC_P2148                                       // {11}
        #define BUTTON_B1              PORT0_BIT15
        #define BUTTON_B2              PORT0_BIT16
        #define LED1                   PORT0_BIT10
        #define LED2                   PORT0_BIT11
        #define BUZZ1                  PORT0_BIT12
        #define BUZZ2                  PORT0_BIT13

        #define FIRST_USER_PORT         10
        #define DEMO_LED_1             (PORT0_BIT10 >> FIRST_USER_PORT)
        #define DEMO_LED_2             (PORT0_BIT11 >> FIRST_USER_PORT)
        #define DEMO_LED_3             (PORT0_BIT12 >> FIRST_USER_PORT)
        #define DEMO_LED_4             (PORT0_BIT13 >> FIRST_USER_PORT)
        #define DEMO_USER_PORTS        (DEMO_LED_1 | DEMO_LED_2 | DEMO_LED_3 | DEMO_LED_4)
        #define BLINK_LED              (DEMO_LED_1 << FIRST_USER_PORT)
        #define BLINK_LED_OUTPUT_STATE  FIO0SET
        #define DEMO_LED_PORT_CLR       FIO0CLR
        #define DEMO_LED_PORT_SET       FIO0SET
        #define DEMO_LED_DDR            FIO0DIR
        #define DEMO_LED_PORT           FIO0PIN
        #define INIT_WATCHDOG_DISABLE() FIO0DIR &= ~(BUTTON_B1);         // ensure input
        #define WATCHDOG_DISABLE()      (!(FIO0PIN & BUTTON_B1))         // pull this input down (press B1) to disable watchdog
        #define TOGGLE_WATCHDOG_LED()     _TOGGLE_PORT(0, (BLINK_LED))

        // USB macros                                                    // {19}
        //
        #define SET_USB_SYMBOL()                                         // dummy - can be use to indicate when USB is active
        #define DEL_USB_SYMBOL()                                         // dummy - can be use to indicate when USB has been deactivated

        #define CONFIGURE_MOUSE_INPUTS()   _CONFIG_PORT_INPUT(0, (BUTTON_B1 | BUTTON_B2))  // configure mouse control inputs
        #define MOUSE_LEFT_CLICK()         0
        #define MOUSE_UP()                 0
        #define MOUSE_DOWN()               0
        #define MOUSE_LEFT()               (!(_READ_PORT_MASK(0, BUTTON_B1))) // press button B1 to move mouse to the left
        #define MOUSE_RIGHT()              (!(_READ_PORT_MASK(0, BUTTON_B2))) // press button B2 to move mouse to the right
    #else
        #if defined LPC2104 || defined LPC2105 || defined LPC2106        // these do not have fast IO so use legacy ports
            #define FIRST_USER_PORT         14
            #define DEMO_LED_1              (PORT0_BIT14 >> FIRST_USER_PORT)
            #define DEMO_LED_2              (PORT0_BIT15 >> FIRST_USER_PORT)
            #define DEMO_LED_3              (PORT0_BIT16 >> FIRST_USER_PORT)
            #define DEMO_LED_4              (PORT0_BIT17 >> FIRST_USER_PORT)
            #define BLINK_LED               (DEMO_LED_1 << FIRST_USER_PORT)
            #define BLINK_LED_OUTPUT_STATE  IO0SET
            #define DEMO_LED_PORT_CLR       IO0CLR
            #define DEMO_LED_PORT_SET       IO0SET
            #define DEMO_LED_DDR            IO0DIR
            #define DEMO_LED_PORT           IO0PIN
        #else
            #define DEMO_LED_1              PORT0_BIT0
            #define DEMO_LED_2              PORT0_BIT1
            #define DEMO_LED_3              PORT0_BIT2
            #define DEMO_LED_4              PORT0_BIT3
            #define BLINK_LED_OUTPUT_STATE  FIO0SET
            #define DEMO_LED_PORT_CLR       FIO0CLR
            #define DEMO_LED_PORT_SET       FIO0SET
            #define DEMO_LED_DDR            FIO0DIR
            #define DEMO_LED_PORT           FIO0PIN
            #define FIRST_USER_PORT         0
            #define BLINK_LED               DEMO_LED_1
        #endif
        #define DEMO_USER_PORTS        (DEMO_LED_1 | DEMO_LED_2 | DEMO_LED_3 | DEMO_LED_4)

        #if defined LPC2104 || defined LPC2105 || defined LPC2106        // these do not have fast IO so use legacy ports
            #define INIT_WATCHDOG_DISABLE()    IO0DIR &= ~(PORT0_BIT8);  // ensure input
            #define WATCHDOG_DISABLE()         (!(IO0PIN & PORT0_BIT8))  // pull this input down to disable watchdog
        #else
            #define INIT_WATCHDOG_DISABLE()    FIO0DIR &= ~(PORT0_BIT8); // ensure input
            #define WATCHDOG_DISABLE()         (!(FIO0PIN & PORT0_BIT8)) // pull this input down to disable watchdog
        #endif
        #define TOGGLE_WATCHDOG_LED()     _TOGGLE_PORT(0, BLINK_LED)
    #endif
#else
    #if defined OLIMEX_LPC2378_STK
        #define FIRST_USER_PORT         21
        #define DEMO_LED_1             (PORT0_BIT21 >> FIRST_USER_PORT)
        #define DEMO_LED_2             (PORT0_BIT22 >> FIRST_USER_PORT)
        #define DEMO_LED_3             (PORT0_BIT23 >> FIRST_USER_PORT)
        #define DEMO_LED_4             (PORT0_BIT24 >> FIRST_USER_PORT)
        #define DEMO_USER_PORTS        (DEMO_LED_1 | DEMO_LED_2 | DEMO_LED_3 | DEMO_LED_4)

        #define BLINK_LED               (DEMO_LED_1 << FIRST_USER_PORT)
        #define BLINK_LED_OUTPUT_STATE  FIO0SET
        #define DEMO_LED_PORT_CLR       FIO0CLR
        #define DEMO_LED_PORT_SET       FIO0SET
        #define DEMO_LED_DDR            FIO0DIR
        #define DEMO_LED_PORT           FIO0PIN

        #define INIT_WATCHDOG_DISABLE()   FIO0DIR &= ~(PORT0_BIT18);     // ensure input
        #define WATCHDOG_DISABLE()        (!(FIO0PIN & PORT0_BIT18))     // pull this input down to disable watchdog (BUT 2)
        #define TOGGLE_WATCHDOG_LED()     _TOGGLE_PORT(0, BLINK_LED)
        #ifdef USE_MAINTENANCE
            #define INIT_WATCHDOG_LED()                                  // let the port set up do this (the user can disable blinking)
        #else
            #define INIT_WATCHDOG_LED()    _CONFIG_PORT_OUTPUT(0, (BLINK_LED))
        #endif
        #define ENABLE_DPLUS_PULLUP()
        #define ENABLE_DMINUS_PULLDOWN()

        // USB macros                                                    // {19}
        //
        #define SET_USB_SYMBOL()                                         // dummy - can be use to indicate when USB is active
        #define DEL_USB_SYMBOL()                                         // dummy - can be use to indicate when USB has been deactivated

        #define CONFIGURE_MOUSE_INPUTS()                                 // configure mouse control inputs
        #define MOUSE_LEFT_CLICK()         0
        #define MOUSE_UP()                 0
        #define MOUSE_DOWN()               0
        #define MOUSE_LEFT()               0
        #define MOUSE_RIGHT()              0
    #elif defined OLIMEX_LPC2478_STK
        #define FIRST_USER_PORT         13
        #define DEMO_LED_1             (PORT1_BIT13 >> FIRST_USER_PORT)
        #define DEMO_LED_2             (PORT1_BIT14 >> FIRST_USER_PORT)
        #define DEMO_LED_3             (PORT1_BIT15 >> FIRST_USER_PORT)
        #define DEMO_LED_4             (PORT1_BIT16 >> FIRST_USER_PORT)
        #define DEMO_USER_PORTS        (DEMO_LED_1 | DEMO_LED_2 | DEMO_LED_3 | DEMO_LED_4)

        #define BLINK_LED               (DEMO_LED_1 << FIRST_USER_PORT)
        #define BLINK_LED_OUTPUT_STATE  FIO1SET
        #define DEMO_LED_PORT_CLR       FIO1CLR
        #define DEMO_LED_PORT_SET       FIO1SET
        #define DEMO_LED_DDR            FIO1DIR
        #define DEMO_LED_PORT           FIO1PIN

        #define INIT_WATCHDOG_DISABLE()   //FIO0DIR &= ~(PORT0_BIT18);   // ensure input
        #define WATCHDOG_DISABLE()      1 //(!(FIO0PIN & PORT0_BIT18))   // pull this input down to disable watchdog (always disabled)
        #define TOGGLE_WATCHDOG_LED()     _TOGGLE_PORT(1, BLINK_LED)

        #ifdef USE_MAINTENANCE
            #define INIT_WATCHDOG_LED()                                      // let the port set up do this (the user can disable blinking)
        #else
            #define INIT_WATCHDOG_LED()    _CONFIG_PORT_OUTPUT(1, (BLINK_LED))
        #endif

        #define SDRAM_SIZE             (32*1024*1024)
                                        // Olimex board mixes up USB control lines so correct here (control USB1_CONNECT as port, disable VBUS and UP_LED2 since they are not connected correctly)
      //#define ENABLE_DPLUS_PULLUP()      _CONFIG_DRIVE_PORT_OUTPUT_VALUE(1, PORT1_BIT19, 0); PINSEL0 &= ~(PINSEL0_P0_13_RESET | PINSEL0_P0_14_RESET); _CONFIG_PORT_INPUT(0, PORT0_BIT14); PINSEL3 &= ~(PINSEL3_P1_30_RESET)
        #define ENABLE_DPLUS_PULLUP()      _CONFIG_DRIVE_PORT_OUTPUT_VALUE(1, PORT1_BIT19, 0); /*PINSEL0 &= ~(PINSEL0_P0_13_RESET | PINSEL0_P0_14_RESET);*/ _CONFIG_PORT_INPUT(0, PORT0_BIT14); PINSEL3 &= ~(PINSEL3_P1_30_RESET)
        #define ENABLE_DMINUS_PULLDOWN()   
        #ifdef SUPPORT_GLCD
            #define SUPPORT_TOUCH_SCREEN                                 // enable touch screen
            #define TOUCH_HW_TIMER          1                            // use HW timer 1 as touch screen time base (1ms)
        #endif

        // USB macros                                                    // {19}
        //
        #define SET_USB_SYMBOL()                                         // dummy - can be use to indicate when USB is active
        #define DEL_USB_SYMBOL()                                         // dummy - can be use to indicate when USB has been deactivated

        #define CONFIGURE_MOUSE_INPUTS()                                 // configure mouse control inputs
        #define MOUSE_LEFT_CLICK()         0
        #define MOUSE_UP()                 0
        #define MOUSE_DOWN()               0
        #define MOUSE_LEFT()               0
        #define MOUSE_RIGHT()              0
    #else                                                                // MCB2300
        #define FIRST_USER_PORT         0
        #define DEMO_LED_1              PORT2_BIT0
        #define DEMO_LED_2              PORT2_BIT1
        #define DEMO_LED_3              PORT2_BIT2
        #define DEMO_LED_4              PORT2_BIT3
        #define DEMO_USER_PORTS        (DEMO_LED_1 | DEMO_LED_2 | DEMO_LED_3 | DEMO_LED_4)

        #define BLINK_LED               DEMO_LED_1
        #define BLINK_LED_OUTPUT_STATE  FIO2SET
        #define DEMO_LED_PORT_CLR       FIO2CLR
        #define DEMO_LED_PORT_SET       FIO2SET
        #define DEMO_LED_DDR            FIO2DIR
        #define DEMO_LED_PORT           FIO2PIN

        #define INIT_WATCHDOG_DISABLE()    FIO2DIR &= ~(PORT2_BIT8);     // ensure input
        #define WATCHDOG_DISABLE()         (!(FIO2PIN & PORT2_BIT8))     // pull this input down to disable watchdog
        #define TOGGLE_WATCHDOG_LED()     _TOGGLE_PORT(2, BLINK_LED)

        #ifdef USE_MAINTENANCE
            #define INIT_WATCHDOG_LED()                                  // let the port set up do this (the user can disable blinking)
        #else
            #define INIT_WATCHDOG_LED()    _CONFIG_PORT_OUTPUT(2, (BLINK_LED))
        #endif
        #define LPC23XX_REV_0                                            // when enabled, some workarounds for the first silicon version are activated
        #define ENABLE_DPLUS_PULLUP()      _CONFIG_DRIVE_PORT_OUTPUT_VALUE(2, PORT2_BIT9, 0)
        #define ENABLE_DMINUS_PULLDOWN()

        // USB macros                                                    // {19}
        //
        #define SET_USB_SYMBOL()                                         // dummy - can be use to indicate when USB is active
        #define DEL_USB_SYMBOL()                                         // dummy - can be use to indicate when USB has been deactivated

        #define CONFIGURE_MOUSE_INPUTS()                                 // configure mouse control inputs
        #define MOUSE_LEFT_CLICK()         0
        #define MOUSE_UP()                 0
        #define MOUSE_DOWN()               0
        #define MOUSE_LEFT()               0
        #define MOUSE_RIGHT()              0
    #endif
    #define ACTIVATE_WATCHDOG()        WDTC = ((PCLK / 4) * 2); WDCLKSEL = WD_CLOCK_PCLK; WDMOD = (WDEN | WDRESET); WDFEED = 0xaa; WDFEED = 0x55; // watchdog enabled to generate reset on 2s timeout
#endif

#define MEASURE_LOW_POWER_ON()
#define MEASURE_LOW_POWER_OFF()

#define CONFIG_TEST_OUTPUT()                                             // we use DEMO_LED_2 which is configured by the user code (and can be disabled in parameters if required)
#define TOGGLE_TEST_OUTPUT()       if (BLINK_LED_OUTPUT_STATE & DEMO_LED_2) { DEMO_LED_PORT_CLR = DEMO_LED_2; }  else {  DEMO_LED_PORT_SET = DEMO_LED_2; }

#define PORT0_DEFAULT_INPUT        0xffffffff
#define PORT1_DEFAULT_INPUT        0xffffffff
#define PORT2_DEFAULT_INPUT        0xffffffff
#define PORT3_DEFAULT_INPUT        0xffffffff
#define PORT4_DEFAULT_INPUT        0xffffffff


#ifdef _LPC21XX
    // User port mapping
    //
    #define USER_PORT_1_BIT            PORT0_BIT4                        // use free PA pins on Eval board
    #define USER_PORT_2_BIT            PORT0_BIT5
    #define USER_PORT_3_BIT            PORT0_BIT6
    #define USER_PORT_4_BIT            PORT0_BIT7
    #define USER_PORT_5_BIT            PORT0_BIT8
    #define USER_PORT_6_BIT            PORT0_BIT9
    #define USER_PORT_7_BIT            PORT0_BIT6
    #define USER_PORT_8_BIT            PORT0_BIT10
    #define USER_PORT_9_BIT            PORT0_BIT11
    #define USER_PORT_10_BIT           PORT0_BIT12
    #define USER_PORT_11_BIT           PORT0_BIT13
    #define USER_PORT_12_BIT           PORT0_BIT14
    #define USER_PORT_13_BIT           PORT0_BIT15
    #define USER_PORT_14_BIT           PORT0_BIT16
    #define USER_PORT_15_BIT           PORT0_BIT17
    #define USER_PORT_16_BIT           PORT0_BIT18

    // Port use definitions
    //

    #if defined LPC2104 || defined LPC2105 || defined LPC2106            // these do not have fast IO so use legacy ports
        #define _FIO0SET IO0SET
        #define _FIO0CLR IO0CLR
        #define _FIO0PIN IO0PIN
        #define _FIO0DIR IO0DIR
    #else
        #define _FIO0SET FIO0SET
        #define _FIO0CLR FIO0CLR
        #define _FIO0PIN FIO0PIN
        #define _FIO0DIR FIO0DIR
    #endif
    #define USER_SET_PORT_1            _FIO0SET
    #define USER_CLEAR_PORT_1          _FIO0CLR
    #define USER_PORT_1                _FIO0PIN
    #define USER_DDR_1                 _FIO0DIR
    #define USER_SET_PORT_2            _FIO0SET
    #define USER_CLEAR_PORT_2          _FIO0CLR
    #define USER_PORT_2                _FIO0PIN
    #define USER_DDR_2                 _FIO0DIR
    #define USER_SET_PORT_3            _FIO0SET
    #define USER_CLEAR_PORT_3          _FIO0CLR
    #define USER_PORT_3                _FIO0PIN
    #define USER_DDR_3                 _FIO0DIR
    #define USER_SET_PORT_4            _FIO0SET
    #define USER_CLEAR_PORT_4          _FIO0CLR
    #define USER_PORT_4                _FIO0PIN
    #define USER_DDR_4                 _FIO0DIR
    #define USER_SET_PORT_5            _FIO0SET
    #define USER_CLEAR_PORT_5          _FIO0CLR
    #define USER_PORT_5                _FIO0PIN
    #define USER_DDR_5                 _FIO0DIR
    #define USER_SET_PORT_6            _FIO0SET
    #define USER_CLEAR_PORT_6          _FIO0CLR
    #define USER_PORT_6                _FIO0PIN
    #define USER_DDR_6                 _FIO0DIR
    #define USER_SET_PORT_7            _FIO0SET
    #define USER_CLEAR_PORT_7          _FIO0CLR
    #define USER_PORT_7                _FIO0PIN
    #define USER_DDR_7                 _FIO0DIR
    #define USER_SET_PORT_8            _FIO0SET
    #define USER_CLEAR_PORT_8          _FIO0CLR
    #define USER_PORT_8                _FIO0PIN
    #define USER_DDR_8                 _FIO0DIR
    #define USER_SET_PORT_9            _FIO0SET
    #define USER_CLEAR_PORT_9          _FIO0CLR
    #define USER_PORT_9                _FIO0PIN
    #define USER_DDR_9                 _FIO0DIR
    #define USER_SET_PORT_10           _FIO0SET
    #define USER_CLEAR_PORT_10         _FIO0CLR
    #define USER_PORT_10               _FIO0PIN
    #define USER_DDR_10                _FIO0DIR
    #define USER_SET_PORT_11           _FIO0SET
    #define USER_CLEAR_PORT_11         _FIO0CLR
    #define USER_PORT_11               _FIO0PIN
    #define USER_DDR_11                _FIO0DIR
    #define USER_SET_PORT_12           _FIO0SET
    #define USER_CLEAR_PORT_12         _FIO0CLR
    #define USER_PORT_12               _FIO0PIN
    #define USER_DDR_12                _FIO0DIR
    #define USER_SET_PORT_13           _FIO0SET
    #define USER_CLEAR_PORT_13         _FIO0CLR
    #define USER_PORT_13               _FIO0PIN
    #define USER_DDR_13                _FIO0DIR
    #define USER_SET_PORT_14           _FIO0SET
    #define USER_CLEAR_PORT_14         _FIO0CLR
    #define USER_PORT_14               _FIO0PIN
    #define USER_DDR_14                _FIO0DIR
    #define USER_SET_PORT_15           _FIO0SET
    #define USER_CLEAR_PORT_15         _FIO0CLR
    #define USER_PORT_15               _FIO0PIN
    #define USER_DDR_15                _FIO0DIR
    #define USER_SET_PORT_16           _FIO0SET
    #define USER_CLEAR_PORT_16         _FIO0CLR
    #define USER_PORT_16               _FIO0PIN
    #define USER_DDR_16                _FIO0DIR
#elif defined _LPC24XX
    // User port mapping
    //
    #define USER_PORT_1_BIT            PORT0_BIT10                        // use free PA pins on Eval board
    #define USER_PORT_2_BIT            PORT0_BIT11
    #define USER_PORT_3_BIT            PORT0_BIT12
    #define USER_PORT_4_BIT            PORT0_BIT13
    #define USER_PORT_5_BIT            PORT0_BIT14
    #define USER_PORT_6_BIT            PORT0_BIT15
    #define USER_PORT_7_BIT            PORT0_BIT16
    #define USER_PORT_8_BIT            PORT0_BIT17
    #define USER_PORT_9_BIT            PORT0_BIT18
    #define USER_PORT_10_BIT           PORT0_BIT19
    #define USER_PORT_11_BIT           PORT0_BIT20
    #define USER_PORT_12_BIT           PORT0_BIT21
    #define USER_PORT_13_BIT           PORT0_BIT22
    #define USER_PORT_14_BIT           PORT0_BIT23
    #define USER_PORT_15_BIT           PORT0_BIT24
    #define USER_PORT_16_BIT           PORT0_BIT25

    // Port use definitions
    //
    #define USER_SET_PORT_1            FIO0SET
    #define USER_CLEAR_PORT_1          FIO0CLR
    #define USER_PORT_1                FIO0PIN
    #define USER_DDR_1                 FIO0DIR
    #define USER_SET_PORT_2            FIO0SET
    #define USER_CLEAR_PORT_2          FIO0CLR
    #define USER_PORT_2                FIO0PIN
    #define USER_DDR_2                 FIO0DIR
    #define USER_SET_PORT_3            FIO0SET
    #define USER_CLEAR_PORT_3          FIO0CLR
    #define USER_PORT_3                FIO0PIN
    #define USER_DDR_3                 FIO0DIR
    #define USER_SET_PORT_4            FIO0SET
    #define USER_CLEAR_PORT_4          FIO0CLR
    #define USER_PORT_4                FIO0PIN
    #define USER_DDR_4                 FIO0DIR
    #define USER_SET_PORT_5            FIO0SET
    #define USER_CLEAR_PORT_5          FIO0CLR
    #define USER_PORT_5                FIO0PIN
    #define USER_DDR_5                 FIO0DIR
    #define USER_SET_PORT_6            FIO0SET
    #define USER_CLEAR_PORT_6          FIO0CLR
    #define USER_PORT_6                FIO0PIN
    #define USER_DDR_6                 FIO0DIR
    #define USER_SET_PORT_7            FIO0SET
    #define USER_CLEAR_PORT_7          FIO0CLR
    #define USER_PORT_7                FIO0PIN
    #define USER_DDR_7                 FIO0DIR
    #define USER_SET_PORT_8            FIO0SET
    #define USER_CLEAR_PORT_8          FIO0CLR
    #define USER_PORT_8                FIO0PIN
    #define USER_DDR_8                 FIO0DIR
    #define USER_SET_PORT_9            FIO0SET
    #define USER_CLEAR_PORT_9          FIO0CLR
    #define USER_PORT_9                FIO0PIN
    #define USER_DDR_9                 FIO0DIR
    #define USER_SET_PORT_10           FIO0SET
    #define USER_CLEAR_PORT_10         FIO0CLR
    #define USER_PORT_10               FIO0PIN
    #define USER_DDR_10                FIO0DIR
    #define USER_SET_PORT_11           FIO0SET
    #define USER_CLEAR_PORT_11         FIO0CLR
    #define USER_PORT_11               FIO0PIN
    #define USER_DDR_11                FIO0DIR
    #define USER_SET_PORT_12           FIO0SET
    #define USER_CLEAR_PORT_12         FIO0CLR
    #define USER_PORT_12               FIO0PIN
    #define USER_DDR_12                FIO0DIR
    #define USER_SET_PORT_13           FIO0SET
    #define USER_CLEAR_PORT_13         FIO0CLR
    #define USER_PORT_13               FIO0PIN
    #define USER_DDR_13                FIO0DIR
    #define USER_SET_PORT_14           FIO0SET
    #define USER_CLEAR_PORT_14         FIO0CLR
    #define USER_PORT_14               FIO0PIN
    #define USER_DDR_14                FIO0DIR
    #define USER_SET_PORT_15           FIO0SET
    #define USER_CLEAR_PORT_15         FIO0CLR
    #define USER_PORT_15               FIO0PIN
    #define USER_DDR_15                FIO0DIR
    #define USER_SET_PORT_16           FIO0SET
    #define USER_CLEAR_PORT_16         FIO0CLR
    #define USER_PORT_16               FIO0PIN
    #define USER_DDR_16                FIO0DIR
#else                                                                    // LPC23XX
    // User port mapping
    //
    #define USER_PORT_1_BIT            PORT4_BIT0                        // use free PA pins on Eval board
    #define USER_PORT_2_BIT            PORT4_BIT1
    #define USER_PORT_3_BIT            PORT4_BIT2
    #define USER_PORT_4_BIT            PORT4_BIT3
    #define USER_PORT_5_BIT            PORT4_BIT4
    #define USER_PORT_6_BIT            PORT4_BIT5
    #define USER_PORT_7_BIT            PORT4_BIT6
    #define USER_PORT_8_BIT            PORT4_BIT7
    #define USER_PORT_9_BIT            PORT4_BIT8
    #define USER_PORT_10_BIT           PORT4_BIT9
    #define USER_PORT_11_BIT           PORT4_BIT10
    #define USER_PORT_12_BIT           PORT4_BIT11
    #define USER_PORT_13_BIT           PORT4_BIT12
    #define USER_PORT_14_BIT           PORT4_BIT13
    #define USER_PORT_15_BIT           PORT4_BIT14
    #define USER_PORT_16_BIT           PORT4_BIT15

    // Port use definitions
    //
    #define USER_SET_PORT_1            FIO4SET
    #define USER_CLEAR_PORT_1          FIO4CLR
    #define USER_PORT_1                FIO4PIN
    #define USER_DDR_1                 FIO4DIR
    #define USER_SET_PORT_2            FIO4SET
    #define USER_CLEAR_PORT_2          FIO4CLR
    #define USER_PORT_2                FIO4PIN
    #define USER_DDR_2                 FIO4DIR
    #define USER_SET_PORT_3            FIO4SET
    #define USER_CLEAR_PORT_3          FIO4CLR
    #define USER_PORT_3                FIO4PIN
    #define USER_DDR_3                 FIO4DIR
    #define USER_SET_PORT_4            FIO4SET
    #define USER_CLEAR_PORT_4          FIO4CLR
    #define USER_PORT_4                FIO4PIN
    #define USER_DDR_4                 FIO4DIR
    #define USER_SET_PORT_5            FIO4SET
    #define USER_CLEAR_PORT_5          FIO4CLR
    #define USER_PORT_5                FIO4PIN
    #define USER_DDR_5                 FIO4DIR
    #define USER_SET_PORT_6            FIO4SET
    #define USER_CLEAR_PORT_6          FIO4CLR
    #define USER_PORT_6                FIO4PIN
    #define USER_DDR_6                 FIO4DIR
    #define USER_SET_PORT_7            FIO4SET
    #define USER_CLEAR_PORT_7          FIO4CLR
    #define USER_PORT_7                FIO4PIN
    #define USER_DDR_7                 FIO4DIR
    #define USER_SET_PORT_8            FIO4SET
    #define USER_CLEAR_PORT_8          FIO4CLR
    #define USER_PORT_8                FIO4PIN
    #define USER_DDR_8                 FIO4DIR
    #define USER_SET_PORT_9            FIO4SET
    #define USER_CLEAR_PORT_9          FIO4CLR
    #define USER_PORT_9                FIO4PIN
    #define USER_DDR_9                 FIO4DIR
    #define USER_SET_PORT_10           FIO4SET
    #define USER_CLEAR_PORT_10         FIO4CLR
    #define USER_PORT_10               FIO4PIN
    #define USER_DDR_10                FIO4DIR
    #define USER_SET_PORT_11           FIO4SET
    #define USER_CLEAR_PORT_11         FIO4CLR
    #define USER_PORT_11               FIO4PIN
    #define USER_DDR_11                FIO4DIR
    #define USER_SET_PORT_12           FIO4SET
    #define USER_CLEAR_PORT_12         FIO4CLR
    #define USER_PORT_12               FIO4PIN
    #define USER_DDR_12                FIO4DIR
    #define USER_SET_PORT_13           FIO4SET
    #define USER_CLEAR_PORT_13         FIO4CLR
    #define USER_PORT_13               FIO4PIN
    #define USER_DDR_13                FIO4DIR
    #define USER_SET_PORT_14           FIO4SET
    #define USER_CLEAR_PORT_14         FIO4CLR
    #define USER_PORT_14               FIO4PIN
    #define USER_DDR_14                FIO4DIR
    #define USER_SET_PORT_15           FIO4SET
    #define USER_CLEAR_PORT_15         FIO4CLR
    #define USER_PORT_15               FIO4PIN
    #define USER_DDR_15                FIO4DIR
    #define USER_SET_PORT_16           FIO4SET
    #define USER_CLEAR_PORT_16         FIO4CLR
    #define USER_PORT_16               FIO4PIN
    #define USER_DDR_16                FIO4DIR
#endif

#define CONFIG_TIMER_TEST_LEDS()   
#define TIMER_TEST_LED_ON()        
#define TIMER_TEST_LED2_ON()       
#define TIMER_TEST_LED_OFF()       
#define TIMER_TEST_LED2_OFF()  

#ifdef _LPC21XX
    // LCD interface: on IAR kickstart card: Data bus (4 Bit) P0.24..P0.27 : RS P0.28, RW P0.29, E P0.31, Backlight P0.30
    //
    typedef unsigned long LCD_BUS_PORT_SIZE;                             // we use 32 bit ports
    typedef unsigned long LCD_CONTROL_PORT_SIZE;
  //#define LCD_BUS_8BIT                                                 // data bus in 8 bit mode
    #define LCD_BUS_4BIT                                                 // data bus in 4 bit mode

    #ifdef LCD_BUS_8BIT
        #define LCD_BUS_MASK         0x7f800000
        #define DATA_SHIFT_RIGHT     0    
        #define DATA_SHIFT_LEFT      23                                  // byte shift down required to bring data into position
    #else
        #define LCD_BUS_MASK         0x0f000000
        #define DATA_SHIFT_RIGHT     0                                   
        #define DATA_SHIFT_LEFT      20                                  // nibble shift down required to bring data into position
    #endif

    #define O_CONTROL_RS             PORT0_BIT28
    #define O_WRITE_READ             PORT0_BIT29
    #define O_CONTROL_EN             PORT0_BIT31
    #define O_LCD_BACKLIGHT          PORT0_BIT30

    #define O_CONTROL_LINES         (O_CONTROL_RS | O_WRITE_READ | O_CONTROL_EN)
    #define IO_BUS_PORT_DAT_IN      _FIO0PIN

    #define SET_DATA_LINES_INPUT()  _CONFIG_PORT_INPUT(0, LCD_BUS_MASK)
    #define SET_DATA_LINES_OUTPUT() _DRIVE_PORT_OUTPUT(0, LCD_BUS_MASK)
    #define SET_CONTROL_LINES_OUTPUT(x) _CONFIG_PORT_OUTPUT(0, x)
    #define SET_BUS_DATA(x)         _WRITE_PORT_MASK(0, x, LCD_BUS_MASK)
    #define SET_CONTROL_LINES(x)    _WRITE_PORT_MASK(0, x, O_CONTROL_LINES)
    #define O_SET_CONTROL_LOW(x)    _CLEARBITS(0, x)
    #define O_SET_CONTROL_HIGH(x)   _CLEARBITS(0, x)

    // Drive the control lines R/W + LCD Backlight '1', RS + E '0' and the data lines with all high impedance at start up
    // enable clocks to port first
    #define INITIALISE_LCD_CONTROL_LINES()       SET_DATA_LINES_INPUT(); \
                                                 O_SET_CONTROL_LOW(O_CONTROL_LINES); O_SET_CONTROL_HIGH(O_LCD_BACKLIGHT); \
                                                 _SIM_PORTS; SET_CONTROL_LINES_OUTPUT(O_CONTROL_LINES | O_LCD_BACKLIGHT);

    #define LCD_DRIVE_DATA()          SET_DATA_LINES_OUTPUT();  SET_DATA_LINES_OUTPUT();
                                      // ensure data bus outputs (delay) by repetitions according to processor speed

    #define CLOCK_EN_HIGH()           O_SET_CONTROL_HIGH(O_CONTROL_EN); O_SET_CONTROL_HIGH(O_CONTROL_EN);
                                      // clock EN to high state - repreat to slow down (delay)

    #define DELAY_ENABLE_CLOCK_HIGH()


    // Monochrome graphic LCD
    //
    #if defined _GLCD_SAMSUNG                                            // {4}
        #define DATA_LINES             (PORT0_BIT27 | PORT0_BIT26 | PORT0_BIT25 | PORT0_BIT24 | PORT0_BIT23 | PORT0_BIT22 | PORT0_BIT21 | PORT0_BIT20)
        #define DATA_SHIFT             20

        #define GLCD_RST               PORT0_BIT31                       // reset
        #define GLCD_RS                PORT0_BIT30                       // GLCD Register Select
        #define GLCD_RW                PORT0_BIT4                        // GLCD Read/Write
        #define GLCD_ENA               PORT0_BIT3                        // GLCD Enable

        #define GLCD_CS0               PORT0_BIT13                       // LCD Controller 0 Chip Select - 2 controller chips for 128 x 64
        #define GLCD_CS1               PORT0_BIT12                       // LCD Controller 1 Chip Select

        #define SET_PULL_DOWNS()       
        #define REMOVE_PULL_DOWNS()    

        #define CONFIGURE_GLCD()       _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, (GLCD_RST | GLCD_RW | GLCD_ENA | GLCD_RS | GLCD_CS0 | GLCD_CS1), (GLCD_RW)); _CONFIG_PORT_INPUT(0, DATA_LINES);

        #define GLCD_DATAASOUTPUT()    _DRIVE_PORT_OUTPUT(0, DATA_LINES)
        #define GLCD_DATAASINPUT()     _FLOAT_PORT(0, DATA_LINES)

        #define GLCD_DATAOUT(data)     _WRITE_PORT_MASK(0, (data << DATA_SHIFT), DATA_LINES) 
        #define GLCD_DATAIN()          ((IO0PIN & (DATA_LINES)) >> DATA_SHIFT) 

        #define GLCD_RS_H()            _SETBITS(0, GLCD_RS)
        #define GLCD_RS_L()            _CLEARBITS(0, GLCD_RS)

        #define GLCD_RW_H()            _SETBITS(0, GLCD_RW)
        #define GLCD_RW_L()            _CLEARBITS(0, GLCD_RW)

        #define GLCD_CS0_H()           _SETBITS(0, GLCD_CS0)  
        #define GLCD_CS0_L()           _CLEARBITS(0, GLCD_CS0)

        #define GLCD_CS1_H()           _SETBITS(0, GLCD_CS1)  
        #define GLCD_CS1_L()           _CLEARBITS(0, GLCD_CS1)

        #define GLCD_DELAY_WRITE()                                       // no write delay since the data is stable for long enough at full speed
        #define GLCD_DELAY_READ()      GLCD_RW_H()                       // one extra operation to ensure set up time of read

        #define GLCD_RST_H()           _SETBITS(0, GLCD_RST)
        #define GLCD_RST_L()           _CLEARBITS(0, GLCD_RST)

        #define GLCD_ENA_H()           _SETBITS(0, GLCD_ENA)  
        #define GLCD_ENA_L()           _CLEARBITS(0, GLCD_ENA)

        #ifdef _WINDOWS
            #define MAX_GLCD_WRITE_BURST   1000                          // the maximum number of writes to the GLCD before the task yields
        #else
            #define MAX_GLCD_WRITE_BURST   80                            // the maximum number of writes to the GLCD before the task yields
        #endif
    #else
        #define DATA_LINES             (PORT0_BIT27 | PORT0_BIT26 | PORT0_BIT25 | PORT0_BIT24 | PORT0_BIT23 | PORT0_BIT22 | PORT0_BIT21 | PORT0_BIT20)
        #define DATA_SHIFT             20
        #define GLCD_RST               PORT0_BIT31
        #define GLCD_C_D               PORT0_BIT30
        #define GLCD_WR                PORT0_BIT4
        #define GLCD_RD                PORT0_BIT3
        #define CONFIGURE_GLCD()       _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, (GLCD_RST | GLCD_WR | GLCD_RD | GLCD_C_D), (GLCD_WR | GLCD_RD | GLCD_C_D)); _CONFIG_PORT_INPUT(0, DATA_LINES);

        #define GLCD_DATAASOUTPUT()    _DRIVE_PORT_OUTPUT(0, DATA_LINES)
        #define GLCD_DATAASINPUT()     _FLOAT_PORT(0, DATA_LINES)

        #define GLCD_DATAOUT(data)     _WRITE_PORT_MASK(0, (data << DATA_SHIFT), DATA_LINES) 
        #define GLCD_DATAIN()          ((IO0PIN & (DATA_LINES)) >> DATA_SHIFT) 

        #define SET_PULL_DOWNS()       
        #define REMOVE_PULL_DOWNS()    

        #define GLCD_WR_H()            _SETBITS(0, GLCD_WR)
        #define GLCD_WR_L()            _CLEARBITS(0, GLCD_WR)

        #define GLCD_CD_H()            _SETBITS(0, GLCD_C_D)
        #define GLCD_CD_L()            _CLEARBITS(0, GLCD_C_D)

        #define GLCD_RD_H()            _SETBITS(0, GLCD_RD)
        #define GLCD_RD_L()            _CLEARBITS(0, GLCD_RD)

        #define GLCD_DELAY_WRITE()     //GLCD_WR_L()                     // no write delay since the data is stable for long enough at full speed
        #define GLCD_DELAY_READ()      GLCD_RD_L()                       // one extra operation to ensure set up time of read

        #define GLCD_RST_H()           _SETBITS(0, GLCD_RST)
        #define GLCD_RST_L()           _CLEARBITS(0, GLCD_RST)

        #ifdef _WINDOWS
            #define MAX_GLCD_WRITE_BURST   1000                          // the maximum number of writes to the GLCD before the task yields
        #else
            #define MAX_GLCD_WRITE_BURST   20                            // the maximum number of writes to the GLCD before the task yields
        #endif
    #endif
#else
    #define LCD_CONTRAST_CONTROL                                         // use electronic contrast control
    #define SUPPORT_PWM_MODULE                                           // enable PWM module support for contrast and backlight control
        #define _LCD_CONTRAST_TIMER          PWM1                        // use PWM module
        #define _LCD_CONTRAST_TIMER_MODE_OF_OPERATION (TIMER_PWM_1 | PWM_OUTPUT_PORT_1) // use PWM channel 1 on port 1 output location
        #define _LCD_CONTRAST_PWM_FREQUENCY  TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(10000)) // 10000 Hz contrast frequency

    #define LCD_BACKLIGHT_CONTROL                                        // use electronic backlight control
        #define _LCD_BACKLIGHT_TIMER         PWM1                        // use PWM module
        #define _LCD_BACKLIGHT_TIMER_MODE_OF_OPERATION (TIMER_PWM_2 | PWM_OUTPUT_PORT_1) // use PWM channel 1 on port 1 output location
        #define _LCD_BACKLIGHT_PWM_FREQUENCY  TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(150)) // 150 Hz backlight frequency

    // LCD interface: on MCB2300 board Data bus (4 Bit) P1.24..P1.27 : RS P1.28, RW P1.29, E P1.31, Backlight P1.30
    //
    typedef unsigned long LCD_BUS_PORT_SIZE;                             // we use 32 bit ports
    typedef unsigned long LCD_CONTROL_PORT_SIZE;
  //#define LCD_BUS_8BIT                                                 // data bus in 8 bit mode
    #define LCD_BUS_4BIT                                                 // data bus in 4 bit mode

    #ifdef LCD_BUS_8BIT
        #define LCD_BUS_MASK      0x7f800000
        #define DATA_SHIFT_RIGHT     0    
        #define DATA_SHIFT_LEFT      23                                  // byte shift down required to bring data into position
    #else
        #define LCD_BUS_MASK      0x0f000000
        #define DATA_SHIFT_RIGHT     0                                   
        #define DATA_SHIFT_LEFT      20                                  // nibble shift down required to bring data into position
    #endif

    #define O_CONTROL_RS            PORT1_BIT28
    #define O_WRITE_READ            PORT1_BIT29
    #define O_CONTROL_EN            PORT1_BIT31
    #define O_LCD_BACKLIGHT         PORT1_BIT30

    #define O_CONTROL_LINES         (O_CONTROL_RS | O_WRITE_READ | O_CONTROL_EN)
    #define IO_BUS_PORT_DAT_IN      FIO1PIN

    #define SET_DATA_LINES_INPUT()  _CONFIG_PORT_INPUT(1, LCD_BUS_MASK)
    #define SET_DATA_LINES_OUTPUT() _DRIVE_PORT_OUTPUT(1, LCD_BUS_MASK)
    #define SET_CONTROL_LINES_OUTPUT(x) _CONFIG_PORT_OUTPUT(1, x)
    #define SET_BUS_DATA(x)         _WRITE_PORT_MASK(1, x,  LCD_BUS_MASK)
    #define SET_CONTROL_LINES(x)    _WRITE_PORT_MASK(1, x, O_CONTROL_LINES)
    #define O_SET_CONTROL_LOW(x)    _CLEARBITS(1, x); _CLEARBITS(1, x); _CLEARBITS(1, x); _CLEARBITS(1, x); _CLEARBITS(1, x); _CLEARBITS(1, x); _CLEARBITS(1, x); _CLEARBITS(1, x); _SIM_PORTS;
    #define O_SET_CONTROL_HIGH(x)   _SETBITS(1, x); _SETBITS(1, x); _SETBITS(1, x); _SETBITS(1, x); _SETBITS(1, x); _SETBITS(1, x); _SETBITS(1, x); _SETBITS(1, x); _SIM_PORTS;

    // Drive the control lines R/W + LCD Backlight '1', RS + E '0' and the data lines with all high impedance at start up
    // enable clocks to port first
    #define INITIALISE_LCD_CONTROL_LINES()       SET_DATA_LINES_INPUT(); \
                                                 O_SET_CONTROL_LOW(O_CONTROL_LINES); O_SET_CONTROL_HIGH(O_LCD_BACKLIGHT); \
                                                 _SIM_PORTS; SET_CONTROL_LINES_OUTPUT(O_CONTROL_LINES | O_LCD_BACKLIGHT);

    #define LCD_DRIVE_DATA()       SET_DATA_LINES_OUTPUT();  SET_DATA_LINES_OUTPUT(); SET_DATA_LINES_OUTPUT(); SET_DATA_LINES_OUTPUT(); SET_DATA_LINES_OUTPUT(); SET_DATA_LINES_OUTPUT(); SET_DATA_LINES_OUTPUT(); SET_DATA_LINES_OUTPUT();
                                   // ensure data bus outputs (delay) by repetitions according to processor speed

    #define CLOCK_EN_HIGH()        O_SET_CONTROL_HIGH(O_CONTROL_EN);
                                   // clock EN to high state - repreat to slow down (delay)

    #define DELAY_ENABLE_CLOCK_HIGH() O_SET_CONTROL_LOW(O_CONTROL_EN);


    // Monochrome graphic LCD
    //
    #define DATA_LINES             (PORT3_BIT7 | PORT3_BIT6 | PORT3_BIT5 | PORT3_BIT4 | PORT3_BIT3 | PORT3_BIT2 | PORT3_BIT1 | PORT3_BIT0)
    #if defined NOKIA_GLCD_MODE                                          // {32} backlight and reset
        #define GLCD_RST           PORT3_BIT25
        #define CONFIGURE_GLCD()   _CONFIG_DRIVE_PORT_OUTPUT_VALUE(1, PORT1_BIT26, 0); _CONFIG_DRIVE_PORT_OUTPUT_VALUE(3, GLCD_RST, 0);
        #define GLCD_RST_H()       _SETBITS(3, GLCD_RST)
        #define GLCD_RST_L()       _CLEARBITS(3, GLCD_RST)
        #define ENABLE_BACKLIGHT() _SETBITS(1, PORT1_BIT26)
        #ifdef _WINDOWS
            #define MAX_GLCD_WRITE_BURST   1000                          // the maximum number of writes to the GLCD before the task yields
        #else
            #define MAX_GLCD_WRITE_BURST   70                            // the maximum number of writes to the GLCD before the task yields
        #endif
    #elif defined _GLCD_SAMSUNG                                          // {4}
        #define GLCD_RST           PORT1_BIT31                           // reset
        #define GLCD_RS            PORT1_BIT30                           // GLCD Register Select
        #define GLCD_RW            PORT1_BIT29                           // GLCD Read/Write
        #define GLCD_ENA           PORT1_BIT28                           // GLCD Enable

        #define GLCD_CS0           PORT1_BIT27                           // LCD Controller 0 Chip Select - 2 controller chips for 128 x 64
        #define GLCD_CS1           PORT1_BIT26                           // LCD Controller 1 Chip Select

        #define CONFIGURE_GLCD()   _CONFIG_DRIVE_PORT_OUTPUT_VALUE(1, (GLCD_RST | GLCD_RW | GLCD_ENA | GLCD_RS | GLCD_CS0 | GLCD_CS1), (GLCD_RW)); _CONFIG_PORT_INPUT(3, DATA_LINES);

        #define GLCD_RS_H()        _SETBITS(1, GLCD_RS)
        #define GLCD_RS_L()        _CLEARBITS(1, GLCD_RS)

        #define GLCD_RW_H()        _SETBITS(1, GLCD_RW)
        #define GLCD_RW_L()        _CLEARBITS(1, GLCD_RW)

        #define GLCD_CS0_H()       _SETBITS(1, GLCD_CS0)  
        #define GLCD_CS0_L()       _CLEARBITS(1, GLCD_CS0)

        #define GLCD_CS1_H()       _SETBITS(1, GLCD_CS1)  
        #define GLCD_CS1_L()       _CLEARBITS(1, GLCD_CS1)

        #define GLCD_DELAY_WRITE()                                       // no write delay since the data is stable for long enough at full speed
        #define GLCD_DELAY_READ()  GLCD_RW_H()                           // one extra operation to ensure set up time of read

        #define GLCD_RST_H()       _SETBITS(1, GLCD_RST)
        #define GLCD_RST_L()       _CLEARBITS(1, GLCD_RST)

        #define GLCD_ENA_H()       _SETBITS(1, GLCD_ENA)  
        #define GLCD_ENA_L()       _CLEARBITS(1, GLCD_ENA)

        #ifdef _WINDOWS
            #define MAX_GLCD_WRITE_BURST   1000                          // the maximum number of writes to the GLCD before the task yields
        #else
            #define MAX_GLCD_WRITE_BURST   80                            // the maximum number of writes to the GLCD before the task yields
        #endif
    #else                                                                // Toshiba type GLCD
        #define GLCD_RST           PORT1_BIT31
        #define GLCD_C_D           PORT1_BIT30
        #define GLCD_WR            PORT1_BIT29
        #define GLCD_RD            PORT1_BIT28
        #define CONFIGURE_GLCD()   _CONFIG_DRIVE_PORT_OUTPUT_VALUE(1, (GLCD_RST | GLCD_WR | GLCD_RD | GLCD_C_D), (GLCD_WR | GLCD_RD | GLCD_C_D)); _CONFIG_PORT_INPUT(3, DATA_LINES);
        #define GLCD_RST_H()       _SETBITS(1, GLCD_RST)
        #define GLCD_RST_L()       _CLEARBITS(1, GLCD_RST)

        #define GLCD_WR_H()        _SETBITS(1, GLCD_WR)
        #define GLCD_WR_L()        _CLEARBITS(1, GLCD_WR)

        #define GLCD_CD_H()        _SETBITS(1, GLCD_C_D)
        #define GLCD_CD_L()        _CLEARBITS(1, GLCD_C_D)

        #define GLCD_RD_H()        _SETBITS(1, GLCD_RD)
        #define GLCD_RD_L()        _CLEARBITS(1, GLCD_RD)

        #define GLCD_DELAY_WRITE() //GLCD_WR_L()                         // no write delay since the data is stable for long enough at full speed
        #define GLCD_DELAY_READ()  GLCD_RD_L()                           // one extra operation to ensure set up time of read

        #ifdef _WINDOWS
            #define MAX_GLCD_WRITE_BURST   1000                          // the maximum number of writes to the GLCD before the task yields
        #else
            #define MAX_GLCD_WRITE_BURST   20                            // the maximum number of writes to the GLCD before the task yields
        #endif
    #endif

    #define GLCD_DATAASOUTPUT()    _DRIVE_PORT_OUTPUT(3, DATA_LINES)
    #define GLCD_DATAASINPUT()     _FLOAT_PORT(3, DATA_LINES)

    #define GLCD_DATAOUT(data)     _WRITE_PORT_MASK(3, data, DATA_LINES) 
    #define GLCD_DATAIN()          _READ_PORT(3)

    #define SET_PULL_DOWNS()       
    #define REMOVE_PULL_DOWNS()    
#endif

#if defined OLIMEX_LPC2478_STK && defined SUPPORT_TOUCH_SCREEN && !defined SUPPORT_ADC // {16}
    #define SUPPORT_ADC                                                  // enable ADC support for touch screen
#endif


// Keypad                                                                // {1}
//
#if defined KEY_COLUMNS && KEY_COLUMNS > 0                               // matrix keypad
    #define KEY_ROW_IN_1              PORT1_BIT17
    #define KEY_ROW_IN_PORT_1         FIO0PIN
    #define KEY_ROW_IN_PORT_1_REF     _PORT0

    #define KEY_ROW_IN_2              PORT1_BIT18
    #define KEY_ROW_IN_PORT_2         FIO0PIN
    #define KEY_ROW_IN_PORT_2_REF     _PORT0

    #define KEY_ROW_IN_3              PORT1_BIT19
    #define KEY_ROW_IN_PORT_3         FIO0PIN
    #define KEY_ROW_IN_PORT_3_REF     _PORT0

    #define KEY_ROW_IN_4              PORT1_BIT20
    #define KEY_ROW_IN_PORT_4         FIO0PIN
    #define KEY_ROW_IN_PORT_4_REF     _PORT0

    #define KEY_COL_OUT_1             PORT1_BIT21
    #define KEY_COL_OUT_PORT_1        FIO0SET
    #define KEY_COL_OUT_DDR_1         FIO0DIR

    #define KEY_COL_OUT_2             PORT1_BIT22
    #define KEY_COL_OUT_PORT_2        FIO0SET
    #define KEY_COL_OUT_DDR_2         FIO0DIR

    #define KEY_COL_OUT_3             PORT1_BIT23
    #define KEY_COL_OUT_PORT_3        FIO0SET
    #define KEY_COL_OUT_DDR_3         FIO0DIR

    #define KEY_COL_OUT_4             PORT1_BIT24
    #define KEY_COL_OUT_PORT_4        FIO0SET
    #define KEY_COL_OUT_DDR_4         FIO0DIR

    // Drive each column low
    //
    #define DRIVE_COLUMN_1()     _DRIVE_PORT_OUTPUT(0, KEY_COL_OUT_1)    // drive output low (column 1) - this will drive a '0' since the output has been prepared
    #define DRIVE_COLUMN_2()     _DRIVE_PORT_OUTPUT(0, KEY_COL_OUT_2)    // drive output low (column 2) - this will drive a '0' since the output has been prepared
    #define DRIVE_COLUMN_3()     _DRIVE_PORT_OUTPUT(0, KEY_COL_OUT_3)    // drive output low (column 3) - this will drive a '0' since the output has been prepared
    #define DRIVE_COLUMN_4()     _DRIVE_PORT_OUTPUT(0, KEY_COL_OUT_4)    // drive output low (column 4) - this will drive a '0' since the output has been prepared

    // Drive high (to avoid slow rise time) then set back as input
    //
    #define RELEASE_COLUMN_1()   _SETBITS(0, KEY_COL_OUT_1); _FLOAT_PORT(0, KEY_COL_OUT_1)
    #define RELEASE_COLUMN_2()   _SETBITS(0, KEY_COL_OUT_2); _FLOAT_PORT(0, KEY_COL_OUT_2)
    #define RELEASE_COLUMN_3()   _SETBITS(0, KEY_COL_OUT_3); _FLOAT_PORT(0, KEY_COL_OUT_3)
    #define RELEASE_COLUMN_4()   _SETBITS(0, KEY_COL_OUT_4); _FLOAT_PORT(0, KEY_COL_OUT_4)

    // Reset any changes ready for next scan sequence
    //
    #define RESET_SCAN()         _CLEARBITS(0, (KEY_COL_OUT_1 | KEY_COL_OUT_2 | KEY_COL_OUT_3 | KEY_COL_OUT_4)); // prepare outputs low for next time

    // Key scan initialisation
    //
    #define INIT_KEY_SCAN()      _CONFIG_PORT_INPUT(0, (KEY_COL_OUT_1 | KEY_COL_OUT_2 | KEY_COL_OUT_3 | KEY_COL_OUT_4)); \
                                 RESET_SCAN()
#elif defined KEY_COLUMNS && KEY_COLUMNS == 0
    #define KEY_ROW_IN_1              PORT1_BIT17
    #define KEY_ROW_IN_2              PORT1_BIT18
    #define KEY_ROW_IN_3              PORT1_BIT19
    #define KEY_ROW_IN_4              PORT1_BIT20

    #define KEY_1_PORT_REF            _PORT0
    #define KEY_1_PORT_PIN            KEY_ROW_IN_1

    #define KEY_5_PORT_REF            _PORT0
    #define KEY_5_PORT_PIN            KEY_ROW_IN_2

    #define KEY_2_PORT_REF            _PORT0
    #define KEY_2_PORT_PIN            KEY_ROW_IN_4

    #define KEY_9_PORT_REF            _PORT0
    #define KEY_9_PORT_PIN            KEY_ROW_IN_3

    #define INIT_KEY_STATE            0x0000000f

    #define READ_KEY_INPUTS()         (_READ_PORT_MASK(0, (KEY_ROW_IN_1 | KEY_ROW_IN_2 | KEY_ROW_IN_3 | KEY_ROW_IN_4)) >> 17)

    #define INIT_KEY_SCAN()           _CONFIG_PORT_INPUT(0, (KEY_ROW_IN_1 | KEY_ROW_IN_2 | KEY_ROW_IN_3 | KEY_ROW_IN_4));
#endif



#define SENDERS_EMAIL_ADDRESS             "LPC23XXDEMO@uTasker.com"      // fictional Email address of the board being used
#define EMAIL_SUBJECT                     "LPC23XXDEMO Test"             // Email subject
#define EMAIL_CONTENT                     "Hello!!\r\nThis is an email message from the LPC23XXDEMO.\r\nI hope that you have received this test and have fun using the uTasker operating system with integrated TCP/IP stack.\r\r\nRegards your LPC23XXDEMO!!";

// Internal HTML message pages
//
#define SUPPORT_INTERNAL_HTML_FILES                                      // enable the use of the following files
#define UPLOAD_FAILED         "<html><head><title>SW Upload failed</title></head><body bgcolor=#ff9000 text=#000000 topmargin=3 marginheight=3><center><td valign=top class=h><font color=#ff0000 style=font-size:30px><b style='mso-bidi-font-weight:normal'>&micro;Tasker</font></i></b></td><br></td><td align=left><br><br>Sorry but upload has failed.</font><br><br><a href=""javascript:history.back()"">Return</a></body></html>"
#define SW_UPLOAD_COMPLETED   "<html><head><meta http-equiv=""refresh"" content=""10;URL=0Menu.htm""><title>LPC23XX SW Uploaded</title></head><body bgcolor=#ffffff text=#000000 topmargin=3 marginheight=3><center><td valign=top class=h><font color=#ff0000 style=font-size:30px><b style='mso-bidi-font-weight:normal'>&micro;Tasker</font> - SW Update</i></b></td><br></td><td align=left><br><br>SW Upload successful. The LPC23XX target will now reset and start the new program. Please wait 10s...</body></html>"


#ifdef USE_TFTP
    #define TFTP_ERROR_MESSAGE               "uTasker TFTP Error"        // Fixed TFTP error test
#endif


#if defined OLIMEX_LPC2378_STK || defined OLIMEX_LPC2478_STK             // MICREL PHY KS8721
    #define PHY_ADDRESS_ (0x01 << 8)                                     // address of PHY on OLIMEX LPC2378-STK and LPC2478-STK (RMII mode)
    #define PHY_IDENTIFIER          0x00221619                           // MICREL identifier
    #if defined OLIMEX_LPC2378_STK
        #define PHY_INTERRUPT                                            // PHY interrupt is used to signal link state changes
        #define PHY_INT_PORT            PORT_0
        #define PHY_INT_PRIORITY        2
        #define PHY_INT_PIN             PORT0_BIT30
    #else
        #define PHY_INTERRUPT                                            // PHY interrupt is used to signal link state changes
        #define PHY_INT_PORT            PORT_2
        #define PHY_INT_PRIORITY        2
        #define PHY_INT_PIN             PORT2_BIT25
    #endif
#elif defined KEIL_MCB2300                                               // NATIONAL PHY DP83848
    #define _DP83848                                                     // {15}
    #define PHY_ADDRESS_ (0x01 << 8)                                     // address of PHY on KEIL MCB2300 (RMII mode)
    #define VNDR_MDL      0x09                                           // vendor model number
    #define MDL_REV       0x00                                           // model revision number
    #define PHY_IDENTIFIER          (0x20005c00 | (VNDR_MDL << 4) | MDL_REV) // NATIONAL DP83848 identifier
    #if (0)                                                              // this board doesn't connect an interrupt line so the user needs to add a connection if required and set the pin used
        #define PHY_INTERRUPT                                            // PHY interrupt is used to signal link state changes
        #define PHY_INT_PORT            PORT_0
        #define PHY_INT_PRIORITY        2
        #define PHY_INT_PIN             PORT0_BIT4
    #endif
    #define PHY_POWERUP_DELAY       (0.150 * SEC)                        // plus 150ms task delay to give > 167ms
#else                                                                    // default to SMSC LAN8700
    #define _LAN8700                                                     // this device uses different interrupt registers
	#define PHY_ADDRESS_ (0x1f << 8)                                     // address 31
	#define VNDR_MDL      0x0c
	#define MDL_REV       0x03
	#define PHY_IDENTIFIER          (0x0007c000 | (VNDR_MDL << 4) | MDL_REV) // LAN8700 identifier
    #define RESET_PHY                                                    // use a port output to hold the PHY in reset so that straps can be configured
    #define PHY_INTERRUPT                                                // PHY interrupt is used to signal link state changes

    #define ASSERT_PHY_RST()        FIO4CLR = PORT4_BIT29; FIO4DIR |= PORT4_BIT29; _SIM_PORTS // drive the PHY reset port low
    #define CONFIG_PHY_STRAPS()     FIO1CLR = PORT1_BIT14; FIO1DIR |= PORT1_BIT14; _SIM_PORTS // configure PHY straps to ensure the PHY configuration on reset
    #define DEASSERT_PHY_RST()      FIO4SET = PORT4_BIT29; FIO1DIR &= ~PORT1_BIT14;_SIM_PORTS    // allow the PHY to run

    #define PHY_INT_PORT            PORT_0
    #define PHY_INT_PRIORITY        2
    #define PHY_INT_PIN             PORT0_BIT4
#endif

#define PHY_MASK                    0xfffffff0                           // don't check the revision number
#if defined PHY_INTERRUPT && !defined SUPPORT_PORT_INTERRUPTS            // port interrupt support must be enabled to us the PHY interrupt
    #define SUPPORT_PORT_INTERRUPTS
#endif


#endif
