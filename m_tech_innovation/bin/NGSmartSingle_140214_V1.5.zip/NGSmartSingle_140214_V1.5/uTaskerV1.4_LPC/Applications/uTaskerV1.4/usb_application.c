/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        usb_application.c - example of USB communication device
    Project:     uTasker Demonstration project
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    19.09.2008 File content made conditional on HOST support             {1}
    19.09.2008 Allow use without USE_MAINTENANCE                         {2}
    14.12.2008 Add Luminary Micro Vendor ID                              {3}
    03.01.2009 Add brackets to quieten GCC warning                       {4}
    11.01.2009 Control callback returns BUFFER_CONSUMED_EXPECT_MORE when extra data is expected {5}
    08.02.2009 Add official uTasker PID for Luminary project             {6}
    11.02.2009 Add official uTasker VID/PID for ATMEL SAM7X project      {7}
    20.02.2009 Make fnSetNewSerialMode() call dependent on DEMO_UART     {8}
    12.05.2009 Set ucCollectingMode to zero after a control endpoint 0 command has been processed {9}
    01.07.2009 Adapt for STRING_OPTIMISATION configuration               {10}
    06.08.2009 MODBUS USB slave support added                            {11}
    07.01.2010 Adapt fnSetSerialNumberString to allow strings with zero content {12}
    21.03.2010 Add USB_TERMINATING_ENDPOINT to control the behavior of bulk endpoint when transmission has terminated {13}
    02.04.2010 Add LPCXXXX descriptor setup to respect endpoint capabilities {14}
    24.09.2010 Change ucDiskFlags to usDiskFlags
    06.03.2011 Accept on MODE_SENSE_6_PAGE_CODE_ALL_PAGES in UFI_MODE_SENSE_6 and report write protection {15}
    07.03.2011 Allow reading and writing MSD when not formatted          {16}
    07.03.2011 Yield after mass-storage writes                           {17}
    05.05.2011 Configure system clock as USB clock source for Kinetis tower kit {18}
    17.05.2011 Official USB VID/PID for Freescale MSD                    {19}
    05.06.2011 Adapt endpoint clear to suit LPC devices                  {20}
    25.01.2012 Add optional USB logo display control                     {21}
    25.01.2012 Activate USB-MSD with define USE_USB_MSD                  {22}
    25.01.2012 Add USE_USB_HID_MOUSE                                     {23}
    05.02.2012 Move USE_USB_CDC default to config.h
    10.02.2012 Only send HID mouse information on change and add mouse left key {24}

*/


/* =================================================================== */
/*                           include files                             */
/* =================================================================== */

//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"

#if defined USB_INTERFACE && !defined USB_HOST_SUPPORT                   // {1}


/* =================================================================== */
/*                          local definitions                          */
/* =================================================================== */

#define OWN_TASK                            TASK_USB


#define NUMBER_OF_POSSIBLE_CONFIGURATIONS   1

#if defined USE_USB_HID_MOUSE                                            // {23}
    #define NUMBER_OF_ENDPOINTS             1                            // uses 1 interrupt IN endpoint in addition to the default control endpoint 0
    #define USB_VENDOR_ID                   0x4321                       // non-official test VID
    #define USB_PRODUCT_ID                  0x1255                       // non-official test HID PID
#elif defined USE_USB_MSD                                                // MSD
    #define NUMBER_OF_ENDPOINTS             3                            // uses 3 endpoints (2 IN and 1 OUT) in addition to the default control endpoint 0
    #define NUMBER_OF_PARTITIONS            1
    #if defined _M5223X || defined _KINETIS
        #define USB_VENDOR_ID               0x0425                       // MOTOROLA vendor ID {19}
        #define USB_PRODUCT_ID              0x03fc                       // uTasker Motorola MSD development product ID {19}
    #elif defined _LM3SXXXX
        #define USB_VENDOR_ID               0x1cbe                       // Luminary Micro, Inc. vendor ID
        #define USB_PRODUCT_ID              0x1234                       // non-official test MSD PID
    #elif defined _HW_SAM7X || defined _HW_AVR32
        #define USB_VENDOR_ID               0x03eb                       // ATMEL Corp. vendor ID
        #define USB_PRODUCT_ID              0x1234                       // non-official test MSD PID
    #else
        #define USB_VENDOR_ID               0x4321                       // non-official test VID
        #define USB_PRODUCT_ID              0x1234                       // non-official test MSD PID
    #endif
#else                                                                    // CDC
    #define NUMBER_OF_ENDPOINTS             3                            // uses 3 endpoints (2 IN and 1 OUT) in addition to the default control endpoint 0
    #if defined _M5223X || defined _KINETIS
        #define USB_VENDOR_ID               0x15a2                       // Freescale vendor ID
        #define USB_PRODUCT_ID              0x0044                       // uTasker Freescale development CDC product ID
    #elif defined _LM3SXXXX
        #define USB_VENDOR_ID               0x1cbe                       // {3} Luminary Micro, Inc. vendor ID
        #define USB_PRODUCT_ID              0x0101                       // {6} uTasker Luminary development CDC product ID
    #elif defined _HW_SAM7X || defined _HW_AVR32
        #define USB_VENDOR_ID               0x03eb                       // {7} ATMEL Corp. vendor ID
        #define USB_PRODUCT_ID              0x21fd                       // {7} uTasker development CDC product ID
    #else
        #define USB_VENDOR_ID               0x4321                       // non-official test VID
        #define USB_PRODUCT_ID              0x1221                       // non-official test CDC PID
    #endif
#endif

#define USB_PRODUCT_RELEASE_NUMBER          0x0100                       // V1.0 (binary coded decimal)

#ifdef USB_STRING_OPTION                                                 // if our project supports strings
    #define MANUFACTURER_STRING_INDEX       1                            // index must match with order in the string list
    #define PRODUCT_STRING_INDEX            2                            // to remove a particular string from the list set to zero
    #define SERIAL_NUMBER_STRING_INDEX      3
    #define CONFIGURATION_STRING_INDEX      4
    #define INTERFACE_STRING_INDEX          5

    #define UNICODE_LANGUAGE_INDEX          UNICODE_ENGLISH_LANGUAGE     // English language used by strings
    #define LAST_STRING_INDEX               INTERFACE_STRING_INDEX       // last string entry - used for protection against invalid string index requests
#endif

#define EVENT_RETURN_PRESENT_UART_SETTING   1
#define EVENT_COMITT_NEW_UART_SETTING       2


#define T_MOUSE_ACTION                      1

/* =================================================================== */
/*                       local structure definitions                   */
/* =================================================================== */

#ifdef _CODE_WARRIOR_CF                                                  // ensure no padding in structs used in this file
    #pragma pack(1)
#endif


// We define the contents of the configuration descriptor used for our specific device and then set its contents
//
#if defined USE_USB_HID_MOUSE                                            // {23}
typedef struct _PACK stUSB_CONFIGURATION_DESCRIPTOR_COLLECTION
{
    USB_CONFIGURATION_DESCRIPTOR               config_desc;              // compulsory configuration descriptor
    USB_INTERFACE_DESCRIPTOR                   interface_desc_1;         // first interface descriptor
    USB_HID_DESCRIPTOR                         hid_desc_1;               // HID descriptor
    USB_ENDPOINT_DESCRIPTOR                    endpoint_1;               // single endpoint
} USB_CONFIGURATION_DESCRIPTOR_COLLECTION;
#elif defined USE_USB_MSD
typedef struct _PACK stUSB_CONFIGURATION_DESCRIPTOR_COLLECTION
{
    USB_CONFIGURATION_DESCRIPTOR               config_desc;              // compulsory configuration descriptor
    USB_INTERFACE_DESCRIPTOR                   interface_desc_1;         // first interface descriptor
    USB_ENDPOINT_DESCRIPTOR                    endpoint_1;               // endpoints of second interface
    USB_ENDPOINT_DESCRIPTOR                    endpoint_2;
} USB_CONFIGURATION_DESCRIPTOR_COLLECTION;
#else
typedef struct _PACK stUSB_CONFIGURATION_DESCRIPTOR_COLLECTION
{
    USB_CONFIGURATION_DESCRIPTOR               config_desc;              // compulsory configuration descriptor

    USB_INTERFACE_DESCRIPTOR                   interface_desc_1;         // first interface descriptor
        USB_CDC_FUNCTIONAL_DESCRIPTOR_HEADER   CDC_func_header;          // CDC function descriptors due to class used
        USB_CDC_FUNCTIONAL_DESCRIPTOR_CALL_MAN CDC_call_management;
        USB_CDC_FUNCTIONAL_DESCRIPTOR_ABSTRACT_CONTROL  CDC_abstract_control;
        USB_CDC_FUNCTIONAL_DESCRIPTOR_UNION    CDC_union;
    USB_ENDPOINT_DESCRIPTOR                    endpoint_3;               // endpoint of first interface

    USB_INTERFACE_DESCRIPTOR                   interface_desc_2;         // second interface descriptor
    USB_ENDPOINT_DESCRIPTOR                    endpoint_1;               // endpoints of second interface
    USB_ENDPOINT_DESCRIPTOR                    endpoint_2;
} USB_CONFIGURATION_DESCRIPTOR_COLLECTION;
#endif


/* =================================================================== */
/*                      global function definitions                    */
/* =================================================================== */

#ifdef MODBUS_USB_SLAVE                                                  // {11}
    QUEUE_HANDLE USBPortID_comms = 0;                                    // USB port endpoint handle (exported for use by MODBUS module)
#endif

/* =================================================================== */
/*                             constants                               */
/* =================================================================== */

#if defined USE_USB_HID_MOUSE                                            // {23}
/*
    /--------------------------\
    |     Device Descriptor    |
    /--------------------------\
                  |
    /--------------------------\
    | Configuration Descriptor |
    /--------------------------\
                  |
    /--------------------------\
    |    Interface Descriptor  |
    /--------------------------\
                  |   |
                  |   ----------------------------
                  |                              |
    /--------------------------\     /--------------------------\
    |    Endpoint Descriptor   |     |       HID Descriptor     |
    /--------------------------\     /--------------------------\
                                                 |
                                  -------------------------------
                                  |                             |
                   /--------------------------\     /--------------------------\
                   |      Report Descriptor   |     |   Physical Descriptor    |
                   /--------------------------\     /--------------------------\
*/

    static const unsigned char ucMouseReport[] = {
    0x05,                                                                // usage page
    0x01,                                                                // generic desktop controls

    0x09,                                                                // usage
    0x02,                                                                // mouse

    0xa1,                                                                // collection 
    0x01,                                                                // application
        0x09,                                                            // usage
        0x01,                                                            // pointer

        0xa1,                                                            // collection
        0x00,                                                            // physical
            0x05,                                                        // usage page
            0x09,                                                        // button

            0x19,                                                        // usage minimum
            0x01,                                                        // button 1 (primary/trigger)

            0x29,                                                        // usage maximum
            0x03,                                                        // button 3 (tertiary)

            0x15,                                                        // logical minimum
            0x00,

            0x25,                                                        // logical maximum
            0x01,

            0x95,                                                        // report count
            0x03,

            0x75,                                                        // report size
            0x01,

            0x81,                                                        // input
            0x02,                                                        // data

            0x95,                                                        // report count
            0x01,

            0x75,                                                        // report size
            0x05,

            0x81,                                                        // input
            0x01,                                                        // constant

            0x05,                                                        // usage page
            0x01,                                                        // generic desktop controls

            0x09,                                                        // usage
            0x30,                                                        // x-axis

            0x09,                                                        // usage
            0x31,                                                        // y-axis

            0x09,                                                        // usage
            0x38,                                                        // wheel

            0x15,                                                        // logical minimum
            0x81,                                                        // -127

            0x25,                                                        // logic maximum
            0x7f,                                                        // +127

            0x75,                                                        // report size
            0x08,

            0x95,                                                        // report count
            0x03,

            0x81,                                                        // input
            0x06,                                                        // data
        0xc0,                                                            // end collection

        0x09,                                                            // usage
        0x3c,                                                            // motion wakeup

        0x15,                                                            // logical minimum
        0x00,

        0x25,                                                            // logical maximum
        0x01,

        0x75,                                                            // report size
        0x01,

        0x95,                                                            // report count
        0x01,

        0xb1,                                                            // feature
        0x22,                                                            // data

        0x95,                                                            // report count 
        0x07,

        0xb1,                                                            // feature 
        0x01,                                                            // constant
    0xc0                                                                 // end collection
};

static const USB_DEVICE_DESCRIPTOR device_descriptor = {                 // constant device descriptor
    STANDARD_DEVICE_DESCRIPTOR_LENGTH,                                   // standard device descriptor length (0x12)
    DESCRIPTOR_TYPE_DEVICE,                                              // 0x01
    {LITTLE_SHORT_WORD_BYTES(USB_SPEC_VERSION_1_1)},                     // USB1.1 or USB2
    DEVICE_CLASS_AT_INTERFACE,                                           // device class, sub-class and protocol (class defined at interface level) - HID should never specifiy the device class at this level
    ENDPOINT_0_SIZE,                                                     // size of endpoint reception buffer
    {LITTLE_SHORT_WORD_BYTES(USB_VENDOR_ID)},                            // our vendor ID
    {LITTLE_SHORT_WORD_BYTES(USB_PRODUCT_ID)},                           // our product ID
    {LITTLE_SHORT_WORD_BYTES(USB_PRODUCT_RELEASE_NUMBER)},               // product release number
    #ifdef USB_STRING_OPTION                                             // if we support strings add the data here
    MANUFACTURER_STRING_INDEX, PRODUCT_STRING_INDEX, SERIAL_NUMBER_STRING_INDEX, // fixed string table indexes - note that mass storage class demainds that each device has a unique serial number of at least 12 digits length!
    #else
    0,0,0,                                                               // used when no strings are supported
    #endif
    NUMBER_OF_POSSIBLE_CONFIGURATIONS                                    // number of configurations possible
};

static const USB_CONFIGURATION_DESCRIPTOR_COLLECTION config_descriptor = {
    {                                                                    // config descriptor
    DESCRIPTOR_TYPE_CONFIGURATION_LENGTH,                                // length (0x09)
    DESCRIPTOR_TYPE_CONFIGURATION,                                       // 0x02
    {LITTLE_SHORT_WORD_BYTES(sizeof(USB_CONFIGURATION_DESCRIPTOR_COLLECTION))}, // total length (little-endian)
    0x01,                                                                // configuration number - mass storage has only one configuratiom
    0x01,                                                                // configuration value
    #ifdef USB_STRING_OPTION
    CONFIGURATION_STRING_INDEX,                                          // string index to configuration
    #else
    0,                                                                   // zero when strings are not supported
    #endif
    (SELF_POWERED | ATTRIBUTE_DEFAULT),                                  // attributes for configuration,
    0                                                                    // consumption in 2mA steps (eg. 100/2 for 100mA)
    },                                                                   // end of compulsory config descriptor

    {                                                                    // interface descriptor
    DESCRIPTOR_TYPE_INTERFACE_LENGTH,                                    // length (0x09)
    DESCRIPTOR_TYPE_INTERFACE,                                           // 0x04
    0,                                                                   // interface number 0
    0,                                                                   // alternative setting 0
    1,                                                                   // number of endpoints in addition to EP0
    USB_CLASS_HID,                                                       // interface class (0x03)
    USB_SUBCLASS_BOOT_INTERFACE,                                         // interface sub-class (0x01)
    USB_INTERFACE_PROTOCOL_MOUSE,                                        // interface protocol (0x02)
    #ifdef USB_STRING_OPTION
    INTERFACE_STRING_INDEX,                                              // string index for interface
    #else
    0,                                                                   // zero when strings are not supported
    #endif
    },                                                                   // end of interface descriptor

    {                                                                    // HID descriptor
    DESCRIPTOR_TYPE_HID_LENGTH,                                          // descriptor size in bytes
    DESCRIPTOR_TYPE_HID,                                                 // device descriptor type
    {LITTLE_SHORT_WORD_BYTES(1)},                                        // HID class specific release number
    0,                                                                   // hardware target country
    1,                                                                   // number of HID class descriptors to follow
    DESCRIPTOR_TYPE_REPORT,                                              // descriptor type
    {LITTLE_SHORT_WORD_BYTES(sizeof(ucMouseReport))},                    // total length of report descriptor
    },

    {                                                                    // interrupt in endpoint descriptor for the interface
    DESCRIPTOR_TYPE_ENDPOINT_LENGTH,                                     // descriptor size in bytes (0x07)
    DESCRIPTOR_TYPE_ENDPOINT,                                            // endpoint descriptor (0x05)
    #if defined _LPC23XX || defined _LPC17XX
    (IN_ENDPOINT | 0x05),                                                // direction and address of endpoint
    #else
    (IN_ENDPOINT | 0x01),                                                // direction and address of endpoint
    #endif
    ENDPOINT_INTERRUPT,                                                  // endpoint attributes
    {LITTLE_SHORT_WORD_BYTES(8)},                                        // endpoint FIFO size (little-endian - 8 bytes)
    10                                                                   // polling interval in ms
    }
};
#elif defined USE_USB_MSD
static const unsigned char  cCBWSignature[4] = {'U', 'S', 'B', 'C'};

static const CBW_INQUIRY_DATA inquiryData = {
    DEVICE_TYPE_FLOPPY,
    RMB_REMOVABLE,
    0,
    RESPONSE_FORMAT_UFI,
    31,                                                                  // additional length should be 31
    {0},                                                                 // reserved field
    {'u', 'T', 'a', 's', 'k', 'e', 'r', ' '},                            // vendor information (8 bytes)
    {'U', 'S', 'B', 't', 'o', 'S', 'D', '-', 'C', 'a', 'r', 'd', ' ', ' ', ' ', ' '}, // product identification (16 bytes)
    {'1', '.', '0', '0' }                                                // product revision level
};

static const CBW_RETURN_SENSE_DATA sense_data = {VALID_SENSE_DATA, 0, SENSE_NO_SENSE, {0,0,0,0}, SENSE_LENGTH_10, {0,0,0,0}, 0, 0, {0,0,0,0}};


static const MODE_PARAMETER_6 SelectData = {                             // {15} standard response without descriptors and no write protection
    3,                                                                   // content length
    DEVICE_TYPE_FLOPPY,                                                  // medium type
    0,                                                                   // no write protection
    0                                                                    // no descriptors
};

static const CBW_CAPACITY_LIST formatCapacityNoMedia = {
    {0},
    8,                                                                   // capacity list length with just one entry
    {
        {0x00, 0x01, 0xf8, 0x00}, DESC_CODE_NO_CARTRIDGE_IN_DRIVE, {0x00, 0x02, 0x00}, // 512 bytes block length
    }
};

static const USB_DEVICE_DESCRIPTOR device_descriptor = {                 // constant device descriptor
    STANDARD_DEVICE_DESCRIPTOR_LENGTH,                                   // standard device descriptor length (0x12)
    DESCRIPTOR_TYPE_DEVICE,                                              // 0x01
    {LITTLE_SHORT_WORD_BYTES(USB_SPEC_VERSION_1_1)},                     // USB1.1 or USB2
    DEVICE_CLASS_AT_INTERFACE,                                           // device class, sub-class and protocol (class defined at interface level)
    ENDPOINT_0_SIZE,                                                     // size of endpoint reception buffer
    {LITTLE_SHORT_WORD_BYTES(USB_VENDOR_ID)},                            // our vendor ID
    {LITTLE_SHORT_WORD_BYTES(USB_PRODUCT_ID)},                           // our product ID
    {LITTLE_SHORT_WORD_BYTES(USB_PRODUCT_RELEASE_NUMBER)},               // product release number
    #ifdef USB_STRING_OPTION                                             // if we support strings add the data here
    MANUFACTURER_STRING_INDEX, PRODUCT_STRING_INDEX, SERIAL_NUMBER_STRING_INDEX, // fixed string table indexes - note that mass storage class demainds that each device has a unique serial number of at least 12 digits length!
    #else
    0,0,0,                                                               // used when no strings are supported
    #endif
    NUMBER_OF_POSSIBLE_CONFIGURATIONS                                    // number of configurations possible
};

static const USB_CONFIGURATION_DESCRIPTOR_COLLECTION config_descriptor = {
    {                                                                    // config descriptor
    DESCRIPTOR_TYPE_CONFIGURATION_LENGTH,                                // length (0x09)
    DESCRIPTOR_TYPE_CONFIGURATION,                                       // 0x02
    {LITTLE_SHORT_WORD_BYTES(sizeof(USB_CONFIGURATION_DESCRIPTOR_COLLECTION))}, // total length (little-endian)
    0x01,                                                                // configuration number - mass storage has only one configuratiom
    0x01,                                                                // configuration value
    #ifdef USB_STRING_OPTION
    CONFIGURATION_STRING_INDEX,                                          // string index to configuration
    #else
    0,                                                                   // zero when strings are not supported
    #endif
    (SELF_POWERED | ATTRIBUTE_DEFAULT),                                  // attributes for configuration,
    0                                                                    // consumption in 2mA steps (eg. 100/2 for 100mA)
    },                                                                   // end of compulsory config descriptor

    {                                                                    // interface descriptor
    DESCRIPTOR_TYPE_INTERFACE_LENGTH,                                    // length (0x09)
    DESCRIPTOR_TYPE_INTERFACE,                                           // 0x04
    0,                                                                   // interface number 0
    0,                                                                   // alternative setting 0
    2,                                                                   // number of endpoints in addition to EP0
    INTERFACE_CLASS_MASS_STORAGE,                                        // interface class (0x08)
    GENERIC_SCSI_MEDIA,                                                  // interface sub-class (0x06)
    BULK_ONLY_TRANSPORT,                                                 // interface protocol (0x50)
    #ifdef USB_STRING_OPTION
    INTERFACE_STRING_INDEX,                                              // string index for interface
    #else
    0,                                                                   // zero when strings are not supported
    #endif
    },                                                                   // end of interface descriptor

    {                                                                    // bulk out endpoint descriptor for the second interface
    DESCRIPTOR_TYPE_ENDPOINT_LENGTH,                                     // descriptor size in bytes (0x07)
    DESCRIPTOR_TYPE_ENDPOINT,                                            // endpoint descriptor (0x05)
    #if defined _LPC23XX || defined _LPC17XX
    (OUT_ENDPOINT | 0x02),                                               // direction and address of endpoint
    #else
    (OUT_ENDPOINT | 0x01),                                               // direction and address of endpoint
    #endif
    ENDPOINT_BULK,                                                       // endpoint attributes
    {LITTLE_SHORT_WORD_BYTES(64)},                                       // endpoint FIFO size (little-endian - 64 bytes)
    0                                                                    // polling interval in ms - ignored for bulk
    },

    {                                                                    // bulk in endpoint descriptor for the second interface
    DESCRIPTOR_TYPE_ENDPOINT_LENGTH,                                     // descriptor size in bytes (0x07)
    DESCRIPTOR_TYPE_ENDPOINT,                                            // endpoint descriptor (0x05)
    #if defined _LPC23XX || defined _LPC17XX
    (IN_ENDPOINT | 0x05),                                                // direction and address of endpoint
    #else
    (IN_ENDPOINT | 0x02),                                                // direction and address of endpoint
    #endif
    ENDPOINT_BULK,                                                       // endpoint attributes
    {LITTLE_SHORT_WORD_BYTES(64)},                                       // endpoint FIFO size (little-endian - 64 bytes)
    0                                                                    // polling interval in ms - ignored for bulk
    }
};
#else                                                                    // CDC
static const USB_DEVICE_DESCRIPTOR device_descriptor = {                 // constant device descriptor
    STANDARD_DEVICE_DESCRIPTOR_LENGTH,                                   // standard device descriptor length (0x12)
    DESCRIPTOR_TYPE_DEVICE,                                              // 0x01
    {LITTLE_SHORT_WORD_BYTES(USB_SPEC_VERSION_1_1)},                     // USB1.1 or USB2
    DEVICE_CLASS_COMMUNICATION_AND_CONTROL,                              // device class, sub-class and protocol (communication class)
    ENDPOINT_0_SIZE,                                                     // size of endpoint reception buffer
    {LITTLE_SHORT_WORD_BYTES(USB_VENDOR_ID)},                            // our vendor ID
    {LITTLE_SHORT_WORD_BYTES(USB_PRODUCT_ID)},                           // our product ID
    {LITTLE_SHORT_WORD_BYTES(USB_PRODUCT_RELEASE_NUMBER)},               // product release number
    #ifdef USB_STRING_OPTION                                             // if we support strings add the data here
    MANUFACTURER_STRING_INDEX, PRODUCT_STRING_INDEX, SERIAL_NUMBER_STRING_INDEX, // fixed string table indexes
    #else
    0,0,0,                                                               // used when no strings are supported
    #endif
    NUMBER_OF_POSSIBLE_CONFIGURATIONS                                    // number of configurations possible
};

static const USB_CONFIGURATION_DESCRIPTOR_COLLECTION config_descriptor = {
    {                                                                    // config descriptor
    DESCRIPTOR_TYPE_CONFIGURATION_LENGTH,                                // length (0x09)
    DESCRIPTOR_TYPE_CONFIGURATION,                                       // 0x02
    {LITTLE_SHORT_WORD_BYTES(sizeof(USB_CONFIGURATION_DESCRIPTOR_COLLECTION))}, // total length (little-endian)
    0x02,                                                                // configuration number
    0x01,                                                                // configuration value
    #ifdef USB_STRING_OPTION
    CONFIGURATION_STRING_INDEX,                                          // string index to configuration
    #else
    0,                                                                   // zero when strings are not supported
    #endif
    (SELF_POWERED | ATTRIBUTE_DEFAULT),                                  // attributes for configuration,
    0                                                                    // consumption in 2mA steps (eg. 100/2 for 100mA)
    },                                                                   // end of compulsory config descriptor

    {                                                                    // interface descriptor
    DESCRIPTOR_TYPE_INTERFACE_LENGTH,                                    // length (0x09)
    DESCRIPTOR_TYPE_INTERFACE,                                           // 0x04
    0,                                                                   // interface number 0
    0,                                                                   // alternative setting 0
    1,                                                                   // number of endpoints in addition to EP0
    USB_CLASS_COMMUNICATION_CONTROL,                                     // interface class (0x02)
    USB_ABSTRACT_LINE_CONTROL_MODEL,                                     // interface sub-class (0x02)
    0,                                                                   // interface protocol
    #ifdef USB_STRING_OPTION
    INTERFACE_STRING_INDEX,                                              // string index for interface
    #else
    0,                                                                   // zero when strings are not supported
    #endif
    },                                                                   // end of interface descriptor

    {                                                                    // function descriptors
    USB_CDC_FUNCTIONAL_DESCRIPTOR_HEADER_LENGTH,                         // descriptor size in bytes (0x05)
    CS_INTERFACE,                                                        // type field (0x24)
    HEADER_FUNCTION_DESCRIPTOR,                                          // header descriptor (0x00)
    {LITTLE_SHORT_WORD_BYTES(USB_SPEC_VERSION_1_1)}                      // {4} specification version
    },

    {
    USB_CDC_FUNCTIONAL_DESCRIPTOR_CALL_MAN_LENGTH,                       // descriptor size in bytes (0x05)
    CS_INTERFACE,                                                        // type field (0x24)
    CALL_MAN_FUNCTIONAL_DESCRIPTOR,                                      // call management function descriptor (0x01)
    1,                                                                   // capabilities
    0                                                                    // data interface
    },                                                                   // end of function descriptors

    {
    USB_CDC_FUNCTIONAL_DESCRIPTOR_ABSTRACT_CONTROL_LENGTH,               // descriptor size in bytes (0x04)
    CS_INTERFACE,                                                        // type field (0x24)
    ABSTRACT_CONTROL_FUNCTION_DESCRIPTOR,                                // abstract control descriptor (0x02)
    2                                                                    // capabilities
    },

    {
    USB_CDC_FUNCTIONAL_DESCRIPTOR_UNION_LENGTH,                          // descriptor size in bytes (0x05)
    CS_INTERFACE,                                                        // type field (0x24)
    UNION_FUNCTIONAL_DESCRIPTOR,                                         // union function descriptor (0x06)
    0,                                                                   // control interface
    1                                                                    // subordinate interface
    },                                                                   // end of function descriptors

    {                                                                    // interrupt endpoint descriptor for first interface
    DESCRIPTOR_TYPE_ENDPOINT_LENGTH,                                     // descriptor size in bytes (0x07)
    DESCRIPTOR_TYPE_ENDPOINT,                                            // endpoint descriptor (0x05)
    #if defined _LPC23XX || defined _LPC17XX                             // {14}
    (IN_ENDPOINT | 0x04),                                                // direction and address of endpoint (endpoint 4 is interrupt)
    #else
    (IN_ENDPOINT | 0x03),                                                // direction and address of endpoint
    #endif
    ENDPOINT_INTERRUPT,                                                  // endpoint attributes
    {LITTLE_SHORT_WORD_BYTES(64)},                                       // endpoint FIFO size (little-endian)
    10                                                                   // polling interval in ms
    },                                                                   // end of endpoint descriptor

    {                                                                    // the second interface
    DESCRIPTOR_TYPE_INTERFACE_LENGTH,                                    // descriptor size in bytes (0x09)
    DESCRIPTOR_TYPE_INTERFACE,                                           // interface descriptor (0x04)
    1,                                                                   // interface number
    0,                                                                   // no alternative setting
    2,                                                                   // 2 endpoints
    INTERFACE_CLASS_COMMUNICATION_DATA,                                  //
    0,                                                                   // sub-class
    0,                                                                   // interface protocol
    #ifdef USB_STRING_OPTION
    INTERFACE_STRING_INDEX,                                              // string index for interface
    #else
    0                                                                    // zero when strings are not supported
    #endif
    },

    {                                                                    // bulk out endpoint descriptor for the second interface
    DESCRIPTOR_TYPE_ENDPOINT_LENGTH,                                     // descriptor size in bytes (0x07)
    DESCRIPTOR_TYPE_ENDPOINT,                                            // endpoint descriptor (0x05)
    #if defined _LPC23XX || defined _LPC17XX                             // {14}
    (OUT_ENDPOINT | 0x02),                                               // direction and address of endpoint (endpoint 2 is bulk)
    #else
    (OUT_ENDPOINT | 0x01),                                               // direction and address of endpoint
    #endif
    ENDPOINT_BULK,                                                       // endpoint attributes
    {LITTLE_SHORT_WORD_BYTES(64)},                                       // endpoint FIFO size (little-endian - 64 bytes)
    0                                                                    // polling interval in ms - ignored for bulk
    },

    {                                                                    // bulk in endpoint descriptor for the second interface
    DESCRIPTOR_TYPE_ENDPOINT_LENGTH,                                     // descriptor size in bytes (0x07)
    DESCRIPTOR_TYPE_ENDPOINT,                                            // endpoint descriptor (0x05)
    #if defined _LPC23XX || defined _LPC17XX                             // {14}
    (IN_ENDPOINT | 0x05),                                                // direction and address of endpoint (endpoint 5 is bulk)
    #else
    (IN_ENDPOINT | 0x02),                                                // direction and address of endpoint
    #endif
    ENDPOINT_BULK,                                                       // endpoint attributes
    {LITTLE_SHORT_WORD_BYTES(64)},                                       // endpoint FIFO size (little-endian - 64 bytes)
    0                                                                    // polling interval in ms - ignored for bulk
    }
};
#endif

#ifdef USB_STRING_OPTION                                                 // if our project supports strings
                                                                         // the characters in the string must be entered as 16 bit unicode in little-endian order!!
                                                                         // the first entry is the length of the content (including the length and descriptor type string entries)
    static const unsigned char usb_language_string[] = {4,  DESCRIPTOR_TYPE_STRING, LITTLE_SHORT_WORD_BYTES(UNICODE_LANGUAGE_INDEX)}; // this is compulsory first string
    static const unsigned char manufacturer_str[]    = {10, DESCRIPTOR_TYPE_STRING, 'M',0, 'a',0, 'n',0, 'u',0};
    static const unsigned char product_str[]         = {16, DESCRIPTOR_TYPE_STRING, 'M',0, 'y',0, ' ',0, 'P',0, 'r',0, 'o',0, 'd',0};
    #if defined USB_RUN_TIME_DEFINABLE_STRINGS
    static const unsigned char serial_number_str[]   = {0};              // the application delivers this string (generated at run time)
    #else
    static const unsigned char serial_number_str[]   = {10, DESCRIPTOR_TYPE_STRING, '0',0, '0',0, '0',0, '1',0};
    #endif
    static const unsigned char config_str[]          = {10, DESCRIPTOR_TYPE_STRING, 'C',0, 'o',0, 'n',0, 'f',0};
    static const unsigned char interface_str[]       = {8,  DESCRIPTOR_TYPE_STRING, 'I',0, 'n',0, 't',0};


    static const unsigned char *ucStringTable[]      = {usb_language_string, manufacturer_str, product_str, serial_number_str, config_str, interface_str};
#endif

/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */

static QUEUE_HANDLE USB_control = 0;;                                    // USB default control endpoint handle
#if defined USE_USB_CDC
    static QUEUE_HANDLE USBPortID_interrupt_3;                           // interrupt endpoint 3
#endif
#ifndef MODBUS_USB_SLAVE                                                 // {11}
    static QUEUE_HANDLE USBPortID_comms;                                 // USB port endpoint handle
#endif
#if defined USB_STRING_OPTION && defined USB_RUN_TIME_DEFINABLE_STRINGS
    static USB_STRING_DESCRIPTOR *SerialNumberDescriptor;                // string built up to contain a variable serial number
#endif
#if defined USE_USB_HID_MOUSE                                            // {23}
    //
#elif defined USE_USB_MSD
    static unsigned long ulLogicalBlockAdr = 0;                          // present logical block address (shared between read and write)
    static unsigned long ulReadBlock = 0;                                // the outstanding blocks to be read from the media
    static unsigned long ulWriteBlock = 0;                               // the outstanding blocks to be written to the media
    static int iContent = 0;
    static UTDISK *ptrDiskInfo = 0;
    static USB_MASS_STORAGE_CSW csw = {{'U', 'S', 'B', 'S'}, {0}, {0}, CSW_STATUS_COMMAND_PASSED };
    static CBW_RETURN_SENSE_DATA present_sense_data;
#else
    static CDC_PSTN_LINE_CODING uart_setting;                            // use a static struct to ensure that non-buffered transmission remains stable. Use also to receive new settings to
#endif


/* =================================================================== */
/*                      local function definitions                     */
/* =================================================================== */

static void fnConfigureUSB(void);                                        // routine to open and configure USB interface
#if defined USB_STRING_OPTION && defined USB_RUN_TIME_DEFINABLE_STRINGS
    static void fnSetSerialNumberString(CHAR *ptrSerialNumber);
#endif
#if defined USE_USB_HID_MOUSE
#elif defined USE_USB_MSD
    static void fnContinueMedia(void);
    static unsigned char *fnGetPartition(unsigned char ucLUN, QUEUE_TRANSFER *length);
#else                                                                    // CDC
    static void fnReturnUART_settings(void);
    static void fnNewUART_settings(unsigned char *ptrData, unsigned short usLength, unsigned short usExpected);
    static void fnComitt_UART(void);
#endif

/* =================================================================== */
/*                      global function definitions                    */
/* =================================================================== */


/* =================================================================== */
/*                                task                                 */
/* =================================================================== */


// USB task
//
extern void fnTaskUSB(TTASKTABLE *ptrTaskTable)
{
#if defined USE_USB_HID_MOUSE                                            // {23}
    static int iUSB_mouse_state = 0;
#elif defined USB_MSD
    QUEUE_TRANSFER Length;
#elif !defined MODBUS_USB_SLAVE                                          // {11}
    QUEUE_TRANSFER Length;
#endif
    QUEUE_HANDLE PortIDInternal = ptrTaskTable->TaskID;                  // queue ID for task input
    unsigned char ucInputMessage[LARGE_MESSAGE];                         // reserve space for receiving messages

    if (USB_control == 0) {                                              // initialisation
#if defined USB_STRING_OPTION && defined USB_RUN_TIME_DEFINABLE_STRINGS  // if dynamic strings are supported, prepare a specific serial number ready for enumeration
        fnSetSerialNumberString(parameters->cDeviceIDName);              // construct a serial number string for USB use
#endif
        fnConfigureUSB();                                                // configure the USB interface
#if defined MODBUS_USB_SLAVE                                             // {11}
        fnInitModbus();                                                  // initialise MODBUS since the USB handle is now ready
#endif
#if defined USE_USB_HID_MOUSE                                            // {23}
        CONFIGURE_MOUSE_INPUTS();
#elif defined USE_USB_MSD
        ptrDiskInfo = fnGetDiskInfo(DISK_D);                             // get a pointer to the disk information for local use
#endif
    }

    while (fnRead(PortIDInternal, ucInputMessage, HEADER_LENGTH)) {      // check input queue
        switch (ucInputMessage[MSG_SOURCE_TASK]) {                       // switch depending on source
#if defined USE_USB_HID_MOUSE                                            // {23}
        case TIMER_EVENT:
            if (iUSB_mouse_state != 0) {                                 // T_MOUSE_ACTION assumed
                static unsigned char ucMouseLastState[4] = {0, 0, 0, 0}; // {24}
                static unsigned char ucMouseState[4] = {0, 0, 0, 0};     // this must be static since the interrupt IN endpoint uses non-buffered transmission
                if (MOUSE_LEFT_CLICK()) {
                    ucMouseState[0] |= 0x01;                             // mouse left key held down
                }
                else {
                    ucMouseState[0] &= ~0x01;                            // mouse left key releases
                }
                if (MOUSE_RIGHT()) {
                    ucMouseState[1]++;                                   // increase x coordinate
                }
                else if (MOUSE_LEFT()) {
                    ucMouseState[1]--;                                   // decrease x coordinate
                }
                else {
                    ucMouseState[1] = 0;
                }
                if (MOUSE_UP()) {
                    ucMouseState[2]++;                                   // increase y coordinate
                }
                else if (MOUSE_DOWN()) {
                    ucMouseState[2]--;                                   // decrease y coordinate
                }
                else {
                    ucMouseState[2] = 0;
                }
                if (uMemcmp(ucMouseLastState, ucMouseState, sizeof(ucMouseState)) != 0) { // {24} if change
                    fnWrite(USBPortID_comms, (unsigned char *)&ucMouseState, sizeof(ucMouseState)); // prepare interrupt IN (non-buffered)
                    uMemcpy(ucMouseLastState, ucMouseState, sizeof(ucMouseState));
                }
                uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(0.05*SEC), T_MOUSE_ACTION);
            }
            break;
#endif
        case INTERRUPT_EVENT:                                            // interrupt event without data
            switch (ucInputMessage[MSG_INTERRUPT_EVENT]) {               // specific interrupt event type
            case EVENT_USB_RESET:                                        // active USB connection has been reset
#if defined USE_USB_HID_MOUSE                                            // {23}
                iUSB_mouse_state = 0;                                    // mark that the mouse function is not active
                uTaskerStopTimer(OWN_TASK);
#elif defined USE_USB_MSD
                ulWriteBlock = 0;                                        // reset local variables on each reset
                ulReadBlock = 0;
                iContent = 0;
#else
                if (usUSB_state != ES_NO_CONNECTION) {                   // if the USB connection was being used for debug menu, restore previous interface
    #if defined SERIAL_INTERFACE && defined DEMO_UART                    // {8}
                    DebugHandle = SerialPortID;
    #else
                    DebugHandle = NETWORK_HANDLE;
    #endif
    #ifdef USE_MAINTENANCE                                               // {2}
                    fnGotoNextState(ES_NO_CONNECTION);
    #endif
                    usUSB_state = ES_NO_CONNECTION;
                }
#endif
                fnDebugMsg("USB Reset\n\r");                             // display that the USB bus has been reset
                DEL_USB_SYMBOL();                                        // {21}
                break;
            case EVENT_USB_SUSPEND:                                      // a suspend condition has been detected. A bus powered device should reduce consumption to <= 500uA or <= 2.5mA (high power device)
#if defined USE_USB_CDC
                if (usUSB_state != ES_NO_CONNECTION) {                   // if the USB connection was being used for debug menu, restore previous interface
    #if defined SERIAL_INTERFACE && defined DEMO_UART                    // {8}
                    DebugHandle = SerialPortID;
    #else
                    DebugHandle = NETWORK_HANDLE;
    #endif
    #ifdef USE_MAINTENANCE                                               // {2}
                    fnGotoNextState(ES_NO_CONNECTION);
    #endif
                    usUSB_state = ES_NO_CONNECTION;
                }
#elif defined USE_USB_HID_MOUSE
                iUSB_mouse_state = 0;                                    // mark that the mouse function is not active
                uTaskerStopTimer(OWN_TASK);
#endif
                fnSetUSBConfigState(USB_DEVICE_SUSPEND, 0);              // set all endpoint states to suspended
                fnDebugMsg("USB Suspended\n\r");
                DEL_USB_SYMBOL();                                        // {21}
                break;
            case EVENT_USB_RESUME:                                       // a resume sequence has been detected so full power consumption can be resumed
                fnSetUSBConfigState(USB_DEVICE_RESUME, 0);               // remove suspended state from all endpoints
                fnDebugMsg("USB Resume\n\r");
                SET_USB_SYMBOL();                                        // {21}
#if defined USE_USB_HID_MOUSE                                            // {23}
                iUSB_mouse_state = 1;                                    // mark that the mouse function is active
                uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(0.05*SEC), T_MOUSE_ACTION);
                break;
#elif defined USE_USB_MSD
            case TX_FREE:
                fnContinueMedia();                                       // the output buffer has space so continue with data transfer
                break;
#else
            case EVENT_RETURN_PRESENT_UART_SETTING:                      // the CDC class host is requesting our serial settings
                fnReturnUART_settings();
                break;

            case EVENT_COMITT_NEW_UART_SETTING:                          // the CDC host has sent new UART settings - we comitt them here
                fnComitt_UART();
                break;
#endif
            }
            break;

        case TASK_USB:                                                   // USB interrupt handler is requesting us to perform work offline
            fnRead(PortIDInternal, &ucInputMessage[MSG_CONTENT_COMMAND], ucInputMessage[MSG_CONTENT_LENGTH]); // get the content
            switch (ucInputMessage[MSG_CONTENT_COMMAND]) {
            case E_USB_ACTIVATE_CONFIGURATION:
                fnDebugMsg("Enumerated (");                              // the interface has been activated and enumeration completed
                fnDebugDec(ucInputMessage[MSG_CONTENT_COMMAND + 1], 1);  // {10} the configuration
                fnDebugMsg(")\n\r");
                SET_USB_SYMBOL();                                        // {21}
#ifdef USE_USB_HID_MOUSE
                iUSB_mouse_state = 1;                                    // mark that the mouse function is active
                uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(0.05*SEC), T_MOUSE_ACTION);
#endif
                break;
            }
            break;

        default:
            break;
        }
    }
#if !defined MODBUS_USB_SLAVE && !defined USE_USB_HID_MOUSE              // {11}{23}
    while (fnMsgs(USBPortID_comms) != 0) {                               // reception from endpoint 1
    #if defined USE_USB_MSD        
        if (ulWriteBlock != 0) {                                         // write data expected
            static unsigned char ucBuffer[512];                          // intermediate buffer to collect each sector content
            Length = fnRead(USBPortID_comms, &ucBuffer[iContent], (QUEUE_TRANSFER)(512 - iContent)); // read the content directly to the intermediate buffer
            ulWriteBlock -= Length;
            iContent += Length;
            if (iContent >= 512) {                                       // input buffer is complete
                fnWriteSector(DISK_D, ucBuffer, ulLogicalBlockAdr++);    // commit the buffer content to the media
                iContent = 0;                                            // reset intermediate buffer
                if (ulWriteBlock != 0) {
                    uTaskerStateChange(OWN_TASK, UTASKER_ACTIVATE);      // {17} yield after a write when further data is expected but schedule again immediately to read any remaining queue content
                    return;
                }
            }
            if (ulWriteBlock != 0) {                                     // more data expected
                continue;
            }                                                            // allow CSW to be sent after a complete transfer has completed
        }
        else {
          //unsigned long ulTransferLength;
            USB_MASS_STORAGE_CBW *ptrCBW;
            Length = fnRead(USBPortID_comms, ucInputMessage, LARGE_MESSAGE); // read the content
            ptrCBW = (USB_MASS_STORAGE_CBW *)ucInputMessage;
          //ulTransferLength = (ptrCBW->dCBWDataTransferLength[0] | (ptrCBW->dCBWDataTransferLength[1] << 8) | (ptrCBW->dCBWDataTransferLength[2] << 16) | (ptrCBW->dCBWDataTransferLength[3] << 24));
            uMemcpy(&csw.dCBWTag, ptrCBW->dCBWTag, sizeof(csw.dCBWTag)); // save the tag
            csw.dCSWDataResidue[0] = 0;
            csw.dCSWDataResidue[1] = 0;
            csw.dCSWDataResidue[2] = 0;
            csw.dCSWDataResidue[3] = 0;
            csw.bCSWStatus = CSW_STATUS_COMMAND_PASSED;                  // set for success
            fnFlush(USBPortID_comms, FLUSH_TX);                          // always flush the tx buffer to ensure message alignment in buffer before responding
            if (ptrCBW->CBWCB[CBW_OperationCode] != UFI_REQUEST_SENSE) { // if not a sense request reset the sense information
                uMemcpy(&present_sense_data, &sense_data, sizeof(sense_data));
            }
            if (ptrCBW->dmCBWFlags & CBW_IN_FLAG) {
                switch (ptrCBW->CBWCB[CBW_OperationCode]) {
                case UFI_FORMAT_UNIT:
                    break;
                case UFI_INQUIRY:
                    {
                        CBW_INQUIRY_COMMAND *ptrInquiry = (CBW_INQUIRY_COMMAND *)ptrCBW->CBWCB;
                        unsigned char ucLogicalUnitNumber = (ptrInquiry->ucLogicalUnitNumber_EVPD >> 5);
                        QUEUE_TRANSFER inquiry_length;
                        unsigned char *ptrInquiryData = fnGetPartition(ucLogicalUnitNumber, &inquiry_length);
                        if (ptrInquiryData == 0) {                       // partition doesn't exist
                            csw.bCSWStatus = CSW_STATUS_COMMAND_FAILED;
                        }
                        else {
                            fnWrite(USBPortID_comms, ptrInquiryData, inquiry_length); // respond to the request and then return 
                        }
                    }
                    break;
                case UFI_MODE_SENSE_6:                                   // {15}
                    {
                        MODE_PARAMETER_6 SelectDataWP;
                        uMemcpy(&SelectDataWP, &SelectData, sizeof(SelectData));
                        if (ptrDiskInfo->usDiskFlags & WRITE_PROTECTED_SD_CARD) {
                            SelectDataWP.ucWP_DPOFUA = PAR6_WRITE_PROTECTED; // the medium is write protected
                        }
                        fnWrite(USBPortID_comms, (unsigned char *)&SelectDataWP, sizeof(SelectData)); // respond to the request and then return 
                    }
                    break;
                case UFI_START_STOP:
                case UFI_MODE_SELECT:
              //case UFI_MODE_SENSE:
                case UFI_PRE_ALLOW_REMOVAL:
                    break;
                case UFI_READ_10:
                case UFI_READ_12:
                    {                                
                        CBW_READ_10 *ptrRead = (CBW_READ_10 *)ptrCBW->CBWCB;
                        ulLogicalBlockAdr = ((ptrRead->ucLogicalBlockAddress[0] << 24) | (ptrRead->ucLogicalBlockAddress[1] << 16) | (ptrRead->ucLogicalBlockAddress[2] << 8) | ptrRead->ucLogicalBlockAddress[3]);
                        if (ptrRead->ucOperationCode == UFI_READ_12) {
                            CBW_READ_12 *ptrRead = (CBW_READ_12 *)ptrCBW->CBWCB;
                            ulReadBlock = ((ptrRead->ucTransferLength[0] << 24) | (ptrRead->ucTransferLength[1] << 16) | (ptrRead->ucTransferLength[2] << 8) | ptrRead->ucTransferLength[3]);
                        }
                        else {
                            ulReadBlock = ((ptrRead->ucTransferLength[0] << 8) | ptrRead->ucTransferLength[1]); // the total number of blocks to be returned
                        }
                        fnContinueMedia();
                        continue;                                        // the transfer has not completed so don't sent termination stage yet
                    }
                    break;
                case UFI_READ_CAPACITY:
                    {
                      //CBW_READ_CAPACITY *ptrCapacities = (CBW_READ_CAPACITY *)ptrCBW->CBWCB;
                        CBW_READ_CAPACITY_DATA formatData;
                        formatData.ucBlockLengthInBytes[0] = 0;
                        formatData.ucBlockLengthInBytes[1] = 0;
                        formatData.ucBlockLengthInBytes[2] = (unsigned char)(ptrDiskInfo->utFAT.usBytesPerSector >> 8);
                        formatData.ucBlockLengthInBytes[3] = (unsigned char)(ptrDiskInfo->utFAT.usBytesPerSector);
                        formatData.ucLastLogicalBlockAddress[0] = (unsigned char)(ptrDiskInfo->ulSD_sectors >> 24);
                        formatData.ucLastLogicalBlockAddress[1] = (unsigned char)(ptrDiskInfo->ulSD_sectors >> 16);
                        formatData.ucLastLogicalBlockAddress[2] = (unsigned char)(ptrDiskInfo->ulSD_sectors >> 8);
                        formatData.ucLastLogicalBlockAddress[3] = (unsigned char)(ptrDiskInfo->ulSD_sectors);
                        fnWrite(USBPortID_comms, (unsigned char *)&formatData, sizeof(formatData));
                    }
                    break;
                case UFI_READ_FORMAT_CAPACITY:
                    {
                        CBW_FORMAT_CAPACITIES *ptrCapacities = (CBW_FORMAT_CAPACITIES *)ptrCBW->CBWCB;
                        unsigned short usLengthAccepted = ((ptrCapacities->ucAllocationLength[0] << 8) | (ptrCapacities->ucAllocationLength[1]));
                        CBW_CAPACITY_LIST mediaCapacity;
                        uMemcpy(&mediaCapacity, &formatCapacityNoMedia, sizeof(CBW_CAPACITY_LIST)); // assume no disk
                        if (ptrDiskInfo->usDiskFlags & (DISK_MOUNTED | DISK_UNFORMATTED)) { // {16}
                            if (ptrDiskInfo->usDiskFlags & DISK_FORMATTED) {
                                mediaCapacity.capacityDescriptor.ucDescriptorCode = DESC_CODE_FORMATTED_MEDIA;
                            }
                            else {
                                mediaCapacity.capacityDescriptor.ucDescriptorCode = DESC_CODE_UNFORMATTED_MEDIA;
                            }
                            mediaCapacity.capacityDescriptor.ucNumberOfBlocks[3] = (unsigned char)ptrDiskInfo->ulSD_sectors;
                            mediaCapacity.capacityDescriptor.ucNumberOfBlocks[2] = (unsigned char)(ptrDiskInfo->ulSD_sectors >> 8);
                            mediaCapacity.capacityDescriptor.ucNumberOfBlocks[1] = (unsigned char)(ptrDiskInfo->ulSD_sectors >> 16);
                            mediaCapacity.capacityDescriptor.ucNumberOfBlocks[0] = (unsigned char)(ptrDiskInfo->ulSD_sectors >> 24);
                        }                                
                        if (usLengthAccepted > sizeof(CBW_CAPACITY_LIST)) {
                            usLengthAccepted = sizeof(CBW_CAPACITY_LIST);
                        }
                        fnWrite(USBPortID_comms, (unsigned char *)&mediaCapacity, usLengthAccepted);
                    }
                    break;
                case UFI_REQUEST_SENSE:
                    fnWrite(USBPortID_comms, (unsigned char *)&present_sense_data, sizeof(present_sense_data));                
                    break;
                case UFI_REZERO_UNIT:
                case UFI_SEEK_10:
                case UFI_SEND_DIAGNOSTIC:
                case UFI_VERIFY:
                case UFI_WRITE_AND_VERIFY:
                default:
                    break;
                }
            }
            else {
                switch (ptrCBW->CBWCB[CBW_OperationCode]) {
                case UFI_TEST_UNIT_READY:
                    {
                        CBW_TEST_UNIT_READY *ptrTest = (CBW_TEST_UNIT_READY *)ptrCBW->CBWCB;
                        unsigned char ucLogicalUnitNumber = (ptrTest->ucLogicalUnitNumber_EVPD >> 5);
                        if (fnGetPartition(ucLogicalUnitNumber, 0) == 0) {
                            csw.bCSWStatus = CSW_STATUS_COMMAND_FAILED;
                        }
                    }
                    break;
                case UFI_WRITE_10:
                case UFI_WRITE_12:
                    {
                        CBW_WRITE_10 *ptrWrite = (CBW_WRITE_10 *)ptrCBW->CBWCB;
                        ulLogicalBlockAdr = ((ptrWrite->ucLogicalBlockAddress[0] << 24) | (ptrWrite->ucLogicalBlockAddress[1] << 16) | (ptrWrite->ucLogicalBlockAddress[2] << 8) | ptrWrite->ucLogicalBlockAddress[3]);
                        if (ptrWrite->ucOperationCode == UFI_WRITE_12) {
                            CBW_WRITE_12 *ptrWrite = (CBW_WRITE_12 *)ptrCBW->CBWCB;
                            ulWriteBlock = ((ptrWrite->ucTransferLength[0] << 24) | (ptrWrite->ucTransferLength[1] << 16) | (ptrWrite->ucTransferLength[2] << 8) | ptrWrite->ucTransferLength[3]);
                        }
                        else {
                            ulWriteBlock = ((ptrWrite->ucTransferLength[0] << 8) | ptrWrite->ucTransferLength[1]); // the total number of blocks to be returned
                        }
                        ulWriteBlock *= 512;                             // convert to byte count
                    }
                    continue;                                            // data will follow so don't reply with CSW stage yet
                }
            }
        }
        fnWrite(USBPortID_comms, (unsigned char *)&csw, sizeof(csw));    // close with CSW stage
    #elif defined USE_MAINTENANCE
        if (usUSB_state & (ES_USB_DOWNLOAD_MODE | ES_USB_RS232_MODE)) {
            if (usUSB_state & ES_USB_RS232_MODE) {
        #if defined SERIAL_INTERFACE && defined DEMO_UART                // {8}
                if (fnWrite(SerialPortID, 0, MEDIUM_MESSAGE) != 0) {     // check that there is space for a block of data
                    Length = fnRead(USBPortID_comms, ucInputMessage, MEDIUM_MESSAGE); // read the content
                    fnWrite(SerialPortID, ucInputMessage, Length);       // send input to serial port
                }
                else {
                    fnDriver(SerialPortID, MODIFY_WAKEUP, (MODIFY_TX | OWN_TASK)); // we want to be woken when the queue is free again
                    break;                                               // leave present USB data in the input buffer until we have enough serial output buffer space
                                                                         // the TX_FREE event is not explicitly handled since it is used to wake a next check of the buffer progress
                }
        #else
            fnRead(USBPortID_comms, ucInputMessage, LARGE_MESSAGE);      // read the content to empty the queue
        #endif
            }
            else {
                Length = fnRead(USBPortID_comms, ucInputMessage, LARGE_MESSAGE); // read the content
        #ifdef ACTIVE_FILE_SYSTEM
                fnDownload(ucInputMessage, Length);                      // pass the input to the downloader
        #endif
            }
            continue;
        }
        else {
            Length = fnRead(USBPortID_comms, ucInputMessage, LARGE_MESSAGE); // read the content
        }
        fnWrite(USBPortID_comms, ucInputMessage, Length);                // echo input
        if (usUSB_state == ES_NO_CONNECTION) {
            if (fnCommandInput(ucInputMessage, Length, SOURCE_USB)) {
                if (fnInitiateLogin(ES_USB_LOGIN) == TELNET_ON_LINE) {
                    static const CHAR ucCOMMAND_MODE_BLOCKED[] = "Command line blocked\r\n";
                    fnWrite(USBPortID_comms, (unsigned char *)ucCOMMAND_MODE_BLOCKED, sizeof(ucCOMMAND_MODE_BLOCKED));
                }
            }
        }
        else {
            fnCommandInput(ucInputMessage, Length, SOURCE_USB);
        }
    #else
        Length = fnRead(USBPortID_comms, ucInputMessage, LARGE_MESSAGE); // read the content
        #if defined SERIAL_INTERFACE && defined DEMO_UART                // {8}
        fnWrite(SerialPortID, ucInputMessage, Length);                   // send input to serial port (data loss not respected)
        #endif
    #endif
    }
#endif
}

#if defined USE_USB_HID_MOUSE                                            // {23}
//
#elif defined USE_USB_MSD
// The output buffer has space so continue with data transfer or terminate
//
static void fnContinueMedia(void)
{
    QUEUE_TRANSFER buffer_space = fnWrite(USBPortID_comms, 0, 0);        // check whether there is space available in the USB output buffer to queue
    while ((ulReadBlock != 0) && (buffer_space >= 512)) {                // send as many blocks as possible as long as the output buffer has space
        if (UTFAT_SUCCESS == fnReadSector(0, 0, ulLogicalBlockAdr)) {
            fnWrite(USBPortID_comms, ptrDiskInfo->ptrSectorData, 512);
            buffer_space -= 512;
            ulLogicalBlockAdr++;
        }
        else {
            // Error reading media
            //
        }
        ulReadBlock--;
    }
    if (ulReadBlock == 0) {                                              // all blocks have been read and put to the output queue
        if (buffer_space >= sizeof(csw)) {
            fnWrite(USBPortID_comms, (unsigned char *)&csw, sizeof(csw));// close with CSW stage
            return;
        }
    }
    if (buffer_space < 512) {
        fnDriver(USBPortID_comms, MODIFY_WAKEUP, (MODIFY_TX | TASK_USB));// when there is room in the output buffer the task will be woken
    }
}
#endif

// Called to transmit data from defined USB endpoint (serial input uses this)
//
extern QUEUE_TRANSFER fnSendToUSB(unsigned char *ptrData, QUEUE_TRANSFER Length)
{
    return (fnWrite(USBPortID_comms, ptrData, Length));                  // send to endpoint 2
}

// Set the global debug interface handle to the USB handle
//
extern void fnSetUSB_debug(void)
{
    DebugHandle = USBPortID_comms;
}

// The application must always supply this routine and return its device descriptor when requested
// This example shows a single fixed device configuration but multiple configurations could be selected (eg. for experimental use)
//
extern void *fnGetUSB_device_descriptor(unsigned short *usLength)
{
    *usLength = sizeof(device_descriptor);
    return (void *)&device_descriptor;
}

// The application must always supply this routine and return its configuration descriptor when requested
// This example shows a single fixed configuration but multiple configurations could be selected (eg. for programmable device types)
//
extern void *fnGetUSB_config_descriptor(unsigned short *usLength)
{
    *usLength = sizeof(config_descriptor);
    return (void *)&config_descriptor;
}

#if defined USB_STRING_OPTION
    #if defined USB_RUN_TIME_DEFINABLE_STRINGS
// This routine constructs a USB string descriptor for use by the USB interface during emumeration.
// The new string has to respect the descriptor format (using UNICODE) and is built in preparation so that it can be passed in an interrupt.
static void fnSetSerialNumberString(CHAR *ptrSerialNumber) {             // {12}
    unsigned char ucDescriptorLength = (sizeof(USB_STRING_DESCRIPTOR) - 2);
    unsigned char *ptrString;
    int iStringLength = (uStrlen(ptrSerialNumber)*2);
    if (iStringLength == 0) {
        ucDescriptorLength += 2;                                         // space for a null-terminator
    }
    else {
        ucDescriptorLength += iStringLength;
    }
    if (!SerialNumberDescriptor) {
        SerialNumberDescriptor = uMalloc(ucDescriptorLength);            // get memory to store the string descriptor
        SerialNumberDescriptor->bLength = ucDescriptorLength;
        SerialNumberDescriptor->bDescriptorType = DESCRIPTOR_TYPE_STRING;
    }
    ptrString = &SerialNumberDescriptor->unicode_string_space[0];
    if (iStringLength == 0) {
        *ptrString++ = 0;                                                // when no string add a null-terminator
        *ptrString++ = 0;
    }
    else {
        while (*ptrSerialNumber != 0) {
            *ptrString++ = *ptrSerialNumber++;                           // unicode - english string (requiring just zeros to be added)
            *ptrString++ = 0;
        }
    }
}
    #endif


// This routine must always be supplied by the user if usb strings are supported
//
extern unsigned char *fnGetUSB_string_entry(unsigned short usStringRef, unsigned short *usLength)
{
    if (usStringRef > LAST_STRING_INDEX) {
        return 0;                                                        // invalid string index
    }
    #if defined USB_RUN_TIME_DEFINABLE_STRINGS                           // if variable strings are supported
    if (ucStringTable[usStringRef][0] == 0) {                            // no length defined, meaning it is a run-time definabled string
        switch (usStringRef) {
        case SERIAL_NUMBER_STRING_INDEX:                                 // USB driver needs to know what string is used as serial number
            *usLength = (unsigned short)SerialNumberDescriptor->bLength; // return length and location of the user defined serial number
            return (unsigned char *)SerialNumberDescriptor;
        default:
            return 0;                                                    // invalid string index
        }
    }
    else {
        *usLength = ucStringTable[usStringRef][0];                       // the length of the string
    }
    #else
    *usLength = ucStringTable[usStringRef][0];                           // the length of the string
    #endif
    return ((unsigned char *)ucStringTable[usStringRef]);                // return a pointer to the string
}
#endif

#if defined USE_USB_CDC
// Convert UART interface settings format to CDC setting format and report to CDC host
//
static void fnReturnUART_settings(void)
{
    unsigned long ulSpeed;

    switch (temp_pars->temp_parameters.ucSerialSpeed) {                  // set present Baud
    case SERIAL_BAUD_300:
        ulSpeed = 300;
        break;
    case SERIAL_BAUD_600:
        ulSpeed = 600;
        break;
    case SERIAL_BAUD_1200:
        ulSpeed = 1200;
        break;
    case SERIAL_BAUD_2400:
        ulSpeed = 2400;
        break;
    case SERIAL_BAUD_4800:
        ulSpeed = 4800;
        break;
    case SERIAL_BAUD_9600:
        ulSpeed = 9600;
        break;
    case SERIAL_BAUD_14400:
        ulSpeed = 14400;
        break;
    case SERIAL_BAUD_19200:
    default:
        ulSpeed = 19200;
        break;
    case SERIAL_BAUD_38400:
        ulSpeed = 38400;
        break;
    case SERIAL_BAUD_57600:
        ulSpeed = 57600;
        break;
    case SERIAL_BAUD_115200:
        ulSpeed = 115200;
        break;
    case SERIAL_BAUD_230400:
        ulSpeed = 230400;
        break;
    case SERIAL_BAUD_250K:
        ulSpeed = 250000;
        break;
    }
    uart_setting.dwDTERate[0] = (unsigned char)ulSpeed;
    ulSpeed >>= 8;
    uart_setting.dwDTERate[1] = (unsigned char)ulSpeed;
    ulSpeed >>= 8;
    uart_setting.dwDTERate[2] = (unsigned char)ulSpeed;
    ulSpeed >>= 8;
    uart_setting.dwDTERate[3] = (unsigned char)ulSpeed;

    if (temp_pars->temp_parameters.usSerialMode & CHAR_7) {              // set present character length
        uart_setting.bDataBits = CDC_PSTN_7_DATA_BITS;
    }
    else {
        uart_setting.bDataBits = CDC_PSTN_8_DATA_BITS;
    }

    if (temp_pars->temp_parameters.usSerialMode & RS232_EVEN_PARITY) {   // set present parity
        uart_setting.bParityType = CDC_PSTN_EVEN_PARITY;
    }
    else if (temp_pars->temp_parameters.usSerialMode & RS232_ODD_PARITY) {
        uart_setting.bParityType = CDC_PSTN_ODD_PARITY;
    }
    else {
        uart_setting.bParityType = CDC_PSTN_NO_PARITY;
    }

    if (temp_pars->temp_parameters.usSerialMode & ONE_HALF_STOPS) {      // set present format
        uart_setting.bCharFormat = CDC_PSTN_1_5_STOP_BIT;
    }
    else if (temp_pars->temp_parameters.usSerialMode & TWO_STOPS) {
        uart_setting.bCharFormat = CDC_PSTN_2_STOP_BITS;
    }
    else {
        uart_setting.bCharFormat = CDC_PSTN_1_STOP_BIT;
    }
    fnWrite(USB_control, (unsigned char *)&uart_setting, sizeof(uart_setting)); // return directly (non-buffered)
}

// Convert new UART settings from the CDC host
//
static void fnNewUART_settings(unsigned char *ptrData, unsigned short usLength, unsigned short usExpected)
{
    unsigned char *ptrSet = (unsigned char *)&uart_setting;

    if (usExpected > sizeof(uart_setting)) {                             // some protection against corrupted reception
        usExpected = sizeof(uart_setting);
    }
    if (usLength > usExpected) {
        usLength = usExpected;
    }

    ptrSet += sizeof(uart_setting) - usExpected;;
    uMemcpy(ptrSet, ptrData, usLength);

    if (usLength >= usExpected) {                                        // all data has been copied
        fnInterruptMessage(OWN_TASK, EVENT_COMITT_NEW_UART_SETTING);
    }
}

// Convert the CDC setting format to the UART interface settings format and modify the UART setting
//
static void fnComitt_UART(void)
{
    unsigned long ulSpeed = uart_setting.dwDTERate[0];
    ulSpeed |= (uart_setting.dwDTERate[1] << 8);
    ulSpeed |= (uart_setting.dwDTERate[2] << 16);
    ulSpeed |= (uart_setting.dwDTERate[3] << 24);

    if (ulSpeed > 230400) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_250K;
    }
    else if (ulSpeed > 115200) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_230400;
    }
    else if (ulSpeed > 57600) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_115200;
    }
    else if (ulSpeed > 38400) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_57600;
    }
    else if (ulSpeed > 19200) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_38400;
    }
    else if (ulSpeed > 14400) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_19200;
    }
    else if (ulSpeed > 9600) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_14400;
    }
    else if (ulSpeed > 4800) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_9600;
    }
    else if (ulSpeed > 2400) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_4800;
    }
    else if (ulSpeed > 1200) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_2400;
    }
    else if (ulSpeed > 600) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_1200;
    }
    else if (ulSpeed > 300) {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_600;
    }
    else {
        temp_pars->temp_parameters.ucSerialSpeed = SERIAL_BAUD_300;
    }

    if (uart_setting.bDataBits == CDC_PSTN_7_DATA_BITS) {
        temp_pars->temp_parameters.usSerialMode |= CHAR_7;
    }
    else {
        temp_pars->temp_parameters.usSerialMode &= ~CHAR_7;
    }

    switch (uart_setting.bParityType) {
    case CDC_PSTN_EVEN_PARITY:
        temp_pars->temp_parameters.usSerialMode |= RS232_EVEN_PARITY;
        temp_pars->temp_parameters.usSerialMode &= ~RS232_ODD_PARITY;
        break;
    case CDC_PSTN_ODD_PARITY:
        temp_pars->temp_parameters.usSerialMode &= ~RS232_EVEN_PARITY;
        temp_pars->temp_parameters.usSerialMode |= RS232_ODD_PARITY;
        break;
    default:
        temp_pars->temp_parameters.usSerialMode &= ~RS232_EVEN_PARITY;
        temp_pars->temp_parameters.usSerialMode &= ~RS232_ODD_PARITY;
        break;
    }

    switch (uart_setting.bCharFormat) {
    case CDC_PSTN_1_5_STOP_BIT:
        temp_pars->temp_parameters.usSerialMode |= ONE_HALF_STOPS;
        temp_pars->temp_parameters.usSerialMode &= ~TWO_STOPS;
        break;
    case CDC_PSTN_2_STOP_BITS:
        temp_pars->temp_parameters.usSerialMode &= ~ONE_HALF_STOPS;
        temp_pars->temp_parameters.usSerialMode |= TWO_STOPS;
        break;
    default:
        temp_pars->temp_parameters.usSerialMode &= ~ONE_HALF_STOPS;
        temp_pars->temp_parameters.usSerialMode &= ~TWO_STOPS;
        break;
    }

#if defined SERIAL_INTERFACE && defined DEMO_UART                        // {8}
    fnSetNewSerialMode(MODIFY_CONFIG);
#endif
}
#endif

#if defined USE_USB_HID_MOUSE
#elif defined USE_USB_CDC
#elif defined USE_USB_MSD
static int mass_storage_callback(unsigned char *ptrData, unsigned short length, int iType)
{
    if (ulWriteBlock != 0) {                                             // data expected
        return TRANSPARENT_CALLBACK;                                     // handle data in task
    }
    if (!uMemcmp(cCBWSignature, ptrData, sizeof(cCBWSignature))) {
        USB_MASS_STORAGE_CBW *ptrCBW = (USB_MASS_STORAGE_CBW *)ptrData;
        if (fnGetPartition(ptrCBW->dCBWLUN, 0) != 0) {                   // if valid storage device
            if ((ptrCBW->dCBWCBLength > 0) && (ptrCBW->dCBWCBLength <= 16)) { // check for valid length
                if (ptrCBW->dmCBWFlags & CBW_IN_FLAG) {
                    switch (ptrCBW->CBWCB[CBW_OperationCode]) {
                    case UFI_MODE_SENSE_6:
                        {                                                // {15}
                            CBW_MODE_SENSE_6 *ptrSense = (CBW_MODE_SENSE_6 *)ptrCBW->CBWCB;
                            unsigned char ucLogicalUnitNumber = (ptrSense->ucLogicalUnitNumber_DBD >> 5);
                            if (fnGetPartition(ucLogicalUnitNumber, 0) != 0) {
                                if ((ptrSense->ucPC_PageCode & MODE_SENSE_6_PAGE_CODE_ALL_PAGES) == MODE_SENSE_6_PAGE_CODE_ALL_PAGES) { // only accept all page request
                                    return TRANSPARENT_CALLBACK;         // accept to be handled by task
                                }
                            }
                        }
                        break;                                           // stall
                    case UFI_REQUEST_SENSE:
                    case UFI_INQUIRY:
                    case UFI_READ_CAPACITY:
                        return TRANSPARENT_CALLBACK;                     // the callback has done its work and the input buffer can now be used
                    case UFI_READ_10:
                    case UFI_READ_12:
                    case UFI_READ_FORMAT_CAPACITY:
                        if (ptrDiskInfo->usDiskFlags & (DISK_MOUNTED | DISK_UNFORMATTED)) { // {16} only respond when there is media inserted, else stall
                            return TRANSPARENT_CALLBACK;                 // the callback has done its work and the input buffer can now be used
                        }
                        present_sense_data.ucValid_ErrorCode = (VALID_SENSE_DATA | CURRENT_ERRORS);
                        present_sense_data.ucSenseKey = SENSE_NOT_READY;
                        present_sense_data.ucAdditionalSenseCode = DESC_MEDIUM_NOT_PRESENT;
                        break;                                           // stall
                    default:
                        break;                                           // stall
                    }
                }
                else {
                    switch (ptrCBW->CBWCB[CBW_OperationCode]) {
                    case UFI_PRE_ALLOW_REMOVAL:
                    case UFI_TEST_UNIT_READY:
                        return TRANSPARENT_CALLBACK;                     // the callback has done its work and the input buffer can now be used
                    case UFI_WRITE_10:
                    case UFI_WRITE_12:
                        if (ptrDiskInfo->usDiskFlags & (DISK_MOUNTED | DISK_UNFORMATTED)) { // {16} only respond when there media inserted, else stall
                            return TRANSPARENT_CALLBACK;                 // the callback has done its work and the input buffer can now be used
                        }
                        present_sense_data.ucValid_ErrorCode = (VALID_SENSE_DATA | CURRENT_ERRORS);
                        present_sense_data.ucSenseKey = SENSE_NOT_READY;
                        present_sense_data.ucAdditionalSenseCode = DESC_MEDIUM_NOT_PRESENT;
                        break;                                           // stall
                    default:
                        break;
                    }
                }
                uMemcpy(&csw.dCBWTag, ptrCBW->dCBWTag, sizeof(csw.dCBWTag)); // save the tag since we will halt
                uMemcpy(csw.dCSWDataResidue, &ptrCBW->dCBWDataTransferLength, sizeof(csw.dCSWDataResidue)); // since no data will be processes the residue is equal to the requested transfer length
                csw.bCSWStatus = CSW_STATUS_COMMAND_FAILED;              // set fail
            }
        }
    }
    return STALL_ENDPOINT;                                               // stall on any invalid formats
}

// Get partition details - used to ease support of multiple LUNs (Logical Units)
//
static unsigned char *fnGetPartition(unsigned char ucLUN, QUEUE_TRANSFER *length)
{
    if (ucLUN >= NUMBER_OF_PARTITIONS) {
        return 0;                                                        // invalid LUN
    }
    if (length != 0) {
        *length = sizeof(inquiryData);                                   // the inquiry data length
    }
    return (unsigned char *)&inquiryData;                                // the fixed inquiry data
}
#endif

// Endpoint 0 callback for any non-supported control transfers.
// This can be called with either setup frame content (iType != 0) or with data belonging to following OUT frames.
// TERMINATE_ZERO_DATA must be returned to setup tokens with NO further data, when there is no response sent.
// BUFFER_CONSUMED_EXPECT_MORE is returned when extra data is to be received.
// STALL_ENDPOINT should be returned if the request in the setup frame is not expected.
// Return BUFFER_CONSUMED in all other cases.
//
// If further data is to be received, this may arrive in multiple frames and the callback needs to manage this to be able to know when the data is complete
//
static int control_callback(unsigned char *ptrData, unsigned short length, int iType)
{
    static unsigned short usExpectedData = 0;
    static unsigned char ucCollectingMode = 0;
    int iRtn = BUFFER_CONSUMED;
    switch (iType) {
#if defined USE_USB_HID_MOUSE                                            // {23}
        //
#elif defined USE_USB_MSD
    case ENDPOINT_CLEARED:                                               // halted endpoint has been freed
    #if defined _LPC23XX || defined _LPC17XX                             // {20}
        if (*ptrData == (IN_ENDPOINT | 0x05))                            // BULK IN 5 is the only endpoint that is expect to be halted
    #else
        if (*ptrData == (IN_ENDPOINT | 0x02))                            // BULK IN 2 is the only endpoint that is expect to be halted
    #endif
        {
            fnWrite(USBPortID_comms, (unsigned char *)&csw, sizeof(csw));// answer with the failed CSW on next endpoint 1 OUT
        }
        return TERMINATE_ZERO_DATA;                                      // send zero data to terminate the halt phase
#endif
    case SETUP_DATA_RECEPTION:
        {
            USB_SETUP_HEADER *ptrSetup = (USB_SETUP_HEADER *)ptrData;    // interpret the received data as a setup header
#if !defined USE_USB_HID_MOUSE                                           // {23}
            if ((ptrSetup->bmRequestType & ~STANDARD_DEVICE_TO_HOST) != REQUEST_INTERFACE_CLASS) { // 0x21
                return STALL_ENDPOINT;                                   // stall on any unsupported request types
            }
#endif
            usExpectedData = ptrSetup->wLength[0];                       // the amount of additional data which is expected to arrive from the host belonging to this request
            usExpectedData |= (ptrSetup->wLength[1] << 8);
            if (ptrSetup->bmRequestType & STANDARD_DEVICE_TO_HOST) {     // request for information
                switch (ptrSetup->bRequest) {
#if defined USE_USB_HID_MOUSE                                            // {23}
                case USB_REQUEST_GET_DESCRIPTOR:                         // standard request
                    if (ptrSetup->wValue[1] == DESCRIPTOR_TYPE_REPORT) {
                        fnWrite(USB_control, (unsigned char *)&ucMouseReport, sizeof(ucMouseReport)); // return directly (non-buffered)
                    }
                    else {
                        return STALL_ENDPOINT;                           // not supported
                    }
                    break;
#elif defined USE_USB_MSD
                case BULK_ONLY_MASS_STORAGE_RESET:
                    break;
                case GET_MAX_LUN:
                    {
                        static const unsigned char ucPartitions = (NUMBER_OF_PARTITIONS - 1);
                        if ((ptrSetup->wValue[0] != 0) || (ptrSetup->wValue[1] != 0) || (ptrSetup->wIndex[0] != 0) || (ptrSetup->wIndex[1] != 0) || (ptrSetup->wLength[0] != 1) || (ptrSetup->wLength[1] != 0)) {
                            return STALL_ENDPOINT;                       // stall if bad request format
                        }
                        else {
                            fnWrite(USB_control, (unsigned char *)&ucPartitions, sizeof(ucPartitions)); // return directly (non-buffered)
                        }
                    }
                    break;
#else
                case GET_LINE_CODING:
                    fnInterruptMessage(OWN_TASK, EVENT_RETURN_PRESENT_UART_SETTING);
                    break;
#endif
                default:
                    return STALL_ENDPOINT;                               // stall on any unsupported requests
                }
            }
            else {                                                       // command
                iRtn = TERMINATE_ZERO_DATA;                              // {5} acknowledge receipt of the request if we have no data to return (default)
                switch (ptrSetup->bRequest) {
#if defined USE_USB_CDC                                                  // {23}
                case SET_LINE_CODING:                                    // 0x20 - the host is informing us of parameters
                    ucCollectingMode = ptrSetup->bRequest;               // the next OUT frame will contain the settings
                    iRtn = BUFFER_CONSUMED_EXPECT_MORE;                  // {5} the present buffer has been consumed but extra data is subsequently expected
                    break;

                case SET_CONTROL_LINE_STATE:                             // OUT - 0x22 (controls RTS and DTR)
    #if defined SERIAL_INTERFACE && defined SUPPORT_HW_FLOW && defined DEMO_UART  // {8}
                    if (ptrSetup->wValue[0] & CDC_RTS) {
                        fnDriver( SerialPortID, (MODIFY_CONTROL | SET_RTS), 0 );
                    }
                    else {
                        fnDriver( SerialPortID, (MODIFY_CONTROL | CLEAR_RTS), 0 );
                    }
                    if (ptrSetup->wValue[0] & CDC_DTR) {
                        fnDriver( SerialPortID, (MODIFY_CONTROL | SET_DTR), 0 );
                    }
                    else {
                        fnDriver( SerialPortID, (MODIFY_CONTROL | CLEAR_DTR), 0 );
                    }
    #endif
                    break;
#elif defined USE_USB_HID_MOUSE                                          // {23}
                case HID_SET_IDLE:                                       // 0x0a - this can silence a report
                    break;                                               // answer with zero data
#endif
                default:
                    return STALL_ENDPOINT;                               // stall on any unsupported requests
                }
            }

            if (length <= sizeof(USB_SETUP_HEADER)) {
                return iRtn;                                             // no extra data in this frame
            }
            length -= sizeof(USB_SETUP_HEADER);                          // header handled
            ptrData += sizeof(USB_SETUP_HEADER);
        }
        break;
    case STATUS_STAGE_RECEPTION:                                         // this is the status stage of a control transfer - it confirms that the exchange has completed and can be ignored if not of interest to us
        return BUFFER_CONSUMED;
    default:                                                             // OUT_DATA_RECEPTION
        break;
    }

    if (usExpectedData != 0) {
        switch (ucCollectingMode) {
#if defined USE_USB_CDC
        case SET_LINE_CODING:
            fnNewUART_settings(ptrData, length, usExpectedData);         // set the new UART mode (the complete data will always be received here so we can always terminate now, otherwise BUFFER_CONSUMED_EXPECT_MORE would be returned until complete)
            iRtn = TERMINATE_ZERO_DATA;                                  // {5}
            break;
#endif
        default:
            break;
        }
        ucCollectingMode = 0;                                            // {9} reset to avoid repeat of command when subsequent, invalid commands are received
    }
                                                                         // handle any (additional) data here
    if (length >= usExpectedData) {
        usExpectedData = 0;                                              // all of the expected data belonging to this transfer has been received
    }
    else {
        usExpectedData -= length;                                        // remaining length to be received before transaction has completed
    }
                                                                         // handle and control commands here
    return iRtn;
}



// The USB interface is configured by opening the USB interface once for the default control endpoint 0,
// followed by an open of each endpoint to be used (each endpoint has its own handle). Each endpoint can use an optional callback
// or can define a task to be woken on OUT frames. Transmission can use direct memory method or else an output buffer (size defined by open),
// and receptions can use an optional input buffer (size defined by open).
//
static void fnConfigureUSB(void)
{
    USBTABLE tInterfaceParameters;                                       // table for passing information to driver

    tInterfaceParameters.Endpoint = 0;                                   // set USB default control endpoint for configuration
#ifdef OLIMEX_LPC2378_STK                                                // {20} this board requires alternative USB pin mapping
    tInterfaceParameters.usConfig = (USB_FULL_SPEED | USB_ALT_PORT_MAPPING); // full-speed, rather than low-speed - use alternative pins
#else
    tInterfaceParameters.usConfig = USB_FULL_SPEED;                      // full-speed, rather than low-speed
#endif
    tInterfaceParameters.usb_callback = control_callback;                // callback for control endpoint to enable class exchanges to be handled
    tInterfaceParameters.queue_sizes.TxQueueSize = 0;                    // no tx buffering
    tInterfaceParameters.queue_sizes.RxQueueSize = 0;                    // no rx buffering
#ifdef TWR_K60N512                                                       // {18}
    tInterfaceParameters.ucClockSource = INTERNAL_USB_CLOCK;             // use system clock and dividers
#else
    tInterfaceParameters.ucClockSource = EXTERNAL_USB_CLOCK;             // use 48MHz crystal directly as USB clock (recommended for lowest jitter)
#endif
#if defined _LPC23XX || defined _LPC17XX                                 // {14}
    tInterfaceParameters.ucEndPoints = 5;                                // due to fixed endpoint ordering in the LPC endpoints up to 5 are used
#else
    tInterfaceParameters.ucEndPoints = NUMBER_OF_ENDPOINTS;              // number of endpoints, in addition to EP0
#endif
    tInterfaceParameters.owner_task = OWN_TASK;                          // local task receives USB state change events
    #ifdef USE_USB_OTG_CHARGE_PUMP
    tInterfaceParameters.OTG_I2C_Channel = IICPortID;                    // let the driver open its own IIC interface, if not yet open
    #endif
    USB_control = fnOpen(TYPE_USB, 0, &tInterfaceParameters);            // open the default control endpoint with defined configurations (reserves resources but only control is active)

#if defined USE_USB_HID_MOUSE                                            // {23}
    tInterfaceParameters.usEndpointSize = 8;                             // endpoint queue size (2 buffers of this size will be created for reception)
    #if defined _LPC23XX || defined _LPC17XX
    tInterfaceParameters.Endpoint = 5;
    #else
    tInterfaceParameters.Endpoint = 1;
    #endif
    tInterfaceParameters.usb_callback = 0;
#else
    #if defined MODBUS_USB_SLAVE && defined USE_USB_CDC                  // {11}{23}
    tInterfaceParameters.owner_task = TASK_MODBUS;                       // receptions on this endpoint are to be handled by the MODBUS task
    #endif
    #if defined _LPC23XX || defined _LPC17XX                             // {14}
    tInterfaceParameters.Endpoint = 5;                                   // set USB endpoints to act as an input/output pair - transmitter (IN)
    tInterfaceParameters.Paired_RxEndpoint = 2;                          // receiver (OUT)
    #else
    tInterfaceParameters.Endpoint = 2;                                   // set USB endpoints to act as an input/output pair - transmitter (IN)
    tInterfaceParameters.Paired_RxEndpoint = 1;                          // receiver (OUT)
    #endif
    tInterfaceParameters.usEndpointSize = 64;                            // endpoint queue size (2 buffers of this size will be created for reception)
    #if defined USE_USB_MSD
    tInterfaceParameters.usb_callback = mass_storage_callback;           // allow receptions to be 'peeked' by callback
    #else
    tInterfaceParameters.usb_callback = 0;                               // no callback since we use rx buffer - the same task is owner
    #endif
    #ifdef WAKE_BLOCKED_USB_TX
    tInterfaceParameters.low_water_level = (tInterfaceParameters.queue_sizes.TxQueueSize/2); // TX_FREE event on half buffer empty
    #endif
    #ifdef USE_USB_MSD
    tInterfaceParameters.queue_sizes.RxQueueSize = 512;                  // optional input queue (used only when no callback defined) and large enough to hold a full sector
    #else
    tInterfaceParameters.usConfig = USB_TERMINATING_ENDPOINT;            // {13} configure the IN endpoint to terminate messages with a zero length frame
    tInterfaceParameters.queue_sizes.RxQueueSize = 256;                  // optional input queue (used only when no callback defined)
    #endif
    tInterfaceParameters.queue_sizes.TxQueueSize = 1024;                 // additional tx buffer
#endif
    USBPortID_comms = fnOpen(TYPE_USB, 0, &tInterfaceParameters);        // open the endpoints with defined configurations (initially inactive)
#if defined USE_USB_CDC
    #if defined MODBUS_USB_SLAVE                                         // {11}
    tInterfaceParameters.owner_task = OWN_TASK;
    #endif
    tInterfaceParameters.usConfig = 0;                                   // {13}
    #if defined _LPC23XX || defined _LPC17XX                             // {14}
    tInterfaceParameters.Endpoint = 4;                                   // set USB channel - interrupt endpoint
    #else
    tInterfaceParameters.Endpoint = 3;                                   // set USB channel - endpoint
    #endif
    tInterfaceParameters.Paired_RxEndpoint = 0;                          // no pairing
    tInterfaceParameters.owner_task = 0;                                 // don't wake task on reception
    tInterfaceParameters.usb_callback = 0;                               // no call back function
    tInterfaceParameters.usEndpointSize = 64;                            // endpoint queue size (2 buffers of this size will be created for reception)
    tInterfaceParameters.queue_sizes.TxQueueSize = tInterfaceParameters.queue_sizes.RxQueueSize = 0; // no buffering
    USBPortID_interrupt_3 = fnOpen(TYPE_USB, 0, &tInterfaceParameters);  // open the endpoint with defined configurations (initially inactive)
#endif
}
#endif
