/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        config.h
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2011
    *********************************************************************/

#ifndef __CONFIG__
#define __CONFIG__


#ifdef _WINDOWS
    #define MEM_FACTOR 1.2                                               // Windows tends to use more memory so expand heap slightly
#else
    #define MEM_FACTOR 1.0
#endif

#define USE_MAINTENANCE                                                  // include some maintenance support for the application (remove to reduce project size for special tests or possibly running from limited RAM)
    #define PREVIOUS_COMMAND_BUFFERS  4                                  // this many command input buffers for returning old commands via arrow key
//#define MONITOR_PERFORMANCE                                            // support measuring duration of tasks and idle phases

#define UNUSED_STACK_PATTERN   0x55                                      // this is the stack fill pattern for recognising maximum stack usage



// Major hardware dependent settings for this project
//
#ifdef _LPC23XX
    // define the chip type used in the project
    //
    //#define LPC2101                                                    // 8k   FLASH,  2k RAM, LQFP48 / PLCC44
    //#define LPC2102                                                    // 16k  FLASH,  4k RAM, LQFP48 / PLCC44
    //#define LPC2103                                                    // 32k  FLASH,  8k RAM, LQFP48 / PLCC44
    //#define LPC2104                                                    // 128k FLASH, 16k RAM, LQFP48
    //#define LPC2105                                                    // 128k FLASH, 32k RAM, LQFP48
    //#define LPC2106                                                    // 128k FLASH, 64k RAM, LQFP48
    //#define LPC2131                                                    // 32k  FLASH, 8k  RAM, 8 x 10bit ADC, LQFP64
    //#define LPC2132                                                    // 64k  FLASH, 16k RAM, 8 x 10bit ADC, 1 x 10bit DAC, LQFP64
    //#define LPC2134                                                    // 128k FLASH, 16k RAM, 16 x 10bit ADC, 1 x 10bit DAC, full modem UART1, LQFP64
    //#define LPC2136                                                    // 256k FLASH, 32k RAM, 16 x 10bit ADC, 1 x 10bit DAC, full modem UART1, LQFP64
    //#define LPC2138                                                    // 512k FLASH, 32k RAM, 16 x 10bit ADC, 1 x 10bit DAC, full modem UART1, LQFP64
    //#define LPC2141                                                    // 32k  FLASH, 8k  RAM (2k USB RAM), LQFP64
    //#define LPC2142                                                    // 64k  FLASH, 16k RAM (2k USB RAM), LQFP64
    //#define LPC2144                                                    // 128k FLASH, 16k RAM (2k USB RAM), LQFP64
    //#define LPC2146                                                    // 256k FLASH, 32k RAM (8k USB DMA) (2k USB RAM), LQFP64
    //#define LPC2148                                                    // 512k FLASH, 32k RAM (8k USB DMA) (2k USB RAM), LQFP64
    //#define LPC2364FBD100                                              // 128k FLASH, 34k RAM total, LQFP100
    //#define LPC2366FBD100                                              // 256k FLASH, 58k RAM total, LQFP100
    //#define LPC2368FBD100                                              // 512k FLASH, 58k RAM total, LQFP100
      #define LPC2378FBD144                                              // 512k FLASH, 58k RAM total, LQFP144
    //#define LPC2387FBD100                                              // 512k FLASH, 98k RAM total, LQFP100
    //#define LPC2458FET180                                              // 512k FLASH, 98k RAM total, TFBGA180
    //#define LPC2468FET208                                              // 512k FLASH, 98k RAM total, TFBGA208
    //#define LPC2468FBD208                                              // 512k FLASH, 98k RAM total, LQFP208
    //#define LPC2478FET208                                              // 512k FLASH, 98k RAM total, TFBGA208 + LCD
    //#define LPC2478FBD208                                              // 512k FLASH, 98k RAM total, LQFP208 + LCD

    #if defined LPC2364FBD100 || defined LPC2366FBD100 || defined LPC2368FBD100 || defined LPC2378FBD144 || defined LPC2387FBD100
      //#define OLIMEX_LPC2378_STK                                       // low cost evaluation board from Olimex
        #define KEIL_MCB2300                                             // Keil evaluation board
        #if defined KEIL_MCB2300
            #define TARGET_HW       "KEIL MCB2300"
        #elif defined OLIMEX_LPC2378_STK
            #define TARGET_HW       "OLIMEX LPC2378-STK"
            #define _336K_FILE_SYSTEM_SPACE                              // activate larger file system space for SW uploads
        #else
            #define TARGET_HW       "Default board with LAN8700"
        #endif

        #define OUR_HEAP_SIZE (HEAP_REQUIREMENTS)((19*1024)*MEM_FACTOR)  // the LPC23xx uses dedicated Ethernet buffers so doesn't need heap for these
    #elif defined LPC2458FET180 || defined LPC2468FET208 || defined LPC2468FBD208 || defined LPC2478FET208 || defined LPC2478FBD208
        #define _ERRATA_MAM_1_SOLVED                                     // LPC24XX doesn't suffer from MAM errata
        #define OLIMEX_LPC2478_STK                                       // low cost evaluation board from Olimex
        #define TARGET_HW           "OLIMEX LPC2478-STK"
        #define OUR_HEAP_SIZE (HEAP_REQUIREMENTS)((19*1024)*MEM_FACTOR)  // the LPC23xx uses dedicated Ethernet buffers so doesn't need heap for these
        #define _LPC24XX                                                 // LPC24XX superset
    #elif defined LPC2148
        #define OLIMEX_LPC_P2148                                         // OLIMEX prototyping board (LPC2148)
        #define TARGET_HW           "OLIMEX LPC-P2148"
        #define OUR_HEAP_SIZE (HEAP_REQUIREMENTS)((10*1024)*MEM_FACTOR)
        #define DEVICE_WITHOUT_ETHERNET                                  // LPC214X has no Ethernet interface
        #define _LPC21XX                                                 // LPC21XX subset
    #elif defined LPC2131
        #define BOARD_LPC_P2131                                          // experimental board (LPC2131)
        #define TARGET_HW           "LPC-2131"
        #define OUR_HEAP_SIZE (HEAP_REQUIREMENTS)((10*1024)*MEM_FACTOR)
        #define DEVICE_WITHOUT_ETHERNET                                  // LPC213X has no Ethernet interface
        #define DEVICE_WITHOUT_USB                                       // LPC213X has no USB interface
        #define _LPC21XX                                                 // LPC21XX subset
    #else
        #if defined LPC2101 || defined LPC2102 || defined LPC2103
            #define OLIMEX_LPC_P2103                                     // OLIMEX prototyping board (LPC2103)
        #else
            #define IAR_LPC210X                                          // IAR evaluation board (LPC2106)
        #endif
        #if defined IAR_LPC210X
            #define TARGET_HW           "IAR LPC210X Card"
        #elif defined OLIMEX_LPC_P2103
            #define TARGET_HW           "OLIMEX LPC-P2103"
        #endif
        #if defined LPC2101 || defined LPC2102 || defined LPC2103
            #define OUR_HEAP_SIZE (HEAP_REQUIREMENTS)((1.4*1024)*MEM_FACTOR)
            #define NO_FLASH_SUPPORT                                     // no parameter or file system
        #else
            #define OUR_HEAP_SIZE (HEAP_REQUIREMENTS)((6*1024)*MEM_FACTOR)
        #endif

      //#define PLCC44                                                   // PLCC44 rather than LQFP48

        #define DEVICE_WITHOUT_USB                                       // LPC210X has no USB interface
        #define DEVICE_WITHOUT_ETHERNET                                  // LPC21XX has no Ethernet interface
        #define _LPC21XX                                                 // LPC21XX subset
    #endif

    #ifdef _WINDOWS
        #define TICK_RESOLUTION      10                                  // 10 ms system time period when simulating to improve touch screen reaction time
    #else
        #define TICK_RESOLUTION      50                                  // 50 ms system time period - max possible with LPC23XX at 70MHz PIT would be about 582s !
    #endif
#endif


//#define NO_FLASH_SUPPORT                                               // neither parameter nor file system
/**************** Specify a file system for use by FTP, HTML and such functions *******************************/
#ifndef NO_FLASH_SUPPORT
    #define USE_PARAMETER_BLOCK                                          // enable a parameter block for storing and retrieving non-volatile information
    #define USE_PAR_SWAP_BLOCK                                           // we support a backup block which can be restored if desired (it is recommended to use this together with USE_PARAMETER_BLOCK
  //#define USE_PARAMETER_AREA                                           // simple parameter area rather than parameter block

  //#define SPI_FILE_SYSTEM                                              // we have an external file system via SPI interface
    #if !defined NAND_FLASH_FAT
        #define FLASH_FILE_SYSTEM                                        // we have an internal file system in FLASH
    #endif
  //#define NVRAM                                                        // we have an external file system in non-volatile RAM
    #define INTERNAL_USER_FILES                                          // allow user to specify program file content
      //#define EMBEDDED_USER_FILES                                      // use together with INTERNAL_USER_FILES to allow sending an embedded user file to the uFileSystem
    #if !defined NAND_FLASH_FAT
        #define MANAGED_FILES                                            // use memory management when interfacing with uFileSystem in internal or external SPI memeory
            #define MANAGED_FILE_COUNT       5                           // the maximum number of managed files open at the same time
          //#define TIME_SLICED_FILE_OPERATION                           // allow file operations to be controlled in time slice manner, otherwise one pass per scheduler cycle (needs GLOBAL_TIMER_TASK)
    #endif
#endif

//#define PERIODIC_TIMER_EVENT                                           // delayed and periodic tasks are schedule with timer events if enabled (otherwise they are simply scheduled)

#if defined (SPI_FILE_SYSTEM) || defined (FLASH_FILE_SYSTEM) || defined (NVRAM)
    #define ACTIVE_FILE_SYSTEM
#endif

#define SUPPORT_MIME_IDENTIFIER                                          // if the file type is to be handled (eg. when mixing HTML with JPGs etc.) this should be set - note that the file system header will be adjusted
//#define SUPPORT_UFREE                                                  // support allocating and freeing a uMalloc() region

#ifdef FLASH_FILE_SYSTEM
    #ifdef SPI_FILE_SYSTEM
      //#define SPI_FLASH_SST25                                          // use SST SPI FLASH rather than ATMEL
        #define SPI_FLASH_ST                                             // use ST FLASH rather than ATMEL
      //#define SPI_DATA_FLASH                                           // FLASH type is data FLASH supporting sub-sectors (relevant for ST types)
        #if defined SPI_FLASH_ST
            #if defined SPI_DATA_FLASH
                #define FILE_GRANULARITY (2*SPI_FLASH_BLOCK_LENGTH)      // (2 x 4096 byte blocks) file granularity is equal to a multiple of the FLASH granularity (as defined by the device)
            #else
                #define FILE_GRANULARITY (SPI_FLASH_BLOCK_LENGTH)        // (65535 byte blocks) file granularity is equal to a multiple of the FLASH granularity (as defined by the device)
            #endif
        #elif defined SPI_FLASH_SST25
            #define FILE_GRANULARITY (SPI_FLASH_BLOCK_LENGTH)            // (4096 byte blocks) file granularity is equal to sub-sector FLASH granularity (as defined by the device)
        #else
            #define FILE_GRANULARITY (2*SPI_FLASH_BLOCK_LENGTH)          // (2112/1056 byte blocks) file granularity is equal to a multiple of the FLASH granularity (as defined by the device)
        #endif
    #endif
#endif

#define uFILE_SYSTEM_START (MEMORY_RANGE_POINTER)(uFILE_START)
#define uFILE_SYSTEM_END   (MEMORY_RANGE_POINTER)(uFILE_START + FILE_SYSTEM_SIZE)
#if defined _STR91XF || defined _LPC23XX || defined _LPC17XX && (defined FLASH_FILE_SYSTEM && !defined SPI_FILE_SYSTEM) // positions parameter block in different FLASH bank and uses sub-files
    #define LAST_FILE_BLOCK    (unsigned short)((FILE_SYSTEM_SIZE)/FILE_GRANULARITY) // last block in our file system
    #define LAST_SUB_FILE_BLOCK  (unsigned short)((FILE_SYSTEM_SIZE)/SUB_FILE_SIZE)  // last sub-block in our file system
#else
    #define LAST_FILE_BLOCK    (unsigned short)((FILE_SYSTEM_SIZE)/FILE_GRANULARITY) // last block in our file system
  //#define LAST_FILE_BLOCK    (unsigned short)((FILE_SYSTEM_SIZE)/SINGLE_FILE_SIZE) // last file block in our file system
#endif

#define POINTER_USER_NAME parameters->cUserName                          // define where the user name and password is taken from
#define POINTER_USER_PASS parameters->cUserPass


//#define USE_MODBUS                                                     // activate MODBUS support in the project
#define USE_MODBUS_SLAVE                                                 // slave capability supported
//#define NO_SLAVE_MODBUS_READ_COILS                                     // disable specific slave public function support
//#define NO_SLAVE_MODBUS_READ_DISCRETE_INPUTS
//#define NO_SLAVE_MODBUS_READ_HOLDING_REGISTERS
//#define NO_SLAVE_MODBUS_READ_INPUT_REGISTERS
//#define NO_SLAVE_MODBUS_WRITE_SINGLE_COIL
//#define NO_SLAVE_MODBUS_WRITE_SINGLE_REGISTER
//#define NO_SLAVE_MODBUS_READ_EXCEPTION_STATUS
//#define NO_SLAVE_MODBUS_DIAGNOSTICS
//#define NO_SLAVE_MODBUS_DIAG_SUB_RETURN_QUERY_DATA
//#define NO_SLAVE_MODBUS_DIAG_SUB_RESTART_COMS
//#define NO_SLAVE_MODBUS_DIAG_SUB_RETURN_DIAG_REG
//#define NO_SLAVE_MODBUS_DIAG_SUB_CHANGE_ASCII_DELIM
//#define NO_SLAVE_MODBUS_DIAG_SUB_FORCE_LISTEN_ONLY
//#define NO_SLAVE_MODBUS_DIAG_SUB_CLEAR_DISGNOSTICS
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_BUS_MSG_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_BUS_COM_ERR_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_BUS_EXC_ERR_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_SLAVE_MSG_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_SLAVE_NO_RSP_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_SLAVE_NAK_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_SLAVE_BSY_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_RTN_BUS_CHR_ORUN_CNT
//#define NO_SLAVE_MODBUS_DIAG_SUB_CLEAR_ORUN_AND_FLG
//#define NO_SLAVE_MODBUS_GET_COMM_EVENT_COUNTER
//#define NO_SLAVE_MODBUS_GET_COMM_EVENT_LOG
//#define NO_SLAVE_MODBUS_WRITE_MULTIPLE_COILS
//#define NO_SLAVE_MODBUS_WRITE_MULTIPLE_REGISTERS
//#define NO_SLAVE_MODBUS_REPORT_SLAVE_ID
//#define NO_SLAVE_MODBUS_MASK_WRITE_REGISTER
//#define NO_SLAVE_MODBUS_READ_WRITE_MULTIPLE_REGISTER
//#define NO_SLAVE_MODBUS_READ_FIFO_QUEUE
//#define NOTIFY_ONLY_COIL_CHANGES                                       // notify user of individual coil changes only
#define USE_MODBUS_MASTER                                                // master capability supported (either slave or master required)
//#define NO_MASTER_MODBUS_READ_COILS                                    // disable specific master public function support
//#define NO_MASTER_MODBUS_READ_DISCRETE_INPUTS
//#define NO_MASTER_MODBUS_READ_HOLDING_REGISTERS
//#define NO_MASTER_MODBUS_READ_INPUT_REGISTERS
//#define NO_MASTER_MODBUS_WRITE_SINGLE_COIL
//#define NO_MASTER_MODBUS_WRITE_SINGLE_REGISTER
//#define NO_MASTER_MODBUS_READ_EXCEPTION_STATUS
//#define NO_MASTER_MODBUS_DIAGNOSTICS                                   // shared by all sub-functions
//#define NO_MASTER_MODBUS_GET_COMM_EVENT_COUNTER
//#define NO_MASTER_MODBUS_GET_COMM_EVENT_LOG
//#define NO_MASTER_MODBUS_WRITE_MULTIPLE_COILS
//#define NO_MASTER_MODBUS_WRITE_MULTIPLE_REGISTERS
//#define NO_MASTER_MODBUS_REPORT_SLAVE_ID
//#define NO_MASTER_MODBUS_MASK_WRITE_REGISTER
//#define NO_MASTER_MODBUS_READ_WRITE_MULTIPLE_REGISTER
//#define NO_MASTER_MODBUS_READ_FIFO_QUEUE
#ifdef USE_MODBUS_MASTER
#define MODBUS_GATE_WAY_ROUTING                                          // configurable routing from slave gateways (requires master functionality)
#define MODBUS_GATE_WAY_QUEUE                                            // support queuing of MODBUS transmissions - advisable for gateways
    #define MODBUS_DELAYED_RESPONSE                                      // allow slave parameter interface to delay request responses - for example to prepare latest data from external location
    #define MAX_QUEUED_REQUEST_LENGTH    8                               // longest request data length that needs to be saved when requests are delayed
#endif


/**************** Configure driver services *******************************************************************/

//#define CAN_INTERFACE                                                  // enable CAN bus interface
#ifdef CAN_INTERFACE
    #define NUMBER_CAN          2                                        // the number of logical queues required for CAN support
  //#define UTASKER_SIM                                                  // simulator HW extension
    #define SIM_HW_IP_ADD       192,168,0,4                              // IP address of our HW simulator extension
    #define SIM_HW_PORT_NUMBER  1234                                     // port number used by out HW simulator
#else
    #define NUMBER_CAN   0                                               // no physical queue needed
#endif

#define SERIAL_INTERFACE                                                 // enable serial interface driver
#ifdef SERIAL_INTERFACE
    #define SERIAL_STATS                                                 // keep statistics about serial interface use
    #define SUPPORT_MSG_MODE                                             // enable terminator recognition (MSG_MODE)
    #define SUPPORT_MSG_CNT                                              // enable the message counter mode (MSG_MODE_RX_CNT) - requires also SUPPORT_MSG_MODE
    #define WAKE_BLOCKED_TX                                              // allow a blocked transmitter to continue after an interrupt event
      //#define WAKE_BLOCKED_TX_BUFFER_LEVEL                             // define specific level in output buffer for wake to occur
    #define SUPPORT_FLUSH                                                // support rx flush
    #define SERIAL_SUPPORT_XON_XOFF                                      // enable XON/XOFF support in driver
    #define HIGH_WATER_MARK   20                                         // stop flow control when the input buffer has less than this space (if variable settings are required, use SUPPORT_FLOW_HIGH_LOW define)
    #define LOW_WATER_MARK    20                                         // restart when the input buffer content falls below this value
    #define SUPPORT_FLOW_HIGH_LOW                                        // allow flow control levels to be configured (in % of buffer size)
    #define SERIAL_SUPPORT_ECHO                                          // enable echo mode in rx driver
    #define SERIAL_SUPPORT_ESCAPE                                        // enable escape sequencing in driver
  //#define SERIAL_SUPPORT_SCAN                                          // serial receiver supports scanning of input buffer for a sequence
  //#define SUPPORT_HW_FLOW                                              // support RTS/CTS flow control and other possible modem signals
    #define UART_BREAK_SUPPORT                                           // support break control in the UART driver

    #define LOG_UART0                                                    // activate this option to log all data sent to UART 0 to a file called "UART0.txt"
    #define LOG_UART1                                                    // activate this option to log all data sent to UART 1 to a file called "UART1.txt"
    #define LOG_UART2                                                    // activate this option to log all data sent to UART 2 to a file called "UART2.txt"
    #define LOG_UART3                                                    // activate this option to log all data sent to UART 3 to a file called "UART3.txt"

    #ifdef USE_MODBUS
        #define MODBUS_RTU                                               // support binary RTU mode
        #define MODBUS_ASCII                                             // support ASCII mode
        #define STRICT_MODBUS_SERIAL_MODE                                // automatically adjust the character length according to mode
        #define MODBUS_SERIAL_INTERFACES          2
      //#define MODBUS_SHARED_SERIAL_INTERFACES   3                      // number of slave interfaces sharing UARTs
        #define MODBUS_RS485_SUPPORT                                     // support RTS control for RS485 transmission
        #define FAST_MODBUS_RTU                                          // speeds of greater than 19200 use calculated RTU times rather than recommended fixed values
        #if defined MODBUS_RS485_SUPPORT
            #if !defined SUPPORT_HW_FLOW
                #define SUPPORT_HW_FLOW                                  // ensure that HW flow control is enabled when RS485 support required
            #endif
            #define UART_FRAME_COMPLETE                                  // the UART driver informs of frame completion - activated when RS485 mode is required
        #endif
        #define MODBUS_SUPPORT_SERIAL_LINE_FUNCTIONS                     // support the serial line function at the slave
        #define MODBUS_SUPPORT_SERIAL_LINE_DIAGNOSTICS                   // support serial line diagnostics
        #define MODBUS_CRC_FROM_LOOKUP_TABLE                             // MODBUS RTU cyclic redundancy check performed with help of loop up table (requires 512 bytes FLASH table, but faster than calculation loop)
    #endif
#else
    #define NUMBER_SERIAL              0                                 // no physical queue needed
    #define NUMBER_EXTERNAL_SERIAL     0
#endif

#if defined USE_MODBUS && defined MODBUS_GATE_WAY_QUEUE && !defined SUPPORT_FLUSH
    #define SUPPORT_FLUSH                                                // support queue flush for use by the MODBUS gateway
#endif

#ifdef DEVICE_WITHOUT_USB
    #define NUMBER_USB     0                                             // no physical queue needed
#else
    #define USB_INTERFACE                                                // enable USB driver interface
    #ifdef USB_INTERFACE
        #define USE_USB_HID_MOUSE                                        // human interface device (mouse) has priority over default MSD and CDC
      //#define USE_USB_MSD                                              // needs SD card to compile and has priority over default CDC
        #if !defined USE_USB_HID_MOUSE && !defined USE_USB_MSD
            #define USE_USB_CDC                                          // default
        #endif

      //#define USB_HOST_SUPPORT
        #define SUPPORT_FLUSH                                            // allow flush command to be used (important for mass storage class)
        #define WAKE_BLOCKED_USB_TX                                      // allow a blocked USB transmitter to continue after an interrupt event
        #define NUMBER_USB     (5 + 1)                                   // 6 physical queues (control plus 5 endpoints) needed for USB interface
        #define LOG_USB_TX                                               // log USB transmissions in simulator
        #define NUMBER_OF_POSSIBLE_CONFIGURATIONS  1                     // one USB configuration
        #define ENDPOINT_0_SIZE                    8                     // maximum packet size for endpoint 0. Low speed devices must use 8 whereas full speed devices can chose to use 8, 16, 32 or 64 (SAM7X must use 8!!)
        #define USB_STRING_OPTION                                        // support optional string descriptors
        #define USB_RUN_TIME_DEFINABLE_STRINGS                           // enable USB string content to be defined at run time (variable)
      //#define USE_USB_OTG_CHARGE_PUMP                                  // enable charge pump control in the driver
        #ifdef USE_USB_OTG_CHARGE_PUMP
            #define IIC_INTERFACE                                        // activate IIC interface since it will be needed
        #endif
        #if defined USE_MODBUS && defined  USE_MODBUS_SLAVE
          //#define MODBUS_USB_SLAVE                                     // MODBUS serial slave realised as USB
        #endif
    #else
        #define NUMBER_USB     0                                         // no physical queue needed
    #endif
#endif

//#define IIC_INTERFACE                                                  // enable IIC interface driver
#ifndef IIC_INTERFACE
    #define NUMBER_IIC     0                                             // no physical queue needed
#endif

//#define SSC_INTERFACE
#ifndef SSC_INTERFACE
    #define NUMBER_SSC     0                                             // no physical queue needed
#endif

//#define SDCARD_SUPPORT                                                 // SD-card interface
#ifdef SDCARD_SUPPORT
    #define SD_CARD_RETRY_INTERVAL       5                               // attempt SD card initialisation at 5s intervals
    #define UT_DIRECTORIES_AVAILABLE     5                               // this many directories objects are available for allocation
    #define UTMANAGED_FILE_COUNT        10                               // allow this many managed files at one time
    #define UTFAT_LFN_READ                                               // enable long file name read support
    #ifdef UTFAT_LFN_READ
        #define MAX_UTFAT_FILE_NAME     (100)                            // the maximum file name length supported
    #endif
    #define UTFAT_WRITE                                                  // enable write functions
    #ifdef UTFAT_WRITE
        #define UTFAT_FORMATTING                                         // enable formatting SD cards (requires also write)
        #define UTFAT_FULL_FORMATTING                                    // enable formatting SD cards including zeroing of data sectors as well as FAT sectors
    #endif
  //#define UTFAT16                                                      // support FAT16 as well as FAT32
  //#define SUPPORT_FILE_TIME_STAMP                                      // when activated fnGetLocalFileTime() must exist, which return the date and time information
#endif

#ifndef DEVICE_WITHOUT_ETHERNET
    #define ETH_INTERFACE                                                // enable Ethernet interface driver
#endif
#ifdef ETH_INTERFACE
    #define MAC_DELIMITER  '-'                                           // used for display and entry of mac addresses
    #define IPV6_DELIMITER ':'                                           // used for display and entry of IPV6 addresses
    #define NUMBER_LAN     1                                             // one physical interface needed for LAN

  //#define LOG_ETHERNET                                                 // activate this option to log all transmitted data to a file called "Eth_tx.txt"
  //#define SUPPORT_DISTRIBUTED_NODES
    #ifdef SUPPORT_DISTRIBUTED_NODES
        #define PROTOCOL_UNETWORK 0x754e                                 // uN - uNetwork protocol
        #define MAX_NETWORK_NODES 2
        #define UPROTOCOL_WITH_RETRANS
        #define MAX_STORED_MESSAGES       10                             // set TIMER_QUANTITY to at least this amount since each message needs a timer
        #define MAX_UPROT_MSG_SIZE        255
        #define UPROT_RETRANS_TIME        (CLOCK_LIMIT)(0.05 * SEC)
        #define MAX_UPROT_RETRANS_ATTEMPS 5
        #define GLOBAL_TIMER_TASK                                        // needs global timer to operate
        #define USE_TIMER_FUNCTION_EVENT                                 // global timer handles messages to itself as function event
    #endif
#endif



#ifdef ETH_INTERFACE
    #define ETHERNET_RELEASE_AFTER_EVERY_FRAME                           // handle only one Ethernet reception frame at a time and allow other tasks to be scheduled in between
        #define ETHERNET_RELEASE_LIMIT  3                                // allow a maximum of three reception frames to be handled
/**************** Configure TCP/IP services ******************************************************************/
  //#define USE_IPV6                                                     // enable IPV6
        #define MAX_HW_ADDRESS_LENGTH  MAC_LENGTH                        // set a variable maximum hardware address length - default is Ethernet MAC, 6 bytes
        #define NEIGHBOR_TABLE_ENTRIES 4                                 // the maximum entries in IPV6 neighbor table
    #define USE_IP                                                       // enable IP and ARP and all other possible tcp/ip services
    #ifdef USE_IP
        #define USE_IP_STATS                                             // enable IP statistics (counters)
        #define ARP_TABLE_ENTRIES      8                                 // the maximum entries in ARP table
        #define ARP_IGNORE_FOREIGN_ENTRIES                               // only add used addresses to ARP table
        #define USE_ICMP                                                 // enable ICMP
      //#define USE_IGMP                                                 // enable IGMP
        #define MULTICAST_IPV4                                           // required by IGMP
        #ifdef _WINDOWS
            #define PSEUDO_LOOPBACK                                      // pseudo loop back when simulating - only for use with the simulator!! (this allows an application to send test frames to its own IP address)
        #endif
        #define USE_ZERO_CONFIG                                          // support IPv4 link-local and zero configuration (autoIP)
        #ifdef USE_ICMP                                                  // specify ICMP support details
            #define ICMP_PING                                            // allow PING reply
            #define ICMP_SEND_PING                                       // support PING transmission
            #define ICMP_DEST_UNREACHABLE                                // allow destination unreachable if no UDP port exists
        #endif
    #endif
    #if defined USE_IP || defined USE_IPV6
        #define USE_UDP                                                  // enable UDP over IP - needs IP
        #define USE_TCP                                                  // enable TCP over IP - needs IP

        #ifdef USE_TCP                                                   // specify TCP support details
            #define REUSE_TIME_WAIT_SOCKETS                              // allow sockets in 2MSL wait to be reallocated to different IP/port pairs
            #define TCP_CHECK_SYS_REPS                                   // reuse a socket whose SYN + ACK has been lost (avoids it repeating its SYN + ACK and unnecessarily blocking in a socket until it times out)
            #define RST_ON_NO_TCP_PORT                                   // SYN to non-existing ports receive a RST
            #define ANNOUNCE_MAX_SEGMENT_SIZE                            // we announce the maximum segment size we can handle when establishing a connection
            #define SUPPORT_PEER_MSS                                     // respect peer's MSS when sending TCP frames
            #define SUPPORT_PEER_WINDOW                                  // respect peer's Open Window when sending TCP frames
            #define WINDOWING_BUFFERS      4                             // we can send 4 frames before requiring ACKs
            #define CONTROL_WINDOW_SIZE                                  // support variable windows size to quench reception

            #define USE_FTP                                              // enable FTP   - needs TCP
            #define USE_FTP_CLIENT                                       // enable FTP client - needs TCP
          //#define USE_SMTP                                             // enable SMTP  - needs TCP
          //#define USE_POP3                                             // enable POP3 Email - needs TCP
            #define USE_HTTP                                             // support embedded Web server - needs TCP
            #define USE_TELNET                                           // enable TELNET support
          //#define USE_TIME_SERVER                                      // enable time server support - presently demo started in application

            #define MODBUS_TCP                                           // support MODBUS TCP protocol

          //#define TEST_CLIENT_SERVER                                   // TCP client/server test (see debug.c)
            #define TEST_TCP_SERVER                                      // TCP server (see debug.c) - uses also a TELNET session
            #if defined TEST_CLIENT_SERVER
                #define USER_TCP_SOCKETS      1
            #else
                #define USER_TCP_SOCKETS      0                          // we use no non-standard TCP sockets
            #endif
        #endif

        #ifdef USE_UDP
            #define USER_UDP_SOCKETS       1                             // we reserve  one non-standard UDP socket in case the UDP demo is required

          //#define USE_BOOTP                                            // enable BOOTP - needs UDP - IPCONFIG default zero.
            #define USE_DHCP                                             // enable DHCP  - needs UDP - IPCONFIG default zero. Needs 1k Ethernet RX Buffers!! (set random number also)
            #define USE_DNS                                              // enable DNS   - needs UDP
                #define DNS_SERVER_OWN_ADDRESS                           // command line menu allows DNS server address to be set, otherwise it uses the default gateway
            #define USE_TFTP                                             // enable TFTP  - needs UDP
            #define USE_NETBIOS                                          // enable NetBIOS - needs UDP
          //#define USE_SNMP
          //#define USE_SNTP                                             // simple network time protocol

            #ifdef USE_DHCP
                #define DHCP_SOCKET 1
            #else
                #define DHCP_SOCKET 0
            #endif
            #ifdef USE_DNS
                #define DNS_SOCKET 1
            #else
                #define DNS_SOCKET 0
            #endif
            #ifdef USE_TFTP
                #define TFTP_SOCKET 1
            #else
                #define TFTP_SOCKET 0
            #endif
            #ifdef USE_SNMP
                #define SNMP_SOCKET 1
            #else
                #define SNMP_SOCKET 0
            #endif
            #ifdef USE_SNTP
                #define SNTP_SOCKET 1
            #else
                #define SNTP_SOCKET 0
            #endif
            #ifdef USE_NETBIOS
                #define NETBIOS_SOCKET 1
                #define SUPPORT_SUBNET_BROADCAST                         // NetBIOS needs to receive sub-net broadcast frames
            #else
                #define NETBIOS_SOCKET 0
            #endif
            #define UDP_SOCKETS   (DHCP_SOCKET + DNS_SOCKET + SNMP_SOCKET + TFTP_SOCKET + NETBIOS_SOCKET + USER_UDP_SOCKETS + SNTP_SOCKET) // the number of UDP sockets supported
        #endif

        #ifdef USE_FTP                                                   // specify FTP support details
          //#define ANONYMOUS_LOGIN                                      // allow anonymous FTP without user/password
          //#define FILE_NAMES_PER_FTP_FRAME    6                        // limit size of buffers required to display files to this many names (remove to use maximum possible)
            #define FTP_SOCKETS 2                                        // reserve 2 TCP sockets for command and data
            #define FTP_SUPPORTS_NAME_DISPLAY                            // show details of files
            #define FTP_SUPPORTS_DELETE                                  // enable delete of files via FTP
            #define FTP_SUPPORTS_DOWNLOAD                                // support read of files via FTP
            #define FTP_VERIFY_DATA_PORT                                 // check for valid data port when in active mode
            #define FTP_PASV_SUPPORT                                     // allow passive mode of operation
            #define DATA_PORT_TRIGGERS_CONTROL                           // activity on the FTP data port resets the control port TCP idle timer - stops control connection timing out on large data transfers with short idle time value
            #define FTP_USER_LOGIN
            #define FTP_WILDCARD_DEL                                     // file system content delete using *.* supported
            #define FTP_DATA_WINDOWS            2                        // allow transmission of FTP data with windowing support
            #ifdef INTERNAL_USER_FILES
                #define FTP_DISPLAY_USER_FILES                           // allow user files to be displayed by FTP
                #define MAX_FILE_NAME_LENGTH    20                       // user files maximum file name length
            #endif
            #ifdef SDCARD_SUPPORT
                #define FTP_UTFAT                                        // allow FTP to work with utFAT
                #define FTP_ROOT                "/"                      // the root directory as seen by the FTP server (can be set to a sub-directory of the main disk to restrict FTP accesses to there)
            #endif
            #define MANAGED_FTP_DELETES                                  // FTP deletes managed
        #else
            #define FTP_SOCKETS 0                                        // no TCP sockets needed
        #endif

        #if defined USE_FTP_CLIENT
          //#define FTP_CLIENT_EXTERN_DATA_SOCKET                        // let application use its own TCP socket for data transfer
          //#define FTP_CLIENT_BUFFERED_SOCKET_MODE                      // FTP client data socket uses buffered TCP socket rather than simple TCP socket
              #define FTP_CLIENT_TCP_BUFFER_LENGTH 512                   // size of optional FTP client data socket TCP buffer
            #define MAX_FTP_CLIENT_PATH_LENGTH 64                        // maximum path string for relative directory referencing
            #if defined FTP_CLIENT_EXTERN_DATA_SOCKET
                #define FTP_CLIENT_SOCKETS  1                            // the user needs to supply the data socket
            #else
                #define FTP_CLIENT_SOCKETS  2                            // FTP client supplies control and data sockets
            #endif
        #else
            #define FTP_CLIENT_SOCKETS  0                                // no TCP sockets needed
        #endif

        #ifdef USE_POP3
            #define POP3_SOCKET 1                                        // reserve a TCP socket for POP3 use
        #else
            #define POP3_SOCKET 0                                        // no TCP socket needed
        #endif

        #ifdef USE_TIME_SERVER
            #define TIME_SERVER_SOCKET 1                                 // reserve a TCP socket for time server use use
        #else
            #define TIME_SERVER_SOCKET 0                                 // no TCP socket needed
        #endif

        #ifdef MODBUS_TCP
            #define MODBUS_TCP_GATEWAY                                   // support MODBUS TCP <-> MODBUS serial gateway
            #ifdef USE_MODBUS_MASTER                                     // following option srequire master support
                #define TCP_SLAVE_ROUTER                                 // TCP slave router support
                #define MODBUS_TCP_MASTERS    2                          // support MODBUS TCP masters
            #endif
            #define MODBUS_TCP_SERVERS    2                              // individual
            #define MODBUS_SOCKETS_0      5                              // the number of sockets (sessions) allocated to first MODBUS TCP slave port
            #define MODBUS_SOCKETS_1      3                              // the number of sockets (sessions) allocated to second MODBUS TCP slave port
            #define MODBUS_SHARED_TCP_INTERFACES 0                       // number of slave interfaces sharing TCP sessions
            #define MODBUS_TCP_SOCKETS    (MODBUS_SOCKETS_0 + MODBUS_SOCKETS_1 + MODBUS_TCP_MASTERS) // total number of sockets required by MODBUS TCP
        #else
            #define MODBUS_TCP_SOCKETS    0
            #define MODBUS_TCP_SERVERS    0
        #endif

        #ifdef USE_SMTP
            #define SMTP_MESSAGE_LEN   300                               // frame length of SMTP transmissions (temporary on stack)
            #define SMTP_SOCKET 1                                        // reserve a TCP socket for SMTP use

            #define OUR_USER_DOMAIN                       "my_domain.com";
            #define DEFAULT_DESTINATION_EMAIL_ADDRESS     "test_name@test.com";
            #define SMTP_PROVIDER_IP_ADDRESS              { 194,158,229,11 }
            #define SMTP_PROVIDER_ADDRESS                 "mail.provider.com"
            #define SMTP_PARAMETERS
            #define USE_SMTP_AUTHENTICATION
        #else
            #define SMTP_SOCKET 0                                        // no TCP socket needed
        #endif

        #ifdef USE_TELNET
            #define USE_BUFFERED_TCP                                     // always use buffered TCP for telnet
            #ifdef TEST_TCP_SERVER
                #define NO_OF_TELNET_SESSIONS   2                        // reserve sockets TELNET sessions
            #else
                #define NO_OF_TELNET_SESSIONS   1                        // reserve TELNET sessions
            #endif
        #else
            #define NO_OF_TELNET_SESSIONS   0                            // no sockets reserved for Telnet
        #endif

        #ifdef USE_BUFFERED_TCP                                          // if using a buffer for TCP to allow interractive data applications (like TELNET)
            #define WAKE_BLOCKED_TCP_BUF                                 // support waking blocked TCP buffer (with USE_BUFFERED_TCP)
          //#define INDIVIDUAL_BUFFERED_TCP_BUFFER_SIZE                  // allow each buffered TCP user to define their own TCP buffer size
        #endif

        #ifdef USE_HTTP                                                  // specify HTTP support details
            #define _VARIABLE_HTTP_PORT                                  // allow server to be started with user-defined port number
            #define HTTP_WINDOWING_BUFFERS     2                         // we can send 2 frames before requiring ACKs
            #define HTTP_IGNORE_PARTIAL_ACKS                             // when transmission error rates are low, ignore partial ack handling in favour of retransmission on timeout

            #define WEB_PARAMETER_GENERATION                             // support of parameter generating (eg. manipulating select and adding values)
            #define WEB_PARAMETER_HANDLING                               // support  handling of received web parameters
            #define WEB_PARSER_START          '�'                        // this symbol is used in Web pages to instruct parsing to begin
            #define WEB_INSERT_STRING         'v'
            #define WEB_DISABLE_FIELD         'D'
            #define WEB_NOT_DISABLE_FIELD     'd'
            #define WEB_SELECTED_FIELD        's'
            #define WEB_INSERT_DYNAMIC        'H'
          //#define WEB_ESCAPE_LEN             5                         // defaults to 4 if not defined
            #define FILE404 (uFILE_SYSTEM_START + (FILE_GRANULARITY*(LAST_FILE_BLOCK-1)))// last block fixed for 404 error page
            #if !defined SPI_FILE_SYSTEM || defined FLASH_FILE_SYSTEM    // SPI file system requires 404 file also to be in file
                #define FILE404_IN_PROG                                  // fixed FILE404 in Code (no NE64 support since it pages the file system in memory)
            #endif
            #define FILE_404_CONTENT        "<html><head><title>uTasker No file</title></head><body bgcolor=#ff9000 text=#000000 topmargin=3 marginheight=3><center><td valign=top class=h><font color=#ff0000 style=font-size:30px><b style='mso-bidi-font-weight:normal'>uTasker</font> - Error 404</i></b></td><br></td><td align=left><br><br>The requested file has not been found on the server. Please check that html files have been loaded correctly.<br></font></td></tr></body></html>"

            #define SUPPORT_CHROME                                       // always answer with HTTP header so that Chrome accepts date

            #define SUPPORT_HTTP_POST                                    // support file uploads using POST command
            #define RESTRICT_POST_CONTENT_TYPE                           // filter allowed posting formats
            #ifdef RESTRICT_POST_CONTENT_TYPE
                #define SUPPORT_POST_BINARY
                #define SUPPORT_POST_TEXT
                #define SUPPORT_POST_GIF
                #define SUPPORT_POST_BMP
                #define SUPPORT_POST_PDF
            #endif
            #define PLAIN_TEXT_POST                                      // allow posting parameters
            #define SUPPORT_HTTP_CONTINUE                                // respond to Expect: 100-continue to start a posting sequence without any delay (useful when working with cURL)
            #define X_WWW_FORM_URLENCODED                                // this encoding is also understood as plain text post (used in addition to PLAIN_TEXT_POST)
            #define AUTO_ASCII_PLAIN_TEXT_DECODE                         // automatically decode any ASCII characters send as "%xx" - this require '%' to be avoided in post content! (Suggested for use with Chrome)
            #define SUPPORT_HTTP_POST_TO_APPLICATION                     // allow application to handle posted data rather than always saving to file
            #define SUPPORT_DELAY_WEB_SERVING                            // enable delayed web page serving defined by the application

            #define NO_OF_HTTP_SESSIONS        4                         // this many parallel HTTP sockets are reserved for this many parallel sessions
            #define HTTP_AUTHENTICATION                                  // activate basic authentication
            #define PROJECT_CREDENTIALS  "HTTP/1.0 401\r\nWWW-Authenticate: Basic realm=""uTasker""\r\n\r\n" // put project name here to spice up credential pop-up
                                                                         //               ^^^^^^^
          //#define PROJECT_CREDENTIALS  "HTTP/1.0 401\r\nWWW-Authenticate: Digest algorithm=MD5 realm=""uTasker"" nonce=""61ff892f""\r\n\r\n" // put project name here to spice up credential pop-up
            #define HTTP_DYNAMIC_CONTENT                                 // activate support of dynamic content generation
            #define DYNAMIC_DATA_FIXED_LENGTH  0
            #ifdef HTTP_DYNAMIC_CONTENT
                #define HTTP_USER_DETAILS                                // enable the application to manage details belonging to a particalar connection
            #endif
            #define HTTP_HEADER_CONTENT_INFO                             // add plain text HTTP header information - ensures that Internet Explorer correctly displays txt files
            #ifdef SDCARD_SUPPORT
                #define HTTP_UTFAT                                       // allow HTTP to work with utFAT
                #define HTTP_ROOT              "dir1"                    // the root directory as seen by the HTTP server (can be set to a sub-directory of the main disk to restrict HTTP accesses to there)
                #define DEFAULT_HTTP_FILE      "index.htm"               // the file served when first contact is made with the web server
            #endif
        #else
            #define NO_OF_HTTP_SESSIONS        0                         // no TCP sockets are reserved for HTML
        #endif

        #define USER_NAME_AND_PASS                                       // routines for user name and password support

        #define NO_OF_TCPSOCKETS (NO_OF_HTTP_SESSIONS + FTP_SOCKETS + FTP_CLIENT_SOCKETS + POP3_SOCKET + SMTP_SOCKET + NO_OF_TELNET_SESSIONS + TIME_SERVER_SOCKET + MODBUS_TCP_SOCKETS + USER_TCP_SOCKETS)   // reserve the number of TCP sockets necessary for our configuration
    #endif
#else
  #define NUMBER_LAN     0                                               // no physical queue needed
#endif

#if defined USE_MODBUS && defined USE_MODBUS_MASTER && defined MODBUS_GATE_WAY_QUEUE
    #if !defined MODBUS_TCP
        #define MODBUS_TCP_SERVERS       0
        #define MODBUS_TCP_MASTERS       0
    #endif
    #if!defined MODBUS_SERIAL_INTERFACES
        #define MODBUS_SERIAL_INTERFACES 0
    #endif
    #define NUMBER_MODBUS_QUEUES  (MODBUS_SERIAL_INTERFACES + MODBUS_TCP_SERVERS + MODBUS_TCP_MASTERS) // reserve one queue for each serial MODBUS port and each MODBUS tcp socket
    #define SUPPORT_INPUT_QUEUE_WRITE                                    // allow writes to an input queue
#else
    #define NUMBER_MODBUS_QUEUES  0
#endif

#define PHYSICAL_QUEUES   (NUMBER_SERIAL + NUMBER_EXTERNAL_SERIAL + NUMBER_LAN + NUMBER_IIC + NUMBER_SSC + NUMBER_CAN + NUMBER_USB + NUMBER_MODBUS_QUEUES) // the number of physical queues in the system


#define RANDOM_NUMBER_GENERATOR                                          // support a random number generator (useful for DHCP and possible DNS)

#define SUPPORT_LCD                                                      // enable a task for interfacing to an character LCD
#ifdef SUPPORT_LCD
    #define LCD_LINES              2                                     // use 2 x 16 LCD
    #define LCD_CHARACTERS         16                                    // options are 1:8 / 1:16 / 1:20 / 1:24 / 1:40 / 2:x / 4:x
    #define LCD_ON_COLOUR          (COLORREF)RGB(60,220,60)              // RGB colour of LCD when backlight is on
    #define LCD_OFF_COLOUR         (COLORREF)RGB(70,160,0)               // RGB colour of LCD when backlight is off
    #define LCD_PIXEL_COLOUR       (COLORREF)RGB(0,0,0)                  // RGB colour of LCD pixels
    #define LCD_PARTNER_TASK       TASK_APPLICATION
  //#define LCD_CYRILLIC_FONT                                            // use cyrillic extended ASCII character set instead of standard extended
#endif
//#define SUPPORT_GLCD                                                     // enable the task for interfacing to a graphical LCD
#if defined SUPPORT_GLCD
  //#define BIG_PIXEL                                                    // display double size in the simulator
  //#define OLED_GLCD_MODE                                               // use an OLED in GLCD compatible mode
  //#define TFT_GLCD_MODE                                                // use a TFT in GLCD compatible mode (only use together with LCD controller - eg LPC24XX)
    #define NOKIA_GLCD_MODE                                              // use Nokia 6100 LCD in compatible mode
  //#define CGLCD_GLCD_MODE                                              // use colour LCD in GLCD compatible mode
  //#define KITRONIX_GLCD_MODE                                           // use colour TFT in GLCD compatible mode (IDM_L35_B)
  //#define MB785_GLCD_MODE                                              // use colour TFT in GLCD compatible mode (STM321C-EVAL)
  //#define TFT2N0369_GLCD_MODE                                          // use colour TFT in GLCD compatible mode (TWR-LCD)
    #define SPECIAL_LCD_DEMO
    #define LCD_PARTNER_TASK       TASK_APPLICATION                      // GLCD task sends initialise complete event and acks to this task
    #if defined OLED_GLCD_MODE
        #define GLCD_X             128                                   // horizontal resolution of the GLCD in pixels
        #define GLCD_Y             96                                    // vertical resolution of the GLCD in pixels
        #define CGLCD_PIXEL_SIZE   1                                     // for each CGLCD pixel use 1 physical pixels in x and y directions
    #elif defined NOKIA_GLCD_MODE
        #define GLCD_X             130                                   // horizontal resolution of the GLCD in pixels - 132 x 132 but two not visible
        #define GLCD_Y             130                                   // vertical resolution of the GLCD in pixels
        #undef BIG_PIXEL
        #define CGLCD_PIXEL_SIZE   1                                     // for each CGLCD pixel use 1 physical pixels in x and y directions
    #elif defined TFT_GLCD_MODE || defined AVR32_EVK1105 || defined KITRONIX_GLCD_MODE || defined TFT2N0369_GLCD_MODE || defined MB785_GLCD_MODE
        #define GLCD_X             320                                   // horizontal resolution of the GLCD in pixels
        #define GLCD_Y             240                                   // vertical resolution of the GLCD in pixels
        #undef BIG_PIXEL
        #define CGLCD_PIXEL_SIZE   2                                     // for each CGLCD pixel use 2 physical pixels in x and y directions - also reduces GLCD memeory requirements
    #else
        #define GLCD_X             160                                   // horizontal resolution of the GLCD in pixels
        #define GLCD_Y             80                                    // vertical resolution of the GLCD in pixels
        #define CGLCD_PIXEL_SIZE   1                                     // for each CGLCD pixel use 1 physical pixels in x and y directions
    #endif
    #if defined OLED_GLCD_MODE
        #define LCD_PIXEL_COLOUR   (COLORREF)RGB(255,255,255)            // RGB colour of LCD pixel when on
        #define LCD_ON_COLOUR      (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is on
        #define LCD_OFF_COLOUR     (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is off
    #elif defined TFT_GLCD_MODE || defined NOKIA_GLCD_MODE || defined CGLCD_GLCD_MODE || defined KITRONIX_GLCD_MODE || defined TFT2N0369_GLCD_MODE || defined MB785_GLCD_MODE
        #define LCD_PIXEL_COLOUR   (COLORREF)RGB(255,255,0)              // RGB colour of LCD pixel when on
        #define LCD_ON_COLOUR      (COLORREF)RGB(0,0,255)                // RGB colour of LCD when backlight is on
      //#define LCD_ON_COLOUR      (COLORREF)RGB(0,0,85)                 // RGB colour of LCD when backlight is on
        #define LCD_OFF_COLOUR     (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is off
        #define NOKIA_EPSON_S1D15G00                                     // Nokia (type) CGLCD can have either this chip or
      //#define PHILIPS_PCF8833                                          // this one
    #else
      //#define _GLCD_SAMSUNG                                            // Samsung controller based display rather than Toshiba
        #if defined _GLCD_SAMSUNG
            #undef GLCD_X
            #undef GLCD_Y
            #define GLCD_X         128                                   // horizontal resolution of the GLCD in pixels
            #define GLCD_Y         64                                    // vertical resolution of the GLCD in pixels
        #endif
        #define SAMSUNG_CHIPS      (GLCD_X/64)                           // Samsung controller has fixed 64 x 64 per chip and may need multiple controllers
        #define LCD_PIXEL_COLOUR   (COLORREF)RGB(255,255,255)            // RGB colour of LCD pixel when on
        #define LCD_ON_COLOUR      (COLORREF)RGB(0,0,255)                // RGB colour of LCD when backlight is on
        #define LCD_OFF_COLOUR     (COLORREF)RGB(0,0,255)                // RGB colour of LCD when backlight is off
    #endif

    #define USER_SPECIAL_SEVEN_DOT      0                                // extend 7 dot font by 0 user characters
    #define USER_SPECIAL_NINE_DOT       3                                // extend 9 dot font by 3 user characters
    #define USER_SPECIAL_TEN_DOT        0                                // extend 10 dot font by 0 user characters
    #define USER_SPECIAL_FIFTEEN_DOT    0                                // extend 15 dot font by 0 user characters
    #define USER_SPECIAL_EIGHTEEN_DOT   0                                // extend 18 dot font by 0 user characters

    #define EN_FIVE_DOT                                                  // define the fonts that should be available for use
    #define EN_FIVE_DOT_FIX
    #define EN_SIX_DOT
    #define EN_SIX_DOT_FIX
    #define EN_SEVEN_DOT
    #define EN_NINE_DOT
    #define EN_TEN_DOT
    #define EN_FIFTEEN_DOT
    #define EN_EIGHTEEN_DOT
    #define EN_CHAR_LCD_DOT
    #define MAX_BLINKING_OBJECTS   3                                     // the number of blinking objects to be supported - comment out when not required
    #define MAX_TEXT_LENGTH        64                                    // maximum text length when writing fonts
  //#define GLCD_PIC_WINDOWING                                           // enable extension to allow picture window to be displayed (GLCD_PIC_WINDOW must be used instead of GLCD_PIC)
#elif defined LPC2478FET208 || defined LPC2478FBD208
/*
    #define SUPPORT_TFT
    #define LCD_PARTNER_TASK       TASK_APPLICATION
    #define GLCD_X                 320                                   // horizontal resolution of the LCD display in pixels
    #define GLCD_Y                 240                                   // vertical resolution of the LCD display in pixels
    #define LCD_PIXEL_COLOUR       (COLORREF)RGB(255,255,255)
    #define GLCD_COLOR                                                   // color GLCD being used
    #define SPECIAL_LCD_DEMO
    #define LCD_ON_COLOUR          (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is on
    #define LCD_OFF_COLOUR         (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is off
    */
#elif defined EK_LM3S3748 || defined AVR32_EVK1105                       // colour GLCD - special demo
/*
    #ifdef EK_LM3S3748
        #define BIG_PIXEL
    #endif
    #define SPECIAL_LCD_DEMO
    #define LCD_PIXEL_COLOUR       (COLORREF)RGB(255,255,255)
    #define LCD_ON_COLOUR          (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is on
    #define LCD_OFF_COLOUR         (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is off
    #define GLCD_COLOR                                                   // color GLCD being used
    #define LCD_PARTNER_TASK       TASK_APPLICATION
    #define LCD_ON_COLOUR          (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is on
    #define LCD_OFF_COLOUR         (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is off */
#endif
//#define SUPPORT_OLED                                                   // enable the task for interfacing to a graphical OLED
#ifdef SUPPORT_OLED
    #define LCD_PARTNER_TASK       TASK_APPLICATION
    #define GLCD_X                 128                                   // horizontal resolution of the OLED display in pixels
    #define GLCD_Y                 96                                    // vertical resolution of the OLED display in pixels
    #define LCD_ON_COLOUR          (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is on
    #define LCD_OFF_COLOUR         (COLORREF)RGB(0,0,0)                  // RGB colour of LCD when backlight is off
    #define BIG_PIXEL
    #define LCD_PIXEL_COLOUR       (COLORREF)RGB(255,255,255)
    #define EN_FIVE_DOT                                                  // define the fonts that should be available
    #define EN_FIVE_DOT_FIX
    #define EN_SIX_DOT
    #define EN_SIX_DOT_FIX
    #define EN_SEVEN_DOT
    #define EN_NINE_DOT
    #define EN_TEN_DOT
    #define EN_FIFTEEN_DOT
    #define EN_EIGHTEEN_DOT
    #define EN_CHAR_LCD_DOT
    #define MAX_BLINKING_OBJECTS   3
    #define MAX_TEXT_LENGTH        64                                    // maximum text length when writing fonts
#endif

//#define SUPPORT_KEY_SCAN                                               // enable a task for key pad scanning
#ifdef SUPPORT_KEY_SCAN
    #define KEY_ROWS                  4                                  // 4 rows by
    #define KEY_COLUMNS               0                                  // 4 columns (set to zero for non-matrix keypad inputs)

    #define KEYPAD_PARTNER_TASK       TASK_APPLICATION                   // key change events sent to this task

    #define VIRTUAL_KEY_ROWS          4                                  // virtual rows and columns when KEY_COLUMNS is zero
    #define VIRTUAL_KEY_COLUMNS       4
#endif


#define GLOBAL_TIMER_TASK                                              // enable a task for global timer tasks

#if defined USE_MODBUS && !defined GLOBAL_TIMER_TASK                     // MODBUS generally required multiple SW timer support
    #define GLOBAL_TIMER_TASK
#endif

#ifdef GLOBAL_TIMER_TASK
    #define TIMER_QUANTITY 10                                            // the number of global timers required
  //#define GLOBAL_HARDWARE_TIMER                                        // global timer task supports hardware resolution
#endif

//#define SUPPORT_LOW_POWER                                              // a low power task supervises power reduction when possible

#define SUPPORT_DOUBLE_QUEUE_WRITES                                      // allow double queue writes to improve efficiency of long queue copies


#define MULTISTART                                                       // enable a board to user multiple task configurations

// Project includes are set here for all files in the correct order
//
#include "types.h"                                                       // project specific type settings (include the hardware configuration headers)
#include "../../uTasker/driver.h"                                        // driver and general formatting routines
#if defined SDCARD_SUPPORT || defined MANAGED_FILES
    #include "../../uTasker/utFAT/mass_storage.h"
#endif
#include "../../stack/tcpip.h"                                           // TCP/IP stack and web utilities
#include "../../Hardware/hardware.h"                                     // general hardware
#include "../../uTasker/uTasker.h"                                       // operating system defines
#if defined USE_MODBUS
    #include "../../uTasker/MODBUS/modbus.h"
#endif
#include "TaskConfig.h"                                                  // the specific task configuration
#include "application.h"                                                 // general project specific include
#include "../../uTasker/uGLCDLIB/glcd.h"                                 // LCD
#ifdef _WINDOWS
    #include "../../WinSim/WinSim.h"
#endif

#ifdef OPSYS_CONFIG                                                      // this is only set in the hardware module
    #ifdef ETH_INTERFACE                                                 // if we support Ethernet we define some constants for its (TCP/IP) use
        const unsigned char cucNullMACIP[MAC_LENGTH] = { 0, 0, 0, 0, 0, 0 };
        const unsigned char cucBroadcast[MAC_LENGTH] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff }; // used also for broadcast IP
    #endif

    #ifdef SUPPORT_MIME_IDENTIFIER
    const CHAR *cMimeTable[] = {                                         // keep the ordering in the table to match the MIME type defines below!!
        (const CHAR *)"HTM",                                             // HTML file - will be interpreted by web server
        (const CHAR *)"JPG",                                             // JPG image
        (const CHAR *)"GIF",                                             // GIF image
        (const CHAR *)"CSS",                                             // CSS Cascading Style Sheets
        (const CHAR *)"JS",                                              // Java script
        (const CHAR *)"BIN",                                             // binary data file
        (const CHAR *)"TXT",                                             // text data file
        (const CHAR *)"BMP",                                             // BMP image
        (const CHAR *)"ICO",                                             // icon
        (const CHAR *)"???",                                             // all other types will be displayed as unknown
    };
    #endif
#endif

// File type identifiers
    //
#define MIME_HTML                  0                                     // this and any lower types will be parsed by the web server
#define MIME_JPG                   1
#define MIME_GIF                   2
#define MIME_CSS                   3
#define MIME_JAVA_SCRIPT           4
#define MIME_BINARY                5
#define MIME_TXT                   6
#define MIME_ICON                  7
#define MIME_BMP                   8
#define UNKNOWN_MIME               9                                     // this entry is needed to terminate the list

#define PLAIN_TEXTCONTENT(x) (x == MIME_TXT)                             // list of content types considered as plain text

#endif
