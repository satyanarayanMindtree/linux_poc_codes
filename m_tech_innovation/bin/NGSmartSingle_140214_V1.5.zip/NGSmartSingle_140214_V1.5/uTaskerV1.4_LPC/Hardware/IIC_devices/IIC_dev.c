/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:   	    IIC_dev.c
   Project: 	Single Chip Embedded Internet
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************

   14.03.2007 Added MAX543X Digital Potentiometer (L,M,N,P suffixes)
   29.09.2007 Added LM80 (microprocessor system hardware monitor) and PCF8574 port expander
   13.10.2007 Added MAX3353 USB OTG Charge Pump with switchable Pullup/Pulldown resistors
   23.05.2008 Added synchronisation of internal battery backed up RTC    {1}
   23.10.2008 Added fixed part type identifier in serial number of DS3640{2}
   30.07.2009 Added LM75A temperature sensor                             {3}
   01.11.2009 Added DS1621 register initialisation and extended operation{4}
   15.08.2010 Added STMPE811 and touch screen interface                  {5}
   28.09.2010 Added Sensirion SHT21 temperature and humidity sensor      {6}

*/                            

// IIC Device simulation when communicating over IIC bus

/* =================================================================== */
/*                           include files                             */
/* =================================================================== */


//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"



/**************************************************************************/
/*                  Dallas DS1621 Temperature sensor                      */
/**************************************************************************/

// Address 0x90

typedef struct stDS1621
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucCommand;
    unsigned char  ucConfigReg;
    unsigned char  ucOperation;

    unsigned char  ucTemperature[2];
} DS1621;

static DS1621 simDS1621 = {0x90, 0, 0, 0, 0, 0, 10, 0};                  // {4}


/**************************************************************************/
/*                  National LM75A Temperature sensor                     */
/**************************************************************************/

// Address 0x9e (Address pins pulled high)

typedef struct stLM75A
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalPointer;

    unsigned char  ucTemperature[2];
    unsigned char  ucConfig;
    unsigned char  ucHyst[2];
    unsigned char  ucOS[2];
    unsigned char  ucID;
} LM75A;

static LM75A simLM75A = {0x9e, 0, 0, 0, {0x1a, 0x80}, 0, {0x4b, 0x00}, {0x50, 0x00}, 0xa1};


/**************************************************************************/
/*                  Dallas DS1307 RTC                                     */
/**************************************************************************/

// Address 0xd0

typedef struct stTIME_BLOCK
{     
    unsigned char ucSeconds;
    unsigned char ucMinutes;
    unsigned char ucHours;
    unsigned char ucDayOfWeek;
    unsigned char ucDayOfMonth;
    unsigned char ucMonth;
    unsigned char ucYear;

    unsigned char ucControl;
} TIME_BLOCK;


typedef struct stDS1307
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalPointer;

    TIME_BLOCK     bTime;
    unsigned char  ucRAM[56];
} DS1307;

static DS1307 simDS1307 = {0xd0, 0};



/**************************************************************************/
/*                  Dallas DS3640 RTC and secure memory                   */
/**************************************************************************/

// Address 0xa0

typedef struct stTIME_BLOCK_S
{     
    unsigned char ucHundreds;
    unsigned char ucSeconds;
    unsigned char ucMinutes;
    unsigned char ucHours;
    unsigned char ucDayOfWeek;
    unsigned char ucDayOfMonth;
    unsigned char ucMonth;
    unsigned char ucYear;
    unsigned char ucWD[2];
    unsigned char ucAlarmMins;
    unsigned char ucAlarmHours;
    unsigned char ucRTC_control;
    unsigned char ucFilter;
    unsigned char ucTamperLatch1;
    unsigned char ucTamperLatch2;
    unsigned char ucSerialNumber[8];
    unsigned char ucRes1[7];
    unsigned char ucID_code;
    unsigned char ucControl[2];
    unsigned char ucStatus[2];
    unsigned char ucBattery[2];
    unsigned char ucRAW_temp[2];
    unsigned char ucHighTemp;
    unsigned char ucRes2;
    unsigned char ucLowTemp;
    unsigned char ucRes3;
    unsigned char ucDeltaTemp;
    unsigned char ucRes4[3];
    unsigned char ucTamperTimeStamp[8];
} TIME_BLOCK_S;


typedef struct stDS3640_DATA
{     
    TIME_BLOCK_S   bTime;
    unsigned char  ucRAM[64];
    unsigned char  ucRes[7];
    unsigned char  ucBankSelect;

    unsigned char  ucKeyPage[8][128];
} DS3640_DATA;

typedef struct stDS3640
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalPointer;

    DS3640_DATA    ucData;
} DS3640;

static DS3640 simDS3640 = {0xa0, 0};

/**************************************************************************/
/* STMPE811 port expander with touch screen controller                    */
/**************************************************************************/

typedef struct stSTMPE811
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalPointer;

    unsigned char  CHIP_ID[2];                                           // address 0
    unsigned char  ID_VER;                                               // address 2
    unsigned char  SYS_CTRL1;                                            // address 3 - reset control
    unsigned char  SYS_CTRL2;                                            // address 4 - clock control
    unsigned char  Res0[3];
    unsigned char  SPI_CFG;                                              // address 8 - SPI configuration
    unsigned char  INT_CTRL;                                             // address 9 - interrupt control register
    unsigned char  INT_EN;                                               // address 10 - interrupt enable register
    unsigned char  INT_STA;                                              // address 11 - interrupt status register (read-only)
    unsigned char  GPIO_EN;                                              // address 12 - GPIO interrupt enable register
    unsigned char  GPIO_INT_STA;                                         // address 13 - GPIO interrupt status register (read-only)
    unsigned char  ADC_INT_EN;                                           // address 14 - ADC interrupt enable register
    unsigned char  ADC_INT_STA;                                          // address 15 - ADC interrupt status register (read-only)
    unsigned char  GPIO_SET_PIN;                                         // address 16 - GPIO set pin register
    unsigned char  GPIO_CLR_PIN;                                         // address 17 - GPIO clear pin register
    unsigned char  GPIO_MPA_STA;                                         // address 18 - GPIO monitor pin state register
    unsigned char  GPIO_DIR;                                             // address 19 - GPIO direction register
    unsigned char  GPIO_ED;                                              // address 20 - GPIO edge detect register
    unsigned char  GPIO_RE;                                              // address 21 - GPIO rising edge register
    unsigned char  GPIO_FE;                                              // address 22 - GPIO falling edge register
    unsigned char  GPIO_AF;                                              // address 23 - GPIO alternate function register
    unsigned char  Res1[8];
    unsigned char  _ADC_CTRL1;                                           // address 32 - ADC control
    unsigned char  _ADC_CTRL2;                                           // address 33 - ADC control
    unsigned char  ADC_CAPT;                                             // address 34 - ADC acquisition control
    unsigned char  Res2[13];
    unsigned char  ADC_DATA_CH0[2];                                      // address 48 - ADC channel 0
    unsigned char  ADC_DATA_CH1[2];                                      // address 50 - ADC channel 1
    unsigned char  ADC_DATA_CH2[2];                                      // address 52 - ADC channel 2
    unsigned char  ADC_DATA_CH3[2];                                      // address 54 - ADC channel 3
    unsigned char  ADC_DATA_CH4[2];                                      // address 56 - ADC channel 4
    unsigned char  ADC_DATA_CH5[2];                                      // address 58 - ADC channel 5
    unsigned char  ADC_DATA_CH6[2];                                      // address 60 - ADC channel 6
    unsigned char  ADC_DATA_CH7[2];                                      // address 62 - ADC channel 7
    unsigned char  TSC_CTRL;                                             // address 64 - 4-wire touch screen controller setup
    unsigned char  TSC_CFG;                                              // address 65 - touch screen controller configuration
    unsigned char  WDW_TR_X[2];                                          // address 66 - window setup for top right X
    unsigned char  WDW_TR_Y[2];                                          // address 68 - window setup for top right Y
    unsigned char  WDW_BL_X[2];                                          // address 70 - window setup for bottom left X
    unsigned char  WDW_BL_Y[2];                                          // address 72 - window setup for bottom left Y
    unsigned char  FIFO_TH;                                              // address 74 - FIFO level to generate interrupt
    unsigned char  FIFO_STA;                                             // address 75 - FIFO status
    unsigned char  FIFO_SIZE;                                            // address 76 - FIFO size (read-only)
    unsigned char  TSC_DATA_X[2];                                        // address 77 - touch screen controller data access (read-only)
    unsigned char  TSC_DATA_Y[2];                                        // address 79 - touch screen controller data access (read-only)
    unsigned char  TSC_DATA_Z;                                           // address 81 - touch screen controller data access (read-only)
    unsigned char  TSC_DATA_XYZ[4];                                      // address 82 - touch screen controller data access (read-only)
    unsigned char  TSC_FRACT_XYZ;                                        // address 86 - touch screen controller FRACTION_XYZ
    unsigned char  TSC_DATA;                                             // address 87 - touch screen controller data access (read-only)
    unsigned char  TSC_I_DRIVE;                                          // address 88 - touch screen controller drive I
    unsigned char  TSC_SHIELD;                                           // address 89 - touch screen controller shield
    unsigned char  Res3[6];
    unsigned char  TEMP_CTRL;                                            // address 96 - temperature sensor setup
    unsigned char  TEMP_DATA;                                            // address 97 - temperature data (read-only)
    unsigned char  TEMP_TH;                                              // address 98 - threshold for temperature controlled interrupt
} STMPE811;

static STMPE811 simSTMPE811 = {0x82, 0, 0, 0,
0x08, 0x11,
0x03,
0x00, 0x0f,
0xff, 0xff, 0xff,
0x01, 0x00, 0x00, 0x10,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
0x9c, 0x01, 0xff,
0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x90, 0x00, 0x0f, 0xff, 0x0f, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00
};


/**************************************************************************/
/*               SHT21 temperature and humidity sensor                    */
/**************************************************************************/

typedef struct stSHT21
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalPointer;

    unsigned char  ucUserRegister;
    unsigned char  usTemperatur[3];
    unsigned char  usHumidity[3];
} SHT21;

static SHT21 simSHT21 = {0x80, 0, 0, 0, 0x02, 0x61, 0x64, 0x55, 0x63, 0x52, 0x63}; // temperatire 20.0�C, humidity 42.5%


#ifdef USE_USB_OTG_CHARGE_PUMP
/**************************************************************************/
/* MAX3353 USB OTG Charge Pump with switchable Pullup/Pulldown resistors  */
/**************************************************************************/

typedef struct stMAX3353_MEMORY
{     
    unsigned char  manufacturer_regs[4];
    unsigned char  manufacturer_id[4];
    unsigned char  res1[8];
    unsigned char  control_regs[2];
    unsigned char  res2;
    unsigned char  status_reg;
    unsigned char  interrupt_mask;
    unsigned char  interrupt_edge;
    unsigned char  interrupt_latch;
    unsigned char  res3[233];
} MAX3353_MEMORY;

// Address 0x58/59 (OTG_CHARGE_PUMP_IIC_ADD)

typedef struct stMAX3353
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucCommand;

    MAX3353_MEMORY memory;
} MAX3353;

static MAX3353 simMAX3353 = {OTG_CHARGE_PUMP_IIC_ADD, 0, 0, 0,
                             0x6a, 0x0b, 0x53, 0x33,                     // manufacturer regs
                             0x48, 0x5a, 0x42, 0x01,                     // manufaturer id
                             0,0,0,0,0,0,0,0,                            // res 1
                             0, 0x01,                                    // control regs
                             0
};

#endif


/**************************************************************************/
/*                  Wolfson WM8510 Audio Codec                            */
/**************************************************************************/

typedef struct stWM8510
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalRegister;
    unsigned short usData;

    unsigned short  usRegisters[56];
} WM8510;

static WM8510 simWM8510 = {0x34, 0};



/**************************************************************************/
/*                  24C01 EEPROM                                          */
/**************************************************************************/

typedef struct stEEPROM_24C01
{     
    unsigned short usMaxEEPROMLength;
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalAddress;
    unsigned char  ucEEPROM[128];
} EEPROM_24C01;

static EEPROM_24C01 sim24C01 = {128, 0xa4, 0};




/**************************************************************************/
/*                  MAX543X Digital Potentiometer                         */
/**************************************************************************/

#define ADDRESS_MAX543X 0x28
#ifdef MAX543X_PROJECT_ADDRESS
    #undef ADDRESS_MAX543X
    #define ADDRESS_MAX543X MAX543X_PROJECT_ADDRESS                      // allow project address define
#endif

typedef struct stMAX543X
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucCommand;
    unsigned char  ucVREG;                                               // volatile register
    unsigned char  ucNVREG;                                              // non-volatile register

    unsigned char  ucWiperPosition;
} MAX543X;

static MAX543X simMAX543X = {ADDRESS_MAX543X, 0};


/**************************************************************************/
/*            NATIONAL LM80 Microprocessor System Hardware Monitor        */
/**************************************************************************/

#define ADDRESS_LM80 0x50

#define LM80_CONFIG_START          0x01
#define LM80_CONFIG_INT_ENABLE     0x02
#define LM80_CONFIG_INT_ACT_HIGH   0x04
#define LM80_CONFIG_INT_CLEAR      0x08
#define LM80_CONFIG_RESET          0x10
#define LM80_CONFIG_CHASSIS_CLEAR  0x20
#define LM80_CONFIG_GPO            0x40
#define LM80_CONFIG_INITIALIZATION 0x80


typedef struct stNATIONAL_LM80
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucInternalPointer;

    unsigned char  ucConfigurationRegister;
    unsigned char  ucInterruptStatusRegister1;
    unsigned char  ucInterruptStatusRegister2;
    unsigned char  ucInterruptMaskRegister1;
    unsigned char  ucInterruptMaskRegister2;
    unsigned char  ucFan_RST_OS_Register;
    unsigned char  ucOS_config_Temperature_Register;
    unsigned char  ucNoRegs[25];
    unsigned char  ucValueRAM[32];
} NATIONAL_LM80;

static NATIONAL_LM80 simLM80 = {ADDRESS_LM80, 0};


/**************************************************************************/
/*                       PHILIPS PCF8574 Port Expander                    */
/**************************************************************************/

#define ADDRESS_PCF8574  0x70

typedef struct stPCF8574
{     
	unsigned char  address;
    unsigned char  ucState;
    unsigned char  ucRW;
    unsigned char  ucOutput;
} PCF8574;

static PCF8574 simPCF8574 = {ADDRESS_PCF8574, 0};




// When one particular device is addressed all others are reset using this routine
//
static void fnResetOthers(unsigned char ucAddress)
{
    if (ucAddress != simDS1621.address) {
        simDS1621.ucState = 0;
    }

    if (ucAddress != simMAX543X.address) {
        simMAX543X.ucState = 0;
    }

    if (ucAddress != simDS1307.address) {
        simDS1307.ucState = 0;
    }

    if (ucAddress != simWM8510.address) {
        simWM8510.ucState = 0;
    }

    if (ucAddress != sim24C01.address) {
        sim24C01.ucState = 0;
    }

    if (ucAddress != simDS3640.address) {
        simDS3640.ucState = 0;
    }

    if (ucAddress != simLM80.address) {
        simLM80.ucState = 0;
    }

    if (ucAddress != simPCF8574.address) {
        simPCF8574.ucState = 0;
    }

    if (ucAddress != simLM75A.address) {                                 // {3}
        simLM75A.ucState = 0;
    }

    if (ucAddress != simSTMPE811.address) {                              // {5}
        simSTMPE811.ucState = 0;
    }

    if (ucAddress != simSHT21.address) {                                 // {6}
        simSHT21.ucState = 0;
    }

#ifdef USE_USB_OTG_CHARGE_PUMP
    if (ucAddress != simMAX3353.address) {
        simMAX3353.ucState = 0;
    }
#endif
}


// Initialise the simulated RTC with security memory from PC's clock
//
static void fnInitTimeDS1307(char *argv[])
{
    unsigned short *ptrShort = (unsigned short *)*argv;
    unsigned char ucTens;
    unsigned char ucUnits;

    simDS1307.bTime.ucYear = (unsigned char)(*ptrShort++ - 2000);
    simDS1307.bTime.ucMonth = (unsigned char)(*ptrShort++);
    simDS1307.bTime.ucDayOfWeek = (unsigned char)(*ptrShort++);
    simDS1307.bTime.ucDayOfMonth = (unsigned char)(*ptrShort++);
    simDS1307.bTime.ucHours = (unsigned char)(*ptrShort++);
    simDS1307.bTime.ucMinutes = (unsigned char)(*ptrShort++);
    simDS1307.bTime.ucSeconds = (unsigned char)(*ptrShort++);

    // we have to convert to the correct format for this device here
    ucTens = (simDS1307.bTime.ucSeconds/10);
    ucUnits = simDS1307.bTime.ucSeconds - 10*ucTens;
    simDS1307.bTime.ucSeconds = ((ucTens<<4) + ucUnits);

    ucTens = (simDS1307.bTime.ucMinutes/10);
    ucUnits = simDS1307.bTime.ucMinutes - 10*ucTens;
    simDS1307.bTime.ucMinutes = ((ucTens<<4) + ucUnits);

    ucTens = (simDS1307.bTime.ucHours/10);
    ucUnits = simDS1307.bTime.ucHours - 10*ucTens;
    simDS1307.bTime.ucHours = ((ucTens<<4) + ucUnits);

    ucTens = (simDS1307.bTime.ucDayOfMonth/10);
    ucUnits = simDS1307.bTime.ucDayOfMonth - 10*ucTens;
    simDS1307.bTime.ucDayOfMonth = ((ucTens<<4) + ucUnits);

    ucTens = (simDS1307.bTime.ucMonth/10);
    ucUnits = simDS1307.bTime.ucMonth - 10*ucTens;
    simDS1307.bTime.ucMonth = ((ucTens<<4) + ucUnits);

    ucTens = (simDS1307.bTime.ucYear/10);
    ucUnits = simDS1307.bTime.ucYear - 10*ucTens;
    simDS1307.bTime.ucYear = ((ucTens<<4) + ucUnits);
}


// Initialise the simulated RTC from PC's clock
//
static void fnInitTimeDS3640(char *argv[])
{
    unsigned short *ptrShort = (unsigned short *)*argv;
    unsigned char ucTens;
    unsigned char ucUnits;

    simDS3640.ucData.bTime.ucYear = (unsigned char)(*ptrShort++ - 2000);
    simDS3640.ucData.bTime.ucMonth = (unsigned char)(*ptrShort++);
    simDS3640.ucData.bTime.ucDayOfWeek = (unsigned char)(*ptrShort++);
    simDS3640.ucData.bTime.ucDayOfMonth = (unsigned char)(*ptrShort++);
    simDS3640.ucData.bTime.ucHours = (unsigned char)(*ptrShort++);
    simDS3640.ucData.bTime.ucMinutes = (unsigned char)(*ptrShort++);
    simDS3640.ucData.bTime.ucSeconds = (unsigned char)(*ptrShort++);

    // we have to convert to the correct format for this device here
    ucTens = (simDS3640.ucData.bTime.ucSeconds/10);
    ucUnits = simDS3640.ucData.bTime.ucSeconds - 10*ucTens;
    simDS3640.ucData.bTime.ucSeconds = ((ucTens<<4) + ucUnits);

    ucTens = (simDS3640.ucData.bTime.ucMinutes/10);
    ucUnits = simDS3640.ucData.bTime.ucMinutes - 10*ucTens;
    simDS3640.ucData.bTime.ucMinutes = ((ucTens<<4) + ucUnits);

    ucTens = (simDS3640.ucData.bTime.ucHours/10);
    ucUnits = simDS3640.ucData.bTime.ucHours - 10*ucTens;
    simDS3640.ucData.bTime.ucHours = ((ucTens<<4) + ucUnits);

    ucTens = (simDS3640.ucData.bTime.ucDayOfMonth/10);
    ucUnits = simDS3640.ucData.bTime.ucDayOfMonth - 10*ucTens;
    simDS3640.ucData.bTime.ucDayOfMonth = ((ucTens<<4) + ucUnits);

    ucTens = (simDS3640.ucData.bTime.ucMonth/10);
    ucUnits = simDS3640.ucData.bTime.ucMonth - 10*ucTens;
    simDS3640.ucData.bTime.ucMonth = ((ucTens<<4) + ucUnits);

    ucTens = (simDS3640.ucData.bTime.ucYear/10);
    ucUnits = simDS3640.ucData.bTime.ucYear - 10*ucTens;
    simDS3640.ucData.bTime.ucYear = ((ucTens<<4) + ucUnits);

    simDS3640.ucData.bTime.ucFilter = 0x54;
    simDS3640.ucData.bTime.ucControl[0] = 0xcf;
    simDS3640.ucData.bTime.ucControl[1] = 0xd8;

    simDS3640.ucData.bTime.ucHighTemp = 0x30;
    simDS3640.ucData.bTime.ucLowTemp = 0xfc;
    simDS3640.ucData.bTime.ucDeltaTemp = 0x0a;


    // Add a serial number
    simDS3640.ucData.bTime.ucSerialNumber[0] = 0x83;                     // {2} chip identifier  byte
    simDS3640.ucData.bTime.ucSerialNumber[1] = 0x22;
    simDS3640.ucData.bTime.ucSerialNumber[2] = 0x33;
    simDS3640.ucData.bTime.ucSerialNumber[3] = 0x44;
    simDS3640.ucData.bTime.ucSerialNumber[4] = 0x55;
    simDS3640.ucData.bTime.ucSerialNumber[5] = 0x66;
    simDS3640.ucData.bTime.ucSerialNumber[6] = 0x77;
    simDS3640.ucData.bTime.ucSerialNumber[7] = 0x88;
}



// Set RTC to system time on startup
//
extern void fnInitTime(char *argv[])
{
#ifdef SUPPORT_RTC                                                       // {1}
    extern void fnInitInternalRTC(char *argv[]);
    fnInitInternalRTC(argv);                                             // allow initialisation of an internal RTC
#endif
    fnInitTimeDS1307(argv);
    fnInitTimeDS3640(argv);

    simLM80.ucConfigurationRegister = LM80_CONFIG_INT_CLEAR;             // initialise also some register values at reset
    simLM80.ucFan_RST_OS_Register   = 0x14;
    simLM80.ucOS_config_Temperature_Register = 0x01;

    simPCF8574.ucOutput = 0xff;
}


extern int fnCheckRTC(void)
{
    if ((!(simDS1307.bTime.ucSeconds & 0x80)) && (simDS1307.bTime.ucControl & 0x10)) {
        if (simDS1307.bTime.ucControl & 0x03) {
            return 1;                                                    // fastest rate possible
        }
        else {
            static unsigned char ucRTC_Output = 0;
            if (++ucRTC_Output >= (500/TICK_RESOLUTION)) {
                ucRTC_Output = 0;
                return 1;                                                // 1 Hz TICK rate
            }
        }
    }
    return 0;
}

unsigned char fnSimIIC_devices(unsigned char ucType, unsigned char ucData)
{
    switch (ucType) {
    case IIC_ADDRESS:
        if ((ucData & ~0x01) == simDS1307.address) {                     // DS1307 is being addressed
            simDS1307.ucState = 1;
            simDS1307.ucRW = (ucData & 0x01);
        }
        else if ((ucData & ~0x01) == simDS1621.address) {
            simDS1621.ucState = 1;
            simDS1621.ucRW = (ucData & 0x01);
            if ((simDS1621.ucCommand == 0xaa) & (ucData & 0x01)) {       // start reading temperature
                simDS1621.ucState = 2;                                   // 2 bytes to be read
            }
        }
        else if ((ucData & ~0x01) == simWM8510.address) {
            simWM8510.ucState = 1;
            simWM8510.ucRW = (ucData & 0x01);
        }
        else if ((ucData & ~0x01) == sim24C01.address) {
            sim24C01.ucState++;                                          // being addressed
            sim24C01.ucRW = (ucData & 0x01);                             // being read or written
            if (sim24C01.ucState >= 4) {
                sim24C01.ucState = 1;
            }
        }
        else if ((ucData & ~0x01) == simDS3640.address) {
            simDS3640.ucState++;                                         // being addressed
            simDS3640.ucRW = (ucData & 0x01);                            // being read or written
            if (simDS3640.ucState >= 4) {
                simDS3640.ucState = 1;
            }
        }
        else if ((ucData & ~0x01) == simMAX543X.address) {               // being addressed
            simMAX543X.ucState = 1;
            simMAX543X.ucRW = (ucData & 0x01);
        }        
        else if ((ucData & ~0x01) == simLM80.address) {                  // being addressed
            simLM80.ucState = 1;
            simLM80.ucRW = (ucData & 0x01);
        }
        else if ((ucData & ~0x01) == simPCF8574.address) {               // being addressed
            simPCF8574.ucState = 1;
            simPCF8574.ucRW = (ucData & 0x01);
        }
        else if ((ucData & ~0x01) == simLM75A.address) {                 // {3} being addressed
            simLM75A.ucState = 1;
            simLM75A.ucRW = (ucData & 0x01);
        }
        else if ((ucData & ~0x01) == simSTMPE811.address) {              // {5} being addressed
            simSTMPE811.ucState = 1;
            simSTMPE811.ucRW = (ucData & 0x01);
        }
        else if ((ucData & ~0x01) == simSHT21.address) {                 // {6} being addressed
            simSHT21.ucState = 1;
            simSHT21.ucRW = (ucData & 0x01);
        }
#ifdef USE_USB_OTG_CHARGE_PUMP
        else if ((ucData & ~0x01) == simMAX3353.address) {               // being addressed
            simMAX3353.ucState = 1;
            simMAX3353.ucRW = (ucData & 0x01);
        }
#endif
        fnResetOthers((unsigned char)(ucData & ~0x01));
        break;

    case IIC_TX_DATA:
        if (simDS1307.ucState == 1) {                                    // DS1307 is being written to
            simDS1307.ucInternalPointer = ucData;
            simDS1307.ucState++;
        }
        else if (simDS1307.ucState > 1) {                                // date being written
            unsigned char *ptr = (unsigned char *)&simDS1307.bTime;
            ptr += simDS1307.ucInternalPointer++;
            *ptr = ucData;                                               // set the data
        }
        else if (simDS1621.ucState != 0) {                               // DS1307 is being written to
            switch (simDS1621.ucCommand) {                               // {4}
            case 0xac:
                simDS1621.ucConfigReg = ucData;                          // write configuration
                simDS1621.ucCommand = 0;
                simDS1621.ucState = 0;
                break;
            default:
                simDS1621.ucCommand = ucData;                            // commands to the temperature sensor
                if (ucData == 0xee) {                                    // start conversion
                    simDS1621.ucState = 0;
                }
                else if (ucData == 0xaa) {                               // command to read temperature
                    simDS1621.ucState = 0;
                }
                break;
            }
        }
        else if (simLM75A.ucState >= 1) {                                // {3} LM75A is being written to
            switch (simLM75A.ucState) {
            case 1:
                simLM75A.ucState++;
                simLM75A.ucInternalPointer = ucData;                     // commands to the temperature sensor
                break;
            case 2:
                if (simLM75A.ucInternalPointer == 1) {                   // write config
                    simLM75A.ucConfig = ucData;
                }
                else if (simLM75A.ucInternalPointer == 2) {              // write hysteresis
                    simLM75A.ucHyst[0] = ucData;
                    simLM75A.ucState++;
                }
                else if (simLM75A.ucInternalPointer == 3) {              // write offset
                    simLM75A.ucOS[0] = ucData;
                    simLM75A.ucState++;
                }
                break;
            case 3:
                if (simLM75A.ucInternalPointer == 2) {                   // write hysteresis
                    simLM75A.ucHyst[1] = ucData;
                }
                else if (simLM75A.ucInternalPointer == 3) {              // write offset
                    simLM75A.ucOS[1] = ucData;
                }
                break;
            default:
                break;
            }
        }
        else if (simSHT21.ucState >= 1) {                                // {6} SHT21 being written to
            simSHT21.ucState++;
            simSHT21.ucInternalPointer = ucData;                         // commands to the temperature/humidity sensor
        }
        else if (simWM8510.ucState == 1) {                               // WM8510 is being written to (command byte 1)
            simWM8510.ucInternalRegister = (ucData>>1);                  // register to be written
            simWM8510.usData = (ucData<<8);                              // save 9th bit
            simWM8510.usData &= 0x100;
            simWM8510.ucState++;
        }
        else if (simWM8510.ucState == 2) {                               // WM8510 is being written to (command byte 2)
            simWM8510.usData |= (ucData);                                // complete register contends received
            simWM8510.usRegisters[simWM8510.ucInternalRegister] = simWM8510.usData;
            simWM8510.ucState = 0;
        }
        else if ((sim24C01.ucState == 1) && (sim24C01.ucRW == 0)) {      // being addressed for write
            sim24C01.ucInternalAddress = ucData;                         // set internal pointer
            sim24C01.ucState++;
        }
        else if ((sim24C01.ucState >= 2) && (sim24C01.ucRW == 0)) {      // being addressed for write
            sim24C01.ucEEPROM[sim24C01.ucInternalAddress++] = ucData;    // write new data to EEPROM
            if (sim24C01.ucInternalAddress >= sim24C01.usMaxEEPROMLength) {
                sim24C01.ucInternalAddress = 0;
            }
            sim24C01.ucState++;
        }
        else if ((simDS3640.ucState == 1) && (simDS3640.ucRW == 0)) {    // being addressed for write
            simDS3640.ucInternalPointer = ucData;                        // set internal pointer
            simDS3640.ucState++;
        }
        else if ((simSTMPE811.ucState == 1) && (simSTMPE811.ucRW == 0)) {// {5} being addressed for write
            simSTMPE811.ucInternalPointer = ucData;                      // set internal pointer
            simSTMPE811.ucState++;
        }
        else if ((simSTMPE811.ucState == 2) && (simSTMPE811.ucRW == 0)) {// {5} being addressed for register write
            unsigned char *ptrData = (unsigned char *)&simSTMPE811.CHIP_ID[0];
            ptrData += simSTMPE811.ucInternalPointer;
            switch (simSTMPE811.ucInternalPointer) {
            case 0x0b:
                if (ucData & 0x01) {
#if defined _STM32 && defined MB785_GLCD_MODE
                    RESET_IRQ_LINE();                                    // set interrupt line back to '1'
#endif
                }
                *ptrData = ucData;
                break;
            default:
                *ptrData = ucData;
                break;
            }
            simSTMPE811.ucInternalPointer++;
        }
        else if ((simDS3640.ucState >= 2) && (simDS3640.ucRW == 0)) {    // being addressed for write
            unsigned char *ptrData = (unsigned char *)&simDS3640.ucData;
            ptrData += simDS3640.ucInternalPointer;
            if (simDS3640.ucInternalPointer >= 0x80) {                   // in paged memory
                ptrData += 128*simDS3640.ucData.ucBankSelect;
            }
            simDS3640.ucInternalPointer++;
            *ptrData = ucData;                                           // write new data to device

            simDS3640.ucState++;
        }
        else if ((simMAX543X.ucState == 1) && (simMAX543X.ucRW == 0)) {  // being addressed for write
            simMAX543X.ucCommand = ucData;                               // set command
            simMAX543X.ucState++;
        }
        else if ((simMAX543X.ucState == 2) && (simMAX543X.ucRW == 0)) {  // being addressed for write
            switch (simMAX543X.ucCommand) {
                case 0x11:                                               // command VREG
                    simMAX543X.ucVREG = (ucData & 0xf8);
                    simMAX543X.ucWiperPosition = (simMAX543X.ucVREG >> 3);
                    break;

                case 0x21:                                               // command NVREG
                    simMAX543X.ucNVREG = (ucData & 0xf8);
                    break;

                case 0x61:                                               // command NVREGxVREG
                    simMAX543X.ucVREG = simMAX543X.ucNVREG;
                    simMAX543X.ucWiperPosition = (simMAX543X.ucVREG >> 3);
                    break;

                case 0x51:                                               // command VREGxNVREG
                    simMAX543X.ucNVREG = simMAX543X.ucVREG;
                    break;
            }
            simMAX543X.ucState = 0;;
        }
        else if ((simLM80.ucState > 0) && (simLM80.ucRW == 0)) {         // being addressed for write
            if (simLM80.ucState == 1) {
                simLM80.ucInternalPointer = ucData;                      // set internal pointer
                simLM80.ucState++;
            }
            else if (simLM80.ucState == 2) {
                unsigned char *ptr = &simLM80.ucConfigurationRegister;
                simLM80.ucState = 0;
                if (simLM80.ucInternalPointer <= 0x3f) {
                    ptr += simLM80.ucInternalPointer;
                    *ptr = ucData;
                }
            }
        }
        else if ((simPCF8574.ucState > 0) && (simPCF8574.ucRW == 0)) {   // being addressed for write
            simPCF8574.ucOutput = ucData;
            simPCF8574.ucState = 0;
        }
#ifdef USE_USB_OTG_CHARGE_PUMP
        else if ((simMAX3353.ucState > 0) && (simMAX3353.ucRW == 0)) {   // being addressed for write
            if (simMAX3353.ucState == 1) {
                simMAX3353.ucCommand = ucData;                           // set the control register being written
                simMAX3353.ucState++;
            }
            else if (simMAX3353.ucState = 2) {
                unsigned char *ptr = (unsigned char *)&simMAX3353.memory;
                ptr += simMAX3353.ucCommand;
                *ptr = ucData;
                simMAX3353.ucState = 0;
            }
        }
#endif
        break;

    case IIC_RX_DATA:
        if (simDS1307.ucRW && (simDS1307.ucState == 1)) {
            unsigned char *ptr = (unsigned char *)&simDS1307.bTime;
            ptr += simDS1307.ucInternalPointer++;
            return (*ptr);
        }
        else if (simDS1621.ucRW && (simDS1621.ucState >= 1)) {
            if (simDS1621.ucCommand == 0xaa) {                           // if the get temperature command was previously executed 
                if (simDS1621.ucState == 2) {
                    simDS1621.ucState--;
                    if (simDS1621.ucTemperature[0] == 10) {              // change between 10 and 35�C on each read
                        simDS1621.ucTemperature[0] = 35;
                    }
                    else {
                        simDS1621.ucTemperature[0] = 10;
                    }
                    return (simDS1621.ucTemperature[0]);
                }
                else {
                    simDS1621.ucState = 0;
                    simDS1621.ucCommand = 0;
                    return (simDS1621.ucTemperature[1]);
                }
            }
            else {
                return 0;
            }
        }
        else if (sim24C01.ucRW && (sim24C01.ucState >= 3)) {             // repeated start - first byte is data
            unsigned char ucReturn = sim24C01.ucEEPROM[sim24C01.ucInternalAddress++];
            if (sim24C01.ucInternalAddress >= sim24C01.usMaxEEPROMLength) {
                sim24C01.ucInternalAddress = 0;
            }
            return (ucReturn);
        }
        else if (simDS3640.ucRW && (simDS3640.ucState >= 3)) {           // repeated start - first byte is data
            unsigned char *ptrData = (unsigned char *)&simDS3640.ucData;
            unsigned char ucReturn;

            ptrData += simDS3640.ucInternalPointer;
            if (simDS3640.ucInternalPointer++ >= 0x80) {                 // in paged memory
                ptrData += 128*simDS3640.ucData.ucBankSelect;
            }
            ucReturn = *ptrData;
            return (ucReturn);
        }
        else if (simSTMPE811.ucRW && (simSTMPE811.ucState != 0)) {       // {5} read from STMPE811
            unsigned char *ptrData = (unsigned char *)&simSTMPE811.CHIP_ID[0];
            ptrData += simSTMPE811.ucInternalPointer;
            simSTMPE811.ucInternalPointer++;
            return (*ptrData);
        }
        else if (simLM75A.ucRW && (simLM75A.ucState != 0)) {             // {3} LM75A is being read
            switch (simLM75A.ucInternalPointer) {
            case 0:                                                      // temperature value
                if (simLM75A.ucState == 1) {
                    simLM75A.ucState++;
                    return (simLM75A.ucTemperature[0]);
                }
                else if (simLM75A.ucState == 2) {
                    simLM75A.ucState++;
                    return (simLM75A.ucTemperature[1]);
                }
                else {
                    return 0xff;
                }
                break;
            case 1:                                                      // configuration
                if ((simLM75A.ucState == 1) || (simLM75A.ucState == 2)) {
                    simLM75A.ucState++;
                    return (simLM75A.ucConfig);
                }
                else {
                    return 0xff;
                }
                break;
            case 2:                                                      // temperature hyst
                if (simLM75A.ucState == 1) {
                    simLM75A.ucState++;
                    return (simLM75A.ucHyst[0]);
                }
                else if (simLM75A.ucState == 2) {
                    simLM75A.ucState++;
                    return (simLM75A.ucHyst[1]);
                }
                else {
                    return 0xff;
                }
                break;
            case 3:                                                      // temperature offset
                if (simLM75A.ucState == 1) {
                    simLM75A.ucState++;
                    return (simLM75A.ucOS[0]);
                }
                else if (simLM75A.ucState == 2) {
                    simLM75A.ucState++;
                    return (simLM75A.ucOS[1]);
                }
                else {
                    return 0xff;
                }
                break;
            case 7:                                                      // product ID
                if ((simLM75A.ucState == 1) || (simLM75A.ucState == 2)) {
                    simLM75A.ucState++;
                    return (simLM75A.ucID);
                }
                else {
                    return 0xff;
                }
                break;
            default:
                return 0xff;
            }
        }
        else if (simSHT21.ucRW && (simSHT21.ucState != 0)) {             // {6} SHT21 being read
            switch (simSHT21.ucInternalPointer) {
            case 0xe3:                                                   // trigger temperature measurement, hold master
            case 0xf3:                                                   // trigger temperature measurement, no-hold master
                return (simSHT21.usTemperatur[simSHT21.ucState++ - 1]);
            case 0xe5:                                                   // trigger humidity measurement, hold master
            case 0xf5:                                                   // trigger humidity measurement, no-hold master
                return (simSHT21.usHumidity[simSHT21.ucState++ - 1]);
            case 0xe7:                                                   // read user register
                return (simSHT21.ucUserRegister);
            default:
                break;
            }
            return (0xff);
        }        
#ifdef USE_USB_OTG_CHARGE_PUMP
        else if (simMAX3353.ucRW && (simMAX3353.ucState >= 3)) {         // repeated start - first byte is data
            return (0);
        }
#endif
        break;

    case IIC_RX_COMPLETE:
    case IIC_TX_COMPLETE:
        fnResetOthers(0);
        break;
    }
    return 0;
}


#if defined SUPPORT_TOUCH_SCREEN && defined MB785_GLCD_MODE              // {5}

#define MIN_X_TOUCH        0x00f0
#define MAX_X_TOUCH        0x0f26
#define MIN_Y_TOUCH        0x0110
#define MAX_Y_TOUCH        0x0f10


// This routine is used to set touch screen ADC values
//
extern void fnSTMPE811(int iX, int iY)
{
    unsigned short usX, usY;
    if (iX < 0) {                                                        // pen lifted
        simSTMPE811.FIFO_STA = 0x20;                                     // FIFO empty
        simSTMPE811.TSC_CTRL &= ~0x80;
        return;
    }
    simSTMPE811.FIFO_STA = 0;                                            // FIFO not empty
    simSTMPE811.TSC_CTRL |= 0x80;
    iX -= 6;
    iY -= 4;
    usX = (MIN_X_TOUCH + ((iX * (MAX_X_TOUCH - MIN_X_TOUCH))/GLCD_X));
    usY = (MIN_Y_TOUCH + ((iY * (MAX_Y_TOUCH - MIN_Y_TOUCH))/GLCD_Y));
    simSTMPE811.TSC_DATA_X[0] = (unsigned char)(usY >> 8);
    simSTMPE811.TSC_DATA_X[1] = (unsigned char)(usY);
    simSTMPE811.TSC_DATA_Y[0] = (unsigned char)(usX >> 8);
    simSTMPE811.TSC_DATA_Y[1] = (unsigned char)(usX);
}
#endif
