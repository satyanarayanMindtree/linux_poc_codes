//note: only I2C calling function you have to configure 


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "i2c.h"
#include "TouchKey.h"
//#include "Timer.h"
//#include "delay.h"

void Capsence_Write_Register(unsigned short int write_address, unsigned short int value);
int Capsence_Read_Register(unsigned long int register_addr);
void Capsence_Init(void);
char check_cap_keypad(void);
extern void Delay_X10ms(unsigned int value);

static const char CAP_Device_addr_write = 0x58;
static const char CAP_Device_addr_read = 0x59;


//I2CRxFlag
/********************************************************************
Function name: Capsence_Write_Register
Description : this function is written for writing value to register
of capsence IC	specially during initialisation process 
remove comment for debugging of register, value we can read back.
call :	Capsence_Write_Register(address of register,value to be written in register)
********************************************************************/
void Capsence_Write_Register(unsigned short int write_address, unsigned short int value)
{
char i;
	for ( i = 0; i < I2CBUFSIZE; i++ )	// clear buffer 
  {
		I2CMasterBuffer[i] = 0;
  }
  I2CWriteLength = 4;
  I2CReadLength = 0;
  I2CMasterBuffer[0] = CAPKEY_DEV_ADDR; // configuration value, no change from default 
  I2CMasterBuffer[1] = ((write_address & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CMasterBuffer[2] = (write_address & 0x00FF);				//REGISTER ADDRESS LSB	
	I2CMasterBuffer[3] = ((value & 0xFF00) >> 8); 				//REGISTER DATA(to Write) MSB
	I2CMasterBuffer[4] = (value & 0x00FF);; 							//REGISTER DATA(to Write) LSB
  I2CCmd = LM75_CONFIG;
//  I2CEngine(); 
}

/********************************************************************
Function name: int Capsence_Read_Register
Description : this function is written for writing value to register
of capsence IC specially during initialisation process 
call :	Capsence_Read_Register(address of register)
return : 2 byte integer value.
**********************************************************************/
int Capsence_Read_Register(unsigned long int register_addr)
{
char i;
	unsigned int reg_val_int=0;
	for ( i = 0; i < I2CBUFSIZE; i++ )	// clear buffer 
  {
		I2CMasterBuffer[i] = 0;
  }
  I2CWriteLength = 2;
  I2CReadLength = 2;
  I2CMasterBuffer[0] = CAPKEY_DEV_ADDR;//CAPKEY_DEV_RD_ADDR;//
  I2CMasterBuffer[1] = ((register_addr & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CMasterBuffer[2] = (register_addr & 0x00FF);				//REGISTER ADDRESS LSB		
  I2CMasterBuffer[3] = CAPKEY_DEV_RD_ADDR;	//CAPKEY_ADDR | RD_BIT;
  I2CCmd = LM75_TEMP;
//  I2CEngine();
	
	reg_val_int = I2CMasterBuffer[4]; 
	reg_val_int <<= 8 ;
	reg_val_int = reg_val_int | I2CMasterBuffer[5];
    	return (reg_val_int);
}

/********************************************************************
Function Name: Initialisation Function
Description:
********************************************************************/ 
void Capsence_Init(void)
{
//	unsigned char res;
//	unsigned int reg_val;

	Capsence_Write_Register(0x0000,0xFFFF);
//	 printf("initialising capsence \n");
/********************************************************************************************/
	Capsence_Write_Register(0x000A,0x0000);		//DCM configuration

/********************************touch sensor*************************************************************/
   	Capsence_Write_Register(0x0041,0x011E);		//Touch Sensor Enable	   
	Capsence_Write_Register(0x0042,0x013F);		//Touch Sensor Enable

/************************************interrupt***********************************************/
	Capsence_Write_Register(0x0008,0x8003);	
	Capsence_Write_Register(0x0043,0x03FF);		//touch interrupt enable =0x01FF disable =0x0000 (Ch=0 to 9)
	Capsence_Write_Register(0x0044,0x03FF);		//touch interrupt enable =0x01FF disable =0x0000 (Ch=10 to 19)
/*******************************touch threshold levels***************************************/
	Capsence_Write_Register(0x005F,0x0001);		//????????? touch parameter page selection
	Capsence_Write_Register(0x0060,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0061,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0062,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0063,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0064,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0065,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0066,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0067,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0068,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0069,0x0014);	   //touch parameters
	Capsence_Write_Register(0x006A,0x0014);	   //touch parameters
	Capsence_Write_Register(0x006B,0x0014);	   //touch parameters
	Capsence_Write_Register(0x006C,0x0014);	   //touch parameters
	Capsence_Write_Register(0x006D,0x0014);	   //touch parameters
	Capsence_Write_Register(0x006E,0x0014);	   //touch parameters
	Capsence_Write_Register(0x006F,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0070,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0071,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0072,0x0014);	   //touch parameters
	Capsence_Write_Register(0x0073,0x0014);	   //touch parameters
/********************************************************************************************/
	Capsence_Write_Register(0x004E,0x5000);	   //SELC_configuration
	Delay_X10ms(40);
/********************************************************************************************/	
	Capsence_Write_Register(0x0051,0x0A0A);	   //Ambient Calibration
/********************************************************************************************/
	Capsence_Write_Register(0x0052,0x0108);	   //recalibration configuration
	Delay_X10ms(20);
/********************************************************************************************/
	Capsence_Write_Register(0x0053,0x0108);	   //stuck touch
	Delay_X10ms(20);
/********************************************************************************************/	
	Capsence_Write_Register(0x0075,0x0005);	   //touch hysteresis	
/********************************************************************************************/
	Capsence_Write_Register(0x0040,0x8130);		//touch configuration
	Delay_X10ms(10);
	Capsence_Write_Register(0x0050,0x00FF);	   //Ambient Calibration
/********************************************************************************************/  
  	Capsence_Write_Register(0x0001,0xFFFF);	 //software reset
	Delay_X10ms(10);
}

/********************************************************************
Function Name: 	char check_cap_keypad(void)
Description:	this function returns value of key from the matrix. it is recomanded to
use this function as it is.
********************************************************************/ 
char check_cap_keypad(void)
{
	int register_val_45,register_val_46;
	char ret_val='=';
//	unsigned long int buf,buf1;
	static const char key_mat[17]={	'1','2','3','U',		// B8,B7,B9,_
					'4','5','6','D',		// B5,B6,B10,_
					'7','8','9','M',		// B3,B4,B11,B1
					'C','0','.','E',};		// __,B2,__,B12

  register_val_45 = Capsence_Read_Register(0x0045);
//	printf("%x\n",register_val_45);
	register_val_46 = Capsence_Read_Register(0x0046);
//	printf("%x\n",register_val_46);

	if(register_val_45==0x0000 && register_val_46==0x0000 )
	{
		ret_val='=';
		return ret_val;
	}
	switch(register_val_45)
	{
		
		case 0x0002:
		{
		 	ret_val=key_mat[11];		
			break;
		}
		case 0x0004:
		{
		 	ret_val=key_mat[13];		
			break;
		}
			case 0x0008:
		{
		 	ret_val=key_mat[8];		
			break;
		}
		case 0x0010:
		{
		 	ret_val=key_mat[9];		
			break;
		}

		case 0x0100:
		{
		 	ret_val=key_mat[4];		
			break;
		}

	}
	switch(register_val_46)
	{
		case 0x001:
		{
		 	ret_val=key_mat[5];		
			break;
		}
		case 0x0002:
		{
		 	ret_val=key_mat[1];		
			break;
		}
		case 0x0004:
		{
		 	ret_val=key_mat[0];		
			break;
		}
		case 0x0008:
		{
		 	ret_val=key_mat[2];		
			break;
		}
		case 0x0010:
		{
		 	ret_val=key_mat[6];		
			break;
		}
		case 0x0020:
		{
		 	ret_val=key_mat[10];		
			break;
		}

		case 0x0100:
		{
		 	ret_val=key_mat[15];		
			break;
		}

	} 
	Delay_X10ms(2);

 return	 ret_val;	
}	
		

/*
void Capsence_Write_Register(unsigned short int write_address, unsigned short int value)
{
	for ( i = 0; i < BUFSIZE; i++ )	// clear buffer 
  {
		I2CMasterBuffer[i] = 0;
  }
  I2CWriteLength = 4;
  I2CReadLength = 0;
  I2CMasterBuffer[0] = CAPKEY_DEV_ADDR; // configuration value, no change from default 
  I2CMasterBuffer[1] = ((write_address & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CMasterBuffer[2] = (write_address & 0x00FF);				//REGISTER ADDRESS LSB	
	I2CMasterBuffer[3] = ((value & 0xFF00) >> 8); 				//REGISTER DATA(to Write) MSB
	I2CMasterBuffer[4] = (value & 0x00FF);; 							//REGISTER DATA(to Write) LSB
  I2CCmd = LM75_CONFIG;
//  I2CEngine(); 
}

int Capsence_Read_Register(unsigned long int register_addr)
{
	for ( i = 0; i < BUFSIZE; i++ )	// clear buffer 
  {
	I2CMasterBuffer[i] = 0;
  }
  I2CWriteLength = 2;
  I2CReadLength = 4;
  I2CMasterBuffer[0] = CAPKEY_DEV_ADDR;
  I2CMasterBuffer[1] = ((register_addr & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CMasterBuffer[2] = (register_addr & 0x00FF);				//REGISTER ADDRESS LSB		
  I2CMasterBuffer[3] = CAPKEY_DEV_RD_ADDR;	//CAPKEY_ADDR | RD_BIT;
  I2CCmd = LM75_TEMP;
//  I2CEngine();
}
*/


