
#ifndef __I2C_H 
#define __I2C_H


#define EXTERN_I2C
//#define EXTERN_I2C	extern


EXTERN_I2C void I2Cclk(void);
EXTERN_I2C void I2CPollSlave(unsigned char  SlaveAddr);
EXTERN_I2C void I2CWrByte(unsigned char  Data);
EXTERN_I2C unsigned char I2CRdByte(void);
EXTERN_I2C void I2CContRd(void);
EXTERN_I2C void I2CStopRd(void);
EXTERN_I2C void I2CStopWr(void);
EXTERN_I2C void I2CWaitAck(void);
EXTERN_I2C void WriteTime(void);
EXTERN_I2C void SEND_START(void);
EXTERN_I2C void SCL_HIGH(void);


#endif

