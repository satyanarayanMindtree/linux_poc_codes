#ifndef __MICROSOFT_SANS_SERIF_BOLD_16__
#define __MICROSOFT_SANS_SERIF_BOLD_16__

#include "bitmapfonts.h"

// Font data for Microsoft Sans Serif 16pt
extern const uint8_t microsoftSansSerif_16ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_16ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_16ptDescriptors[];
#endif

