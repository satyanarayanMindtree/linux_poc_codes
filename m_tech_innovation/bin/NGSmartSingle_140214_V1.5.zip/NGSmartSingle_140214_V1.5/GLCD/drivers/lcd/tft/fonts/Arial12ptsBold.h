#ifndef __AERIAL_BOLD_12__
#define __AERIAL_BOLD_12__

#include "bitmapfonts.h"
// Font data for Arial 12pt
extern const uint8_t arial_12ptBitmaps[];
extern const FONT_INFO arial_12ptFontInfo;
extern const FONT_CHAR_INFO arial_12ptDescriptors[];
#endif
