#ifndef __VRINDA_BOLD_20__
#define __VRINDA_BOLD_20__

#include "bitmapfonts.h"
// Font data for Vrinda 20pt
extern const uint8_t vrinda_20ptBitmaps[];
extern const FONT_INFO vrinda_20ptFontInfo;
extern const FONT_CHAR_INFO vrinda_20ptDescriptors[];
#endif

