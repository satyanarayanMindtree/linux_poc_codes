/**************************************************************************/
/*! 
    @file     touchscreen.c
    @author   K. Townsend (microBuilder.eu)

    @section LICENSE

    Software License Agreement (BSD License)

    Copyright (c) 2010, microBuilder SARL
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holders nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**************************************************************************/
#include <stdio.h>
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include "touchscreen.h"
#include "adc.h"
//#include "core/gpio/gpio.h"
//#include "core/systick/systick.h"
//#include "drivers/eeprom/eeprom.h"
#include "../../GLCD/drivers/lcd/tft/lcd.h"
#include "../../GLCD/drivers/lcd/tft/drawing.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusans9.h"
#include "userIntfGLCD.h"
#include "config.h"
#include "type.h"
#include "uart.h"
#include "smartbio.h"
#include "userIntf.h"
#include "access.h"
#include "memory.h"

//#define TS_CALIBRATION_OUTOFRANGE (300)     // Maximum value for calibration
#define TS_CALIBRATION_OUTOFRANGE (0x1a0)     // Maximum value for calibration
//#define TS_CALIBRATION_OUTOFRANGE (0x1a0)     // Maximum value for calibration
#define TS_ADC_LIMIT              (0x03FF)  // 10-bit ADC = 0..1023

#define TS_LINE1                  "Touch the center of"
#define TS_LINE2                  "the red circle using"
#define TS_LINE3                  "a pen or stylus"


//static bool _tsInitialised = FALSE;
//static bool _tsInitialised = TRUE;//to avoid calling of calibrate
//static tsCalibrationData_t _calibration;
typedef unsigned char  BYTE;	 	// 1 byte
extern volatile BYTE KeyBuff[];
extern volatile BYTE KeyWritePtr,KeyReadPtr;

void Delay_X10ms(unsigned int value);
unsigned int	dataX,dataY;
extern struct DOOR_INFO Doorinfo;
/**************************************************************************/
/*                                                                        */
/* ----------------------- Private Methods ------------------------------ */
/*                                                                        */
/**************************************************************************/

/**************************************************************************/
/*!
    @brief  Reads the current Z/pressure level using the ADC
	XP = 1;
	YM = 0;
	read YP, XM
*/
/**************************************************************************/
void tsReadZ(uint32_t* z1, uint32_t* z2)
{
//  if (!_tsInitialised) tsInit();
  if (!Doorinfo.TScalibrated) tsInit();

  // Make sure that X+/Y- are set to GPIO
  TS_XP_FUNC_GPIO();
  TS_YM_FUNC_GPIO();

  // Set X- and Y+ to inputs (necessary?)
  //gpioSetDir (TS_XM_PORT, TS_XM_PIN, 0);
  //gpioSetDir (TS_YP_PORT, TS_YP_PIN, 0);
DIR_IN_TS_XM_PIN();
DIR_IN_TS_YP_PIN();

  // Set X+ and Y- to output
  //gpioSetDir (TS_XP_PORT, TS_XP_PIN, 1);
  //gpioSetDir (TS_YM_PORT, TS_YM_PIN, 1);
DIR_OUT_TS_XP_PIN();
DIR_OUT_TS_YM_PIN();

  // X+ goes low, Y- goes high
//  gpioSetValue(TS_XP_PORT, TS_XP_PIN, 0);   // GND
//  gpioSetValue(TS_YM_PORT, TS_YM_PIN, 1);   // 3.3V
  B_TS_XP(0);
  B_TS_YM(1);

  // Set X- and Y+ to ADC
  TS_XM_FUNC_ADC();  
  TS_YP_FUNC_ADC();  

  // Get ADC results
//	Delay_X10ms(2);
	*z1 = adcRead(TS_YP_ADC_CHANNEL);     // Z1 (Read Y+)
	//Delay_X10ms(2);
	*z2 = adcRead(TS_XM_ADC_CHANNEL);     // Z2 (Read X-)
}

/**************************************************************************/
/*!
    @brief  Reads the current X position using the ADC
	XP=0   //FOR LANDSCAP ORIENTATION.
    XM=1
    READ YP
*/
/**************************************************************************/
uint32_t tsReadX(void)
{
  lcdOrientation_t orientation;
//  if (!_tsInitialised) tsInit();
  if (!Doorinfo.TScalibrated) tsInit();

  orientation = lcdGetOrientation();

  if (orientation == LCD_ORIENTATION_LANDSCAPE)
  {
    // Make sure X+/X- are set to GPIO
    TS_XP_FUNC_GPIO();
    TS_XM_FUNC_GPIO();
  
    // Set Y- and Y+ to inputs
//    gpioSetDir (TS_YM_PORT, TS_YM_PIN, 0);
//    gpioSetDir (TS_YP_PORT, TS_YP_PIN, 0);
	DIR_IN_TS_YM_PIN();
	DIR_IN_TS_YP_PIN();    

    // Set X- and X+ to output
//    gpioSetDir (TS_XM_PORT, TS_XM_PIN, 1);
//    gpioSetDir (TS_XP_PORT, TS_XP_PIN, 1);
	DIR_OUT_TS_XM_PIN();
	DIR_OUT_TS_XP_PIN();
  
    // X+ goes low, X- goes high
//    gpioSetValue(TS_XP_PORT, TS_XP_PIN, 0);   // GND
//    gpioSetValue(TS_XM_PORT, TS_XM_PIN, 1);   // 3.3V
//	B_TS_XP(0);
//	B_TS_XM(1);
	B_TS_XP(1);
	B_TS_XM(0);
  
    // Set pin 0.11 (Y+) to ADC0
    TS_YP_FUNC_ADC();
  
//	Delay_X10ms(2);
    // Return the ADC results
    return adcRead(TS_YP_ADC_CHANNEL);
  }
  else
  {
    // Make sure Y+/Y- are set to GPIO
    TS_YP_FUNC_GPIO();
    TS_YM_FUNC_GPIO();
  
    // Set X- and X+ to inputs
//    gpioSetDir (TS_XM_PORT, TS_XM_PIN, 0);
//    gpioSetDir (TS_XP_PORT, TS_XP_PIN, 0);
	DIR_IN_TS_XM_PIN();
	DIR_IN_TS_XP_PIN();
    
    // Set Y- and Y+ to output
//    gpioSetDir (TS_YM_PORT, TS_YM_PIN, 1);
//    gpioSetDir (TS_YP_PORT, TS_YP_PIN, 1);
	DIR_OUT_TS_YM_PIN();
	DIR_OUT_TS_YP_PIN();
  
    // Y+ goes high, Y- goes low
//    gpioSetValue(TS_YP_PORT, TS_YP_PIN, 1);   // 3.3V
//    gpioSetValue(TS_YM_PORT, TS_YM_PIN, 0);   // GND
//	B_TS_YP(1);
//	B_TS_YM(0);
	B_TS_YP(0);
	B_TS_YM(1);
  
    // Set pin 1.0 (X+) to ADC1
    TS_XP_FUNC_ADC();  
  
    // Return the ADC results
    return adcRead(TS_XP_ADC_CHANNEL);
  }
}

/**************************************************************************/
/*!
    @brief  Reads the current Y position using the ADC
	YP=0   //FOR LANDSCAP ORIENTATION.
    YM=1
    READ XP
*/
/**************************************************************************/
uint32_t tsReadY(void)
{
  lcdOrientation_t orientation;
//  if (!_tsInitialised) tsInit();
  if (!Doorinfo.TScalibrated) tsInit();

  orientation = lcdGetOrientation();

  if (orientation == LCD_ORIENTATION_LANDSCAPE)
  {
    // Make sure Y+/Y- are set to GPIO
    TS_YP_FUNC_GPIO();
    TS_YM_FUNC_GPIO();
  
// Set X- and X+ to inputs
//    gpioSetDir (TS_XM_PORT, TS_XM_PIN, 0);
//    gpioSetDir (TS_XP_PORT, TS_XP_PIN, 0);
	DIR_IN_TS_XM_PIN();
	DIR_IN_TS_XP_PIN();
    
    // Set Y- and Y+ to output
//    gpioSetDir (TS_YM_PORT, TS_YM_PIN, 1);
//    gpioSetDir (TS_YP_PORT, TS_YP_PIN, 1);
	DIR_OUT_TS_YM_PIN();
	DIR_OUT_TS_YP_PIN();
  
    // Y+ goes high, Y- goes low
//    gpioSetValue(TS_YP_PORT, TS_YP_PIN, 1);   // 3.3V
//    gpioSetValue(TS_YM_PORT, TS_YM_PIN, 0);   // GND
//	B_TS_YP(1);
//	B_TS_YM(0);
	B_TS_YP(0);	 //haresh// other wise touch screen works on horizontal mirror image; dont interchange YP and YM in hw file
	B_TS_YM(1);
  
    // Set pin 1.0 (X+) to ADC1
    TS_XP_FUNC_ADC();  
		
//	Delay_X10ms(2);
    // Return the ADC results
    return adcRead(TS_XP_ADC_CHANNEL);
  }
  else
  {
    // Make sure X+/X- are set to GPIO
    TS_XP_FUNC_GPIO();
    TS_XM_FUNC_GPIO();
  
    // Set Y- and Y+ to inputs
//    gpioSetDir (TS_YM_PORT, TS_YM_PIN, 0);
//    gpioSetDir (TS_YP_PORT, TS_YP_PIN, 0);
	DIR_IN_TS_YM_PIN();
	DIR_IN_TS_YP_PIN();    
    
    // Set X- and X+ to output
//    gpioSetDir (TS_XM_PORT, TS_XM_PIN, 1);
//    gpioSetDir (TS_XP_PORT, TS_XP_PIN, 1);
	DIR_OUT_TS_XM_PIN();
	DIR_OUT_TS_XP_PIN();
  
    // X+ goes high, X- goes low
//    gpioSetValue(TS_XP_PORT, TS_XP_PIN, 1);   // 3.3V
//    gpioSetValue(TS_XM_PORT, TS_XM_PIN, 0);   // GND
	B_TS_XP(1);
	B_TS_YM(0);
  
    // Set pin 0.11 (Y+) to ADC0
    TS_YP_FUNC_ADC();
  
    // Return the ADC results
    return adcRead(TS_YP_ADC_CHANNEL);
  }
}

/**************************************************************************/
/*!
    @brief  Converts Z variables into 'pressure' value (0..255)
*/
/**************************************************************************/
uint8_t tsCalculatePressure(uint32_t x, uint32_t z1, uint32_t z2)
{
  // Calculate pressure level
  int32_t t = z2 * x / z1;
  t-=64;
  if (t < 0)
  {
    return 0;
  }
  else if (t > 255)
  {
    return 255;
  }
  else
  {
    return (uint8_t)t;
  }
}

/**************************************************************************/
/*!
    @brief  Centers a line of text horizontally
*/
/**************************************************************************/
void tsCalibCenterText(char* text, uint16_t y, uint16_t color)
{
  drawString((lcdGetWidth() - drawGetStringWidth(&dejaVuSans9ptFontInfo, text)) / 2, y, color, &dejaVuSans9ptFontInfo, (unsigned char*)text);
}

/**************************************************************************/
/*!
    @brief  Renders the calibration screen with an appropriately
            placed test point and waits for a touch event
*/
/**************************************************************************/
void tsRenderCalibrationScreen(uint16_t x, uint16_t y, uint16_t radius)
{
  uint32_t z1, z2;

  drawFill(COLOR_WHITE);
  tsCalibCenterText(TS_LINE1, 50, COLOR_DARKGRAY);
  tsCalibCenterText(TS_LINE2, 65, COLOR_DARKGRAY);
  tsCalibCenterText(TS_LINE3, 80, COLOR_DARKGRAY);
  drawCircle(x, y, radius, COLOR_RED);
  drawCircle(x, y, radius + 2, COLOR_MEDIUMGRAY);

  // Wait for touch
  z1 = z2 = 0;
  while (z2 < CFG_TFTLCD_TS_THRESHOLD) 
    tsReadZ(&z1, &z2);
}

/**************************************************************************/
/*                                                                        */
/* ----------------------- Public Methods ------------------------------- */
/*                                                                        */
/**************************************************************************/

/**************************************************************************/
/*!
    @brief  Initialises the appropriate GPIO pins and ADC for the
            touchscreen
*/
/**************************************************************************/
void tsInit(void)
{
  // Make sure that ADC is initialised
  adcInit();

  // Set initialisation flag
//  _tsInitialised = TRUE;

  // Check if the touch-screen has been calibrated
//  if (eepromReadU8(CFG_EEPROM_TOUCHSCREEN_CALIBRATED) == 1)
//  {
//    // Load calibration data
//    Doorinfo.offsetLeft   = eepromReadU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_LEFT);
//    Doorinfo.offsetRight  = eepromReadU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_RIGHT);
//    Doorinfo.offsetTop    = eepromReadU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_TOP);
//    Doorinfo.offsetBottom = eepromReadU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_BOT);
//    Doorinfo.divisorX     = eepromReadU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_DIVX);
//    Doorinfo.divisorY     = eepromReadU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_DIVY);
//  }
//  else
	if(! Doorinfo.TScalibrated )
  {
		Doorinfo.TScalibrated = TRUE;
    // Start touch-screen calibration
    tsCalibrate();
		
		//write all touch screen related data to flash.
		WriteDoorInfoToFlash();
  }
}

/**************************************************************************/
/*!
    @brief  Starts the screen calibration process.  Each corner will be
            tested, meaning that each boundary (top, left, right and 
            bottom) will be tested twice and the readings averaged.
*/
/**************************************************************************/
void tsCalibrate(void)
{
  lcdOrientation_t orientation;
  uint16_t right2, top2, left2, bottom2,count = 0;
  bool passed = false;

  // Determine screen orientation before starting calibration
  orientation = lcdGetOrientation();

  /* -------------- Welcome Screen --------------- */
  tsRenderCalibrationScreen(lcdGetWidth() / 2, lcdGetHeight() / 2, 5);

  // Delay to avoid multiple touch events
  //systickDelay(250);
#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
#endif	
	Delay_X10ms(25);

  /* -------------- CALIBRATE TOP-LEFT --------------- */
  passed = false;
  while (!passed)
  {
    // Read X/Y depending on screen orientation
    tsRenderCalibrationScreen(lcdGetWidth() - 4, lcdGetHeight() - 4, 5);
    Doorinfo.TSoffsetLeft = orientation == LCD_ORIENTATION_LANDSCAPE ? tsReadY() : tsReadX();
    Doorinfo.TSoffsetTop = orientation == LCD_ORIENTATION_LANDSCAPE ? tsReadX() : tsReadY();
  	Doorinfo.TSoffsetLeft = 240-Doorinfo.TSoffsetLeft;
	Doorinfo.TSoffsetTop = 320-Doorinfo.TSoffsetTop ;  
    // Make sure values are in range
    if (Doorinfo.TSoffsetLeft < TS_CALIBRATION_OUTOFRANGE && Doorinfo.TSoffsetTop < TS_CALIBRATION_OUTOFRANGE)
      passed = true;
#ifdef ENABLE_WATCHDOG
	if(count%15 == 0)
	{	
		count =0;
		WDTFeed();		//Clear watchdog timer
	}
		count++;
#endif	
  }

  // Delay to avoid multiple touch events
  //systickDelay(250);
  	Delay_X10ms(25);
  /* -------------- CALIBRATE BOTTOM-RIGHT  --------------- */
  passed = false;
  while (!passed)
  {
  
    // Read X/Y depending on screen orientation
    tsRenderCalibrationScreen(3, 3+DUMMY_ZONE_HEIGHT, 5);
    Doorinfo.TSoffsetRight = orientation == LCD_ORIENTATION_LANDSCAPE ? TS_ADC_LIMIT - tsReadY() : TS_ADC_LIMIT - tsReadX();
    Doorinfo.TSoffsetBottom = orientation == LCD_ORIENTATION_LANDSCAPE ? TS_ADC_LIMIT - tsReadX() : TS_ADC_LIMIT - tsReadY();
  Doorinfo.TSoffsetRight = 240 - Doorinfo.TSoffsetRight;
	  Doorinfo.TSoffsetBottom = 320-Doorinfo.TSoffsetBottom;
    // Redo test if value is out of range
    if (Doorinfo.TSoffsetRight < TS_CALIBRATION_OUTOFRANGE && Doorinfo.TSoffsetBottom < TS_CALIBRATION_OUTOFRANGE)
      passed = true;
#ifdef ENABLE_WATCHDOG
	if(count%15 == 0)
	{	
		count =0;
		WDTFeed();		//Clear watchdog timer
	}
		count++;
#endif	
  }

  // Delay to avoid multiple touch events
  	Delay_X10ms(25);

  /* -------------- CALIBRATE TOP-RIGHT  --------------- */
  passed = false;
  while (!passed)
  {
    tsRenderCalibrationScreen(3, lcdGetHeight() - 4, 5);
  
    if (orientation == LCD_ORIENTATION_LANDSCAPE)
    {
      right2 = TS_ADC_LIMIT - tsReadY();
      top2 = tsReadX();
    }
    else
    {
      right2 = tsReadX();
      top2 = TS_ADC_LIMIT - tsReadY();
    }
  right2 =  240-right2;
	top2 = 320-top2;
    // Redo test if value is out of range
    if (right2 < TS_CALIBRATION_OUTOFRANGE && top2 < TS_CALIBRATION_OUTOFRANGE)
      passed = true;  
#ifdef ENABLE_WATCHDOG
	if(count%15 == 0)
	{	
		count =0;
		WDTFeed();		//Clear watchdog timer
	}
		count++;
#endif	
  }

  // Average readings
  Doorinfo.TSoffsetRight = (Doorinfo.TSoffsetRight + right2) / 2;
  Doorinfo.TSoffsetTop = (Doorinfo.TSoffsetTop + top2) / 2;

  // Delay to avoid multiple touch events
  	Delay_X10ms(25);

  /* -------------- CALIBRATE BOTTOM-LEFT --------------- */
  passed = false;
  while (!passed)
  {
    tsRenderCalibrationScreen(lcdGetWidth() - 4, 3+DUMMY_ZONE_HEIGHT, 5);
  
    if (orientation == LCD_ORIENTATION_LANDSCAPE)
    {
      left2 = tsReadY();
      bottom2 = TS_ADC_LIMIT - tsReadX();
    }
    else
    {
      left2 = TS_ADC_LIMIT - tsReadX();
      bottom2 = tsReadY();
    }
	left2 = 240-left2;
	bottom2 = 320-bottom2;
  
    // Redo test if value is out of range
    if (left2 < TS_CALIBRATION_OUTOFRANGE && bottom2 < TS_CALIBRATION_OUTOFRANGE)
      passed = true;
#ifdef ENABLE_WATCHDOG
	if(count%15 == 0)
	{	
		count =0;
		WDTFeed();		//Clear watchdog timer
	}
		count++;
#endif	
  }

  // Average readings
  Doorinfo.TSoffsetLeft = (Doorinfo.TSoffsetLeft + left2) / 2;
  Doorinfo.TSoffsetBottom = (Doorinfo.TSoffsetBottom + bottom2) / 2;

  // Delay to avoid multiple touch events
  	Delay_X10ms(25);

  Doorinfo.TSdivisorX = ((TS_ADC_LIMIT - (Doorinfo.TSoffsetLeft + Doorinfo.TSoffsetRight)) * 100) / lcdGetWidth();
  Doorinfo.TSdivisorY = ((TS_ADC_LIMIT - (Doorinfo.TSoffsetTop + Doorinfo.TSoffsetBottom)) * 100) / lcdGetHeight();

  /* -------------- Persist Data --------------- */
//  // Persist data to EEPROM
//  eepromWriteU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_LEFT, _calibration.offsetLeft);
//  eepromWriteU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_RIGHT, _calibration.offsetRight);
//  eepromWriteU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_TOP, _calibration.offsetTop);
//  eepromWriteU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_BOT, _calibration.offsetBottom);
//  eepromWriteU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_DIVX, _calibration.divisorX);
//  eepromWriteU16(CFG_EEPROM_TOUCHSCREEN_OFFSET_DIVY, _calibration.divisorY);
//  eepromWriteU8(CFG_EEPROM_TOUCHSCREEN_CALIBRATED, 1);

  // Clear the screen
  drawFill(COLOR_BLACK);
}

/**************************************************************************/
/*!
    @brief  Causes a blocking delay until a valid touch event occurs

    @note   Thanks to 'rossum' and limor for this nifty little tidbit on
            debouncing the signals via pressure sensitivity (using Z)

    @section Example

    @code 
    #include "drivers/lcd/tft/touchscreen.h"

    // Create an object to hold the eventual event data
    tsTouchData_t data;
    tsTouchError_t error;

    // Cause a blocking delay until a touch event occurs or 5s passes
    error = tsWaitForEvent(&data, 5000);

    if (error)
    {
      switch(error)
      {
        case TS_ERROR_TIMEOUT:
          printf("Timeout occurred %s", CFG_PRINTF_NEWLINE);
          break;
        case TS_ERROR_XYMISMATCH:
          // X/Y double-check failed ... likely a faulty reading
          printf("X/Y mismatch %s", CFG_PRINTF_NEWLINE);
        default:
          break;
      }
    }
    else
    {
      // A valid touch event occurred ... parse data
      if (data.x > 100 && data.x < 200)
      {
        // Do something
        printf("Touch Event: X = %d, Y = %d %s", 
            (int)data.x, 
            (int)data.y, 
            CFG_PRINTF_NEWLINE);
      }
    }

    @endcode
*/
/**************************************************************************/
/*tsTouchError_t tsWaitForEvent(tsTouchData_t* dat, uint32_t timeoutMS)
{
  uint32_t z1, z2;
  uint32_t xRaw1, xRaw2, yRaw1, yRaw2;
  if (!_tsInitialised) tsInit();

  z1 = z2 = 0;

  // Handle timeout if delay > 0 milliseconds
//  if (timeoutMS)
//  {
//    uint32_t startTick = systickGetTicks();
//    // Systick rollover may occur while waiting for timeout
//    if (startTick > 0xFFFFFFFF - timeoutMS)
//    {
//      // Wait for timeout or touch event
//      while (z2 < CFG_TFTLCD_TS_THRESHOLD)
//      {
//        // Throw alert if timeout delay has been passed
//        if ((systickGetTicks() < startTick) && (systickGetTicks() >= (timeoutMS - (0xFFFFFFFF - startTick))))
//        {
//          return TS_ERROR_TIMEOUT;
//        }      
//        tsReadZ(&z1, &z2);
//      }
//    }
//    // No systick rollover will occur ... calculate timeout the simple way
//    else
//    {
//      // Wait in infinite loop
//      while (z2 < CFG_TFTLCD_TS_THRESHOLD)
//      {
//        // Throw timeout if delay has been passed
//        if ((systickGetTicks() - startTick) > timeoutMS)
//        {
//          return TS_ERROR_TIMEOUT;
//        }
//        tsReadZ(&z1, &z2);
//      }
//    }
//  }
//  // No timeout requested ... wait forever
//  else
  {
    while (z2 < CFG_TFTLCD_TS_THRESHOLD)
    {
      tsReadZ(&z1, &z2);
    }
  }

  // Get raw conversion results
  // Each value is read twice and compared to avoid erroneous readings
  xRaw1 = tsReadY();    // X and Y are reversed
  xRaw2 = tsReadY();    // X and Y are reversed
  yRaw1 = tsReadX();    // X and Y are reverse
  yRaw2 = tsReadX();    // X and Y are reverse

  // If both read attempts aren't identical, return mismatch error
  if ((xRaw1 != xRaw2) || (yRaw1 != yRaw2))
  {
    return TS_ERROR_XYMISMATCH;
  }

  // Normalise X
  dat->x = ((xRaw1 - Doorinfo.TSoffsetLeft > TS_ADC_LIMIT ? 0 : xRaw1 - Doorinfo.TSoffsetLeft) * 100) / Doorinfo.TSdivisorX;
  if (dat->x > lcdGetWidth() - 1) dat->x = lcdGetWidth() - 1;

  // Normalise Y
  dat->y = ((yRaw1 - Doorinfo.TSoffsetTop > TS_ADC_LIMIT ? 0 : yRaw1 - Doorinfo.TSoffsetTop) * 100) / Doorinfo.TSdivisorY;
  if (dat->y > lcdGetHeight() - 1) dat->y = lcdGetHeight() - 1;

  // Indicate correct reading
  return TS_ERROR_NONE;
}

extern unsigned int	dataX,dataY;
tsTouchError_t tsWaitForEvent2(uint32_t timeoutMS)
{
  uint32_t z1, z2;
  uint32_t xRaw1, xRaw2, yRaw1, yRaw2;
  if (!_tsInitialised) tsInit();

  z1 = z2 = 0;

  {
    while (z2 < CFG_TFTLCD_TS_THRESHOLD)
    {
      tsReadZ(&z1, &z2);
    }
  }

  // Get raw conversion results
  // Each value is read twice and compared to avoid erroneous readings
  xRaw1 = tsReadY();    // X and Y are reversed
  xRaw2 = tsReadY();    // X and Y are reversed
  yRaw1 = tsReadX();    // X and Y are reverse
  yRaw2 = tsReadX();    // X and Y are reverse

  // If both read attempts aren't identical, return mismatch error
  if ((xRaw1 != xRaw2) || (yRaw1 != yRaw2))
  {
    return TS_ERROR_XYMISMATCH;
  }

  // Normalise X
  dataX = ((xRaw1 - Doorinfo.TSoffsetLeft > TS_ADC_LIMIT ? 0 : xRaw1 - Doorinfo.TSoffsetLeft) * 100) / Doorinfo.TSdivisorX;
  if (dataX > lcdGetWidth() - 1) dataX = lcdGetWidth() - 1;

  // Normalise Y
  dataY = ((yRaw1 - Doorinfo.TSoffsetTop > TS_ADC_LIMIT ? 0 : yRaw1 - Doorinfo.TSoffsetTop) * 100) / Doorinfo.TSdivisorY;
  if (dataY > lcdGetHeight() - 1) dataY = lcdGetHeight() - 1;

  // Indicate correct reading
  return TS_ERROR_NONE;
} */
/**
THIS FUNCTION READ touch screen 
check if touch button is pressed.
	if pressed then highlight that button
	after releasing that button ,that key become non-highlighted and that key is pushed to buffer.
there is nothing like key debounsing here.
*/
char HandleTouchScreenKey(void)
{
  uint32_t z1, z2;//,z3;
  uint32_t xRaw1, xRaw2, yRaw1, yRaw2;
//  if (!_tsInitialised) tsInit();
  if (!Doorinfo.TScalibrated) tsInit();

  z1 = z2 = 0;

    tsReadZ(&z1, &z2);
    if (z2 < CFG_TFTLCD_TS_THRESHOLD)
    {//no touch is found
		if(TouchKeyPad.CurrentSelection != 0)
		{
		//if previously selected menu then push in key buffer
			KeyBuff[KeyWritePtr++] = TouchKeyPad.Keyfunction[TouchKeyPad.CurrentSelection-1];
			if(KeyWritePtr >= 4)
				KeyWritePtr = 0;
			
			//un highlight menu
			UpdateTouchScreen(TouchKeyPad.CurrentSelection,0);
		}
		TouchKeyPad.CurrentSelection = 0 ;
		TouchKeyPad.PreviousSelection = 0 ;
		return TS_ERROR_NOINPUT;
    }

  // Get raw conversion results
  // Each value is read twice and compared to avoid erroneous readings
  xRaw1 = tsReadY();    // X and Y are reversed
  yRaw1 = tsReadX();    // X and Y are reverse
//  tsReadZ(&z1, &z3);    //dummy read to generate delay  ;to remove false triggering
  xRaw2 = tsReadY();    // X and Y are reversed
  yRaw2 = tsReadX();    // X and Y are reverse
//   xRaw1 = tsReadY();    // X and Y are reversed
//   xRaw2 = tsReadY();    // X and Y are reversed
//   yRaw1 = tsReadX();    // X and Y are reverse
//   yRaw2 = tsReadX();    // X and Y are reverse
//	z3=z2;

//   // If both read attempts aren't identical, return mismatch error
//   if ((xRaw1 != xRaw2) || (yRaw1 != yRaw2))
//   {
//     return TS_ERROR_XYMISMATCH;
//   }

// 	//mismatched condition is changed for better touch response
// 	//now we check if two x and two y value differnce are less then 10
//  	if( (xRaw1!=xRaw2) || (yRaw2!=yRaw1) )
//  	{
//  		return TS_ERROR_XYMISMATCH;	
//  	}
	//mismatched condition is changed for better touch response
	//now we check if two x and two y value differnce are less then 10
// 	if( 10 < ((xRaw1>xRaw2)?(xRaw1-xRaw2):(xRaw2-xRaw1)) ||
// 		10 < ((yRaw1>yRaw2)?(yRaw1-yRaw2):(yRaw2-yRaw1)) ||
// 		5 < ((z3>z2)?(z3-z2):(z3-z2)) )
	if( 10 < ((xRaw1>xRaw2)?(xRaw1-xRaw2):(xRaw2-xRaw1)) ||
		10 < ((yRaw1>yRaw2)?(yRaw1-yRaw2):(yRaw2-yRaw1)) )
	{
		return TS_ERROR_XYMISMATCH;	
	}
  // Normalise X
  dataX = ((xRaw1 - Doorinfo.TSoffsetLeft > TS_ADC_LIMIT ? 0 : xRaw1 - Doorinfo.TSoffsetLeft) * 100) / Doorinfo.TSdivisorX;
  if (dataX > lcdGetWidth() - 1) dataX = lcdGetWidth() - 1;

  // Normalise Y
  dataY = ((yRaw1 - Doorinfo.TSoffsetTop > TS_ADC_LIMIT ? 0 : yRaw1 - Doorinfo.TSoffsetTop) * 100) / Doorinfo.TSdivisorY;
  if (dataY > lcdGetHeight() - 1) dataY = lcdGetHeight() - 1;

  // Indicate correct reading -------------------------
#ifndef ROTATE_DISPLAY
	dataX = 320-dataX;
	dataY = 240-dataY;	
#endif
	if(dataY > GRID_ICON1_SECTION_Y0 && dataY < (GRID_ICON5_SECTION_Y0+GRID_ICON_HEIGHT ) && 
		ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)
	{
		//selection is in grid section
		DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;

		if(dataY < GRID_ICON5_SECTION_Y0 )
		{   //in icon 1 to 4
			if(dataX < GRID_ICON2_SECTION_X0)
			{	DisplayData.GridCurrentSelection = 1;	}
			else if(dataX < GRID_ICON3_SECTION_X0)
			{	DisplayData.GridCurrentSelection = 2;	}
			else if(dataX < GRID_ICON4_SECTION_X0)
			{	DisplayData.GridCurrentSelection = 3;	}
			else
			{	DisplayData.GridCurrentSelection = 4;	}
		}
		else
		{//in icon 5 to 8
			if(dataX < GRID_ICON2_SECTION_X0)
			{	DisplayData.GridCurrentSelection = 5;	}
			else if(dataX < GRID_ICON3_SECTION_X0)
			{	DisplayData.GridCurrentSelection = 6;	}
			else if(dataX < GRID_ICON4_SECTION_X0)
			{	DisplayData.GridCurrentSelection = 7;	}
			else
			{	DisplayData.GridCurrentSelection = 8;	}
		}
#ifdef REMOVE_ICON_DELAY
		UpdateGridView();
		//delay for just esthetic reason
	  	Delay_X10ms(50);
#endif
		KeyBuff[KeyWritePtr++] = 12;
		if(KeyWritePtr >= 4)
			KeyWritePtr = 0;
		return TS_ERROR_NONE;

	}
	else if(dataY > TOUCH_KEY_SECTION_Y0)
	{	//todo pixel is in touch screen range

		if( dataX<TOUCH_KEY2_X0 )
		{TouchKeyPad.CurrentSelection = 1;}
		else if( dataX < TOUCH_KEY3_X0 )
		{TouchKeyPad.CurrentSelection = 2;}
		else if( dataX < TOUCH_KEY4_X0 )
		{TouchKeyPad.CurrentSelection = 3;}
		else if( dataX < TOUCH_KEY5_X0 )
		{TouchKeyPad.CurrentSelection = 4;}
		else 
		{TouchKeyPad.CurrentSelection = 5;}
		
		if(TouchKeyPad.PreviousSelection != TouchKeyPad.CurrentSelection)
		{
			if(TouchKeyPad.PreviousSelection != 0)
			{//uh highlight previous menu
				UpdateTouchScreen(TouchKeyPad.PreviousSelection,0);
			}
			//highlight curren menu
			UpdateTouchScreen(TouchKeyPad.CurrentSelection,1);
		}
		TouchKeyPad.PreviousSelection = TouchKeyPad.CurrentSelection ;
	}
    else
	{
		if(TouchKeyPad.CurrentSelection != 0)
		{
			//if previously selected menu then push in key buffer
			KeyBuff[KeyWritePtr++] = TouchKeyPad.Keyfunction[TouchKeyPad.CurrentSelection-1];
			if(KeyWritePtr >= 4)
				KeyWritePtr = 0;

			//un highlight current selection and return
			UpdateTouchScreen(TouchKeyPad.CurrentSelection,0);
			TouchKeyPad.PreviousSelection = 0;
			TouchKeyPad.CurrentSelection = 0;
			return 0;
		}
	}
  return TS_ERROR_NONE;
}
