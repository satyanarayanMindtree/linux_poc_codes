
#ifndef __MICROSOFT_SANS_SERIF_26_POINT_TIME__
#define __MICROSOFT_SANS_SERIF_26_POINT_TIME__

#include "bitmapfonts.h"
// Font data for Microsoft Sans Serif 26pt
extern const uint8_t microsoftSansSerif_26ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_26ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_26ptDescriptors[];

#endif
