#ifndef __VERDANA_MONO_BOLD_12__
#define __VERDANA_MONO_BOLD_12__

#include "bitmapfonts.h"
// Font data for Verdana 12pt
extern const uint8_t verdana_12ptBitmaps[];
extern const FONT_INFO verdana_12ptFontInfo;
extern const FONT_CHAR_INFO verdana_12ptDescriptors[];
#endif
