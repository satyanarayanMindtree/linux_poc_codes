#ifndef __MICROSOFT_SANS_BOLD_12__
#define __MICROSOFT_SANS_BOLD_12__

#include "bitmapfonts.h"
// Font data for Microsoft Sans Serif 12pt
extern const uint8_t microsoftSansSerif_12ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_12ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_12ptDescriptors[];
#endif
