#ifndef __DEJA_VU_SANS_MONO_BOLD_8__
#define __DEJA_VU_SANS_MONO_BOLD_8__

#include "bitmapfonts.h"

extern const uint8_t dejaVuSansMonoBold8ptCharBitmaps[];
extern const FONT_CHAR_INFO dejaVuSansMonoBold8ptCharDescriptors[];
extern const FONT_INFO dejaVuSansMonoBold8ptFontInfo;

#endif

