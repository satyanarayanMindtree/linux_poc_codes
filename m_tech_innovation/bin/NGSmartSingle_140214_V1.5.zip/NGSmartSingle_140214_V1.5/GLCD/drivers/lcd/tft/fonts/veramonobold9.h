#ifndef __VERA_MONO_BOLD_9__
#define __VERA_MONO_BOLD_9__

#include "bitmapfonts.h"

/* Font data for Bitstream Vera Sans Mono Bold 9pt */
extern const uint8_t bitstreamVeraSansMonoBold9ptCharBitmaps[];
extern const FONT_CHAR_INFO bitstreamVeraSansMonoBold9ptCharDescriptors[];
extern const FONT_INFO bitstreamVeraSansMonoBold9ptFontInfo;

#endif

