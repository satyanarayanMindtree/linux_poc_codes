/**************************************************************************/
/*! 
    @file     bmp.c
    @author   K. Townsend (microBuilder.eu)

    @brief    Loads uncomprssed 24-bit windows bitmaps images

    Based on the information available at:
    http://local.wasp.uwa.edu.au/~pbourke/dataformats/bmp/
    and some sample code written by Michael Sweet
	
    @section LICENSE

    Software License Agreement (BSD License)

    Copyright (c) 2010, microBuilder SARL
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holders nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**************************************************************************/
#include <string.h>
#include "config.h"
#include <LPC23xx.h>      // Keil: Register definition file for LPC2378
#include "portdef.h"

#include "bmp.h"

#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "spi.h"
//#include "drivers/lcd/tft/drawing.h"
#include "../../GLCD/drivers/lcd/tft/drawing.h"
//#include "drivers/lcd/tft/lcd.h"
#include "../../GLCD/drivers/lcd/tft/lcd.h"
#include "../../GLCD/BMPImage/sea3_565.h"
#include "userIntfGLCD.h"
#include "../../GLCD/BMPImage/button.h"
#include "../../GLCD/BMPImage/icon.h"
#include "../../GLCD/drivers/lcd/tft/hw/ssd2119_8bit.h"
#include "../../GLCD/drivers/lcd/tft/fonts/veramonobold11.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusanscondensed9.h"
#include "portlcd.h"

#ifdef INSERT_SDCARD
	#include "../../SDCard/fat32.h"
	#include "../../SDCard/SD_routines.h"
#endif
#include "cardmgmt.h"
#include "memory.h"
#include "memmap.h"


extern const unsigned short imageSea3[];
bmp_error_t bmpParseBitmapFromCode(uint16_t x, uint16_t y, const unsigned short image[]);
bmp_error_t bmpParseBitmapFromCodeUpToDown(uint16_t x, uint16_t y,  unsigned short image);
void DisplayBackGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height, unsigned short image);
void SDDisplayBackGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,unsigned char groupno);
void SDDisplaySpecificGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,unsigned char groupno);
extern const unsigned short TouchKeyPosition[][2];
extern const unsigned short GridIconPosition[][2];


// static void Delay(int i)
// {
// while(--i);
// }

// Only include read support if CFG_SDCARD is defined
#ifdef CFG_SDCARD
  #include "drivers/fatfs/diskio.h"
  #include "drivers/fatfs/ff.h"
  static FATFS Fatfs[1];
  #if defined CFG_SDCARD_READONLY && CFG_SDCARD_READONLY == 0
	static FILINFO Finfo;
	static FIL bmpSDFile;
  #endif

/**************************************************************************/
/*                                                                        */
/* ----------------------- Private Methods ------------------------------ */
/*                                                                        */
/**************************************************************************/
// bmp_error_t bmpParseBitmap(uint16_t x, uint16_t y, FIL file)
// {
//   UINT              bytesRead;
//   bmp_header_t      header;
//   bmp_infoheader_t  infoHeader;

//   // Read the file header
//   // ToDo: Optimise this to read buffer once and parse it
//   f_read(&file, &header.type, sizeof(header.type), &bytesRead);
//   f_read(&file, &header.size, sizeof(header.size), &bytesRead);
//   f_read(&file, &header.reserved1, sizeof(header.reserved1), &bytesRead);
//   f_read(&file, &header.reserved2, sizeof(header.reserved2), &bytesRead);
//   f_read(&file, &header.offset, sizeof(header.offset), &bytesRead);

//   // Make sure this is a bitmap (first two bytes = 'BM' or 0x4D42 on little-endian systems)
//   if (header.type != 0x4D42) return BMP_ERROR_NOTABITMAP;

//   // Read the info header
//   // ToDo: Optimise this to read buffer once and parse it
//   f_read(&file, &infoHeader.size, sizeof(infoHeader.size), &bytesRead);
//   f_read(&file, &infoHeader.width, sizeof(infoHeader.width), &bytesRead);
//   f_read(&file, &infoHeader.height, sizeof(infoHeader.height), &bytesRead);
//   f_read(&file, &infoHeader.planes, sizeof(infoHeader.planes), &bytesRead);
//   f_read(&file, &infoHeader.bits, sizeof(infoHeader.bits), &bytesRead);
//   f_read(&file, &infoHeader.compression, sizeof(infoHeader.compression), &bytesRead);
//   f_read(&file, &infoHeader.imagesize, sizeof(infoHeader.imagesize), &bytesRead);
//   f_read(&file, &infoHeader.xresolution, sizeof(infoHeader.xresolution), &bytesRead);
//   f_read(&file, &infoHeader.yresolution, sizeof(infoHeader.yresolution), &bytesRead);
//   f_read(&file, &infoHeader.ncolours, sizeof(infoHeader.ncolours), &bytesRead);
//   f_read(&file, &infoHeader.importantcolours, sizeof(infoHeader.importantcolours), &bytesRead);

//   // Make sure that this is a 24-bit image
//   if (infoHeader.bits != 24) 
//     return BMP_ERROR_INVALIDBITDEPTH;

//   // Check image dimensions
//   if ((infoHeader.width > lcdGetWidth()) | (infoHeader.height > lcdGetHeight()))
//     return BMP_ERROR_INVALIDDIMENSIONS;

//   // Make sure image is not compressed
//   if (infoHeader.compression != BMP_COMPRESSION_NONE) 
//     return BMP_ERROR_COMPRESSEDDATA;

//   // Read 24-bit image data
//   uint32_t px, py;
//   FRESULT res;
//   uint8_t buffer[infoHeader.width * 3];
//   for (py = infoHeader.height; py > 0; py--)
//   {
//     // Read one row at a time
//     res = f_read(&file, &buffer, infoHeader.width * 3, &bytesRead);
//     if (res || bytesRead == 0)
//     {
//       // Error or EOF
//       return BMP_ERROR_PREMATUREEOF;
//     }
//     for (px = 0; px < infoHeader.width; px++)
//     {
//       // Render pixel
//       // ToDo: This is a brutally slow way of rendering bitmaps ...
//       //        update to pass one row of data at a time
//       drawPixel(x + px, y + py - 1, drawRGB24toRGB565(buffer[(px * 3) + 2], buffer[(px * 3) + 1], buffer[(px * 3)]));
//     }
//   }

//   return BMP_ERROR_NONE;
// }

/**************************************************************************/
/*                                                                        */
/* ----------------------- Public Methods ------------------------------- */
/*                                                                        */
/**************************************************************************/

/**************************************************************************/
/*!
    @brief  Loads a 24-bit Windows bitmap image from an SD card and
            renders it

    @section Example

    @code 

    #include "drivers/lcd/tft/bmp.h"

    bmp_error_t error;

    // Draw image.bmp (from the root folder) starting at pixel 0,0
    error = bmpDrawBitmap(0, 0, "/image.bmp");

    // Check 'error' for problems such as BMP_ERROR_FILENOTFOUND

    @endcode
*/
/**************************************************************************/
// bmp_error_t bmpDrawBitmap(uint16_t x, uint16_t y, const char* filename)
// {
//   bmp_error_t error = BMP_ERROR_NONE;
//   DSTATUS stat;
//   BYTE res;

//   stat = disk_initialize(0);

//   if ((stat & STA_NOINIT) || (stat & STA_NODISK))
//   {
//     // Card not initialised or no disk present
//     return BMP_ERROR_SDINITFAIL;
//   }

//   if (stat == 0)
//   {
//     // Try to mount drive
//     res = f_mount(0, &Fatfs[0]);
//     if (res != FR_OK) 
//     {
//       // Failed to mount 0:
//       return BMP_ERROR_SDINITFAIL;
//     }
//     if (res == FR_OK)
//     {
//       // Try to open the requested file
//       FIL imgfile;  
//       if(f_open(&imgfile, filename, FA_READ | FA_OPEN_EXISTING) != FR_OK) 
//       {  
//         // Unable to open the requested file
//         return BMP_ERROR_FILENOTFOUND;
//       }
//       // Try to render the specified image
//       error = bmpParseBitmap(x, y, imgfile);
//       // Close file
//       f_close(&imgfile);
//       // Unmount drive
//       f_mount(0,0);
//        // Return results
//       return error;
//     }
//   }

//   // Return OK signal
//   return BMP_ERROR_NONE;
// }

#if defined CFG_SDCARD_READONLY && CFG_SDCARD_READONLY == 0
/**************************************************************************/
/*!
    @brief  Writes the contents of the LCD screen to a 24-bit bitmap
            images.  CFG_SDCARD_READONLY must be set to '0' to be able
            to use this function.

    @section Example

    @code 

    #include "drivers/lcd/tft/bmp.h"

    bmp_error_t error;

    // Note: The LED stays on while the image is being written since
    //       it can take quite a while to read the entire screen
    //       pixel by pixel and write the data to the SD card

    // Turn the LED on to signal busy state
    gpioSetValue (CFG_LED_PORT, CFG_LED_PIN, CFG_LED_ON); 
    // Write the screen contents to a bitmap image
    error = bmpSaveScreenshot("capture.bmp");
    // Turn the LED off to indicate that the capture is complete
    gpioSetValue (CFG_LED_PORT, CFG_LED_PIN, CFG_LED_OFF); 

    // Check 'error' for problems

    @endcode
*/
/**************************************************************************/
// bmp_error_t bmpSaveScreenshot(const char* filename)
// {
//   DSTATUS stat;
//   bmp_error_t error = BMP_ERROR_NONE;
//   bmp_header_t header;
//   bmp_infoheader_t infoHeader;
//   uint32_t lcdWidth, lcdHeight, x, y, bgra32;
//   UINT bytesWritten;
//   uint16_t rgb565, eof;
//   uint8_t r, g, b;

//   // Create a new file (Crossworks only)
//   stat = disk_initialize(0);
//   if (stat & STA_NOINIT) 
//   {
//     return BMP_ERROR_SDINITFAIL;
//   }
//   if (stat & STA_NODISK) 
//   {
//     return BMP_ERROR_SDINITFAIL;
//   }
//   if (stat == 0)
//   {
//     // SD card sucessfully initialised
//     DSTATUS stat;
//     DWORD p2;
//     WORD w1;
//     BYTE res, b1;
//     DIR dir; 
//     // Try to mount drive
//     res = f_mount(0, &Fatfs[0]);
//     if (res != FR_OK) 
//     {
//       return BMP_ERROR_SDINITFAIL;
//     }
//     if (res == FR_OK)
//     {
//       // Create a file (overwriting any existing file!)
//       if(f_open(&bmpSDFile, filename, FA_READ | FA_WRITE | FA_CREATE_ALWAYS)!=FR_OK) 
//       {  
//         return BMP_ERROR_UNABLETOCREATEFILE; 
//       }
//     }
//   }

//   lcdWidth = lcdGetWidth();
//   lcdHeight = lcdGetHeight();

//   // Create header
//   header.type = 0x4d42;   // 'BM'
//   header.size = (lcdWidth * lcdHeight * 3) + sizeof(header) + sizeof(infoHeader);   // File size in bytes
//   header.reserved1 = 0;
//   header.reserved2 = 0;
//   header.offset = 0x36;   // Offset in bytes to the image data
//   
//   // Create infoheader
//   infoHeader.size = sizeof(infoHeader);
//   infoHeader.width = lcdWidth;
//   infoHeader.height = lcdHeight;
//   infoHeader.planes = 1;
//   infoHeader.bits = 24;
//   infoHeader.compression = BMP_COMPRESSION_NONE;
//   infoHeader.imagesize = (lcdWidth * lcdHeight * 3) + 2;  // 3 bytes per pixel + 2 bytes for EOF
//   infoHeader.xresolution = 0x0B12;
//   infoHeader.yresolution = 0x0B12;
//   infoHeader.ncolours = 0;
//   infoHeader.importantcolours = 0;

//   // Write header to disk
//   f_write(&bmpSDFile, &header.type, sizeof(header.type), &bytesWritten);
//   f_write(&bmpSDFile, &header.size, sizeof(header.size), &bytesWritten);
//   f_write(&bmpSDFile, &header.reserved1, sizeof(header.reserved1), &bytesWritten);
//   f_write(&bmpSDFile, &header.reserved2, sizeof(header.reserved2), &bytesWritten);
//   f_write(&bmpSDFile, &header.offset, sizeof(header.offset), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.size, sizeof(infoHeader.size), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.width, sizeof(infoHeader.width), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.height, sizeof(infoHeader.height), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.planes, sizeof(infoHeader.planes), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.bits, sizeof(infoHeader.bits), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.compression, sizeof(infoHeader.compression), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.imagesize, sizeof(infoHeader.imagesize), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.xresolution, sizeof(infoHeader.xresolution), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.yresolution, sizeof(infoHeader.yresolution), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.ncolours, sizeof(infoHeader.ncolours), &bytesWritten);
//   f_write(&bmpSDFile, &infoHeader.importantcolours, sizeof(infoHeader.importantcolours), &bytesWritten);

//   // Write image data to disk (starting from bottom row)
//   for (y = lcdHeight; y != 0; y--)
//   {
//     for (x = 0; x < lcdWidth; x++)
//     {
//       rgb565 = lcdGetPixel(x, y - 1);               // Get RGB565 pixel
//       bgra32 = drawRGB565toBGRA32(rgb565);          // Convert RGB565 to 24-bit color
//       r = (bgra32 & 0x00FF0000) >> 16;
//       g = (bgra32 & 0x0000FF00) >> 8;
//       b = (bgra32 & 0x000000FF);
//       f_write(&bmpSDFile, &b, 1, &bytesWritten);    // Write RGB data
//       f_write(&bmpSDFile, &g, 1, &bytesWritten);
//       f_write(&bmpSDFile, &r, 1, &bytesWritten);
//     }    
//   }
//   
//   // Write EOF (2 bytes)
//   eof = 0x0000;
//   f_write(&bmpSDFile, &eof, 2, &bytesWritten);

//   // Close the file
//   f_close(&bmpSDFile);

//   // Return OK signal
//   return BMP_ERROR_NONE;
// }
#endif  // End of read-only check to write bitmaps

#endif  // End of CFG_SDCARD check

/**************************************************************************/
/*!
    @brief  Loads a 24-bit Windows bitmap image from an code and
            renders it

    @section Example

    @code 

    #include "drivers/lcd/tft/bmp.h"

    bmp_error_t error;

    // Draw image.bmp (from the root folder) starting at pixel 0,0
    error = bmpDrawBitmap(0, 0, "/image.bmp");

    // Check 'error' for problems such as BMP_ERROR_FILENOTFOUND

    @endcode
*/
/**************************************************************************/
// bmp_error_t bmpDrawBitmap1(uint16_t x, uint16_t y)
// {
//   bmp_error_t error = BMP_ERROR_NONE;
// 	//  DSTATUS stat;
// //  BYTE res;

// //  stat = disk_initialize(0);

// //   if ((stat & STA_NOINIT) || (stat & STA_NODISK))
// //   {
// //     // Card not initialised or no disk present
// //     return BMP_ERROR_SDINITFAIL;
// //   }

// //   if (stat == 0)
// //   {
// //     // Try to mount drive
// //     res = f_mount(0, &Fatfs[0]);
// //     if (res != FR_OK) 
// //     {
// //       // Failed to mount 0:
// //       return BMP_ERROR_SDINITFAIL;
// //     }
// //     if (res == FR_OK)
// //     {
// //       // Try to open the requested file
// //       FIL imgfile;  
// //       if(f_open(&imgfile, filename, FA_READ | FA_OPEN_EXISTING) != FR_OK) 
// //       {  
// //         // Unable to open the requested file
// //         return BMP_ERROR_FILENOTFOUND;
// //       }
//       // Try to render the specified image
// //      error = bmpParseBitmap(x, y, imgfile);
// 		//error = bmpParseBitmapFromCode(x, y, image16);
// //		bmpParseBitmapFromCodeUpToDown(x, y, image16);  //this shown full bk gnd image
// //		Delay(1000);
// //		Delay(1000);
// 		DisplayBackGround(0,0,80,60,image16) ;
// 		DisplayBackGround(160,0,80,60,image16) ;
// 		DisplayBackGround(0,180,80,60,image16) ;
// 		DisplayBackGround(80,60,80,60,image16) ;
// 		DisplayBackGround(80,120,80,60,image16) ;
// 		DisplayBackGround(160,60,80,60,image16) ;
// 		DisplayBackGround(240,180,80,60,image16) ;
// 		DisplayBackGround(240,120,80,60,image16) ;
// 		DisplayBackGround(240,0,80,60,image16) ;
// 		DisplayBackGround(0,120,80,60,image16) ;
// 		DisplayBackGround(160,180,80,60,image16) ;
// 		DisplayBackGround(80,0,80,60,image16) ;
// 		DisplayBackGround(240,60,80,60,image16) ;
// 		DisplayBackGround(80,180,80,60,image16) ;
// 		DisplayBackGround(160,120,80,60,image16) ;
// 		DisplayBackGround(0,60,80,60,image16) ;


// //       // Close file
// //       f_close(&imgfile);
// //       // Unmount drive
// //       f_mount(0,0);
// //        // Return results
//        return error;
// //     }
// //   }

//   // Return OK signal
// //  return BMP_ERROR_NONE;
// }
// bmp_error_t bmpParseBitmapFromCode(uint16_t x, uint16_t y, const unsigned short image[])
// {
// //   UINT              bytesRead;
// //   bmp_header_t      header;
// //   bmp_infoheader_t  infoHeader;
//    //uint32_t px, py;
//    uint32_t  py;

// //   if ((infoHeader.width > lcdGetWidth()) | (infoHeader.height > lcdGetHeight()))
//    if ((BMPWIDTH > lcdGetWidth()) | (BMPHEIGHT > lcdGetHeight()))
//      return BMP_ERROR_INVALIDDIMENSIONS;

// //   // Make sure image is not compressed
// //   if (infoHeader.compression != BMP_COMPRESSION_NONE) 
// //     return BMP_ERROR_COMPRESSEDDATA;

// //   // Read 24-bit image data
// //   FRESULT res;
// //   uint8_t buffer[infoHeader.width * 3];
//    for (py = BMPHEIGHT; py > 0; py--)
//    {
// //     // Read one row at a time
// //     res = f_read(&file, &buffer, infoHeader.width * 3, &bytesRead);
// //     if (res || bytesRead == 0)
// //     {
// //       // Error or EOF
// //       return BMP_ERROR_PREMATUREEOF;
// //     }
// #ifdef SPEED1
//      for (px = 0; px < BMPWIDTH ; px++)
//      {
//        // Render pixel
//        // ToDo: This is a brutally slow way of rendering bitmaps ...
//        //        update to pass one row of data at a time
// //       drawPixel(x + px, y + py - 1, drawRGB24toRGB565(buffer[(px * 3) + 2], buffer[(px * 3) + 1], buffer[(px * 3)]));
// 		 drawPixel(x + px, y + py , image[px+320*py]);
// 	 }
// #endif
// #ifdef SPEED2
// 		 lcdDrawHLineWithBuff(x,BMPWIDTH, y + py ,(uint16_t*)&image[320*py]);//send line buffer
// #endif

//  }

//   return BMP_ERROR_NONE;
// }
// bmp_error_t bmpParseBitmapFromCodeUpToDown(uint16_t x, uint16_t y,unsigned short image)
// {
// 	uint32_t  py;
// //	uint32_t px, py;

// 	if ((BMPWIDTH > lcdGetWidth()) | (BMPHEIGHT > lcdGetHeight()))
// 	 return BMP_ERROR_INVALIDDIMENSIONS;

// //	for (py = BMPHEIGHT; py > 0; py--)
// 	for (py = 0; py < BMPHEIGHT; ++py)
// 	{
// #ifdef SPEED1
// 		for (px = 0; px < BMPWIDTH ; px++)
// 		{
// 			drawPixel(x + px, y + py , (uint16_t)image[px+320*py]);
// 		}
// #endif
// #ifdef SPEED2
// 		lcdDrawHLineWithBuff(x,BMPWIDTH, y + py ,(uint16_t*)&image);//send line buffer
// #endif

// 	}

// 	return BMP_ERROR_NONE;
// }
//this function take 320*240 image as total bkgnd and update sectionof this.
void DisplayBackGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned short image)
{
	uint32_t  py,pixels;
//	uint32_t px, py,pixels;
// 	if ((BMPWIDTH > lcdGetWidth()) | (BMPHEIGHT > lcdGetHeight()))
// 	 return BMP_ERROR_INVALIDDIMENSIONS;
	
	
	
	for (py = y; py < (y+height); ++py)
	{
#ifdef SPEED2
//		lcdDrawHLineWithBuff(x,x+width, py ,(uint16_t*)&image[x+320*py]);//send line buffer  for BMP image
		// without BMP image
		{
			LcdSetCursor(x, py);
			TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
			for(pixels = 0; pixels < width; pixels++)
			{
				TFTWriteData(COLOR_LIGHTGRAY);
			}
		}
#endif
	}
	return ;//BMP_ERROR_NONE;
}
#ifdef INSERT_SDCARD
extern volatile DWORD SPI0Status;
void SDDisplayBackGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,unsigned char groupno)
{
	register int  py,SDbufcounter;
	unsigned int len,startblock;
	//register BYTE dataBuff[2];	
//	register int dataBuff;	
	int response;
	unsigned int retry=0;

	if(groupno == IMAGES_GROUP)
	{	
		len = BLOCKSPERIMAGE;
		startblock = SD_START_BLOCKNO_SD_BMP;
		if(ImageNo>MAX_IMAGES)
		return;
	}
	else if(groupno == ICON_GROUP)
	{	
		len = BLOCKSPERICON;				
		startblock = SD_START_BLOCKNO_ICON;
		if(ImageNo>MAX_ICONNO)
		return;
	}
	ImageNo = ImageNo - 1;			
	guintBlockNum = (startblock + (ImageNo*len)); // 300 beacouse  for single Image we need 300 Block

	SDbufcounter = 0;
			
	// Write the X Start
	TFTWriteCommand(SSD2119_H_RAM_START_REG);
	TFTWriteData( x );
	// Write the X End
	TFTWriteCommand(SSD2119_H_RAM_END_REG);
	TFTWriteData( width + x -1);
	// Write the Y start + end location
	TFTWriteCommand(SSD2119_V_RAM_POS_REG);
	TFTWriteData(y | ((height+y)<<8) );
	// Set the display cursor to the upper left of the rectangle (in application coordinate space).
	TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
	TFTWriteData(x);
	TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
	TFTWriteData(y);
	// Tell the controller we are about to write data into its RAM.
	TFTWriteCommand(SSD2119_RAM_DATA_REG);

	{
		//command to read first byte
		response = SD_sendCommand(READ_MULTIPLE_BLOCKS, guintBlockNum++); 

		if(response != 0x00) return ; //check for SD status: 0x00 - OK (No flags set)

		SET_SD_CS_LOW();

		retry = 0;
		while(SPIReceiveByte() != 0xfe) //wait for start block token 0xfe (0x11111110)
		if(retry++ > 0xfffe){SET_SD_CS_HIGH(); return ;} //return if time-out

		/* wrtie dummy byte out to generate clock, then read data from MISO */
		S0SPDR = 0xFF;
	}
	CLR_CS;
	SET_CD;	
	FIO1MASK = ~PINS_P1_GLCD_DATA;
	for (py = height*width; py >0 ; py--)
	{
		{//wait byte 0 read byte 1
								/* Wait for transfer complete, SPIF bit set */
		#if INTERRUPT_MODE
			/* In the receive routine, there is nothing to be done if TX_DONE, or
			SPI transfer complete bit, is not set, so it's polling if the flag is set 
			or not which is being handled inside the ISR. Not an ideal example but 
			show how the interrupt is being set and handled. */ 
			while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
			SPI0Status &= ~SPI0_TX_DONE;
		#else
			while ( !(S0SPSR & SPIF) );
		#endif
			//dataBuff[0] = S0SPDR;
			GLCD_OUT_LINES = S0SPDR<<GLCD_OUT_LINES_SHIFT;

			//read byte
			/* wrtie dummy byte out to generate clock, then read data from MISO */
			S0SPDR = 0xFF;
			
		}		
	#ifdef INSERT_SDCARD
		//NEW_BYTE_GLCD_OUT(dataBuff[0]);//write byte 0
		SDbufcounter++;
		CLR_WR;
		SET_WR;  // for SD card 

		{
			//wait byte 1 read byte 0 
			/* Wait for transfer complete, SPIF bit set */
#if INTERRUPT_MODE
			while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
			SPI0Status &= ~SPI0_TX_DONE;
#else
			while ( !(S0SPSR & SPIF) );
#endif
			//dataBuff[1] = S0SPDR;
			GLCD_OUT_LINES = S0SPDR<<GLCD_OUT_LINES_SHIFT;

			//read byte
			/* wrtie dummy byte out to generate clock, then read data from MISO */
			S0SPDR = 0xFF;
			
		}		

		//NEW_BYTE_GLCD_OUT(dataBuff[1]);
		SDbufcounter++;
		CLR_WR;
		SET_WR;  // for SD card 
				
		if(SDbufcounter>=512)
		{
		// After 512 byte recive send these command 					
								/* Wait for transfer complete, SPIF bit set */
		#if INTERRUPT_MODE
								while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
								SPI0Status &= ~SPI0_TX_DONE;
		#else
								while ( !(S0SPSR & SPIF) );
		#endif
			//SPIReceiveByte();
			/* wrtie dummy byte out to generate clock, then read data from MISO */
			S0SPDR = 0xFF;
								/* Wait for transfer complete, SPIF bit set */
		#if INTERRUPT_MODE
								while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
								SPI0Status &= ~SPI0_TX_DONE;
		#else
								while ( !(S0SPSR & SPIF) );
		#endif

			//SPIReceiveByte(); //extra 8 clock pulses
			/* wrtie dummy byte out to generate clock, then read data from MISO */
			S0SPDR = 0xFF;
								/* Wait for transfer complete, SPIF bit set */
		#if INTERRUPT_MODE
								while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
								SPI0Status &= ~SPI0_TX_DONE;
		#else
								while ( !(S0SPSR & SPIF) );
		#endif
			{
				//command to read first byte
				retry = 0;
				while(SPIReceiveByte() != 0xfe) //wait for start block token 0xfe (0x11111110)
					if(retry++ > 0xfffe){SET_SD_CS_HIGH(); return ;} //return if time-out

					//read byte
					/* wrtie dummy byte out to generate clock, then read data from MISO */
					S0SPDR = 0xFF;
			}	
			SDbufcounter = 0;
		}
#endif				
	}
	FIO1MASK = 0;
    SET_CS;
#if INTERRUPT_MODE
		while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
		SPI0Status &= ~SPI0_TX_DONE;
#else
		while ( !(S0SPSR & SPIF) );
#endif
		//dataBuff[0] = S0SPDR;

SD_sendCommand(STOP_TRANSMISSION, 0); //command to stop transmission
SET_SD_CS_HIGH();
SPIReceiveByte(); //extra 8 clock pulses
	
	SET_CS;  // for SD card 
	
    // Set the display size and ensure that the GRAM window is set to allow
    // access to the full display buffer.
    TFTWriteCommand(SSD2119_V_RAM_POS_REG);
    TFTWriteData((LCD_VERTICAL_MAX-1) << 8);
    TFTWriteCommand(SSD2119_H_RAM_START_REG);
    TFTWriteData(0x0000);
    TFTWriteCommand(SSD2119_H_RAM_END_REG);
    TFTWriteData(LCD_HORIZONTAL_MAX-1);
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(0x00);
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(0x00);
	return ;//BMP_ERROR_NONE;
}


// This funtion will display specific area from SD - update only specific area in wallpaper 
// void SDDisplaySpecificGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,unsigned char groupno)
// {
// //	unsigned int px, py,pixels,SDbufcounter,temp,len,startblock;
// 	unsigned int  py,pixels,SDbufcounter,len,startblock;
// 	int sblock;
// 		
// 			if(groupno == IMAGES_GROUP)
// 			{	
// 				len = BLOCKSPERIMAGE;
// 				startblock = SD_START_BLOCKNO_SD_BMP;
// 				if(ImageNo>MAX_IMAGES)
// 					return;
// 		  }
// 			else if(groupno == ICON_GROUP)
// 			{	
// 				len = BLOCKSPERICON;				
// 				startblock = SD_START_BLOCKNO_ICON;
// 				if(ImageNo>MAX_ICONNO)
// 					return;
// 		  }
// 				
// 	ImageNo = ImageNo - 1;
// 	
// 	for (py = y; py < (y+height); ++py)
// 	{
// 		sblock = (py*640 +x*2)/512;  //   block no to be read  according to Y
// 		SDbufcounter = (py*640 +x*2)%512;  
// 		guintBlockNum = (startblock + (ImageNo*len)) + (int)sblock;   //actual page no. without offset
// 		SD_NewreadSingleBlock (guintBlockNum++);

// 		LcdSetCursor(x, py);
// 		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 	CLR_CS;
// 	SET_CD;
// 		for(pixels = 0; pixels < width; pixels++)
// 		{
// #ifdef INSERT_SDCARD
// //			TFTWriteByteData(SDbuffer[SDbufcounter++]);
// //			TFTWriteByteData(SDbuffer[SDbufcounter++]);
// 			BYTE_GLCD_OUT(SDbuffer[SDbufcounter++]);
// 			CLR_WR;
// 			SET_WR;  // for SD card 
// 			BYTE_GLCD_OUT(SDbuffer[SDbufcounter++]);
// 			CLR_WR;
// 			SET_WR;  // for SD card 

// 			if(SDbufcounter>=512)
// 			{
// 				SD_NewreadSingleBlock (guintBlockNum++);
// 				SDbufcounter = 0;
// 			}
// #endif				
// 		}
// 	SET_CS;  // for SD card 

// 		}
// 	return ;//BMP_ERROR_NONE;
// }

//	To dispay Icon  
// void SDDisplayIcon(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,unsigned char groupno)
// {
// //	unsigned int  py,pixels,SDbufcounter,len,startblock;
// 	unsigned int  py,SDbufcounter,len,startblock;
// //	unsigned int px, py,pixels,SDbufcounter,temp,len,startblock;
// //	int sblock;

// 		if(groupno == IMAGES_GROUP)
// 			{	
// 				len = BLOCKSPERIMAGE;
// 				startblock = SD_START_BLOCKNO_SD_BMP;
// 				if(ImageNo>MAX_IMAGES)
// 					return;
// 		  }
// 			else if(groupno == ICON_GROUP)
// 			{	
// 				len = BLOCKSPERICON;				
// 				startblock = SD_START_BLOCKNO_ICON;
// 				if(ImageNo>MAX_ICONNO)
// 					return;
// 		  }
// 			else if(groupno == EVENT_ICON_GROUP) 
// 			{	
// 				len = BLOCKSPER_EVENTICON;
// 				startblock = SD_START_BLOCKNO_EVENT_ICON;
// 				if(ImageNo>EVENT_ICON_GROUP)
// 					return;
// 		  }
// 			else {}
// 	
// 	ImageNo = ImageNo - 1;
// 	
// 	guintBlockNum = (startblock + (ImageNo*len));
// 	SDbufcounter = 0;
// 	SD_NewreadSingleBlock(guintBlockNum++);
// 		
// 			// Write the X Start
// 			TFTWriteCommand(SSD2119_H_RAM_START_REG);
// 			TFTWriteData( x );
// 			// Write the X End
// 			TFTWriteCommand(SSD2119_H_RAM_END_REG);
// 			TFTWriteData( width + x -1);
// 			// Write the Y start + end location
// 			TFTWriteCommand(SSD2119_V_RAM_POS_REG);
// 			TFTWriteData(y | ((height+y)<<8) );
// 			// Set the display cursor to the upper left of the rectangle (in application coordinate space).
// 			TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
// 			TFTWriteData(x);
// 			TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
// 			TFTWriteData(y);
// 			// Tell the controller we are about to write data into its RAM.
// 			//
// 			TFTWriteCommand(SSD2119_RAM_DATA_REG);

// 		CLR_CS;
// 		SET_CD;
// 		for(py = 0; py < height*width; ++py)
// 		{
// #ifdef INSERT_SDCARD
// //			TFTWriteByteData(SDbuffer[SDbufcounter++]);
// //			TFTWriteByteData(SDbuffer[SDbufcounter++]);
// 				BYTE_GLCD_OUT(SDbuffer[SDbufcounter++]);
// 				CLR_WR;
// 				SET_WR;  // for SD card 
// 				BYTE_GLCD_OUT(SDbuffer[SDbufcounter++]);
// 				CLR_WR;
// 				SET_WR;  // for SD card 

// 			if(SDbufcounter>=512)
// 			{
// 				SD_NewreadSingleBlock (guintBlockNum++);
// 				SDbufcounter = 0;
// 			}
// #endif				
// 		}
// 		SET_CS;  // for SD card 

//     // Set the display size and ensure that the GRAM window is set to allow
//     // access to the full display buffer.
//     TFTWriteCommand(SSD2119_V_RAM_POS_REG);
//     TFTWriteData((LCD_VERTICAL_MAX-1) << 8);
//     TFTWriteCommand(SSD2119_H_RAM_START_REG);
//     TFTWriteData(0x0000);
//     TFTWriteCommand(SSD2119_H_RAM_END_REG);
//     TFTWriteData(LCD_HORIZONTAL_MAX-1);
//     TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
//     TFTWriteData(0x00);
//     TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
//     TFTWriteData(0x00);
// 	return ;//BMP_ERROR_NONE;
// }

#endif

//this function display specified size of BMP on specified location
//uint16_t x, uint16_t = start location of coordinate to show BMP
//uint16_t width, uint16_t height = size of source BMP
// void DisplayBmp(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned short image[])
// {
// //	uint32_t px, py;
// 	uint32_t  py;
// 	for (py = 0; py < (height); ++py)
// 	{
// #ifdef SPEED2
// 		lcdDrawHLineWithBuff(x,x+width, py+y ,(uint16_t*)&image[width*py]);//send line buffer
// #endif
// 	}
// //	return BMP_ERROR_NONE;
// }
/**
this function draw any size bitmap,
it takes "const unsigned short TransparentColor" this as transparent color i.e. back gnd is shown
there is scope of optimisation using window...
*/
// void DisplayBmpTransparent(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned short image[],const unsigned short TransparentColor)
// {
// 	uint32_t px, py;
// 	for (py = 0; py < height; ++py)
// 	{
// // #ifdef SPEED2
// // 		lcdDrawHLineWithBuff(x,x+width, py+y ,&image[width*py]);//send line buffer
// // #endif
// 		for (px = 0; px < width ; px++)
// 		{
// 			if(image[px+width*py] != TransparentColor)    //display only non transparent color
// 				drawPixel(x + px, y + py , image[px+width*py]);
// 		}
// 	}
// //	return BMP_ERROR_NONE;
// }
void DisplayIcon(unsigned char iconPos,unsigned char iconNo,unsigned char select)
{
//	struct RectInfo rectinfo;
	extern SYSInfo SysInfo;
	iconPos -=1;
	iconNo -= 1;
	if(select == 0)
	{   //
// 		DisplayBmpTransparent(	GridIconPosition[iconPos-1][XPOS],
// 								GridIconPosition[iconPos-1][YPOS],
// 								GRID_ICON_WIDTH,
// 								GRID_ICON_HEIGHT,
// 								icon3,
// 								COLOR_BLACK);
// 		DisplayBmp1Bit(	GridIconPosition[iconPos][XPOS],
// 						GridIconPosition[iconPos][YPOS],
// 						GRID_ICON_WIDTH,
// 						GRID_ICON_HEIGHT,
// 						GridIconDataArray[iconNo],
// 						GridIconNormalPaletteArray[iconNo]);
				
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;
// 				rectinfo.Hight = GRID_ICON_HEIGHT;
// 				rectinfo.Width = GRID_ICON_WIDTH;
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo, GridIconPosition[iconPos][XPOS], GridIconPosition[iconPos][YPOS]);		
#ifdef INSERT_SDCARD
				SDDisplayBackGround(GridIconPosition[iconPos][XPOS],   
										GridIconPosition[iconPos][YPOS],
										GRID_ICON_WIDTH,
										GRID_ICON_HEIGHT,
										iconNo+1+8,ICON_GROUP);
#endif										
	}
	else
	{   //highlighted
// 		DisplayBmp1Bit(	GridIconPosition[iconPos][XPOS],
// 						GridIconPosition[iconPos][YPOS],
// 						GRID_ICON_WIDTH,
// 						GRID_ICON_HEIGHT,
// 						GridIconDataArray[iconNo],
// 						GridIconHighlightPaletteArray[iconNo]);
		
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TitleMSGBackgroundColour;
// 				rectinfo.Hight = GRID_ICON_HEIGHT;
// 				rectinfo.Width = GRID_ICON_WIDTH;
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo, GridIconPosition[iconPos][XPOS], GridIconPosition[iconPos][YPOS]);		
#ifdef INSERT_SDCARD		
			SDDisplayBackGround(GridIconPosition[iconPos][XPOS],
										GridIconPosition[iconPos][YPOS],
										GRID_ICON_WIDTH , 
										GRID_ICON_HEIGHT ,
										iconNo+1,ICON_GROUP);
#endif		
	}
} 

void DisplayIconWithName(unsigned char iconPos,unsigned char iconNo,unsigned char select,char* text)
{
	extern unsigned char DisplayTempBuffer[50];
	unsigned char temp1;
	extern SYSInfo SysInfo;
//	struct RectInfo rectinfo;
	iconPos -=1;
	iconNo -= 1;
	
	sprintf((char*)DisplayTempBuffer,"%s",text);
																	
	temp1 = GridIconPosition[iconPos+8][XPOS];
		
	if(select == 0)
	{   
// 		DisplayBmp1Bit(	GridIconPosition[iconPos][XPOS],
// 						GridIconPosition[iconPos][YPOS],
// 						GRID_ICON_WIDTH,
// 						GRID_ICON_HEIGHT,
// 						GridIconDataArray[iconNo],
// 						GridIconNormalPaletteArray[iconNo]);
#ifdef INSERT_SDCARD		
		SDDisplayBackGround(GridIconPosition[iconPos][XPOS],
										GridIconPosition[iconPos][YPOS],
										GRID_ICON_WIDTH,
										GRID_ICON_HEIGHT,
										iconNo+1+8,ICON_GROUP);
#endif		
	}
	else
	{   //highlighted
// 		DisplayBmp1Bit(	GridIconPosition[iconPos][XPOS],
// 						GridIconPosition[iconPos][YPOS],
// 						GRID_ICON_WIDTH,
// 						GRID_ICON_HEIGHT,
// 						GridIconDataArray[iconNo],
// 						GridIconHighlightPaletteArray[iconNo]);
#ifdef INSERT_SDCARD		
		SDDisplayBackGround(GridIconPosition[iconPos][XPOS],
										GridIconPosition[iconPos][YPOS],
										GRID_ICON_WIDTH,
										GRID_ICON_HEIGHT,
										iconNo+1,ICON_GROUP);		
#endif		
	}
	
	//draw center string.	
	drawStringWithBackground( temp1 + ((GRIDICON_NAME_STRWIDTH) - drawGetStringWidth(FONT_ICON_NAME, DisplayTempBuffer)) / 2, //x  Time
						GridIconPosition[iconPos+8][YPOS],	    //y
						COLOR_BLACK,      //color
						FONT_ICON_NAME,       //font
						(unsigned char*)DisplayTempBuffer,
						ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour);  //string
} 

/**
this function is created to show boot screen logo
logo will be dispolayed like comming from whitish screen to actual color.
function is not completed yet.
*/
// void SDDisplayAnimatedSpecificGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,uint16_t BackColor)
// {
// 	unsigned int px, py,pixels,SDbufcounter,temp1,temp2,r,g,b;
// 	int sblock;
// 	
// 	ImageNo = ImageNo - 1;
// 	
// 	for (py = y; py < (y+height); ++py)
// 	{
// 		sblock = (py*640 +x*2)/512;  //   block no to be read  according to Y
// 		SDbufcounter = (py*640 +x*2)%512;  
// 		guintBlockNum = (SD_START_BLOCKNO_SD_BMP + (ImageNo*300)) + (int)sblock;   //actual page no. without offset
// 		SD_readSingleBlock (guintBlockNum++);

// 		for(pixels = 0; pixels < width; pixels++)
// 		{
// #ifdef INSERT_SDCARD
// 			temp1=SDbuffer[SDbufcounter++];
// 			temp2=SDbuffer[SDbufcounter++];
// 			
// 			if(temp1!=0xff || temp2!=0xff)
// 			{
// 				LcdSetCursor(pixels+x, py);
// 				TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 				TFTWriteByteData(temp1);
// 				TFTWriteByteData(temp2);
// 			}
// 			if(SDbufcounter>=512)
// 			{
// 				SD_readSingleBlock (guintBlockNum++);
// 				SDbufcounter = 0;
// 			}
// #endif				
// 		}
// 	}
// 	return ;//BMP_ERROR_NONE;
// }
/**
this function draw any size bitmap of 2 bit resolution,
it takes array of image and pallete array
uint16_t x=start location of icon
uint16_t y==start location of icon
uint16_t width=weidth of icon       **width must be multiple of 4.
uint16_t height=weidth of icon
const unsigned short image[]=array of image bitmap
const unsigned short pallete[]=array of pallete
*/
// void DisplayBmp2Bit(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned char image[],const unsigned char Pallete[])
// {
// 	uint32_t px, py,temp;
// 	for (py = 0; py < height; ++py)
// 	{
// 		LcdSetCursor(x, y+py);
// 		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 		for (px = 0; px < width ; )
// 		{
// 			temp = (*image & 0xC0)>>6;
// 			//drawPixel(x + px++, y + py , Pallete[temp]);
// 			temp *= 2;
// 			TFTWriteByteData(Pallete[temp]);
// 			TFTWriteByteData(Pallete[temp+1]);
// 			
// 			temp = (*image & 0x30)>>4;
// 			temp *= 2;
// 			TFTWriteByteData(Pallete[temp]);
// 			TFTWriteByteData(Pallete[temp+1]);

// 			temp = (*image & 0x0C)>>2;
// 			temp *= 2;
// 			TFTWriteByteData(Pallete[temp]);
// 			TFTWriteByteData(Pallete[temp+1]);

// 			temp = (*image & 0x03);
// 			temp *= 2;
// 			TFTWriteByteData(Pallete[temp]);
// 			TFTWriteByteData(Pallete[temp+1]);

// 			image++;
// 			px += 4;
// 		}
// 	}
// //	return BMP_ERROR_NONE;
// }
/**
this function draw any size bitmap of 2 bit resolution,
it takes array of image and pallete array
uint16_t x=start location of icon
uint16_t y==start location of icon
uint16_t width=weidth of icon       **width must be multiple of 4.
uint16_t height=weidth of icon
const unsigned short image[]=array of image bitmap
const unsigned short pallete[]=array of pallete

*/
void DisplayBmp1Bit(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned char image[],const unsigned char Pallete[])
{
	uint32_t px, py,temp;
	for (py = 0; py < height; ++py)
	{
		LcdSetCursor(x, y+py);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
		for (px = 0; px < width ; )
		{
			temp = (*image & 0x80)>>7;
			//drawPixel(x + px++, y + py , Pallete[temp]);
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);
			
			temp = (*image & 0x40)>>6;
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			temp = (*image & 0x20)>>5;
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			temp = (*image & 0x10)>>4;
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			temp = (*image & 0x08)>>3;
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			temp = (*image & 0x04)>>2;
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			temp = (*image & 0x02)>>1;
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			temp = (*image & 0x01);
			temp *= 2;
			TFTWriteByteData(Pallete[temp]);
			TFTWriteByteData(Pallete[temp+1]);

			image++;
			px += 8;
		}
	}
//	return BMP_ERROR_NONE;
}
//this function displays rgb colors 5,5,5 bits resolution on display
void DrawFullColors(void)
{
	unsigned short height,width,color;
	unsigned char r,g,b;
	for(height=0;height<50;++height)
	{
		LcdSetCursor(0,height);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
		r=31;g=0;b=0;
		for(width=0;width<32;++width)
		{
			color = r*32*32*2 + g*2*32 + b;
			TFTWriteData(color);
			g += 1;
		}

	    drawLine(32, 0, 32, 240, 0);
		LcdSetCursor(33,height);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)

		g=31;
		for(width=0;width<32;++width)
		{
			color = r*32*32*2 + g*2*32 + b;
			TFTWriteData(color);
			r -= 1;
		}

	    drawLine(65, 0, 65, 240, 0);
		LcdSetCursor(66,height);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)

		r=0;
		for(width=0;width<32;++width)
		{
			color = r*32*32*2 + g*2*32 + b;
			TFTWriteData(color);
			b += 1;
		}

	    drawLine(99, 0, 99, 240, 0);
		LcdSetCursor(100,height);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)

		b=31;
		for(width=0;width<32;++width)
		{
			color = r*32*32*2 + g*2*32 + b;
			TFTWriteData(color);
			g-=1;
		}

	    drawLine(133, 0, 133, 240, 0);
		LcdSetCursor(134,height);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)

		g=0;
		for(width=0;width<32;++width)
		{
			color = r*32*32*2 + g*2*32 + b;
			TFTWriteData(color);
			r += 1;
		}

	    drawLine(167, 0, 167, 240, 0);
		LcdSetCursor(168,height);
		TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)

		r=31;
		for(width=0;width<32;++width)
		{
			color = r*32*32*2 + g*2*32 + b;
			TFTWriteData(color);
			b -= 1;
		}
	}
}
