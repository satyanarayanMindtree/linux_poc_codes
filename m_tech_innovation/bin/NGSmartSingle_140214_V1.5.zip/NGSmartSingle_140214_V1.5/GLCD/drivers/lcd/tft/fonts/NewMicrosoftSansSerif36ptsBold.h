#ifndef __MICROSOFT_SANS_SERIF_36_POINT___
#define __MICROSOFT_SANS_SERIF_36_POINT___

#include "bitmapfonts.h"
// Font data for Microsoft Sans Serif 36pt
extern const uint8_t microsoftSansSerif_36ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_36ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_36ptDescriptors[];
#endif

