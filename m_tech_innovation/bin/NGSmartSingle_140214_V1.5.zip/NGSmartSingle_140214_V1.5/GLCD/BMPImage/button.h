

/*
 * BMP image data converted from 24bpp
 * to RGB565
 * Red and green data swapped
 */

#define BUTTON_COLOR_BPP          16
#define BUTTON_COLOR_STORAGE_SIZE 2
#define BUTTON_BMPWIDTH           62;
#define BUTTON_BMPHEIGHT          48;

extern const unsigned short btnNormal[] ;
extern const unsigned short btnPressed[] ;
extern const unsigned short FourClrBmp[] ;

