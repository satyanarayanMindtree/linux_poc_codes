/*******************************************************
FileName: NewSdmain.h
Author:Creative
Description: 
********************************************************/
#ifndef __NEWSDMAIN_H__
#define __NEWSDMAIN_H__

#include "stdio.h"

#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (1)
#endif

//#define DEBUG_EN

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

//extern void Delay (u32 lulDelayCnt);
extern u8 gaucDebDuf[100];
#define TX_NEWLINE {TransmitChar(0x0d); TransmitChar(0x0a);}
#endif  /* __TYPE_H__ */
/*--------------------------File Ends----------------------------*/
