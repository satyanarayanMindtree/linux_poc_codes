/*****************************************************************************
 *   spi.c:  SPI C file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.19  ver 1.00    Prelimnary version, first Release
 *
*****************************************************************************/
#include "LPC23XX.H"                        /* LPC23xx definitions */
#include "spi.h"

volatile DWORD SPI0Status = 0;
volatile DWORD TxCounter = 0;
//extern BYTE SBuffer[BUFSIZE];
//BYTE SPIWRData[SPIBUFSIZE];
BYTE SPIRDData[2];
 


/*****************************************************************************
** Function name:		SPI0Handler
**
** Descriptions:		SPI0 interrupt handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void SPI0Handler (void) __irq 
{
  DWORD regValue;
  
  S0SPINT = SPI0_INT_FLAG;		/* clear interrupt flag */
  IENABLE;				/* handles nested interrupt */

  regValue = S0SPSR;
  if ( regValue & WCOL )
  {
	SPI0Status |= SPI0_COL;
  }
  if ( regValue & SPIF )
  {
	SPI0Status |= SPI0_TX_DONE;
	TxCounter++;
  }
  IDISABLE;
  VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		SPIInit
**
** Descriptions:		SPI port initialization routine
**				
** parameters:			None
** Returned value:		true or false, if the interrupt handler
**				can't be installed correctly, return false.
** 
*****************************************************************************/
DWORD SPIInit( void )
{
  TxCounter = 0;

  PCONP |= (1 << 8);	/* by default, it's enabled already, for safety reason */

  S0SPCR = 0x00;
 
 /* Port 0.15 SPI SCK, port0.16 uses GPIO SPI_SEL, 
  port0.17 MISO, port0.18 MOSI */
  PINSEL0 |= 0xC0000000;
  PINSEL1 |= 0x0000003C;

  FIO0DIR |= SPI0_SEL|SPI1_SEL;		 //Fast GPIO Port Direction control register
  FIO0CLR |= SPI0_SEL;
  FIO0SET |= SPI0_SEL;
//for flash2
//  FIO0DIR |= SPI1_SEL;		 //Fast GPIO Port Direction control register
  FIO0CLR |= SPI1_SEL;		 //Fast Port Output Clear register
  FIO0SET |= SPI1_SEL;		 //Fast Port Output Set register

// // For SD Card 	
//   FIO4DIR |= SD_SPI_SEL;		 //Fast GPIO Port Direction control register
//   FIO4CLR |= SD_SPI_SEL;		 //Fast Port Output Clear register
//   FIO4SET |= SD_SPI_SEL;		 //Fast Port Output Set register
	
//  IODIR0 |= SPI0_SEL;
//  IOCLR0 |= SPI0_SEL;
//  IOSET0 |= SPI0_SEL;
//  S0PTCR =   0x0000000E; //testing SPI clk 

  /* Setting SPI0 clock, for Atmel SEEPROM, SPI clock should be no more 
  than 3Mhz on 4.5V~5.5V, no more than 2.1Mhz on 2.7V~5.5V */
  S0SPCCR = 0x8;
#if INTERRUPT_MODE
  if ( install_irq( SPI0_INT, (void *)SPI0Handler, HIGHEST_PRIORITY ) == FALSE )
  {
	return (FALSE);
  }
  /* 8 bit, CPOL=CPHA=0, master mode, MSB first, interrupt enabled */
  S0SPCR = SPI0_SPIE | SPI0_MSTR ;
#else
  S0SPCR = SPI0_MSTR;
#endif
  return( TRUE );
}

/*****************************************************************************
** Function name:		SPISend
**
** Descriptions:		Send a block of data to the SPI port, the first
**				parameter is the buffer pointer, the 2nd 
**				parameter is the block length.
**
** parameters:			buffer pointer, and the block length
** Returned value:		None
** 
*****************************************************************************/
void SPISend( BYTE *buf,DWORD Length )
{
DWORD i;
//BYTE Dummy;
  //this is used for command adjustment MSB byte of cammand first.
  if(Length <= 8)
  		buf= buf+3;
  if ( Length == 0 )
	return;
  for ( i = 0; i < Length; i++ )    
  {	//	MsgPrint(MSG_MEM,i," ");	    		used for debug	
	//	MsgPrint(MSG_MEM,*buf,"FLASH SPI ");	used for debug    


	S0SPDR = *buf ;
#if INTERRUPT_MODE
	/* In the interrupt, there is nothing to be done if TX_DONE, SPI transfer 
	complete bit, is not set, so it's polling if the flag is set or not which 
	is being handled inside the ISR. Not an ideal example but show how the 
	interrupt is being set and handled. */ 
	while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
	SPI0Status &= ~SPI0_TX_DONE;
#else
	while ( !(S0SPSR & SPIF) );
#endif
	
//	Dummy = S0SPDR;		/* Read receive data from RxFIFO */
//this is used for command adjustment MSB byte of cammand first.
   if(Length <= 8)
	  buf--;
   else
   	  buf++;
  }
  
  return; 
}


/*****************************************************************************
** Function name:		SPIReceive
** Descriptions:		the module will receive a block of data from 
**				the SPI, the 2nd parameter is the block length.
** parameters:			buffer pointer, and block length
** Returned value:		None
** 
*****************************************************************************/
void SPIReceive( BYTE *buf, DWORD Length )
{
  DWORD i;
  
  for ( i = 0; i < Length; i++ )
  {
	*buf = SPIReceiveByte();
	buf++;
  }
 
  return; 
}

/*****************************************************************************
** Function name:		SPIReceiveContinues
** Descriptions:		the module will receive byte by byte of data from 
**				the SPI, the 2nd parameter is the block length.
** parameters:			buffer pointer, and block length,and data to be matched.
** Returned value:		True/False for matched data.
** 
*****************************************************************************/
short SPIReceiveCont( BYTE *buf, DWORD Length, BYTE *Crdptr )
{
  DWORD i;
  
  for ( i = 0; i < Length; i++ )
  {
	*buf = SPIReceiveByte();
	buf++;
  }
 
  return(0); 
}

/*****************************************************************************
** Function name:		SPIReceiveByte
**
** Descriptions:		Receive one byte of data from the SPI port
**				Write a dummy byte, wait until SPI transfer
**				complete, then, read the data register to
**				get the SPI data.
**
** parameters:			None
** Returned value:		the data byte received
** 
*****************************************************************************/
BYTE SPIReceiveByte( void )
{
  BYTE data;

  /* wrtie dummy byte out to generate clock, then read data from MISO */
  S0SPDR = 0xFF;
  /* Wait for transfer complete, SPIF bit set */
#if INTERRUPT_MODE
  /* In the receive routine, there is nothing to be done if TX_DONE, or
  SPI transfer complete bit, is not set, so it's polling if the flag is set 
  or not which is being handled inside the ISR. Not an ideal example but 
  show how the interrupt is being set and handled. */ 
  while ( (SPI0Status & SPI0_TX_DONE) != SPI0_TX_DONE );
  SPI0Status &= ~SPI0_TX_DONE;
#else
  while ( !(S0SPSR & SPIF) );
#endif
  data = S0SPDR;
  return ( data ); 
}
/*****************************************************************************
** Function name:		Main menory page read
**
** Descriptions:		Reads Main memory page directly with out affecting 
**				spi internal buf1,buff2.
**				
**				
**
** parameters:			11 bit page address and 9 bit buff start address.
** Returned value:		the data byte received
** 
*****************************************************************************/

void MainMem_ReadPage(WORD pageadd,WORD Bufadd,BYTE *buf,WORD Length)
{   unsigned int Command;
	
//	FIO0CLR |= SPI0_SEL;
	FIO0CLR |= SPI1_SEL;
  	Command = 0;
	Command |= Main_MemPage_Rd;
	Command |= pageadd<<SF_BUFFADD;
	Command	|= (Bufadd & SF_PAGEADD);
  	SPISend( (BYTE *)&Command,8 );
	if(Length < 8)				//	This adjustment for command and data 
		Length = 9;
	SPIReceive( (BYTE *)buf,Length);
//	FIO0SET |= SPI0_SEL;
	FIO0SET |= SPI1_SEL;
    Command = 0;


}	 
/*****************************************************************************
** Function name:		Flash Buffer  Write
**
** Descriptions:		either buffer 1 or buffer 2. To load data into the 
DataFlash standard buffer (264 bytes), a 1-byte opcode, 84H for buffer 1 
or 87H for buffer 2,must be clocked into the device, followed by three 
address bytes comprised of 15 don�t care bits and 9 buffer address 
bits (BFA8 - BFA0). The 9 buffer address bits specify the first byte in the
buffer to be written.
**
** parameters:			None
** Returned value:		the data byte received
** 
*****************************************************************************/

void MainMem_BuffWrt( WORD Bufadd,WORD Bufno,BYTE *buf,WORD Length )
{	unsigned int Command;
//	FIO0CLR |= SPI0_SEL;
	FIO0CLR |= SPI1_SEL;
	Command = 0;
	if(Bufno == 1)
		Command |= Buf1_Wrt;
	else if(Bufno == 2)
		Command |= Buf2_Wrt;
	Command	|= (Bufadd & SF_PAGEADD);
	SPISend( (BYTE *)&Command,4 );
	if(Length < 8)				//	This adjustment for command and data 
		Length = 9;
   	SPISend( (BYTE *)buf, Length );
//	FIO0SET |= SPI0_SEL;
	FIO0SET |= SPI1_SEL;

}
/*****************************************************************************
** Function name:		Flash to Buffer  Write
**
** Descriptions:		either buffer 1 or buffer 2. To load data into the 
DataFlash standard buffer (264 bytes), a 1-byte opcode, 53H for buffer 1 
or 55H for buffer 2,must be clocked into the device, followed by three 
address bytes comprised of 15   page address bits and 9 dont care
bits (BFA8 - BFA0). 
**
** parameters:			page no 
** Returned value:		the data byte received
** 
*****************************************************************************/

void MainMem_ToBuff( WORD Pageadd,WORD Bufno)
{	unsigned int Command;
//	FIO0CLR |= SPI0_SEL;
	FIO0CLR |= SPI1_SEL;
	Command = 0;
	if(Bufno == 1)
		Command |= Main_MemPage_ToBuf1;
	else if(Bufno == 2)
		Command |= Main_MemPage_ToBuf2;
	Command	|= Pageadd<<SF_BUFFADD;
	SPISend( (BYTE *)&Command,4 );
//	FIO0SET |= SPI0_SEL;
	FIO0SET |= SPI1_SEL;
	SPI_Status();

}		
/*****************************************************************************
** Function name:		Buffer to Main Memory Page Program with Built-in Erase
**
** Descriptions:		Data written into either buffer 1 or buffer 2 can be programmed 
into the main memory. A 1-byte opcode, 83H for buffer 1 or 86H for buffer 2, 
must be clocked into the device. For the DataFlash standard page size (264 bytes),
**
** parameters:			page address and buffno
** Returned value:		none
** 
*****************************************************************************/

void BuffWrt_MainMem( WORD pageadd,WORD Bufadd)
{
 	unsigned int Command;
//	FIO0CLR |= SPI0_SEL;
	FIO0CLR |= SPI1_SEL;
	Command = 0;
	if(Bufadd == 1)
		Command |= Buf1_ToMemPage;
	else if(Bufadd ==2)
		Command |= Buf2_ToMemPage;
	Command |= pageadd<<SF_BUFFADD;
  	SPISend((BYTE *)&Command,4);
//	FIO0SET |= SPI0_SEL;
	FIO0SET |= SPI1_SEL;
	SPI_Status();

}
   
/*****************************************************************************
** Function name:		Device ID
**
** Descriptions:	   Return device ID
**
** parameters:			 
** Returned value:		Device ID
** 
*****************************************************************************/
 
void SPI_DeviceID(BYTE *buf)
{	unsigned int Command;
//	FIO0CLR |= SPI0_SEL;	
	FIO0CLR |= SPI1_SEL;	
	Command = 0;
	Command |= Manuf_DevID_Rd;
  	SPISend( (BYTE *)&Command,1 );
	SPIReceive( (BYTE *)buf,4 );
//	FIO0SET |= SPI0_SEL;
	FIO0SET |= SPI1_SEL;
}
/*****************************************************************************
** Function name:		Status register
**
** Descriptions: The status register can be used to determine the device�s 
ready/busy status, page size, a Main Memory Page to Buffer Compare operation 
result, the Sector Protection status or the device density. The Status 
Register can be read at any time, including during an internally self-timed
program or erase operation.	 
**
** parameters:			none
** Returned value:		none
** 
*****************************************************************************/


void SPI_Status(void)
{	unsigned int Command;
	SPIRDData[0]= 0x00;
	while(1)
	{
//		FIO0CLR |= SPI0_SEL;
		FIO0CLR |= SPI1_SEL;
		Command = 0;
		Command |= Status_RegRd;
  		SPISend( (BYTE *)&Command,1 );
		SPIReceive( (BYTE *)SPIRDData,1);
//		FIO0SET |= SPI0_SEL;
		FIO0SET |= SPI1_SEL;
		if( SPIRDData[0] & 0x80)
			break; 
	}
}
/*****************************************************************************
** Function name:		Erase Page
**
** Descriptions: Single page Erase
**
** parameters:			Pageno
** Returned value:		none
** 
*****************************************************************************/
void SPI_PageErase(WORD Pageno)
{
  unsigned int Command;
//	FIO0CLR |= SPI0_SEL;	
	FIO0CLR |= SPI1_SEL;	
	Command = 0;
	Command |=  Page_Erase;
	Command |= Pageno<<SF_BUFFADD;
  	SPISend( (BYTE *)&Command,4 );
//   	FIO0SET |= SPI0_SEL;
   	FIO0SET |= SPI1_SEL;
	SPI_Status();

}
/*****************************************************************************
** Function name:		Erase Chip
**
** Descriptions: ChipErase
**
** parameters:			None
** Returned value:		none
** 
*****************************************************************************/
void SPI_ChipErase(void)
{   unsigned int Command;
//    FIO0CLR |= SPI0_SEL;	
    FIO0CLR |= SPI1_SEL;	
	Command = 0;
	Command =  Chip_Erase;
   	SPISend((BYTE *)&Command,4 );
//   	FIO0SET |= SPI0_SEL;
   	FIO0SET |= SPI1_SEL;
	SPI_Status();

}
void SPI_Conti_ArrayRd (WORD pageadd,WORD Bufadd,BYTE *buf,DWORD Length,BYTE *Crdptr )
{
 unsigned int Command;
//	FIO0CLR |= SPI0_SEL;
	FIO0CLR |= SPI1_SEL;
	Command = 0;
	Command |= Cti_Ary_Rd_LoFrq;
	Command |= pageadd<<SF_BUFFADD;
	Command	|= (Bufadd & SF_PAGEADD);
  	SPISend((BYTE *)&Command,4);
	SPIReceiveCont((BYTE *)buf,Length,(BYTE *)Crdptr );
//	FIO0SET |= SPI0_SEL;
	FIO0SET |= SPI1_SEL;

}


/* Initialize the interrupt controller */
/******************************************************************************
** Function name:		init_VIC
**
** Descriptions:		Initialize VIC interrupt controller.
** parameters:			None
** Returned value:		None
** 
******************************************************************************/
void init_VIC(void) 
{
    DWORD i = 0;
    DWORD *vect_addr, *vect_prio;
   	
    /* initialize VIC*/
    VICIntEnClr = 0xffffffff;
    VICVectAddr = 0;
    VICIntSelect = 0;

    /* set all the vector and vector control register to 0 */
    for ( i = 0; i < VIC_SIZE; i++ )
    {
		vect_addr = (DWORD *)(VIC_BASE_ADDR + VECT_ADDR_INDEX + i*4);
		vect_prio = (DWORD *)(VIC_BASE_ADDR + VECT_PRIO_INDEX + i*4);
		*vect_addr = 0x0;	
		*vect_prio = 0xF;
    }
    return;
}

/******************************************************************************
** Function name:		install_irq
**
** Descriptions:		Install interrupt handler
** parameters:			Interrupt number, interrupt handler address, 
**						interrupt priority
** Returned value:		true or false, return false if IntNum is out of range
** 
******************************************************************************/
DWORD install_irq( DWORD IntNumber, void *HandlerAddr, DWORD Priority )
{
    DWORD *vect_addr;
    DWORD *vect_prio;
      
    VICIntEnClr = 1 << IntNumber;	/* Disable Interrupt */
    if ( IntNumber >= VIC_SIZE )
    {
		return ( FALSE );
    }
    else
    {
		/* find first un-assigned VIC address for the handler */
		vect_addr = (DWORD *)(VIC_BASE_ADDR + VECT_ADDR_INDEX + IntNumber*4);
		vect_prio = (DWORD *)(VIC_BASE_ADDR + VECT_PRIO_INDEX + IntNumber*4);
		*vect_addr = (DWORD)HandlerAddr;	/* set interrupt vector */
		*vect_prio = Priority;
		VICIntEnable = 1 << IntNumber;	/* Enable Interrupt */
		return( TRUE );
    }
}

void GPIOInit( DWORD PortNum, DWORD PortType, DWORD PortDir )
{
  if ( (PortType == REGULAR_PORT) && ((PortNum == 0) || (PortNum == 1)) )
  {
	SCS &= ~GPIOM;		/* set GPIOx to use regular I/O */
	if ( PortDir == DIR_OUT )
	{
	  (*(volatile unsigned long *)(REGULAR_PORT_DIR_BASE 
			+ PortNum * REGULAR_PORT_DIR_INDEX)) = 0xFFFFFFFF;
	}
	else
	{
	  (*(volatile unsigned long *)(REGULAR_PORT_DIR_BASE 
			+ PortNum * REGULAR_PORT_DIR_INDEX)) = 0x00000000;
	}
  }
  else if ( PortType == FAST_PORT )
  {
	if ( (PortNum == 0) || (PortNum == 1) )
	{
	  SCS |= GPIOM;	/* set GPIOx to use Fast I/O */
	}
	if ( PortDir == DIR_OUT )
	{
	  (*(volatile unsigned long *)(HS_PORT_DIR_BASE 
			+ PortNum * HS_PORT_DIR_INDEX)) = 0xFFFFFFFF;
	}
	else
	{
	  (*(volatile unsigned long *)(HS_PORT_DIR_BASE 
			+ PortNum * HS_PORT_DIR_INDEX)) = 0x00000000;
    }
  }
  return;
}
/******************************************************************************
**                            End Of File
******************************************************************************/

