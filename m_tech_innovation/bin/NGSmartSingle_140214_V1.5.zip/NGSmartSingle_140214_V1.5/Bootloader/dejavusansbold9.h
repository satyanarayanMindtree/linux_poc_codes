#ifndef __DEJA_VU_SANS_BOLD_9__
#define __DEJA_VU_SANS_BOLD_9__

#include "bitmapfonts.h"

extern const unsigned  char dejaVuSansBold9ptCharBitmaps[];
extern const FONT_CHAR_INFO dejaVuSansBold9ptCharDescriptors[];
extern const FONT_INFO dejaVuSansBold9ptFontInfo;

#endif

