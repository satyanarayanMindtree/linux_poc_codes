//***************************************************************************** 
 // 
 // kitronix320x240x16_ssd2119_8bit.h - Prototypes for the Kitronix K350QVG-V1-F 
 // display driver with an SSD2119 
 // controller. 
 // 
 
 // 
 //***************************************************************************** 
  
 #ifndef __KITRONIX320X240X16_SSD2119_8BIT_H__ 
 #define __KITRONIX320X240X16_SSD2119_8BIT_H__ 
 

//*****************************************************************************
//
// Various internal SD2119 registers name labels
//
//*****************************************************************************
#define SSD2119_DEVICE_CODE_READ_REG  0x00
#define SSD2119_OSC_START_REG         0x00
#define SSD2119_OUTPUT_CTRL_REG       0x01
#define SSD2119_LCD_DRIVE_AC_CTRL_REG 0x02
#define SSD2119_PWR_CTRL_1_REG        0x03
#define SSD2119_DISPLAY_CTRL_REG      0x07
#define SSD2119_FRAME_CYCLE_CTRL_REG  0x0B
#define SSD2119_PWR_CTRL_2_REG        0x0C
#define SSD2119_PWR_CTRL_3_REG        0x0D
#define SSD2119_PWR_CTRL_4_REG        0x0E
#define SSD2119_GATE_SCAN_START_REG   0x0F
#define SSD2119_SLEEP_MODE_REG        0x10
#define SSD2119_ENTRY_MODE_REG        0x11
#define SSD2119_GEN_IF_CTRL_REG       0x15
#define SSD2119_PWR_CTRL_5_REG        0x1E
#define SSD2119_RAM_DATA_REG          0x22
#define SSD2119_FRAME_FREQ_REG        0x25
#define SSD2119_VCOM_OTP_1_REG        0x28
#define SSD2119_VCOM_OTP_2_REG        0x29
#define SSD2119_GAMMA_CTRL_1_REG      0x30
#define SSD2119_GAMMA_CTRL_2_REG      0x31
#define SSD2119_GAMMA_CTRL_3_REG      0x32
#define SSD2119_GAMMA_CTRL_4_REG      0x33
#define SSD2119_GAMMA_CTRL_5_REG      0x34
#define SSD2119_GAMMA_CTRL_6_REG      0x35
#define SSD2119_GAMMA_CTRL_7_REG      0x36
#define SSD2119_GAMMA_CTRL_8_REG      0x37
#define SSD2119_GAMMA_CTRL_9_REG      0x3A
#define SSD2119_GAMMA_CTRL_10_REG     0x3B
#define SSD2119_V_RAM_POS_REG         0x44
#define SSD2119_H_RAM_START_REG       0x45
#define SSD2119_H_RAM_END_REG         0x46
#define SSD2119_X_RAM_ADDR_REG        0x4E
#define SSD2119_Y_RAM_ADDR_REG        0x4F

//*****************************************************************************
//
// The dimensions of the LCD panel.
//
//*****************************************************************************
#define LCD_VERTICAL_MAX 240
#define LCD_HORIZONTAL_MAX 320

 
 //***************************************************************************** 
 // 
 // Prototypes for the globals exported by this driver. 
 // 
 //***************************************************************************** 
extern void Kitronix320x240x16_SSD2119Init(void); 
// extern const tDisplay g_sKitronix320x240x16_SSD2119; 
extern void Kitronix320x240x16_SSD2119LineDrawH(void *pvDisplayData, long lX1, long lX2, long lY, unsigned long ulValue);
extern unsigned short ReadDataGPIO(void);
extern unsigned short ReadCommandGPIO(void);   //IT IS READ COMMAND
extern void FillScreen(unsigned short Color);
extern void WriteCommand(unsigned char ucData);
void LcdSetCursor(long lX, long lY);
void lcdDrawHLine(long lX1, long lX2, long lY, unsigned long ulValue) ;
void lcdDrawPixel(long lX, long lY, unsigned long ulValue);
void lcdInit(void);
void InitGPIOLCDInterface(unsigned long ulClockMS);
void TFTWriteCommand(unsigned char ucData);
void TFTWriteByteData(unsigned char usData);
void TFTWriteData(unsigned short usData);
unsigned short TFTReadCommand(void);
void EnableDisplay(void);
void DisableDisplay(void);

////////////////////////////////////////// GLCD 3.2" /////////////////////////////////////

#define PIN_P2_GLCD_E     0x00000004	// Enable control pin    p2.2            
#define PIN_P2_GLCD_RS    0x00000008	// Data/Instruction control  p2.3        
#define PIN_P2_GLCD_WR    0x00000010	// RI_VD:pin: 2.4               
#define PIN_P2_GLCD_RD    0x00000020	// IORD:pin: 2.5              
#define PIN_P2_GLCD_RESET 0x00000040	// IORD:pin: 2.6              
#define PIN_P2_GLCD_BL	  0x00002000	// IORD:pin: 2.13

#define PINS_P1_GLCD_DATA     		0x07f80000	// IORD:pin 1.19 to p1.26              

#define DIR_OUT_GLCD_CTRL_BITS()	{FIO2DIR |= PIN_P2_GLCD_E | PIN_P2_GLCD_RS | PIN_P2_GLCD_RD | PIN_P2_GLCD_WR | PIN_P2_GLCD_RESET | PIN_P2_GLCD_BL; }

#define DIR_OUT_GLCD_DATALINE()		{FIO1DIR |= PINS_P1_GLCD_DATA; }

#define DIR_IN_GLCD_DATALINE()		{FIO1DIR &= ~PINS_P1_GLCD_DATA;}
			
// #define B_GLCD_E(X)  {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_E) :  (FIO2CLR |= PIN_P2_GLCD_E);}
// #define B_GLCD_RS(X) {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_RS) : (FIO2CLR |= PIN_P2_GLCD_RS);}
// #define B_GLCD_RD(X) {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_RD) : (FIO2CLR |= PIN_P2_GLCD_RD);}
// #define B_GLCD_WR(X) {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_WR) : (FIO2CLR |= PIN_P2_GLCD_WR);}
			
// #define BYTE_GLCD_OUT(x) 	{		   			\
// 	FIO1PIN &= ~PINS_P1_GLCD_DATA;	 		   	\
// 	FIO1PIN |= (x<<19 & PINS_P1_GLCD_DATA);		\
// }

#define BYTE_GLCD_OUT(x) 	{		   			\
	FIO1CLR = PINS_P1_GLCD_DATA;	 		   	\
	FIO1SET = (x<<19 & PINS_P1_GLCD_DATA);		\
}

#define GLCD_OUT_LINES 			FIO1PIN
#define GLCD_OUT_LINES_SHIFT 	19

#define BYTE_GLCD_READ(x)	{					\
	x = (FIO1PIN & PINS_P1_GLCD_DATA) >> 19;	\
}

#define CLR_BL			{FIO2CLR = PIN_P2_GLCD_BL;}                                             
#define SET_BL          {FIO2SET = PIN_P2_GLCD_BL;}

//=================================================================================================
//I/O selection pins
//#define PINO_P4_CSIP	0x10000000	  		//P4.28
//#define PINO_P4_CSOP  	0x20000000			//P4.29

#define PIN_P0_CSIP  	  0x00000010			//P0.4 ,cs1   //cs_ipcs1 , CS input Latch
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
#define PIN_P1_CSOP  	  0x80000000			//P1.31 ,cs3  //cs_opcs1 , CS output Latch
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs8

#define PINS_P1_IO     		0x07f80000	// :pin 1.19 to p1.26   D0 to D7           

//#define DIR_IO_DEC_PINS()		{FIO4DIR |= PINO_P4_CSIP | PINO_P4_CSOP;}
#define DIR_IO_DEC_PINS()		{FIO1DIR |= PIN_P1_CSOP ; FIO0DIR |= PIN_P0_CSIP ;}     //select cs as out pins

//#define DIR_IO_OUT_PORT()		{FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000;}
#define DIR_IO_OUT_PORT()		{FIO1DIR |= PINS_P1_IO; } //select data pin as out

//#define DIR_IO_IN_PORT()		{FIO2DIR &= ~0x000000FC; FIO3DIR &= ~0x06000000;}
#define DIR_IO_IN_PORT()		{FIO1DIR &= ~PINS_P1_IO; } //select data pin as in

#define DISABLE_DECODER() 			{FIO1SET |= PIN_P1_CSOP ; FIO0SET |= PIN_P0_CSIP ;}

#define BYTE_IO_OUT_PORT(x)		{DIR_IO_OUT_PORT(); FIO1PIN &= ~PINS_P1_IO; 	\
	FIO1PIN |= (x<<19 & PINS_P1_IO);		}

//#define BYTE_IO_READ_PORT(X)	{DIR_IO_IN_PORT(); X = (FIO2PIN & 0x000000FC) >> 2;	\
//									X = X | ((FIO3PIN & 0x06000000) >> 19);}	   //ARMD0063								
#define BYTE_IO_READ_PORT(x)	{	DIR_IO_IN_PORT();				\
	x = (FIO1PIN & PINS_P1_IO) >> 19;	\
}
#define CLR_CD			{FIO2CLR = PIN_P2_GLCD_RS;}
#define SET_CD          {FIO2SET = PIN_P2_GLCD_RS;}
#define CLR_CS			{FIO2CLR = PIN_P2_GLCD_E;}
#define SET_CS			{FIO2SET = PIN_P2_GLCD_E;}
#define CLR_WR			{FIO2CLR = PIN_P2_GLCD_WR;}
#define SET_WR          {FIO2SET = PIN_P2_GLCD_WR;}                                             
#define CLR_RESET       {FIO2CLR = PIN_P2_GLCD_RESET;}
#define SET_RESET       {FIO2SET = PIN_P2_GLCD_RESET;}
#define CLR_RD			{FIO2CLR = PIN_P2_GLCD_RD;}                                             
#define SET_RD          {FIO2SET = PIN_P2_GLCD_RD;}
#define CLR_BL			{FIO2CLR = PIN_P2_GLCD_BL;}                                             
#define SET_BL          {FIO2SET = PIN_P2_GLCD_BL;}

#define CLR_CS_CD				{FIO2CLR = PIN_P2_GLCD_E|PIN_P2_GLCD_RS;}
#define SET_RD_WR				{FIO2SET = PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}           
#define SET_WR_CS				{FIO2SET = PIN_P2_GLCD_WR|PIN_P2_GLCD_E;}	           
#define SET_CD_RD_WR			{FIO2SET = PIN_P2_GLCD_RS|PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}
#define CLR_CS_CD_SET_RD_WR		{FIO2CLR = PIN_P2_GLCD_E|PIN_P2_GLCD_RS;   FIO2SET = PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}
#define CLR_CS_SET_CD_RD_WR 	{FIO2CLR = PIN_P2_GLCD_E;   FIO2SET = PIN_P2_GLCD_RS|PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}
/*
#define BOOT_MSG1			1
#define BOOT_MSG2	        2
#define BOOT_MSG3	        3
#define ROW_USER_TITLE	    4
#define ROW_USER_FUNCTION   5
#define ROW_USER_ENTRY      6
#define ROW_USER_ENTRY2	    7
#define ROW_USER_ENTRY3	    8
#define ROW_USER_ENTRY4	    9
#define ROW_USER_ENTRY5	    10

#define USER_TITLE_LINE_COLOR			COLOR_BLUE
#define	COLOR_BLACK         0x0000
#define	COLOR_BLUE          0x001F
#define	COLOR_RED           0xF800
#define	COLOR_GREEN         0x07E0
#define COLOR_CYAN          0x07FF
#define COLOR_MAGENTA       0xF81F
#define COLOR_YELLOW        0xFFE0
#define COLOR_WHITE         0xFFFF

#define BOOT_MSG_HEIGHT			16
#define BOOT_MSG1_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG1_Y0			(BOOT_MSG_SECTION_Y0)
#define BOOT_MSG2_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG2_Y0			(BOOT_MSG1_Y0+BOOT_MSG_HEIGHT+1)
#define BOOT_MSG3_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG3_Y0			(BOOT_MSG2_Y0+BOOT_MSG_HEIGHT+1)
#define BOOT_MSG_COLOR			COLOR_WHITE
#define BOOT_MSG_FONT			dejaVuSansBold9ptFontInfo

typedef unsigned  char uint8_t;
typedef unsigned short     int uint16_t;
typedef unsigned           int uint32_t;
typedef unsigned       __int64 uint64_t;

void drawString(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo, unsigned char *str);
void drawString(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo, unsigned char *str);

#define TOUCH_KEY_SECTION_HEIGHT			50
#define TOUCH_KEY_SECTION_WIDTH				DISPLAY_WIDTH

#define BOOT_MSG_SECTION_HEIGHT					TOUCH_KEY_SECTION_HEIGHT
#define BOOT_MSG_SECTION_WIDTH					TOUCH_KEY_SECTION_WIDTH
#define BOOT_MSG_SECTION_X0					0
#define BOOT_MSG_SECTION_Y0					(DISPLAY_HEIGHT - BOOT_MSG_SECTION_HEIGHT)*/

 #endif // __KITRONIX320X240X16_SSD2119_H__ 

