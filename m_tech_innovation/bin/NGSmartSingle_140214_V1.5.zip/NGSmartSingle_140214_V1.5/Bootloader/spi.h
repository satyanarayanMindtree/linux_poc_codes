/*****************************************************************************
 *   spi.h:  Header file for NXP LPC23xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __SPI_H__
#define __SPI_H__

/* this flag is to test SPI in either interrupt mode or polling */
#define INTERRUPT_MODE	1

//#define SUPPORT_8MB_FLASH

#ifdef	 SUPPORT_8MB_FLASH
/* SPI read and write buffer size */
#define SPIBUFSIZE		264
#define CMD_OFFSET		3		/* Leave one for cmd, one for addH, and one for addL */
#define SF_BLOCKS		2048
#define SF_BLOCKSIZE	264
#define SF_PAGEADD		0x1ff  // for 8 Mibt Ox1ff for 64MB 0xfff
#define SF_BUFFADD		9	   // for 8 Mibt 9 for 64MB 10

#else

/* SPI read and write buffer size */
#define SPIBUFSIZE        528
#define CMD_OFFSET        3        /* Leave one for cmd, one for addH, and one for addL */
#define SF_BLOCKS         2048
#define SF_BLOCKSIZE      528
#define SF_PAGEADD        0x7ff  // for 8 Mibt Ox1ff for 64MB 0xfff
#define SF_BUFFADD        10       // for 8 Mibt 9 for 64MB 10

#endif

/* Delay count after each write */
#define DELAY_COUNT		10

#define SPI0_INT_FLAG	0x01

/* SPI select pin */
//#define SPI01_SEL		1 << 23		/* P0.23 is used as GPIO, CS signal to SPI EEPROM */ 
#define SPI0_SEL		1 << 6		/* P0.6 is used as GPIO, CS signal to SPI EEPROM */ 
#define SPI1_SEL		1 << 16		/* P0.16 is used as GPIO, CS signal to SPI EEPROM */
#define MAX_TIMEOUT		0xFF

#define SPI0_ABORT		0x01		/* below two are SPI0 interrupt */
#define SPI0_MODE_FAULT	0x02
#define SPI0_OVERRUN	0x04
#define SPI0_COL		0x08
#define SPI0_TX_DONE	0x10

#define ABRT		1 << 3		/* SPI0 interrupt status */
#define MODF		1 << 4
#define ROVR		1 << 5
#define WCOL		1 << 6
#define SPIF		1 << 7

#define RORIC		0x00000001
#define RTIC		0x00000002

/* SPI 0 PCR register */
#define SPI0_BE		0x00000004
#define SPI0_CPHA	0x00000008
#define SPI0_CPOL	0x00000010
#define SPI0_MSTR	0x00000020
#define SPI0_LSBF	0x00000040
#define SPI0_SPIE	0x00000080


/* ATMEL AT45DB041D SPIFLASH command set */
#define Main_MemPage_Rd		0xD2000000
#define Conti_Array_Rd		0xE8000000
#define Cti_Ary_Rd_LoFrq	0x03000000
#define Cti_Ary_Rd_HiFrq	0x0B000000
#define Buf1_RdLoFrq		0xD1000000
#define Buf2_RdLoFrq		0xD3000000
#define Buf1_Rd				0xD4000000
#define Buf2_Rd				0xD6000000

#define Buf1_Wrt				0x84000000
#define Buf2_Wrt				0x87000000
#define Buf1_ToMemPage			0x83000000
#define Buf2_ToMemPage			0x86000000
#define Page_Erase				0x81000000
#define Block_Erase				0x50000000
#define Sector_Erase			0x7C000000
#define Chip_Erase				0xC794809A
#define Main_MemPage_ToBuf1		0x53000000
#define Main_MemPage_ToBuf2		0x55000000
#define Main_MemPage_ToBuf1Comp	0x60000000
#define Main_MemPage_ToBuf2Comp	0x61000000
#define Auto_PageRewrt_Buf1		0x58000000
#define Auto_PageRewrt_Buf2		0x59000000
#define Deep_Pow_dwn			0xB9000000
#define Resume_Deep_Powdwn		0xAB000000
#define Status_RegRd			0xD7000000
#define Manuf_DevID_Rd			0x9F000000


/* RDSR status bit definition */
#define RDSR_RDY	0x01
#define RDSR_WEN	0x02

typedef unsigned char  BYTE;	 	// 1 byte
typedef unsigned short WORD;		// 2 bytes		 	
typedef unsigned long  DWORD;		// 4 bytes
typedef unsigned int   BOOL;		// 4 bytes

#define I_Bit			0x80
#define F_Bit			0x40

#define SYS32Mode		0x1F
#define IRQ32Mode		0x12
#define FIQ32Mode		0x11

#define HIGHEST_PRIORITY	0x01
#define LOWEST_PRIORITY		0x0F

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (1)
#endif

/*
Total Pages 
for 32 Mbit 
Pages 7943 of 528 bytes
Pages 8192 of 512 bytes
We will consider 7943 pages
*/
#define	PAGE_SIZE				528
#define	CODE_PAGE_SIZE			512 

#define FL_NEW_FW_CODE_INFO		6900
#define FL_NEW_FW_BASE_ADDRESS	6901	//We will use 542 pages for new f/w i.e. 271K program size	
#define SUPPORT_MAX_CODE_SZ		512000 	//277504	//271K		

static DWORD sysreg;		/* used as LR register */
#define IENABLE __asm { MRS sysreg, SPSR; MSR CPSR_c, #SYS32Mode }
#define IDISABLE __asm { MSR CPSR_c, #(IRQ32Mode|I_Bit); MSR SPSR_cxsf, sysreg }

#define SPI0_INT		10			/* SPI and SSP0 share VIC slot */

#define VIC_SIZE		32

#define VECT_ADDR_INDEX	0x100
#define VECT_PRIO_INDEX 0x200

void init_VIC( void );
DWORD install_irq( DWORD IntNumber, void *HandlerAddr, DWORD Priority );

extern void SPI0Handler (void) __irq;
extern DWORD SPIInit( void );
extern void SPISend( BYTE *buf,DWORD Length );
extern void SPIReceive( BYTE *buf, DWORD Length );
extern BYTE SPIReceiveByte( void );
extern void MainMem_BuffWrt( WORD Bufadd,WORD Bufno,BYTE *buf,WORD Length  );
extern void MainMem_ReadPage(WORD pageadd,WORD Bufadd,BYTE *buf,WORD Length);
extern void BuffWrt_MainMem( WORD pageadd,WORD Bufadd);
extern void SPI_DeviceID(BYTE *buf);
extern void SPI_Status(void);
extern void SPI_ChipErase(void);
extern void SPI_PageErase(WORD Pageno);
extern void SPI_Conti_ArrayRd (WORD pageadd,WORD Bufadd,BYTE *buf,DWORD Length,BYTE *Crdptr );
extern short SPIReceiveCont( BYTE *buf, DWORD Length, BYTE *Crdptr );
extern void MainMem_ToBuff( WORD Pageadd,WORD Bufno);


#define GPIOM			0x00000001

/* see master definition file lpc230x.h for more details */
#define REGULAR_PORT_DIR_BASE		GPIO_BASE_ADDR + 0x08
#define REGULAR_PORT_DIR_INDEX		0x10	

#define HS_PORT_DIR_BASE			FIO_BASE_ADDR + 0x00
#define HS_PORT_DIR_INDEX			0x20

#define FAST_PORT		0x01
#define REGULAR_PORT	0x02

#define DIR_OUT			0x01
#define DIR_IN			0x02

extern void GPIOInit( DWORD PortNum, DWORD PortType, DWORD PortDir );


#endif  /* __SPI_H__ */
/*****************************************************************************
**                            End Of File
******************************************************************************/

