//-----------------------------------------------------------------------------
// Software that is described herein is for illustrative purposes only  
// which provides customers with programming information regarding the  
// products. This software is supplied "AS IS" without any warranties.  
// NXP Semiconductors assumes no responsibility or liability for the 
// use of the software, conveys no license or title under any patent, 
// copyright, or mask work right to the product. NXP Semiconductors 
// reserves the right to make changes in the software without 
// notification. NXP Semiconductors also make no representation or 
// warranty that such application will be suitable for the specified 
// use without further testing or modification. 
//-----------------------------------------------------------------------------

#include <LPC23XX.H>                        /* LPC23xx definitions */

#include "sbl_config.h"
#include "comms.h"
#include "isp\isp_iap.h"
#include "board_init\board_init.h"

const unsigned crp __attribute__((section(".ARM.__at_0x1FC"))) = CRP;
const unsigned fcclk_KHz = FCCLK / 1000;

#define CHECK_AFTER_BOOTLOADER 	(*((unsigned int *) 0xE0084014))
#define CHECK_AFTER_BOOTLOADER_INFO1 	(*((unsigned int *) 0xE0084018))
#define CHECK_AFTER_BOOTLOADER_INFO2 	(*((unsigned int *) 0xE008401C))

void enter_isp(void)
{
  board_init();
  init_comms();
  comm_handshake();
  isp_cmd_loop();
}

/* Main Program */
void sbl_main (void) {
  
  
  if( user_code_present() )
  {
      if ( crp == CRP3 )
	  {
          /* CRP3 is enabled and user flash start sector is not blank, 
		     execute the user code */
		  execute_user_code();
      }
	  else
	  {
//	      if ( check_isp_entry_pin() )
		 if(CHECK_AFTER_BOOTLOADER != 12345)
		  {
		      /* isp entry not requested and CRP3 not enabled */			  
		      execute_user_code();
		  }
		  else
		  {
		      /* isp entry requested and CRP3 not enabled */
			  CHECK_AFTER_BOOTLOADER = 0;
			  enter_isp();
		  }
	  }
  }
  /* User code not present, enter isp */
  enter_isp();
}
