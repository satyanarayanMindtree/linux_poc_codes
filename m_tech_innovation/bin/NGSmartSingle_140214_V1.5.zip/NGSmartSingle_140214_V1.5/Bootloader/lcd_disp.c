
#include "lcd_disp.h"
#include"tft.h"
#include "LPC23XX.H"                        /* LPC23xx definitions */
#include "bitmapfonts.h"
#include "dejavusansbold9.h"

// void L_DisplayROMStr(unsigned char *strdata,unsigned char len,unsigned char row)
// {
// 	L_DisplayROMStrLoc(strdata, len, row,0);
// }
// void L_DisplayROMStrLoc(unsigned char *strdata,unsigned char len,unsigned char row, unsigned char pos)
// {
// 	switch(row)
// 	{
// 		case BOOT_MSG1:
// 			drawString(BOOT_MSG1_X0,BOOT_MSG1_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
// 		break;
// 		case BOOT_MSG2:	
// 			drawString(BOOT_MSG2_X0,BOOT_MSG2_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
// 		break;
// 		case BOOT_MSG3:	
// 			drawString(BOOT_MSG3_X0,BOOT_MSG3_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
// 		break;
// 	}
// }
void drawString(unsigned short x, unsigned short y, unsigned short color, const FONT_INFO *fontInfo, unsigned char *str)
{
  unsigned short currentX, charWidth, characterToOutput;
  const FONT_CHAR_INFO *charInfo;
  uint16_t charOffset;
  
  // set current x, y to that of requested
  currentX = x;
//  y=y+ (fontInfo->heightPages*8 /2) ;   //this is added because string write is always top shifted
	  y=y+8 ;
  // while not NULL
  while (*str != '\0')
  {
    characterToOutput = *str;
    charInfo = fontInfo->charInfo;    
    // some fonts have character descriptors, some don't
    if (charInfo != '\0')
    {
		characterToOutput = *str;
		charInfo = fontInfo->charInfo; 
      // get correct char offset
      charInfo += (characterToOutput - fontInfo->startChar);
      
      // get width from char info
      charWidth = charInfo->widthBits;
      
      // get offset from char info
      charOffset = charInfo->offset;
    }        
    else
    {
      // if no char info, char width is always 5
      charWidth = 5;
      
      // char offset - assume 5 * letter offset
      charOffset = (characterToOutput - fontInfo->startChar) * 5;
    }            
    // Send individual characters
    drawCharBitmap(currentX, y + 1, color, &fontInfo->data[charOffset], fontInfo->heightPages, charWidth);

    // next char X
    currentX += charWidth + 1;
    
    // next char
    str++;
  }
}
void drawCharBitmap(const unsigned short xPixel, const unsigned short yPixel, unsigned short color, const unsigned char  *glyph, uint8_t glyphHeightPages, unsigned char glyphWidthBits)
{
  unsigned short verticalPage, horizBit, currentY, currentX;
  unsigned short indexIntoGlyph;

  // set initial current y
  currentY = yPixel;
  currentX = xPixel;
	CLR_CS;
	FIO1MASK = ~PINS_P1_GLCD_DATA;
  // for each page of the glyph
  for (verticalPage = glyphHeightPages; verticalPage > 0; --verticalPage)
  {
    // for each horizontol bit
    for (horizBit = 0; horizBit < glyphWidthBits; ++horizBit)
    {
      // next byte
      indexIntoGlyph = (glyphHeightPages * horizBit) + verticalPage - 1;
      
      currentX = xPixel + (horizBit);
      // send the data byte
      if (glyph[indexIntoGlyph] & (0X80)) NewDrawPixel(currentX, currentY, color);
      if (glyph[indexIntoGlyph] & (0X40)) NewDrawPixel(currentX, currentY - 1, color);
      if (glyph[indexIntoGlyph] & (0X20)) NewDrawPixel(currentX, currentY - 2, color);
      if (glyph[indexIntoGlyph] & (0X10)) NewDrawPixel(currentX, currentY - 3, color);
      if (glyph[indexIntoGlyph] & (0X08)) NewDrawPixel(currentX, currentY - 4, color);
      if (glyph[indexIntoGlyph] & (0X04)) NewDrawPixel(currentX, currentY - 5, color);
      if (glyph[indexIntoGlyph] & (0X02)) NewDrawPixel(currentX, currentY - 6, color);
      if (glyph[indexIntoGlyph] & (0X01)) NewDrawPixel(currentX, currentY - 7, color);
    }
    // next line of pages
    currentY += 8;
  }
	FIO1MASK = 0;
	SET_CS;
}
void NewDrawPixel(uint16_t x, uint16_t y, uint16_t color)
{
//	unsigned char dat;
  if ((x >= LCD_HORIZONTAL_MAX) || (y >= LCD_VERTICAL_MAX))
  {
    // Pixel out of range
    return;
  }

  // Redirect to LCD
  //lcdDrawPixel(x, y, color);
    // Set the X address of the display cursor.
    //TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
	CLR_CD;
    GLCD_OUT_LINES=0x00;
	CLR_WR;
	SET_WR;
	GLCD_OUT_LINES = SSD2119_X_RAM_ADDR_REG<<GLCD_OUT_LINES_SHIFT;
	CLR_WR;
	SET_WR;
    //TFTWriteData(x);
	SET_CD;
	//dat = (x >> 8)&0xff;  // Write the most significant byte of the data to the bus.
    GLCD_OUT_LINES=x<<(GLCD_OUT_LINES_SHIFT-8);
	CLR_WR;
	SET_WR;
	//dat = x & 0xFF; // Write the least significant byte of the data to the bus.
    GLCD_OUT_LINES=x<<GLCD_OUT_LINES_SHIFT;
	CLR_WR;
	SET_WR;

    // Set the Y address of the display cursor.
    //TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
	CLR_CD;
    GLCD_OUT_LINES=0x00;
	CLR_WR;
	SET_WR;
	GLCD_OUT_LINES = SSD2119_Y_RAM_ADDR_REG<<GLCD_OUT_LINES_SHIFT;
	CLR_WR;
	SET_WR;
    //TFTWriteData(y);
	SET_CD;
	//dat = (y >> 8)&0xff;  // Write the most significant byte of the data to the bus.
    GLCD_OUT_LINES=y<<(GLCD_OUT_LINES_SHIFT-8);
	CLR_WR;
	SET_WR;
	//dat = y & 0xFF; // Write the least significant byte of the data to the bus.
    GLCD_OUT_LINES=y<<GLCD_OUT_LINES_SHIFT;
	CLR_WR;
	SET_WR;

    // Write the pixel value.
    //TFTWriteCommand(SSD2119_RAM_DATA_REG);
	CLR_CD;
    GLCD_OUT_LINES=0x00;
	CLR_WR;
	SET_WR;
	GLCD_OUT_LINES = SSD2119_RAM_DATA_REG<<GLCD_OUT_LINES_SHIFT;
	CLR_WR;
	SET_WR;
    //TFTWriteData(color);
	SET_CD;
	//dat = (color >> 8)&0xff;  // Write the most significant byte of the data to the bus.
    GLCD_OUT_LINES=color<<(GLCD_OUT_LINES_SHIFT-8);
	CLR_WR;
	SET_WR;
	//dat = color & 0xFF; // Write the least significant byte of the data to the bus.
    GLCD_OUT_LINES=color<<GLCD_OUT_LINES_SHIFT;
	CLR_WR;
	SET_WR;
}

