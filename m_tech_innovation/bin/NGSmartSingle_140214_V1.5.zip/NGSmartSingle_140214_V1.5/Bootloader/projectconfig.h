/**************************************************************************/
/*! 
    @file     projectconfig.h
    @author   K. Townsend (microBuilder.eu)

    @section LICENSE

    Software License Agreement (BSD License)

    Copyright (c) 2010, microBuilder SARL
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holders nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**************************************************************************/

#ifndef _PROJECTCONFIG_H_
#define _PROJECTCONFIG_H_

//#include "lpc134x.h"	/////////haresh
//#include "config.h"
//#include "portdef.h"
//#include "sysdefs.h"
/*=========================================================================
    BOARD SELECTION

    Because several boards use this code library with sometimes slightly
    different pin configuration, you will need to specify which board you
    are using by enabling one of the following definitions. The code base
    will then try to configure itself accordingly for that board.
    -----------------------------------------------------------------------*/
    #define CFG_BRD_LPC1343_REFDESIGN
    // #define CFG_BRD_LPC1343_TFTLCDSTANDALONE
    // #define CFG_BRD_LPC1343_802154USBSTICK
/*=========================================================================*/

/*=========================================================================
    TFT LCD
    -----------------------------------------------------------------------

    CFG_TFTLCD                  If defined, this will cause drivers for
                                a pre-determined LCD screen to be included
                                during build.  Only one LCD driver can be 
                                included during the build process (for ex.
                                'drivers/lcd/hw/ILI9325.c')
    CFG_TFTLCD_INCLUDESMALLFONTS If set to 1, smallfont support will be
                                included for 3x6, 5x8, 7x8 and 8x8 fonts.
                                This should only be enabled if these small
                                fonts are required since there is already
                                support for larger fonts generated with
                                Dot Factory 
                                http://www.pavius.net/downloads/tools/53-the-dot-factory
    CFG_TFTLCD_TS_THRESHOLD     Minimum threshold to trigger a touch event
                                with the touch screen (and exit from
                                'tsWaitForEvent' in touchscreen.c).  Should
                                be an 8-bit value somewhere between 8 and 32
                                in normal circumstances.
    CFG_TFTLCD_TS_KEYPADDELAY   The delay in milliseconds between key
                                presses in dialogue boxes

    PIN LAYOUT:                 The pin layout that is used by this driver
                                can be seen in the following schematic:
                                /tools/schematics/Breakout_TFTLCD_ILI9325_v1.3

    DEPENDENCIES:               TFTLCD requires the use of pins 1.8, 1.9,
                                1.10, 1.11, 3.3 and 2.1-9.
    -----------------------------------------------------------------------*/
    #ifdef CFG_BRD_LPC1343_REFDESIGN      //this is our selection
      // #define CFG_TFTLCD
      #define CFG_TFTLCD_INCLUDESMALLFONTS   (0)
      #define CFG_TFTLCD_TS_THRESHOLD        (10)
//      #define CFG_TFTLCD_TS_THRESHOLD        (25)
      #define CFG_TFTLCD_TS_KEYPADDELAY      (150)
    #endif

    #ifdef CFG_BRD_LPC1343_TFTLCDSTANDALONE
      #define CFG_TFTLCD
      #define CFG_TFTLCD_INCLUDESMALLFONTS   (0)
      #define CFG_TFTLCD_TS_THRESHOLD        (40)
      #define CFG_TFTLCD_TS_KEYPADDELAY      (200)
    #endif

    #ifdef CFG_BRD_LPC1343_802154USBSTICK
      // #define CFG_TFTLCD
      #define CFG_TFTLCD_INCLUDESMALLFONTS   (0)
      #define CFG_TFTLCD_TS_THRESHOLD        (40)
      #define CFG_TFTLCD_TS_KEYPADDELAY      (200)
    #endif
/*=========================================================================*/

#endif



