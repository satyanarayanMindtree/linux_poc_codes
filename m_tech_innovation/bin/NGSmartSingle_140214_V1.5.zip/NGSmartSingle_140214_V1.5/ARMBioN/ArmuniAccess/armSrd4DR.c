/*
C File created for Arm 4DR Serial 8 reader board
*/

#include "config.h"
#include <LPC23xx.h>      // Keil: Register definition file for LPC2378
#include "portdef.h"
#include "type.h"
#include "timer.h"
#include "portdef.h"
#include "serial.h"
//#include "portlcd.h"
#include "INOUT.h"
#include "rdcont.h"
#include "rdpoll.h"
#include "uart.h"
#include "SmartBio.h"

extern void Delay(DWORD cnt);
void SelectIOCS(unsigned char iotype);

extern SYSInfo SysInfo;

//unsigned char F_OutPutLock;


/*

#define READ_INPUT(X)								\
{   														\

	SelectIOCS(CS_IPCS1);							\
	X = RdPortI(PADR);								\
	SelectIOCS(CS_IPCS2);							\
	X = X + RdPortI(PADR)*0x100;					\
	SelectIOCS(CS_NO_SEL);							\
	WrPortI(SPCR, &SPCRShadow, 0x84);			\
   WrPortI(PADR, &PADRShadow, 0xFF);         \

}		  
*/


/*
This is to select then CHIP select pin

*/


void InitialiseIO(void)
{
  	SCS |= 0x00000001;	/* set GPIOx to use Fast I/O */
	BuffOPCS1Latch = DEFAULT_CS1_OUT;
	DIR_IO_OUT_PORT();
	SelectIOCS(CS_OPCS1);
	BYTE_IO_OUT_PORT(BuffOPCS1Latch);
	SelectIOCS(CS_NO_SEL);
//	DIR_BUZZER_BIT();
	BUZZER_OFF();
	DIR_IO_DEC_PINS();
	BYTE_IO_OUT_PORT(0xFF);
   	DIR_LCD_PORT_BITS();
//PORT 0 PINS USED 31 TO 16 :0001 0000 0010 0000 0000 0000 0011 1100 
 	FIO0DIR |= 0x08000000; 
//select default Wigend as input when SDC memory is used no interrupt is received on wiegand
	FIO0CLR |=	WG_LATCh_SEL;
//Weigand output direction control
#ifdef WEIGAND_OUT_READER
	DIR_WEIGAND_OUT_PORT();
#endif

	DIR_LCD_OUT_PORT();
	BYTE_LCD_OUT(0xFF);
	DIR_LCD_PORT_BITS();
}

void SelectIOCS(unsigned char iotype)
{
	F_OutPutLock = 1;
	DIR_IO_DEC_PINS();
	Delay(100);
	switch(iotype)
   {
   	case CS_IPCS1:
	FIO1CLR |=PINO_P1_DEC1;
	FIO1CLR |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC0;
	DIR_IO_IN_PORT();
	break;
   case CS_IPCS2:
//	DIR_IO_IN_PORT();
	FIO1CLR |=PINO_P1_DEC1;
	FIO1CLR |=PINO_P1_DEC2;
	FIO4SET |=PINO_P4_DEC0;
	DIR_IO_IN_PORT();
	break;
   case CS_IPCS3:
//	DIR_IO_IN_PORT();
	FIO1CLR |=PINO_P1_DEC1;
	FIO1SET |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC0;
	DIR_IO_IN_PORT();
	break;

   case CS_OPCS1:
//	DIR_IO_IN_PORT();
	FIO1SET |=PINO_P1_DEC1;
	FIO1CLR |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC0;	 
	DIR_IO_OUT_PORT();
   break;
   case CS_OPCS2:
//	DIR_IO_IN_PORT();
	FIO1SET |=PINO_P1_DEC1;
	FIO1CLR |=PINO_P1_DEC2;
	FIO4SET |=PINO_P4_DEC0;
	DIR_IO_OUT_PORT();
   break;
   case CS_OPCS3:
//	DIR_IO_IN_PORT();
	FIO1CLR |=PINO_P1_DEC1;
	FIO1SET |=PINO_P1_DEC2;
	FIO4SET |=PINO_P4_DEC0;
	DIR_IO_OUT_PORT();   
	break;

   case CS_BUZZER:
/*	tdata = (PFDRShadow & 0x6E) | 0x90;                // 1xx1 xxx1
	WrPortI(PFDR, &PFDRShadow,tdata);
	Delay(10);
	WrPortI(SPCR, &SPCRShadow, 0x80);
	WrPortI(PADR, &PADRShadow, 0xFF);
	F_OutPutLock=0;*/
   break;
   case CS_NO_SEL:
//	DIR_IO_IN_PORT();
	FIO4SET |=PINO_P4_DEC0;
	FIO1SET |=PINO_P1_DEC1;
	FIO1SET |=PINO_P1_DEC2;
	DIR_IO_IN_PORT();
//	DIR_IO_OUT_PORT();  
   	F_OutPutLock = 0;
   	break;
   }
}


/*** BeginHeader DoorOpen*/
void DoorOpen(unsigned char drno);
/*** EndHeader */
/// Actual Door Open
void DoorOpen(unsigned char drno)
{
   	if(drno >= SysInfo.ControllerMode)
   		return;
    MsgPrint(1,drno,"Door number Open= ");
	DRStruct[drno].DRCurrentStatus = SET;
	if(SysInfo.ControllerMode==8)
		drno = drno/2;
	switch(drno)
	{
		case 0:
		DOOR_OPEN(1);
		break;		
		case 1:
		DOOR_OPEN(2);
		break;
		case 2:
		DOOR_OPEN(3);
		break;
		case 3:
		DOOR_OPEN(4);
		break;
	}
	 MsgPrint(1,BuffOPCS1Latch,"BuffOPCS1Latch= ");
/*
	if(drno==0)
	{
	   SelectIOCS(CS_OPCS1);
	   UnLockD1;
	   BYTE_IO_OUT_PORT(BuffOPCS1Latch);
	   SelectIOCS(CS_NO_SEL);
	}
	else if(drno==1)
	{
	   SelectIOCS(CS_OPCS1);
	   UnLockD2;
	   I_OPortWite();
	   SelectIOCS(CS_NO_SEL);
	}
   else if(drno==2)
	{
	   SelectIOCS(CS_OPCS1);
	   UnLockD3;
	   I_OPortWite();
	   SelectIOCS(CS_NO_SEL);
	}
   else if(drno==3)
	{
	   SelectIOCS(CS_OPCS1);
	   UnLockD4;
	   I_OPortWite();
	   SelectIOCS(CS_NO_SEL);
	}
	DRStruct[drno].DRCurrentStatus = SET;
	MsgPrint(MSG_DOOR_CONT,drno,"Door Opened ");
*/
}

/*** BeginHeader DoorClose*/
void DoorClose(unsigned char drno);
/*** EndHeader */
// Actual Door Close
void DoorClose(unsigned char drno)
{
   	if(drno >= SysInfo.ControllerMode)
   		return;
    MsgPrint(1,drno,"Door number Close= ");
	if(CHECK_SHARED_DOTL(drno))
		DRStruct[((drno/2)*2)+1].DRCurrentStatus = CLR;	
	DRStruct[drno].DRCurrentStatus = CLR;
	if(SysInfo.ControllerMode == 8)
		drno = drno/2;
	switch(drno)
	{
		case 0:
			DOOR_CLOSE(1);
			break;		
		case 1:
			DOOR_CLOSE(2);
			break;
		case 2:
			DOOR_CLOSE(3);
			break;
		case 3:
			DOOR_CLOSE(4);
			break;
	}
	MsgPrint(1,BuffOPCS1Latch,"BuffOPCS1Latch= ");
}

/*** BeginHeader WeigandLedOn*/
void WeigandLedOn(unsigned char rdno);
/*** EndHeader */
void WeigandLedOn(unsigned char rdno)
{
 	DRStruct[rdno].DRControlRdrData |= (0x1<<SL_RDR_LED_CONTROL);     	 //Set bit
//	AddToSendQueue((rdno/2)+1,QUEUE_CMD_WEI_LED_ON,(rdno%2)+1,ReaderInfo[rdno].DOpTime,ReaderInfo[rdno].DOTLTime,(rdno%2)+1,1);
}

/*** BeginHeader WeigandLedOff*/
void WeigandLedOff(unsigned char rdno);
/*** EndHeader */
void WeigandLedOff(unsigned char rdno)
{	
	DRStruct[rdno].DRControlRdrData &= (~(0x1<<SL_RDR_LED_CONTROL));	//Clear bit
}

/*** BeginHeader DOTLLedOn*/
void DOTLLedOn(unsigned int rdno);
/*** EndHeader */
void DOTLLedOn(unsigned int rdno)
{
	DRStruct[rdno].DRControlRdrData |= (0x1<<SL_RDR_DOTL_CONTROL);     	 //Set bit
	if(SysInfo.ControllerMode == 8)
	{
		if(rdno%2)
			return;
		rdno = rdno / 2;
	}
	switch(rdno)
	{   	
		case 0:
			SET_DOTL(1)
			break;
      	case 1:
			SET_DOTL(2)
			break;
      	case 2:
			SET_DOTL(3)
			break;
      	case 3:
			SET_DOTL(4)
			break;
	}
}

/*** BeginHeader DOTLLedOff*/
void DOTLLedOff(unsigned int rdno);
/*** EndHeader */
void DOTLLedOff(unsigned int rdno)
{
	DRStruct[rdno].DRControlRdrData &= (~(0x1<<SL_RDR_DOTL_CONTROL));	//Clear bit
	if(SysInfo.ControllerMode == 8)
	{	
		if(rdno & 0x01)				 
			return;	
		rdno = rdno / 2;
	}
	switch(rdno)
	{   	
		case 0:
			CLR_DOTL(1)
			break;
		case 1:
			CLR_DOTL(2)
			break;
		case 2:
			CLR_DOTL(3)
			break;
		case 3:
			CLR_DOTL(4)
			break;
	}
}

/*** BeginHeader WeigandBuzOn*/
void WeigandBuzOn(unsigned char rdno);
/*** EndHeader */
void WeigandBuzOn(unsigned char rdno)
{
	DRStruct[rdno].F_BuzzerOn = SET;
	DRStruct[rdno].DRControlRdrData |= (0x1<<SL_RDR_BUZ_CONTROL);			//Set bit  
}

/*** BeginHeader WeigandBuzOff*/
void WeigandBuzOff(unsigned char rdno);
/*** EndHeader */
void WeigandBuzOff(unsigned char rdno)
{
	DRStruct[rdno].F_BuzzerOn = CLR;
   
	DRStruct[rdno].DRControlRdrData &= (~(0x1<<SL_RDR_BUZ_CONTROL));		//Clear bit
}

