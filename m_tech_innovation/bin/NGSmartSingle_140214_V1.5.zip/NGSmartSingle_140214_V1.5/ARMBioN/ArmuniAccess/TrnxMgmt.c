#include <stdio.h>
#include <string.h>
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "timer.h"
#include "tranxmgmt.h"
#include "spi.h"
#include "serial.h"
#include "cardmgmt.h"
#include "access.h"
#include "memory.h"
#include "memmap.h"
#include "portlcd.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "IOEventMgmt.h"
#ifdef INSERT_SDCARD
	#include "../../SDCard/fat32.h"
#endif
#include "userIntfGLCD.h"
/*-----------------------------------------------------------------------------------------*/

#define MAX_PAGE_TIMER_SEC		30

#ifdef IMMEDIATE_WRITE_TRANS
	#define READ_WRITE_CHECK
#endif
#define NEW_TRANS_UPDATE_LOGIC

extern BYTE DeabugLevel;

extern _TRANSData UExTrnxData; 
extern RTCTime Datetime;

//extern WORD TransReadPtr,TransWritePtr,TotalNosOfTrans,TotalCards;
extern BYTE PercentageMem;
extern unsigned int TransFreeLocation;
extern BYTE F_TransCrossOver;
extern unsigned char F_SDCardStatus,F_FAT_MemStatus;
extern unsigned char DisplayTempBuffer[50];

/*-------------------------------------------------------------------------------------------*/
/*
1) Write Cross over is used just to indicate that over cross over the memory from 0 to MAX and back to zero
This is used to keep readpointer pointer to proper location if we get error to read all data keep  readpointer to
zero if no cross over and next to writer pointer if we cross over the mem,
2) Write :
	a) go ahead and overwrite memory to current write pointer
    b) increament write pointer
		if write pointer is greater than MAX Memory make write pointer zero and set crossover to 1
			and increament TotalNosTrans
		if write pointer equal to read pointer move read pointer by 1 ( i.e to next location
			do not increament totalNosTrans as new trans is replacing old trans

3) READ:
	a) If readpointer is equal to write pointer indicates that no data available. come out.
	b) Read Data from current read pointer
		if data is not valid increament read pointer and read. Stop if readpointer equal to write pointer.
		Store new readpointer to MEM location and read valid data from current location and send.
	b) Increament readpointer
		if readpointer is greater than MAX Memory make it zero

*/
/*-------------------------------------------------------------------------*/
/* Following function is used to insitialise all transaction initial values 
*/
unsigned char buff[PAGE_SIZE];

void IniTransaction(void)
{
	PageWriteTimer=0;
	CheckPagePointersAndUpdate();
}

int DeleteTransaction(void)
{

   if(DelCurrentTrans()!=0)
   		return(NO_TRANS_TO_DELETE);
   else
		return(0);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader StoreCardInTrDB*/
void StoreCardInTrDB(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event);
/*** EndHeader */
void StoreCardInTrDB(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event)
{	/* in upper page of mem 64k 9326 trnx can be stored*/

	GenerateEvent(event,channelno); 		//FA00070
#ifdef PANK_DEBUG
	TransmitChar('T');
	TransmitChar(HexToAscii(SwapChar(channelno ) & 0x0f));
	TransmitChar(HexToAscii(channelno & 0x0f));
#endif

//	if(cardno != 0)			We have to store card number zero also which we use for invalid finger to store card number
	{
		//Access serial flash 1MB 4095 pages and 264 byte block read write
		UExTrnxData.Chnl = channelno;
		UExTrnxData.Event = event;
		UExTrnxData.CardNo = cardno;
		UExTrnxData.Datetime = Datetime;
#ifdef TRANS_EXTRA_DATA
		if(CurrentUser.SearchCard.CardNo == cardno)						  //ARMD0256
      {
			UExTrnxData.CType = CurrentUser.SearchCard.Info.CType;
			UExTrnxData.InputType = CurrentUser.InputType;
      }
      else
      {
/*         if((Doorinfo.EnDisEMPNoTrnx == 1) && (event == EVENT_EMPNO_TRNX))      //We will implement this when smart card is implemented..
         {
            UExTrnxData.CType = (unsigned char)((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo >> 8);
            UExTrnxData.CType = UExTrnxData.CType & 0xFF;
			UExTrnxData.InputType = (unsigned char) ((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo & 0xFF);
         }
         else*/
         {
         	UExTrnxData.CType = 0;
			UExTrnxData.InputType = 0;
         }
      }
#endif

#ifdef ENABLE_UDP
	   SendUDPTransaction(&UExTrnxData,SER_UDP_PUSH_PORT); //ARMD0409
#endif
			
	if(F_TrnxMemFull == CLR)
		WriteTrans(&UExTrnxData);
	}
#ifdef INSERT_SDCARD	
	if(F_SDCardStatus == 0)
	{
		clearSDbuffer();	 	  
		if(SysInfo.EnableSDWrite !=0)		//NGD0033
			SDStoreTransaction(GLOBAL_PORT);
	}
#endif	
	return;
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader StoreCardInTrDBFull*/
void StoreCardInTrDBFull(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event,unsigned char ctype,unsigned char inputtype);
/*** EndHeader */
void StoreCardInTrDBFull(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event,unsigned char ctype,unsigned char inputtype)
{
	GenerateEvent(event,channelno);      //FA00070

	UExTrnxData.Chnl = channelno;
	UExTrnxData.Event = event;
	UExTrnxData.CardNo = cardno;
	UExTrnxData.Datetime = Datetime;
#ifdef TRANS_EXTRA_DATA
	UExTrnxData.CType = ctype;
	UExTrnxData.InputType = inputtype;
#endif
#ifdef ENABLE_UDP
	SendUDPTransaction(&UExTrnxData,SER_UDP_PUSH_PORT);//ARMD0409
#endif
	
	if(F_TrnxMemFull == CLR)
	{	
		WriteTrans(&UExTrnxData);
	}
#ifdef INSERT_SDCARD	
	clearSDbuffer();	
	if(SysInfo.EnableSDWrite !=0)		//NGD0033
		SDStoreTransaction(GLOBAL_PORT);
#endif	
	return;
}

// void SDStoreTransaction(struct TRNX_DATA *trans,unsigned char port)
// {
// 	
// char err;
// // 	  	 if(GetDataByPosition(bufptr,buffer,3) == NULL) // file name
// // 				 goto ERR_NEW_CMD_TestComand;

// // 				sprintf(SDFileName,"%s",bufptr);
// // 				SDDataLength = strlen(SDFileName);
// // 			 
// // 			 if(GetDataByPosition(bufptr,buffer,4) == NULL)
// // 				  goto ERR_NEW_CMD_TestComand;
// // 			  sprintf(gaucDataBuf,"%s",bufptr);
// // 			  SDDataLength = strlen(gaucDataBuf);
// 	
// 				sprintf(SDFileName,"%s","130812.txt");
// 				sprintf((char*)gaucDataBuf[0],"%c%c%d%d",trans->Chnl,trans->Event,trans->CardNo,trans->Datetime);
//  			  SDDataLength = strlen(gaucDataBuf);
// 				err = ucFnAppendFile(SDFileName, &gaucDataBuf[0], SDDataLength);	
// 				if(err == 0)
// 				{
// 						TransmitCharToX('c',port);
// 					  TransmitCharToX(',',port);
//   					TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
// 						TransmitNStrToX("Appened Successful",sizeof("Appened Successful"),port);
// 					  TransmitCharToX(',',port);
// 				}
// 				else
// 				{
// //					  goto ERR_NEW_CMD_TestComand;
// 						TransmitCharToX('e',port);
// 						TransmitCharToX(',',port);
// 						SendDecimalToPC3CharToX(err,port);
// 						TransmitCharToX(',',port);
// 						TransmitCheckSumX(port);
// 						TransmitCharToX(',',port);
// 						TransmitCharToX(TERMINATOR,port);
// 				}
// }

#ifdef INSERT_SDCARD
void SDStoreTransaction(unsigned char port)		
{
//_TX_DATE TX_Date;	
	unsigned int filename,wrptr,maxtrans;
	char err;
	memset(DisplayTempBuffer,0,sizeof(DisplayTempBuffer)); ////NGD00028
	if(TransWritePtr%50 == 0)	//NGD00026
		memoryStatistics();  // Limit FAT file System 
	  if(921600 < (TotalSDMem - FreeSDMemory)) //// NGD00027  NGD00155 total mem - fre memory less than 0.9GB (in KByte)
	  {
		  err = ERROR_FAT_FILE_ERR;		// //NG0017
		  MsgPrint(MSG_WARNING,err,"SD FAT File Mem Full");	
		  F_FAT_MemStatus  = 1;	// // NGD00023
	  }
		else			 
		{			
			wrptr =TransWritePtr;
			maxtrans = TotalNosOfTrans;
  			if(wrptr ==0)
				wrptr = MAX_TRANS;
			if(maxtrans>= MAX_TRANS)
				maxtrans= MAX_TRANS;
			else if(maxtrans== 0)
				maxtrans =1;

		 	F_FAT_MemStatus  = 0;	// // NGD00023  
			sprintf((char*)SDFileName,"%02d%02d%02d.txt",UExTrnxData.Datetime.Date.Day,UExTrnxData.Datetime.Date.Month,UExTrnxData.Datetime.Date.Year);//.Day,trans->Datetime.Date.Month,trans->Datetime.Date.Year);				
////NGD00028   NGD00034
			sprintf((char*)DisplayTempBuffer,"#%dT,%d,%d,%010u,%02d%02d%02d,%02d%02d%02d,%d,%d,%d,%d,%d,\n",SysInfo.MySlaveNo,UExTrnxData.Chnl,UExTrnxData.Event,	
			UExTrnxData.CardNo, 
			UExTrnxData.Datetime.Time.Hour,UExTrnxData.Datetime.Time.Min,UExTrnxData.Datetime.Time.Secs, 
			UExTrnxData.Datetime.Date.Day,UExTrnxData.Datetime.Date.Month,UExTrnxData.Datetime.Date.Year,
			(maxtrans-1),(wrptr-1),UExTrnxData.CType,UExTrnxData.InputType,Doorinfo.ControllerNo);
//			TotalNosOfTrans+1,TransWritePtr,0,0,Doorinfo.ControllerNo,port,TERMINATOR );
	
			SDDataLength = strlen((const char*) DisplayTempBuffer);
			err = ucFnSearchFile(SDFileName); // search tx date file is already present
			filename = SDFileName[5] + 10*SDFileName[4] + 100*SDFileName[3] + 1000*SDFileName[2]+ 10000*SDFileName[1] + 100000*SDFileName[0];
			if(err == 1)  // file exist then 1 elseif 0 then not exsist 
			{
				err = ucFnAppendFile(SDFileName,(unsigned char *)&DisplayTempBuffer[0], SDDataLength);	
				if(err == 0)	//NG0017
				{	MsgPrint(MSG_WARNING,filename,"SD txtFile Appended Succesfully");	}
				else
				{MsgPrint(MSG_WARNING,filename,"SD txtFile Appended Fail..");}
			}
			else
			{	 
				err = ucFnSetFile(SDFileName,(unsigned char *)&DisplayTempBuffer[0],SDDataLength); // Will Create a file and 20 bytes will be written
				if(err == 0)	
				{	MsgPrint(MSG_WARNING,filename,"SD txtFile Created Succeddfully");	}
				else
				{ MsgPrint(MSG_WARNING,filename,"SD txtFile not Created ");}
			}
		 }					
}
#endif

/*----------------------------------------------------------------------------------------*/
// PANKAJ NEW CODE STARTS HERE						   
// This gives page number for given read/ write pointer
unsigned int GetPageNoByDataIndex(unsigned int dataindex)
{
unsigned char perpagedata;
	perpagedata = (unsigned char) (PAGE_SIZE / APP_DATA_SIZE);
	return(dataindex / perpagedata);
}

/*----------------------------------------------------------------------------------------*/

// This gives Position of data in the page for given read/ write pointer

unsigned int GetLocInPageFromIndex(unsigned int dataindex)
{
	unsigned int perpagedata;
	perpagedata = PAGE_SIZE / APP_DATA_SIZE;
	return(dataindex % perpagedata);
}
/*---------------------------------------------------------------------------------------*/

int CopyPageToNVRAM(unsigned int pagenumber,BYTE *dataptr)
{
/*	BYTE i ;
	for(i=0;i<PAGE_SIZE;i++)
		BigData[(pagenumber*PAGE_SIZE)+i] = dataptr[i];
	return(0);

*/
   MainMem_BuffWrt(0,1,(BYTE *)dataptr,PAGE_SIZE);
   BuffWrt_MainMem(pagenumber,1);	  
 //  sf_writeRAM(dataptr, 0, PAGE_SIZE);
 //  sf_RAMToPage(pagenumber);
return(0);
}
/*----------------------------------------------------------------------------------------*/
#ifndef IMMEDIATE_WRITE_TRANS												 
int CopyCurrentPageToNVRAM()
{
	WritePage.PageStatus = PAGE_STATUS_UPDATED;
	if( CopyPageToNVRAM(WritePage.PageNo,WritePage.PBuffer) !=0)
	   	return(-1);
	WritePage.PageStatus = PAGE_STATUS_SAVED;
   	MsgPrint(MSG_WARNING,WritePage.PageNo,"Write Current Page to NVRAM PageNo =");
	return(0);
}
#endif
/*---------------------------------------------------------------------------------------*/

int CopyFromNVRAMToBuffer(unsigned int pagenumber,unsigned char *dataptr)
{	
//	unsigned int i;
   	MsgPrint(MSG_WARNING,pagenumber,"CopyFromNVRAMToBuffer  =");
 	MainMem_ReadPage(pagenumber,0,dataptr,PAGE_SIZE);
   	MsgPrint(MSG_WARNING,PAGE_SIZE,"CopyFromNVRAMToBuffer 2 =");
/*	for(i=0;i<PAGE_SIZE;i++)
		MsgPrint(MSG_MEM,dataptr[i],"TRNX:Trnx Buffer Data Read =");	*/
	return(0);
}
/*---------------------------------------------------------------------------------------*/

int WriteData(unsigned int writeindex, BYTE *dataptr)
{
	unsigned int pagenumber;
	unsigned int *pInt1=NULL;
	BYTE *pByte1=NULL, *pByte2 = NULL;
	short c=0;
//	unsigned char buff[PAGE_SIZE];	
F_FlashSelect = 1;	
#ifdef IMMEDIATE_WRITE_TRANS									
	pagenumber = TRANS_DATA_BASE + GetPageNoByDataIndex(writeindex);
	CopyFromNVRAMToBuffer(pagenumber,buff);

	#ifdef READ_WRITE_CHECK
		pInt1=(unsigned int*)buff;
		if(*pInt1 == 0xFFFFFFFFL)//check 1st 4byte
		{
			CopyFromNVRAMToBuffer(pagenumber,buff);	//read again same page if 8 bytes are ff
		}
		else 
		{
			++pInt1;
			if(*pInt1 == 0xFFFFFFFFL)//check next 4byte
			{
				CopyFromNVRAMToBuffer(pagenumber,buff);	//read again same page if 8 bytes are ff
			}
		}
	#endif //#ifdef READ_WRITE_CHECK

	memcpy(&buff[GetLocInPageFromIndex(writeindex)*APP_DATA_SIZE],dataptr,APP_DATA_SIZE);   
   	MainMem_BuffWrt(0,1,buff,PAGE_SIZE);
   	BuffWrt_MainMem(pagenumber,1);

	#ifdef READ_WRITE_CHECK
		pByte2 = (BYTE *)dataptr; //actual data to write
		CopyFromNVRAMToBuffer(pagenumber,buff);//read writen data
		pByte1 = (BYTE *)(&buff[GetLocInPageFromIndex(writeindex)*APP_DATA_SIZE]);//data from flash

		for(c=0; c<APP_DATA_SIZE ; c++)
		{
			if( pByte1[c] != pByte2[c] )//comparison fail
			{	//write again
				memcpy(&buff[GetLocInPageFromIndex(writeindex)*APP_DATA_SIZE],dataptr,APP_DATA_SIZE);   
			   	MainMem_BuffWrt(0,1,buff,PAGE_SIZE);
			   	BuffWrt_MainMem(pagenumber,1);
				break;
			}	
		}

	#endif //#ifdef READ_WRITE_CHECK

#else//#ifdef IMMEDIATE_WRITE_TRANS							   
//	unsigned int pagenumber;
#ifdef NEW_TRANS_UPDATE_LOGIC
	unsigned int chksum,i;
   	unsigned char *wrpagechar;
#endif//#ifdef NEW_TRANS_UPDATE_LOGIC
	pagenumber = TRANS_DATA_BASE + GetPageNoByDataIndex(writeindex);
	if(pagenumber != WritePage.PageNo)
	{
		if(WritePage.PageStatus == PAGE_STATUS_UPDATED)
		{
      		// This indicates current page is updated and we need to save same before taking new page in to this buffer
			if(CopyCurrentPageToNVRAM() ==-1)
         		return(-1);
		}
		CopyFromNVRAMToBuffer(pagenumber,WritePage.PBuffer);
      	WritePage.PageStatus = PAGE_STATUS_NEW;
		WritePage.PageNo = pagenumber;
#ifdef NEW_TRANS_UPDATE_LOGIC
      	WritePage.Index = writeindex;
#endif//#ifdef NEW_TRANS_UPDATE_LOGIC
	}
	memcpy(	(char *) &WritePage.PBuffer[GetLocInPageFromIndex(writeindex)*APP_DATA_SIZE],dataptr,APP_DATA_SIZE);
   	WritePage.PageStatus = PAGE_STATUS_UPDATED;

#ifdef NEW_TRANS_UPDATE_LOGIC
	wrpagechar = (unsigned char *)&WritePage;
	WritePage.ChkSum =0;
   	chksum = 0;
	for(i=0;i<sizeof(WritePage);i++)
   		chksum = chksum + wrpagechar[i];
	chksum = chksum + CHK_SUM_MOD_VALUE;
	WritePage.ChkSum = chksum;
#endif//#ifdef NEW_TRANS_UPDATE_LOGIC
	if(WritePage.PageNo == ReadPage.PageNo)
	{
		memcpy((char *) &ReadPage.PBuffer[GetLocInPageFromIndex(writeindex)*APP_DATA_SIZE],dataptr,APP_DATA_SIZE);
	}
	PageWriteTimer =0;
#endif//#ifdef IMMEDIATE_WRITE_TRANS
F_FlashSelect = 0;
	return(0);
}

/*----------------------------------------------------------------------------------------*/

unsigned int ReadData(unsigned int readindex, BYTE *dataptr)						   
{
	unsigned int pagenumber;
	unsigned int *pInt1=NULL;
F_FlashSelect = 1;
#ifdef IMMEDIATE_WRITE_TRANS
//	unsigned char buff[PAGE_SIZE];	
	pagenumber = TRANS_DATA_BASE + GetPageNoByDataIndex(readindex);
	CopyFromNVRAMToBuffer(pagenumber,buff);
	#ifdef READ_WRITE_CHECK
		pInt1=(unsigned int*)buff;
		if(*pInt1 == 0xFFFFFFFFL)//check 1st 4byte
		{
			CopyFromNVRAMToBuffer(pagenumber,buff);	//read again same page if 8 bytes are ff
		}
		else 
		{
			++pInt1;
			if(*pInt1 == 0xFFFFFFFFL)//check next 4byte
			{
				CopyFromNVRAMToBuffer(pagenumber,buff);	//read again same page if 8 bytes are ff
			}
		}
	#endif //#ifdef READ_WRITE_CHECK
	memcpy(dataptr,(char *)&buff[GetLocInPageFromIndex(readindex)*APP_DATA_SIZE],APP_DATA_SIZE);
#else  //#ifdef IMMEDIATE_WRITE_TRANS
	pagenumber = TRANS_DATA_BASE + GetPageNoByDataIndex(readindex);
	MsgPrint(MSG_WARNING,readindex,"Read index = ");
	if(pagenumber != ReadPage.PageNo)
	{																   
		if(pagenumber == WritePage.PageNo)
		{  
			MsgPrint(MSG_WARNING,pagenumber,"Read Page present in write Buffer \n");
			memcpy(ReadPage.PBuffer,WritePage.PBuffer,PAGE_SIZE);
		}
		else
		{
			CopyFromNVRAMToBuffer(pagenumber,ReadPage.PBuffer);
		}
		ReadPage.PageNo = pagenumber;
	}
	memcpy(dataptr,(char *)&ReadPage.PBuffer[GetLocInPageFromIndex(readindex)*APP_DATA_SIZE],APP_DATA_SIZE);
//	for(temp=0; temp<APP_DATA_SIZE; temp++)
//   		MsgPrint(MSG_MEM,dataptr[temp],"TRNX:Data Ptr=");	
#endif	//#else  //#ifdef IMMEDIATE_WRITE_TRANS
F_FlashSelect = 0;
	return(0);
}

/*----------------------------------------------------------------------------------------*/

unsigned int WriteTrans(_TRANSData *trans)
{
//unsigned int oldwriteptr;
#ifndef IMMEDIATE_WRITE_TRANS
int status;							// just to take care of warning...
	status = WriteData(TransWritePtr,(unsigned char *) trans);
//   	WDTHandleType = WDT_WRITE_TRANS;
	if(status == -1)     //status is always 0 so no need to check
   	{
   		F_BadPage = SET; //FA00050			  
	   	BadPageNumber = WritePage.PageNo;
// Indicates that we are not able to write transaction so we need to write page to next page location and update all pointers.. properly.
//		printf("********* ERROR WE ARE NOT ABLE TO WRITE DATA TO FLASH AT POINTER %d  PAGE LOCATION %d *********** \n",TransWritePtr,WritePage.PageNo);
 		L_DisplayROMStr("ERROR: FLASH WR",16,ROW_USER_FUNCTION);
 		L_DisplayROMStr("PAGENO:           ",16,ROW_CARD_ERROR_DISP);
		L_DisplayDecimalInteger(WritePage.PageNo,8,ROW_CARD_ERROR_DISP);
		F_TempCounterStart = SET;
	   	Temp_Time_Counter=0;
//		VdHitWd(WatchDogHndl);
      	while(Temp_Time_Counter < 4) 
			MakeSound(SOUND_CARD_NOT_FOUND);
      	oldwriteptr = TransWritePtr;
      	TransWritePtr = TransWritePtr + (PAGE_SIZE / APP_DATA_SIZE);
		if(TransWritePtr >=MAX_TRANS)
      	{
      		// As TransWritePtr is torated so we will store page no 0th transaction pagelocation.
	      	TransWritePtr =  (PAGE_SIZE / APP_DATA_SIZE);
	      	F_TransCrossOver = 1;
			WritePage.PageNo = TRANS_DATA_BASE + 0;
         	if(TransReadPtr < TransWritePtr)
				TransReadPtr = TransWritePtr;
      	}
      	else
      	{
			WritePage.PageNo = WritePage.PageNo + 1;
	      	if((TransReadPtr>=oldwriteptr)&&(TransReadPtr<=TransWritePtr))
	      	{
         		// Check if Readpointer is in between oldwriteptr and new write ptr
            	// which indicates we need to move readptr next to writeptr
	         	TransReadPtr =TransWritePtr;
	      	}
      	}
		ReadPage.PageNo = 0xFFFF; // This is just t re-validate ReadPage buffer
		 //and we read data again from flash or from write Page
		if(WriteData(TransWritePtr,(unsigned char *) trans) == -1)
      	{
//	   		printf("********* ERROR WE ARE NOT ABLE TO WRITE DATA TO FLASH AT POINTER %d  PAGE LOCATION %d *********** \n",TransWritePtr,WritePage.PageNo);
	   		L_DisplayROMStr("ERROR:FLASH BAD",16,ROW_USER_FUNCTION);    //FA00050
	      	L_DisplayROMStr("PAGENO:           ",16,ROW_CARD_ERROR_DISP);
	      	L_DisplayDecimalInteger(WritePage.PageNo,8,ROW_CARD_ERROR_DISP);
	      	F_TempCounterStart = SET;
	      	Temp_Time_Counter=0;
//			VdHitWd(WatchDogHndl);
	      	while(Temp_Time_Counter <4 ) 
  				MakeSound(SOUND_CARD_NOT_FOUND);
      	}
	}	
#endif
	WriteData(TransWritePtr,(unsigned char *) trans);
	TransWritePtr++;
	if(TransWritePtr >=MAX_TRANS)
	{
		TransWritePtr = 0;
      	F_TransCrossOver = 1;
	}
	if(TransReadPtr == TransWritePtr)
	{
		/* indicates that we have to overwrite old read transactions */
		TransReadPtr++;
		if(TransReadPtr >=MAX_TRANS)
		{
			TransReadPtr = 0;
		}
	}
	else
	{
		TotalNosOfTrans ++;
		if(TotalNosOfTrans>= MAX_TRANS)
			TotalNosOfTrans= MAX_TRANS-1;
	}
	return(TransWritePtr);
}

/*----------------------------------------------------------------------------------------*/

unsigned int ReadTrans(_TRANSData *trans,unsigned int readptr)
{
		ReadData(readptr,(BYTE *)trans);	  // should not keep & this is bug :-(
		return(0);
}
/*----------------------------------------------------------------------------------------*/

int DelCurrentTrans(void)
{
	if(TransReadPtr != TransWritePtr)
	{
		TransReadPtr++;					 
		if(TransReadPtr >=MAX_TRANS)
		{
			TransReadPtr = 0;
		}
		if(TotalNosOfTrans !=0)
			TotalNosOfTrans --;
	}
	else
	{
		return(-1);
	}
	return(0);
}

/*----------------------------------------------------------------------------------------*/

int ReadDelTrans(_TRANSData trans)
{
	if(TransReadPtr != TransWritePtr)
	{
//		F_FlashSelect = 1;
		ReadData(TransReadPtr,(BYTE *)&trans);
		TransReadPtr++;
//		F_FlashSelect = 0;
		if(TransReadPtr >=MAX_TRANS)
		{
			TransReadPtr = 0;
		}
		if(TotalNosOfTrans !=0)
			TotalNosOfTrans --;
	}
	else
	{
		return(-1);
	}
	return(0);
}

/*----------------------------------------------------------------------------------------*/

int ReadCurrentTransaction(_TRANSData *trans)
{	//BYTE temp;
		
	// MsgPrint(MSG_MEM,TransReadPtr,"READ TRNX:TransReadPtr =");	
	//  MsgPrint(MSG_MEM,TransWritePtr,"READ TRNX:TransWritePtr =");		
	if(TransReadPtr >MAX_TRANS)
		return(-1);
	if(TransReadPtr != TransWritePtr)
	{
		ReadData(TransReadPtr,(BYTE *)trans);
		MsgPrint(MSG_MEM,trans->CardNo,"READ TRNX:cardNo =");	
		UExTrnxData = 	*trans;
	}
	else	   
	{
		return(-1);
	}
	return(0);
}

/*----------------------------------------------------------------------------------------*/
unsigned int CheckPagePointersAndUpdate(void)
{
// unsigned int pagenumber;
// #ifdef NEW_TRANS_UPDATE_LOGIC
// 	unsigned char *wrpagechar;
//    unsigned int chksum,chksumold,i;
// #endif

	if(TransReadPtr>MAX_TRANS)
		TransReadPtr=0;
	if(TransWritePtr>MAX_TRANS)
		TransWritePtr=0;

// 	pagenumber = TRANS_DATA_BASE + GetPageNoByDataIndex(TransWritePtr);     //Added base addess
// 	if( WritePage.PageNo == pagenumber)
// 	{  
//    		MsgPrint(1,TransWritePtr,"Page number maches with TransWritePtr = \n");
// #ifdef NEW_TRANS_UPDATE_LOGIC
// 	   wrpagechar = (unsigned char *)&WritePage;
// 	   chksumold = WritePage.ChkSum;
// 	   WritePage.ChkSum =0;
// 	   chksum = 0;
// 	   for(i=0;i<sizeof(WritePage);i++)
// 	      chksum = chksum + wrpagechar[i];
// 	   chksum = chksum + CHK_SUM_MOD_VALUE;
// 	   if(chksumold != chksum)
// 	   {
//          	MsgPrint(1,chksum,"****ERROR WRITE TRANS CACHE CHKSUM DO NOT MATCH checksum ***\n");
// 			CopyFromNVRAMToBuffer(pagenumber,WritePage.PBuffer);
// 	      	wrpagechar = (unsigned char *)&WritePage;
// 	      	chksumold = WritePage.ChkSum;
// 	      	WritePage.ChkSum =0;
// 	      	chksum = 0;
// 	      	for(i=0;i<sizeof(WritePage);i++)
// 	         	chksum = chksum + wrpagechar[i];
// 	      	chksum = chksum + CHK_SUM_MOD_VALUE;
//       }
// 	   else
// 	      MsgPrint(1,chksumold,"WRITE TRANS CACHE CHKSUM MATCH New chksumold \n");
// 	   WritePage.ChkSum = chksum;
// #endif

//    }
//    else
//    {
// 		MsgPrint(1,WritePage.PageNo,"ERROR: Page do not maches with WritePage.PageNo");
// 		MsgPrint(1,WritePage.PageStatus,"ERROR: Page do not maches with WritePage.PageStatus");
//       	if(WritePage.PageStatus > PAGE_STATUS_MAX)
//       	{
//       		MsgPrint(1,WritePage.PageStatus,"Page is Bad Page as status is invalidWritePage.PageStatus \n");
//          // Read WritePage as per current TransWritePtr
// 			CopyFromNVRAMToBuffer(pagenumber,WritePage.PBuffer);
//    	   		WritePage.PageStatus = PAGE_STATUS_NEW;
// 			WritePage.PageNo = pagenumber;
//       	}
//       	else if((WritePage.PageStatus == PAGE_STATUS_NEW)||(WritePage.PageStatus == PAGE_STATUS_SAVED))
//       	{ 
// 			MsgPrint(1,WritePage.PageStatus,"2 Page is Bad Page as status is invalidWritePage \n");
// 			CopyFromNVRAMToBuffer(pagenumber,WritePage.PBuffer);
//    	   		WritePage.PageStatus = PAGE_STATUS_NEW;
// 			WritePage.PageNo = pagenumber;
//       	}
//       	else if(WritePage.PageStatus == PAGE_STATUS_UPDATED)
//       	{
// 			MsgPrint(1,WritePage.PageStatus,"3 Page is Bad Page as status is invalidWritePage \n");
// 			CopyFromNVRAMToBuffer(pagenumber,WritePage.PBuffer);
//    	   		WritePage.PageStatus = PAGE_STATUS_NEW;
// 			WritePage.PageNo = pagenumber;
//       	}
//    }
// #ifndef IMMEDIATE_WRITE_TRANS
// // In all case read Readcache data form write cache or from Flash
//    		ReadPage.PageNo  = TRANS_DATA_BASE + GetPageNoByDataIndex(TransReadPtr);			//FA00033  //Added base address
// // Added code to re-read read page from Flash or from Write Cache.
// 		if(ReadPage.PageNo == WritePage.PageNo)
// 		{  
// 			MsgPrint(1,0,"Read Page present in write Buffer \n");
// 			memcpy(ReadPage.PBuffer,WritePage.PBuffer,PAGE_SIZE);
// 		}
// 		else
// 		{
// 			MsgPrint(1,WritePage.PageStatus,"Read Read Page from FLASH  \n");
// 			CopyFromNVRAMToBuffer(ReadPage.PageNo,&ReadPage.PBuffer[0]);
// 		}
// #endif
// 	MsgPrint(1,TransWritePtr,"CheckPagePointersAndUpdate Complete = \n");
	return(0);
}

/*----------------------------------------------------------------------------------------*/
unsigned int GetPercentageFull(unsigned int readptr,unsigned int writeptr)
{
	BYTE percentage;
	if(readptr == writeptr)
		return(0);
	if(readptr > writeptr )
	{
		readptr = readptr - writeptr ;
		percentage = (BYTE) ( (long)(MAX_TRANS- readptr)*(long)100/MAX_TRANS) ;
	}
	else
	{
		readptr = writeptr - readptr;
		percentage = ((long) readptr*(long)100/MAX_TRANS);
	}
	TransFreeLocation = readptr;
	return(percentage);
}



void HandelSerialSendTrans(_TRANSData trans)
{

      TransmitChar('T');
      TransmitChar((trans.Chnl)+'0');
      SendDecimalToPC(trans.Event);
/*      if(F_Facility)
	   {  F_Facility = CLR;
      	SendDecimalToPC3Char(trans->Facility);

      }
*/
      SendDecimalIntToPC(trans.CardNo);
      SendDecimalToPC(trans.Datetime.Time.Hour);
      SendDecimalToPC(trans.Datetime.Time.Min);
      SendDecimalToPC(trans.Datetime.Time.Secs);
      SendDecimalToPC(trans.Datetime.Date.Day);
      SendDecimalToPC(trans.Datetime.Date.Month);
      SendDecimalToPC(trans.Datetime.Date.Year);
      SendDecimalLongToX6digit(TotalNosOfTrans,GLOBAL_PORT);
}

// Following function will get number transaction which are pending in buffer to be sent to PC/ Server
/*** BeginHeader GetPendingTrans*/
unsigned int GetPendingTrans(unsigned int readptr,unsigned int writeptr);
/*** EndHeader */
unsigned int GetPendingTrans(unsigned int readptr,unsigned int writeptr)
{
	if(readptr == writeptr)
		return(0);
	if(readptr > writeptr )
	{
		return(MAX_TRANS -(readptr - writeptr));
	}
	else
	{
		return(writeptr - readptr);
	}
}

#ifndef IMMEDIATE_WRITE_TRANS
/*
Update Write cache to Flash every 10 min [ currently hardcoded] so that we have backup done in flash
We will update only if Page status is PAGE_STATUS_UPDATED
*/


// Following function will get number transaction which are pending in buffer to be sent to PC/ Server
/*** BeginHeader UpdateWritePage*/
void UpdateWritePage(void);
/*** EndHeader */
void UpdateWritePage(void)
{
	if(PageWriteTimer >= MAX_PAGE_TIMER_SEC)
   {
   		PageWriteTimer =0;
  		if(WritePage.PageStatus == PAGE_STATUS_UPDATED)
      	{
//     		printf("SAVE: Save write cached to eeprom \n");
       		CopyCurrentPageToNVRAM();
			WritePage.PageStatus = PAGE_STATUS_SAVED;
			PageWriteTimer =0;
      	}
   }
}
#endif

