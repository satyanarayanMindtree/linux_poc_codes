

#include <stdio.h>
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include <string.h>
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "spi.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "Cardmgmt.h"
#include "Serial.h"
#include "userIntfGLCD.h"
#include "userIntf.h"
#include "timer.h"
//#include "button.h"
#include "../../GLCD/BMPImage/button.h"
#include "../../GLCD/BMPImage/sea3_565.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusans9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusansbold9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusanscondensed9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/veramonobold11.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerifBold20.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif22pts_Bold.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif20pts.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerifBold16.h"
#include "../../GLCD/drivers/lcd/tft/fonts/OCR_A_Extended_16.h"
#include "../../GLCD/drivers/lcd/tft/bmp.h"
#include "../../GLCD/drivers/lcd/tft/hw/ssd2119_8bit.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif26ptsBold_Time.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif48pts_Bold.h"
#include "../../GLCD/drivers/lcd/tft/fonts/NewMicrosoftSansSerif36ptsBold.h"
#ifdef SUPPORT_SPEECHIC
	#include "DriverSpeech_IC.h"
#endif
#include "portlcd.h"
#include "../../GLCD/BMPImage/icon.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif

static int Temp1,Temp2,Temp3;
extern SYSInfo SysInfo;
extern unsigned char F_authScreenTimer,F_authScreenTimerEnable;				
struct RADIO_SCROLL_DATA stRadioScrollData;

extern const char WEEK_DAY[7][4];
unsigned char CurrentMenu=0;
struct TOUCHKEYDATA
{
	unsigned short x0,y0;//x,y co-ordinate for each keys. 
	char *str1, *str2; //string of button for different mode.
};
const struct TOUCHKEYDATA TouchKeyData[5]={
	{TOUCH_KEY1_X0, TOUCH_KEY1_Y0, "Home","Home"},
	{TOUCH_KEY2_X0, TOUCH_KEY2_Y0, "Up","Up"},
	{TOUCH_KEY3_X0, TOUCH_KEY3_Y0, "Select","Select"},
	{TOUCH_KEY4_X0, TOUCH_KEY4_Y0, "Down","Down"},
	{TOUCH_KEY5_X0, TOUCH_KEY5_Y0, "Back","Back"}	
};

const unsigned short GridIconPosition[][2]={
	{GRID_ICON1_X0,	GRID_ICON1_Y0}, //icon 1
	{GRID_ICON2_X0,	GRID_ICON2_Y0}, //icon 2
	{GRID_ICON3_X0,	GRID_ICON3_Y0}, //icon 3
	{GRID_ICON4_X0,	GRID_ICON4_Y0}, //icon 4
	{GRID_ICON5_X0,	GRID_ICON5_Y0}, //icon 5
	{GRID_ICON6_X0,	GRID_ICON6_Y0}, //icon 6
	{GRID_ICON7_X0,	GRID_ICON7_Y0}, //icon 7
	{GRID_ICON8_X0,	GRID_ICON8_Y0}, //icon 8

	{GRID_ICON1_NAME_X0,	GRID_ICON1_NAME_Y0}, //icon Name 1
	{GRID_ICON2_NAME_X0,	GRID_ICON2_NAME_Y0}, //icon Name 2	
	{GRID_ICON3_NAME_X0,	GRID_ICON3_NAME_Y0}, //icon Name 3	
	{GRID_ICON4_NAME_X0,	GRID_ICON4_NAME_Y0}, //icon Name 4
	{GRID_ICON5_NAME_X0,	GRID_ICON5_NAME_Y0}, //icon Name 5
	{GRID_ICON6_NAME_X0,	GRID_ICON6_NAME_Y0}, //icon Name 6
	{GRID_ICON7_NAME_X0,	GRID_ICON7_NAME_Y0}, //icon Name 7
	{GRID_ICON8_NAME_X0,	GRID_ICON8_NAME_Y0} //icon Name 8
	
//	{GRID_ICON9_X0,	GRID_ICON9_Y0}  //icon 9
};
struct structTouchKeyPad TouchKeyPad;
struct DISPLAY_DATA DisplayData;
//unsigned char CurrentFormat;
struct SCROLL_MENU_DATA ScrollMenuData;
extern unsigned char DisplayTempBuffer[50];
struct SCREEN_FORMAT_DATA ScreenFormatData;
extern struct stUserIntf UserIntfData;

// __packed struct RectInfo
// {
// 	unsigned char FillType;
// 	uint16_t	Color;
//    	uint16_t	Hight;
// 	uint16_t	Width;
// 	uint16_t	BorderColor;
// };
struct RectInfo	HighlightRect = {RCTFILL_PLAIN,COLOR_YELLOW,14,320};//FillType,Color,Hight,Width
const struct stSCROLL_DATA SCROLL_DATA ={
	COLOR_BLUE,
	COLOR_BLACK,
	COLOR_GREEN,
	&microsoftSansSerif_16ptFontInfo,
	&bitstreamVeraSansMonoBold11ptFontInfo,
	&HighlightRect,
	{{USER_LINE3_START_X0,USER_LINE3_START_Y0},
	{USER_LINE4_START_X0,USER_LINE4_START_Y0},
	{USER_LINE5_START_X0,USER_LINE5_START_Y0},
	{USER_LINE6_START_X0,USER_LINE6_START_Y0},
	{USER_LINE7_START_X0,USER_LINE7_START_Y0}} };

//drawString(xStart, yStart, pressed ? fontactive : font, &*fontInfo, text);
//void drawString(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo, char *str)

//  status 						timedate						background					ststusmsg     	
const struct Theme_Colour ThemeColour [MAX_THEME] = {
		{COLOR_WHITE ,
			COLOR_RED_MODIFIED1 ,
			COLOR_WHITE ,
			COLOR_BLACK,
			COLOR_RED_MODIFIED1, 
			COLOR_WHITE ,
			COLOR_WHITE,
			COLOR_MAGENTA,
			COLOR_WHITE,
//			COLOR_BLACK,
			COLOR_BLACK},
		{COLOR_WHITE ,
			COLOR_RED_MODIFIED2,
			COLOR_WHITE ,
			COLOR_BLACK,
			COLOR_RED_MODIFIED2, 
			COLOR_WHITE,
			COLOR_WHITE,
			COLOR_STEELBLUE,
			COLOR_WHITE,
//			COLOR_BLACK,
			COLOR_BLACK},
		{COLOR_WHITE ,
			COLOR_RED_MODIFIED,
			COLOR_WHITE ,
			COLOR_BLACK,
			COLOR_RED_MODIFIED, 
			COLOR_BLACK,
			COLOR_WHITE,
			COLOR_RED,
			COLOR_WHITE,
//			COLOR_BLACK,
			COLOR_BLACK},
//		{COLOR_CORAL ,COLOR_ORANGERED ,COLOR_CORAL ,COLOR_ORANGERED},	
		{COLOR_WHITE ,
			COLOR_RED_MODIFIED3, 
			COLOR_WHITE, 
			COLOR_BLACK,
			COLOR_RED_MODIFIED3, 
			COLOR_WHITE,
			COLOR_WHITE,
			COLOR_LIME,
			COLOR_WHITE,
//			COLOR_BLACK,
			COLOR_BLACK}
	};
const struct Theme_Select ThemeSelect = {
	STATUSBAR_HEIGHT,
	STATUSBAR_WIDTH,
	STATUSBAR_X0,
	STATUSBAR_Y0,
	
	DISP_DATETIME_HEIGHT,
	DISP_DATETIME_WIDTH,
	DISP_DATETIME_X0,
	DISP_DATETIME_Y0,
	
	WALLPAPER_HEIGHT,
	WALLPAPER_WIDTH,
	WALLPAPER_X0,
	WALLPAPER_Y0,
	
	DISP_STATUSMSGHEIGHT_HEIGHT,
	DISP_STATUSMSGHEIGHT_WIDTH,
	DISP_STATUSMSGHEIGHT_X0,
	DISP_STATUSMSGHEIGHT_Y0,
	
	TITLEMSG_HEIGHT,
	TITLEMSG_WEIGHT,
	DISP_TITLEMSG_X0,
	DISP_TITLEMSG_Y0
	};
	
void HandleCardDigit(unsigned char keytype);
	
//gird view is like this.
// icon1	icon2	icon3
// icon4	icon5	icon6
// icon7	icon8	icon9
const struct MENU_GROUP_S UserInt1[MAX_DISPLAY_NEWMODE_MEMBER] = 
{
//ModeNo,      	DeviceOpMode		,GroupNo    , DSPMode				,SpKey 	,MenuName[]     	, *EvFunction			,IconInfo,Admin
{100 			,U_WELCOME   		,0			,0						,0		,"Welcome"			,HandleWelcomeMode		,0		,BIT_ANY_ADMIN	},	
//this handles main menu grid view.
{101 			,U_WELCOME   		,0			,0						,0		,"Welcome"			,HandleGridView			,0		,BIT_ANY_ADMIN	},	

//icon 1
//////////////////user setting GROUP
	{102 		,U_WELCOME     		,G_CARD		, 0						,0		,"Admin"			,HandleSubMenuScroll	,1		,BIT_ANY_ADMIN	},
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Set Time"			,HandleSetTime			,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN},
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Set Date"			,HandleSetDate			,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN},
//		{103 	,U_WELCOME			,G_CARD		,MODE_ADMIN_ADD_DEL		,0		,"Add/Delete Admin ID",HandleUserAdminAddDel,0		,BIT_SUPER_ADMIN},	
		{103 	,U_WELCOME			,G_CARD		,MODE_ADMIN_ADD			,0		,"Add Admin ID"		,HandleUserAdminAdd,0		,BIT_SUPER_ADMIN},	
		{103 	,U_WELCOME			,G_CARD		,MODE_ADMIN_DEL			,0		,"Delete Admin ID"	,HandleUserAdminDel,0		,BIT_SUPER_ADMIN},	
		{103 	,U_WELCOME			,G_CARD		,MODE_ADMIN_CHANGE		,0		,"Change Password"	,HandleUserAdminChange,0		,BIT_SUPER_ADMIN},	
#ifdef INSERT_SDCARD
//		{103 	,U_WELCOME			,G_BILLING	,0						,0		,ADM_USR			,"Scroll Images",ScrollBmpImage			,0	},	  	
#endif
//icon 2
//////////////////card management GROUP
  	{102 		,U_WELCOME			,G_BILLING  ,0						,0		,"User"				,HandleSubMenuScroll	,2		,BIT_ANY_ADMIN},
#ifdef BIO_METRIC
		{103 	,U_WELCOME			,G_BILLING	,MODE_ADD_CARD			,0		,"Add User"			,HandleAddCardKeyBio	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN},
#else
		{103 	,U_WELCOME			,G_BILLING	,MODE_ADD_CARD			,0		,"Add User"			,HandleAddCardKey		,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN},
#endif
		{103 	,U_WELCOME			,G_BILLING	,MODE_DEL_CARD			,0		,"Del User"			,HandleDelCardKey		,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN},	  
		{103 	,U_WELCOME			,G_BILLING	,MODE_SEARCH_CARD		,0		,"Search User"		,HandleSearchCardKey			,0	,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
#ifndef BIO_METRIC
		{103 	,U_WELCOME			,G_BILLING	,MODE_BULK_ADD_CARD		,0		,"Bulk Add Card"	,HandleBulkCardAddDelkey,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN},	  
#endif
		{103 	,U_WELCOME			,G_CARD		,MODE_CHANGE_PIN		,0		,"Change Pin"		,HandleChangePinKey		,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN		},
		{103 	,U_WELCOME			,G_BILLING	,MODE_CARD_ADD_DATA		,0		,"Add User Data"	,HandleCardData			,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN},	  
#ifdef BIO_METRIC
		{103 	,U_WELCOME			,G_BILLING	,MODE_ADD_FINGER_TO_ID	,0		,"AddFing To ID"	,HandleAddFingerToId	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN},	  
#endif
#ifndef BIOLITE_LOW_END
		{103 	,U_WELCOME			,G_BILLING	,MODE_FACILITY_CODE		,0		,"Facility Code"	,HandleFacilityCode		,0		,BIT_SUPER_ADMIN | BIT_ADMIN},	  
#endif
#ifdef ENABLE_DUAL_AUTH
		{103 	,U_WELCOME			,G_BILLING	,MODE_DUA_SEARCH_CARD		,0	,"DUA SearchCard"	,HandleDUASearchCard		,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
#endif //#ifdef ENABLE_DUAL_AUTH
		
//icon 3
/////////////////// help menu
  	{102 		,U_WELCOME			,G_BILLING  , 0						,0		,"System"			,HandleSubMenuScroll	,3		,BIT_ANY_ADMIN},
		{103 	,U_WELCOME			,G_BILLING	, 0						,0		,"Set slave ID"		,HandleMultiFuncSlaveNoSet,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN },	  
		{103 	,U_WELCOME			,G_BILLING	, 0						,0		,"Set controller No.",HandleControllerNo	,0		,BIT_SUPER_ADMIN},	  
#ifdef BIO_METRIC
		{103 	,U_WELCOME			,G_BILLING	, 0						,0		,"Sensor security level",HandleSecurityLevelMode,0	,BIT_SUPER_ADMIN | BIT_ADMIN },	  
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Identify Mode"	,HandleIdentifyMode		,0		,BIT_SUPER_ADMIN | BIT_ADMIN },	  
#endif							
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Controller type"	,HandleControllerType	,0		,BIT_SUPER_ADMIN | BIT_ADMIN },	  
		{103	,U_WELCOME			,G_CARD		, 0						,0		,"Weigand bits"		,HandleWeigandType		,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },	  
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Card digit display",HandleCardDigit		,0		,BIT_SUPER_ADMIN},	  
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Calibrate Touch ",HandleCalibrateTouch	,0		,BIT_SUPER_ADMIN},	  
#ifdef INSERT_SDCARD
		{103 	,U_WELCOME			,G_CARD		, 0						,0		,"Del Transaction SD",HandleDeleteSDTrans	,0		,BIT_SUPER_ADMIN},	  
#endif		
	//icon 4  
///////////////////
  	{102 		,U_WELCOME			,G_BILLING  , 0						,0		,"Network"			,HandleSubMenuScroll	,4		,BIT_ANY_ADMIN},
		{103 	,U_WELCOME			,G_BILLING	, 0						,0		,"Network setting"	,HandleSubMenuScroll	,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"IP Address"		,HandleIpSetting		,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Subnet Mask"		,HandleSubnetMask		,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Gateway"			,HandleGateway			,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Local TCP Port"	,HandleLocalport		,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Local UDP Port"	,HandleUDPport			,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Server IP"		,HandleServerIP			,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Push Server1 IP"	,HandlePushServer1IP	,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Push Server1 Port",HandlePushServer1Port	,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Push Server2 IP"	,HandlePushServer2IP	,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Push Server2 Port",HandlePushServer2Port	,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"UDP PushServer IP",HandleUDPServerIP		,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"UDP PushServer Port",HandleUDPServerPort	,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"HB Server IP"		,HandleHBServerIP		,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
 			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"HB Server Port"	,HandleHBServerPort		,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"HB Time"			,HandleHBTime			,0		,BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},	  
		{103 ,U_WELCOME				,G_BILLING	,MODE_WEI_CARD_DISPLAY	,0		,"MAC Security EN/DS"  ,HandleServerMACEnDis	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
//		{103 ,U_WELCOME				,G_BILLING	,MODE_WEI_CARD_DISPLAY	,0		,"Server Auth Check",HandleAuthServerIpSetting	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
#ifdef ENABLE_SERVER_AUTH
		{103 ,U_WELCOME				,G_BILLING	,0	,0		,"Server Authentication",HandleSubMenuScroll	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  		
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Server Auth EN/DI"  ,HandleAuthServerEnDi	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Auth Ser1 IP"  ,HandleAuthServer1Ip	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Auth Ser1 Port"  ,HandleAuthServer1Port	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Auth Ser2 IP"  ,HandleAuthServer2Ip	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Auth Ser2 Port"  ,HandleAuthServer2Port	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
#endif //#ifdef ENABLE_SERVER_AUTH
#ifdef ENABLE_GSM_GPRS			
		{103 ,U_WELCOME				,G_BILLING	,MODE_WEI_CARD_DISPLAY	,0		,"GPRS dignosis"  ,HandleSubMenuScroll	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Modem Connection"  ,CheckModemConnection	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Display Operator"  ,CheckDisplayOperator	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Signal Strength"  ,CheckSignalStength	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Get IP Address"  ,GetModemIP	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Connect GPRS"  ,ConnectGprs	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
			{104 ,U_WELCOME				,G_BILLING	,0	,0		,"Disconnect GPRS"  ,DissconnectGprs	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
#endif			
//icon 5
////////////////////
  	{102 ,U_WELCOME					,G_BILLING  , 0						,0		,"Door"				,HandleSubMenuScroll	,5		,BIT_ANY_ADMIN},
		{103 ,U_WELCOME				,G_BILLING	, 0						,0		,"Door OpenTime"	,HandleDoorTimeMode		,0		,BIT_SUPER_ADMIN | BIT_ADMIN},	  
		{103 ,U_WELCOME				,G_BILLING	,MODE_SET_SHARED_DOTL	,0		,"Shared DOTL"		,HandleSetSharedDOTL				,0		,BIT_SUPER_ADMIN | BIT_ADMIN},	  
		{103 ,U_WELCOME				,G_BILLING	, 0						,0		,"Reader In/Out"	,HandleReaderInOutType	,0		,BIT_SUPER_ADMIN | BIT_ADMIN},	  
		{103 ,U_WELCOME				,G_BILLING	, 0						,0		,"FIRE-TAMPER EnDs"	,HandleSetFireTamper	,0		,BIT_SUPER_ADMIN | BIT_ADMIN},	  
//icon 6
////////////////////
  	{102 ,U_WELCOME					,G_BILLING  , 0						,0		,"Trouble shoot"	,HandleSubMenuScroll	,6		,BIT_ANY_ADMIN},
		{103 ,U_WELCOME				,G_BILLING	, 0						,0		,"InitialiseSystem"	,HandleSubMenuScroll	,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del All Data"		,HandleDelAllData		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del Transaction"	,HandleDelTransaction	,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del All Users"	,HandleDelAllUsers		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Set All Default"	,HandleSetAllDefault	,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Delete SysInfo"	,HandleDelSysInfo		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del  TimeZone"	,HandleDelTimeZone		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del Holiday"		,HandleDelHoliday		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del FacilityCode"	,HandleDelFacilityCode	,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del Door info"	,HandleDelDoorInfo		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del Admin IDs"	,HandleDelAdminIDs		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Reset System"		,HandleResetSystem		,0		,BIT_SUPER_ADMIN},	  
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del Cards Only"	,HandleDelCardsOnly		,0		,BIT_SUPER_ADMIN},	  
#ifdef BIO_METRIC
			{104 ,U_WELCOME			,G_BILLING	, 0						,0		,"Del All Fingers"	,HandleDelAllFingers	,0		,BIT_SUPER_ADMIN},	  
#endif
		{103 ,U_WELCOME				,G_BILLING	,MODE_WEI_CARD_DISPLAY	,0		,"Weigand Display"	,HandleWeiCardDataDisplay,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
		{103 ,U_WELCOME				,G_BILLING	,0						,0		,"Network test"		,HandleSubMenuScroll	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
		{104 ,U_WELCOME			,G_BILLING	,MODE_LAN_TEST			,0		,"LAN test"			,HandleLANTest			,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  
		{104 ,U_WELCOME			,G_BILLING	,MODE_INTERNET_TEST		,0		,"Internet test"	,HandleInternetTest		,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  

//icon 7
//////////////////
  	{102 ,U_WELCOME					,G_BILLING  , 0						,0		,"Device info"		,HandleSubMenuScroll	,7		,BIT_ANY_ADMIN},
		{103 ,U_WELCOME				,G_BILLING	, 0						,0		,"Disp All Para",HandleUserDispAllPara	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN},	  
		{103 ,U_WELCOME				,G_BILLING	, 0						,0		,"Disp Useful Para",HandleUserDispUsefulPara	,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN},	  
//		{103 ,U_WELCOME				,G_BILLING	, 2						,0		,"HELP MENU"		,HandleMenu				,0		,BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},	  				
//icon 8				
///////////////////				
  	{102 ,U_WELCOME					,G_BILLING  , 0						,0		,"Log out"			,HandleWaitForAdminCardKey	,8	,BIT_ANY_ADMIN},
				
{100 	,U_WELCOME   				,G_MAIN_SCREEN,0					,0		,"Admin Login"		,HandleWaitForAdminCardKey	,0	,BIT_ANY_ADMIN}	//dummy entry required at the END

};																												 		


const FONT_INFO *GlobalFontInfo = &dejaVuSansBold9ptFontInfo;
const FONT_INFO *IconFontInfo = &dejaVuSans9ptFontInfo;



unsigned char SubMenuMax,SMScrolIndex;		//i.e.SubMenuScrolIndex This is used only in SubMenuScroll Function as Group Main Index ..
struct USER_MGMT UserMgmt;		// User management values for mode management.
// struct MULTI_FUN multifun;
struct RectInfo		DefaultBackground = {RCTFILL_PLAIN,BACKGROUND_COLOR,240,320};//FillType,Color,Hight,Width
//struct RectInfo		MenuHighlight = 	{RCTFILL_PLAIN,COLOR_BLUE	,GRID_PALLET_SIZE_Y,GRID_PALLET_SIZE_X}; 
struct RectInfo		MenuHighlight = 	{RCTFILL_VERTICAL_UP_SHADOW,COLOR_BLUE	,GRID_PALLET_SIZE_Y,GRID_PALLET_SIZE_X}; 
struct RectInfo		MenuBachground = 	{RCTFILL_PLAIN,COLOR_YELLOW		,GRID_PALLET_SIZE_Y,GRID_PALLET_SIZE_X}; 
struct RectInfo		MenuNoHighlight = 	{RCTFILL_PLAIN,BACKGROUND_COLOR	,GRID_PALLET_SIZE_Y,GRID_PALLET_SIZE_X}; 
//struct RectInfo		DefaultFullBackgnd= {RCTFILL_PLAIN,BACKGROUND_COLOR	,240,320};

//==============================================================================================================
/*
Following function will return Row number in structure where data is written.
*/
// unsigned char GetDisplayModeFromGroupNo(unsigned char grno,unsigned char no)
// {
// 	char i=0;
// 	while(i <= MAX_DISPLAY_NEWMODE_MEMBER)
// 		{
// 		 	if((UserInt1[i].Group==grno)&&(UserInt1[i].DSPMode==no))
// 			{
// 				return(i);
// 			}
// 			i++;
// 		}
// 		return(0xFF);		
// }
void DisplayDefaultBackGround(void)
{
	//lcdFillRGB_Fast(COLOR_CYAN);
	//lcdFillRGB_Fast2(COLOR_DARKERGRAY);
	DrawRect(&DefaultBackground,0,0);
}
void DisplayDefaultScreen(void)
{
	DisplayDefaultBackGround();
//	drawString()
}
/**
This function draws rectangle on tft screen from starting point x0 and y0,
RectInfo struct will have other information.
rectinfo.FillType = RCTFILL_PLAIN;  //this variable use to give information of drawing
rectinfo.Color = COLOR_BLACK;
rectinfo.Hight = DISPLAY_HEIGHT;
rectinfo.Width = DISPLAY_WIDTH;
rectinfo.BorderColor = 0;
*/
void DrawRect(struct RectInfo * rectinfo, uint16_t x0, uint16_t y0 )
{
//	int pixels,height,color;
	register int  py;
	unsigned int temp1,temp2;
//	const int CURV_PIXEL = 3;
//	unsigned char r,g,b;
	switch(rectinfo->FillType)
	{
		case RCTFILL_PLAIN:
		{
			//drawRectangleFilled(x0, y0, x0+rectinfo->Width ,y0+rectinfo->Hight ,rectinfo->Color);
			temp1=(rectinfo->Color&0xff00)>>8;
			temp2=rectinfo->Color&0xff;
			temp1 = temp1 << GLCD_OUT_LINES_SHIFT;
			temp2 = temp2 << GLCD_OUT_LINES_SHIFT;

			// Write the X Start
			TFTWriteCommand(SSD2119_H_RAM_START_REG);
			TFTWriteData( x0 );
			// Write the X End
			TFTWriteCommand(SSD2119_H_RAM_END_REG);
			TFTWriteData( rectinfo->Width + x0 -1);
			// Write the Y start + end location
			TFTWriteCommand(SSD2119_V_RAM_POS_REG);
			TFTWriteData(y0 | ((rectinfo->Hight+y0)<<8) );
			// Set the display cursor to the upper left of the rectangle (in application coordinate space).
			TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
			TFTWriteData(x0);
			TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
			TFTWriteData(y0);
			// Tell the controller we are about to write data into its RAM.
			TFTWriteCommand(SSD2119_RAM_DATA_REG);

	CLR_CS;
	SET_CD;
	
	FIO1MASK = ~PINS_P1_GLCD_DATA;		
	for (py = rectinfo->Hight*rectinfo->Width; py > 0; py--)
	{
//				BYTE_GLCD_OUT((unsigned char)temp1);
				GLCD_OUT_LINES = temp1;
				CLR_WR;
				SET_WR;  
//				BYTE_GLCD_OUT(temp2);
				GLCD_OUT_LINES = temp2;
				CLR_WR;
				SET_WR;  
	}
	FIO1MASK = 0;
	SET_CS;  
    // Set the display size and ensure that the GRAM window is set to allow
    // access to the full display buffer.
    TFTWriteCommand(SSD2119_V_RAM_POS_REG);
    TFTWriteData((LCD_VERTICAL_MAX-1) << 8);
    TFTWriteCommand(SSD2119_H_RAM_START_REG);
    TFTWriteData(0x0000);
    TFTWriteCommand(SSD2119_H_RAM_END_REG);
    TFTWriteData(LCD_HORIZONTAL_MAX-1);
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(0x00);
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(0x00);

// 	for (height = y0; height < rectinfo->Hight+y0 ; ++height)
// 			{
// 				//drawLine(x0, height, x1, height, color);
// //				LcdSetCursor(x0,height);
// //				TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 				//WORD_GLCD_OUT(data);use this instead
// 				//rectinfo->Color + 1;
// //				CLR_CS;
// 				//for (pixels = 0; pixels < rectinfo->Width -1; pixels++)//-1 is bec one pixel is drawn in above fun.
// 				for (pixels = 0; pixels < rectinfo->Width ; pixels++)//-1 is bec one pixel is drawn in above fun.
// 				{
// 					//ili9328WriteData(rectinfo->Color);
// 					//TFTWriteData(rectinfo->Color);
// 					TFTWriteByteData((unsigned char)temp1);
// 					TFTWriteByteData(temp2);
// 				}
// //				SET_CS;
// 			}
		}
		break;
// 		case 50:  //draw rect with rectangle selection :don't use bec no speed improvement
// 		{
// 			temp1=(rectinfo->Color&0xff00)>>8;
// 			temp2=rectinfo->Color&0xff;

// 			//
// 			// Write the Y extents of the rectangle.
// 			//
// 			TFTWriteCommand(SSD2119_ENTRY_MODE_REG);
// 			TFTWriteData(0x6800);

// 			//
// 			// Write the X extents of the rectangle.
// 			//
// 			TFTWriteCommand(SSD2119_H_RAM_START_REG);
// 			TFTWriteData( x0 );

// 			TFTWriteCommand(SSD2119_H_RAM_END_REG);
// 			TFTWriteData( rectinfo->Width + x0 );

// 			//
// 			// Write the Y extents of the rectangle
// 			//
// 			TFTWriteCommand(SSD2119_V_RAM_POS_REG);
// 			TFTWriteData(y0 | (rectinfo->Hight+y0)<<8);

// 			//
// 			// Set the display cursor to the upper left of the rectangle (in application
// 			// coordinate space).
// 			//
// 			TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
// 			TFTWriteData(x0);

// 			TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
// 			TFTWriteData(y0);

// 			//
// 			// Tell the controller we are about to write data into its RAM.
// 			//
// 			TFTWriteCommand(SSD2119_RAM_DATA_REG);


// 			for (height = y0; height < rectinfo->Hight+y0 ; ++height)
// 			{
// 				for (pixels = 0; pixels < rectinfo->Width ; pixels++)//-1 is bec one pixel is drawn in above fun.
// 				{
// 					TFTWriteByteData(temp1);
// 					TFTWriteByteData(temp2);
// 				}
// 			}
// 			//
// 			// Reset the X extents to the entire screen.
// 			//
// 			TFTWriteCommand(SSD2119_H_RAM_START_REG);
// 			TFTWriteData(0x0000);
// 			TFTWriteCommand(SSD2119_H_RAM_END_REG);
// 			TFTWriteData(0x013F);

// 			//
// 			// Reset the Y extent to the full screen
// 			//
// 			TFTWriteCommand(SSD2119_V_RAM_POS_REG);
// 			TFTWriteData(0xEF00);
// 		}
// 		break;
// 		case RCTFILL_VERTICAL_UP_SHADOW:
// 		{
// 			color = rectinfo->Color;
// 			for (height = 0; height < rectinfo->Hight ; ++height)
// 			{
// 				LcdSetCursor(x0,height+y0);
// 				TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 				if( (height%rectinfo->YSpacePixel ==0) && (height != 0) )
// 				{
// 					color += 0x0841;	//increment each color by 1 bit
// 				}
// 				for (pixels = 0; pixels < rectinfo->Width ; pixels++)
// 				{
// 					TFTWriteData(color);
// 				}
// 			}
// 		}
// 		break;
// 		case RCTFILL_VERTICAL_DOWN_SHADOW:  //just testing
// 		{
// 			color = rectinfo->Color;
// 			for (height = 0; height < rectinfo->Hight ; ++height)
// 			{
// 				LcdSetCursor(x0, (rectinfo->Hight-height-1)+y0);
// 				TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 				if( (height%rectinfo->YSpacePixel ==0) && (height != 0) )
// 				{
// 					color += 0x0841;	//increment each color by 1 bit
// 				}
// 				for (pixels = 0; pixels < rectinfo->Width ; pixels++)//
// 				{
// 					TFTWriteData(color);
// 				}
// 			}
// 		}
// 		break;
// 		case RCTFILL_HORIZONTAL_LEFT_SHADOW:
// 		{
// 			for (height = 0; height < rectinfo->Hight ; ++height)
// 			{
// 				LcdSetCursor(x0, (rectinfo->Hight-height-1)+y0);
// 				TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 				color = rectinfo->Color;
// 				for (pixels = 0; pixels < rectinfo->Width ; pixels++)
// 				{
// 					if( (pixels%rectinfo->XSpacePixel ==0) && (pixels != 0) )
// 					{
// 						color += 0x0841;	//increment each color by 1 bit
// 					}
// 					TFTWriteData(color);
// 				}
// 			}
// 		}
// 		break;
// 		case RCTFILL_HORIZONTAL_RIGHT_SHADOW:
// 		break;
// 		case RCTFILL_VERTICAL_DOUBLE_SHADOW:	 //not done
// 		{
// 			temp1 = 0;
// 			//drawRectangleFilled(x0, y0, x0+rectinfo->Width ,y0+rectinfo->Hight ,rectinfo->Color);
// 			for (height = y0; height < rectinfo->Hight+y0 ; ++height)
// 			{
// 				//drawLine(x0, height, x1, height, color);
// 				LcdSetCursor(x0,height);   //set cursor
// //				TFTWriteCommand(ILI9328_COMMANDS_WRITEDATATOGRAM);  // Write Data to GRAM (R22h)
// 				TFTWriteData((rectinfo->Color-temp1/3)&0x001f);//only for blue color
// 				++temp1;
// 				//WORD_GLCD_OUT(data);use this instead
// 				//rectinfo->Color + 1;
// 				CLR_CS;
// 				for (pixels = 0; pixels < rectinfo->Width -1; pixels++)//-1 is bec one pixel is drawn in above fun.
// 				{
// 					//ili9328WriteData(rectinfo->Color);
// 					TFTWriteData((rectinfo->Color-temp1/3)&0x001f);//only for blue color

// // 					SET_CD_RD_WR;
// // 					CLR_WR;
// // 					//SET_WR_CS;
// // 					SET_WR;				
// 				}
// 				SET_CS;
// 			}
// 		}
// 		break;
// 		case RCTFILL_HORIZONTAL_DOUBLE_SHADOW:
// 		break;
// 		case RCTFILL_BORDER:
// 		{
// 				
// 		}
// 		break;
// 		case RCTFILL_CURVEDBORDER:
// 		{
// 			
// 		}
// 		break;
// 		case RCTFILL_CURVED:
// 		{	 //this is only possible if height and width of rect is more then 6 pixel
// 			//drawRectangleFilled(x0, y0, x0+rectinfo->Width ,y0+rectinfo->Hight ,rectinfo->Color);
// 			for (height = y0; height < rectinfo->Hight+y0 ; ++height)
// 			{
// 				//drawLine(x0, height, x1, height, color);
// 				if( (height-y0)<CURV_PIXEL)
// 				{
// 					pixels = x0+CURV_PIXEL-(height-y0);
// 					temp1= rectinfo->Width-pixels*2;
// 					LcdSetCursor(pixels,height);

// 				}
// 				else
// 				{
// 					pixels = 0;
// 					temp1= rectinfo->Width;
// 					LcdSetCursor(x0,height);
// 				}
// 				TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
// 				TFTWriteData(rectinfo->Color);
// 				//WORD_GLCD_OUT(data);use this instead
// 				//rectinfo->Color + 1;
// 				CLR_CS;
// 				for (; pixels < temp1 -1; pixels++)//-1 is bec one pixel is drawn in above fun.
// 				{
// 					//ili9328WriteData(rectinfo->Color);
// 					TFTWriteData(rectinfo->Color);

// // 					SET_CD_RD_WR;
// // 					CLR_WR;
// // 					//SET_WR_CS;
// // 					SET_WR;				
// 				}
// 				SET_CS;
// 			}
//		}
//		break;
	}
}
void DrawBox_UID(void)
{
	struct RectInfo rectinfo;
	
	rectinfo.FillType = RCTFILL_PLAIN;		
	rectinfo.Color = COLOR_LIGHTGRAY;
	rectinfo.Hight = 30;
	rectinfo.Width = 110;
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo,106,100);
}
void ClearDrawBox_UID(void)
{
	struct RectInfo rectinfo;
	rectinfo.FillType = RCTFILL_PLAIN;
	rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;
	rectinfo.Hight = 30;
	rectinfo.Width = 110;
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo,106,100);
}
void DisplayClr(void)
{
	DisplayDefaultBackGround();	
}
// void DrawIconByByte(unsigned char Index, uint16_t color, uint16_t x0, uint16_t y0)
// {
// 	uint16_t X,Y;
// 	char flag=0,i;
// 	int ArrIndex;

// 	ArrIndex = 0;
// 	for(Y=0;Y<ICON_HEIGHT_PIXEL;Y++)
// 	{
// 		flag = 0;
// 		for(X=0 ;X<ICON_WIDTH_BYTE ;X++)
// 		{
// 			for(i=0; i<BITS_PER_DATA ;i++)
// 			{
// 				if( (flag==1) && ( IconArray2[Index][ArrIndex] & (ICON_DATA_MASK>>i) ) )
// 				{
// 					CLR_CS_SET_CD_RD_WR;
// 					CLR_WR;
// 					SET_WR_CS;				
// 				}
// 				else if( (flag==1) && !( IconArray2[Index][ArrIndex] & (ICON_DATA_MASK>>i) ) )
// 				{
// 					flag = 0;
// 				}
// 				else if( (flag==0) && ( IconArray2[Index][ArrIndex] & (ICON_DATA_MASK>>i) ) )
// 				{
// 					ili9328SetCursor(x0+X*8+i,y0+Y);
// 					ili9328WriteCmd(ILI9328_COMMANDS_WRITEDATATOGRAM);
// 					ili9328WriteData(color);
// 	
// 					flag =1;
// 				}
// 			}
// 			++ArrIndex;
// 		}
// 	}
// }
// void DrawIcon(unsigned char Index, uint16_t color, uint16_t x0, uint16_t y0)
// {
// 	uint16_t X,Y;
// 	char flag=0,i;

// 	for(Y=0;Y<16;Y++)
// 	{
// 		for(i=0;i<3;i++)
// 		{
// 			flag = 0;
// 			for(X=0;X<16;X++)
// 			{
// 				if( (flag==1) && ( IconArray[Index][Y] & (0x8000>>X) ) )
// 				{
// 					//ili9328WriteData(color);
// 					//ili9328WriteData(color);
// 					//ili9328WriteData(color);
// 					CLR_CS_SET_CD_RD_WR;
// 					CLR_WR;
// 					SET_WR_CS;				
// 					CLR_CS_SET_CD_RD_WR;
// 					CLR_WR;
// 					SET_WR_CS;				
// 					CLR_CS_SET_CD_RD_WR;
// 					CLR_WR;
// 					SET_WR_CS;				
// 				}
// 				else if( (flag==1) && !( IconArray[Index][Y] & (0x8000>>X) ) )
// 				{
// 					flag = 0;
// 				}
// 				else if( (flag==0) && ( IconArray[Index][Y] & (0x8000>>X) ) )
// 				{
// 					ili9328SetCursor(x0+X*3,y0+Y*3+i);
// 					ili9328WriteCmd(ILI9328_COMMANDS_WRITEDATATOGRAM);
// 					ili9328WriteData(color);
// 					//ili9328WriteData(color);
// 					//ili9328WriteData(color);
// 					CLR_CS_SET_CD_RD_WR;
// 					CLR_WR;
// 					SET_WR_CS;				
// 					CLR_CS_SET_CD_RD_WR;
// 					CLR_WR;
// 					SET_WR_CS;				

// 					flag =1;
// 				}
// 				//ili9328WriteData(COLOR_RED);
// 			}
// 		}
// 	}
// }
uint16_t GetSectorX0(unsigned char num)//0 to 8
{
	num %= 3;		
	return GRID_START_X0 + num*GRID_SECTOR_SIZE_X;
}
uint16_t GetSectorY0(unsigned char num)//0 to 8
{
	num /= 3;		
	return GRID_START_Y0 + num*GRID_SECTOR_SIZE_Y ;
}

uint16_t GetIconX0(unsigned char num)//0 to 8
{
	num %= 3;		
	return GRID_START_X0 + num*GRID_SECTOR_SIZE_X + GRID_ICON_POS_X;
}
uint16_t GetIconY0(unsigned char num)//0 to 8
{
	num /= 3;		
	return GRID_START_Y0 + num*GRID_SECTOR_SIZE_Y + GRID_ICON_POS_Y;
}
uint16_t GetPalletX0(unsigned char num)//0 to 8
{
	num %= 3;		
	return GRID_START_X0 + num*GRID_SECTOR_SIZE_X + 1;
}
uint16_t GetPalletY0(unsigned char num)//0 to 8
{
	num /= 3;		
	return GRID_START_Y0 + num*GRID_SECTOR_SIZE_Y + 1;
}
void GL_BlankDisplay(unsigned char lin)
{
//	GL_PositionCursorOnRow(1,lin,1);
//	lin = 1;
//	while(lin < 21)	
//	{
//		WriteDataToDisplay(' ');
//		lin ++;
//	}

	drawString(0, 240/(GlobalFontInfo->heightPages) ,GLOBAL_FONT_COLOR,GlobalFontInfo,"                 ");

//	switch(lin)
//	{
//		case	0:
//		break	;
//		case	1:
//		break	;
//		case	2:
//		break	;
//		case	3:
//		break	;
//		case	4:
//		break	;
//		case	5:
//		break	;
//		case	6:
//		break	;
//		case	7:
//		break	;
//	}
}
/*------------------------------------------------------------------------*/ 
// void GL_PositionCursorOnRow(unsigned char position, unsigned char row)
// {
// //	Chk_FontSize(font);
// //	gotoxy(row,position);
// 	//240/(currentFontInfo->heightPages);//y
// 	// use       lcdGetHeight();
// 	ili9328SetCursor(position, 240/(GlobalFontInfo->heightPages * row) );//x,y
// }
/*
Any Special Key Press ---> Functionname
			--> If this is group special key
				--> Call HandleAllModeEvents
					--> Select required sub menu
GroupNo
UserIntfData.NewModeIndex =SubMenuGroupIndex
SubMenuMax
*/
/*------------------------------------------------------------------------*/   
////////////////////////////////////////////////
//icon index from 0 to max in icon array
//icon number from 0 to 8
void HighlightIcon(unsigned char CurrentIconIndex,unsigned char PreviousIconIndex,
					unsigned char CurrentIconNum,unsigned char PreviousIconNum,
					unsigned char currentArr,unsigned char prevArr)
{
uint16_t	startX,startY;	
// remove privious highlight
	startX = GetSectorX0(PreviousIconNum);
	startY = GetSectorY0(PreviousIconNum);
	DrawRect(&MenuNoHighlight,startX + GRID_PALLET_POS_X,startY + GRID_PALLET_POS_Y);
	//DrawIcon(PreviousIconIndex,ICON_COLOR,startX + GRID_ICON_POS_X,startY + GRID_ICON_POS_Y);
//	DrawIconByByte(0,ICON_COLOR,startX + GRID_ICON_POS_X,startY + GRID_ICON_POS_Y);
	drawString(startX+GRID_TEXT_POS_X ,startY+GRID_TEXT_POS_Y ,MENU_FONT_COLOR ,IconFontInfo,(unsigned char*) UserInt1[prevArr].MenuName);

//show new highlight	
	startX = GetSectorX0(CurrentIconNum);
	startY = GetSectorY0(CurrentIconNum);
	DrawRect(&MenuHighlight,startX + GRID_PALLET_POS_X,startY + GRID_PALLET_POS_Y);
	//DrawIcon(CurrentIconIndex,ICON_COLOR,startX + GRID_ICON_POS_X,startY + GRID_ICON_POS_Y);
//	DrawIconByByte(0,ICON_COLOR,startX + GRID_ICON_POS_X,startY + GRID_ICON_POS_Y);
	drawString(startX+GRID_TEXT_POS_X ,startY+GRID_TEXT_POS_Y ,MENU_FONT_COLOR ,IconFontInfo,(unsigned char*)UserInt1[currentArr].MenuName);
}
// void ShiftDisplayUp(void)
// {
// //  ili9328Command(ILI9328_COMMANDS_DISPLAYCONTROL1, 0x0133);     // Display Control (R07h)
// 	ili9328Command(ILI9328_COMMANDS_DISPLAYCONTROL1, 0x0033);     // Display Control (R07h)
// //  ili9328Command(ILI9328_COMMANDS_DRIVEROUTPUTCONTROL2, 0xa700); 
// 	ili9328Command(ILI9328_COMMANDS_DRIVEROUTPUTCONTROL2, 0xa700);   //NL = 0x27

// 	ili9328Command(ILI9328_COMMANDS_PARTIALIMAGE1DISPLAYPOSITION, 0x0080);	//PTDP0=080h 
// 	ili9328Command(ILI9328_COMMANDS_PARTIALIMAGE1AREASTARTLINE, 0x0000); 	//PTSA0=000h
// 	ili9328Command(ILI9328_COMMANDS_PARTIALIMAGE1AREAENDLINE, 0x000f); 		//PTEA0=00fh
// 	
// }
void ClearBootScreen(void)
{
	struct RectInfo rectinfo;
	rectinfo.FillType = RCTFILL_PLAIN;
	rectinfo.Color = COLOR_BLACK;
	rectinfo.Hight = BOOT_MSG_SECTION_HEIGHT;
	rectinfo.Width = BOOT_MSG_SECTION_WIDTH;
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo,BOOT_MSG_SECTION_X0,BOOT_MSG_SECTION_Y0);
}
void DispTouchKeyPad(unsigned char Format)
{
	unsigned char count=0;
	switch(Format)
	{
		case FORMAT_WELCOME_SCREEN: //
		{
			while(count < MAX_TOUCH_KEY)
			{
				drawButton(	TouchKeyData[count].x0,
							TouchKeyData[count].y0,
							TOUCH_KEY_WIDTH,
							TOUCH_KEY_HEIGHT,
							TOUCH_KEY_FONT_INFO_PTR,
							TOUCH_KEY_FONT_HEIGHT,
							TouchKeyData[count].str1,
							0
					);
				count++;
			}
		}
		break;
		case FORMAT_GRID_SCREEN: //
		case FORMAT_SCROLL_SCREEN: //
		case FORMAT_SUBMENU_SCREEN: //
		case FORMAT_EVENT_ICON:
		case FORMAT_CONNECT_GPRS:
		{
			while(count < MAX_TOUCH_KEY)
			{
				drawButton(	TouchKeyData[count].x0,
							TouchKeyData[count].y0,
							TOUCH_KEY_WIDTH,
							TOUCH_KEY_HEIGHT,
							TOUCH_KEY_FONT_INFO_PTR,
							TOUCH_KEY_FONT_HEIGHT,
							TouchKeyData[count].str2,
							0
					);
				count++;
			}
		}
		break;
	}
}
//this fuynction highlight and unhighlight menu
void UpdateTouchScreen(unsigned char tcKey,unsigned char select)
{
	tcKey -= 1;
	switch(ScreenFormatData.CurrentFormat)
	{
		case FORMAT_WELCOME_SCREEN: //
		case FORMAT_EVENT_ICON:
		{
			if(select == 0)
			{   //
		// 		DisplayBmpTransparent(	TouchKeyPosition[tcKey-1][XPOS],
		// 								TouchKeyPosition[tcKey-1][YPOS],
		// 								TOUCH_KEY_WIDTH,
		// 								TOUCH_KEY_HEIGHT,
		// 								btnNormal,
		// 								COLOR_WHITE);
					drawButton(	TouchKeyData[tcKey].x0,
								TouchKeyData[tcKey].y0,
								TOUCH_KEY_WIDTH,
								TOUCH_KEY_HEIGHT,
								TOUCH_KEY_FONT_INFO_PTR,
								TOUCH_KEY_FONT_HEIGHT,
								TouchKeyData[tcKey].str1,
								0
						);
			}
			else
			{   //highlighted
		// 		DisplayBmpTransparent(	TouchKeyPosition[tcKey-1][XPOS],
		// 								TouchKeyPosition[tcKey-1][YPOS],
		// 								TOUCH_KEY_WIDTH,
		// 								TOUCH_KEY_HEIGHT,
		// 								btnPressed,
		// 								COLOR_WHITE);
					drawButton(	TouchKeyData[tcKey].x0,
								TouchKeyData[tcKey].y0,
								TOUCH_KEY_WIDTH,
								TOUCH_KEY_HEIGHT,
								TOUCH_KEY_FONT_INFO_PTR,
								TOUCH_KEY_FONT_HEIGHT,
								TouchKeyData[tcKey].str1,
								1
						);
			}
		}
		break;
		case FORMAT_GRID_SCREEN: //
		case FORMAT_SCROLL_SCREEN: //
		case FORMAT_SUBMENU_SCREEN: //
		{
			if(select == 0)
			{   //
					drawButton(	TouchKeyData[tcKey].x0,
								TouchKeyData[tcKey].y0,
								TOUCH_KEY_WIDTH,
								TOUCH_KEY_HEIGHT,
								TOUCH_KEY_FONT_INFO_PTR,
								TOUCH_KEY_FONT_HEIGHT,
								TouchKeyData[tcKey].str2,
								0
						);
			}
			else
			{   //highlighted
					drawButton(	TouchKeyData[tcKey].x0,
								TouchKeyData[tcKey].y0,
								TOUCH_KEY_WIDTH,
								TOUCH_KEY_HEIGHT,
								TOUCH_KEY_FONT_INFO_PTR,
								TOUCH_KEY_FONT_HEIGHT,
								TouchKeyData[tcKey].str2,
								1
						);
			}
		}
		break;
	}
}
void DisplayGridMenu(void)
{
	char i=1,IconPos=1; //we skip welcome mode
//	struct RectInfo rectinfo;
DisableDisplay();	
ScreenFormatData.F_GridVisible = 1;
	
	while(i < MAX_DISPLAY_NEWMODE_MEMBER)
	{
		if(UserInt1[i].ModeNo == 102)
		{
			if(UserInt1[i].IconInfo==0)
			{
				//no icon is available for this menu
			}
			else
			{
				if(IconPos != DisplayData.GridCurrentSelection)
				{//no selection
#ifdef ENABLE_WATCHDOG
					WDTFeed();		//Clear watchdog timer
#endif
					DisplayIconWithName(IconPos,UserInt1[i].IconInfo,0,(char*)UserInt1[i].MenuName);
				}
				else
				{//selection
					//SHOW TITLE HERE
// 					L_DisplayTitleStr(UserInt1[i].MenuName,
// 										50,
// 										ROW_USER_TITLE,
// 										0);	
//				DisplayTitleStr();	
//				DisplayTitleStr(UserInt1[i].MenuName,ROW_USER_TITLE);	
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TitleMSGBackgroundColour;
// 				rectinfo.Hight = TITLEMSG_HEIGHT;  
// 				rectinfo.Width = TITLEMSG_WEIGHT;  
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,DISP_TITLEMSG_X0,DISP_TITLEMSG_Y0);
		
// 				DrawCenterText(	USER_LINE1_START_Y0,
// 							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 							USER_TITLE_FONTINFO_PTR,
// 							(char*)UserInt1[i].MenuName);
					DisplayIconWithName(IconPos,UserInt1[i].IconInfo,1,(char*)UserInt1[i].MenuName);
				}
				++IconPos;
			}
		}
		i++;
	}
	EnableDisplay();
}
void ClearGridDisplay(void)
{
//display default backgnd in grid section
	DisplayBackGround(GRID_SECTION_X0,GRID_SECTION_Y0, GRID_SECTION_WIDTH, GRID_SECTION_HEIGHT,image16) ;
	ScreenFormatData.F_GridVisible = 0;	
}
void UpdateGridView(void)
{
	char i=1,IconPos=1;
	unsigned char CurrentIconNo,PreviousIconNo;
//	struct RectInfo rectinfo;

	DisableDisplay();
	while(i < MAX_DISPLAY_NEWMODE_MEMBER)
	{
		if(UserInt1[i].ModeNo == 102)
		{
			if(UserInt1[i].IconInfo==0)
			{
				//no icon is available for this menu
			}
			else
			{
#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
#endif
				if(IconPos==DisplayData.GridCurrentSelection)
				{
					CurrentIconNo = UserInt1[i].IconInfo;
					DisplayIcon(DisplayData.GridCurrentSelection,CurrentIconNo,1);
				}
				else if(IconPos==DisplayData.GridPreviousSelection)
				{
					PreviousIconNo = UserInt1[i].IconInfo;
					DisplayIcon(DisplayData.GridPreviousSelection,PreviousIconNo,0);
				}
				++IconPos;
			}
		}
		i++;
	}
	EnableDisplay();
//update icon;
	
	//SHOW TITLE HERE
// 	L_DisplayROMStrLoc(UserInt1[DisplayData.GridCurrentSelection].MenuName,
// 						50,
// 						ROW_USER_TITLE,
// 						0);
//	DisplayWithBackgroundColour
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TitleMSGBackgroundColour;
// 				rectinfo.Hight = TITLEMSG_HEIGHT;  
// 				rectinfo.Width = TITLEMSG_WEIGHT;  
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,DISP_TITLEMSG_X0,DISP_TITLEMSG_Y0);
// 		
// 			 	DrawCenterText(	USER_LINE1_START_Y0,
// 							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 							USER_TITLE_FONTINFO_PTR,
// 							(char*)UserInt1[DisplayData.GridCurrentSelection].MenuName);
	
}
unsigned char GetIndexFromGridSelection(void)
{
	char i=1,IconPos=1;
//	unsigned char CurrentIconNo,PreviousIconNo;

	if(DisplayData.GridCurrentSelection == 0)
		return 0;
	while(i < MAX_DISPLAY_NEWMODE_MEMBER)
	{
		if(UserInt1[i].ModeNo == 102)
		{
			if(UserInt1[i].IconInfo==0)
			{
				//no icon is available for this menu
			}
			else
			{
				if(IconPos==DisplayData.GridCurrentSelection)
				{
					return i;
				}
				IconPos++;
			}
		}
		i++;
	}
	return 0;
}
/**
this function will take care of screen initialisation.
i.e. 	if we came from grid view to scroll view then it will remove all data related to grid view from screen.
		so grid part of screen gets erased.
so this function do erasing of unwnated data from screen.
it maintains previeous and current view data so only part of screen gets change instead of entier screen.
currently there are 5 formats.
	FORMAT_BOOT_SCREEN			
	FORMAT_WELCOME_SCREEN       
	FORMAT_GRID_SCREEN          
	FORMAT_SCROLL_SCREEN        
	FORMAT_SUBMENU_SCREEN 
	FORMAT_EVENT_ICON    //for authorised,unauthorised,enter uid,select function used for "HandleWaitForCardKeyBio()"
	FORMAT_SCROLL_MENU
*/
void DisplayFormat(unsigned char Format)
{
	struct RectInfo rectinfo;
#ifdef ENABLE_WATCHDOG
	WDTFeed();		//Clear watchdog timer
#endif
	DisableDisplay();
//	DiaplyInverted();
	switch(Format)
	{
		case FORMAT_BOOT_SCREEN: //boot screen
		{
			//clear entire screen
			rectinfo.FillType = RCTFILL_PLAIN;
//			rectinfo.FillType = 50;			
			rectinfo.Color = COLOR_WHITE;
			rectinfo.Hight = DISPLAY_HEIGHT;
			rectinfo.Width = DISPLAY_WIDTH;
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,0);
			//display icon in first half
			//second half is color black
			rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = COLOR_BLACK;
			rectinfo.Hight = BOOT_MSG_SECTION_HEIGHT;
			rectinfo.Width = BOOT_MSG_SECTION_WIDTH;
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,BOOT_MSG_SECTION_X0,BOOT_MSG_SECTION_Y0);

#ifdef INSERT_SDCARD
			//draw first half acreen as animated.
// 			SDDisplayAnimatedSpecificGround(0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									1,              //default image no. for boot screen is 1
// 									COLOR_WHITE	);	//this is back ground color
			SDDisplayBackGround(0,
									0,
									DISPLAY_WIDTH,
									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
									1,IMAGES_GROUP);              //default image no. for boot screen is 1
#endif

			ScreenFormatData.F_SmallTimeVisible=0  ;
            ScreenFormatData.F_BigTimeVisible=0    ;
            ScreenFormatData.F_TouchScreenVisible=0;
            ScreenFormatData.F_GridVisible=0       ;
            ScreenFormatData.F_ScrollMenuVisible=0 ;
            ScreenFormatData.F_SubMenuVisible=0    ;
            ScreenFormatData.F_SatusBar1Visible=0  ;
            ScreenFormatData.F_SatusBar2Visible=0  ;
			ScreenFormatData.CurrentFormat = Format;	
//			DrawFullColors();
		}
		break;
		case FORMAT_WELCOME_SCREEN:	//welcome screen
		{
			DisplayDummy();
			DispWall_IdealTime = 0;
			if(ScreenFormatData.CurrentFormat == FORMAT_BOOT_SCREEN)
			{
				//clear entire screen
				DisplayWallpaper();
				DisplayMode = 0;     //  sud 
				DisplaySubMode = 0;  // sud 
				NumericValue = 0;	   // sud  
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
// 				DispTouchKeyPad(FORMAT_WELCOME_SCREEN);  // wallpper do not have touch keypad 
// 				ScreenFormatData.F_TouchScreenVisible=1;
				
				//display welcome wallpaper
#ifdef INSERT_SDCARD				
// 				SDDisplaySpecificGround(0,
// 										0,
// 										DISPLAY_WIDTH,
// 										DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 										ScreenFormatData.F_ImageNo);
				SDDisplayBackGround(0,98,320,142,2,IMAGES_GROUP);
#else
				//bmpDrawBitmap1(0,0,NULL);
				DisplayBackGround(	0,
									0, 
									DISPLAY_WIDTH, 
									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
									image16) ;
#endif		

				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)
			{
				DisplayMode = 0;     //  sud 
				DisplaySubMode = 0;  // sud 
				NumericValue = 0;	   // sud
				F_Poll_Bio_Sensor = SET;		// When we comes to welcome screen it takes arround 10 sec to on Sensor if it is in Autopolling or finger sense mode 
			}
			else if((ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN) ||(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN) || \
						 (ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN) ||(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_MENU)||\
						 (ScreenFormatData.CurrentFormat == FORMAT_CONNECT_GPRS))
			{
				//clear grid screen	//display default backgnd in grid section
#ifdef INSERT_SDCARD				
//				DisplayWallpaperWithoutGrid();
				ClrScreenWithoutStatusBar();   // 
				SDDisplayBackGround(0,98,320,142,2,IMAGES_GROUP);
				DisplayMode = 0;     //  sud 
				DisplaySubMode = 0;  // sud 
				NumericValue = 0;	   // sud
// 				SDDisplaySpecificGround(GRID_SECTION_X0,
// 										GRID_SECTION_Y0, 
// 										GRID_SECTION_WIDTH, 
// 										GRID_SECTION_HEIGHT,
// 										ScreenFormatData.F_ImageNo);
#else
				DisplayBackGround(	GRID_SECTION_X0,
									GRID_SECTION_Y0, 
									GRID_SECTION_WIDTH, 
									GRID_SECTION_HEIGHT,
									image16) ;
#endif		
				
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
								F_Poll_Bio_Sensor = SET;// When we comes to welcome screen it takes arround 10 sec to on Sensor if it is in Autopolling or finger sense mode 

			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)	
			{
#ifdef INSERT_SDCARD				
				ClrScreenWithoutStatusBar();   // 
				SDDisplayBackGround(0,98,320,142,2,IMAGES_GROUP);
				NumericValue = 0;	   // sud
#else
				DisplayBackGround(	GRID_SECTION_X0,
									GRID_SECTION_Y0, 
									GRID_SECTION_WIDTH, 
									GRID_SECTION_HEIGHT,
									image16) ;
#endif		
				
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
				F_Poll_Bio_Sensor = SET;// When we comes to welcome screen it takes arround 10 sec to ON Sensor if it is in Autopolling or finger sense mode 
				
			}	
			DisplayMode = 0;     //  sud 
			DisplaySubMode = 0;  // sud 			
			ScreenFormatData.CurrentFormat = Format;
			//initialisation to start
			UserIntfData.NewModeIndex = 0;
//			DisplayMode = UserInt1[UserIntfData.NewModeIndex].ModeNo ;
			GroupNo=UserInt1[UserIntfData.NewModeIndex].Group;
		}
		break;
		case FORMAT_GRID_SCREEN:	//grid menu view
		{
			DisplayDummy();
			if((ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)||(ScreenFormatData.CurrentFormat == FORMAT_CONNECT_GPRS))
			{
#ifdef INSERT_SDCARD				
				//clear big time
				ClrScreenWithoutStatusBar();
#else
				//clear big time
				DisplayBackGround(	BIG_TIME_START_X0,
									BIG_TIME_START_Y0,
									BIG_TIME_SECTOR_SIZE_X, 
									BIG_TIME_SECTOR_SIZE_Y,
									image16) ;
				DisplayBackGround(	BIG_DATE_START_X0,
									BIG_DATE_START_Y0,
									BIG_DATE_SECTOR_SIZE_X, 
									BIG_DATE_SECTOR_SIZE_Y,
									image16) ;
				//clear welcome msgs.
				DisplayBackGround(	WELCOME_MSG_SECTION_START_X0,
									WELCOME_MSG_SECTION_START_Y0,
									WELCOME_MSG_SECTION_SIZE_X, 
									WELCOME_MSG_SECTION_SIZE_Y,
									image16) ;
#endif		

				//clear top status
				//clear critical status
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_GRID_SCREEN);
				ScreenFormatData.F_TouchScreenVisible=1;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)
			{
				//nothing to do
			}
			else if( (ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN) || 
				(ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN) )
			{
#ifdef INSERT_SDCARD				// wallpaper 
//					DisplayWallpaperWithoutGrid();
								//DisplayWallpaper();
				ClrScreenScrollToGrid();
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_GRID_SCREEN);
				ScreenFormatData.F_TouchScreenVisible=1;

// 				SDDisplaySpecificGround(0,
// 										0,
// 										DISPLAY_WIDTH,
// 										DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 										ScreenFormatData.F_ImageNo);
#else
				DisplayBackGround(	0,
									0,
									DISPLAY_WIDTH,
									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
									image16) ;
#endif

				//no change for touch key
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)
			{
#ifdef INSERT_SDCARD			
//				DisplayWallpaperWithoutGrid();
								//DisplayWallpaper();

				ClrScreenWithoutStatusBar();

				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_WELCOME_SCREEN);
				ScreenFormatData.F_TouchScreenVisible=1;

// 				SDDisplaySpecificGround(0,
// 										0,
// 										DISPLAY_WIDTH,
// 										DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 										ScreenFormatData.F_ImageNo);
#else
				DisplayBackGround(	0,
									0,
									DISPLAY_WIDTH,
									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
									image16) ;
#endif
			}
			ScreenFormatData.F_SmallTimeVisible=0  ;
            ScreenFormatData.F_BigTimeVisible=0    ;
            ScreenFormatData.F_GridVisible=0       ;
            ScreenFormatData.F_ScrollMenuVisible=0 ;
            ScreenFormatData.F_SubMenuVisible=0    ;
            ScreenFormatData.F_SatusBar1Visible=0  ;
            ScreenFormatData.F_SatusBar2Visible=0  ;
			ScreenFormatData.CurrentFormat = Format;
		}
		break;
		case FORMAT_SCROLL_SCREEN:	//list menu view
		{
			DisplayDummy();
			if((ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)||(ScreenFormatData.CurrentFormat == FORMAT_CONNECT_GPRS))
			{
// 				DisplayBackGround(	0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									image16) ;
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;     
// 				rectinfo.Hight = ThemeSelect.StatusbarHeight+ThemeSelect.TimeDateHeight+  \
// 													ThemeSelect.BackGroundHeight ;  // 18
// 				rectinfo.Width = ThemeSelect.StatusbarWidth;   // 320
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,ThemeSelect.StatusbarStartXO,ThemeSelect.StatusbarStartYO); \
				//clear top status
				//clear critical status
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_SCROLL_SCREEN);
				ScreenFormatData.F_TouchScreenVisible=1;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)
			{
// 				DisplayBackGround(	0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									image16) ;
//  				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;     
// 				rectinfo.Hight = ThemeSelect.StatusbarHeight+ThemeSelect.TimeDateHeight+  \
// 													ThemeSelect.BackGroundHeight + DISP_STATUSMSG_WITHOUTGRID_HEIGHT;  // 18
// 				rectinfo.Width = ThemeSelect.StatusbarWidth;   // 320
				DefaultGrid_SubmenueScreen();
				
				rectinfo.BorderColor = 0;
//				DrawRect(&rectinfo,ThemeSelect.StatusbarStartXO,ThemeSelect.StatusbarStartYO); 	
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN)
			{
				DefaultGrid_SubmenueScreen();
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN)
			{
				//clear all lines of scroll menu
// 				DisplayBackGround(	SCROLL_SECTION_START_X0,
// 									SCROLL_SECTION_START_Y0, 
// 									SCROLL_SECTION_SIZE_X, 
// 									SCROLL_SECTION_SIZE_Y,
// 									image16) ;
				DefaultGrid_SubmenueScreen();

				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)
			{
// 				DisplayBackGround(	0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									image16) ;
				DefaultGrid_SubmenueScreen();
				
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			ScreenFormatData.CurrentFormat = Format;
		}
		break;
		case FORMAT_SUBMENU_SCREEN:	//add card .... kind of menu
		{
			DisplayDummy();
			if(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)
			{
				DefaultGrid_SubmenueScreen();
// 				DisplayBackGround(	0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									image16) ;
				//clear top status
				//clear critical status
				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_SUBMENU_SCREEN);
				ScreenFormatData.CurrentFormat = Format;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)
			{
// 				DisplayBackGround(	0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									image16) ;
				DefaultGrid_SubmenueScreen();

				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN) 
			{
				DefaultGrid_SubmenueScreen(); 
				
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN)
			{
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)
			{
// 				DisplayBackGround(	0,
// 									0,
// 									DISPLAY_WIDTH,
// 									DISPLAY_HEIGHT-TOUCH_KEY_SECTION_HEIGHT,
// 									image16) ;
				DefaultGrid_SubmenueScreen();

				ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_ScrollMenuVisible=0 ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			}
			ScreenFormatData.CurrentFormat = Format;
		}
		break;
		case FORMAT_EVENT_ICON:	//LIKE AUTHORISED /UNAUTHORISED
		{
			DisplayDummy();
			if((ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)||(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)||  \
				(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN) || (ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN)|| \
				(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_MENU)|| (ScreenFormatData.CurrentFormat == FORMAT_CONNECT_GPRS))
			{
				DefaultGrid_SubmenueScreen();
// 				//CLEAR SCREEN REQUIRED
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;
// 				rectinfo.Hight = SCREEN_ICON1_SECTION_HEIGHT;  //
// 				rectinfo.Width = SCREEN_ICON1_SECTION_WIDTH;  // 
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,SCREEN_ICON1_SECTION_X0,SCREEN_ICON1_SECTION_Y0);

				//clear top status
				//clear critical status
				ScreenFormatData.F_BigTimeVisible=0  ;
				ScreenFormatData.F_SatusBar1Visible=0;
				ScreenFormatData.F_SatusBar2Visible=0;
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_EVENT_ICON);
				ScreenFormatData.F_TouchScreenVisible=1;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)
			{
				
			}
			ScreenFormatData.CurrentFormat = Format;
			ScreenFormatData.F_SmallTimeVisible=0  ;
			ScreenFormatData.F_BigTimeVisible=0    ;
			ScreenFormatData.F_GridVisible=0       ;
			ScreenFormatData.F_SubMenuVisible=0    ;
			ScreenFormatData.F_SatusBar1Visible=0  ;
			ScreenFormatData.F_SatusBar2Visible=0  ;
		}
		break;
		case FORMAT_CONNECT_GPRS:
			if((ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)||(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)||  \
				(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN) || (ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN)|| \
				(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_MENU)||(ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON))
			{
					DefaultGrid_SubmenueScreen();
					ScreenFormatData.F_BigTimeVisible=0  ;
					ScreenFormatData.F_SatusBar1Visible=0;
					ScreenFormatData.F_SatusBar2Visible=0;
					//display touch key
					TouchKeyPad.CurrentSelection = 0;
					TouchKeyPad.PreviousSelection = 0;
					TouchKeyPad.IsVisible = 1;
					DispTouchKeyPad(FORMAT_CONNECT_GPRS);
					ScreenFormatData.F_TouchScreenVisible=1;
			}
			else if(ScreenFormatData.CurrentFormat == FORMAT_CONNECT_GPRS)
			{}
			ScreenFormatData.CurrentFormat = Format;
							ScreenFormatData.F_SmallTimeVisible=0  ;
				ScreenFormatData.F_BigTimeVisible=0    ;
				ScreenFormatData.F_GridVisible=0       ;
				ScreenFormatData.F_SubMenuVisible=0    ;
				ScreenFormatData.F_SatusBar1Visible=0  ;
				ScreenFormatData.F_SatusBar2Visible=0  ;
			break;	
/*		
		case FORMAT_SCROLL_MENU:
		{
			ScreenFormatData.CurrentFormat = FORMAT_SCROLL_MENU;
		}
		break;*/
	}
	EnableDisplay();
}

void DefaultGrid_SubmenueScreen(void)  // This fn will format all sscreen with Background colour Except TouchKepad
{
		struct RectInfo rectinfo;
				
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour;
				rectinfo.Hight = ThemeSelect.SubmenueTitleMSGHeight;  
				rectinfo.Width = ThemeSelect.SubmenueTitleMSGWidth;  
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.SubmenueTitleMSGStartXO, ThemeSelect.submenueSatusMSGStartYO);
	
				
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
				rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT + DUMMY_ZONE_HEIGHT-1) ;  // 240 - 35  = 205
				rectinfo.Width = 320;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight + DUMMY_ZONE_HEIGHT);
}
void DisplayWallpaper(void)
{
		struct RectInfo rectinfo;
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;     
				rectinfo.Hight = ThemeSelect.StatusbarHeight;  // 18
				rectinfo.Width = ThemeSelect.StatusbarWidth;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.StatusbarStartXO,ThemeSelect.StatusbarStartYO); 
				
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour;
				rectinfo.Hight = ThemeSelect.TimeDateHeight;  // 20
				rectinfo.Width = ThemeSelect.TimeDateWidth;  // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.TimeDateStartXO,ThemeSelect.TimeDateStartYO);
				
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
				rectinfo.Hight = ThemeSelect.BackGroundHeight;  // 240 - 35  = 205
				rectinfo.Width = ThemeSelect.BackGroundWidth;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.BackGroundStartXO,ThemeSelect.BackGroundStartYO);

// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;   
// 				rectinfo.Hight = ThemeSelect.SatusMSGHeight;  // 240 - 35  = 205
// 				rectinfo.Width = ThemeSelect.SatusMSGWidth;   // 320
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,ThemeSelect.SatusMSGStartXO,ThemeSelect.SatusMSGStartYO);

}


void ClrScreenWithoutStatusBar(void)
{
struct RectInfo rectinfo;
	rectinfo.FillType = RCTFILL_PLAIN;
	rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;
	rectinfo.Hight = 240-18;  // 20
	rectinfo.Width = 320;  // 320
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo,ThemeSelect.TimeDateStartXO,ThemeSelect.TimeDateStartYO);
}
void ClrScreenScrollToGrid(void)
{
	struct RectInfo rectinfo;
	rectinfo.FillType = RCTFILL_PLAIN;
	rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;
	rectinfo.Hight = 240-18-50;  // 20
	rectinfo.Width = 320;  // 320
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo,ThemeSelect.TimeDateStartXO,ThemeSelect.TimeDateStartYO);
}
void DisplayWallpaperWithoutGrid(void)
{
		struct RectInfo rectinfo;
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;     
// 				rectinfo.Hight = ThemeSelect.StatusbarHeight;  // 18
// 				rectinfo.Width = ThemeSelect.StatusbarWidth;   // 320
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,ThemeSelect.StatusbarStartXO,ThemeSelect.StatusbarStartYO); 
				
				//time date clear with red color
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour;
				rectinfo.Hight = ThemeSelect.TimeDateHeight;  // 20
				rectinfo.Width = ThemeSelect.TimeDateWidth;  // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.TimeDateStartXO,ThemeSelect.TimeDateStartYO);
				
				//portion below time-date, clear with white color
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
				rectinfo.Hight = ThemeSelect.BackGroundHeight;  // 240 - 35  = 205
				rectinfo.Width = ThemeSelect.BackGroundWidth;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.BackGroundStartXO,ThemeSelect.BackGroundStartYO);
			
				//status msg clear with white color
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;   
				rectinfo.Hight = 15;  // 240 - 35  = 205
				rectinfo.Width = ThemeSelect.SatusMSGWidth;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.SatusMSGStartXO,ThemeSelect.SatusMSGStartYO);
}

void DisplayScrollMenu(unsigned char MenuIndex)
{
	char i=MenuIndex,ScrollMenu=1;
//	unsigned char CurrentIconNo,PreviousIconNo;
		struct RectInfo rectinfo;
DisableDisplay();
    i++;
	while( (i < MAX_DISPLAY_NEWMODE_MEMBER) && (ScrollMenu<= MAX_SCROLL_LINE) )
	{
		if(UserInt1[MenuIndex].ModeNo+1 == UserInt1[i].ModeNo)
		{
			if(ScrollMenu == 1)
			{
			//display highlighted string
				rectinfo.FillType = RCTFILL_PLAIN;   // //display highlighted background   //
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuStrBackgroundColour;   
				rectinfo.Hight = 20;  
				rectinfo.Width = 320;   
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,	SCROLL_DATA.Coordinate[ScrollMenu-1][0],SCROLL_DATA.Coordinate[ScrollMenu-1][1]);
				sprintf((char*)DisplayTempBuffer,"%2d:%s",ScrollMenu,
													UserInt1[i].MenuName);
				drawString(	SCROLL_DATA.Coordinate[ScrollMenu-1][0],		//x
							SCROLL_DATA.Coordinate[ScrollMenu-1][1],      //y
							ThemeColour[SysInfo.ThemeSelectNo].SubmenuHighlightStrColour,                //color
							SCROLL_DATA.NormalFontInfo,                 //font
							DisplayTempBuffer);              //string
			}
			else
			{
			//display normal string
				sprintf((char*)DisplayTempBuffer,"%2d:%s",ScrollMenu,
													UserInt1[i].MenuName);
				drawString(	SCROLL_DATA.Coordinate[ScrollMenu-1][0],		//x
							SCROLL_DATA.Coordinate[ScrollMenu-1][1],      //y
							ThemeColour[SysInfo.ThemeSelectNo].SubmenuUnHighlightStrColour,                //color
							SCROLL_DATA.NormalFontInfo,                 //font
							DisplayTempBuffer);              //string
			}
			++ScrollMenu;
		}
		else if(UserInt1[MenuIndex].ModeNo >= UserInt1[i].ModeNo)
		{
			EnableDisplay();
			return;
		}
		i++;
	}
EnableDisplay();
}
/**
	start form this menu ON     MONDAY    MONDAY 
*/
void UpdateScrollMenu(unsigned char MenuIndex)
{
	char i=MenuIndex,j=MenuIndex,ScrollMenu=1;
	//unsigned char CurrentIconNo,PreviousIconNo;
	struct RectInfo rectinfo;
     i++;
DisableDisplay();
	if( ScrollMenuData.ScrollMenuCurrentSelection > (MAX_SCROLL_LINE + ScrollMenuData.firstMenuNum -1) )
	{//we need next page of scroll menu
		if( (ScrollMenuData.ScrollMenuCurrentSelection -1)% (MAX_SCROLL_LINE) == 0)
		{
			ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection;
		}
		else
		{ //do correction for first menu
			if(ScrollMenuData.ScrollMenuCurrentSelection % (MAX_SCROLL_LINE) == 0)
			{
				ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - MAX_SCROLL_LINE +1;
			}
			else// up key starting 
			{
				ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - ((ScrollMenuData.ScrollMenuCurrentSelection % 5) - 1);
//				ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - (ScrollMenuData.ScrollMenuCurrentSelection -1)% (MAX_SCROLL_LINE);
			}	
		}
		
//clear scrolling menus
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = (USER_SECTION_SIZE_Y-USER_LINE2_START_Y0 + DUMMY_ZONE_HEIGHT);  
					rectinfo.Width = USER_LINE2_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,	USER_LINE3_START_X0,USER_LINE3_START_Y0);				
	}
	else if ( ScrollMenuData.ScrollMenuCurrentSelection < ScrollMenuData.firstMenuNum )
	{//check if  previous and we need next page of scroll menu
		if(ScrollMenuData.ScrollMenuCurrentSelection == 1)
		{
			ScrollMenuData.firstMenuNum = 1;
		}
		else
		{
			if(ScrollMenuData.ScrollMenuCurrentSelection % (MAX_SCROLL_LINE) == 0)
			{
				ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - MAX_SCROLL_LINE +1;
			}
			else
			{
				ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - ((ScrollMenuData.ScrollMenuCurrentSelection % 4) - 1);
//				ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - (ScrollMenuData.ScrollMenuCurrentSelection -1)% (MAX_SCROLL_LINE);
			}
//			ScrollMenuData.firstMenuNum = ScrollMenuData.ScrollMenuCurrentSelection - (MAX_SCROLL_LINE-1);
		}
		
		//clear scrolling menus
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = (USER_SECTION_SIZE_Y-USER_LINE2_START_Y0);  
					rectinfo.Width = USER_LINE2_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,	USER_LINE3_START_X0,USER_LINE3_START_Y0);		
	}

	j =1;	//this is used for actual position of menu in structure
	ScrollMenu=1; //this is used for view of glcd
	while( (i < MAX_DISPLAY_NEWMODE_MEMBER) && (ScrollMenu<= MAX_SCROLL_LINE) )
	{
		if(UserInt1[MenuIndex].ModeNo+1 == UserInt1[i].ModeNo)
		{
			if(j >=ScrollMenuData.firstMenuNum)
			{
				if(j == ScrollMenuData.ScrollMenuCurrentSelection)
				{
				//display highlighted string
				rectinfo.FillType = RCTFILL_PLAIN;   // //display highlighted background   //
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuStrBackgroundColour;   
				rectinfo.Hight = 20;  
				rectinfo.Width = 320;   
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,	SCROLL_DATA.Coordinate[ScrollMenu-1][0],SCROLL_DATA.Coordinate[ScrollMenu-1][1]);
					
					sprintf((char*)DisplayTempBuffer,"%2d:%s",j,
														UserInt1[i].MenuName);
					drawString(	SCROLL_DATA.Coordinate[ScrollMenu-1][0],		//x
								SCROLL_DATA.Coordinate[ScrollMenu-1][1],      //y
								ThemeColour[SysInfo.ThemeSelectNo].SubmenuHighlightStrColour,                //color
								SCROLL_DATA.NormalFontInfo,                 //font
								DisplayTempBuffer);              //string
				}
				else
				{
				//display normal string
					rectinfo.FillType = RCTFILL_PLAIN;   // //display highlighted background   //
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = 20;  
					rectinfo.Width = 320;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,	SCROLL_DATA.Coordinate[ScrollMenu-1][0],SCROLL_DATA.Coordinate[ScrollMenu-1][1]);
		
					sprintf((char*)DisplayTempBuffer,"%2d:%s",j,
														UserInt1[i].MenuName);
					drawString(	SCROLL_DATA.Coordinate[ScrollMenu-1][0],		//x
								SCROLL_DATA.Coordinate[ScrollMenu-1][1],      //y
								ThemeColour[SysInfo.ThemeSelectNo].SubmenuUnHighlightStrColour,                //color
								SCROLL_DATA.NormalFontInfo,                 //font
								DisplayTempBuffer);              //string
				}
				++ScrollMenu;
			}
		++j;
		}
		else if(UserInt1[MenuIndex].ModeNo >= UserInt1[i].ModeNo)
		{
			EnableDisplay();
			return;
		}
		i++;
	}
	EnableDisplay();
}
unsigned char GetMaxScrollMenu(unsigned char Index)
{
	char i=0,j=Index;
	++j;
	while( j < MAX_DISPLAY_NEWMODE_MEMBER )
	{
		if(UserInt1[Index].ModeNo+1 == UserInt1[j].ModeNo)
		{
			i++;
		}
		else if(UserInt1[Index].ModeNo >= UserInt1[j].ModeNo)
		{
			return i;
		}
		++j;
	}
	return i;
}
unsigned char GetModeIndexFromSelection(unsigned char Index,unsigned char CurrentSelection)
{
	char i=Index,j=1;
	i++;
	while( i < MAX_DISPLAY_NEWMODE_MEMBER )
	{
		if(UserInt1[Index].ModeNo+1 == UserInt1[i].ModeNo)
		{
			if(CurrentSelection == j)
				return i;
			++j;
		}
		else if(UserInt1[Index].ModeNo >= UserInt1[i].ModeNo)
		{
			return Index;
		}
		++i;
	}
	return Index;
}

const char Disp_Month[12][4] = {
"Jan",
"Feb",
"Mar",
"Apr",		
"May",
"Jun",	
"Jul",
"Aug",
"Sep",
"Oct",	
"Nov",
"Dec",		
};

void DisplayDateTime(void)
{
//	static char minute=0,temp;
	 static char Toggle=0;	
#ifdef ENABLE_WATCHDOG
		WDTHandleType = WDT_MAIN_LOOP;
		WDTFeed();		//Clear watchdog timer
#endif

	if(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)
	{  
		//show big time here
//		if( (minute != Datetime.Time.Min) || ScreenFormatData.F_BigTimeVisible==0)
		if(ScreenFormatData.F_BigTimeVisible==0)
		{
			struct RectInfo rectinfo;
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour;
				rectinfo.Hight = ThemeSelect.TimeDateHeight;  
				rectinfo.Width = ThemeSelect.TimeDateWidth;  // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.TimeDateStartXO,ThemeSelect.TimeDateStartYO);
		}
			//minute = Datetime.Time.Min;
		ScreenFormatData.F_BigTimeVisible=1;
		if(Toggle)
		{
			sprintf((char*)DisplayTempBuffer,"%02d %02d %02d",Datetime.Time.Hour,
											Datetime.Time.Min,
											Datetime.Time.Secs);
			Toggle = 0;
		}
		else
		{
			sprintf((char*)DisplayTempBuffer,"%02d:%02d:%02d",Datetime.Time.Hour,
											Datetime.Time.Min,
											Datetime.Time.Secs);
//			Toggle = 1;
		}
// 			drawStringWithBackground(	BIG_TIME_START_X0,		//x  Time
// 										ThemeSelect.TimeDateStartYO,	    //y
			DrawCenterTextWithBackGround(ThemeSelect.TimeDateStartYO+DUMMY_ZONE_HEIGHT-6,
														BIG_TIME_FONT_COLOR,
														BIG_TIME_FONT_INFO,
														320,	
														DisplayTempBuffer,
														ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);

			sprintf((char*)DisplayTempBuffer,"%s %02d %s %d",WEEK_DAY[CWeekDay],
														Datetime.Date.Day,
														Disp_Month[Datetime.Date.Month-1],
														CurrentTimeDt.tm_year);
	// 													Disp_Month[Datetime.Date.Month-1]);
	// 		(lcdGetWidth() - drawGetStringWidth(fontInfo, text)) / 2
			DrawCenterTextWithBackGround(BIG_DATE_START_Y0,
														BIG_DATE_FONT_COLOR,
														BIG_DATE_FONT_INFO,
														320,
														DisplayTempBuffer,
														ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);

// 		
// 					drawStringWithBackground(	BIG_DATE_START_X0,		//x
// 										BIG_DATE_START_Y0,	    //y
// 										BIG_DATE_FONT_COLOR,      //color
// 										BIG_DATE_FONT_INFO,       //font
// 										DisplayTempBuffer,
// 										ThemeColour[ThemeNo].TimeDateColour);  //string

// 		
// 			sprintf((char*)DisplayTempBuffer,"%s",CurrentTimeDt.tm_year);
// 			drawStringWithBackground(	BIG_YEAR_START_X0,		//x
// 										BIG_YEAR_START_Y0,	    //y
// 										BIG_DATE_FONT_COLOR,      //color
// 										BIG_DATE_FONT_INFO,       //font
// 										DisplayTempBuffer,
// 										ThemeColour[ThemeNo].TimeDateColour);  //string

// 		drawStringWithBackground(	BIG_DATE_START_X0,		//x
// 									BIG_DATE_START_Y0,	    //y
// 									BIG_DATE_FONT_COLOR,      //color
// 									BIG_DATE_FONT_INFO,       //font
// 									DisplayTempBuffer,
// 									ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);  //string


// 		sprintf((char*)DisplayTempBuffer,"%s ",Disp_Month[Datetime.Date.Month-1]);
// 		drawStringWithBackground(	BIG_YEAR_START_X0,		//x
// 									BIG_YEAR_START_Y0,	    //y
// 									BIG_DATE_FONT_COLOR,      //color
// 									BIG_DATE_FONT_INFO,       //font
// 									DisplayTempBuffer,
// 									ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);  //string

    }
	else if(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_MENU)
	{	
		sprintf((char*)DisplayTempBuffer,"%02d/%02d/%02d",Datetime.Date.Day,
												Datetime.Date.Month,
												Datetime.Date.Year	);
		drawStringWithBackground(	SMALL_DATE_START_X0,		//x
					SMALL_DATE_START_Y0,	    //y
					SMALL_DATE_FONT_COLOR,      //color
					SMALL_DATE_FONT_INFO,       //font
					DisplayTempBuffer,  //string
					ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
	
 		sprintf((char*)DisplayTempBuffer,"%02d:%02d",Datetime.Time.Hour,
 												Datetime.Time.Min);
// 			sprintf((char*)DisplayTempBuffer,"%02d:%02d:%02d",Datetime.Time.Hour,
// 											Datetime.Time.Min,
// 											Datetime.Time.Secs);
		drawStringWithBackground(	SMALL_TIME_START_X0,		//x
					SMALL_TIME_START_Y0,	    //y
					SMALL_TIME_FONT_COLOR,      //color
					SMALL_TIME_FONT_INFO,       //font
					DisplayTempBuffer,
					ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);  //string
	}
		/*
	else if(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN || ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN)
	{
		//clear small time area
		DisplayBackGround(	SMALL_TIME_START_X0,
							SMALL_TIME_START_Y0,
							SMALL_TIME_SECTOR_SIZE_X, 
							SMALL_TIME_SECTOR_SIZE_Y,
							image16) ;
		DisplayBackGround(	SMALL_DATE_START_X0,
							SMALL_DATE_START_Y0,
							SMALL_DATE_SECTOR_SIZE_X, 
							SMALL_DATE_SECTOR_SIZE_Y,
							image16) ;
		
		//show small time here
		sprintf((char*)DisplayTempBuffer,"%02d:%02d:%02d",Datetime.Time.Hour,
												Datetime.Time.Min,
												Datetime.Time.Secs	);
		drawString(	SMALL_TIME_START_X0,		//x
					SMALL_TIME_START_Y0,	    //y
					SMALL_TIME_FONT_COLOR,      //color
					SMALL_TIME_FONT_INFO,       //font
					DisplayTempBuffer);  //string

		sprintf((char*)DisplayTempBuffer,"%02d/%02d/%02d",Datetime.Date.Day,
												Datetime.Date.Month,
												Datetime.Date.Year	);
		drawString(	SMALL_DATE_START_X0,		//x
					SMALL_DATE_START_Y0,	    //y
					SMALL_DATE_FONT_COLOR,      //color
					SMALL_DATE_FONT_INFO,       //font
					DisplayTempBuffer);  //string
	}*/
}
//extern const unsigned char Auth[]; //icon arrays
//extern const unsigned char unAuth[];
//extern const unsigned char AuthPaletteArray[4];
//extern const unsigned char UnAuthPaletteArray[4];

void DisplayEventIcon(short event)   //this displays icon for events like authorised user un auth user
{
	switch(event)
	{
		case EVENT_VALID_CARD:
		{
			//show icon here
#ifdef SUPPORT_SPEECHIC
			PlaySoundMsg(AUTHERISED);  // Speech code
#endif			
//			waitX10ms(100);						
// 			DisplayBmp(	SCREEN_ICON1_X0,
// 						SCREEN_ICON1_Y0,
// 						SCREEN_ICON1_WIDTH,
// 						SCREEN_ICON1_HEIGHT,
// 						Auth);
// 					DisplayBmp1Bit(	SCREEN_ICON1_X0,
// 						SCREEN_ICON1_Y0,
// 						SCREEN_ICON1_WIDTH,
// 						SCREEN_ICON1_HEIGHT,
// 						Auth,
// 						AuthPaletteArray);	
#ifdef INSERT_SDCARD
				SDDisplayBackGround(SCREEN_ICON1_X0,   
										SCREEN_ICON1_Y0,
										SCREEN_ICON1_WIDTH,
										SCREEN_ICON1_HEIGHT,
										6,IMAGES_GROUP);
#endif		
		}
		break;
		case EVENT_CARD_NOT_FOUND:
		{
			//show icon here
#ifdef SUPPORT_SPEECHIC
			PlaySoundMsg(NOT_AUTHERISED);  // Speech code
			waitX10ms(20);
#endif	
//			waitX10ms(100);			

// 			DisplayBmp(	SCREEN_ICON1_X0,
// 						SCREEN_ICON1_Y0,
// 						SCREEN_ICON1_WIDTH,
// 						SCREEN_ICON1_HEIGHT,
// 						unAuth);
// 						DisplayBmp1Bit(	SCREEN_ICON1_X0,
// 						SCREEN_ICON1_Y0,
// 						SCREEN_UNAUTH_WIDTH,
// 						SCREEN_UNAUTH_HEIGHT,
// 						unAuth,
// 						UnAuthPaletteArray);	
#ifdef INSERT_SDCARD			
							SDDisplayBackGround(SCREEN_ICON1_X0,   
										SCREEN_ICON1_Y0,
										SCREEN_UNAUTH_WIDTH,
										SCREEN_UNAUTH_HEIGHT,
										7,IMAGES_GROUP);
#endif												
		}
		break;
		default :
		{}
		break;
 	}
}
/**
	this function shows event like batery, lock unlock e.t.c. this all is only icon of 16X16 pixel
*/
const struct stTopStatusData TopStatusData[MAX_STATUS_ICON]={
	{TOP_STATUS_ICON1_X0,TOP_STATUS_ICON1_Y0,1,0},
	{TOP_STATUS_ICON1_X0,TOP_STATUS_ICON1_Y0,1,0},
	{TOP_STATUS_ICON1_X0,TOP_STATUS_ICON1_Y0,1,0}
	};
void DisplayStatusIcon(unsigned char Event,unsigned char Status) // Status of Device locked or Unlocked
{
	if(Status == 1)
	{
		DisplayBmp1Bit(	TopStatusData[Event].x0,
						TopStatusData[Event].y0,
						TOP_STATUS_ICON_WIDTH,
						TOP_STATUS_ICON_HEIGHT,
						TopStatusIconDataArray[ TopStatusData[Event].ActiveIconNum ],
						TopStatusIconPaletteArray[ TopStatusData[Event].ActiveIconNum ]);	
	}
	else
	{
		DisplayBmp1Bit(	TopStatusData[Event].x0,
						TopStatusData[Event].y0,
						TOP_STATUS_ICON_WIDTH,
						TOP_STATUS_ICON_HEIGHT,
						TopStatusIconDataArray[ TopStatusData[Event].InActiveIconNum ],
						TopStatusIconPaletteArray[ TopStatusData[Event].InActiveIconNum ]);	
	}
}
/**
	this function shows event like fire,
	this is smal icon + string on Top bar.
*/
unsigned char BottomEventIcon[MAX_BOTTOM_EVENT][2]={
			{EVENT_FIRMWARE_UPGRADE,0},
			{EVENT_FIRE_ALARM_HIGH,0},
			{EVENT_TAMPER_ALARM_HIGH,0},
			{EVENT_INTRUSION_ALARM_HIGH,0},
			{EVENT_DOTL1_ALARM,0},
			{EVENT_FORCE1_ALARM,0},
			{EVENT_DEAD_MAN_ZONE,0},
			{EVENT_DUEL_USER_2,0}
		};
		
void DisplayBottomStatusIcon(unsigned char Event,unsigned char *Str,unsigned char IconFlag,unsigned char IconNo) // Display Event String at Top and icon .Icon not yet Implimented
{																																						// IconFlag -> 0 no icon for Event , 1->Icon for Event 
//	unsigned char i;
	struct RectInfo rectinfo;
	
	if(ScreenFormatData.CurrentFormat == FORMAT_BOOT_SCREEN)   //it shown sensor time out msg in boot screen so remove it
		return ;
		
// 	for(i=0;i<MAX_BOTTOM_EVENT;++i)	
// 	{
// 		if(BottomEventIcon[i][0] == Event)
// 		{
// 			break;
// 		}
// 	}

	//clear bottom msg area.
	rectinfo.FillType = RCTFILL_PLAIN;
	rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;
	rectinfo.Hight = BOTTOM_STATUS_ICON_SECTION_HEIGHT ;
	rectinfo.Width = BOTTOM_STATUS_ICON_SECTION_WIDTH ;
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo, DISP_STATUSMSGHEIGHT_X0, DISP_STATUSMSGHEIGHT_Y0);

// 	if(i==MAX_BOTTOM_EVENT)
// 	{
// 		//clear icon area because no icon available.
// 	}
//	else
//	{
		//draw icon number 
// 		DisplayBmp1Bit(	BOTTOM_STATUS_ICON_X0,
// 						BOTTOM_STATUS_ICON_Y0,
// 						BOTTOM_STATUS_ICON_WIDTH,
// 						BOTTOM_STATUS_ICON_HEIGHT,
// 						BottomStatusIconDataArray[ BottomEventIcon[i][1] ],
// 						BottomStatusIconPaletteArray[ BottomEventIcon[i][1] ]);	
//		SDDisplayBackGround(1,1,16,6,1,EVENT_ICON_GROUP);
		if(IconFlag ==1)
		{
#ifdef INSERT_SDCARD			
			SDDisplayBackGround(BOTTOM_STATUS_ICON_X0,
										BOTTOM_STATUS_ICON_Y0,
										BOTTOM_STATUS_ICON_WIDTH,
										BOTTOM_STATUS_ICON_HEIGHT,
										IconNo,EVENT_ICON_GROUP);
#endif	
		}			
		else{}
//	}

	//draw center string.
	DrawCenterText(	BOTTOM_STATUS_ICON_SECTION_Y0,
				ThemeColour[SysInfo.ThemeSelectNo].SatusMSGColour,   // 
				BOTTOM_STATUS_MSG_FONTINFO_PTR,
				(unsigned char*)Str);
}

void UpdateRadioScroll(void)
{
	DisableDisplay();

	//find displaying page number.
	Temp1 = stRadioScrollData.CurrSeletion / MAX_RADIO_BUTTON_LINES; //page no. from 0 to..
	Temp3=0;//page update flag
	if(stRadioScrollData.PageNumber != Temp1)
	{//need to display different page so clear scroll screen.
		struct RectInfo rectinfo;
		
		rectinfo.FillType = RCTFILL_PLAIN;
		rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
		rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
		rectinfo.Width = 320;   // 320
		rectinfo.BorderColor = 0;
		DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
		
		//updte page number.
		stRadioScrollData.PageNumber = Temp1;
		Temp3 =1;//page is updated
	}
	//find first element of page.								
	Temp2 = Temp1*MAX_RADIO_BUTTON_LINES;					//first element from 0 to ...
	//display max or upto last element from that.
	Temp1 = 0; //
	while( (Temp1 < MAX_RADIO_BUTTON_LINES) && (Temp2 < stRadioScrollData.MaxScrollElement) )
	{
		sprintf( (char*)DisplayTempBuffer,"%s",(unsigned char*)stRadioScrollData.Array[Temp2]);
		if(Temp2 == stRadioScrollData.CurrSeletion)
			DisplayRadioButton(DisplayTempBuffer,ROW_USER_ENTRY + Temp1,1);	//display highlighted		
		else if(Temp3==1 || Temp2 == stRadioScrollData.PrevSeletion)
			DisplayRadioButton(DisplayTempBuffer,ROW_USER_ENTRY + Temp1,0);	//display normal
		
		Temp1++;
		Temp2++;
	}
EnableDisplay();	
}
void DisplayRadioScroll(void) 
{
	char j;
DisableDisplay();
	//find displaying page number.
	Temp1 = stRadioScrollData.CurrSeletion / MAX_RADIO_BUTTON_LINES; //page no. from 0 to..
	//find first element of page.								

		if(stRadioScrollData.PageNumber != Temp1)
		{//need to display different page so clear scroll screen.
			struct RectInfo rectinfo;
			
			rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT + DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
			
			//updte page number.
//			stRadioScrollData.PageNumber = Temp1;
//			Temp3 =1;//page is updated
		}
		stRadioScrollData.PageNumber = Temp1;
		
		Temp1 = 0;
		Temp2 = stRadioScrollData.PageNumber*MAX_RADIO_BUTTON_LINES;
		for(j = Temp2; j < (Temp2 + MAX_RADIO_BUTTON_LINES); j++)
		{
			if( j < stRadioScrollData.MaxScrollElement)
			{
				sprintf( (char*)DisplayTempBuffer,"%s",(unsigned char*)stRadioScrollData.Array[j]);	
				if(j == stRadioScrollData.CurrSeletion)
					DisplayRadioButton(DisplayTempBuffer,ROW_USER_ENTRY + Temp1,1);	//display highlighted		
				else	
					DisplayRadioButton(DisplayTempBuffer,ROW_USER_ENTRY + Temp1,0);	//display normal
			}
			Temp1++;
		}
EnableDisplay();
}
void DisplayDummy(void)
{
	struct RectInfo rectinfo;
	
	rectinfo.FillType = RCTFILL_PLAIN;
	rectinfo.Color = DUMMY_ZONE_COLOR;     
	rectinfo.Hight = DUMMY_ZONE_HEIGHT;  // 
	rectinfo.Width = DUMMY_ZONE_WIDTH;   //
	rectinfo.BorderColor = 0;
	DrawRect(&rectinfo,DUMMY_ZONE_X0,DUMMY_ZONE_Y0); 
}
