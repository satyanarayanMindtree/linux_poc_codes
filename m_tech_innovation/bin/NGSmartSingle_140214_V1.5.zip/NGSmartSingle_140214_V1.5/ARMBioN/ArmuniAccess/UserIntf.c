#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "LPC23xx.h"
#include "config.h"
#include "portdef.h"
#include "version.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
//#include "portlcd.h"																			   
#include "spi.h"
#include "rtc.h"
#include "serial.h"
#include "access.h"
#include "portlcd.h"
#include "tranxmgmt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "userintf.h"
#include "cardmgmt.h"
#include "memory.h"
#include "rdcont.h"
#include "rdpoll.h"
//#include "tcpip.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif
#ifdef BIOLITE_HARDWARE
//	#include "timer.h"
#endif
#include "smartcard.h"
#ifdef ENABLE_GSM_GPRS
	#include "GSMModem.h"
#endif

#include "TemplatesonFlash.h"
#include "IClassRdr.h"
#include "IClassRdrProcess.h"

#include "userIntfGLCD.h"
#include "../../GLCD/BMPImage/sea3_565.h"
#include "timer.h"

#ifdef SUPPORT_SPEECHIC
#include "DriverSpeech_IC.h"
#endif
#include "../../GLCD/drivers/lcd/tft/fonts/veramonobold11.h"



const extern __packed struct PROTOCOL_CMD_HNDL SetSysPara[];
const extern __packed struct PROTOCOL_CMD_HNDL OtherPara[];
const extern __packed struct PROTOCOL_CMD_HNDL Usefulpara[];
extern unsigned char ucFnDeleteFile (unsigned char *fileName);

//extern RTCTime Datetime;	
RTCTime DDateTime;
extern volatile BYTE KeyBuff[];
extern volatile BYTE KeyWritePtr,KeyReadPtr;
//#ifdef SMART_CARD
#ifdef	BIO_METRIC
extern unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE]; 
//	extern unsigned char BufferTemp[MAX_BIO_TEMPLATE_SIZE]; 

#endif
//#endif
extern BYTE UserName[20];
extern unsigned char AdminLogOutTimer,IdleKeyCounter,F_Password;
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;
extern CardData Carddata;

extern BYTE F_BIO_COMM,F_UserMessageDisplay,F_Password,F_UserTimeOut,F_KeyIdleTime;
extern BYTE CWeekDay;//BioCmdStatus;
//extern WORD BioCmdSize,SensorTemplateSize;
extern DWORD BioCmdData;
extern BYTE FaclityCode1,ReaderNo; 
extern unsigned int ReceivedPin;
extern BYTE InOutReader ,InOutReaderTime,F_DisplayINOutToggle;
unsigned char CardPositionCount; 
#ifdef SUPPORT_NSERIES2
extern unsigned char F_DuelUserAuth;
#endif
extern unsigned int AdminMenuRight;
extern SmartCardData CurrentCard;
unsigned char F_ChkAdminFinger;
extern USOCKET MyUDP_Socket;

void DisplayUsefulPara(unsigned char parano);
void InitNetworkParameter(void);
void InitParameters(void);
int InitialiseSocket(unsigned long ip, unsigned long mask,unsigned long gateway);
void HandleWeiCardDataDisplay(unsigned char keytype);
void HandleUserHostVerify(unsigned eventtype);
void HandleSerialReaderEnaDis(unsigned char keytype);
extern volatile WORD ReceiveCount;
extern BYTE DspRdrNo;
void HandleSubMenuScroll(unsigned char key);
void HandleIpNumericKey(void);

extern unsigned char DisplayTempBuffer[50];
unsigned char DoNotProcessThisKey =0;
//extern unsigned char GridIconSelection =0;
//extern unsigned char CurrentModeNo;
extern const struct stSCROLL_DATA SCROLL_DATA;

unsigned short Xpos,Xdigts,StartXpos;
unsigned char TempUse,TempUse1;   // variables for general purpose use 
char ipaddstr[20];
_CExtraInfo  tExtInfo;

extern unsigned char F_authScreenTimer,F_authScreenTimerEnable;				
extern struct RADIO_SCROLL_DATA stRadioScrollData;
void Delayandreturnback(void);
const unsigned char DISPLAY_MODE[MAX_DISPLAY_MODE+1][17] = {  //ARMD0411
//			"    Welcome     ",		//0
			"                ",		//0
#ifndef BIOLITE_LOW_END
			"Change Pin:     ",		//1												 
#else
			"No Function:    ",		//1
#endif
			"Admin User:     ",		//2
			"Add User:       ",		//3
			"Del User:       ",		//4
			"Search User:    ",		//5
			"Set Time Date:  ",		//6
#ifdef BIO_METRIC
			"AddFing To ID:  ",		//7
#else
			"Func Not Defined",		//7
#endif
			"HELP MENU       ",		//8
			"MultiFunction:  ",		//9
			"InitialiseSystem",		//10
			"ACS Cont. No:   ",		//11
			"Add Admin ID:   ",		//12
#ifdef BIO_METRIC
			"Identify Mode:  ",		//13
#else
			"Func Not Defined",		//13
#endif
			"Door OpenTime:  ",		//14
#ifdef BIO_METRIC
			"SecurityLevel:  ",		//15
#else
			"Func Not Defined",		//15
#endif
#ifndef BIOLITE_LOW_END
			"Facility Code:  ",		//16
#else
			"No Function:    ",		//16
#endif
			"Controller Type:",		//17
			"Add User Data:  ",	  	//18//ARMD0193
			"MultiFunction:  ",		//19
			"IP Address:     ",     //20
			"Disp System Para",	  	//21
			"EN/DI SharedDOTL",	    //22
#ifdef BIO_METRIC
			"Reader In/Out:  ",		//23
			"No Function:    ",	    //24 ARMD0354
#else
			"No Function:    ",		//23
	#ifdef SUPPORT_2_4DOOR
			"No Function:    ",		//24
	#else
			"Reader Config:  ",	    //24	   //ARMD0156
	#endif
#endif
			"Card Digit      ",		//25
			"Controller No:  ",		//26
			"No Function:    ",	    //27
			"AUTH ServerCHK  ",	    //28		//ARMF2004	
			"MultiFunction:  ",		//29
#ifndef	SMART_CARD
			"No Function:    ",	    //30
#else
			"Enable SerialRDR",	    //30
#endif
			"System Parameter",		//31
#ifdef WEIGAND_OUT_READER				//ARMD0184
			"WeigandOut Bits ",		//32
#else
			"No Function:    ",	    //32
#endif
#ifndef BIO_METRIC  //ARMD0318
			"Bulk Add Card:  ",	    //33
#else
			"No Function:    ",	    //33
#endif
			"FIRE-TAMPER EnDs",	    //34
#ifdef ENABLE_GSM_GPRS
			"GPRS En/Di       ",    //35
#else
			"No Function:     ",    //35
#endif
			"No Function:     ",    //36	 //out facility code
			"MAC Security :   ",	//37
			"Wei Card Data    ",		//38
			"MultiFunction:  ",		//39
			"Network Test:   ",	    //40
			"DUA SearchCard: ",	    //41
};

__packed struct DISP_MENU_HNDL
{
   unsigned char DispName[17];
   unsigned int MenuAuthType;
};

const __packed struct DISP_MENU_HNDL DisplayAuthMenu[] =
{  //we have to decide rights for every menu accessibility currently i have enabled all menus
   //for MenuAuthType we are going to OR required admin type in below structure
	{"    Welcome     ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},					//0
	{"Change Pin:     ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},					//1
	{"AdminPassword:  ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },					//2
	{"Add Card :      ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },				//3
	{"Del Card :      ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },					//4
	{"Search Card :   ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},					//5
	{"Set Time Date   ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN },					//6
	{"AddFing To ID:  ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },					//7
	{"HELP MENU       ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},					//8
	{"MultiFunction:  ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},					//9
	{"InitialiseSystem",BIT_SUPER_ADMIN},					//10
	{"ACS Cont. No:   ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN },					//11
	{"Admin Add/Del:  ",BIT_SUPER_ADMIN },					//12
	{"Identify Mode:  ",BIT_SUPER_ADMIN | BIT_ADMIN },					//13
	{"Door OpenTime:  ",BIT_SUPER_ADMIN | BIT_ADMIN },					//14
	{"SecurityLevel:  ",BIT_SUPER_ADMIN | BIT_ADMIN },					//15
	{"Facility Code:  ",BIT_SUPER_ADMIN | BIT_ADMIN },					//16
	{"Controller Type:",BIT_SUPER_ADMIN | BIT_ADMIN },					//17
   {"Add User Data:  ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },	  				//18
	{"No Function     ",BIT_SUPER_ADMIN},					//19
   {"IP Address:     ",BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},     			//20
   {"Disp System Para",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN },	  				//21
	{"EN/DI SharedDOTL",BIT_SUPER_ADMIN | BIT_ADMIN},	    			//22
	{"No Function     ",BIT_SUPER_ADMIN},					//23
	{"No Function     ",BIT_SUPER_ADMIN},					//24
	{"Card Digit      ",BIT_SUPER_ADMIN},					//25
   {"Controller No   ",BIT_SUPER_ADMIN},					//26
   {"No Function:    ",BIT_SUPER_ADMIN},					//27
   {"EMP IN Count:   ",BIT_SUPER_ADMIN},					//28
	{"No Function:    ",BIT_SUPER_ADMIN},					//29
   {"Enable SerialRDR",BIT_SUPER_ADMIN | BIT_ADMIN },					//30
   {"System Parameter",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },					//31 //F0018 Add New service menu to display useful system parameters
	{"WeigandOut Bits ",BIT_SUPER_ADMIN | BIT_ADMIN },					//32
	{"Bulk Add Card:  ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },	//33	
	{"No Function     ",BIT_SUPER_ADMIN},					//34
#ifdef ENABLE_GSM_GPRS
   {"GPRS Diagnosis  ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN },					//35 //GPRS menu
#else
	{"No Function     ",BIT_SUPER_ADMIN},					//35
#endif
    {"No Function     ",BIT_SUPER_ADMIN },	//36 //out facility code
    {"MACSecurty En/Di",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},
	{"Wei Card Data   ",BIT_SUPER_ADMIN | BIT_SERVICING_USER_ADMIN | BIT_SERVICING_ADMIN | BIT_ADMIN | BIT_USER_ADMIN | BIT_SEARCH_USER_ADMIN},
  {"Scroll Images   ",BIT_SUPER_ADMIN | BIT_ADMIN | BIT_IP_SET_ADMIN},     			//45
};

//GPRS Diagnosis
#ifdef ENABLE_GSM_GPRS
extern unsigned char ServiceProvider[32],SignalStrength;
#define MAX_DIAGNOSIS_MODES		8
const char GPRS_DIAGNOSIS_TYPE[MAX_DIAGNOSIS_MODES][17]	= {
	"Chk MODEM Conn. ",
	"Display Operator",
	"Signal Strength ",
	"Get GPRS IP Addr",
	"Connect GPRS    ",
	"DisConnect GPRS ",
	"Enable GPRS     ",
	"Disable GPRS    ",
};
#endif

#ifdef SMART_CARD
const char SERIAL_RDR_ENADIS[5][17] = {            
 	"DisableINOUT RDR",
    "IN Reader       ",
 	"OUT Reader      ",
 	"IN & OUT Reader ",
   };
#endif

// #define GET_CARD_FROM_KEYPAD() {     						\
// 	if(Doorinfo.CardDigit == 8)								\
// 	{														\
// 		if(CardPositionCount == 1)							\
// 		{													\
// 			if(NumericValue > 255)							\
// 			{												\
// 				NumericValue = 0;							\
// 				NumericKeyCount = 0;						\
// 			}												\
// 			DisplayCardNo = NumericValue * 0x10000;			\
// 			if(NumericKeyCount == 3)						\
// 			{												\
// 				NumericKeyCount = 0;						\
// 				CardPositionCount = 0;						\
// 				NumericValue = 0;							\
// 				PositionCursorOnRowNo(15,ROW_USER_ENTRY);	\
// 			}												\
// 		}													\
// 		else												\
// 		{													\
// 			if(NumericValue > 65535)						\
// 			{												\
// 				NumericValue = 0;							\
// 				NumericKeyCount = 0;						\
// 				CardPositionCount = 1;						\
// 				DisplayCardNo = 0;							\
// 				PositionCursorOnRowNo(9,ROW_USER_ENTRY);	\
// 			}												\
// 			if(NumericKeyCount == 6)						\
// 			{												\
// 				NumericKeyCount = 0;						\
// 				CardPositionCount = 1;						\
// 				NumericValue = 0;							\
// 				PositionCursorOnRowNo(9,ROW_USER_ENTRY);	\
// 			}												\
// 			DisplayCardNo = (DisplayCardNo | 0x0000FFFFL) & (NumericValue | 0xFFFF0000L);	\
// 		}													\
// 	}														\
// 	else													\
// 	{														\
// 		DisplayCardNo = NumericValue;						\
// 	}														\
// 	L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);	\
// 	if(Doorinfo.CardDigit == 8)								\
// 	{														\
// 		if(CardPositionCount == 1)							\
// 			PositionCursorOnRowNo(9,ROW_USER_ENTRY);		\
// 		else												\
// 			PositionCursorOnRowNo(15,ROW_USER_ENTRY);		\
// 	}														\
// }

// this funtion display card no at Differnet X pos
// if X pos is 0 it dispaly card at Ceter of row 
// else display at x position of that row 
void CARD_FROM_KEYPAD_Xpos(unsigned char row,unsigned char Xpos) 
{     					
	if(Doorinfo.CardDigit == 8)								
	{														
		if(CardPositionCount == 1)							
		{													
			if(NumericValue > 255)							
			{												
				NumericValue = 0;							
				NumericKeyCount = 0;						
			}												
			DisplayCardNo = NumericValue * 0x10000;			
			if(NumericKeyCount == 3)						
			{												
				NumericKeyCount = 0;						
				CardPositionCount = 0;						
				NumericValue = 0;							
//				PositionCursorOnRowNo(15,ROW_USER_ENTRY);	
			}												
		}													
		else												
		{													
			if(NumericValue > 65535)						
			{												
				NumericValue = 0;							
				NumericKeyCount = 0;						
				CardPositionCount = 1;						
				DisplayCardNo = 0;							
//				PositionCursorOnRowNo(9,ROW_USER_ENTRY);	
			}												
			if(NumericKeyCount == 6)						
			{												
				NumericKeyCount = 0;						
				CardPositionCount = 1;						
				NumericValue = 0;							
//				PositionCursorOnRowNo(9,ROW_USER_ENTRY);	
			}												
			DisplayCardNo = (DisplayCardNo | 0x0000FFFFL) & (NumericValue | 0xFFFF0000L);	
		}													
	}														
	else													
	{														
		DisplayCardNo = NumericValue;						
	}														
	L_DisplayCardNumber(DisplayCardNo,6,row);	
	//	sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
	if(Xpos == 0)
//		L_CenterDisplayROMStrLoc(DisplayTempBuffer,row);
		L_CenterDisplaySubStr(DisplayTempBuffer,row,SUBMENUE_NUMBER_FONTINFO_PTR);
	else
		L_DisplayROMStrLoc(DisplayTempBuffer,16,row,Xpos);	
	
	
	if(Doorinfo.CardDigit == 8)								
	{														
		if(CardPositionCount == 1)							
			PositionCursorOnRowNo(9,ROW_USER_ENTRY);		
		else												
			PositionCursorOnRowNo(15,ROW_USER_ENTRY);		
	}														
}

void DISPLAY_CARD_FROM_KEYPAD(unsigned short x, unsigned short y, unsigned short color, const FONT_INFO *fontInfo,unsigned short bkColor)
{     						
	
	if(Doorinfo.CardDigit == 8)								
	{														
		if(CardPositionCount == 1)							
		{													
			if(NumericValue > 255)							
			{												
				NumericValue = 0;							
				NumericKeyCount = 0;						
			}												
			DisplayCardNo = NumericValue * 0x10000;			
			if(NumericKeyCount == 3)						
			{												
				NumericKeyCount = 0;						
				CardPositionCount = 0;						
				NumericValue = 0;							
//				PositionCursorOnRowNo(15,row);	
			}												
		}													
		else												
		{													
			if(NumericValue > 65535)						
			{												
				NumericValue = 0;							
				NumericKeyCount = 0;						
				CardPositionCount = 1;						
				DisplayCardNo = 0;							
//				PositionCursorOnRowNo(9,row);	
			}												
			if(NumericKeyCount == 6)						
			{												
				NumericKeyCount = 0;						
				CardPositionCount = 1;						
				NumericValue = 0;							
//				PositionCursorOnRowNo(9,row);	
			}												
			DisplayCardNo = (DisplayCardNo | 0x0000FFFFL) & (NumericValue | 0xFFFF0000L);	
		}													
	}														
	else													
	{														
		DisplayCardNo = NumericValue;						
	}														
	L_DisplayCardNumber(DisplayCardNo,6,3);	
// 	sprintf((char*)DisplayTempBuffer,"UID: %010u",DisplayCardNo);
 	L_NewDisplayROMStrLoc(x,y,color,fontInfo,DisplayTempBuffer,bkColor);	
	if(Doorinfo.CardDigit == 8)								
	{														
// 		if(CardPositionCount == 1)							
// 			PositionCursorOnRowNo(9,row);		
// 		else												
// 			PositionCursorOnRowNo(15,row);		
	}														
}

// fn will not display keypad value on TFT , it will store keypad value into DisplayCardNo, 
// after fn return we can use DisplayCardNo to Display at any Position we want in GUI 
void CARD_FROM_KEYPAD()   
{     						
	if(Doorinfo.CardDigit == 8)								
	{														
		if(CardPositionCount == 1)							
		{													
			if(NumericValue > 255)							
			{												
				NumericValue = 0;							
				NumericKeyCount = 0;						
			}												
			DisplayCardNo = NumericValue * 0x10000;			
			if(NumericKeyCount == 3)						
			{												
				NumericKeyCount = 0;						
				CardPositionCount = 0;						
				NumericValue = 0;							
//				PositionCursorOnRowNo(15,row);	
			}												
		}													
		else												
		{													
			if(NumericValue > 65535)						
			{												
				NumericValue = 0;							
				NumericKeyCount = 0;						
				CardPositionCount = 1;						
				DisplayCardNo = 0;							
//				PositionCursorOnRowNo(9,row);	
			}												
			if(NumericKeyCount == 6)						
			{												
				NumericKeyCount = 0;						
				CardPositionCount = 1;						
				NumericValue = 0;							
//				PositionCursorOnRowNo(9,row);	
			}												
			DisplayCardNo = (DisplayCardNo | 0x0000FFFFL) & (NumericValue | 0xFFFF0000L);	
		}													
	}														
	else													
	{														
		DisplayCardNo = NumericValue;						
	}														
	L_DisplayCardNumber(DisplayCardNo,6,3);	
//	sprintf((char*)DisplayTempBuffer,"UID: %010u",DisplayCardNo);
//	L_NewDisplayROMStrLoc(x,y,color,fontInfo,DisplayTempBuffer,bkColor);	
	if(Doorinfo.CardDigit == 8)								
	{														
// 		if(CardPositionCount == 1)							
// 			PositionCursorOnRowNo(9,row);		
// 		else												
// 			PositionCursorOnRowNo(15,row);		
	}														
}
										
/*---------------------------------------------------------------------------------------*/
struct stUserIntf UserIntfData={0,0,0,0};
void NewHandleAllModeEvents(BYTE key);

void NewHandleKeyEvent(BYTE key)   //only call when keypad event is detected
{
#ifdef BIO_METRIC
	if(F_BIO_COMM == SET)	 //ARMD0440
	{
		CancelBioCommand();
		F_BIO_COMM = CLR;
	}
#endif
#ifdef ENABLE_LCD_BACKLITE
	BacklitOnTime = 0;				 					//Defect X0048     
	ON_LCD_BACKLIGHT();
#endif
	IdleKeyCounter = 0;
	F_UserMessageDisplay = CLR;
	F_KeyIdleTime = CLR;
	if( F_Password != CLR )//ARMD0291 ,ARMD0292 
		AdminLogOutTimer = 0;
	MakeSound(SOUND_KEY_PRESS);
	
	switch(key)
	{
		case FUNCTION_KEY:
		{
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;                                           
			NewHandleAllModeEvents(FUNCTION_KEY);
		}
		break;
		case ENTER_KEY:
		{
			NewHandleAllModeEvents(ENTER_KEY);
		}
		break;

		default:
		{
			if(key <= 9) 
			{
				//handle all numeric key here
				NewHandleAllModeEvents(NUMERIC_KEY);	
			}
			else
			{
				//handle all touch key here
				NewHandleAllModeEvents(key);	
			}
		}
		break;
	}
}
void NewHandleAllModeEvents(BYTE key)
{
	switch(ScreenFormatData.CurrentFormat)
	{
		case FORMAT_WELCOME_SCREEN:
		{
			HandleWelcomeMode(key);
		}
		break;
		case FORMAT_EVENT_ICON:
		{
			HandleEventIconMode(key);
		}
		break;
		case FORMAT_GRID_SCREEN:
		{
			HandleGridView(key);
		}
		break;
		case FORMAT_SCROLL_SCREEN:
		{
			UserInt1[UserIntfData.NewModeIndex].EvFunction(key);
		}
		break;
		case FORMAT_SUBMENU_SCREEN:
		{
			if(key == TOUCH_KEY1 || key == FUNCTION_KEY )  	//menu/home key
			{
				//go to welcome screen
				DisplayData.GridCurrentSelection=0;
				DisplayData.GridPreviousSelection=0;

				//display format 2
				DisplayFormat(FORMAT_WELCOME_SCREEN);
                DisplayMode = MODE_WAIT_FOR_CARD;
				//not req to clear grid icon
				//change string of touch keys
			}
			else if(key == TOUCH_KEY5)
			{
				GotoPreviousMenu(UserIntfData.NewModeIndex,FUNCTION_KEY);
				return;
			}
			else if(key == TOUCH_KEY3)
			{
				UserInt1[UserIntfData.NewModeIndex].EvFunction(ENTER_KEY);   //to hadle touch key3 as enter key
			}
			else
			{
				UserInt1[UserIntfData.NewModeIndex].EvFunction(key);
			}
		}
		break;
// 		case DISP_MODE_SUB_MENU:
// 		{
// 		}
// 		break;
	}
}
void HandleKeyEvent(BYTE key)
{
 	if(!(key & 0x80))
	{
#ifdef BIO_METRIC
	   	if(F_BIO_COMM == SET)	 //ARMD0440
		{
			CancelBioCommand();
			F_BIO_COMM = CLR;
		}
#endif
#ifdef ENABLE_LCD_BACKLITE
		BacklitOnTime = 0;				 					//Defect X0048     
  	    ON_LCD_BACKLIGHT();
#endif
		IdleKeyCounter = 0;
		F_UserMessageDisplay = CLR;
		F_KeyIdleTime = CLR;
//		if( F_Password == SET || F_Password == PASS_ADMIN_LOGIN || F_Password == PASS_IPSET_LOGIN )//ARMD0291 ,ARMD0292 
		if( F_Password != CLR)//ARMD0291 ,ARMD0292 
			AdminLogOutTimer = 0;
		MakeSound(SOUND_KEY_PRESS);
//		switch(key & 0x0f)
		switch(key)
		{
			case FUNCTION_KEY:
				CurrentKey = FUNCTION_KEY;
	      		NextFuncKey = 0;
//				DisplayMode = FUNCTION_READ_MODE;
//				IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;                                           
				//HandleAllModeEvents(FUNCTION_KEY);
				NewHandleAllModeEvents(FUNCTION_KEY);
				break;

			case ENTER_KEY:
//				CurrentKey = ENTER_KEY;
	      		NextFuncKey = 0;
				HandleAllModeEvents(ENTER_KEY);
				//NewHandleAllModeEvents(ENTER_KEY);
				break;

			default:
			{
				if(key <= 9) 
				{
					//handle all numeric key here
					//NewHandleAllModeEvents(NUMERIC_KEY);	
				}
				else
				{
					//handle all touch key here
					NewHandleAllModeEvents(key);	
					break;
				}
			}
				if(key <= 9)//all numeric key
				{
					CurrentKey = key & 0x0f;
#ifdef CARD_NO_10_DIGIT
					if(Doorinfo.CardDigit != 5)
		            {
			            if(NumericValue > 429496729)
			            {
			               if((NumericValue - 429496729) >= 5)
			                  NumericValue = 0;
			            }
			            else
			            {
			               NumericValue = (NumericValue*10) + key;
			               NumericKeyCount = NumericKeyCount + 1;
			               if(NumericKeyCount > 5)
			                  NumericKeyCount = 0;
			            }
			            HandleAllModeEvents(NUMERIC_KEY);
		            }
		            else
		            {
			            if(((long)((long)NumericValue*10) + key) <= 65535)
			            {
			               NumericValue = (NumericValue*10) + key;
			               NumericKeyCount = NumericKeyCount + 1;
			               if(NumericKeyCount > 5)
			                  NumericKeyCount = 0;
			            }
			            else
			            {
			               NumericValue = 0;
			               NumericKeyCount = 0;
			            }
			            HandleAllModeEvents(NUMERIC_KEY);
		            }
#else
#ifdef CARD_NO_8_DIGIT
				if(((long)((long)NumericValue*10)+key) <= 99999999)
#else
				if(((long)((long)NumericValue*10)+key) <= 65535)
#endif
	            {
					NumericValue = (NumericValue*10) + key;
					NumericKeyCount = NumericKeyCount + 1;
					if(NumericKeyCount > 5)
						NumericKeyCount = 0;
	            }
	            else
				{
					NumericValue = 0;
					NumericKeyCount = 0;
				}
				HandleAllModeEvents(NUMERIC_KEY);
#endif
		}
			break;
	   }
	}
	return;
}

/*------------------------------------------------------------------------*/
void GenerateUserTimerEvent(BYTE time,BYTE event)
{
	UserTimeOut = time;
	UserTimeOutEvent = event;
	F_UserTimeOut = SET;
}
void ResetUserTimerEvent(BYTE event)
{
	F_UserTimeOut = CLR;
	UserTimeOut = 0;
}
/*------------------------------------------------------------------------*/
void HandleUserTimeOutEvents(void)
{
	switch(DisplayMode)
	{
		case MODE_ADD_CARD:
#ifdef BIO_METRIC
			HandleAddCardKeyBio(EVENT_TIME_OUT);
#else
			HandleAddCardKey(EVENT_TIME_OUT);
#endif
			break;
		case MODE_LAN_TEST:	//ARMF0502
			HandleLANTest(EVENT_TIME_OUT);
		break;
		case MODE_INTERNET_TEST:	//ARMF0502
			HandleInternetTest(EVENT_TIME_OUT);
		break;
	}
}

/*------------------------------------------------------------------------*/
void HandleAllModeEvents(BYTE eventtype)
{
 	MsgPrint(MSG_WARNING,eventtype,"HandleAllModeEvents:eventtype=");
	switch(eventtype)
	{
		case NUMERIC_KEY:
			break;
		case FUNCTION_KEY:
			NumericValue = 0;
			DisplaySubMode = 0;
	      	NumericKeyCount = 0;
      		CardPositionCount = 1;
			L_BlankDisplay(ROW_USER_FUNCTION);
			L_BlankDisplay(ROW_USER_ENTRY);
			break;
		case ENTER_KEY:
// 			if(CheckAdminFunction() == 0)
// 			{
// // 				L_DisplayWelcomeMessage(" Need ADM Login ",16,ROW_USER_ENTRY,0);
// // 				MakeSound(SOUND_USER_ERROR);
// // 				return;
// 			}
			break;
	}

	MsgPrint(MSG_WARNING,DisplayMode,"HandleAllModeEvents:DisplayMode=");
	if(eventtype != FUNCTION_KEY)
		NewHandleAllModeEvents(eventtype);
	if( (ScreenFormatData.CurrentFormat != FORMAT_WELCOME_SCREEN) && (ScreenFormatData.CurrentFormat != FORMAT_EVENT_ICON) )
	{
		return;
	}
	if(DoNotProcessThisKey == 1)
	{
		DoNotProcessThisKey = 0;
		return;
	}
//	if(DisplayMode == MODE_WAIT_FOR_CARD )
	switch(DisplayMode)
	{
#ifdef BIO_METRIC
		case USER_IDENTIFY_MODE:
			DisplayMode = MODE_WAIT_FOR_CARD;
//			break;
#endif
		case MODE_WAIT_FOR_CARD:
#ifdef BIO_METRIC
      		FingerRechkCount = 0;
			HandleWaitForCardKeyBio(eventtype);
#else
			HandleWaitForCardKey(eventtype);
#endif
			break;
		case FUNCTION_READ_NEXT_MODE:
		case MODE_MULTIPLE_FUNCTION:
			HandleMultipleFunction(eventtype);
			break;
		case MODE_ADMIN_PASSWORD:
			//HandleAdminPassword(eventtype);
			HandleWaitForAdminCardKey(eventtype); //ARMD0273 
			break;
#ifdef BIO_METRIC
	   	case MODE_ADMIN_CARD_FOUND://ARMD0312
			AskAndVerifyPinForAdmin(eventtype);
		break;
#endif
// 		case MODE_ADD_CARD:
// #ifdef BIO_METRIC
// 			HandleAddCardKeyBio(eventtype);
// #else
// 			HandleAddCardKey(eventtype);
// #endif
// 			break;
// #ifndef BIOLITE_LOW_END
// 		case MODE_CHANGE_PIN:
// 			HandleChangePinKey(eventtype);
// 			break;
// 		case MODE_FACILITY_CODE:
// 			HandleFacilityCode(eventtype);
// 			break;
// #endif
// 		case MODE_MENU:
// 			HandleMenu(eventtype);
// 			break;
// 		case MODE_DEL_CARD:
// 			HandleDelCardKey(eventtype);
// 			break;
// 		case MODE_SEARCH_CARD:
// 			HandleSearchCardKey(eventtype);
// 			break;
// 		case MODE_SET_TIME_DATA:
// 			HandleSetTimeData(eventtype);
// 			break;

// 		case MODE_WEI_CARD_DISPLAY:				   //*9997 = 37
// 			HandleWeiCardDataDisplay(eventtype);
// 			break;
// 		
// 		case MODE_SET_SHARED_DOTL:				   //*9998 = 38
// 			HandleSetSharedDOTL(eventtype);
// 			break;
// 			
 #ifdef BIO_METRIC
 		case MODE_ADD_FINGER_TO_ID:
 			HandleAddFingerToId(eventtype);
 			break;
// 		case MODE_SET_IDENTIFY_MODE:
// 			HandleIdentifyMode(eventtype);
// 			break;
// 		case MODE_SET_SECURITY_LEVEL:
// 			HandleSecurityLevelMode(eventtype);
// 			break;
 #endif
// 		case MODE_READER_INOUT:
// 			HandleReaderInOutType(eventtype);
// 			break;
// #ifdef WEIGAND_OUT_READER
// 		case MODE_WEIGAND_TYPE:
// 			HandleWeigandType(eventtype);
// 			break;
// #endif
 		case MODE_CARD_FOUND:
 //#ifdef BIO_METRIC
 			AskAndVerifyPin(eventtype);
 //#else
 	//		HandleCardFound(eventtype);
 //#endif
 			break;
// 		case MODE_MULTI_FUN_DEL_ALL:
// 			HandleDelAllDataKey(eventtype);
// 			break;
// 		case MODE_MULTI_FUN_SLAVE_NO_SET:
// 			HandleMultiFuncSlaveNoSet(eventtype);
// 			break;
// 		case MODE_ADMIN_ADD_DEL:
// 			HandleUserAdminAddDel(eventtype);
// 			break;
// 		case MODE_SET_DOOR_OPEN_TIME:
// 			HandleDoorTimeMode(eventtype);
// 			break;
// //		case MODE_BAUDRATE_SETTING:
// //			HandleBaudrateSetting(eventtype);
// //			break;
// 		case MODE_CONTROLLER_TYPE:
// 			HandleControllerType(eventtype);
// 			break;
// 		case MODE_IP_SETTING:
// 			HandleIpSetting(eventtype);
// 			break;
// #ifdef INSERT_SDCARD				
// 		case SCROLL_IMAGES:
// 			ScrollImageTime = 0;
// 			ScreenFormatData.F_ImageNo = 1;  // select current walpaper -> later modify from variable stored in flash ie controlled by a protocol
// 			ScrollBmpImage(0);
// 			break;
// #endif		
// 		case MODE_CARD_ADD_DATA://ARMD0193
// 			HandleCardData(eventtype);
// 			break;
// 		case MODE_AUTH_SERVER_SETTING:			  //*998
// 			HandleAuthServerIpSetting(eventtype);
// 			break;
// 		case MODE_DISP_SYS_PARA:
// 			HandleUserDispAllPara(eventtype);
// 			break;
// 		case MODE_CARD_DIGIT:
// 			HandleCardDigit(eventtype);
//          	break;
// 		case MODE_CONTROLLER_NO:
//       		HandleControllerNo(eventtype);
//          	break;
// 		case MODE_DISP_USEFUL_PARA:  
// 			HandleUserDispUsefulPara(eventtype);
// 			break;
// #ifdef SMART_CARD
// 		case MODE_SERIAL_RDR_EN_DIS:
// 			HandleSerialReaderEnaDis(eventtype);
// 		break;
// #endif
/*#ifndef BIO_METRIC
		case MODE_READER_CONFIG:			  //ARMD0156
			HandleReaderConfig(eventtype);
			break;
#endif */
// #ifndef BIO_METRIC  //ARMD0318
//          case MODE_BULK_ADD_CARD:		
//            HandleBulkCardAddDelkey(eventtype);
// 	     break;
// #endif
// 		case MODE_SET_FIRE_TAMPER:							 //Defect X0039
// 			HandleSetFireTamper(eventtype);
// 			break;
// 	#ifdef ENABLE_GSM_GPRS
// 		case MODE_GPRS_DIAGNOSIS:
// 		HandleGPRSDiagnosis(eventtype);
// 		break;
// 	#endif
// #ifndef SMART_CARD
// 		case MODE_MACSECURITY_ENDISABLE:
// 			HandleServerMACEnDis(eventtype);
// 		break;
// #endif
// 		case MODE_NETWORK_TEST:		//ARMF0502
// 			HandleNetworkTest(eventtype);
// 			break;
	}
}

/*------------------------------------------------------------------------*/
void HandleWeigandEvent(void)
{
//	MsgPrint(MSG_WARNING,DisplayMode,"Event Weigand Data DisplayMode=");
#ifdef ENABLE_LCD_BACKLITE
		BacklitOnTime = 0;				 					  
  	    ON_LCD_BACKLIGHT();
#endif
	switch(DisplayMode)
	{
		case USER_IDENTIFY_MODE:
		case MODE_WAIT_FOR_CARD:
		case USER_VERIFY_MODE: //ARMD0316
		case USER_VERIFY_BY_HOST_MODE:	// NGD00147
#ifdef BIO_METRIC
			HandleWaitForCardKeyBio(WEIGAND_DATA);
#else
			HandleWaitForCardKey(WEIGAND_DATA);
#endif
			break;
		case MODE_ADD_CARD:
#ifdef BIO_METRIC
//			HandleAddCardKeyBio(WEIGAND_DATA);
				UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
#else
			HandleAddCardKey(WEIGAND_DATA);
#endif
			break;
		case MODE_DEL_CARD:
//			HandleDelCardKey(WEIGAND_DATA);
			UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);				
			break;
		case MODE_CARD_ADD_DATA://ARMD0193
//			HandleCardData(WEIGAND_DATA);
			UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
			break;
		case MODE_SEARCH_CARD:
//			HandleSearchCardKey(WEIGAND_DATA);
			UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
			break;
#ifdef ENABLE_DUAL_AUTH
		case MODE_DUA_SEARCH_CARD:		
			HandleDUASearchCard(WEIGAND_DATA);
		break;		
#endif //#ifdef ENABLE_DUAL_AUTH
#ifdef BIO_METRIC
		case MODE_ADD_FINGER_TO_ID:
			HandleAddFingerToId(WEIGAND_DATA);
			break;
#endif
#ifndef BIOLITE_LOW_END
		case MODE_CHANGE_PIN:
//			HandleChangePinKey(WEIGAND_DATA);
			UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
			break;
		case MODE_FACILITY_CODE:
			HandleFacilityCode(WEIGAND_DATA);
			break;
#endif
		case MODE_ADMIN_ADD:
//			HandleUserAdminAdd(WEIGAND_DATA);
			UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
		break;
		case MODE_ADMIN_DEL:
//			HandleUserAdminDel(WEIGAND_DATA);
			UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
		break;
		case MODE_ADMIN_CHANGE:
			//HandleUserAdminChange(WEIGAND_DATA);
		UserInt1[UserIntfData.NewModeIndex].EvFunction(WEIGAND_DATA);		
		break;
		case MODE_ADMIN_PASSWORD:
      		HandleWaitForAdminCardKey(WEIGAND_DATA);
		break;
	  #ifndef BIO_METRIC  //ARMD0318
	    case MODE_BULK_ADD_CARD:          
         HandleBulkCardAddDelkey(WEIGAND_DATA);
	    break;
	   #endif
		case MODE_WEI_CARD_DISPLAY:				   //*9997 = 37
			HandleWeiCardDataDisplay(WEIGAND_DATA);		  	
		break;

		case MODE_SET_SHARED_DOTL:				   //*9998 = 38
			HandleSetSharedDOTL(WEIGAND_DATA);
		break;
	}
}

/*------------------------------------------------------------------------*/
/*
void LCDDisplayTimeData(RTCTime timedate,BYTE blinkpos,BYTE weekday)
{
   PositionCursorOnRow2(0);
//   RSSET;
	WriteDataToDisplay( (timedate.Time.Hour/10) +'0');
	WriteDataToDisplay( (timedate.Time.Hour%10) +'0');
	WriteDataToDisplay(':');
	WriteDataToDisplay( (timedate.Time.Min/10) +'0');
	WriteDataToDisplay( (timedate.Time.Min%10) +'0');
	WriteDataToDisplay(' ');
	WriteDataToDisplay( (timedate.Date.Day/10) +'0');
	WriteDataToDisplay( (timedate.Date.Day%10) +'0');
	WriteDataToDisplay('/');
	WriteDataToDisplay( (timedate.Date.Month/10) +'0');
	WriteDataToDisplay( (timedate.Date.Month%10) +'0');
	WriteDataToDisplay('/');
	WriteDataToDisplay( (timedate.Date.Year/10) +'0');
	WriteDataToDisplay( (timedate.Date.Year%10) +'0');
	L_DisplayROMStrLoc((BYTE *)&WEEK_DAY[weekday],3,2,14);
 //	PositionCursorOnRow2(blinkpos + (blinkpos/2));
} */

/*------------------------------------------------------------------------*/
//Following functions is used to provide admin access to specific menu
// BYTE CheckAdminFunction(void)
// {
//   	switch(DisplayMode)
// 	{
// 		case MODE_WAIT_FOR_CARD:
// 		case USER_IDENTIFY_MODE:
// 		case FUNCTION_READ_NEXT_MODE:
// 		case MODE_MULTIPLE_FUNCTION:
// 		case MODE_ADMIN_PASSWORD:
// #ifndef BIOLITE_LOW_END
// 		case MODE_CHANGE_PIN:
// #endif
// 		case MODE_CARD_FOUND:
// 		case MODE_ADMIN_CARD_FOUND://ARMD0273 
// 			return(1);
// 		case MODE_ADD_CARD:
// 		case MODE_DEL_CARD:
// 		case MODE_SEARCH_CARD:
// 		case MODE_SET_TIME_DATA:
// 		case MODE_MULTI_FUN_DEL_ALL:
// 		case MODE_MULTI_FUN_SLAVE_NO_SET:
// 		case MODE_ADMIN_ADD:
// 		case MODE_ADMIN_DEL:
// 		case MODE_ADMIN_CHANGE:
// #ifdef BIO_METRIC
// 		case MODE_ADD_FINGER_TO_ID:
// 		case MODE_SET_IDENTIFY_MODE:
// 		case MODE_SET_SECURITY_LEVEL:
// #endif
// 		case MODE_WEIGAND_TYPE:	//ARMD0355
//         case MODE_READER_INOUT:
// 		case MODE_SET_DOOR_OPEN_TIME:
// #ifndef BIOLITE_LOW_END
// 		case MODE_FACILITY_CODE:
// #endif
// 		case MODE_CARD_DIGIT:
// 		case MODE_CONTROLLER_NO:
// //		case MODE_BAUDRATE_SETTING:
// 		case MODE_CARD_ADD_DATA:
// 		case MODE_CONTROLLER_TYPE:
// 	//	case MODE_IP_SETTING:
// 		case MODE_DISP_USEFUL_PARA:
// #ifdef SMART_CARD
// 		case MODE_SERIAL_RDR_EN_DIS:
// #endif
// 		case MODE_MENU:
// 		#ifdef ENABLE_GSM_GPRS
// 		    case MODE_GPRS_DIAGNOSIS:
//         #endif

//         case MODE_DISP_SYS_PARA://ARMD0358
// 		case MODE_WEI_CARD_DISPLAY:
// 		case MODE_SET_SHARED_DOTL:
//         #ifndef BIO_METRIC  
//          case MODE_BULK_ADD_CARD:
// 		#endif 
// 		case MODE_SET_FIRE_TAMPER:
// //		#ifdef ENABLE_GSM_GPRS
// //		  case MODE_GPRS_DIAGNOSIS:
//  //       #endif
// #ifndef SMART_CARD
// 		case MODE_MACSECURITY_ENDISABLE:
// #endif
// 		case MODE_AUTH_SERVER_SETTING:	//*998
// 		case MODE_LAN_TEST:		//ARMF0502
// 		case MODE_INTERNET_TEST:		//ARMF0502
// 		case SCROLL_IMAGES:	
// 		if(DisplayAuthMenu[DisplayMode].MenuAuthType & AdminMenuRight)
// 		{
// 			//if(F_Password == SET)
// 			if(F_Password == PASS_ADMIN_LOGIN)
// 				return(1);
// 			else
// 				return(0);
// 		}
// 		else
// 			return(0);
// 		
// 		case MODE_IP_SETTING:
//       	if(DisplayAuthMenu[DisplayMode].MenuAuthType & AdminMenuRight)
//          {
// 	         if(F_Password & PASS_IPSET_LOGIN)
// 	            return(1);
// 	         else
// 	            return(0);
//          }
// 			else
// 				return(0);
// 	}
// 	return(0);
// }

/*---------------------------------------------------------------------------------------*/
void HandleChangePinKey(BYTE keytype)
{
int cardptr;
//unsigned char disptempbuffer[25];
	switch(keytype)
	{
		case FUNCTION_KEY:
			NumericValue = 0;		
			L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_DisplayCardNumber((CARDNO_DATA_STORAGE_TYPE)NumericValue,6,ROW_USER_ENTRY);
//			sprintf((char*)DisplayTempBuffer,"UID:%010u",NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			if(Doorinfo.CardDigit == 8)
//				PositionCursorOnRowNo(9,ROW_USER_ENTRY);
			CardPositionCount = 1;
         	NumericKeyCount = 0;
			DisplayMode = MODE_CHANGE_PIN;
         	DisplayCardNo = NumericValue;
			break;

		case NUMERIC_KEY:
			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
//				CARD_FROM_KEYPAD();	
				CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
// 				sprintf((char*)disptempbuffer,"UID:%u",DisplayTempBuffer);
// 				L_CenterDisplaySubStr(disptempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);						
			}
			else if(DisplaySubMode == 1)
			{
	      		if(NumericValue > 65535)
	         		NumericValue = 0;
				sprintf((char*)DisplayTempBuffer,"OldPin:%05u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);

// 						L_DisplayROMStr("OldPin:        ",16,ROW_USER_ENTRY);
// 				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			}
			else if(DisplaySubMode == 2)
			{
	      		if(NumericValue>65535)
	         		NumericValue = 0;
				sprintf((char*)DisplayTempBuffer,"NewPin:%05u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						
// 				L_DisplayROMStr("NewPin:        ",16,ROW_USER_ENTRY);
// 				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			}
			break;

		case ENTER_KEY:
			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{  // Search card
//				DisplayCardNo = NumericValue;
				Carddata.CardNo = DisplayCardNo;
				MsgPrint(MSG_WARNING,DisplayCardNo,"search CardData");
				cardptr = SearchDisplayCard(DisplayCardNo,&Carddata);
				if(cardptr != CARD_NOT_FOUND)
				{
					MsgPrint(MSG_WARNING,cardptr,"search CardData ptr=");
					MsgPrint(MSG_WARNING,Carddata.CardNo,"CardNo");
					MsgPrint(MSG_WARNING,Carddata.CardPin,"User Pin");
					NumericValue = 0;
					DisplaySubMode = 1;
					L_CenterDisplaySubStr("Enter Pin",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					sprintf((char*)DisplayTempBuffer,"OldPin:%05u",NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"Card not found ptr=");
					L_CenterDisplaySubStr("Card Not Found",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Card Not Found  ",16,ROW_USER_ENTRY);
					DisplaySubMode = 0;
					NumericValue = 0;
					CardPositionCount = 1;
					NumericKeyCount = 0;
					DisplayCardNo = NumericValue;
					MakeSound(SOUND_USER_ERROR);
					Delayandreturnback();
				}
			}
			else if(DisplaySubMode == 1)
			{	// Check Old Pin
				if(Carddata.CardPin == (WORD)NumericValue)
				{
					DisplaySubMode = 2;
					NumericValue = 0;
					sprintf((char*)DisplayTempBuffer,"NewPin:%05u",NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				else
				{
					MsgPrint(MSG_WARNING,NumericValue,"Pin Match Fail pin=");
					MsgPrint(MSG_WARNING,Carddata.CardPin,"Old Pin =");
					L_CenterDisplaySubStr("Pin Match Fail",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Pin Match Fail",16,ROW_USER_ENTRY);
					DisplaySubMode = 1;
					MakeSound(SOUND_USER_ERROR);
					Delayandreturnback();					
				}
			}
			else if(DisplaySubMode == 2)
			{
				Carddata.CardPin = (WORD)NumericValue;
				cardptr= AddCard(Carddata);
				if(cardptr < 0)
				{
					MsgPrint(MSG_WARNING,cardptr,"Card Add Fail");
					L_CenterDisplaySubStr("Card Add Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);

//					L_DisplayROMStr("Card Add Fail",16,ROW_USER_ENTRY);
					MakeSound(SOUND_USER_ERROR);
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"Pin Changed");
					L_CenterDisplaySubStr("Pin Changed",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Pin Changed",16,ROW_USER_ENTRY);
				}
				Delayandreturnback();
				DisplaySubMode = 0xFF;
			}
			break;

		case WEIGAND_DATA:
			if(DisplaySubMode == 0)
			{
				NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
				L_DisplayCardNumber((CARDNO_DATA_STORAGE_TYPE)NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"UID:%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				CardPositionCount = 1;
				NumericKeyCount = 0;
				DisplayCardNo = NumericValue;
			}
			break;
	}
}
#ifndef BIO_METRIC
/*---------------------------------------------------------------------------------------*/
//need to modify same for bio and non-bio support
void HandleWaitForCardKey(BYTE keytype)	//copied from rabbit code.		
{
unsigned char fccode;
struct RectInfo rectinfo;	
unsigned char disptempbuffer[25];
extern unsigned char DisplayTempBuffer[50];
	
	switch(keytype)
	{
	case WEIGAND_DATA:
// 				DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
// 				DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
// 						ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 						USER_TITLE_FONTINFO_PTR,
// 						320,
// 						(unsigned char*)"User Access",
// 						ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
// 	
// 					rectinfo.FillType = RCTFILL_PLAIN;
// 					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
// 					rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT) ;  // 240 - 35  = 205
// 					rectinfo.Width = 320;   // 320
// 					rectinfo.BorderColor = 0;
// 					DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight);				

	
      MsgPrint(1,ReceivedCardNo,"Process Card..");
      MsgPrint(1,2,"Main:Reader Number=");
      if(ReaderNo != 0)
         fccode = ReaderData[ReaderNo-1].FacCode;
      CurrentUser.FCode = fccode;
      if(GetUserInfoAndProcess(ReceivedCardNo,&CurrentUser,CurrentUser.InputType) != 0)
         break;
      L_BlankDisplay(ROW_USER_FUNCTION);
      if(CHK_NAME_DISPLAY())
         L_DisplayROMStr((unsigned char*)CurrentUser.UserName,16,ROW_USER_FUNCTION);
      else
      {
			L_DisplayCardNumber(ReceivedCardNo,6,ROW_USER_FUNCTION);
			sprintf((char*)disptempbuffer,"UID: %s",DisplayTempBuffer)  ;
			L_DisplayROMStr(disptempbuffer,16,ROW_USER_ENTRY3);

// 		  L_DisplayROMStr("UID :        ",16,ROW_USER_FUNCTION);
//          L_DisplayCardNumber(ReceivedCardNo,6,ROW_USER_FUNCTION);
#ifdef SUPPORT_SEVEN_BYTE_CARD_NO
			if(SysInfo.NameType == DISPLAY_7BYTE_CSN)
         {
            L_BlankDisplay(ROW_USER_FUNCTION);
            L_DisplaySevenByteCardNo(ReaderData[ReaderNo-1].WeigandExData,ReaderData[ReaderNo-1].WeigandData,0,ROW_USER_FUNCTION); //Mandar
         }
#endif
      }
      if((CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD)&&(CurrentUser.SearchCard.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED))
      {
         L_DisplayROMStr("Please Show Card",16,ROW_USER_ENTRY);
          goto GOTO_ZERO_ERROR_CTYPE;
      }
      if((ReaderNo==2) && (CurrentUser.SearchCard.Info.CType != 0) && (Doorinfo.UserRestrict != 1))      //shree 23Jan09     //shree 13Oct
      {
         if(!((CurrentUser.InputType==INPUT_USER_FROM_PIN_CARD_WEIGAND)||(CurrentUser.InputType==INPUT_USER_FROM_PIN_PROX)))
         {
            // INDICATES THAT DOOR 2 IS INDEPENDENENT AND WE DO NOT HAVE TO ASK FOR FINGER OR PIN
            UserAccessGranted(&CurrentUser);
            DisplaySubMode=0;
            break;
         }
      }
      if((CurrentUser.SearchCard.Info.CType == 0) && (Doorinfo.UserRestrict == 1))        //shree 23Jan09         //shree 13Oct
      {
         MsgPrint(MSG_WARNING,EVENT_INVALID_ACCESS,"Invalid Access returncode=");      //shree 19Jan09
         StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,ReaderNo,EVENT_INVALID_ACCESS);  //shree 19Jan09
         MakeSound(SOUND_CARD_NOT_FOUND);
         HandleDisplayErrorMessages(EVENT_INVALID_ACCESS);     //19Jan09
         F_KeyIdleTime = CLR;
         IdleKeyCounter = MAX_KEY_IDLE_TIME-4;
         DisplayMode = MODE_WAIT_FOR_CARD;
         DisplaySubMode=0;
         break;
      }
      if((CurrentUser.SearchCard.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED)&&(CurrentUser.InputType==INPUT_USER_FROM_PIN_PROX))
      {
         L_DisplayROMStr("Please Show Card",16,ROW_USER_ENTRY);
GOTO_ZERO_ERROR_CTYPE:
            F_KeyIdleTime = CLR;
            IdleKeyCounter = MAX_KEY_IDLE_TIME-4;
            DisplayMode = MODE_WAIT_FOR_CARD ;
            DisplaySubMode=0;
            break;
      }
      if((SysInfo.ChkPin !=0)&&(CurrentUser.SearchCard.Info.CType & UTYPE_CHECK_PIN))
      {
         if((CurrentUser.InputType==INPUT_USER_FROM_PIN_CARD_WEIGAND)||(CurrentUser.InputType==INPUT_USER_FROM_PIN_PROX))
         {
            if((ReceivedPin != CurrentUser.SearchCard.CardPin)||(CurrentUser.InputType==INPUT_USER_FROM_PIN_PROX))
            {
               MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
               StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,ReaderNo,EVENT_PIN_VERIFICATION);
               MakeSound(SOUND_CARD_NOT_FOUND);
               HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
               F_KeyIdleTime = CLR;
               IdleKeyCounter = MAX_KEY_IDLE_TIME-4;
               DisplayMode = MODE_WAIT_FOR_CARD ;
               DisplaySubMode=0;
               break;
            }
         }
         else
         {
GO_TO_CHECK_PIN:
            DisplayMode = MODE_CARD_FOUND;
            NumericValue = 0;
            ReceivedPin = 0;
            L_DisplayROMStr("User Pin:           ",16,ROW_USER_ENTRY);
            AskAndVerifyPin(FUNCTION_KEY);
            IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
            F_KeyIdleTime = CLR;
//            L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
            break;
         }
      }
     /* if((SysInfo.ChkPin != 0) && (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))
      {
         goto GO_TO_CHECK_PIN;
      }*/
	  if((SysInfo.ChkPin == 0) && (CurrentUser.SearchCard.Info.CType == UTYPE_CHECK_PIN))
      {
         goto GO_TO_CHECK_PIN;
      }
      UserAccessGranted(&CurrentUser);
      DisplaySubMode=0;
   	break;
   case FUNCTION_KEY:
//      LCDDisplayTimeDataAtRow(Datetime,2,CWeekDay,ROW_DATE_TIME_DISP);
//		PositionCursorOnRowNo (2,ROW_DATE_TIME_DISP);
		//make display normal
		//L_DisplayROMStrLoc("                          ",50,ROW_USER_FUNCTION,0);
		//L_DisplayROMStrLoc("                          ",50,ROW_USER_ENTRY,0);
// 		DisplayFormat(FORMAT_WELCOME_SCREEN);     //menu *0
// 			DrawCenterText(	USER_LINE1_START_Y0,
// 						ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 						USER_TITLE_FONTINFO_PTR,
// 						(unsigned char*)"User Access");
		DisplaySubMode=0;
		break;
	case NUMERIC_KEY:
//			DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
// 			DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
// 						ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 						USER_TITLE_FONTINFO_PTR,
// 						320,
// 						(unsigned char*)"User Access",
// 						ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
		if( DisplaySubMode == 0)
		{
      	if(SysInfo.ContInOut != 0)
         {
	      	if(NumericValue == 0)
   	      {
            	if(SysInfo.ContInOut <= 2)
               {
               	if(SysInfo.InOutToggle == INOUT_TOGGLE)
                  {
	                  if(SysInfo.ContInOut == 1)
	                  {
	                     SysInfo.ContInOut = 2;
	                  }
	                  else
	                  {
	                     SysInfo.ContInOut = 1;
	                  }
                  }
               }
	            else if(SysInfo.ContInOut == 3)
	            {
	            	//this is reader inout type as 3 which is outreader for small time
	               InOutReader = 2;
	               InOutReaderTime = 5;
	               F_DisplayINOutToggle = CLR;
	            }
	            else if(SysInfo.ContInOut == 4)
	            {
	            	if(InOutReader == 1)
	               {
	                  InOutReader = 2;
	               }
	               else
	               {
	                  InOutReader = 1;
	               }
						InOutReaderTime = 20;
						F_DisplayINOutToggle = CLR;
	            }
         	}
         }
	      if((SysInfo.ContInOut != 0) && (SysInfo.ContInOut != 5))//ARMD0356
	      {
	         if(SysInfo.ContInOut <= 2)
	         {
	            if(SysInfo.ContInOut == 2)
					DisplayBottomStatusIcon(0,"   Out Entry    ",0,0);						
	            else
					DisplayBottomStatusIcon(0,"   In Entry    ",0,0);						
	         }
	         else
	         {
	            if(InOutReader == 1)
					DisplayBottomStatusIcon(0,"   In Entry    ",0,0);						
	            else
					DisplayBottomStatusIcon(0,"   Out Entry    ",0,0);						
	         }
			}
         if(NumericValue != 0)
         {
			DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
			DefaultGrid_SubmenueScreen();			 
			DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
						ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
						USER_TITLE_FONTINFO_PTR,
						320,
						(unsigned char*)"User Access",
						ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
			 
     		if( Doorinfo.AllowKeypadCard == 1)
				{
					NumericValue  = NumericValue % 10;
					DisplaySubMode = 1;
					L_NewDisplayROMStrLoc(USER_LINE4_START_X0,
																USER_LINE4_START_Y0,
																USER_NORMAL_LINE_COLOR,
																USER_NORMAL_FONTINFO_PTR,
																"Enter User ID ",
																ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour);       //DA00052
            }
         }
      }
//  		else
//       {
//      		if(Doorinfo.AllowKeypadCard == 1)
//          {
// 				if(DisplaySubMode == 1)
// 					L_DisplayROMStr("Enter User ID      ",16,ROW_USER_FUNCTION);
//          }
//       }
		if(DisplaySubMode == 1)
      {
//				L_DisplayROMStr("UID:            ",16,ROW_USER_ENTRY3);
// 					L_NewDisplayROMStrLoc(USER_LINE4_START_X0,
// 																USER_LINE4_START_Y0,
// 																USER_NORMAL_LINE_COLOR,
// 																USER_NORMAL_FONTINFO_PTR,
// 																"UID: ",
// 																ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour); 
// 				
		  DISPLAY_CARD_FROM_KEYPAD(USER_LINE5_START_X0,  // USER_NORMAL_FONT_WIDTH * 4 because UID: is 4 char 
																USER_LINE5_START_Y0,
																USER_NORMAL_LINE_COLOR,
																USER_NORMAL_FONTINFO_PTR,
																ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour);	
      }
      break;
	case ENTER_KEY:
      if(Doorinfo.AllowKeypadCard == 1)
      {
	      if(DisplaySubMode == 1)
	      {
				DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
				DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							320,
							(unsigned char*)"User Access",
							ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
						rectinfo.FillType = RCTFILL_PLAIN;
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
						rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
						rectinfo.Width = 320;   // 320
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);				

	         CurrentUser.InputType = INPUT_USER_FROM_KEYBOARD;
	         ReceivedCardNo = DisplayCardNo;  // = NumericValue;
	         ReaderNo = 1;
	         CardPositionCount = 1;
	         NumericKeyCount = 0;
	         DisplayCardNo = NumericValue;
             ReaderData[0].F_CardFound = SET;
             ReaderData[0].FacCode = ReaderData[1].FacCode = 0;
	         NumericValue = 0;    //shree card no cleared after processing
			 DisplaySubMode = 0;			 
	         break;
	      }
		}
		break;
	case ACCESS_TYPE_SEL:
	   if(SysInfo.SelAccessType)
	   {
				DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
				DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							320,
							(unsigned char*)"User Access",
							ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
			    AccessType_Timer = 0x00;
	      if((CurrentKey >= 3) && (CurrentKey <= 8))
	      {
	         AccessType = CurrentKey - 2;
	         if(SysInfo.TransType[AccessType-1] == 0)
	         {
	            AccessType = 0;
	            break;
	         }
	         if( GetMessageFromFlash(SysInfo.TransType[AccessType-1],AccessTypeMessage)==0)
	         {
	            L_DisplayROMStr(AccessTypeMessage,16,ROW_USER_FUNCTION);
	            IdleKeyCounter = MAX_KEY_IDLE_TIME - 8;
	         }
	         else
	         {
	            L_DisplayROMStr("ERR::Not Defined" ,16,ROW_USER_FUNCTION);
	            AccessType = 0;
	            IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
	         }
	         F_KeyIdleTime = CLR;
	      }
	   }
   	break;
	}
}
#endif
#ifdef BIO_METRIC
/*** BeginHeader HandleWaitForCardKeyBio */
void HandleWaitForCardKeyBio(unsigned char keytype);
/*** EndHeader */
void HandleWaitForCardKeyBio(unsigned char keytype)//ARMD0332
{
	struct RectInfo rectinfo;	
	unsigned char disptempbuffer[25];
	extern unsigned char DisplayTempBuffer[50];
	switch(keytype)
	{
		case WEIGAND_DATA:
/*
			if((DisplaySubMode !=0)||(DisplaySubMode !=1))
				break;
*/					
			MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,"Weigand Card no =");
			if(GetUserInfoAndProcess(ReceivedCardNo,&CurrentUser,CurrentUser.InputType) != 0)
			{
				F_KeyIdleTime = CLR;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;
				DisplayMode = MODE_WAIT_FOR_CARD;
				DisplaySubMode = 0;
//				AccessTimoutScreen = 1; // variable is for if password is set and Screen is at wellcome mode and card shown then  
#ifdef BIO_METRIC
				if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
				{
			  		DISABLE_BIO_COMM();   	//A00012
					if(F_BIO_COMM == CLR)
						PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 1;		// earlier it was -3
				}
#endif
				break;
			}
			if(!CHK_NAME_DISPLAY())//ARMD0335
			{
				L_BlankDisplay(ROW_USER_FUNCTION);

				{
					if(ReaderNo == 1)
					{
						L_DisplayCardNumber(ReceivedCardNo,6,ROW_USER_FUNCTION);
						sprintf((char*)disptempbuffer,"UID: %s",(unsigned char*)DisplayTempBuffer)  ;
						L_DisplayROMStr(disptempbuffer,16,ROW_USER_ENTRY3);
					}
					//MakeSound(SOUND_KEY_PRESS);										
				}
			}//if(CHK_NAME_DISPLAY())//ARMD0335
			if((CHECK_TWO_DOOR(DspRdrNo) == 0) && (ReaderNo == 2))
			{
				if(!((CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX)))
				{
//INDICATES THAT DOOR 2 IS INDEPENDENENT AND WE DO NOT HAVE TO ASK FOR FINGER OR PIN
					UserAccessGranted(&CurrentUser);//,ReaderNo);
					DisplaySubMode = 0;
					break;
				}
			}
			if((CurrentUser.SearchCard.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED) && (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
			{
				L_DisplayROMStr("Please Show Card",16,ROW_USER_ENTRY);
				goto GOTO_ZERO_ERROR_CTYPE;
			}
			if((CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) && (CurrentUser.SearchCard.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED))
			{
				L_DisplayROMStr("Please Show Card",16,ROW_USER_ENTRY);
				goto GOTO_ZERO_ERROR_CTYPE;
			}
			if((CurrentUser.SearchCard.Info.CType & UTYPE_FINGER_SMARTCARD) && (SysInfo.CardDataSource & CDATA_SOURCE_TEMPLATE))
			{
				if(CHECK_BIO_NOCHK(DspRdrNo))                 //FA00075
				{
				// INDICATES THAT WE DO NOT HAVE TO ASK FOR FINGER
					if((SysInfo.ChkPin != 0) && (CurrentUser.SearchCard.Info.CType & UTYPE_CHECK_PIN))
						goto GOTO_ASK_Verify_Pin;
					else
					{
						UserAccessGranted(&CurrentUser);//,ReaderNo);
						DisplaySubMode = 0;
						break;
					}
				}
				else
				{
	            	if(CurrentUser.InputType == INPUT_USER_FROM_SMART)
					{
						if(CurrentCard.NoOfTemp == 0)
						{
							L_DisplayROMStr("ERR:CType ZT0   ",16,ROW_USER_ENTRY);
							goto GOTO_ZERO_ERROR_CTYPE;
						}
						NextDisplayMode = USER_VERIFY_BY_HOST_MODE;
//indicates we have received card from smartcard and template from smartcard finger verify card type is set
						if(SysInfo.ChkPin != 0)
						{
							if((CurrentUser.SearchCard.Info.CType & UTYPE_CHECK_PIN) != 0)
								goto GOTO_ASK_Finger_Verify_Pin;
							else
								goto GOTO_HOST_VERIFY_Finger;
						}
						else
							goto GOTO_HOST_VERIFY_Finger;
					}
					else	
					{                                 
						if((CurrentUser.InputType == INPUT_USER_FROM_FINGER) || (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))
						{
							if (CurrentUser.InputType == INPUT_USER_FROM_FINGER)
							{
								UserAccessGranted(&CurrentUser);//,ReaderNo);
								DisplaySubMode = 0;
								break;
							}
							else
							{
								DisplayCardNo = NumericValue;
								DisplayMode = USER_VERIFY_MODE;
								BioReaderNo = ReaderNo;
								HandleUserVerifyMode(INITIALISE_EVENT);
								DisplaySubMode = 0;
								break;
							}
						}
						else
						{
							L_DisplayROMStr("ERR:CType NOSC  ",16,ROW_USER_ENTRY);
GOTO_ZERO_ERROR_CTYPE:
							F_KeyIdleTime = CLR;
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
							DisplayMode = MODE_WAIT_FOR_CARD;
							DisplaySubMode = 0;
							break;
						}
					}
				}
			}
			if((SysInfo.ChkPin != 0) && (CurrentUser.SearchCard.Info.CType & UTYPE_CHECK_PIN))
			{
				if((CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
				{
					if((ReceivedPin != CurrentUser.SearchCard.CardPin) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
					{
						MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
						StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,ReaderNo,EVENT_PIN_VERIFICATION);
						MakeSound(SOUND_CARD_NOT_FOUND);
						HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
						goto GOTO_ZERO_ERROR_CTYPE;
					}
					NextDisplayMode = USER_VERIFY_MODE;
					goto GOTO_HandleWaitForCardKey_WeigandCard;
				}
				else
				{
					L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
					if((CurrentUser.InputType == INPUT_USER_FROM_FINGER) ||       		\
						((CurrentUser.SearchCard.Info.CType & UTYPE_CARD_ONLY_VERIFY) && 	\
						((CurrentUser.InputType == INPUT_USER_FROM_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_SMART) || (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))))
					{
						DisplaySubMode = 4;
					}
					else
					{
GOTO_ASK_Finger_Verify_Pin:
						DisplaySubMode = 6;   // Ask for finger verification....
					}
					DisplayMode = MODE_CARD_FOUND;
					NumericValue = 0;
					ReceivedPin = 0;
					L_DisplayROMStr("User Pin:        ",16,ROW_USER_ENTRY);
					AskAndVerifyPin(FUNCTION_KEY);
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
					F_KeyIdleTime = CLR;
					break;
				}
			}
			else //else4
			{	////NGD00169
				if((CurrentUser.InputType == INPUT_USER_FROM_FINGER) || \
					((CurrentUser.SearchCard.Info.CType & UTYPE_CARD_ONLY_VERIFY) && (!(CHECK_ATT_NOCARD(ReaderNo)))  &&\
					((CurrentUser.InputType == INPUT_USER_FROM_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_SMART) ||\
					(CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) ||\
					(CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))))
				{
					if((SysInfo.ChkPin != 0) && (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))
					{
GOTO_ASK_Verify_Pin:
						DisplayMode = MODE_CARD_FOUND;
						NumericValue = 0;
						ReceivedPin = 0;
						L_DisplayROMStr("User Pin:        ",16,ROW_USER_ENTRY);
						AskAndVerifyPin(FUNCTION_KEY);
						IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
						F_KeyIdleTime = CLR;
						DisplaySubMode = 4;
						break;
					}//if((SysInfo.ChkPin != 0) && (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))
				else
                 {//else5
                    if( (Doorinfo.DuelUserAuth == 1))
                    {   
                      if(F_DuelUserAuth == CLR)//ARMD0325
					  {
						UserAccessGranted(&CurrentUser);
						DisplaySubMode = 0;
						break;
					  }// if(F_DuelUserAuth == CLR)
                    }// if( (Doorinfo.DuelUserAuth == 1) 
                     else 
					 {
						 UserAccessGranted(&CurrentUser);
						 DisplaySubMode = 0;
	                   	 break;//ARMD0359
					 }
                  }//else5
      if( (Doorinfo.DuelUserAuth == 1) )
				  if(F_DuelUserAuth == SET)//dont grant access & go out of this fun.
				  	{
						
#ifdef BIO_METRIC
						if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
						{
			  				DISABLE_BIO_COMM();   	
							if(F_BIO_COMM == CLR)
								PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 1;		// earlier it was -3
						}
#endif
				  		break;
					}
				}//if((CurrentUser.InputType == INPUT_USER_FROM_FINGER) 
			}//else4
GOTO_HandleWaitForCardKey_WeigandCard:
			if(NextDisplayMode == USER_VERIFY_BY_HOST_MODE)
			{
GOTO_HOST_VERIFY_Finger:
				BioReaderNo = ReaderNo;
				HandleUserHostVerify(INITIALISE_EVENT);
				NextDisplayMode = 0;
				break;
			}
//			L_DisplayROMStr("Processing Card.",16,ROW_USER_ENTRY1);
			DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
			DisplayMode = USER_VERIFY_MODE;
/*			L_DisplayROMStr("UserID:         ",16,1);
			L_DisplayCardNumber((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,8,1);*/
			BioReaderNo = ReaderNo;
			HandleUserVerifyMode(WEIGAND_DATA);
			break;
		case FUNCTION_KEY:
			//L_DisplayROMStr("Show Card ......",16,ROW_USER_ENTRY);//haresh not required in tft
			//LCDDisplayTimeDataAtRow(Datetime,2,CWeekDay,ROW_DATE_TIME_DISP);
			//L_DisplayROMStr(" ",16,ROW_USER_FUNCTION);// required in tft
			//L_DisplayROMStr(" ",16,ROW_USER_ENTRY);// required in tft
			//PositionCursorOnRowNo(2,ROW_DATE_TIME_DISP);
			//DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
		
// 			DisplayFormat(FORMAT_WELCOME_SCREEN);  //menu *0
// 			DrawCenterText(	USER_LINE1_START_Y0,
// 						ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 						USER_TITLE_FONTINFO_PTR,
// 						(unsigned char*)"User Access");
			DisplaySubMode = 0;
//			AccessType = 0;
			break;
		case NUMERIC_KEY:
			DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
			DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
						ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
						USER_TITLE_FONTINFO_PTR,
						320,
						(unsigned char*)"User Access",
						ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
			if(DisplaySubMode == 0)
			{
				if(SysInfo.ContInOut != 0)
				{
					if(NumericValue == 0)
					{
						if(SysInfo.ContInOut <= 2)
						{
							if(SysInfo.InOutToggle == INOUT_TOGGLE)
							{
								if(SysInfo.ContInOut == 1)
									SysInfo.ContInOut = 2;
								else
									SysInfo.ContInOut = 1;
							}
						}
						else if(SysInfo.ContInOut == 3)
						{
						//this is reader inout type as 3 which is outreader for small time
							InOutReader = 2;
							InOutReaderTime = 5;
							F_DisplayINOutToggle = CLR;
						}
						else if(SysInfo.ContInOut == 4)
						{
							if(InOutReader == 1)
								InOutReader = 2;
							else
								InOutReader = 1;
							InOutReaderTime = 20;
							F_DisplayINOutToggle = CLR;
						}
					}
				}
				if(SysInfo.ContInOut != 0)
				{
					if(SysInfo.ContInOut <= 2)
					{
						if(SysInfo.ContInOut == 2)
							DisplayBottomStatusIcon(0,"   Out Entry    ",0,0);						
						else
							DisplayBottomStatusIcon(0,"   In Entry     ",0,0);						
					}
					else
					{
						if(InOutReader == 1)
							DisplayBottomStatusIcon(0,"   In Entry     ",0,0);						
						else
							DisplayBottomStatusIcon(0,"   Out Entry    ",0,0);						
					}
#ifdef EXTENDED_KEYPAD	 								
					if(LunchODInOut > 0)
						L_DisplayROMStrLoc((BYTE *)&F2_KEY_MODE[LunchODInOut],16,ROW_USER_FUNCTION,0);
#endif	 				   			
				}
				if(NumericValue != 0)
				{
				   //if( Doorinfo.AllowKeypadCard == 1)  //ARMD0324
				    {
						NumericValue  = NumericValue % 10;
						DisplaySubMode = 1;
						
						rectinfo.FillType = RCTFILL_PLAIN;
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
						rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT + DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
						rectinfo.Width = 320;   // 320
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight + DUMMY_ZONE_HEIGHT);
						
						L_NewDisplayROMStrLoc(USER_LINE4_START_X0,
											USER_LINE4_START_Y0,
											USER_NORMAL_LINE_COLOR,
											USER_NORMAL_FONTINFO_PTR,
											"Enter User ID ",
											ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour);       //DA00052
																		
				    }
				}
			}
			if(DisplaySubMode == 1)
			{
				
				DISPLAY_CARD_FROM_KEYPAD(USER_LINE5_START_X0 ,  		// USER_NORMAL_FONT_WIDTH * 4 because UID: is 4 char 
										USER_LINE5_START_Y0,
										USER_NORMAL_LINE_COLOR,
										USER_NORMAL_FONTINFO_PTR,
										ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour);	
			}
			break;

		case ENTER_KEY:
				DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
				DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
				ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
				USER_TITLE_FONTINFO_PTR,
				320,
				(unsigned char*)"User Access",
				ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
				rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
				rectinfo.Width = 320;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);				

			if(DisplaySubMode == 1)
			{
				CurrentUser.InputType =INPUT_USER_FROM_KEYBOARD;
				ReceivedCardNo = DisplayCardNo;// = NumericValue;
				ReaderNo = 1;
				CardPositionCount = 1;
				NumericKeyCount = 0;
				DisplayCardNo = NumericValue;
				ReaderData[0].F_CardFound = SET;
				ReaderData[0].FacCode = ReaderData[1].FacCode = 0;
				NumericValue = 0;    //card no cleared after processing
				break;
			}
			else if(DisplaySubMode == 0)
			{
				if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY)||( SysInfo.IdentifyMode ==BIO_POLL_TYPE_KEY_IDENTIFY))
				{
					NextDisplayMode = 0;
					ENABLE_BIO_COMM();
					ReaderNo = 1;
					if(SysInfo.ContInOut != 0)
					{
						if(SysInfo.ContInOut <= 2)
						{
// 							if(SysInfo.ContInOut == 2)
// 								L_DisplayROMStr("   Out Entry    ",16,ROW_USER_FUNCTION);
// 							else
// 								L_DisplayROMStr("   In Entry     ",16,ROW_USER_FUNCTION);
						}
						else
						{
// 							if(InOutReader == 1)
// 								L_DisplayROMStr("   In Entry     ",16,ROW_USER_FUNCTION);
// 							else
// 								L_DisplayROMStr("   Out Entry    ",16,ROW_USER_FUNCTION);
						}
#ifdef EXTENDED_KEYPAD	 									//defect X00010
						if(LunchODInOut > 0)
							L_DisplayROMStrLoc((BYTE *)&F2_KEY_MODE[LunchODInOut],16,ROW_USER_FUNCTION,0);
#endif	 
					}
					else
						L_DisplayROMStr("User Identify   ",16,ROW_USER_ENTRY2);
					L_DisplayROMStr("Place Finger ...",16,ROW_USER_ENTRY3);
#ifdef SUPPORT_SPEECHIC				
						PlaySoundMsg(PLACE_FINGER);
						waitX10ms(100);	
#endif							
					IdentifyFinger();
					UserBioMode = BIO_GET_USER_ID_BY_SCAN;
					FingerWaitTimeOut = 0;
					DisplayMode = USER_IDENTIFY_MODE;
					DisplaySubMode = 0;
				}
				else
				{
					MsgPrint(1,0,"Identify mode disabled");
				}
			}
			break;
		case ACCESS_TYPE_SEL:
			if(SysInfo.SelAccessType)
			{
				DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
				DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							320,
							(unsigned char*)"User Access",
							ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
			    AccessType_Timer = 0x00;
				if((CurrentKey >= 3) && (CurrentKey <= 8))
				{
					AccessType = CurrentKey - 2;
					if(SysInfo.TransType[AccessType-1] == 0)
					{
						AccessType = 0;
						break;
					}
					if(GetMessageFromFlash(SysInfo.TransType[AccessType-1],AccessTypeMessage)==0)
					{
						L_BlankDisplay(ROW_USER_FUNCTION);
						L_DisplayROMStr(AccessTypeMessage,16,ROW_USER_FUNCTION);
						IdleKeyCounter = MAX_KEY_IDLE_TIME - 8;
					}
					else
					{
						L_DisplayROMStr("ERR::Not Defined  " ,16,ROW_USER_FUNCTION);
						AccessType = 0;
						IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
					}
					F_KeyIdleTime = CLR;
				}
			} 
			break;	

	}
}

/*** BeginHeader AskAndVerifyPin */
void AskAndVerifyPin(BYTE keytype);
/*** EndHeader */
void AskAndVerifyPin(BYTE keytype)
{
unsigned char posstar,count,tempbuff1[6];
	// This function is not in use same will be used in pin read mode	
	switch(keytype)
	{
		case FUNCTION_KEY:
			CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_PIN;
			NumericValue = 0;
			NumericKeyCount = 0;
			PinReaderNo = ReaderNo;
			DisplayMode = MODE_CARD_FOUND;
			sprintf((char*)DisplayTempBuffer,"User Pin:%05d",NumericValue);
			L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY);
			F_authScreenTimerEnable = 1;	// NGD00145
			F_authScreenTimer =11;			
			IdleKeyCounter	= CLR;	
//			L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
			break;
	
		case NUMERIC_KEY:
//			L_BlankDisplay(2);
//			L_DisplayROMStr("UserPin:   ",10,ROW_USER_ENTRY);
			F_authScreenTimerEnable = 1; // NGD00145
			F_authScreenTimer =11;			
			IdleKeyCounter	= CLR;	
			if(NumericValue>65535)
				NumericValue = 0;
//			L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
/*-------------------------------------------*/
// Following code is added to show pin as password in *
			if(NumericValue != 0)
			{
				posstar = 0;
				count = 0;
				for(posstar =NumericKeyCount;posstar >0 ;posstar--)
				{
					tempbuff1[count++] = '*';
				}
					tempbuff1[count++] = '\0';		

				sprintf((char*)DisplayTempBuffer,"UserPin:%5s",tempbuff1);
				L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY);					
// 				while(NumericKeyCount>posstar)
// 				{
// 					L_DisplayCharAtRow(14-posstar,'*',ROW_USER_ENTRY);
// 					posstar++;
// 				}
// 				PositionCursorOnRowNo(14,ROW_USER_ENTRY);
			}
			else
			{
				sprintf((char*)DisplayTempBuffer,"UserPin:%05d",NumericValue);
				L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY);	
			}
/*-------------------------------------------*/
			break;
	
		case ENTER_KEY:
			if ((DisplaySubMode == 4) || (DisplaySubMode == 6))
			{
				if(NumericValue > 65535)
					NumericValue = 0;
				ReceivedPin = (unsigned int)NumericValue;
				ReaderNo = PinReaderNo;
				if((ReceivedPin != CurrentUser.SearchCard.CardPin) || ((ReceivedPin == 0) && (Doorinfo.UserRestrict == 1)))  	
				{
					MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
					StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,PinReaderNo,EVENT_PIN_VERIFICATION);
					MakeSound(SOUND_CARD_NOT_FOUND);
					HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
					F_KeyIdleTime = CLR;
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
					DisplayMode = MODE_WAIT_FOR_CARD;
					DisplaySubMode = 0;
					break;
				}
				if(DisplaySubMode == 4)
				{
					L_DisplayROMStr(" ",16,ROW_USER_ENTRY);
					UserAccessGranted(&CurrentUser);//,PinReaderNo);
				}
				else if(DisplaySubMode == 6)
				{
#ifdef BIO_SMART_TEMPLATE
					if(NextDisplayMode == USER_VERIFY_BY_HOST_MODE)
					{
						BioReaderNo = PinReaderNo;
						HandleUserHostVerify(INITIALISE_EVENT);
						NextDisplayMode = 0;
						break;
					}
#endif
					L_DisplayROMStr("Processing Card...",16,ROW_USER_ENTRY);
					DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
					DisplayMode = USER_VERIFY_MODE;
// 					L_DisplayROMStr("UID:             ",16,ROW_USER_FUNCTION); // for ng not tested after comment
// 					L_DisplayCardNumber((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,6,ROW_USER_FUNCTION);
					BioReaderNo = PinReaderNo;
					HandleUserVerifyMode(WEIGAND_DATA);
					break;
				}
			}
			break;
	}
}
#endif

/*---------------------------------------------------------------------------------------*/
void HandleDelCardKey(BYTE keytype)
{
	int cardptr,err,searchptr;
	DisplayMode = MODE_DEL_CARD	;
	switch(keytype)
	{
		case WEIGAND_DATA:
			NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
			DisplayCardNo = NumericValue;
			L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//			sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			CardPositionCount = 1;
			NumericKeyCount = 0;
		break;

		case FUNCTION_KEY:
				L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				if(Doorinfo.CardDigit == 8)
					CardPositionCount = 1;
				NumericKeyCount = 0;
				DisplayCardNo = NumericValue;
		break;
				
		case NUMERIC_KEY:
				CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
		break;
		
		case ENTER_KEY:
			if(DisplayCardNo == 0)
			{
				L_CenterDisplaySubStr("Card Number Err ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				MakeSound(SOUND_USER_ERROR);
				break;
			}
			NumericValue = 0;
			Carddata.CardNo = DisplayCardNo;
			searchptr = CardSearch(Carddata.CardNo);	
			ReadCardTemplateInfoFromFlash(searchptr,&tExtInfo);		// check whether card template is in SD or saensor 
			cardptr = DelCard(Carddata);


// Del Extra info 
// Del Template and image from SD -> if image present 
						
			if(cardptr  == CARD_NOT_FOUND)
			{
				MsgPrint(MSG_WARNING,cardptr,"Card not found");
//				L_BlankDisplay(ROW_USER_ENTRY);
				L_CenterDisplaySubStr(" User Not Found ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				MakeSound(SOUND_USER_ERROR);
			}
			else
			{
				err = DelCardTemplateInfoFromFlash(searchptr);		// Del extra info from Flash					
				if(err  == 0)	
				{
					L_CenterDisplaySubStr("User Deleted",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);			   //NG003
/*					F_TempCounterStart = SET;
					Temp_Time_Counter = 0;
					while(Temp_Time_Counter < 1);
						F_TempCounterStart = CLR;*/ //NG003
				}
				else
				{
					L_CenterDisplaySubStr("User Del Fail",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);		//NG003
					break;
				}

				if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 1)
				{
#ifdef BIO_METRIC
					ENABLE_BIO_COMM();
					if(DeleteBioUserID(Carddata.CardNo) == 0)
					{
						L_CenterDisplaySubStr("Finger Deleted",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR); 
					}
					else
						L_CenterDisplaySubStr("Finger Del Fail ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
//					memset((BYTE *)&tExtInfo,0x00,CARD_EXTRA_DATA_BYTES);
#endif				
				}
				else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2)
				{
#ifdef BIO_METRIC					
					err = DelTempletSD(searchptr);	// Del template  from SD
					if(err  == 0)	// Sud
						L_CenterDisplaySubStr("SDFinger Deleted",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					else
						L_CenterDisplaySubStr("SDFinger Del Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//					memset((BYTE *)&tExtInfo,0x00,CARD_EXTRA_DATA_BYTES);
#endif 										
				}
				else
				{
					L_CenterDisplaySubStr("User Deleted",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);		//NG003
				}					
			}
			Delayandreturnback();
			break;
	}
}


/*---------------------------------------------------------------------------------------*/
void HandleSearchCardKey(BYTE keytype)
{
int cardptr/*,nooffinger*/;
//char pinfrom;
char temp;	

	switch(keytype)
	{
		case WEIGAND_DATA:
//			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
				NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
				DisplayCardNo = NumericValue;
				CardPositionCount = 1;
				NumericKeyCount = 0;
				DisplayCardNo = NumericValue;
				L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
	//			sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);

				CardPositionCount = 1;
				NumericKeyCount = 0;
			}
			break;
		case FUNCTION_KEY:
				L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			if(Doorinfo.CardDigit == 8)
			CardPositionCount = 1;
			NumericKeyCount = 0;
			DisplayCardNo = NumericValue;
			DisplayMode = MODE_SEARCH_CARD;
	 		DisplaySubMode = 0;
			break;
		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
				CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
			break;
	
		case ENTER_KEY:
			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
				Carddata.CardNo = DisplayCardNo;
				MsgPrint(MSG_WARNING,DisplayCardNo,"search CardData");
				cardptr = SearchDisplayCard(DisplayCardNo,&Carddata);
				if(cardptr != CARD_NOT_FOUND)
				{
		            if((INPUT_USER_FROM_SMART==CurrentUser.InputType) && (SysInfo.CardDataSource & CDATA_SOURCE_PIN) && (DisplayCardNo == CurrentCard.CardNo))
		            {							  			
		               Carddata.CardPin = CurrentCard.Pin;
//		               pinfrom = 'S';
		            }
		            else  
//		               pinfrom = 'L';
//					MsgPrint(MSG_WARNING,cardptr,"search CardData ptr=");
					MsgPrint(MSG_WARNING,Carddata.CardNo,"CardNo");
					MsgPrint(MSG_WARNING,Carddata.CardPin,"Card Pin");
//					L_DisplayCardNumber(Carddata.CardNo,0,ROW_USER_ENTRY);
//	            	L_DisplayCharAtRow(10,pinfrom,ROW_USER_ENTRY);
//					L_DisplayDecimalInteger(Carddata.CardPin,11,ROW_USER_ENTRY);
					L_DisplayCardNumber(Carddata.CardNo,6,ROW_USER_ENTRY);
//					sprintf((char*)DisplayTempBuffer,"UID:%010u",Carddata.CardNo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);

								
					sprintf((char*)DisplayTempBuffer,"Card Pin: %04u",Carddata.CardPin);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);								
					MakeSound(SOUND_KEY_PRESS);
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"Card not found ptr=");
					L_CenterDisplaySubStr("User Search Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
					break;
				}				
				ReadCardTemplateInfoFromFlash(cardptr,&tExtInfo);// NGD00061 // check whether card template is in SD or saensor 
				
#ifdef BIO_METRIC            // Changed for NG Biosmart 
			if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 1)
			{				
				ENABLE_BIO_COMM();
	#ifdef SUPPORT_SUPREMA
				if(CheckBioUserID(DisplayCardNo) == 0)
	#else
				if(CheckBioUserID(DisplayCardNo) != 0)
	#endif	//#ifdef SUPPORT_SUPREMA
				{
					UserFingerNo = (unsigned char)BioCmdSize & 0x0f;
//					nooffinger = UserFingerNo;
//Pankaj New Change for finger add problem
	#ifdef SUPPORT_SUPREMA
					if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
					{
						if(UserFingerNo != 1)
	                  		UserFingerNo = (UserFingerNo&0xFF) / 2;
					}
					else
	#endif	//#ifdef SUPPORT_SUPREMA
						UserFingerNo = UserFingerNo & 0xFF;
						sprintf((char*)DisplayTempBuffer,"Finger Added: %02u",UserFingerNo);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY4,SUBMENUE_CHAR_FONTINFO_PTR);													MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)BioCmdData,"Finger Found");
						MsgPrint(MSG_WARNING,(WORD)BioCmdSize,"Finger Count");					
				}
				else
				{
FingerNotFound:
					L_CenterDisplaySubStr("Finger Not Found",ROW_USER_ENTRY4,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
					break;
				}
			}
			else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2)
			{
				UserFingerNo = 0;
				for(temp=0;temp<=7;temp++)
				{
					UserFingerNo += (tExtInfo.TemplateData>>temp) & 0x01;					
				}	
				if(UserFingerNo == 0)
					goto FingerNotFound;
				else 
				{
					sprintf((char*)DisplayTempBuffer,"SD Finger Added: %02u",UserFingerNo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY4,SUBMENUE_CHAR_FONTINFO_PTR);													MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)BioCmdData,"Finger Found");
				}
					
			}	
			else			
				goto FingerNotFound;	// NGD00141			
			
				MakeSound(SOUND_KEY_PRESS);
				DISABLE_BIO_COMM();
				Delayandreturnback();
				DisplaySubMode = 1;
#endif	//#ifdef BIO_METRIC	
		}
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
void HandleDoorTimeMode(BYTE keytype)
{
BYTE doors;	
	switch(keytype)
	{
		case ENTER_KEY:
			if(DisplaySubMode == 0)
			{
				if((NumericValue <= 98) && (NumericValue != 0))		//to make max DOTL alarm time 99
				{
					DisplaySubMode = 0xFF;
					for(doors=0;doors<MAX_READERS_SUPPORT;doors++)
					{
						ReaderInfo[doors].DOpTime = (unsigned int)NumericValue % 100;
						ReaderInfo[doors].DOTLTime = ReaderInfo[doors].DOpTime + 1;
					}
					#ifdef RDPOLL_INCLUDE
					F_UpdateSlaveInfo = SET;
					#endif
					WriteReaderInfoToFlash();
					L_CenterDisplaySubStr("Door Time Saved",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	
				}
				else
				{
					L_CenterDisplaySubStr("Error Time......",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
					NumericValue = 0;
				}
				Delayandreturnback();
			}
			break;
		case FUNCTION_KEY:
//			if( DisplaySubMode == 0)
//			{
	
				NumericValue = ReaderInfo[0].DOpTime;  
				L_CenterDisplaySubStr("Enter Time:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				sprintf((char*)DisplayTempBuffer,"%03d",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplaySubMode = 0;
//			}
			break;
		case NUMERIC_KEY:
			if( DisplaySubMode == 0)
			{
//				L_CenterDisplaySubStr("DoorTime:       ",16,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR));
				if(NumericValue >= 100)
				{
					NumericValue = 0;
					MakeSound(SOUND_USER_ERROR);
				}
				sprintf((char*)DisplayTempBuffer,"%03d",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			}
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
/*void HandleAdminPassword(BYTE keytype)
{
BYTE tempdata1;
int cardptr;

	switch(keytype)
	{
		case FUNCTION_KEY:
     		NumericKeyCount = 0;
      		L_BlankDisplay(ROW_USER_ENTRY);
			if(F_Password == SET)
			{
				L_DisplayROMStr("Enter to Log Out",16,ROW_USER_ENTRY);
				DisplaySubMode = 2;
			}
			else
			{
				L_DisplayROMStr("UserID:   ",10,ROW_USER_ENTRY);
				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
				DisplaySubMode = 0;
			}
			break;
		case NUMERIC_KEY:
			L_BlankDisplay(ROW_USER_ENTRY);
			if(F_Password == SET)
				DisplaySubMode = 2;
			if(NumericValue > 0xFFFF)
			{
				NumericValue = 0;
			}
			if(DisplaySubMode == 0)
			{
				L_DisplayROMStr("UserID:   ",10,ROW_USER_ENTRY);
				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			}
			else if(DisplaySubMode == 1)
			{
				L_DisplayROMStr("Password: ",10,ROW_USER_ENTRY);
				if(NumericValue != 0)
				{
					cardptr = 0;
					while(NumericKeyCount > cardptr)
					{
						L_DisplayCharAtRow(14-cardptr,'*',ROW_USER_ENTRY);
						cardptr++;
					}
					PositionCursorOnRowNo(14,ROW_USER_ENTRY);
				}
				else
					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			}
			if(DisplaySubMode == 2)
			{
				L_DisplayROMStr("Enter to Log Out",16,ROW_USER_ENTRY);
			}
			break;

		case ENTER_KEY:
			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
				if((NumericValue != 0) && (NumericValue <= 0xFFFF))					// SACSD1
				{
					DisplayCardNo = NumericValue;
					DisplaySubMode = 1;
					NumericValue = 0;
		         	NumericKeyCount = 0;
					L_DisplayROMStr("Password: ",10,ROW_USER_ENTRY);
					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
				}
				else
				{
					L_DisplayROMStr("Invalid User    ",16,ROW_USER_ENTRY);
					MakeSound(SOUND_USER_ERROR);
				}
			}
			else if(DisplaySubMode == 1)
			{
				if(DisplayCardNo == 55555)
				{
					if(NumericValue == 11111)
					{
						L_DisplayROMStr("IP SET Login..  ",16,ROW_USER_ENTRY);
						F_Password = PASS_IPSET_LOGIN;
						AdminLogOutTimer = 0;
						StoreCardInTrDB(DisplayCardNo,0x1,EVENT_ADMIN_LOGIN);
						AdminMenuRight = BIT_IP_SET_ADMIN;
						break;
					}
				}
			if(SysInfo.BlockKeyboard != 1) 
			{	 
				cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
				if(cardptr != CARD_NOT_FOUND)
				{
//					MsgPrint(MSG_WARNING,cardptr,"Admin user found =");
//					MsgPrint(MSG_WARNING,Carddata.CardNo,"User no");
//					MsgPrint(MSG_WARNING,Carddata.CardPin,"User PasswordPin");
//				
					if(AdmCard.AdmData.CardPin == NumericValue)
					{
						L_DisplayROMStr("Admin Login OK  ",16,ROW_USER_ENTRY);
						F_Password = SET;
						AdminLogOutTimer = 0;
						tempdata1 = CurrentUser.InputType;
//         				CurrentUser.InputType = F_Password;
						ReceivedPin = 0;
						StoreCardInTrDBFull(DisplayCardNo,0x1,EVENT_ADMIN_LOGIN,0,0);
						CurrentUser.InputType = tempdata1;
						DisplaySubMode = 0xFF;
						 AdminMenuRight = AdmCard.AdminType;
					}
					else
					{
						L_DisplayROMStr("User/Pass Fail..",16,ROW_USER_ENTRY);
						MakeSound(SOUND_USER_ERROR);
					}
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"user / pass not found ptr=");
					L_DisplayROMStr("User/Pass Fail  ",16,ROW_USER_ENTRY);
					MakeSound(SOUND_USER_ERROR);
				}
			}//if(SysInfo.BlockKeyboard != 1)
				else
				{
					L_DisplayROMStr("Login Disabled  ",16,ROW_USER_ENTRY);
					F_Password = CLR;
				}
			}
			if(DisplaySubMode == 2)
			{
				L_DisplayROMStr("Logged Out      ",16,ROW_USER_ENTRY);
				F_Password = CLR;
				DisplaySubMode = 0;
			}
			break;
	}
}
*/
/*---------------------------------------------------------------------------------------*/
// void HandleSetTimeData(BYTE keytype)
// { 
// BYTE tmpdata;
// struct tm vDate;
// time_t time,time1;
//  
// 	switch(keytype)
// 	{
// 		case FUNCTION_KEY:
// 	        DDateTime.Time.Hour = Datetime.Time.Hour;
// 			DDateTime.Time.Min = Datetime.Time.Min;
// 			DDateTime.Time.Secs = Datetime.Time.Secs;
// 			DDateTime.Date.Day = Datetime.Date.Day;
// 			DDateTime.Date.Month = Datetime.Date.Month;
// 			DDateTime.Date.Year = Datetime.Date.Year;
// 			DWeekDay = CWeekDay;
// 		L_CenterDisplayROMStrLoc("Enter New Time and Date ",ROW_USER_ENTRY);
// 		
// 					sprintf((char*)DisplayTempBuffer,"Set Time :-   %02d:%02d",DDateTime.Time.Hour,
// 																			DDateTime.Time.Min);
// 					L_DisplayROMStrLoc(DisplayTempBuffer,16,ROW_USER_ENTRY2,1);

// 					sprintf((char*)DisplayTempBuffer,"Set Date :-   %02d/%02d/%02d",DDateTime.Date.Day,
// 															DDateTime.Date.Month,
// 															DDateTime.Date.Year	);
// 					L_DisplayROMStrLoc(DisplayTempBuffer,16,ROW_USER_ENTRY4,1);
// 					
// // 					drawStringWithBackground(	SMALL_TIME_START_X0,		//x
// // 								SMALL_TIME_START_Y0,	    //y
// // 								SMALL_TIME_FONT_COLOR,      //color
// // 								SMALL_TIME_FONT_INFO,       //font
// // 								DisplayTempBuffer,
// // 								ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);  //string
// 		
// //			LCDDisplayTimeData(DDateTime,DisplaySubMode,DWeekDay);
// 			DisplaySubMode = 0;
// 			NumericValue = 0;
// 			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY);      
// 			break;

// 		case NUMERIC_KEY:
// 			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY);
// 			switch(DisplaySubMode/2)
// 			{
// 				case POS_TIME_HOUR:
// 					DDateTime.Time.Hour = tmpdata = (WORD)NumericValue & 0x00FF;
// 					if(tmpdata > 23)
// 					{
// 						DDateTime.Time.Hour = 0;
// 						DisplaySubMode = (POS_TIME_HOUR*2);
// 						NumericValue = 0;
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 					break;
// 				case POS_TIME_MIN:
// 					DDateTime.Time.Min = tmpdata = (WORD)NumericValue & 0x00FF;
// 					if(tmpdata > 59)
// 					{
// 						NumericValue = DDateTime.Time.Min = 0;
// 						DisplaySubMode = (POS_TIME_MIN*2) - 1;
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 					break;
// 				case POS_DATE_DAY:
// 					DDateTime.Date.Day = tmpdata = (WORD)NumericValue & 0x00FF;
// 					if(tmpdata > 31)
// 					{
// 						NumericValue = DDateTime.Date.Day = 1;
// 						DisplaySubMode = (POS_DATE_DAY*2) - 1;
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 					break;
// 				case POS_DATE_MONTH:
// 					DDateTime.Date.Month = tmpdata = (WORD)NumericValue & 0x00FF;
// 					if(tmpdata > 12)
// 					{
// 						NumericValue = DDateTime.Date.Month = 1;
// 						DisplaySubMode = (POS_DATE_MONTH*2) - 1;
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 					break;
// 				case POS_DATE_YEAR:
// 					DDateTime.Date.Year = tmpdata = (WORD)NumericValue & 0x00FF;
// 					if(tmpdata > 99)
// 					{
// 						NumericValue = DDateTime.Date.Year = 0;
// 						DisplaySubMode = (POS_DATE_YEAR*2) - 1;
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 					break;
// 				case POS_WEEK_DAY:
// 					tmpdata = CurrentKey & 0x000F;
// 					if((tmpdata >= 0) && (tmpdata < 7))
// 						DWeekDay = tmpdata;
// 					if(tmpdata > 6)  
// 					{
// 						DWeekDay = 0;
// 						DisplaySubMode = (POS_WEEK_DAY*2) - 1;
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 					break;
// 			}
// //			MsgPrint(MSG_WARNING,DisplaySubMode,"prev DisplaySubMode=");
// //			MsgPrint(MSG_WARNING,NumericValue,"prev NumericValue=");
// 			DisplaySubMode ++;
// 			if(DisplaySubMode >= (MAX_POS_TIME_DATE*2)+2)
// 				DisplaySubMode = 0;
// 			if(!(DisplaySubMode % 2))
// 				NumericValue = 0;
// //			MsgPrint(MSG_WARNING,DisplaySubMode,"DisplaySubMode=");
// //			MsgPrint(MSG_WARNING,NumericValue,"NumericValue=");
// 			L_BlankDisplay(ROW_USER_ENTRY);
// //			LCDDisplayTimeData(DDateTime,DisplaySubMode,DWeekDay);
// //			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY); 
// 	
// 				sprintf((char*)DisplayTempBuffer,"Set Time :-   %02d:%02d",DDateTime.Time.Hour,
// 																			DDateTime.Time.Min);
// 					L_DisplayROMStrLoc(DisplayTempBuffer,16,ROW_USER_ENTRY2,1);

// 					sprintf((char*)DisplayTempBuffer,"Set Date :-   %02d/%02d/%02d",DDateTime.Date.Day,
// 															DDateTime.Date.Month,
// 															DDateTime.Date.Year	);
// 					L_DisplayROMStrLoc(DisplayTempBuffer,16,ROW_USER_ENTRY4,1);

// 			break;

// 		case ENTER_KEY:
// 	        vDate.tm_hour = DDateTime.Time.Hour;
// 	        vDate.tm_min = DDateTime.Time.Min;
// 	        vDate.tm_sec = 0;
// 	        vDate.tm_mday = DDateTime.Date.Day;
// 	        vDate.tm_mon = DDateTime.Date.Month;
// 	        vDate.tm_year = YEAR_BASE_VALUE + DDateTime.Date.Year;
//          	vDate.tm_wday = 0;
// 			time = mktime(&vDate);
// 			gmtime_r(&time,&vDate);
// 			time1 = mktime(&vDate);
// 			if(time == time1)				
// 				DWeekDay = vDate.tm_wday;
// 			SetRTCTimeDate(DDateTime,DWeekDay);
// 			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY); 
// 			MsgPrint(MSG_WARNING,0,"Time Date Set");
// 			break;
// 	}
// }

void HandleSetTime(BYTE keytype)
{ 
BYTE tmpdata;
struct tm vDate;
time_t time,time1;
 
	switch(keytype)
	{
		case FUNCTION_KEY:
	        DDateTime.Time.Hour = Datetime.Time.Hour;
			DDateTime.Time.Min = Datetime.Time.Min;
			DDateTime.Time.Secs = Datetime.Time.Secs;
			DDateTime.Date.Day = Datetime.Date.Day;
			DDateTime.Date.Month = Datetime.Date.Month;
			DDateTime.Date.Year = Datetime.Date.Year;
			DWeekDay = CWeekDay;		

			L_CenterDisplaySubStr("Enter Time",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr("HH:MM:SS",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);

			sprintf((char*)DisplayTempBuffer,"%02d:%02d:%02d",DDateTime.Time.Hour,
																			DDateTime.Time.Min,DDateTime.Time.Secs);
			Xpos = (320 - drawGetStringWidth(SUBMENUE_NUMBER_FONTINFO_PTR, (char*)DisplayTempBuffer))/2; // it decides start of Str position
			Xdigts = 2;   // it will heghlight 2 char 
			PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);
		
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);
			StartXpos = Xpos;
		//			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			
			DisplaySubMode = 0;
			NumericValue = 0;
//			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY);      
			break;
						
		case NUMERIC_KEY:
			switch(DisplaySubMode/2)
			{
				case POS_TIME_HOUR:		// 0 &1 
					DDateTime.Time.Hour = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode ++; 	
					if(tmpdata > 23)
					{
						DDateTime.Time.Hour = 0;
//						DisplaySubMode = (POS_TIME_HOUR*2);
						DisplaySubMode = POS_TIME_HOUR;
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == 2)
					{
						Xpos += (SUBMENUE_NUMBER_FONT_WIDTH*3);
					}
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);					
					break;
					
				case POS_TIME_MIN: // 2&3
					DDateTime.Time.Min = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode ++;
					if(tmpdata > 59)
					{
						NumericValue = DDateTime.Time.Min = 0;
						DisplaySubMode = POS_TIME_MIN*2; // 2 
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == 4)
					{
						Xpos += (SUBMENUE_NUMBER_FONT_WIDTH*3);
					}
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);					
					break;
					
				case POS_TIME_SEC: // 4&5
					DDateTime.Time.Secs = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode ++;
					if(tmpdata > 59)
					{
						NumericValue = DDateTime.Time.Secs = 0;
//						DisplaySubMode = (POS_TIME_SEC*2) - 1;
						DisplaySubMode = POS_TIME_SEC*2;
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == 6)
					{
						Xpos =	StartXpos;
						DisplaySubMode = 0;							
					}
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);					
					break;
			}							
			if(!(DisplaySubMode%2)) // if modulus is 0 
			{
				NumericValue = 0;
				PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);
			}										
			sprintf((char*)DisplayTempBuffer,"%02d:%02d:%02d",DDateTime.Time.Hour,
																			DDateTime.Time.Min,DDateTime.Time.Secs);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);
			break;

		case ENTER_KEY:
	        vDate.tm_hour = DDateTime.Time.Hour;
	        vDate.tm_min = DDateTime.Time.Min;
	        vDate.tm_sec = 0;
	        vDate.tm_mday = DDateTime.Date.Day;
	        vDate.tm_mon = DDateTime.Date.Month;
	        vDate.tm_year = YEAR_BASE_VALUE + DDateTime.Date.Year;
         	vDate.tm_wday = 0;
			time = mktime(&vDate);
			gmtime_r(&time,&vDate);
			time1 = mktime(&vDate);
			if(time == time1)				
				DWeekDay = vDate.tm_wday;
			SetRTCTimeDate(DDateTime,CWeekDay);
			L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr("Set Successful",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY); 
			MsgPrint(MSG_WARNING,0,"Time Date Set");
			Delayandreturnback();
						
			break;
	}
}

void HandleSetDate(BYTE keytype)
{ 
BYTE tmpdata;
struct tm vDate;
time_t time,time1;
 
	switch(keytype)
	{
		case FUNCTION_KEY:
			DDateTime.Date.Day = Datetime.Date.Day;
			DDateTime.Date.Month = Datetime.Date.Month;
			DDateTime.Date.Year = Datetime.Date.Year;
			DWeekDay = CWeekDay;
	
			L_CenterDisplaySubStr("Enter Date",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr("DD:MM:YY",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		
			sprintf((char*)DisplayTempBuffer,"%02d/%02d/%02d",DDateTime.Date.Day,
															DDateTime.Date.Month,
															DDateTime.Date.Year	);
			Xpos = (320 - drawGetStringWidth(SUBMENUE_NUMBER_FONTINFO_PTR, (char*)DisplayTempBuffer))/2; // it decides start of Str position
			Xdigts = 2;   // it will heghlight 2 char 
			PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);
		
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);
			StartXpos = Xpos;
		
			DisplaySubMode = 0;
			NumericValue = 0;
			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY);      
			break;

		case NUMERIC_KEY:
			LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY);
			switch(DisplaySubMode/2)
			{
				case POS_DATE_DAY:
					DDateTime.Date.Day = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode++;
					if(tmpdata > 31)
					{
						NumericValue = DDateTime.Date.Day = 1;
						DisplaySubMode = POS_DATE_DAY;
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == 2)
					{
						Xpos += (SUBMENUE_NUMBER_FONT_WIDTH*3);
					}
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
				break;
					
				case POS_DATE_MONTH:
					DDateTime.Date.Month = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode++;
					if(tmpdata > 12)
					{
						NumericValue = DDateTime.Date.Month = 1;
						DisplaySubMode = (POS_DATE_MONTH*2);
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == 4)
					{
						Xpos += (SUBMENUE_NUMBER_FONT_WIDTH*3);
					}
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);															
				break;
					
				case POS_DATE_YEAR:
					DDateTime.Date.Year = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode++;
					if(tmpdata > 99)
					{
						NumericValue = DDateTime.Date.Year = 0;
						DisplaySubMode = (POS_DATE_YEAR*2);
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode >= MAX_POS_DATE)
					{
						Xpos = StartXpos;
						DisplaySubMode = 0;
					}
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
				break;
			}

			if(!(DisplaySubMode % 2))
			{
				NumericValue = 0;
			}				
			sprintf((char*)DisplayTempBuffer,"%02d/%02d/%02d",DDateTime.Date.Day,
															DDateTime.Date.Month,
															DDateTime.Date.Year	);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);
//			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);

			break;

		case ENTER_KEY:
	        vDate.tm_hour = Datetime.Time.Hour;
	        vDate.tm_min = 	Datetime.Time.Min;
	        vDate.tm_sec = Datetime.Time.Secs;
	        vDate.tm_mday = DDateTime.Date.Day;
	        vDate.tm_mon = DDateTime.Date.Month;
	        vDate.tm_year = YEAR_BASE_VALUE + DDateTime.Date.Year;
         	vDate.tm_wday = 0;
			time = mktime(&vDate);
			gmtime_r(&time,&vDate);
			time1 = mktime(&vDate);
			if(time == time1)				
				DWeekDay = vDate.tm_wday;
			SetRTCTimeDate(DDateTime,DWeekDay);
			L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr("Set Successful",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//		LCDDisplayTimeDataAtRow(DDateTime,DisplaySubMode,DWeekDay,ROW_USER_ENTRY); 
			MsgPrint(MSG_WARNING,0,"Time Date Set");
			Delayandreturnback();
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
void HandleMultipleFunction(BYTE keytype)
{
	switch(keytype)
	{
		case FUNCTION_KEY:
			//L_DisplayROMStr("Press Next Func Key",16,ROW_USER_ENTRY);
			break;
		case NUMERIC_KEY:
			break;
		case ENTER_KEY:
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
void HandleMultiFuncSlaveNoSet(BYTE keytype)
{
	switch(keytype)
	{
		case FUNCTION_KEY:
			L_CenterDisplaySubStr("Enter SlaveNo:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			NumericValue = SysInfo.MySlaveNo;
			sprintf((char*)DisplayTempBuffer,"%03d",NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;

		case NUMERIC_KEY:
//			L_BlankDisplay(ROW_USER_ENTRY);
//			L_DisplayROMStr("SlaveNo:        ",16,ROW_USER_ENTRY);
			if((NumericValue >= 1) && (NumericValue <= MAX_SLAVE_NO))
			{
				NumericValue = NumericValue;
			}
			else
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
			}
			sprintf((char*)DisplayTempBuffer,"%03d",NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//			L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			break;

		case ENTER_KEY:
//			L_DisplayROMStr("SlaveNo:        ",16,ROW_USER_ENTRY);
			if((NumericValue >= 1) && (NumericValue <= MAX_SLAVE_NO))
			{
				SysInfo.MySlaveNo = (WORD)NumericValue & 0x00ff;
				WriteSysInfoToFlash();
				L_CenterDisplaySubStr("Slave Updated",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				Delayandreturnback();
			}
// 			else
// 			{
// 				NumericValue = 0;
// 				MakeSound(SOUND_USER_ERROR);
// 				L_DisplayROMStr("SlaveNo:        ",16,ROW_USER_ENTRY);
// 				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
// 			}
			break;
	}
}

/*---------------------------------------------------------------------------------*/
// void HandleUserAdminAddDel(BYTE type)
// {
// int cardptr;
// 	switch(type)
// 	{
// 		case WEIGAND_DATA: //ARMD0273 
// 			if((DisplaySubMode == 1) || (DisplaySubMode == 11))
// 			{
// 				DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
// 				L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
// 				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
// 			}
// 		break;
// 		case ENTER_KEY:
// 			if(DisplaySubMode == 0)
// 			{
// 				if(Doorinfo.CardDigit == 8)
// 					PositionCursorOnRowNo(9,ROW_USER_ENTRY);
// 				CardPositionCount = 1;
// 				NumericKeyCount = 0;
// 				if(NumericValue == 1)
// 				{
// 					// Add / Change user ID
// 					L_DisplayROMStr("Add Admin User: ",16,ROW_USER_FUNCTION);
// 					DisplaySubMode = 1;
// 					NumericValue = 0;
// 					HandleNumericUserAdminAddDel();
// 				}
// 				else if(NumericValue == 3)
// 				{	// Del Admin User ID
// 					L_DisplayROMStr("Del Admin User: ",16,ROW_USER_FUNCTION);
// 					DisplaySubMode = 11;
// 					NumericValue = 0;
// 					HandleNumericUserAdminAddDel();
// 				}
// 			}
// 			else if(DisplaySubMode == 1)
// 			{
// 				// Read Admin and verify in Database if not present add new user
// 				if(NumericValue != 0)
// 				{
// //	         		DisplayCardNo = NumericValue;
// 					L_DisplayROMStr("Searching Admin ",16,ROW_USER_ENTRY);
// 					cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
// 					if(cardptr != CARD_NOT_FOUND)
// 					{
// 						L_DisplayROMStr("Change Admin Pass",16,ROW_USER_FUNCTION);
// 						MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
// 						MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
// 						DisplaySubMode = 2;
// 						NumericValue = 0;
// 						HandleNumericUserAdminAddDel();
// 					}
// 					else
// 					{
// 						// New user addition
// 						DisplaySubMode = 3;
// 						NumericValue = 0;
// 						L_DisplayROMStr("Add Admin User  ",16,ROW_USER_FUNCTION);
// 						HandleNumericUserAdminAddDel();
// 						MsgPrint(MSG_WARNING,DisplayCardNo,"Adding new user ID no=");
// 					}
// 				}
// 				else
// 				{
// 					MakeSound(SOUND_USER_ERROR);
// 				}
// 			}
// 			else if(DisplaySubMode == 2)
// 			{ // Take password and verify in database
// 				L_DisplayROMStr("Password: ",10,ROW_USER_ENTRY);
// 				cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
// 				if(cardptr != CARD_NOT_FOUND)
// 				{
// 					MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
// 					MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
// 					DisplaySubMode = 2;
// 					if(AdmCard.AdmData.CardPin == NumericValue)
// 					{
// 					// Password Match
// 						DisplaySubMode = 3;
// 						NumericValue = 0;
// 						HandleNumericUserAdminAddDel();
// 					}
// 					else
// 					{
// 						MsgPrint(MSG_WARNING,NumericValue,"Password Fail  =");
// 						L_DisplayROMStr("Password Fail   ",16,ROW_USER_ENTRY);
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 				}
// 				else
// 				{
// 					L_DisplayROMStr("Admin ID Fail :(",16,ROW_USER_ENTRY);
// 					MakeSound(SOUND_USER_ERROR);
// 					DisplaySubMode = 1;
// 				}
// 				NumericValue = 0;
// 			}
// 			else if(DisplaySubMode == 3)
// 			{  // Change password
// 				AdmCard.AdmData.CardPin = (WORD)NumericValue;
// 				AdmCard.AdmData.CardNo = DisplayCardNo;
//          		AdmCard.AdmData.Info.CType = 0x0A;    //UID + PIN	   ARMD0262
//       			AdmCard.AdminType = BIT_ADMIN;      //Added admin with Admin rights		ARMD0262

// 				cardptr = AddNewAdminUser(AdmCard);
// 				if(cardptr == -1)
// 				{
// 					L_DisplayROMStr("Admin Add Fail  ",16,ROW_USER_FUNCTION);
// 					L_DisplayROMStr("Memory Full ....",16,ROW_USER_ENTRY);
// 					MakeSound(SOUND_USER_ERROR);
// 					DisplaySubMode = 0;
// 				}
// 				else
// 				{
// 					L_DisplayROMStr("Admin User Added",16,ROW_USER_FUNCTION);
// 					L_DisplayROMStr("          L:    ",16,ROW_USER_ENTRY);
// 					L_DisplayCardNumber(AdmCard.AdmData.CardNo,0,ROW_USER_ENTRY);//ARMD0290 ,  //ARMD0262
// 					L_DisplayDecimalInteger(cardptr,11,ROW_USER_ENTRY);
// 					DisplaySubMode = 1;
// 				}
// 				NumericValue = 0;
// 			}
// 			else if(DisplaySubMode == 11)
// 			{
// 			// Menu to Delet Admin User ID
// //				DisplayCardNo = NumericValue;
// 				L_DisplayROMStr("Searching Admin ",16,ROW_USER_ENTRY);
// 				cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
// 				if(cardptr != CARD_NOT_FOUND)
// 				{
// 					MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
// 					MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
// 					DisplaySubMode = 12;
// 					NumericValue = 0;
// 					HandleNumericUserAdminAddDel();
// 				}
// 				else
// 				{
// 					// New user addition
// 					DisplaySubMode = 11;
// 					NumericValue = 0;
// 					L_DisplayROMStr("Admin Not Found ",16,ROW_USER_ENTRY);
// 					MsgPrint(MSG_WARNING,DisplayCardNo,"Admin user ID Not found no=");
// 				}
// 			}
// 			else if(DisplaySubMode == 12)
// 			{ // Take password and verify in database
// 				L_DisplayROMStr("Password: ",10,ROW_USER_ENTRY);
// 				cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
// 				if(cardptr != CARD_NOT_FOUND)
// 				{
// 					MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
// 					MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
// 					
// 					if(AdmCard.AdmData.CardPin == NumericValue)
// 					{
// 					// Password Match
// 						L_DisplayROMStr("Delete AdminUser",16,ROW_USER_ENTRY);
// 						if(DelNewAdminUser(AdmCard) == CARD_NOT_FOUND)
// 						{
// 							L_DisplayROMStr("Delete Fail ....",16,ROW_USER_ENTRY);
// 							MakeSound(SOUND_USER_ERROR);
// 							DisplaySubMode = 11;
// 						}
// 						else
// 						{
// 							L_DisplayROMStr("AdminUserDeleted",16,ROW_USER_ENTRY);
// 							DisplaySubMode = 11;
// 						}
// 					}
// 					else
// 					{
// 						MsgPrint(MSG_WARNING,NumericValue,"Password Fail=");
// 						L_DisplayROMStr("Password Fail   ",16,ROW_USER_ENTRY);
// 						MakeSound(SOUND_USER_ERROR);
// 					}
// 				}
// 				else
// 				{
// 					L_DisplayROMStr("Delete Fail.....",16,ROW_USER_ENTRY);
// 					MakeSound(SOUND_USER_ERROR);
// 					DisplaySubMode = 11;
// 				}
// 				NumericValue = 0;
// 			}
// 			break;
// 	
// 		case FUNCTION_KEY:
// 			L_DisplayROMStr("1:Add/Ch   3:Del",16,ROW_USER_ENTRY);
// 			PositionCursorOnRowNo(0,ROW_USER_ENTRY);
// 			NumericValue = 1;
// 			DisplaySubMode = 0;
// 			break;
// 		
// 		case NUMERIC_KEY:
// 			HandleNumericUserAdminAddDel();
// 			break;
// 	}
// }
void HandleUserAdminDel(BYTE type)
{
int cardptr;
	switch(type)
	{
		case WEIGAND_DATA: //ARMD0273 
			if(DisplaySubMode == 0) 
			{
				DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				
			}		
		break;	
			
		case ENTER_KEY:
		case TOUCH_KEY3:			
			if(DisplaySubMode == 0)				
			{
				if(NumericValue != 0)
				{
//						L_CenterDisplaySubStr("Searching Admin",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
						if(cardptr != CARD_NOT_FOUND)
						{
							MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
//							MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
							DisplaySubMode = 1;
							NumericValue = 0;
//							HandleNumericUserAdminAddDel();
							L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);							
							sprintf((char*)DisplayTempBuffer,"%05d",NumericValue);					
							L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);  // password  stored in Numeric value 
							
						}
						else
						{
							// New user addition
							DisplaySubMode = 0;
							NumericValue = 0;
							L_CenterDisplaySubStr("Admin Not Found",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							MsgPrint(MSG_WARNING,DisplayCardNo,"Admin user ID Not found no=");
							Delayandreturnback();
						}
				 }
			 }	
			 else if(DisplaySubMode == 1)
				{  //  delete
//						L_DisplayROMStr("Password: ",10,ROW_USER_ENTRY);
						cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
						if(cardptr != CARD_NOT_FOUND)
						{
//  						MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
//							MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");					
							if(AdmCard.AdmData.CardPin == NumericValue)
							{
							// Password Match
//								L_DisplayROMStr("Delete AdminUser",16,ROW_USER_ENTRY);
								if(DelNewAdminUser(AdmCard) == CARD_NOT_FOUND)
								{
									L_CenterDisplaySubStr("Delete Fail...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
									MakeSound(SOUND_USER_ERROR);
									DisplaySubMode = 0;
								}
								else
								{
									L_CenterDisplaySubStr("Admin User Deleted",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
									DisplaySubMode = 0;
								}
							}
							else
							{
								MsgPrint(MSG_WARNING,NumericValue,"Password Fail=");
								L_CenterDisplaySubStr("Password Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
								MakeSound(SOUND_USER_ERROR);
							}
						}
						else
						{
							L_CenterDisplaySubStr("Delete Fail...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							MakeSound(SOUND_USER_ERROR);
//							DisplaySubMode = 0;
						}
						NumericValue = 0;	
						Delayandreturnback();						
				}
				else{}
			break;	
					
		case FUNCTION_KEY:			
				NumericValue = DisplayCardNo =0;
				L_CenterDisplaySubStr("Enter ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				DisplaySubMode = 0;
				DisplayMode = MODE_ADMIN_DEL;
				NumericKeyCount = 0;
			break;	
		
		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(NumericValue > 0xFFFFFFFF)
						NumericValue = 0;
					CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);		   //  ID - store in Card no  
			}
			else
			{
					if(NumericValue > 0xFFFF)
							NumericValue = 0;
						sprintf((char*)DisplayTempBuffer,"%05d",NumericValue);					
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);  // password  stored in Numeric value 
			}
		break;
	}	
}
void HandleUserAdminChange(BYTE type)
{
int cardptr;

	switch(type)
	{
		case WEIGAND_DATA: //ARMD0273 
			if(DisplaySubMode == 0) 
			{
				DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);				
			}		
		break;
			
		case ENTER_KEY:
		case TOUCH_KEY3:			
			if(DisplaySubMode == 0)				
			{
				if(NumericValue != 0)
				{
//	         		DisplayCardNo = NumericValue;
//						L_DisplayROMStr("Searching Admin ",16,ROW_USER_ENTRY);
						cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
						if(cardptr != CARD_NOT_FOUND)
						{
//							L_DisplayROMStr("Change Admin Pass",16,ROW_USER_FUNCTION);
							MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
							MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
//							HandleNumericUserAdminAddDel();
							DisplaySubMode = 1;
							NumericValue = 0;
							L_CenterDisplaySubStr("Old Password:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	//						HandleNumericUserAdminAddDel();
							WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)NumericValue);  
							L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
						}
						else
						{
							  NumericValue = 0;
								L_CenterDisplaySubStr("Admin Not Found",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);									
								Delayandreturnback();
						}														
				  }
				}	
			 else if(DisplaySubMode == 1)	
			 {
//						L_DisplayROMStr("Password: ",10,ROW_USER_ENTRY);
					cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
					if(cardptr != CARD_NOT_FOUND)
					{
						MsgPrint(MSG_WARNING,AdmCard.AdmData.CardNo,"User Found no=");
						MsgPrint(MSG_WARNING,AdmCard.AdmData.CardPin,"Old Password =");
						DisplaySubMode = 2;
						if(AdmCard.AdmData.CardPin == NumericValue)
						{
						// Password Match
							DisplaySubMode = 2;
							NumericValue = 0;
							L_CenterDisplaySubStr("New Password:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)NumericValue);  							
							L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
						}
						else
						{
							NumericValue = 0;
							MsgPrint(MSG_WARNING,NumericValue,"Password Fail  =");
							L_CenterDisplaySubStr("Password Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							MakeSound(SOUND_USER_ERROR);
							Delayandreturnback();

						}
					}	
					
			 }
			 else if(DisplaySubMode == 2)
				{  //  password
						AdmCard.AdmData.CardPin = (WORD)NumericValue;
						AdmCard.AdmData.CardNo = DisplayCardNo;
								AdmCard.AdmData.Info.CType = 0x0A;    //UID + PIN	   ARMD0262
//								AdmCard.AdminType = BIT_ADMIN;      //Added admin with Admin rights		ARMD0262
// Card Type should not change // Sud 
						cardptr = AddNewAdminUser(AdmCard);
						if(cardptr == -1)
						{
							L_CenterDisplaySubStr("Admin Add Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							L_CenterDisplaySubStr("Memory Full ...",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
							MakeSound(SOUND_USER_ERROR);
							DisplaySubMode = 0;
						}
						else
						{
							L_CenterDisplaySubStr("Password Changed",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//							L_DisplayROMStr("          L:    ",16,ROW_USER_ENTRY);
							L_DisplayCardNumber(AdmCard.AdmData.CardNo,6,ROW_USER_ENTRY);
//							sprintf((char*)DisplayTempBuffer,"%010u",AdmCard.AdmData.CardNo);
							L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
//							L_DisplayCardNumber(AdmCard.AdmData.CardNo,0,ROW_USER_ENTRY);//ARMD0290 ,  //ARMD0262
//							L_DisplayDecimalInteger(cardptr,11,ROW_USER_ENTRY);
//							DisplaySubMode = 0;
						}
						NumericValue = 0;
						Delayandreturnback();

				}
				else{}
				break;	
					
		case FUNCTION_KEY:			
				NumericValue =DisplayCardNo = 0;
				L_CenterDisplaySubStr("Enter ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				DisplaySubMode = 0;
				DisplayMode = MODE_ADMIN_CHANGE;
				NumericKeyCount = 0;
			break;	
		
		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(NumericValue > 0xFFFFFFFF)
						NumericValue = 0;
					CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);		   //  ID - store in Card no  
			}
			else
			{
					if(NumericValue > 0xFFFF)
							NumericValue = 0;
						WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)NumericValue);  
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);  // password  stored in Numeric value 
			}
			break;
	}	
}	
void HandleUserAdminAdd(BYTE type)
{
int cardptr;

	switch(type)
	{
		case WEIGAND_DATA: //ARMD0273 
			if(DisplaySubMode == 0) 
			{
				DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				
			}		
			break;
		case ENTER_KEY:
		case TOUCH_KEY3:			
			if(DisplaySubMode == 0)				
			{
				if(NumericValue != 0)
				{
					cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
					if(cardptr != CARD_NOT_FOUND)
					{
						NumericValue = 0;
						L_CenterDisplaySubStr("Admin Exist",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);									
						Delayandreturnback();				
					}
					else
					{
						// New user addition
						DisplaySubMode = 1;
						NumericValue = 0;
						L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//						HandleNumericUserAdminAddDel();
						WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)NumericValue);  
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
//						MsgPrint(MSG_WARNING,DisplayCardNo,"Adding new user ID no=");
					}
				 }
			 }	
			 else if(DisplaySubMode == 1)
				{  //  password
						AdmCard.AdmData.CardPin = (WORD)NumericValue;
						AdmCard.AdmData.CardNo = DisplayCardNo;
								AdmCard.AdmData.Info.CType = 0x0A;    //UID + PIN	   ARMD0262
								AdmCard.AdminType = BIT_ADMIN;      //Added admin with Admin rights		ARMD0262

						cardptr = AddNewAdminUser(AdmCard);
						if(cardptr == -1)
						{
							L_CenterDisplaySubStr("Admin Add Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							L_CenterDisplaySubStr("Memory Full ...",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
							MakeSound(SOUND_USER_ERROR);
							DisplaySubMode = 0;
						}
						else
						{
							L_CenterDisplaySubStr("Admin User Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//							L_DisplayROMStr("          L:    ",16,ROW_USER_ENTRY);
							L_DisplayCardNumber(AdmCard.AdmData.CardNo,6,ROW_USER_ENTRY);
							//sprintf((char*)DisplayTempBuffer,"%010u",AdmCard.AdmData.CardNo);
							L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
//							L_DisplayCardNumber(AdmCard.AdmData.CardNo,0,ROW_USER_ENTRY);//ARMD0290 ,  //ARMD0262
//							L_DisplayDecimalInteger(cardptr,11,ROW_USER_ENTRY);
//							DisplaySubMode = 0;
						}
						Delayandreturnback();						
						NumericValue = 0;
				}
				else{}
			break;	
					
		case FUNCTION_KEY:			
				NumericValue = DisplayCardNo = 0;
				L_CenterDisplaySubStr("Enter ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				DisplaySubMode = 0;
				DisplayMode = MODE_ADMIN_ADD;
				NumericKeyCount = 0;
			break;	
		
		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(NumericValue > 0xFFFFFFFF)
						NumericValue = 0;
					CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);		   //  ID - store in Card no  
			}
			else
				{
					if(NumericValue > 0xFFFF)
							NumericValue = 0;
						WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)NumericValue);  
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);  // password  stored in Numeric value 
				}
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
// void HandleNumericUserAdminAddDel(void)
// {
// 	L_BlankDisplay(ROW_USER_ENTRY);
// //	if(NumericValue > 0xFFFF)
// //		NumericValue = 0;
// 	if(DisplaySubMode == 0)
// 	{
// 		L_DisplayROMStr("Add Admin ID:   ",16,ROW_USER_FUNCTION);
// 		L_DisplayROMStr("1:Add/Ch   3:Del",16,ROW_USER_ENTRY);
// 		if(CurrentKey == 1)
// 		{
// 			PositionCursorOnRowNo(0,ROW_USER_ENTRY);
// 			NumericValue = 1;
// 		}
// 		else if(CurrentKey == 3)
// 		{
// 			PositionCursorOnRowNo(11,ROW_USER_ENTRY);
// 	    	NumericValue = 3;
// 		}
// 		else
// 		{
// 			PositionCursorOnRowNo(0,ROW_USER_ENTRY);
// 			CurrentKey = 1;
// 	    	NumericValue = 1;
// 		}
// 		return;
// 	}
// 	else if(DisplaySubMode == 1)
// 	{
// 		L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
// 	}
// 	else if(DisplaySubMode == 2)
// 	{
// 		L_DisplayROMStr("OldPass:  ",10,ROW_USER_ENTRY);
// 	}
// 	else if(DisplaySubMode == 3)
// 	{
// 		L_DisplayROMStr("NewPass:   ",10,ROW_USER_ENTRY);
// 	}
// 	else if(DisplaySubMode == 11)
// 	{
// 		L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
// 	}
// 	else if(DisplaySubMode == 12)
// 	{
// 		L_DisplayROMStr("Password:  ",10,ROW_USER_ENTRY);
// 	}

// 	if((DisplaySubMode == 1) || (DisplaySubMode == 11))
// 	{
// 		if(NumericValue > 0xFFFFFFFF)
// 			NumericValue = 0;
// //		L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
// 		GET_CARD_FROM_KEYPAD();
// 	}
// 	else
// 	{
// 		if(NumericValue > 0xFFFF)
// 			NumericValue = 0;
// 		L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
// 	}
// }

/*---------------------------------------------------------------------------------------*/
void HandleFacilityCode(BYTE keytype)
{
BYTE FacilityCodeData;
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			L_CenterDisplaySubStr("Facility Code:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			strcpy((char*)DisplayTempBuffer,"EN          DI");
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
			Xdigts = 3;
//			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		
// 			L_DisplayROMStr("Facility Code:  ",16,ROW_USER_FUNCTION);
// 			L_DisplayROMStr(" 1:EN      3:DI ",16,ROW_USER_ENTRY);
			if(Doorinfo.FaclityCode_Chk == 1)
			{
//				PositionCursorOnRowNo(1,ROW_USER_ENTRY);
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				CurrentKey = YES_KEY;
			}
			else
			{
//				PositionCursorOnRowNo(11,ROW_USER_ENTRY);
				Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
				PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				CurrentKey = NO_KEY;
			}
			DrawCenterText(SUBMENUE_LINE3_START_Y0,
											USER_NORMAL_LINE_COLOR,
											SUBMENUE_CHAR_FONTINFO_PTR,
											DisplayTempBuffer);				
		break;
			
		case NUMERIC_KEY:
		case TOUCH_KEY2:
		case TOUCH_KEY4:		
			if(keytype == TOUCH_KEY2)
				CurrentKey = YES_KEY;
			else if(keytype == TOUCH_KEY4)
				CurrentKey = NO_KEY;
			else{}
			if(DisplaySubMode == 0)
			{
				if((CurrentKey) == YES_KEY)
				{
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				else if((CurrentKey) == NO_KEY)
				{
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				else
				{
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					CurrentKey = YES_KEY;
//					NumericValue = NO_KEY;
				}
					strcpy((char*)DisplayTempBuffer,"EN          DI");
					DrawCenterText(SUBMENUE_LINE3_START_Y0,
													USER_NORMAL_LINE_COLOR,
													SUBMENUE_CHAR_FONTINFO_PTR,
													DisplayTempBuffer);			
			}
			else if(DisplaySubMode == 2)
			{
				DisplayCardNo = 0;
//				L_DisplayROMStr("Facility Code:  ",16,ROW_USER_FUNCTION);
//				L_DisplayROMStr("Location:       ",16,ROW_USER_ENTRY);
//				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
//				NumericValue = NumericValue %10;
				if(CurrentKey <= 7)			//(CurrentKey >= 0) && to avoid warning..
				{
						sprintf((char*)DisplayTempBuffer,"Location:%02d",CurrentKey);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
// 					L_DisplayROMStr("Location:      ",16,ROW_USER_ENTRY);
// 					L_DisplayDecimalInteger(CurrentKey,10,ROW_USER_ENTRY);
						DisplayCardNo = CurrentKey;
				}
				else
				{
						NumericValue = 0;
						sprintf((char*)DisplayTempBuffer,"Location:%02d",NumericValue);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Location:      ",16,ROW_USER_ENTRY);
//					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
				}
				MsgPrint(MSG_WARNING,DisplaySubMode,"Numeric Display submode=");
			}
			else if(DisplaySubMode == 3)
			{
				if(NumericValue <= 0xFF)
				{
					sprintf((char*)DisplayTempBuffer,"Facility Code:%02d",DisplayCardNo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Facility Code:",16,ROW_USER_FUNCTION);
//					L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_FUNCTION);
					sprintf((char*)DisplayTempBuffer,"Code:%02d",NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Code:           ",16,ROW_USER_ENTRY);
//					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
				}
				else
				{
					MakeSound(SOUND_USER_ERROR);
					NumericValue = 0;
				}
				MsgPrint(MSG_WARNING,DisplaySubMode,"Numeric Display submode=");
			}
			break;
	
		case ENTER_KEY:
			if(DisplaySubMode == 0)
			{
				if(CurrentKey == YES_KEY)
				{
						Doorinfo.FaclityCode_Chk = 1;
//					L_CenterDisplaySubStr("Enabled",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					DisplaySubMode = 1;
						DisplayCardNo = 0;
						sprintf((char*)DisplayTempBuffer,"Location:%02d",DisplayCardNo);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//						L_DisplayDecimalInteger((WORD)DisplayCardNo,10,ROW_USER_ENTRY);
						DisplaySubMode = 2;
						MsgPrint(MSG_WARNING,DisplaySubMode,"Function Display submode=");
				}
				else if(CurrentKey == NO_KEY)
				{
					Doorinfo.FaclityCode_Chk = 0;
					L_CenterDisplaySubStr("Disabled",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					Delayandreturnback();					
				}
				WriteDoorInfoToFlash();
				DisplayCardNo = 0;
				MsgPrint(MSG_WARNING,DisplaySubMode,"Function Display submode=");
			}
// 			else if(DisplaySubMode == 1)
// 			{
// 				L_DisplayROMStr("Location:       ",16,ROW_USER_ENTRY);
// 				L_DisplayDecimalInteger((WORD)DisplayCardNo,10,ROW_USER_ENTRY);
// 				DisplaySubMode = 2;
// 				DisplayCardNo = 0;
// 				MsgPrint(MSG_WARNING,DisplaySubMode,"Function Display submode=");
// 			}
			else if(DisplaySubMode == 2)
			{
				if(DisplayCardNo <= 7)
				{
					NumericValue = SysInfo.FacilityCodeNo[(WORD)DisplayCardNo];
					FacilityCodeData = (WORD)NumericValue & 0x00ff;
//					sprintf((char*)DisplayTempBuffer,"Facility Code: %02d",DisplayCardNo);
					L_CenterDisplaySubStr("Facility Code:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayROMStr("Facility Code:  ",16,ROW_USER_FUNCTION);
//					L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_FUNCTION);
					sprintf((char*)DisplayTempBuffer,"%02d",FacilityCodeData);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					DisplaySubMode = 3;
				}
				MsgPrint(MSG_WARNING,DisplaySubMode,"Function Display submode=");
			}
			else if(DisplaySubMode == 3)
			{
				if(NumericValue <= 0xFF)
				{
					FacilityCodeData = (WORD)NumericValue & 0x00ff;
					SysInfo.FacilityCodeNo[(WORD)DisplayCardNo] = FacilityCodeData;
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Code Updated",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					MsgPrint(MSG_WARNING,SysInfo.FacilityCodeNo[DisplayCardNo],Facility Code =");
					MsgPrint(MSG_WARNING,DisplaySubMode,"Function Display submode=");
					Delayandreturnback();

				}
				else
				{
					NumericValue = 0;
					MakeSound(SOUND_USER_ERROR);
				}
				DisplaySubMode = 0xFF;
				MsgPrint(MSG_WARNING,DisplaySubMode,"Function Display submode =");
			}
			break;
		case WEIGAND_DATA:
			if(DisplaySubMode == 3)
			{
				NumericValue = CurrentUser.FCode;
//				sprintf((char*)DisplayTempBuffer,"Facility Code:%02d",DisplayCardNo);
//				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_CenterDisplaySubStr("Facility Code:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_DisplayROMStr("Facility Code:  ",16,ROW_USER_FUNCTION);
//				L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_FUNCTION);
				sprintf((char*)DisplayTempBuffer,"%02d",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_DisplayROMStr("Code:           ",16,ROW_USER_ENTRY);
//				L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			}
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
#ifdef INSERT_SDCARD		
void  ScrollBmpImage(unsigned char key)
{
	struct RectInfo rectinfo;
	
	ScreenFormatData.CurrentFormat = FORMAT_SCROLL_MENU;
	
	if(key == FUNCTION_KEY)
	{
		//init and draw rect for time
		ScrollImageTime = 0;
		ScreenFormatData.F_ImageNo = 3;
		
		rectinfo.FillType = RCTFILL_PLAIN;
		rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour;
		rectinfo.Hight = ThemeSelect.SubmenueTitleMSGHeight;  
		rectinfo.Width = ThemeSelect.SubmenueTitleMSGWidth;  
		rectinfo.BorderColor = 0;
		DrawRect(&rectinfo,ThemeSelect.SubmenueTitleMSGStartXO, ThemeSelect.submenueSatusMSGStartYO);
		ScreenFormatData.F_BigTimeVisible=0  ;
		ScreenFormatData.F_SatusBar1Visible=0;
		ScreenFormatData.F_SatusBar2Visible=0;
		//display touch key
		TouchKeyPad.CurrentSelection = 0;
		TouchKeyPad.PreviousSelection = 0;
		TouchKeyPad.IsVisible = 0;
		ScreenFormatData.F_Scrollimage = 1;
	}
	//else
	{
		F_KeyIdleTime = 0;
		SDDisplayBackGround(0,48,320,192,ScreenFormatData.F_ImageNo,IMAGES_GROUP) ;
		ScreenFormatData.F_ImageNo ++ ;
		if(ScreenFormatData.F_ImageNo > 5)
			ScreenFormatData.F_ImageNo = 3;
	}
}
#endif
void HandleIpNumericKey(void)
{
					DisplaySubMode ++;
					if(NumericValue > 255)
					{
						DisplaySubMode = (DisplaySubMode/4)*4;
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					DispIP[DisplaySubMode/4] = (BYTE)(NumericValue&0xFF);
					
					if((DisplaySubMode+1)%4 == 0)
					{
						DisplaySubMode ++;
						NumericValue = 0;
						if(DisplaySubMode >= 16)
						{
							DisplaySubMode = 0;
							Xpos = StartXpos;							
						}
						else
							Xpos = Xpos + 4*SUBMENUE_CHAR_FONT_WIDTH + 3;// 20 + 4*2 = 28
					}
					if(DisplaySubMode >= 16)
					{
						DisplaySubMode = 0;
						NumericValue = 0;
					}
					L_BlankDisplay(ROW_USER_ENTRY);
					IPArrayToStr(DispIP,ipaddstr);
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(BYTE *)ipaddstr);
//					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
}
void HandleIpSetting(BYTE keytype)
{  
//	char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.LOCAL_IP[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;			
			HandleIpNumericKey();
		break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.LOCAL_IP,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
					DisplaySubMode = 0xFF;

			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
	}
}

void HandleSubnetMask(BYTE keytype)
{ 
//char ipaddstr[20];	
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.LOCAL_NETMASK[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);		
// 			L_CenterDisplaySubStr("SubNet Mask:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
// 			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
			
				HandleIpNumericKey();
			break;			
			
		case TOUCH_KEY3: 
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.LOCAL_NETMASK,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
					DisplaySubMode = 0xFF;

			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
	}
}
void HandleGateway(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.LOCAL_GATEWAY[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("Enter GateWay:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);

			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
		
//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;			
			HandleIpNumericKey();
		break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.LOCAL_GATEWAY,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
					DisplaySubMode = 0xFF;

			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
	}
}
void HandleLocalport(BYTE keytype)
{  
//char ipaddstr[20];	
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,SysInfo.ETH_Port);
			L_CenterDisplaySubStr("Enter Port No",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					SysInfo.ETH_Port = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
				WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;
			
	}
}
void HandleUDPServerPort(BYTE keytype)
{  
//char ipaddstr[20];
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,SysInfo.UDP_PushPort);
			L_CenterDisplaySubStr("Enter Port No",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;

		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
					break;
					
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					SysInfo.UDP_PushPort = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
					Delayandreturnback();			
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;
		
	}
}
void HandleServerIP(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.SERVER_IP_ADD[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
 			L_CenterDisplaySubStr("Enter IP:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
		
// 			L_CenterDisplaySubStr("Enter IP:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
// 			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;

		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
			
				HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.SERVER_IP_ADD,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
//					DisplaySubFunction = DI_NETMASK;
					DisplaySubMode = 0xFF;
			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
		
	}
}
void HandlePushServer1IP(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.PUSH_TCP_ServAdd1[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("Enter IP:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
		
// 			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
			
				HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.PUSH_TCP_ServAdd1,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
//					DisplaySubFunction = DI_NETMASK;
					DisplaySubMode = 0xFF;

			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		

	}
}
void HandlePushServer1Port(BYTE keytype)
{  
//char ipaddstr[20];
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,SysInfo.PUSH_TCP_Port1);
			L_CenterDisplaySubStr("Enter Port No:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		break;

		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					SysInfo.PUSH_TCP_Port1 = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;		
	}
}
void HandlePushServer2IP(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.PUSH_TCP_ServAdd2[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("Enter IP:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);

//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
			
				HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.PUSH_TCP_ServAdd2,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
//					DisplaySubFunction = DI_NETMASK;
					DisplaySubMode = 0xFF;

			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;				
	}
}
void HandlePushServer2Port(BYTE keytype)
{  
//char ipaddstr[20];
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,SysInfo.PUSH_TCP_Port2);
			L_CenterDisplaySubStr("Enter Port No:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;

		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					SysInfo.PUSH_TCP_Port2 = (unsigned int)NumericValue;
					DisplaySubMode =0XFF;
					NumericValue = 0;		
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);			
					Delayandreturnback();			
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;		
	}
}
void HandleUDPServerIP(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.UDP_IPAdd[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("Enter IP:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		break;
		
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;			
				HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.UDP_IPAdd,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
//					DisplaySubFunction = DI_NETMASK;
					DisplaySubMode = 0xFF;

			WriteSysInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;						 		
	}
}
void HandleUDPport(BYTE keytype)
{  
//char ipaddstr[20];
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,Doorinfo.UDPServerPort);
			L_CenterDisplaySubStr("Enter Port No:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					DisplaySubFunction = DI_PUSH_IP1;
					Doorinfo.UDPServerPort = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
					WriteDoorInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);			
					Delayandreturnback();			
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;		
	}
}
void HandleHBServerIP(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&Doorinfo.HeartBeatIP[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("Enter IP:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
			
				HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(Doorinfo.HeartBeatIP,ipaddstr,16);
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
				DisplaySubMode = 0xFF;

			WriteDoorInfoToFlash();
			Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;						 				 		
	}
}
void HandleHBServerPort(BYTE keytype)
{  
//char ipaddstr[20];
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,Doorinfo.HBPort);
			L_CenterDisplaySubStr("Enter Port No:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					Doorinfo.HBPort = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
					WriteDoorInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);		
					Delayandreturnback();
#ifndef ENABLE_ETHERNET_OLD
//			SocketTcpPort = SysInfo.ETH_Port;
			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); //ip parameter is only init at reset
//			InitParameters();
#endif
#ifdef ETHERNET
			TCPLowLevelInit();		   //ARMD0076
#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;		
	}
}
void HandleHBTime(BYTE keytype)
{  
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;									
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,Doorinfo.UDPHeartBeat);
			L_CenterDisplaySubStr("Enter HB Time",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					Doorinfo.UDPHeartBeat = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
					WriteDoorInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
					Delayandreturnback();
			
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;		
	}
}

/*---------------------------------------------------------------------------------------*/
#ifdef ENABLE_SERVER_AUTH
void HandleAuthServerIpSetting(BYTE keytype)
{  
//char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
	switch(keytype)
	{
		case FUNCTION_KEY:
			L_DisplayROMStr("EN/DIS ServerCHK ",16,ROW_USER_FUNCTION);
			DisplaySubMode = 0;
			if(SysInfo.ServerAuthType == 1) 
				CurrentKey = YES_KEY;
			else
				CurrentKey = NO_KEY;

			if(CurrentKey == YES_KEY)
			{
				L_DisplayROMStr("1:Yes      3:No ",16,ROW_USER_ENTRY);
				PositionCursorOnRowNo(0,ROW_USER_ENTRY);
			}
			else if(CurrentKey == NO_KEY)
			{
				L_DisplayROMStr("1:Yes      3:No ",16,ROW_USER_ENTRY);
				PositionCursorOnRowNo(11,ROW_USER_ENTRY);
			}
			DisplaySubFunction = DI_AUTH_SERVER_EN_DIS;
			break;
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)		 //ARMD0434
				break;
			switch(DisplaySubFunction)
			{
         		case DI_AUTH_SERVER_EN_DIS:
					if(CurrentKey == YES_KEY)
					{
						L_DisplayROMStr("1:Yes      3:No ",16,ROW_USER_ENTRY);
						PositionCursorOnRowNo(0,ROW_USER_ENTRY);
					}
					else if(CurrentKey == NO_KEY)
					{
						L_DisplayROMStr("1:Yes      3:No ",16,ROW_USER_ENTRY);
						PositionCursorOnRowNo(11,ROW_USER_ENTRY);
					}
					else
					{
						L_DisplayROMStr("1:Yes      3:No ",16,ROW_USER_ENTRY);
						PositionCursorOnRowNo(0,ROW_USER_ENTRY);
						CurrentKey = YES_KEY;
					}
					break;
				case DI_AUTH_SERVER_IP1_PORT:
				case DI_AUTH_SERVER_IP2_PORT:
					L_DisplayROMStr("Port No:        ",16,ROW_USER_ENTRY);
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
					break;

				case DI_AUTH_SERVER_IP1:
        case DI_AUTH_SERVER_IP2:

					DisplaySubMode ++;
					if(NumericValue > 255)
					{
						DisplaySubMode = (DisplaySubMode/4)*4;
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					DispIP[DisplaySubMode/4] = (BYTE)(NumericValue&0xFF);
					if((DisplaySubMode+1)%4 == 0)
					{
						DisplaySubMode ++;
						NumericValue = 0;
					}
					if(DisplaySubMode >= 19)
					{
						DisplaySubMode = 0;
						NumericValue = 0;
					}
					L_BlankDisplay(ROW_USER_ENTRY);
					IPArrayToStr(DispIP,ipaddstr);
					L_DisplayROMStrLoc((BYTE *)ipaddstr,16,ROW_USER_ENTRY,0);
					PositionCursorOnRowNo(DisplaySubMode,ROW_USER_ENTRY);   
					break;
			}
			break;
	
		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)			 //ARMD0434
				break;
			MakeSound(SOUND_USER_ERROR);
			switch(DisplaySubFunction)
			{
				case DI_AUTH_SERVER_EN_DIS:
					if(CurrentKey == YES_KEY)
					{
						L_DisplayROMStr("ServerCHK EN     ",16,ROW_USER_ENTRY);
						SysInfo.ServerAuthType = 1;
					}
					if(CurrentKey == NO_KEY)
					{
						SysInfo.ServerAuthType = 0;
						L_DisplayROMStr("ServerCHK DI     ",16,ROW_USER_ENTRY);
						DisplaySubMode = 0xFF;				//ARMD0434
						goto EXIT_AUTH_SVR_ENTER_KEY;
					}
					DisplaySubFunction = DI_AUTH_SERVER_IP1;
					DisplaySubMode = 0;
					L_DisplayROMStr("AuthSvr1 IPAddr:  ",16,ROW_USER_FUNCTION);
					ipadd = aton((char *)&SysInfo.SB_AUTH_ServAdd1[0]);
					IPStrToArray(DispIP,ipadd);
					IPArrayToStr(DispIP,ipaddstr);
					L_DisplayROMStrLoc((BYTE *)ipaddstr,16,ROW_USER_ENTRY,0);
					PositionCursorOnRowNo(DisplaySubMode,ROW_USER_ENTRY); 
EXIT_AUTH_SVR_ENTER_KEY:
					break;
				case DI_AUTH_SERVER_IP1:
					L_DisplayROMStr("AuthSvr1 IPAddr:  ",16,ROW_USER_FUNCTION);
					L_DisplayROMStrLoc((BYTE *)ipaddstr,16,ROW_USER_ENTRY,0);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.SB_AUTH_ServAdd1,ipaddstr,16);
					DisplaySubFunction = DI_AUTH_SERVER_IP1_PORT;
					DisplaySubMode = 0;
					L_DisplayROMStr("Auth Server1:       ",16,ROW_USER_FUNCTION);
					L_DisplayROMStr("Port No:        ",16,ROW_USER_ENTRY);
					NumericValue = SysInfo.SB_AUTH_Port1;
					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
		        	break;
				case DI_AUTH_SERVER_IP1_PORT:
					if((NumericValue==0)||(NumericValue>=0xFFFF))
		             {
		             	NumericValue = 0;
			            MakeSound(SOUND_USER_ERROR);
		               break;
		             }
		          	DisplaySubFunction = DI_AUTH_SERVER_IP2;
		            SysInfo.SB_AUTH_Port1 = (WORD)NumericValue;
		            DisplaySubMode =0;
		            NumericValue = 0;				
		         	L_DisplayROMStr("AuthSvr2 IPAddr:  ",16,ROW_USER_FUNCTION);
					ipadd = aton((char *)&SysInfo.SB_AUTH_ServAdd2[0]);
					IPStrToArray(DispIP,ipadd);
		      		IPArrayToStr(DispIP,ipaddstr);
			   		L_DisplayROMStrLoc((BYTE *)ipaddstr,16,ROW_USER_ENTRY,0);
				    PositionCursorOnRowNo(DisplaySubMode,ROW_USER_ENTRY);
					break;

			case DI_AUTH_SERVER_IP2:
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.SB_AUTH_ServAdd2,ipaddstr,16);
					DisplaySubFunction = DI_AUTH_SERVER_IP2_PORT;
					DisplaySubMode = 0;
					L_DisplayROMStr("Auth Server2:       ",16,ROW_USER_FUNCTION);
					L_DisplayROMStr("Port No:        ",16,ROW_USER_ENTRY);
					NumericValue = SysInfo.SB_AUTH_Port2;
					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
		         break;
				case DI_AUTH_SERVER_IP2_PORT:
					if((NumericValue==0)||(NumericValue>=0xFFFF))
		             {
		             	NumericValue = 0;
			            MakeSound(SOUND_USER_ERROR);
		               break;
		             }
		          	DisplaySubFunction = 0xFF;
		            SysInfo.SB_AUTH_Port2 = (WORD)NumericValue;
					L_DisplayROMStr("All IP Data Saved",16,ROW_USER_FUNCTION);
		         	L_DisplayROMStr("Initialised N/W   ",16,ROW_USER_ENTRY);
		            DisplaySubMode =0;
		            NumericValue = 0;
					break;
			}
			WriteSysInfoToFlash();
//#ifndef ENABLE_ETHERNET_OLD
////			SocketTcpPort = SysInfo.ETH_Port;
//			InitialiseSocket(aton((char*)&SysInfo.LOCAL_IP[0]),aton((char*)&SysInfo.LOCAL_NETMASK[0]),aton((char*)&SysInfo.LOCAL_GATEWAY[0]));
//			InitNetworkParameter(); 
//			InitParameters();
//#endif
//#ifdef ETHERNET
//			TCPLowLevelInit();		   //ARMD0076
//#endif
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
	}
}
#endif //#ifdef ENABLE_SERVER_AUTH
#ifdef ENABLE_SERVER_AUTH
void HandleAuthServerEnDi(BYTE keytype)
{
	switch(keytype)
	{	
		case FUNCTION_KEY:
			L_CenterDisplaySubStr("EN/DIS Server",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			DisplaySubMode = 0;
// 			if(SysInfo.ServerAuthType == 1)   // EN
// 				CurrentKey = 1;
// 			else
// 				CurrentKey = 3;

				strcpy((char*)DisplayTempBuffer,"EN         DIS");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				CurrentKey = YES_KEY;
				PositionCursorOnRowNo(0,ROW_USER_ENTRY);
		break;
		
		case NUMERIC_KEY:
		case 	TOUCH_KEY2:   // left shift   select YES
		case 	TOUCH_KEY4:   // Right shift Select NO
		 if(DisplaySubMode == 0)
		 {		
			if(keytype == TOUCH_KEY2)
				CurrentKey = YES_KEY;
			else if(keytype == TOUCH_KEY4)
				CurrentKey = NO_KEY;
			//			L_BlankDisplay(ROW_USER_ENTRY);
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"EN         DIS");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else if(CurrentKey == NO_KEY)
				{	
					strcpy((char*)DisplayTempBuffer,"EN         DIS");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
			}	
			break;		

		case TOUCH_KEY3:
		case ENTER_KEY:				
					DisplaySubMode =1;
					if(CurrentKey == YES_KEY)
					{
						L_CenterDisplaySubStr("Enabled",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						SysInfo.ServerAuthType = 1;
					}
					if(CurrentKey == NO_KEY)
					{
						SysInfo.ServerAuthType = 0;
						L_CenterDisplaySubStr("Dissabled",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						DisplaySubMode = 0xFF;				
					}
			WriteSysInfoToFlash();
			break;	
	}				
				
}
#endif //#ifdef ENABLE_SERVER_AUTH
#ifdef ENABLE_SERVER_AUTH
void HandleAuthServer1Ip(BYTE keytype)
{  
//	char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
 if(SysInfo.ServerAuthType == 1)	
 { 
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.SB_AUTH_ServAdd1[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
		
//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
					HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.SB_AUTH_ServAdd1,ipaddstr,16);
					DisplaySubMode = 0xFF;
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
			Delayandreturnback();
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
	}
 }
 else
 {
		L_CenterDisplaySubStr("Please Enable",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		L_CenterDisplaySubStr("Server Auth",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	 
 }
}
void HandleAuthServer2Ip(BYTE keytype)
{  
//	char ipaddstr[20];
unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
 if(SysInfo.ServerAuthType == 1)	
 { 	
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			ipadd = aton((char *)&SysInfo.SB_AUTH_ServAdd2[0]);
			IPStrToArray(DispIP,ipadd);
			IPArrayToStr(DispIP,ipaddstr);
			L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)ipaddstr)) / 2;
			Xdigts = 3;
			Xpos = StartXpos;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,(unsigned char*)ipaddstr);
		
//			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:		
			if(DisplaySubMode == 0xFF)
				break;
					HandleIpNumericKey();
			break;			

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			MakeSound(SOUND_USER_ERROR);

//					L_CenterDisplaySubStr("IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					IPArrayToStr(DispIP,ipaddstr);
					memcpy(SysInfo.SB_AUTH_ServAdd2,ipaddstr,16);
					DisplaySubMode = 0xFF;
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);		
					Delayandreturnback();			
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif
			break;			 		
	}
 }
 else
 {
		L_CenterDisplaySubStr("Please Enable",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		L_CenterDisplaySubStr("Server Auth",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	 
 } 
}
void HandleAuthServer1Port(BYTE keytype)
{
//char ipaddstr[20];	
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
 if(SysInfo.ServerAuthType == 1)	
 { 	
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,SysInfo.SB_AUTH_Port1);
			L_CenterDisplaySubStr("Enter Port No",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
			SysInfo.SB_AUTH_Port1 = (unsigned int)NumericValue;
			DisplaySubMode =0xFF;
			NumericValue = 0;		
			WriteSysInfoToFlash();
			L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
			L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);			
			Delayandreturnback();
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;		
	}
 }
 else
 {
		L_CenterDisplaySubStr("Please Enable",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		L_CenterDisplaySubStr("Server Auth",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	 
 } 
}
void HandleAuthServer2Port(BYTE keytype)
{
//char ipaddstr[20];	
//unsigned long ipadd;
//DWORD ipaddress;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_IPSETTING;
	WDTInit(10);			//watchdog initialization for secs
#endif
 if(SysInfo.ServerAuthType == 1)	
 { 	
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			DisplaySubFunction = 0;
			WORDHextoDeciamal((char*)ipaddstr,SysInfo.SB_AUTH_Port2);
			L_CenterDisplaySubStr("Enter Port No",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr((BYTE *)ipaddstr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		
		case NUMERIC_KEY:
			if(DisplaySubMode == 0xFF)
				break;		
					if(NumericValue>=0xFFFF)
					{
						NumericValue = 0;
						MakeSound(SOUND_USER_ERROR);
					}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				break;
					
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(DisplaySubMode == 0xFF)
				break;
			
			if((NumericValue == 0) || (NumericValue >= 0xFFFF))
			{
				NumericValue = 0;
				MakeSound(SOUND_USER_ERROR);
				break;
			}
					SysInfo.SB_AUTH_Port2 = (unsigned int)NumericValue;
					DisplaySubMode =0xFF;
					NumericValue = 0;		
					WriteSysInfoToFlash();
					L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);		
					Delayandreturnback();			
#ifdef ENABLE_WATCHDOG
			WDTInit(5);			//watchdog initialization for secs
#endif			
			break;
			
	}
 }
 else
 {
		L_CenterDisplaySubStr("Please Enable",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		L_CenterDisplaySubStr("Server Auth",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	 
 } 
}
#endif //#ifdef ENABLE_SERVER_AUTH

/*---------------------------------------------------------------------------------------*/
void IPArrayToStr(BYTE *ipadd,char *ipstr)
{
	sprintf(ipstr,"%03d.%03d.%03d.%03d",ipadd[0],ipadd[1],ipadd[2],ipadd[3]);
}

/*---------------------------------------------------------------------------------------*/
void IPStrToArray(BYTE *ipaddarray,DWORD ipadd)
{
	ipaddarray[0] = (BYTE)(ipadd/0x1000000) & 0x000000FF;
	ipaddarray[1] = (BYTE)(ipadd/0x10000) & 0x000000FF;
	ipaddarray[2] = (BYTE)(ipadd/0x100) & 0x000000FF;
	ipaddarray[3] = (BYTE)(ipadd & 0x000000FF);
}

/*---------------------------------------------------------------------------------------*/
void HandleBaudrateSetting(BYTE keytype)
{
/*
	switch(keytype)
	{
	case FUNCTION_KEY:
		L_DisplayROMStr("Baudrate:        ",16,ROW_USER_ENTRY);
		NumericValue = SysInfo.BAUDPORT_D;
      if(SysInfo.BAUDPORT_D > MAX_BAUDRATE)
      	SysInfo.BAUDPORT_D = DEFAULT_BAUDRATE;
		L_DisplayROMStrLoc((char *)&BaudStr[DEFAULT_BAUDRATE],16,ROW_USER_ENTRY,10);
		DisplaySubMode = 0;
		break;
	case NUMERIC_KEY:
		L_BlankDisplay(ROW_USER_ENTRY);
		NumericValue = NumericValue%10;
		L_DisplayROMStr("Baudrate:      ",16,ROW_USER_ENTRY);
		if((NumericValue>=0 )&&(NumericValue<=MAX_BAUDRATE))
		{
			NumericValue = NumericValue ;
		}
		else
		{
			NumericValue = DEFAULT_BAUDRATE;
			MakeSound(SOUND_USER_ERROR);
		}
		L_DisplayROMStrLoc((char *)&BaudStr[(WORD)NumericValue],16,ROW_USER_ENTRY,10);
		break;
	case ENTER_KEY:
		if( DisplaySubMode == 0)
		{
			if((NumericValue>=0 ) &&(NumericValue<=MAX_BAUD_RATE_NO))
			{
				SysInfo.BAUDPORT_D = (WORD)NumericValue;
				L_DisplayROMStr("Baurate Updated    ",16,ROW_USER_ENTRY);
  				WriteSysInfoToFlash();
			}
			else
			{
				NumericValue = 2;
				MakeSound(SOUND_USER_ERROR);
				L_DisplayROMStrLoc((char *)&BaudStr[(WORD)NumericValue],16,ROW_USER_ENTRY,10);
			}
			DisplaySubMode = 0xFF;
		}
		break;
	}
*/
}

/*---------------------------------------------------------------------------------------*/
void HandleCardData(BYTE keytype) 
{
int cardptr;
struct RectInfo rectinfo;	
	switch(keytype)
	{
		case FUNCTION_KEY:
			NumericValue = 0;
			L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//			sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//      		if(Doorinfo.CardDigit == 8)
 //        		PositionCursorOnRowNo(9,ROW_USER_ENTRY);
      		CardPositionCount = 1;
      		NumericKeyCount = 0;
      		DisplayCardNo = NumericValue;
			DisplayMode = MODE_CARD_ADD_DATA;
			DisplaySubMode = 0;
			break;

		case WEIGAND_DATA:
			if(DisplaySubMode == 0)
      		{
						NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
						LongHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
       			DisplayCardNo = NumericValue;
						CardPositionCount = 1;
         		NumericKeyCount = 0;
			}	
		break;
			
			case 	TOUCH_KEY2: 
UP:
				if(DisplaySubMode == 1)
				{
					if(stRadioScrollData.CurrSeletion > 0)
					{	
						stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
						stRadioScrollData.CurrSeletion--;								
					}
					DisplayRadioScroll();
				}
			break;
			
		case 	TOUCH_KEY4: 		
DOWN:
				if(DisplaySubMode == 1)
				{
					if(stRadioScrollData.CurrSeletion < MAX_CARD_TYPE-1)
					{	
						stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
						stRadioScrollData.CurrSeletion++;								
					}
					DisplayRadioScroll();
				}
			break;
			
			case NUMERIC_KEY:
					if(DisplaySubMode == 0)
					{
						CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
					}
					else if(DisplaySubMode == 1)
					{
						if(CurrentKey == 2)
							goto UP;
						else if (CurrentKey == 8)
							goto DOWN;
						else if (CurrentKey == 5)
							goto ENTER;
// 				if(CurrentKey <= 6)
// 				{
// 					L_DisplayROMStr((BYTE *)&CARD_TYPES[CurrentKey],16,ROW_USER_ENTRY);
// 	      }
// 				else
// 				{
// 					CurrentKey = 0;
// 					L_DisplayROMStr((BYTE *)&CARD_TYPES[CurrentKey],16,ROW_USER_ENTRY);
// 				}
//   				L_DisplayCharRow(14,CurrentKey,ROW_USER_ENTRY);           
					}
			break;
			
		case 	TOUCH_KEY3: 	
		case ENTER_KEY:
ENTER:			
				rectinfo.FillType = RCTFILL_PLAIN;
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
				rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
				rectinfo.Width = 320;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
		
			if((DisplaySubMode == 0)&&(NumericValue != 0))
			{
				CurrentKey = 0;
//	  			L_DisplayCharRow(14,CurrentKey,ROW_USER_ENTRY);      
//				DisplayCardNo = NumericValue;
				DisplaySubMode = 1;
				stRadioScrollData.MaxScrollElement = MAX_CARD_TYPE;
				stRadioScrollData.PrevSeletion= -1;
				stRadioScrollData.CurrSeletion= CurrentKey;
				stRadioScrollData.Array= (const char**)CARD_TYPES;
				
				DisplayRadioScroll();				
			}
			else if(DisplaySubMode == 1)
			{
				Carddata.CardNo = DisplayCardNo;				
           		if(Doorinfo.CardDigit == 8)
					Carddata.CardPin = (WORD)((DWORD)(DisplayCardNo & 0x0000FFFFL) % (DWORD)10000);   
	            else
                	Carddata.CardPin = (WORD)((DWORD)DisplayCardNo % (DWORD)10000);   

				Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
				Carddata.CardInfo.Door1 = 0x1;
				Carddata.CardInfo.Door2 = 0x1;
				Carddata.CardInfo.Holiday = 0x0;
				Carddata.Info.MesgInfo = 0;
#ifdef EN_CARD_EXP_DATE
		 		Carddata.ExpDT = 0;
#endif
#ifdef EN_DOORACCESS
				Carddata.DoorAccess = 0xFF;		  //ARMD0402	  ''
#endif//#endif EN_DOORACCESS
#ifndef NEW_CARD_FORMAT
				Carddata.Info.BirthMonth = 0;
				Carddata.Info.BirthDate = 0;
#endif

//				Carddata.Info.CNVF = CurrentKey;
//				Carddata.Info.CType = CurrentKey*2;
#ifdef BIO_METRIC				
			if(stRadioScrollData.CurrSeletion == 4)
				Carddata.Info.CType = UTYPE_CHECK_CARD_PIN;				
				
				Carddata.Info.CType = stRadioScrollData.CurrSeletion*2;				
#else
			if(stRadioScrollData.CurrSeletion == 0)
				Carddata.Info.CType = UTYPE_CARD_ONLY_VERIFY;				
			if(stRadioScrollData.CurrSeletion == 1)
				Carddata.Info.CType = UTYPE_CARD_ONLY;				
			if(stRadioScrollData.CurrSeletion == 2)
				Carddata.Info.CType = UTYPE_CHECK_CARD_PIN;				
			if(stRadioScrollData.CurrSeletion == 3)
				Carddata.Info.CType = 12;				
			
#endif
							
				LongHextoDeciamal((char*)DisplayTempBuffer,DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);							
//				L_DisplayROMStr((BYTE *)&CARD_TYPES[CurrentKey],ROW_USER_ENTRY);
//	  			L_DisplayCharRow(14,CurrentKey,ROW_USER_ENTRY);            
				cardptr = AddCard(Carddata);
				if(cardptr != -1)
				{
					L_CenterDisplaySubStr("User Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"User Add Fail");
					L_CenterDisplaySubStr("User Add Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
				}
				Delayandreturnback();
				DisplaySubMode = 0;
			}
			break;
	}
}

#ifdef BIO_METRIC
static char flag_templ_sd ;
/*---------------------------------------------------------------------------------------*/
void HandleAddCardKeyBio(unsigned char type)
{
   {
	switch(type)
	{
		case WEIGAND_DATA:
			CardPositionCount = 1;
			NumericKeyCount = 0;
//			NumericValue = ReceivedCardNo;
			DisplayCardNo = NumericValue = ReceivedCardNo;
			if(DisplaySubMode == 0)
			{
					L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			}
			break;
			
		case TOUCH_KEY3:	
		case ENTER_KEY:
			HandleEnterAddCardKey();
			break;
	
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
		
			if(Doorinfo.CardDigit == 8)
				PositionCursorOnRowNo(9,ROW_USER_ENTRY);
			CardPositionCount = 1;
			NumericKeyCount = 0;     
			flag_templ_sd=1;
			break;
	
		case 	NUMERIC_KEY:
		case 	TOUCH_KEY2:   // left shift   select YES
		case 	TOUCH_KEY4:   // Right shift Select NO				 
			if(type == TOUCH_KEY2)
				CurrentKey = YES_KEY;
			else if(type == TOUCH_KEY4)
				CurrentKey = NO_KEY;
			//			L_BlankDisplay(ROW_USER_ENTRY);
			if((flag_templ_sd == 0) &&(DisplaySubMode == 0))
			{
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Sensor        SD");
					Xdigts = 6;
					tExtInfo.Image_TemplateSD_Flag  = 0x01; //
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

				}
				else if(CurrentKey == NO_KEY)
				{	
					strcpy((char*)DisplayTempBuffer,"Sensor        SD");
					Xdigts = 2;
					tExtInfo.Image_TemplateSD_Flag  = 0x02;
					Xpos = StartXpos + 15*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else{}	
				NumericValue = DisplayCardNo  ;					
			}
			else if(DisplaySubMode == 0)
			{
				CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
			}
			else if((DisplaySubMode == 10) || (DisplaySubMode == 25))
			{
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

				}
				else if(CurrentKey == NO_KEY)
				{	
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

				}
				else
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
			}
			break;

		case EVENT_TIME_OUT:
			if(TEVENT_ADDCARD_SEL_ADD_DEL == UserTimeOutEvent)
			{
				MakeSound(SOUND_KEY_PRESS);
				L_CenterDisplaySubStr("Del Old Fingers:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				MsgPrint(MSG_WARNING,UserFingerNo,"Fingers present Total Finger=");					
//				L_DisplayCharRow(14,(UserFingerNo & 0x0f)/2,ROW_USER_FUNCTION);
				DisplaySubMode = 10;			// DEL OLD FINGER
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
					CurrentKey = YES_KEY;
				  MsgPrint(MSG_WARNING,DisplayCardNo,"TEVENT_ADDCARD_SEL_ADD_DEL =");
			}
			else if(TEVENT_ADDCARD_DISP_SCORE == UserTimeOutEvent)
			{
				MsgPrint(MSG_WARNING,UserFingerNo,"Add finger Old finger no=");
//				L_DisplayROMStr("Add Finger No:  ",16,ROW_USER_FUNCTION);
//				L_DisplayCharRow(14,UserFingerNo+1,ROW_USER_FUNCTION);
//				L_DisplayROMStr("1:Yes      3:No ",16,ROW_USER_ENTRY);
				
				sprintf((char*)DisplayTempBuffer,"Add Finger:%d",UserFingerNo+1);				
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);

				strcpy((char*)DisplayTempBuffer,"Yes         No");
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				CurrentKey = YES_KEY;
				DisplayMode = MODE_ADD_FINGER_TO_ID;
				DisplaySubMode = SMODE_CHECK_ADD_FINGER_TO_ID;
				UserIntfData.NewModeIndex  = 14;
			}
			break;
	}
   }
	
}

/*------------------------------------------------------------------------*/
extern int AddCardExtraData(unsigned int cardindex,_CExtraInfo *tmpinfobuff);
void HandleEnterAddCardKey(void)
{
int cardptr;
char temp;
BYTE askfinger,err,tno;
WORD templatesize;	
struct SD_TEMPLATE_DATA SDtemplateinfo;
// _CExtraInfo  tExtInfo;
//	struct RectInfo rectinfo;
	askfinger = 1;
	if(DisplaySubMode == 0)
	{
		if(NumericValue != 0)
		{
			MsgPrint(MSG_WARNING,DisplayCardNo,"search CardData");
			cardptr = SearchDisplayCard(DisplayCardNo,&Carddata);
			if(cardptr == CARD_NOT_FOUND)
			{
				if(flag_templ_sd)
				{
					L_CenterDisplaySubStr("Add Template in:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					strcpy((char*)DisplayTempBuffer,"Sensor        SD");
					StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
					Xdigts = 6;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
	//				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
					CurrentKey = YES_KEY;
					tExtInfo.Image_TemplateSD_Flag  = 1; // no template in Sensor or sd 
					flag_templ_sd = 0;					
					PositionCursorOnRowNo(0,ROW_USER_ENTRY);
					return;
				}	
//#ifdef BIO_SMART_TEMPLATE//need to take care of this when developing for standalone unit.
//				L_DisplayROMStr("Add Finger :    ",16,ROW_USER_FUNCTION);					
				
				if((tExtInfo.Image_TemplateSD_Flag&0x0F) == 1)	
				{
					GetBalanceTemplate();	// NG0004
					if(BalTemplates < TEMPLATE_OFFSET)
					{
						L_CenterDisplaySubStr("Sensor Mem Full",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);						
						L_CenterDisplaySubStr("Add in SD",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						DisplaySubMode = 0;
						NumericValue = 0;
						Delayandreturnback();
						return;
					}
				}
				L_CenterDisplaySubStr("Add Finger:1",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				strcpy((char*)DisplayTempBuffer,"Yes         No");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

				CurrentKey = YES_KEY;
				PositionCursorOnRowNo(0,ROW_USER_ENTRY);
				DisplaySubMode = 25;
				return;
//#endif
AddFingerToUnit:			
				// Card Not Present So adding new card
				MsgPrint(MSG_WARNING,DisplayCardNo,"User ID Not Present ID=");		
				ENABLE_BIO_COMM();	

#ifdef SUPPORT_SUPREMA
				if(CheckBioUserID(DisplayCardNo) == 0)					
#else
				if(CheckBioUserID(DisplayCardNo) != 0)					
#endif
				{
//finger is present for this id
					UserFingerNo = (BYTE)BioCmdSize & 0x0f;
// Pankaj New Change for finger add problem
#ifdef SUPPORT_SUPREMA
					if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
					{
						if(UserFingerNo != 1)                     
							UserFingerNo = (UserFingerNo & 0xFF) / 2;
					}
					else
#endif
					UserFingerNo = UserFingerNo & 0xFF;
					DISABLE_BIO_COMM();
					// Indicates finger with this ID present so ask to Delete the Finger
					MsgPrint(MSG_WARNING,UserFingerNo,"Fingers present But no User ID so ask");
					MakeSound(SOUND_KEY_PRESS);
					GenerateUserTimerEvent(2,TEVENT_ADDCARD_SEL_ADD_DEL);
//					L_DisplayROMStr("Fingers Present:",16,ROW_USER_FUNCTION);
					MsgPrint(MSG_WARNING,UserFingerNo,"Fingers present Total Finger=");
//					L_DisplayCharRow(14,UserFingerNo,ROW_USER_FUNCTION);
					sprintf((char*)DisplayTempBuffer,"Fingers Present:%d",UserFingerNo);					
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);										
//					L_DisplayROMStr("UID:            ",16,ROW_USER_ENTRY);
//					L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);				
					sprintf((char*)DisplayTempBuffer,"UID:%010u",DisplayCardNo);					
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);										
				}
				else
				{
					UserFingerNo = 0;
					MsgPrint(MSG_WARNING,UserFingerNo,"Fingers Not Present For ID ");
					DISABLE_BIO_COMM();
					// Add New Card and Finger
					DisplaySubMode = 1;
					UserFingerNo = 0;
					MsgPrint(MSG_WARNING,DisplayCardNo,"Enroll Started");
					ENABLE_BIO_COMM();					
					sprintf((char*)DisplayTempBuffer,"Place Finger:%d",UserFingerNo+1);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);										
#ifdef SUPPORT_SPEECHIC				
					PlaySoundMsg(PLACE_FINGER);
					waitX10ms(100);	
#endif		
					if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 1 )
					{
						UserBioMode = BIO_GET_ENROLLED_FINGER_ID;
						EnrollNewFingerID(DisplayCardNo,0x84);
						FingerWaitTimeOut = 0;
						UserTempData = 0;
					}
					else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2 )
					{
						tExtInfo.TemplateData = FIRST_TEMPLATE;
						err = ScanBioTemplate((BYTE*)&SDtemplateinfo.TData);
						if(err == 1)
						{
							L_CenterDisplaySubStr("Sensor Fail!",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
							return;
						}	
						else
						{	
							DisplaySubMode = ENTER_ADD_CARD_CONTROLLER;
							SDtemplateinfo.TSZ = BioCmdSize;
							goto AddCardToController;
						}
					}
				}
			}				
		 else
		 {
// Card Present in controller so add finger to card
			ReadCardTemplateInfoFromFlash(cardptr,&tExtInfo);		// check whether card template is in SD or saensor 
			MsgPrint(MSG_WARNING,DisplayCardNo,"UserID Present=");
			ENABLE_BIO_COMM();
			UserFingerNo = 0;
				
			if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 1)
			{			
					GetBalanceTemplate();	// NGD0022
					if(BalTemplates < TEMPLATE_OFFSET)
					{
						L_CenterDisplaySubStr("Sensor Mem Full",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);						
						L_CenterDisplaySubStr("Del& Add in SD",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						DisplaySubMode = 0;
						NumericValue = 0;
						return;
					}					
#ifdef SUPPORT_SUPREMA						
					if(CheckBioUserID(DisplayCardNo) == 0)									
#else
					if(CheckBioUserID(DisplayCardNo) != 0)
#endif
					{
						UserFingerNo = (BYTE)BioCmdSize & 0x0f;
#ifdef SUPPORT_SUPREMA
						if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
						{
							if(UserFingerNo != 1)                     
								UserFingerNo = (UserFingerNo & 0xFF) / 2;
						}
						else
#endif
							UserFingerNo = UserFingerNo & 0xFF;
						MsgPrint(MSG_WARNING,UserFingerNo ,"Finger Also Prsent No=");
					}
			 }
			else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2)
			{

				UserFingerNo = 0;
				for(temp=0;temp<=7;temp++)
				{
					UserFingerNo += (tExtInfo.TemplateData>>temp) & 0x01;					
				}
			}	
			if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 0)
			{			
				GetBalanceTemplate();	// NGD0022
				if(BalTemplates < TEMPLATE_OFFSET)
					{
						tExtInfo.Image_TemplateSD_Flag = 2;					
					}					
					else
					{
						tExtInfo.Image_TemplateSD_Flag = 1;					
					}	
					AddCardExtraData(cardptr,&tExtInfo);		//NGD00029					
			}
			temp = UserFingerNo;		// this is to handle for Finger in 2 Template mode
			DISABLE_BIO_COMM();
			MsgPrint(MSG_WARNING,DisplayCardNo,"Add  finger to ID=");
			if(UserFingerNo == 0)
			{
				sprintf((char*)DisplayTempBuffer,"Add Finger:%d",UserFingerNo+1);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				sprintf((char*)DisplayTempBuffer,"Place Finger:%d",UserFingerNo+1);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
#ifdef SUPPORT_SPEECHIC				
					PlaySoundMsg(PLACE_FINGER);
					waitX10ms(100);	
#endif		
				MsgPrint(MSG_WARNING,DisplayCardNo,"New finger to ID=");
				UserBioMode = BIO_GET_ENROLLED_FINGER_ID;
				DisplaySubMode = 0;
				ENABLE_BIO_COMM();
				
				if((tExtInfo.Image_TemplateSD_Flag & 0x0F)== 1)			
					EnrollNewFingerID(DisplayCardNo,0x84);
				else if((tExtInfo.Image_TemplateSD_Flag & 0x0F)== 2)		
				{
					FingerWaitTimeOut = 0;						
					err = ScanBioTemplate((BYTE*)&SDtemplateinfo.TData);
					if(err == 1)
						return;
					else
					{
						DisplaySubMode = ENTER_ADD_CARD_CONTROLLER;
						SDtemplateinfo.TSZ = BioCmdSize;
						goto AddCardToController;
					}
				}	
					
				FingerWaitTimeOut = 0;
				UserTempData = 0;
				DisplayMode = MODE_ADD_FINGER_TO_ID;
			}
			else
			{
				if((BIO_SINGLE_ENROLL != SysInfo.BioEnrollType) &&(tExtInfo.Image_TemplateSD_Flag == 1))	// NGD00138					
					temp = 	UserFingerNo*2;
					
				if(temp < MAX_FINGERS)
				{
					if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType) // NGD00138												
						UserFingerNo = 	temp/2;
				
					MsgPrint(MSG_WARNING,UserFingerNo,"Add finger Old finger no=");
					sprintf((char*)DisplayTempBuffer,"Add Finger:%d",UserFingerNo+1);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

//				if((tExtInfo.Image_TemplateSD_Flag & 0x0F)== 1)			
				{
					CurrentKey = YES_KEY;
					DisplayMode = MODE_ADD_FINGER_TO_ID;
					DisplaySubMode = SMODE_CHECK_ADD_FINGER_TO_ID;
					UserIntfData.NewModeIndex  = 14;
				}
// 				else if((tExtInfo.Image_TemplateSD_Flag & 0x0F)== 2)
// 				{
// 					FingerWaitTimeOut = 0;						
// 					err = ScanBioTemplate((BYTE*)&SDtemplateinfo.TData);
// 					if(err == 1)
// 						return;
// 					else
// 					{
// 						DisplaySubMode = ENTER_ADD_CARD_CONTROLLER;
// 						SDtemplateinfo.TSZ = BioCmdSize;
// 					}					
// 				}
					
// 					CurrentKey = YES_KEY;
// 					DisplayMode = MODE_ADD_FINGER_TO_ID;
// 					DisplaySubMode = SMODE_CHECK_ADD_FINGER_TO_ID;
					return;
				}
				else
				{
						L_CenterDisplaySubStr("No Finger Space:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);																	
						sprintf((char*)DisplayTempBuffer,"Total Finger:%d",UserFingerNo);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						MakeSound(SOUND_USER_ERROR);
						DisplaySubMode = 20;
						Delayandreturnback(); //NGD00180					
				}
			}
		 }
		}
		else
		{
			MakeSound(SOUND_USER_ERROR);
		}
	}
	else if(DisplaySubMode == ENTER_ADD_CARD_CONTROLLER)
	{
AddCardToController:
		L_BlankDisplay(ROW_USER_ENTRY);
//		L_DisplayROMStr("Adding User.....",16,ROW_USER_ENTRY);
		Carddata.CardNo = DisplayCardNo;
		if(DisplayCardNo > 65535)
		{
			if(Doorinfo.CardDigit == 8)
				Carddata.CardPin = (WORD)((DWORD)(DisplayCardNo & 0x0000FFFFL) % (DWORD)10000);   
			else
				Carddata.CardPin = (WORD)((DWORD)DisplayCardNo % 10000);
		}
		else
			Carddata.CardPin = (WORD)DisplayCardNo;
		Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
		Carddata.CardInfo.Door1 = 0x1;
		Carddata.CardInfo.Door2 = 0x1;
		Carddata.CardInfo.Holiday = 0x0;
		Carddata.Info.MesgInfo = 0;
//		Carddata.Info.CNVF = UTYPE_CARD_OP_FIN_MUST_VERIFY;
		Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
		if(askfinger == 0)//  ARMD0257
		Carddata.Info.CType = UTYPE_CARD_ONLY_VERIFY;
#ifdef EN_DOORACCESS
		Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
#ifdef EN_CARD_EXP_DATE
		Carddata.ExpDT = 0;
#endif
#ifndef NEW_CARD_FORMAT
		Carddata.Info.BirthMonth = 0;
		Carddata.Info.BirthDate = 0;
#endif		
		for(temp=0;temp<15;temp++)
		{	tExtInfo.Name[temp] = ' ';}
		if(tExtInfo.Image_TemplateSD_Flag == 2)	// NGD00024
		{
			tno = 0;
			for(temp=0;temp<=7;temp++)
			{
				tno += (tExtInfo.TemplateData>>temp) & 0x01;					
			}
		}	
		else{tExtInfo.TemplateData = 0;}	
		
		if(askfinger == 0)
		{		
			tExtInfo.JoiningDate = 0;
			tExtInfo.BirthDate = 0;
			tExtInfo.BirthMonth = 0;
			tExtInfo.AccessDate = 0;
			tExtInfo.TemplateData =0 ;
			if(tExtInfo.Image_TemplateSD_Flag == 1)	// NGD00051
				tExtInfo.Image_TemplateSD_Flag = 0; 
		}
		else
		{
			tExtInfo.JoiningDate = 0;
			tExtInfo.BirthDate = 0;
			tExtInfo.BirthMonth = 0;
			tExtInfo.AccessDate = 0;
		}
		cardptr = AddCard(Carddata);	
		L_BlankDisplay(ROW_USER_ENTRY);
		if(cardptr != -1)	
		{
			if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 0x02)
			{	
				SDtemplateinfo.CardNo= Carddata.CardNo;
				if(tno != 0)//NGD00158
				{
					err = AddTemplateToSD(SDtemplateinfo,cardptr,tno);			//NGD00028
					if(err== 0)
					{
						err = ERROR_SD_WRITE_FAIL;
						L_CenterDisplaySubStr("SD write fail!",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						return;	
					}
				}
			}
			err = AddCardExtraData(cardptr,&tExtInfo);		
			
			MsgPrint(MSG_WARNING,cardptr,"Card Added");
//			L_DisplayROMStr("UAdded:         ",16,ROW_USER_ENTRY);
			MakeSound(SOUND_KEY_PRESS);
//#ifdef BIO_SMART_TEMPLATE//need to take care of this when developing for standalone unit.
				if(askfinger == 0)
				{
					L_CenterDisplaySubStr("User Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_DisplayCardNumber(Carddata.CardNo,6,ROW_USER_ENTRY);
//					sprintf((char*)DisplayTempBuffer,"%010u",Carddata.CardNo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
					DisplaySubMode = 0;
					Delayandreturnback();	//NGD00064
					return;
				}
//#endif
// 				AddCardNameToFlash add name to extra card data info so we can directly add name in AddCardExtraData 
//				AddCardNameToFlash(cardptr,"                ");  
//				L_DisplayROMStr("UAdd:           ",16,ROW_USER_ENTRY);
//          	L_DisplayCardNumber(Carddata.CardNo,6,ROW_USER_ENTRY);
						
				ENABLE_BIO_COMM();
				UserFingerNo = 0;			
				if(tExtInfo.Image_TemplateSD_Flag == 1)
				{	
#ifdef DISP_ENROLL_SCORE
				if(BioCmdStatus == STATUS_BIO_SUCCESS)                        
					Enroll_Score = (BYTE)BioCmdSize & 0xff;
#endif
		
#ifdef SUPPORT_SUPREMA				
				if(CheckBioUserID(DisplayCardNo) == 0)
#else
				if(CheckBioUserID(DisplayCardNo) != 0)
#endif
				{
					UserFingerNo = (BYTE)BioCmdSize & 0x0f;
#ifdef SUPPORT_SUPREMA
					if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
					{
						if(UserFingerNo != 1)                     
							UserFingerNo= (UserFingerNo & 0xFF) / 2;
					}
					else
#endif
						UserFingerNo = UserFingerNo & 0xFF;
	//				DISABLE_BIO_COMM();
					MsgPrint(MSG_WARNING,UserFingerNo ,"Finger Also Presnt No=");
				}
			 }	
			 else if(tExtInfo.Image_TemplateSD_Flag == 2)
			 {
				 Enroll_Score = BioCmdData;
				 templatesize = BioCmdSize;	 	 
				 UserFingerNo =0;				
				for(temp=0;temp<=7;temp++)
				{		
					UserFingerNo += tExtInfo.TemplateData>>temp&0x01;
				}
				L_CenterDisplaySubStr("Finger Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR); // NG0004
				sprintf((char*)DisplayTempBuffer,"Score:%3d%%",Enroll_Score);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);					
			 }
				DISABLE_BIO_COMM();
#ifdef DISP_ENROLL_SCORE

// 				L_CenterDisplaySubStr("Finger Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
// 				sprintf((char*)DisplayTempBuffer,"Score:%3d%%",Enroll_Score);
// 				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
// 				// Generate time out event so we can give some time to use to see data on display. we can come out of this by entering enter key also
// 				GenerateUserTimerEvent(1,TEVENT_ADDCARD_DISP_SCORE);
// //				DisplayMode = MODE_ADD_FINGER_TO_ID;
// 				DisplaySubMode = ENTER_ADD_CARD_SCORE_TIMEOUT;
			 
				F_TempCounterStart = SET;
				Temp_Time_Counter = 0;
				while(Temp_Time_Counter < 1);
					F_TempCounterStart = CLR;

				sprintf((char*)DisplayTempBuffer,"Add Finger:%d",UserFingerNo+1);				
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);

				strcpy((char*)DisplayTempBuffer,"Yes         No");
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				CurrentKey = YES_KEY;
				DisplayMode = MODE_ADD_FINGER_TO_ID;
				DisplaySubMode = SMODE_CHECK_ADD_FINGER_TO_ID;
				UserIntfData.NewModeIndex  = 14;
						 
#else
				MsgPrint(MSG_WARNING,UserFingerNo,"Add finger Old finger no=");
	//			L_DisplayCharRow(14,UserFingerNo+1,ROW_USER_FUNCTION);
				sprintf(DisplayTempBuffer,"Add Finger:%d",UserFingerNo+1);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);	
				strcpy((char*)DisplayTempBuffer,"Yes         No");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, DisplayTempBuffer)) / 2;
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				
				CurrentKey = YES_KEY;
//				PositionCursorOnRowNo(0,ROW_USER_ENTRY);
 				DisplayMode = MODE_ADD_FINGER_TO_ID;
				DisplaySubMode = SMODE_CHECK_ADD_FINGER_TO_ID;
#endif
		}
		else
		{
			MsgPrint(MSG_WARNING,cardptr,"User Memory Full");
//			L_DisplayROMStr("User Memory Full",16,ROW_USER_ENTRY);
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
			L_CenterDisplayROMStrLoc("User Memory Full",ROW_USER_ENTRY);
			DeleteBioUserID(DisplayCardNo);
			MsgPrint(MSG_WARNING,DisplayCardNo,"Delete User finger which is added");
			MakeSound(SOUND_USER_ERROR);
		}
	}
	else if (DisplaySubMode == 10)
	{
		if(CurrentKey == YES_KEY)
		{
			ENABLE_BIO_COMM();
			DeleteBioUserID(DisplayCardNo);
			DISABLE_BIO_COMM();
			MsgPrint(MSG_WARNING,DisplayCardNo,"Deleted finger for ID =");
			DisplaySubMode = 1;
			UserFingerNo = 0;
			MsgPrint(MSG_WARNING,DisplayCardNo,"Enroll Started");
			ENABLE_BIO_COMM();
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
//			L_CenterDisplayROMStrLoc("Add FingerToID: ",ROW_USER_ENTRY);
			L_CenterDisplaySubStr("Place Finger:1",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			UserBioMode = BIO_GET_ENROLLED_FINGER_ID;
			tExtInfo.Image_TemplateSD_Flag = 1; // in  sensor 
			tExtInfo.TemplateData = FIRST_TEMPLATE;			
			EnrollNewFingerID(DisplayCardNo,0x84);
			FingerWaitTimeOut = 0;			
			UserTempData = 0;
		}
		else if(CurrentKey == NO_KEY)
		{
			// Do not delete fingers and add new finger to card...
			MsgPrint(MSG_WARNING,DisplayCardNo,"Do not delete add new finger to ID=");
			L_BlankDisplay(ROW_USER_ENTRY);
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
			L_CenterDisplaySubStr("Adding UserID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			Carddata.CardNo = DisplayCardNo;
			if(DisplayCardNo > 65535)
				Carddata.CardPin = (WORD)((DWORD)DisplayCardNo % 10000);
			else
				Carddata.CardPin = (WORD)DisplayCardNo;
			Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
			Carddata.CardInfo.Door1 = 0x1;
			Carddata.CardInfo.Door2 = 0x1;
			Carddata.CardInfo.Holiday = 0x0;
//			Carddata.Info.CNVF = UTYPE_CARD_OP_FIN_MUST_VERIFY;
            Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
			Carddata.Info.MesgInfo = 0;
#ifdef EN_DOORACCESS
		Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
#ifdef EN_CARD_EXP_DATE
			Carddata.ExpDT = 0;
#endif
#ifndef NEW_CARD_FORMAT
			Carddata.Info.BirthMonth = 0;
			Carddata.Info.BirthDate = 0;
#endif
			tExtInfo.Image_TemplateSD_Flag = 1; // in  sensor 
			
			for(temp=0;temp<15;temp++)	//NGD00025        
			{tExtInfo.Name[temp] = ' ';}
			tExtInfo.JoiningDate = 0;
			tExtInfo.BirthDate = 0;
			tExtInfo.BirthMonth = 0;
			tExtInfo.AccessDate = 0;
			tExtInfo.TemplateData = 0;
			
			cardptr = AddCard(Carddata);
			L_BlankDisplay(ROW_USER_ENTRY);
			if(cardptr != -1)
			{
				err = AddCardExtraData(cardptr,&tExtInfo);
				AddCardNameToFlash(cardptr,"                ");
				MsgPrint(MSG_WARNING,cardptr,"Card Added");
				L_CenterDisplaySubStr("User Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				// Adding new finger to samer User ID
				UserFingerNo = 0;
				ENABLE_BIO_COMM();
#ifdef SUPPORT_SUPREMA
				if(CheckBioUserID(DisplayCardNo) == 0)
#else
				if(CheckBioUserID(DisplayCardNo) != 0)
#endif
				{
					UserFingerNo = (BYTE )BioCmdSize & 0x0f;
#ifdef SUPPORT_SUPREMA
					if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
					{
						if(UserFingerNo != 1)                     
							UserFingerNo = (UserFingerNo & 0xFF) / 2;
					}
					else
#endif
						UserFingerNo = UserFingerNo & 0xFF;
//					DISABLE_BIO_COMM();
				}
				DISABLE_BIO_COMM();
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
				if(UserFingerNo >=MAX_TEMPLATE_SD_PERUSER)
				{
					sprintf((char*)DisplayTempBuffer,"MAX Template -%d ",UserFingerNo);
					L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY2);					
					Delayandreturnback();
						return;
				}
				L_CenterDisplaySubStr("Add FingerToID:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
//				L_DisplayROMStr("Add FingerToID: ",16,ROW_USER_ENTRY);
				MsgPrint(MSG_WARNING,(WORD)BioCmdSize,"Finger No BioCmdSize=");
				sprintf((char*)DisplayTempBuffer,"Put Finger - %d ",UserFingerNo+1);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_DisplayCharRow(14,UserFingerNo+1,ROW_USER_ENTRY4);
				//Adding finger to existing ID
#ifdef SUPPORT_SPEECHIC				
						PlaySoundMsg(PLACE_FINGER);
#endif		
				DisplayMode = MODE_ADD_FINGER_TO_ID;
				DisplaySubMode = 1;
				ENABLE_BIO_COMM();
				UserBioMode = BIO_GET_ENROLLED_FINGER_ID;
				EnrollNewFingerID(DisplayCardNo,0x84);
				FingerWaitTimeOut = 0;
				UserTempData = 0;
			}
			else
			{
				MsgPrint(MSG_WARNING,cardptr,"User Add Fail");
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
				L_DisplayROMStr("User Add Fail   ",16,ROW_USER_ENTRY);
				MakeSound(SOUND_USER_ERROR);
			}
		}
		else
		{
			MakeSound(SOUND_USER_ERROR);
		}
	}
	else if(DisplaySubMode == 20)
	{
		DisplayMode = MODE_ADD_CARD;
//		L_DisplayROMStr("Add Card:       ",16,ROW_USER_FUNCTION);
//		L_DisplayROMStr("UID:            ",16,ROW_USER_ENTRY);
//		L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
		DisplaySubMode = 0;
//		DisplayModeData(MODE_ADD_CARD);
	}
	else if(DisplaySubMode == 25)
	{
	// To aks whether user wants to add local finger or not
		if(CurrentKey == YES_KEY)
		{
			DisplaySubMode = 0;
			goto AddFingerToUnit;
		}
		else
		{
			DisplaySubMode = ENTER_ADD_CARD_CONTROLLER;
			askfinger = 0;
			goto AddCardToController;
		}
	}
	else if(DisplaySubMode == ENTER_ADD_CARD_SCORE_TIMEOUT)
	{
		if(TEVENT_ADDCARD_DISP_SCORE == UserTimeOutEvent)
			HandleAddCardKeyBio(EVENT_TIME_OUT);
	}
}

/*---------------------------------------------------------------------------------------*/
void HandleUserIdentifyMode(BYTE eventtype)
{
unsigned char sensorfail;

	sensorfail = 0;
	switch(eventtype)
	{
		case BIO_EVENT:
			switch(BioCmdStatus)
			{
#ifdef SUPPORT_SUPREMA
				case STATUS_BIO_FINGER_FOUND:
					//L_DisplayROMStr("Finger Scan Over",16,ROW_USER_ENTRY);    //for ng
					break;
#endif
				case STATUS_BIO_TIME_OUT:
					if(SysInfo.IdentifyMode != BIO_POLL_TYPE_AUTO_IDENTIFY)
					{
						if(F_FingerUnderPoll != SET)
							L_DisplayROMStr("Finger Time Out ",16,ROW_USER_ENTRY);
					}
					goto FAIL_HANDLEId;

				case STATUS_BIO_COMM_TIME_OUT:
					L_DisplayROMStr("Sensor Fail TimeOut",16,ROW_USER_ENTRY);
					sensorfail = 1;
					goto FAIL_HANDLEId;

				case STATUS_BIO_SUCCESS:
					DISABLE_BIO_COMM();
					//MakeSound(SOUND_KEY_PRESS);
					ReceivedCardNo = (CARDNO_DATA_STORAGE_TYPE)BioCmdData;	   
#ifdef SUPPORT_WEIGAND_OUT
					if(Doorinfo.CardMask == 16)
						ReceivedCardNo = ReceivedCardNo & (DWORD)0x0000FFFF;
					WCount = SysInfo.WeigandOutCont & 0x3F;  //ARMF0554
#endif
					MsgPrint(MSG_WARNING,ReceivedCardNo,"Finger Received with ID");
               		ReaderNo = 1;
					ReaderData[ReaderNo-1].FacCode = 0;
					CurrentUser.InputType = INPUT_USER_FROM_FINGER;
					ReaderData[0].F_CardFound = SET;
//					F_CardFound1 = SET;
//					ProcessCard(1);
					UserBioMode = 0;
/*					if(SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY)
					{
						F_Poll_Bio_Sensor = SET;
						F_FingerUnderPoll = CLR;
					}*/
					break;
				case STATUS_BIO_NOT_FOUND:
#ifndef SUPPORT_SUPREMA
				case STATUS_BIO_IDENTIFY_FAILED:
#endif
                DisplayFormat(FORMAT_EVENT_ICON);
								DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
								ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
								USER_TITLE_FONTINFO_PTR,
								320,
								(unsigned char*)"User Access",
								ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
					HandleDisplayErrorMessages(EVENT_CARD_NOT_FOUND);
					ReceivedCardNo = 0;
					StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,ReaderNo,EVENT_CARD_NOT_FOUND);
					goto FAIL_HANDLEId;

				case STATUS_BIO_NOT_MATCH:
#ifdef SUPPORT_SUPREMA
				case STATUS_BIO_FINGER_MATCH_TIMEOUT:      			
#endif
					L_DisplayROMStr("Finger Not Match",16,ROW_USER_ENTRY);
					ReceivedCardNo = 0;
					StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,ReaderNo,EVENT_CARD_NOT_FOUND);
					goto FAIL_HANDLEId;
				case STATUS_BIO_BUSY:
//            		printf("Sensor Busy \n");
            		break;

				default:
FAIL_HANDLEId:
					if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
					{
						PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 3;
						if(F_FingerUnderPoll == SET)
						{
							F_Poll_Bio_Sensor = SET;
							F_FingerUnderPoll = CLR;
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
							F_KeyIdleTime = CLR;
							DisplayMode = MODE_WAIT_FOR_CARD;
							DISABLE_BIO_COMM();
							UserBioMode = 0;
							if((STATUS_BIO_NOT_FOUND ==BioCmdStatus )||( STATUS_BIO_FINGER_MATCH_TIMEOUT ==BioCmdStatus)||(BioCmdStatus==STATUS_BIO_NOT_MATCH)) //ARMD0189
							{
								//MakeSound(SOUND_CARD_NOT_FOUND);
							}
							else if(STATUS_BIO_TIME_OUT != BioCmdStatus)
							{
								MakeSound(SOUND_USER_ERROR);
								IdleKeyCounter = MAX_KEY_IDLE_TIME - 3;
							}
							break;
              			}
					}
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
					F_KeyIdleTime = CLR;
					DisplayMode = MODE_WAIT_FOR_CARD;
					DISABLE_BIO_COMM();
					UserBioMode = 0;
//					MakeSound(SOUND_USER_ERROR);
					MakeSound(SOUND_CARD_NOT_FOUND);
					break;
			}
			break;
	}
	BioSensorFail = sensorfail;
}
/*---------------------------------------------------------------------------------------*/
void HandleUserVerifyMode(BYTE eventtype)
{
	switch(eventtype)
	{
		case KEYBOARD_CARD_EVENT:
		case WEIGAND_DATA:
		case INITIALISE_EVENT:
			CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FROM_FINGER;
			DisplayCardNo = NumericValue;
			L_DisplayROMStr("Search User.....",16,ROW_USER_ENTRY);
			VerifyFingerCardID = DisplayCardNo;
			if(F_BIO_COMM == SET)
			{
				CancelBioCommand();
				F_BIO_COMM = CLR;
			}
//===================================
// Impliment Bio Att no Check ie it gives access to card in card+finger  mode			
		 	//if(CheckBioUserID(DisplayCardNo) != 0)
			//{
//				F_FlashSelect = 1;              // CurrentUser.SearchCardPtr -> GetUserinfo - User no added in Card Structure
			F_authScreenTimerEnable = 1;
			F_authScreenTimer =11;								
			IdleKeyCounter	= CLR;	
			
		 	if((CheckBioUserID(DisplayCardNo) != 0)&&(!((CHECK_ATT_NOCARD(DspRdrNo)) || (CHECK_DENY_LIST(DspRdrNo)) )))  //ARMF0504 //ARMF2000TF	
			{				
				if(ReadCardTemplateInfoFromFlash(CurrentUser.SearchCardPtr,&tExtInfo)== 0)
				{		
//						if(SysInfo.IdentifyMode == 0)
									
						if(tExtInfo.Image_TemplateSD_Flag == 2)
						{
							CurrentCard.Template = SensorTemplateSize;
//							CurrentCard.NoOfTemp = tExtInfo.CardTemplateInfo.NoOfTemp;
							HandleUserHostVerify(INITIALISE_EVENT);							
						}	
						else		//NG0007
						{
							if(CheckBioUserID(DisplayCardNo) == 0)
							{
#ifdef SUPPORT_SPEECHIC
								PlaySoundMsg(PLACE_FINGER);
#endif								
								ENABLE_BIO_COMM();
								F_VerifyFingerCardID_CNVF = CLR;
								
								VerifyFinger(DisplayCardNo);
								if(FingerRechkCount == 0)
									L_DisplayROMStr("Place Finger...",16,ROW_USER_ENTRY);
								else
								{
									L_DisplayROMStr("Finger Retry -  ",16,ROW_USER_ENTRY);
									L_DisplayCharAtRow(15,(FingerRechkCount)+'0',ROW_USER_ENTRY);
								}
								UserBioMode = BIO_GET_USER_ID_BY_SCAN;
								FingerWaitTimeOut = 0;
								NumericValue = 0;
								DisplaySubMode = 0;
							}
							else
							{
								L_DisplayROMStr("No finger in Sensor..",16,ROW_USER_ENTRY);
								IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
								F_KeyIdleTime = CLR;
								DisplayMode = MODE_WAIT_FOR_CARD;
								DISABLE_BIO_COMM();
								UserBioMode = 0;
								MakeSound(SOUND_CARD_NOT_FOUND);																								
							}
						}
				}
			}
			else
			{
#ifdef SUPPORT_SPEECHIC
				PlaySoundMsg(PLACE_FINGER);
#endif								

				ENABLE_BIO_COMM();	// NGD00171
				VerifyFinger(DisplayCardNo);
				if(FingerRechkCount == 0)               
					L_DisplayROMStr("Place Finger :L:",16,ROW_USER_ENTRY);
				else
				{
					L_DisplayROMStr("Finger Retry -  ",16,ROW_USER_ENTRY);
					L_DisplayCharAtRow(15,(FingerRechkCount)+'0',ROW_USER_ENTRY);
				}	
				UserBioMode = BIO_GET_USER_ID_BY_SCAN;
				FingerWaitTimeOut = 0;
				NumericValue = 0;
				DisplaySubMode = 0;				
			}

/*					nooftemp = 0;
					for(i=0;i<4;i++)
					{
						if(tExtInfo.CardTemplateInfo.TLoc[i] != 0xFFFF)
						{
							nooftemp++;
							tindex = tExtInfo.CardTemplateInfo.TLoc[i];
							ReadTemplateFromSD(tindex,&tempdata);
							memcpy(&BufferTemp[nooftemp-1][0],tempdata.TemplateData,MAX_TEMPLATE_SIZE);
						}
					} */
					
//					for(i=1;i<=4;i++)
					{	
			//			ReadTemplateFromSD(CurrentUser.SearchCardPtr,&tempdata,NoOfTemp);					
//						memcpy(&BufferTemp,tempdata.TemplateData,MAX_TEMPLATE_SIZE);						
					}	
//					tExtInfo.CardTemplateInfo.NoOfTemp = nooftemp;
//				}
//				F_FlashSelect = 0;
		//	}
//===================================
			break;

		case BIO_EVENT:
			switch(BioCmdStatus)
			{
#ifdef SUPPORT_SUPREMA
				case STATUS_BIO_FINGER_FOUND:
					L_DisplayROMStr("Finger Scan Over",16,ROW_USER_ENTRY);
#ifdef ENABLE_LCD_BACKLITE
					BacklitOnTime = 0;	   
  	    			ON_LCD_BACKLIGHT();
#endif
/*					if(F_VerifyFingerCardID_CNVF == SET)         	// PANKAJ NEEDS TO TAKE CARE IF SENSOR IS SET with different parameters for finfer scan sent
					{
						DISABLE_BIO_COMM();
						MakeSound(SOUND_KEY_PRESS);
						ReceivedCardNo = VerifyFingerCardID;
						VerifyCard();
						UserBioMode = 0;
						MsgPrint(MSG_WARNING,BioCmdData,"Finger NVF Type =");
					}*/
					break;
#endif
				case STATUS_BIO_TIME_OUT:
					L_DisplayROMStr("Finger Time Out ",16,ROW_USER_ENTRY);
					goto FAIL_HANDLE;

				case STATUS_BIO_COMM_TIME_OUT:
					L_DisplayROMStr("Sensor Fail TimeOut",16,ROW_USER_ENTRY);
					BioSensorFail = 1;
					goto FAIL_HANDLE;

				case STATUS_BIO_SUCCESS:
					MakeSound(SOUND_KEY_PRESS);
					DISABLE_BIO_COMM();
					ReceivedCardNo = (CARDNO_DATA_STORAGE_TYPE)BioCmdData;
#ifdef SUPPORT_WEIGAND_OUT
					if(Doorinfo.CardMask == 16)
						ReceivedCardNo = ReceivedCardNo & (DWORD)0x0000FFFF;
					WCount = SysInfo.WeigandOutCont & 0x3F;  //ARMF0554
#endif
					MsgPrint(MSG_WARNING,(WORD)ReceivedCardNo,"Finger Verified with ID");
					
					ReaderNo = 1;
					CurrentUser.RdrNo = ReaderNo;			//NGD00151
					CurrentUser.SearchCard.CardNo = ReceivedCardNo;
					CurrentUser.InputType = INPUT_USER_FROM_SMART_FINGER;		
					CurrentUser.SearchCard.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;		
					
					
//					VerifyCard();
//					ReaderNo = 1;
               if(F_ChkAdminFinger == SET)//ARMD0312
               {
               	  DisplaySubMode = 1;
                  NumericValue = ReceivedPin;
                  HandleWaitForAdminCardKey(ENTER_KEY);
               }
               else	
                    { 
                       if( (Doorinfo.DuelUserAuth == 1))
                       {
                         if(F_DuelUserAuth == CLR) //ARMD0325
					     UserAccessGranted(&CurrentUser);//,BioReaderNo);
                       } else  UserAccessGranted(&CurrentUser);//,BioReaderNo)
                     
                    }
					UserBioMode = 0;
					break;
				case STATUS_BIO_NOT_FOUND:
#ifndef SUPPORT_SUPREMA
				case STATUS_BIO_IDENTIFY_FAILED:
#endif
					if(F_VerifyFingerCardID_CNVF == SET)
					{
						DISABLE_BIO_COMM();
						MakeSound(SOUND_KEY_PRESS);
						ReceivedCardNo= VerifyFingerCardID;
//						VerifyCard();
//						ReaderNo = 1;
						UserAccessGranted(&CurrentUser);//,BioReaderNo);
						UserBioMode = 0;
						MsgPrint(MSG_WARNING,(WORD)BioCmdData,"Finger NVF Type =");
					}
					else
					{
						if(UTYPE_PIN_ON_FINGER_FAIL & CurrentUser.SearchCard.Info.CType)
						{
		                     MakeSound(SOUND_KEY_PRESS);
		                     DisplaySubMode = 4;
		                     DISABLE_BIO_COMM();
		                     UserBioMode = 0;
		                     CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FAIL_FINGER_PIN;
		                     ReaderNo = BioReaderNo;
		                     AskAndVerifyPin(FUNCTION_KEY);
		                     IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
		                     F_KeyIdleTime = CLR;
		                     break;
						}
						L_DisplayROMStr("Finger Not Found",16,ROW_USER_ENTRY);
						ReceivedCardNo = (CARDNO_DATA_STORAGE_TYPE)BioCmdData;
						StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,BioReaderNo,EVENT_CARD_NOT_FOUND);
						goto FAIL_HANDLE;
					}
					break;
				case STATUS_BIO_NOT_MATCH:
					if(F_VerifyFingerCardID_CNVF == SET)
					{
						DISABLE_BIO_COMM();
						MakeSound(SOUND_KEY_PRESS);
						ReceivedCardNo= VerifyFingerCardID;
//						VerifyCard();
//						ReaderNo = 1;
						UserAccessGranted(&CurrentUser);//,BioReaderNo);
						UserBioMode = 0;
						MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)BioCmdData,"Finger NVF Type =");
					}
					else
					{
						if(UTYPE_PIN_ON_FINGER_FAIL & CurrentUser.SearchCard.Info.CType)
						{
							MakeSound(SOUND_KEY_PRESS);
							DisplaySubMode = 4;
							DISABLE_BIO_COMM();
							UserBioMode = 0;
							CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FAIL_FINGER_PIN;
							ReaderNo = BioReaderNo;
							AskAndVerifyPin(FUNCTION_KEY);
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
							F_KeyIdleTime = CLR;
							break;
						}
						if((FingerRechkCount < MAX_FINGER_RECHK_COUNT) && (Doorinfo.FingerRecheck == 1))      		//A00006
						{
//							L_DisplayROMStr("Finger Not Match   ",16,ROW_USER_ENTRY);    //FA00070
							ReceivedCardNo = (CARDNO_DATA_STORAGE_TYPE)BioCmdData;
							StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,BioReaderNo,EVENT_FINGER_RETRY);
							FingerRechkCount++;
							MakeSound(SOUND_KEY_PRESS);
							DISABLE_BIO_COMM();
							NumericValue = ReceivedCardNo;
							DisplayMode = USER_VERIFY_MODE;
							BioReaderNo = ReaderNo;
							HandleUserVerifyMode(INITIALISE_EVENT);
							NextDisplayMode = 0;
							break;
						}
						else
						{
							L_DisplayROMStr("Finger Match Fail",16,ROW_USER_ENTRY);       
							#ifdef SUPPORT_NSERIES2 
							F_DuelUserAuth = CLR;	//281210-4				//Clear Duel user Flag on finger not match DUA
							DuelUserCounter = 0;//on fail cond. start counter from begining = 0.
							#endif
							ReceivedCardNo = (CARDNO_DATA_STORAGE_TYPE)BioCmdData;
							StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,BioReaderNo,EVENT_FINGER_NOT_MATCH);
							goto FAIL_HANDLE;
						}
					}
					break;

				default:
					L_DisplayROMStr("Finger Scan Fail   ",16,ROW_USER_ENTRY);
FAIL_HANDLE:
                    #ifdef SUPPORT_NSERIES2
					F_DuelUserAuth = CLR;   //281210-4           //Clear Duel user Flag on finger not match DUA
					DuelUserCounter = 0; //ARMD0325
					#endif
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
					F_KeyIdleTime = CLR;
					FingerRechkCount = 0; 			//A00006
					DisplayMode = MODE_WAIT_FOR_CARD;
					DISABLE_BIO_COMM();
					UserBioMode = 0;
//					MakeSound(SOUND_USER_ERROR);
					MakeSound(SOUND_CARD_NOT_FOUND);
					break;
			}
			break;
	}
}

//#ifdef BIO_SMART_TEMPLATE
// This is used when we use smart card and send tenmplate from smartcard
/*** BeginHeader HandleUserHostVerify */
void HandleUserHostVerify(unsigned eventtype);
/*** EndHeader */
void HandleUserHostVerify(unsigned eventtype)
{
//	struct TEMPLATE_DATA tempdata;
 char tno,var; //,nooftemp;
//WORD tempsize;
	
//_CExtraInfo  tExtInfo;
	
	switch(eventtype)				 
	{
		case INITIALISE_EVENT:
			CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FROM_SMART_FINGER;

			if(F_BIO_COMM == SET)
			{
				CancelBioCommand();
 				F_BIO_COMM = CLR;
 			}
			F_authScreenTimerEnable = 1;
			F_authScreenTimer =11;											
			IdleKeyCounter	= CLR;	
			if (FingerRechkCount == 0)                 //A00006
				L_DisplayROMStr("Place FingerSD",16,ROW_USER_ENTRY);
			else
			{
				L_DisplayROMStr("Finger RetrySD -  ",16,ROW_USER_ENTRY);
				L_DisplayCharAtRow(15,(FingerRechkCount)+'0',ROW_USER_ENTRY);
			}
			DisplayMode = USER_VERIFY_BY_HOST_MODE;
			FingerWaitTimeOut = 0;
			NumericValue = 0;
			DisplaySubMode = 0;
			ENABLE_BIO_COMM();
			
			tno=0;
			for(var = 0;var<=7;var++)
				tno += (tExtInfo.TemplateData>>var)&0x01;					
			if((tno>MAX_TEMPLATE_SD_PERUSER)||(tno == 0))
			{
				L_DisplayROMStr("No Template in SD",16,ROW_USER_ENTRY);
				break;
			}					
			// Implemented same as smart card
//			if(GetTemplateFromSDToBuff(ReceivedCardNo,&tempsize,&nooftemp,tExtInfo.TemplateData,CurrentUser.SearchCardPtr,( char (*)[MAX_BIO_TEMPLATE_SIZE])BufferTemp[0])==0)
//			{
//				if(VerifyBioTemplateFromHost(tempsize,nooftemp,( char (*)[MAX_BIO_TEMPLATE_SIZE])BufferTemp[0])==0)
//				if(VerifyBioTemplateFromSD(MAX_TEMPLATE_SIZE,tno,tExtInfo.TemplateData,CurrentUser.SearchCardPtr)==0)	 	// NG0015

// Following code is added so we send required no of templates. rt now we read template two time.
				if(VerifyBioTemplateFromSDNew(ReceivedCardNo,MAX_TEMPLATE_SIZE,tno,tExtInfo.TemplateData,CurrentUser.SearchCardPtr)==0)	 	// NGD00039
				{										  //NG0007
#ifdef SUPPORT_SPEECHIC
					PlaySoundMsg(PLACE_FINGER);		
#endif					
					VerifyFingerCardID = ReceivedCardNo;
					DisplayCardNo = ReceivedCardNo;
					break;
				}
//			}
// indicates there is no valid template in SD card so show error..
			L_DisplayROMStr("BADTemplatein SD",16,ROW_USER_ENTRY);			//NG0007	
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
			F_KeyIdleTime = CLR;
			DisplayMode = MODE_WAIT_FOR_CARD;
			DISABLE_BIO_COMM();
			UserBioMode = 0;
			MakeSound(SOUND_CARD_NOT_FOUND);
			break;
		case BIO_EVENT:
			switch(BioCmdStatus)
			{
#ifdef SUPPORT_SUPREMA				
				case STATUS_BIO_FINGER_FOUND:
					L_DisplayROMStr("Finger Scan Over",16,ROW_USER_ENTRY);
				break;
#endif				
				case STATUS_BIO_TIME_OUT:
					L_DisplayROMStr("Finger Time Out ",16,ROW_USER_ENTRY);
					goto FAIL_HANDLE;
				case STATUS_BIO_COMM_TIME_OUT:
					L_DisplayROMStr("Sensor Fail TimeOut",16,ROW_USER_ENTRY);
					BioSensorFail = 1;
					goto FAIL_HANDLE;
				case STATUS_BIO_SUCCESS:
					MakeSound(SOUND_KEY_PRESS);
					DISABLE_BIO_COMM();
					ReceivedCardNo = VerifyFingerCardID;
#ifdef SUPPORT_WEIGAND_OUT
					if(Doorinfo.CardMask == 16)
						ReceivedCardNo = ReceivedCardNo & (DWORD)0x0000FFFF;
					WCount = SysInfo.WeigandOutCont & 0x3F;   //ARMF0554
#endif
					MsgPrint(MSG_WARNING,(WORD)ReceivedCardNo,"Finger Verified with ID");
					if(F_ChkAdminFinger == SET)
					{
						DisplaySubMode = 1;
						NumericValue = ReceivedPin;
						HandleWaitForAdminCardKey(ENTER_KEY);
					}
					else
						UserAccessGranted(&CurrentUser);//,BioReaderNo);
					UserBioMode = 0;
					break;
				case STATUS_BIO_NOT_FOUND:
#ifndef SUPPORT_SUPREMA
				case STATUS_BIO_IDENTIFY_FAILED:
#endif
					if(F_VerifyFingerCardID_CNVF == SET)
					{
						DISABLE_BIO_COMM();
						MakeSound(SOUND_KEY_PRESS);
						ReceivedCardNo = VerifyFingerCardID;
//						VerifyCard();
//						ReaderNo = 1;
						UserAccessGranted(&CurrentUser);//,BioReaderNo);
						UserBioMode = 0;
						MsgPrint(MSG_WARNING,(WORD)BioCmdData,"Finger NVF Type =");
					}
					else
					{
						if(F_ChkAdminFinger == SET)
						{
							if(UTYPE_PIN_ON_FINGER_FAIL & AdmCard.AdmData.Info.CType)
							{
								MakeSound(SOUND_KEY_PRESS);
								DisplaySubMode = 4;
								DISABLE_BIO_COMM();
								UserBioMode = 0;
								CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FAIL_FINGER_PIN;
								ReaderNo = BioReaderNo;
								AskAndVerifyPinForAdmin(FUNCTION_KEY);
								IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
								F_KeyIdleTime = CLR;
								break;
							}
						}
						else if(UTYPE_PIN_ON_FINGER_FAIL & CurrentUser.SearchCard.Info.CType)
						{
							MakeSound(SOUND_KEY_PRESS);
							DisplaySubMode = 4;
							DISABLE_BIO_COMM();
							UserBioMode = 0;
							CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FAIL_FINGER_PIN;
							ReaderNo = BioReaderNo;
							AskAndVerifyPin(FUNCTION_KEY);
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
							F_KeyIdleTime = CLR;
							break;
						}
						L_DisplayROMStr("Finger Not Found",16,ROW_USER_ENTRY);
//						ReceivedCardNo = (CARDNO_DATA_STORAGE_TYPE)BioCmdData;
						StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,BioReaderNo,EVENT_CARD_NOT_FOUND);
						goto FAIL_HANDLE;
					}
					break;
				case STATUS_BIO_NOT_MATCH:
					if(F_VerifyFingerCardID_CNVF == SET)
					{
						DISABLE_BIO_COMM();
						MakeSound(SOUND_KEY_PRESS);
						ReceivedCardNo = VerifyFingerCardID;
//						VerifyCard();
//						ReaderNo = 1;
				  		UserAccessGranted(&CurrentUser);//,BioReaderNo);
						UserBioMode = 0;
						MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)BioCmdData,"Finger NVF Type =");
					}
					else
					{
						if(F_ChkAdminFinger == SET)
						{
							if(UTYPE_PIN_ON_FINGER_FAIL & AdmCard.AdmData.Info.CType)
							{
								MakeSound(SOUND_KEY_PRESS);
								DisplaySubMode = 4;
								DISABLE_BIO_COMM();
								UserBioMode = 0;
								CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FAIL_FINGER_PIN;
								ReaderNo = BioReaderNo;
								AskAndVerifyPinForAdmin(FUNCTION_KEY);
								IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
								F_KeyIdleTime = CLR;
								break;
                     		}
						}
						else if(UTYPE_PIN_ON_FINGER_FAIL & CurrentUser.SearchCard.Info.CType)
						{
							MakeSound(SOUND_KEY_PRESS);
							DisplaySubMode = 4;
							DISABLE_BIO_COMM();
							UserBioMode = 0;
							CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_FAIL_FINGER_PIN;
							ReaderNo = BioReaderNo;
							AskAndVerifyPin(FUNCTION_KEY);
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
							F_KeyIdleTime = CLR;
							break;
						}
						if((FingerRechkCount < MAX_FINGER_RECHK_COUNT) && (Doorinfo.FingerRecheck == 1))          //A00006
						{
//							L_DisplayROMStr("Finger Not Match   ",16,ROW_USER_ENTRY);        //FA00070
							StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,BioReaderNo,EVENT_FINGER_RETRY);
							FingerRechkCount++;
							MakeSound(SOUND_KEY_PRESS);
							DISABLE_BIO_COMM();
							DisplayMode = USER_VERIFY_BY_HOST_MODE;
							BioReaderNo = ReaderNo;
							HandleUserHostVerify(INITIALISE_EVENT);
							NextDisplayMode = 0;
							break;
						}
						else
						{
						    F_DuelUserAuth = CLR;	//281210-4				//Clear Duel user Flag on finger not match DUA
							DuelUserCounter = 0; //ARMD0325
							L_DisplayROMStr("Finger Match Fail",16,ROW_USER_ENTRY);       //FA00070
							StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,BioReaderNo,EVENT_FINGER_NOT_MATCH);
							goto FAIL_HANDLE;
						}
					}
					break;

				default:
					L_DisplayROMStr("Finger Scan Fail",16,ROW_USER_ENTRY);
FAIL_HANDLE:
                    F_DuelUserAuth = CLR;   //281210-4           //Clear Duel user Flag on finger not match DUA
					DuelUserCounter = 0; //ARMD0325
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
					F_KeyIdleTime = CLR;
					FingerRechkCount = 0; 			
					DisplayMode = MODE_WAIT_FOR_CARD;
					DISABLE_BIO_COMM();
					UserBioMode  = 0;
//					MakeSound(SOUND_USER_ERROR);
					MakeSound(SOUND_CARD_NOT_FOUND);
					break;
			}
	}
}
//#endif

#endif
/*---------------------------------------------------------------------------------------*/
// void HandleMenu(BYTE keytype)
// {
// 	switch(keytype)
// 	{
// 		case FUNCTION_KEY:
// 			L_DisplayROMStr("1.INC      3.DEC",16,ROW_USER_ENTRY);
// 			DisplayCardNo = 0;
// 			break;

// 		case NUMERIC_KEY:
// 			if(CurrentKey == YES_KEY)
// 			{
// 				DisplayCardNo++;
// 				if(DisplayCardNo > MAX_DISPLAY_MODE)
// 					DisplayCardNo = 1;
// 				L_DisplayROMStr((BYTE *)DISPLAY_MODE[((WORD)DisplayCardNo)],16,ROW_USER_FUNCTION);
// 				L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_FUNCTION);
// 				if(DisplayCardNo <= 9)
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys =   *",15,ROW_USER_ENTRY);			
// 				}
// 				else if(DisplayCardNo <= 19)
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo%10),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys =  *9",15,ROW_USER_ENTRY);			
// 				}
// 				else if(DisplayCardNo <= 29)
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo%10),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys = *99",15,ROW_USER_ENTRY);			
// 				}
// 				else if(DisplayCardNo <= 39) 			
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo%10),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys =*999",15,ROW_USER_ENTRY);
// 				}
// 			}
// 			else if(CurrentKey == NO_KEY)
// 			{
// 				if(DisplayCardNo != 0)
// 					DisplayCardNo--;
// 				else
// 					DisplayCardNo = MAX_DISPLAY_MODE;
// 				if(DisplayCardNo < 1)
// 				{
// 					DisplayCardNo = MAX_DISPLAY_MODE;
// 				}
// 				L_DisplayROMStr((BYTE *)DISPLAY_MODE[((WORD)DisplayCardNo)],16,ROW_USER_FUNCTION);
// 				L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_FUNCTION);
// 				if(DisplayCardNo <= 9)
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys =   *",15,ROW_USER_ENTRY);				
// 				}
// 				else if(DisplayCardNo <= 19)
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo%10),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys =  *9",15,ROW_USER_ENTRY);				
// 				}
// 				else if(DisplayCardNo <= 29)
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo%10),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys = *99",15,ROW_USER_ENTRY);				
// 				}
// 				else if(DisplayCardNo <= 39) 			
// 				{
// 					L_DisplayCharRow(14,((WORD)DisplayCardNo%10),ROW_USER_ENTRY);
// 					L_DisplayROMStr("Menu keys =*999",15,ROW_USER_ENTRY);
// 				}
// 			}
// 			else
// 				MakeSound(SOUND_USER_ERROR);
// 			break;

// 		case ENTER_KEY:
// 			if(DisplayCardNo > 0)
// 			{
// 				DisplayMode = (WORD)DisplayCardNo;
// 				if(DisplayMode != 9)
// 					HandleAllModeEvents(FUNCTION_KEY);
// 			}
// 			break;
// 	}
// }

/*---------------------------------------------------------------------------------------*/
void HandleControllerType(BYTE keytype)
{
	struct RectInfo rectinfo;	
	switch(keytype)
	{
		case ENTER_KEY:
		case TOUCH_KEY3:	
ENTER:
			rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion <= MAX_CONTROLLER_TYPE)
				{
					DisplaySubMode = 0xFF;
					ReaderInfo[0].CntrolrType = (char)stRadioScrollData.CurrSeletion;
					ReaderInfo[1].CntrolrType = (char)stRadioScrollData.CurrSeletion;
				}
				else			   
				{
#ifdef BIO_METRIC
					ReaderInfo[0].CntrolrType = CONT_BIO_ACCESS;
					ReaderInfo[1].CntrolrType = CONT_BIO_ACCESS;
#else					
					ReaderInfo[0].CntrolrType = CONT_SMAART_ACCESS;
					ReaderInfo[1].CntrolrType = CONT_SMAART_ACCESS;
#endif
				}
				if(CHECK_ATT_NOCARD(DspRdrNo) || CHECK_ATT_CARD_ONLY(DspRdrNo) || CHECK_DENY_LIST(DspRdrNo) || CHECK_ATT_SC_NOCARD(DspRdrNo))
				{
				// indicates system is attendance type so disable DOTL alarm
					ReaderInfo[0].DOTLEn_Dis = 0;
					ReaderInfo[1].DOTLEn_Dis = 0;
					Doorinfo.APBEANABLE = 0;
				}
				else
				{  // for access we have to enable same
					ReaderInfo[0].DOTLEn_Dis = 1;
					ReaderInfo[1].DOTLEn_Dis = 1;
				}
				SysInfo.ControllerType = ReaderInfo[0].CntrolrType;
				WriteDoorInfoToFlash();
				WriteReaderInfoToFlash();
				WriteSysInfoToFlash();
				L_CenterDisplaySubStr("ONOFF/RST System",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				Delayandreturnback();
			}
			break;
		case FUNCTION_KEY:
			if(DisplaySubMode == 0)
			{
				NumericValue = ReaderInfo[0].CntrolrType;
				if(NumericValue <= MAX_CONTROLLER_TYPE)
				{
					NumericValue = ReaderInfo[0].CntrolrType;
				}
				else
				{
#ifdef BIO_METRIC
					NumericValue = CONT_BIO_ACCESS;
#else					
					NumericValue = CONT_SMAART_ACCESS;
#endif
				}
				stRadioScrollData.MaxScrollElement = MAX_CONTROLLER_TYPE+1;
				stRadioScrollData.PrevSeletion= -1;
				stRadioScrollData.CurrSeletion= NumericValue;
				stRadioScrollData.Array= (const char**)CONTR_TYPE;
				DisplayRadioScroll();
//				L_DisplayROMStrLoc((BYTE*)&CONTR_TYPE[(WORD)NumericValue],16,ROW_USER_ENTRY,0);
			}
			break;
			
		case 	TOUCH_KEY2: 
UP:
			if(stRadioScrollData.CurrSeletion > 0)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
				stRadioScrollData.CurrSeletion--;								
			}
			DisplayRadioScroll();
		break;
		case 	TOUCH_KEY4: 		
DOWN:
			if(stRadioScrollData.CurrSeletion < MAX_CONTROLLER_TYPE)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
				stRadioScrollData.CurrSeletion++;								
			}
			DisplayRadioScroll();
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse1&0xFF)],ROW_USER_ENTRY + TempUse1,1);			
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse&0xFF)],ROW_USER_ENTRY + TempUse,0);									
		break;

		case NUMERIC_KEY:
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
			break;
				
// 		case NUMERIC_KEY:
// 			NumericValue = NumericValue % 10;
// 			if(DisplaySubMode == 0)
// 			{
// #ifdef BIO_METRIC
// 	#ifndef SMART_CARD
// 				if( (NumericValue > MAX_CONTROLLER_TYPE) || \
// 				    (NumericValue == CONT_BIO_ATT_SC_NOCARD) || \
// 				    (NumericValue == CONT_BIO_2RD_ATT_SC_NOCARD))
// 	#else
// 				if( (NumericValue > MAX_CONTROLLER_TYPE)   )
// 	#endif
// #else
// 				if( (NumericValue > MAX_CONTROLLER_TYPE)   )
// #endif
// 				{
// #ifdef BIO_METRIC
// 					NumericValue = CONT_BIO_ACCESS;
// #else					
// 					NumericValue = CONT_SMAART_ACCESS;
// #endif
// 				}
// 				L_DisplayROMStrLoc((BYTE*)&CONTR_TYPE[(WORD)NumericValue],16,ROW_USER_ENTRY,0);
// 			}
// 			break;
	}
}

/*---------------------------------------------------------------------------------*/
void HandleUserDispAllPara(BYTE type)
{
	switch(type)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			NumericValue = 0;
			DisplaySysPara(DisplaySubMode);
			break;
		case NUMERIC_KEY:
			if(NumericValue >= MAX_SET_SYS_PARA)
				NumericValue = 0;
			DisplaySubMode = (BYTE)NumericValue;
			DisplaySysPara(DisplaySubMode);
			break;
			
		case TOUCH_KEY3:
		case ENTER_KEY:
			DisplaySubMode ++;
			if(DisplaySubMode > MAX_SET_SYS_PARA)
				DisplaySubMode = 0;
			DisplaySysPara(DisplaySubMode);
			break;
		case EVENT_TIME_OUT :
			UserTimeOut = 2;
			F_UserTimeOut = SET;
			DisplaySysPara(UserTimeOutEvent);
			UserTimeOutEvent ++;
			if(UserTimeOutEvent > MAX_SET_SYS_PARA)
			{
	         	UserTimeOutEvent = 0;
	            DisplayMode = MODE_WAIT_FOR_CARD;
				HandleAllModeEvents(FUNCTION_KEY);
				F_UserTimeOut = CLR;
		  		UserTimeOut = 4;
				F_KeyIdleTime = CLR;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
         	}
   			break;
   	}
}

/*---------------------------------------------------------------------------------*/
void DisplaySysPara(BYTE parano)
{
BYTE datastr[16],icnt;
//	L_DisplayROMStr("                ",16,ROW_USER_FUNCTION);
	strncpy((char *)datastr,(char *)SetSysPara[parano].ParaName,16);
	L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	memset(datastr,' ',sizeof(datastr));
	switch(SetSysPara[parano].Type)
	{
		case D_CHAR:
         	itoa(*SetSysPara[parano].VChar,(char *)datastr);
			//L_DisplayROMStr(datastr,16,ROW_USER_ENTRY);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_BIN:
       		if(*SetSysPara[parano].VChar == 0)
				L_CenterDisplaySubStr("No   ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			else
				L_CenterDisplaySubStr("Yes  ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
		case D_INT:
			itoa(*SetSysPara[parano].VInt,(char *)datastr);
			sprintf((char *)datastr,"%0u",*SetSysPara[parano].VInt);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_LONG:
     		LongToStr(datastr,*SetSysPara[parano].VLong,1);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_STR:
			strncpy((char *)datastr,(char *)SetSysPara[parano].VStr,16);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			break;
      case D_ARRAY_CHAR:
         memset(datastr,' ',sizeof(datastr));
         for(icnt=0;icnt<SetSysPara[parano].Len;icnt++)
         {
            if(((icnt*3)+3) >= 16)
               break;
            sprintf((char *)&datastr[icnt*3],"%02x ",SetSysPara[parano].VStr[icnt]);
         }
         L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
         break;	  
	}
}

/*---------------------------------------------------------------------------------------*/
void DeleteData(BYTE keytype,BYTE deletedata)
{
	switch(keytype)
	{
		case FUNCTION_KEY:
				DisplayBottomStatusIcon(0,"  ",0,0);			
				strcpy((char*)DisplayTempBuffer,"Yes         No");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				CurrentKey = YES_KEY;
				DisplaySubMode = 0;
			break;
		
		case 	NUMERIC_KEY:
		case 	TOUCH_KEY2:   // left shift   select YES
		case 	TOUCH_KEY4:   // Right shift Select NO
			if(DisplaySubMode == 0)
			{
				 if(keytype == TOUCH_KEY2)
    				 CurrentKey = YES_KEY;
				 if(keytype == TOUCH_KEY4)
					CurrentKey = NO_KEY;
				 
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else if(CurrentKey == NO_KEY)
				{	
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else
				{
					CurrentKey = YES_KEY;
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
			 }
			break;
		case TOUCH_KEY3:
		case ENTER_KEY:
			DisplaySubMode = 1;
				if(CurrentKey == YES_KEY)
				{
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr("Deleting data...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					InitialiseDefaultSelect((WORD)deletedata);
					L_CenterDisplaySubStr("Data Deleted",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					Delayandreturnback();
				}
				else if(CurrentKey == NO_KEY)
				{
					KeyBuff[KeyWritePtr++] = 0x14;
					if(KeyWritePtr >= 4)
						KeyWritePtr = 0;

				}			
			break;
	}
}
void HandleDelAllData(BYTE keytype)	
{		
		L_CenterDisplaySubStr("Del All Data",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_DATA);
}
void HandleDelTransaction(BYTE keytype)	
{
		L_CenterDisplaySubStr("Del Transaction",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DEL_TRANSACTION);
}
void HandleDelAllUsers(BYTE keytype)		
{
		L_CenterDisplaySubStr("Del All Users",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_USER);
}
void HandleSetAllDefault(BYTE keytype)	
{
		L_CenterDisplaySubStr("Set All Default",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_DEFAULT);
}
void HandleDelSysInfo(BYTE keytype)		
{
		L_CenterDisplaySubStr("Delete SysInfo",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_SYSINFO);
}
void HandleDelTimeZone(BYTE keytype)		
{
		L_CenterDisplaySubStr("Del  TimeZone",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_TIMEZONE);
}
void HandleDelHoliday(BYTE keytype)		
{
		L_CenterDisplaySubStr("Del Holiday",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_HOLIDAY);
}
void HandleDelFacilityCode(BYTE keytype)	
{
		L_CenterDisplaySubStr("Del FacilityCode",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_FACILITY_CODE);
}
void HandleDelDoorInfo(BYTE keytype)		
{
		L_CenterDisplaySubStr("Del Door info",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_DOORINFO);
}
void HandleDelAdminIDs(BYTE keytype)		
{
		L_CenterDisplaySubStr("Del Admin IDs",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_ADMIN_ID);
}
void HandleResetSystem(BYTE keytype)		
{
		L_CenterDisplaySubStr("Reset System",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//		DeleteData(keytype,RESET_SSYSTEM);
	switch(keytype)
	{
		case FUNCTION_KEY:
			strcpy((char*)DisplayTempBuffer,"Yes         No");
			StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
			Xdigts = 3;
			PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
			DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
			CurrentKey = YES_KEY;
			DisplaySubMode = 0;
		break;
		
		case 	NUMERIC_KEY:
		case 	TOUCH_KEY2:   // left shift   select YES
		case 	TOUCH_KEY4:   // Right shift Select NO
			if(DisplaySubMode == 0)
			{
				if(keytype == TOUCH_KEY2)
					CurrentKey = YES_KEY;
				else if(keytype == TOUCH_KEY4)
					CurrentKey = NO_KEY;
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else if(CurrentKey == NO_KEY)
				{	
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
			 }
			break;
			 
	 		case TOUCH_KEY3:
			case ENTER_KEY:
				if(F_FirmwareUpgrade == 0x00)
					StoreCardInTrDBFull(10,0x01,EVENT_SYSTEM_INI,0,0);
				#ifdef ENABLE_WATCHDOG
				   if(F_FirmwareUpgrade == 0x01)
				   L_DisplayROMStr("BOOTING NEW F/W ",16,ROW_USER_ENTRY);
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr("BOOTING NEW F/W ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				   WDTInit(1); //watchdog initialization for secs
				   while(1) ;
				#else
				   L_DisplayROMStr(" RESTART FAIL   ",16,ROW_USER_ENTRY);
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr("RESTART FAIL",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				   Delayandreturnback();
				#endif
			 break;
		 }

}
void HandleDelCardsOnly(BYTE keytype)		
{
		L_CenterDisplaySubStr("Del Cards Only",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_CARD_ONLY);
}
#ifdef BIO_METRIC
	void HandleDelAllFingers(BYTE keytype)	
	{
		L_CenterDisplaySubStr("Del All Fingers",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		DeleteData(keytype,DELALL_FINGERS);
	}
#endif

#ifdef BIO_METRIC
/*---------------------------------------------------------------------------------*/
void HandleBioUserEvents(void)
{
//	struct RectInfo rectinfo;	
	switch(DisplayMode)
	{
		case USER_IDENTIFY_MODE:
			HandleUserIdentifyMode(BIO_EVENT);
			return;
		case USER_VERIFY_MODE:
			HandleUserVerifyMode(BIO_EVENT);
			return;
//#ifdef BIO_SMART_TEMPLATE
		case USER_VERIFY_BY_HOST_MODE:			
			HandleUserHostVerify(BIO_EVENT);
			return;
//#endif
	}
	switch(UserBioMode)
	{
		case BIO_GET_ENROLLED_FINGER_ID:
			switch(BioCmdStatus)
			{
#ifdef SUPPORT_SUPREMA
				case STATUS_BIO_FINGER_FOUND:
					if(BIO_SINGLE_ENROLL == SysInfo.BioEnrollType)
					{
						UserTempData = 1;
					}
					if(UserTempData == 0)
					{
//						L_DisplayROMStr("Put Finger Again",16,ROW_USER_ENTRY);
							L_CenterDisplaySubStr("Put Finger Again",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					}
					break;
#endif
				case STATUS_BIO_EXIST_FINGER:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("Finger Exist",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
				case STATUS_BIO_TIME_OUT:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("Finger Timeout",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
				case STATUS_BIO_COMM_TIME_OUT:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("Sensor Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
#ifdef SUPPORT_SUPREMA
				case STATUS_BIO_SCAN_FAIL:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("Scan Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
				case STATUS_BIO_MEMORY_FULL:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("Memory Full",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
				case STATUS_BIO_FINGER_LIMIT:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("MaxFinger For ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
				case STATUS_BIO_INVALID_ID:
//				L_CenterDisplayROMStrFont(" ",ROW_USER_ENTRY2,USER_BOLD_NORMAL_FONTINFO_PTR);		
					L_CenterDisplaySubStr("Invalid user ID ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					break;
#endif
				case STATUS_BIO_SUCCESS:
#ifdef DISP_ENROLL_SCORE
	            	Enroll_Score = (unsigned char)BioCmdSize & 0xff;				//A00007
#endif
#ifdef SUPPORT_SUPREMA
					if(BIO_SINGLE_ENROLL == SysInfo.BioEnrollType)
//#endif
					{
						UserTempData = 1;
					}
#endif					
					if(UserTempData == 0)   
					{
						UserTempData = 1;
						L_CenterDisplaySubStr("Put Finger Again",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//						MakeSound(SOUND_KEY_PRESS);
#ifdef SUPPORT_SPEECHIC				
						PlaySoundMsg(PLACE_FINGER);
						waitX10ms(100);	
#endif						
					}
					else
					{
#ifdef DISP_ENROLL_SCORE
//						DisplayMode = MODE_ADD_CARD;
//						L_DisplayROMStr("Score:    %     ",16,ROW_USER_FUNCTION);       
//					  	L_DisplayDecimalByte(Enroll_Score,7,ROW_USER_FUNCTION);			 
#endif
//						L_DisplayROMStr("Finger Added    ",16,ROW_USER_ENTRY);
				
					L_CenterDisplaySubStr("Finger Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2)
					{
						Enroll_Score = BioCmdData;
						UserFingerNo =0;									 
					}		
					sprintf((char*)DisplayTempBuffer,"Score:%3d%% ",Enroll_Score);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
						if(MODE_ADD_FINGER_TO_ID == DisplayMode)
						{
							MsgPrint(MSG_WARNING,DisplayCardNo,"Finger Added to ID =");
							Delayandreturnback();
						}
						else if(MODE_ADD_CARD == DisplayMode)
						{
							DisplaySubMode = ENTER_ADD_CARD_CONTROLLER;
							HandleEnterAddCardKey();
							MakeSound(SOUND_KEY_PRESS);
							MsgPrint(MSG_WARNING,DisplayCardNo,"Added Finger and New Card =");
						}
					}
					break;
#ifdef SUPPORT_SUPREMA
				case STATUS_BIO_TRY_AGAIN:
					L_CenterDisplaySubStr("Add Finger Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					Delayandreturnback();
					break;
#endif
				default:
/*				if(MODE_ADD_FINGER_TO_ID == DisplayMode)
            		L_DisplayROMStr("No Finger Space   ",16,ROW_USER_ENTRY);
				else*/
					L_CenterDisplaySubStr("Add Finger Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DISABLE_BIO_COMM();
					UserBioMode = 0;
					DisplaySubMode = 0;
					MakeSound(SOUND_USER_ERROR);
					Delayandreturnback();
					break;
			}
			break;
	}
}

/*---------------------------------------------------------------------------------------*/
void HandleAddFingerToId(BYTE keytype)
{  
int cardptr;
//_CExtraInfo  tExtInfo;	
struct SD_TEMPLATE_DATA SDtemplateinfo;	
	char err,temp;
unsigned char disptempbuffer[25];	
	
	DisplayMode = MODE_ADD_FINGER_TO_ID;
	switch(keytype)
	{
		case WEIGAND_DATA:
			if(DisplaySubMode == 0)
			{
				NumericValue = ReceivedCardNo;
				L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_BlankDisplay(ROW_USER_ENTRY);
				DisplayCardNo = NumericValue;
				CardPositionCount = 1;
				NumericKeyCount = 0;
				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			}
			break;
		case FUNCTION_KEY:
			DisplaySubMode = 0;
				L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				if(Doorinfo.CardDigit == 8)
					PositionCursorOnRowNo(9,ROW_USER_ENTRY);
				CardPositionCount = 1;
				NumericKeyCount = 0;
				DisplayCardNo = NumericValue;
		break;
	
		case NUMERIC_KEY:
		case 	TOUCH_KEY2:   // left shift   select YES
		case 	TOUCH_KEY4:   // Right shift Select NO
			if(keytype == TOUCH_KEY2)
				CurrentKey = YES_KEY;
			else if(keytype == TOUCH_KEY4)
				CurrentKey = NO_KEY;
			//			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
				CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
			}
			else if(DisplaySubMode == SMODE_CHECK_ADD_FINGER_TO_ID)
			{
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

				}
				else if(CurrentKey == NO_KEY)
				{	
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);

				}
				else
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
			}
			break;

		case ENTER_KEY:
		case TOUCH_KEY3:	
//			HandleAddFingerIDEntOK();
			if(DisplaySubMode == 0)
			{
//				DisplayCardNo = NumericValue;
ADDFINGERTOID:
				Carddata.CardNo = DisplayCardNo;
				L_CenterDisplaySubStr("Searching UserID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				MsgPrint(MSG_WARNING,DisplayCardNo,"search CardData");
				cardptr = SearchDisplayCard(DisplayCardNo,&Carddata);
				if(cardptr != CARD_NOT_FOUND) 
				{
					ENABLE_BIO_COMM();
					ReadCardTemplateInfoFromFlash(cardptr,&tExtInfo);// check whether card template is in SD or saensor 
					UserFingerNo = 0;
				if(((tExtInfo.Image_TemplateSD_Flag & 0x0F)) == 1)	
				{	
					GetBalanceTemplate();	// NGD0022
					if(BalTemplates < TEMPLATE_OFFSET)
					{
						L_CenterDisplaySubStr("Sensor Mem Full",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);						
						L_CenterDisplaySubStr("Del& Add in SD",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						DisplaySubMode = 0;
						NumericValue = 0;
						break;
					}					

#ifdef SUPPORT_SUPREMA
					if(CheckBioUserID(DisplayCardNo) != 0)  
#else
					if(CheckBioUserID(DisplayCardNo) == 0)
#endif
					{
						// indciates that this user is not there in biometric reader
						DISABLE_BIO_COMM();
						L_CenterDisplaySubStr("Put Finger:01",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
						sprintf((char*)disptempbuffer,"UID:%s",DisplayTempBuffer);
						L_CenterDisplaySubStr(disptempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);						
						MsgPrint(MSG_WARNING,DisplayCardNo,"User not in BioReader");
					}
					else
					{						
						UserFingerNo = (BYTE)BioCmdSize & 0x0f;
#ifdef SUPPORT_SUPREMA
						if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
						{
							if(UserFingerNo == 1)
								UserFingerNo = 1;
							else
								UserFingerNo = (UserFingerNo & 0xFF) / 2;
						}
						else
#endif
						UserFingerNo = UserFingerNo & 0xFF;
					}	
				}
				else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2)
				{ 
					// show next  finger tExtInfo.TemplateData next bit towards msb logic 1 
					if(tExtInfo.TemplateData == 0x01)    // 0x01 
					{	
						UserFingerNo = 0x02;
						tExtInfo.TemplateData = tExtInfo.TemplateData | SECOND_TEMPLATE;						 
					}
					else if(tExtInfo.TemplateData == 0x03)
					{	
						UserFingerNo = 0x03;
						tExtInfo.TemplateData = tExtInfo.TemplateData | THIRD_TEMPLATE;						
					}
					else if(tExtInfo.TemplateData == 0x07) // 3rd template
					{	
						UserFingerNo = 0x04;
						tExtInfo.TemplateData = tExtInfo.TemplateData | FOURTH_TEMPLATE;						
					}
					else if(tExtInfo.TemplateData == 0x0F)// 4 template
					{	
						UserFingerNo = 0x05;
						tExtInfo.TemplateData = tExtInfo.TemplateData | FIFTH_TEMPLATE;						
					}
					else if(tExtInfo.TemplateData == 0x1F)// 5 template
					{	
						UserFingerNo = 0x06;
						tExtInfo.TemplateData = tExtInfo.TemplateData | SIXTH_TEMPLATE;						
					}
					else if(tExtInfo.TemplateData == 0x3F)// 6 template
					{	
						UserFingerNo = 0x07;
						tExtInfo.TemplateData = tExtInfo.TemplateData | SEVENTH_TEMPLATE;						
					}
					else if(tExtInfo.TemplateData == 0x7F)// 7 template
					{	
						UserFingerNo = 0x08;
						tExtInfo.TemplateData = tExtInfo.TemplateData | EIGHTH_TEMPLATE;						
					}
					else if(tExtInfo.TemplateData == 0xFF)// 8 template
					{	
						UserFingerNo = 0x09;
						tExtInfo.TemplateData = tExtInfo.TemplateData | EIGHTH_TEMPLATE;						
					}	
					else	
					{}						
//					tExtInfo.TemplateData = tExtInfo.TemplateData | UserFingerNo;						
					UserFingerNo = UserFingerNo - 1;
				}
				
				DISABLE_BIO_COMM();
				 temp = UserFingerNo;
				if((BIO_SINGLE_ENROLL != SysInfo.BioEnrollType) &&(tExtInfo.Image_TemplateSD_Flag == 1))	//NGD00157  NGD00138					
					temp = 	UserFingerNo*2;

				if(temp < MAX_FINGERS)
				{
					if((BIO_SINGLE_ENROLL != SysInfo.BioEnrollType) &&(tExtInfo.Image_TemplateSD_Flag == 1))	//NGD00157  NGD00138					
						UserFingerNo = 	temp/2;
#ifdef SUPPORT_SPEECHIC				
					PlaySoundMsg(PLACE_FINGER);
//					waitX10ms(100);	
#endif		
					sprintf((char*)DisplayTempBuffer,"Put Finger:%02d",UserFingerNo+1);							
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
					sprintf((char*)disptempbuffer,"UID:%s",(unsigned char*)DisplayTempBuffer);
					L_CenterDisplaySubStr(disptempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);						
//							L_DisplayCharRow(14,UserFingerNo+1,ROW_USER_ENTRY);
					MsgPrint(MSG_WARNING,(WORD)UserFingerNo,"Add new finger to Old ID OTF=");
				}
				else
				{
					L_CenterDisplaySubStr("No Finger Space",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					sprintf((char*)DisplayTempBuffer,"Total Finger:%02u",UserFingerNo);							
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//							L_DisplayCharRow(14,UserFingerNo,ROW_USER_ENTRY);
					MakeSound(SOUND_USER_ERROR);
					Delayandreturnback();
					DisplaySubMode = 0;
					return;
				}
				
				MakeSound(SOUND_KEY_PRESS);
				DisplaySubMode = 1;
				if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 1)							
				{
					ENABLE_BIO_COMM();
					UserBioMode = BIO_GET_ENROLLED_FINGER_ID;
					EnrollNewFingerID(DisplayCardNo,0x84);
				}	
				else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2)
				{
					err = ScanBioTemplate((BYTE*)&SDtemplateinfo.TData);
					if(err == 1)
						return;
					if(err == 0)
					{
						SDtemplateinfo.TSZ= BioCmdSize;		 //NG0019
						SDtemplateinfo.CardNo= Carddata.CardNo;
						err = AddTemplateToSD(SDtemplateinfo,cardptr,UserFingerNo+1);		//NGD00028
					}
					if(err==0)
					{
						L_CenterDisplaySubStr("SD Write Fail!",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);			
						DisplaySubMode = 0;						
						NumericValue=0;
						Delayandreturnback();
						break;
					}
					else
					{
						err = AddCardExtraData(cardptr,&tExtInfo);
					}
						Enroll_Score = BioCmdData;
						L_CenterDisplaySubStr("Finger Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						sprintf((char*)DisplayTempBuffer,"Score:%3d%%",Enroll_Score);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);	
						Delayandreturnback();
				 }
				UserTempData = 0;
				FingerWaitTimeOut = 0;
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"Card not found ptr=");
					L_CenterDisplaySubStr("User Search Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					Delayandreturnback();
					MakeSound(SOUND_USER_ERROR);
					DisplaySubMode = 0;
				}
			}
/*			else if(DisplaySubMode == 1)
			{
	
			}  */
			else if(DisplaySubMode == SMODE_CHECK_ADD_FINGER_TO_ID)
			{
//				NumericValue = NumericValue % 10;
				if(CurrentKey == YES_KEY)			// A00025 We have create CurrentKey variable to store current key so use same instead of NumericValue
				{
					// Add more finger to Same ID
					DisplaySubMode = 0;
					goto ADDFINGERTOID;
				}
				else if(CurrentKey == NO_KEY)
				{
					KeyBuff[KeyWritePtr++] = 0x14;
					if(KeyWritePtr >= 4)
						KeyWritePtr = 0;
//					DisplayMode = FUNCTION_READ_MODE;
				}
			}
			break;			
	}
}

/*---------------------------------------------------------------------------------------*/
void HandleAddFingerIDEntOK(void)
{
int cardptr;
	if(DisplaySubMode == 0)
	{
		DisplayCardNo = NumericValue;
ADDFINGERTOID:
		Carddata.CardNo = DisplayCardNo;
		L_DisplayROMStr("Searching UserID",16,ROW_USER_ENTRY);
		MsgPrint(MSG_WARNING,DisplayCardNo,"search CardData");
		cardptr = SearchDisplayCard(DisplayCardNo,&Carddata);
		if(cardptr != CARD_NOT_FOUND)
		{
			UserFingerNo = 0;
			ENABLE_BIO_COMM();
#ifdef SUPPORT_SUPREMA
			if(CheckBioUserID(DisplayCardNo) != 0)
#else
			if(CheckBioUserID(DisplayCardNo) == 0)
#endif
			{// indciates that this user is not there in biometric reader
				DISABLE_BIO_COMM();
				L_DisplayROMStr("PutNewFinger: 1 ",16,ROW_USER_ENTRY);
				MsgPrint(MSG_WARNING,DisplayCardNo,"User not in BioReader");
			}
			else
			{
				UserFingerNo = (BYTE)BioCmdSize & 0x0f;
#ifdef SUPPORT_SUPREMA
				if(BIO_SINGLE_ENROLL != SysInfo.BioEnrollType)
				{
					if(UserFingerNo == 1)
						UserFingerNo = 1;
					else
						UserFingerNo = (UserFingerNo & 0xFF) / 2;
				}
				else
#endif
					UserFingerNo = UserFingerNo & 0xFF;
				DISABLE_BIO_COMM();
				if(UserFingerNo < MAX_FINGERS)
				{
					L_DisplayROMStr("PutNewFinger:   ",16,ROW_USER_ENTRY);
#ifdef SUPPORT_SPEECHIC				
						PlaySoundMsg(PLACE_FINGER);
						waitX10ms(100);	
#endif		
					L_DisplayCharRow(14,(BioCmdSize&0x0f)+1,ROW_USER_ENTRY);
					MsgPrint(MSG_WARNING,BioCmdSize,"Add new finger to Old ID OTF=");
				}
				else
				{
					L_DisplayROMStr("No Finger Space:",16,ROW_USER_FUNCTION);
					L_DisplayROMStr("Total Finger:   ",16,ROW_USER_ENTRY);
					L_DisplayCharRow(14,UserFingerNo,ROW_USER_ENTRY);
					MakeSound(SOUND_USER_ERROR);
					DisplaySubMode = 0;
					return;
				}
			}
			MakeSound(SOUND_KEY_PRESS);
			DisplaySubMode = 1;
			ENABLE_BIO_COMM();
			UserBioMode = BIO_GET_ENROLLED_FINGER_ID;
			EnrollNewFingerID(DisplayCardNo,0x84);
			FingerWaitTimeOut = 0;
			UserTempData = 0;
		}
		else
		{
			MsgPrint(MSG_WARNING,cardptr,"Card not found ptr=");
			L_DisplayROMStr("User Search Fail",16,ROW_USER_ENTRY);
			MakeSound(SOUND_USER_ERROR);
			DisplaySubMode = 0;
		}
	}
/*	else if(DisplaySubMode == 1)
	{

	}*/
	else if(DisplaySubMode == SMODE_CHECK_ADD_FINGER_TO_ID)
	{
		NumericValue = NumericValue % 10;
		if(NumericValue == YES_KEY)
		{
			// Add more finger to Same ID
			DisplaySubMode = 0;
			goto ADDFINGERTOID;
		}
		else if(NumericValue == NO_KEY)
		{
			// Come out do not add finger go to Card Add mode
			MsgPrint(MSG_WARNING,DisplayCardNo,"No Press go to function mode ...");
			L_DisplayROMStr("Come out of ADD ",16,ROW_USER_FUNCTION);
			DisplayMode = FUNCTION_READ_MODE;
			HandleAllModeEvents(FUNCTION_KEY);
//			DisplayModeData(DisplayMode);
		}
	}
}

/*---------------------------------------------------------------------------------------*/
#endif	//#ifdef BIO_METRIC
void HandleIdentifyMode(BYTE keytype)
{
struct RectInfo rectinfo;
//char temp;
	switch(keytype)
	{
		case 	TOUCH_KEY3: 
		case ENTER_KEY:
ENTER:
			rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);

			SysInfo.IdentifyMode = (BYTE)(stRadioScrollData.CurrSeletion & 0x000000FF);
			if(SysInfo.IdentifyMode == 3)
				SysInfo.IdentifyMode = BIO_POLL_TYPE_FINGER_SENSE;  //  XYZ:
	        WriteSysInfoToFlash();
		
			L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			DisplaySubMode = 1;
		Delayandreturnback();
			break;
		case FUNCTION_KEY:
			// 0 = Normal Mode
			// 1 = # Key to identify
			// 2 = Poll mode
			if(SysInfo.IdentifyMode > MAX_POLL_TYPES)
				SysInfo.IdentifyMode = 0;
			stRadioScrollData.MaxScrollElement = MAX_POLL_TYPES;
			stRadioScrollData.PrevSeletion= -1;
			if(SysInfo.IdentifyMode == 4)
				stRadioScrollData.CurrSeletion= SysInfo.IdentifyMode-1;//  SysInfo.IdentifyMode-1 beacuse it is 0 to 3  goto XYZ
			else
				stRadioScrollData.CurrSeletion= SysInfo.IdentifyMode; 
			stRadioScrollData.Array= (const char**)POLL_TYPES;
			
			DisplayRadioScroll();
			DisplaySubMode = 0;
			break;
			
		case 	TOUCH_KEY2: 
UP:
		if(DisplaySubMode == 0)
		{
			if(stRadioScrollData.CurrSeletion > 0)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
				stRadioScrollData.CurrSeletion--;								
			}
			DisplayRadioScroll();
		}
		break;
		case 	TOUCH_KEY4: 		
DOWN:
		if(DisplaySubMode == 0)
		{
			if(stRadioScrollData.CurrSeletion < MAX_POLL_TYPES-1)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
				stRadioScrollData.CurrSeletion++;								
			}
			DisplayRadioScroll();
		}
		break;
		case NUMERIC_KEY:
		if(DisplaySubMode == 0)
		{
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
		}
		break;		
// 						DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(NumericValue&0xFF)],ROW_USER_ENTRY + NumericValue,1);			
// 						DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse&0xFF)],ROW_USER_ENTRY + TempUse,0);									
// 			break;
	}
}
#ifdef BIO_METRIC
/*---------------------------------------------------------------------------------------*/
void HandleSecurityLevelMode(BYTE keytype)
{
struct RectInfo rectinfo;
BYTE seclevel,i;
	switch(keytype)
	{
		case FUNCTION_KEY:
			DisplaySubMode = 0;
			ENABLE_BIO_COMM();
			if(ReadBioSystemParameter(BIO_SYS_REG_SEC_LEVEL) == 0)
			{
				NumericValue = 0xFF;
				seclevel = (BYTE)BioCmdSize;
				for(i=0;i<MAX_SEC_LEVEL;i++)
				{
					if(SEC_LEVEL_VAL[i] == seclevel)
					{
						NumericValue = i;
						break;
					}
				}
				if(NumericValue == 0xFF)
				{
					NumericValue = 0;
				}
				stRadioScrollData.MaxScrollElement = MAX_SEC_LEVEL;
				stRadioScrollData.PrevSeletion= -1;
				stRadioScrollData.CurrSeletion= NumericValue;
				stRadioScrollData.Array= (const char**)SEC_LEVEL_STR;
				DisplayRadioScroll();
				DisplaySubMode = 0;
			}
			else
			{
				L_CenterDisplaySubStr("Sensor Fail...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				BioSensorFail = 1;
				MakeSound(SOUND_USER_ERROR);
			}
			DISABLE_BIO_COMM();
			break;

		case 	TOUCH_KEY2: 
UP:
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion > 0)
				{	
					stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
					stRadioScrollData.CurrSeletion--;								
				}
				DisplayRadioScroll();
			}
		break;
		case 	TOUCH_KEY4: 		
DOWN:
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion < MAX_SEC_LEVEL-1)
				{	
					stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
					stRadioScrollData.CurrSeletion++;								
				}
				DisplayRadioScroll();
		    }
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse1&0xFF)],ROW_USER_ENTRY + TempUse1,1);			
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse&0xFF)],ROW_USER_ENTRY + TempUse,0);									
		break;

		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
			}
			break;

		case 	TOUCH_KEY3: 
		case ENTER_KEY:
ENTER:
			
			rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
		
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion < MAX_SEC_LEVEL)
				{
					ENABLE_BIO_COMM();
					DisplaySubMode =1;
					if(WriteSystemParameter(BIO_SYS_REG_SEC_LEVEL,(WORD)SEC_LEVEL_VAL[(BYTE)stRadioScrollData.CurrSeletion]) == 0)
					{
						if(	SaveBioSystemParameter() == 0)
						{
							L_CenterDisplaySubStr("SecLevel Updated",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							DisplaySubMode = 0xFF;
						}
						else
						{
							L_CenterDisplaySubStr("Save Fail...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
							MakeSound(SOUND_USER_ERROR);
						}
					}
					else
					{
						L_CenterDisplaySubStr("Write Fail...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						MakeSound(SOUND_USER_ERROR);
					}
					DISABLE_BIO_COMM();
				}
				else
				{
					L_CenterDisplaySubStr("Error High Value",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
				}
			}
			Delayandreturnback();
			break;
	}
}

#endif

/*** BeginHeader HandleCardDigit */
void HandleCardDigit(BYTE keytype);
/*** EndHeader */
void HandleCardDigit(BYTE keytype)
{
	struct RectInfo rectinfo;	
	switch(keytype)
	{
		case FUNCTION_KEY:
			if(Doorinfo.CardDigit == 5)
			{
				stRadioScrollData.CurrSeletion = 0;
			}
			else if(Doorinfo.CardDigit == 8)
			{
					stRadioScrollData.CurrSeletion = 01;
			}
			 else
			{
					stRadioScrollData.CurrSeletion = 02;
			}			
				stRadioScrollData.MaxScrollElement = MAX_CARD_DIGIT;
				stRadioScrollData.PrevSeletion= -1;
//				stRadioScrollData.CurrSeletion= Doorinfo.CardDigit;
				stRadioScrollData.Array= (const char**)CARD_DIGIT;
				DisplayRadioScroll();
				DisplaySubMode = 0;

			break;

		case 	TOUCH_KEY2: 
UP:
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion > 0)
				{	
					stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
					stRadioScrollData.CurrSeletion--;								
				}
				DisplayRadioScroll();
			}
		break;
		case 	TOUCH_KEY4: 		
DOWN:
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion < MAX_CARD_DIGIT-1)
				{	
					stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
					stRadioScrollData.CurrSeletion++;								
				}
			}
			DisplayRadioScroll();
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse1&0xFF)],ROW_USER_ENTRY + TempUse1,1);			
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse&0xFF)],ROW_USER_ENTRY + TempUse,0);									
		break;

		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
			}
			break;

// 		case NUMERIC_KEY:
// 			if(CurrentKey == 5)
//       			DisplayCardNo = 5;
// 			else if(CurrentKey == 8)
// 				DisplayCardNo = 8;
// 			else
// 				DisplayCardNo = 10;

// 			if(DisplayCardNo == 5)
// 				L_DisplayROMStr("5 Digit Card    ",16,ROW_USER_ENTRY);
// 			else if(DisplayCardNo == 8)
// 				L_DisplayROMStr("8 Digit Card    ",16,ROW_USER_ENTRY);
// 			else
// 				L_DisplayROMStr("10 Digit Card   ",16,ROW_USER_ENTRY);
// 			break;

		case ENTER_KEY:
		case TOUCH_KEY3:	
ENTER:

				rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
			DisplaySubMode = 1;

			if(stRadioScrollData.CurrSeletion == 0)
			{
	         	Doorinfo.CardDigit = 5;
		   		Doorinfo.CardMask = 16;
	        }
			else if(stRadioScrollData.CurrSeletion == 1)
	        {
	         	Doorinfo.CardDigit = 8;
	            Doorinfo.CardMask = 24;
	        }
	         else
					{
	         	Doorinfo.CardDigit = 10;
	            Doorinfo.CardMask = 32;
	        }
			WriteDoorInfoToFlash();
	   		if(stRadioScrollData.CurrSeletion  == 0)
				L_CenterDisplaySubStr("5 Digit Saved ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	   		else if(stRadioScrollData.CurrSeletion  == 1)
				L_CenterDisplaySubStr("8 Digit Saved",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			else
	      		L_CenterDisplaySubStr("10 Digit Saved",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			
			Delayandreturnback();
			break;
	}
}

/*** BeginHeader HandleControllerNo */
void HandleControllerNo(BYTE keytype);
/*** EndHeader */
void HandleControllerNo(BYTE keytype)
{
	switch(keytype)
	{
		case ENTER_KEY:
			Doorinfo.ControllerNo = (WORD)NumericValue;
			WriteDoorInfoToFlash();
			L_CenterDisplaySubStr("Saved",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			Delayandreturnback();
			break;
		case FUNCTION_KEY:
			L_CenterDisplaySubStr("Controller No:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			NumericValue = Doorinfo.ControllerNo;
//			L_CenterDisplaySubStr("No:             ",16,ROW_USER_ENTRY);
//			sprintf((char*)DisplayTempBuffer,"%05d",NumericValue);
			WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//			L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			DisplaySubMode = 0;
			break;
		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(NumericValue >= MAX_CONTROLLER_NO)
				{
					NumericValue = 0;
//					L_DisplayROMStr("No:             ",16,ROW_USER_ENTRY);
//					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
				}
// 				else
// 				{
// 					L_DisplayROMStr("No:             ",16,ROW_USER_ENTRY);
// 					L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
// 				}
					WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
//					sprintf((char*)DisplayTempBuffer,"%05d",NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);

			}
			break;
	}
}

/*** BeginHeader HandleUserDispUsefulPara */    //F0018 Add New service menu to display useful system parameters
void HandleUserDispUsefulPara(BYTE type);
/*** EndHeader */
void HandleUserDispUsefulPara(BYTE type)
{
	switch(type)
	{
		case FUNCTION_KEY:
			MaxValues();
			DisplaySubMode = 0;
			NumericValue = 0;
			DisplayUsefulPara(DisplaySubMode);
			break;
		case NUMERIC_KEY:
			if(NumericValue >= MAX_USEFUL_PARA)
				NumericValue = 0;
			DisplaySubMode = (BYTE)NumericValue;
			DisplayUsefulPara(DisplaySubMode);
			break;
		case ENTER_KEY:
		case TOUCH_KEY3:

			DisplaySubMode ++;
			if(DisplaySubMode > MAX_USEFUL_PARA)
				DisplaySubMode = 0;
			DisplayUsefulPara(DisplaySubMode);
			break;
		case EVENT_TIME_OUT:
			UserTimeOut = 2;
			F_UserTimeOut = SET;
			DisplayUsefulPara(UserTimeOutEvent);
			UserTimeOutEvent ++;
			if(UserTimeOutEvent > MAX_USEFUL_PARA)
			{
				UserTimeOutEvent = 0;
				DisplayMode = MODE_WAIT_FOR_CARD;
				HandleAllModeEvents(FUNCTION_KEY);
				F_UserTimeOut = CLR;
				UserTimeOut = 4;
				F_KeyIdleTime = CLR;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
			}
			break;
   	}
}

/*** BeginHeader DisplayUsefulPara */          //F0018 Add New service menu to display useful system parameters
void DisplayUsefulPara(BYTE parano);
/*** EndHeader */
void DisplayUsefulPara(BYTE parano)
{
BYTE datastr[16],icnt;
	strncpy((char *)datastr,(char *)Usefulpara[parano].ParaName,16);
	L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	memset(datastr,' ',sizeof(datastr));
	switch(Usefulpara[parano].Type)
	{
		case D_CHAR:
			itoa(*Usefulpara[parano].VChar,(char *)datastr);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_BIN:
			if(*Usefulpara[parano].VChar == 0)
				L_CenterDisplaySubStr("No",ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			else
				L_CenterDisplaySubStr("Yes",ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_INT:
         	itoa(*Usefulpara[parano].VInt,(char *)datastr);
			sprintf((char *)datastr,"%0u",*Usefulpara[parano].VInt);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_LONG:
			LongToStr(datastr,*Usefulpara[parano].VLong,0);		 //no decimal point required
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_STR:
			strncpy((char *)datastr,(char *)Usefulpara[parano].VStr,Usefulpara[parano].Len);
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		case D_ARRAY_CHAR:
			memset(datastr,' ',sizeof(datastr));
			for(icnt=0;icnt<Usefulpara[parano].Len;icnt++)
			{
				if(((icnt*2)+2) >= 16)
					break;
				sprintf((char *)&datastr[icnt*2],"%02X",Usefulpara[parano].VStr[icnt]);
			}
			L_CenterDisplaySubStr(datastr,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break; 

	}
}

/*------------------------------------------------------------------------*/
void HandleAddCardKey(BYTE type)
{
	
int cardptr;
	DisplayMode = MODE_ADD_CARD;
	switch(type)
	{
		case WEIGAND_DATA:
			DisplayCardNo = NumericValue = ReceivedCardNo;
			if(DisplaySubMode == 0)
			{
					L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		//			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//					sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			}
			break;

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0)
			{
				if(DisplayCardNo == 0)
				{
					L_CenterDisplaySubStr("Card Number Err",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
					break;
				}
//				DisplayCardNo = NumericValue;
#ifdef ENABLE_PIN_VERIFICATION
				NumericValue = 0;
//				L_BlankDisplay(ROW_USER_ENTRY);

//				L_DisplayROMStr("Pin  :   ",10,ROW_USER_ENTRY);
				L_CenterDisplaySubStr("Pin  :",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplaySubMode = 1;
			}
			else
			{
#endif
				L_BlankDisplay(ROW_USER_ENTRY);
				L_CenterDisplaySubStr("Adding Card ....",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
	            Carddata.CardNo = DisplayCardNo;
            	if(Doorinfo.CardDigit == 8)//ARMD0340
					Carddata.CardPin = (WORD)((DWORD)(DisplayCardNo & 0x0000FFFFL) % (DWORD)10000);   
	            else
                	Carddata.CardPin = (WORD)((DWORD)DisplayCardNo % (DWORD)10000);   

				Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;    			
				Carddata.CardInfo.Door1 = 0x01;
				Carddata.CardInfo.Door2 = 0x01;
				Carddata.CardInfo.Holiday = 0x0;
				Carddata.Info.MesgInfo = 0;
#ifdef EN_DOORACCESS
				Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
#ifndef NEW_CARD_FORMAT
				Carddata.Info.BirthMonth = 0;
				Carddata.Info.BirthDate = 0;
#endif
#ifdef EN_CARD_EXP_DATE
		 		Carddata.ExpDT = 0;
#endif
				Carddata.Info.CType = UTYPE_CARD_ONLY_VERIFY;      	//shree 13Oct default card add is card/UID
	         	cardptr = AddCard(Carddata);
				L_BlankDisplay(ROW_USER_ENTRY);
				if(cardptr != -1)
				{
					AddCardNameToFlash(cardptr,"                ");
					MsgPrint(MSG_WARNING,cardptr,"Card Added");
					L_CenterDisplaySubStr("Card Added",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
					NumericValue = 0;
				}
				else
				{
					MsgPrint(MSG_WARNING,cardptr,"Card Add Fail");
					L_CenterDisplaySubStr("User Memory Full",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR); //DB001 If adding card after maximum card added, massage  display "Card Add Fai ",Can we display "User Memory Full" ?
					MakeSound(SOUND_USER_ERROR);
				}
			Delayandreturnback();
			}
//			HandleEnterAddCardKey();
			break;

		case FUNCTION_KEY:
			DisplaySubMode = 0;
				L_CenterDisplaySubStr("Enter UID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
	      	if(Doorinfo.CardDigit == 8)
					PositionCursorOnRowNo(9,ROW_USER_ENTRY);
			CardPositionCount = 1;
	         NumericKeyCount = 0;
			break;

		case NUMERIC_KEY:
		case 	TOUCH_KEY2:   // left shift   select YES
		case 	TOUCH_KEY4:   // Right shift Select NO
			if(type == TOUCH_KEY2)
				CurrentKey = YES_KEY;
			else if(type == TOUCH_KEY4)
				CurrentKey = NO_KEY;
			//			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
				CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
			}
			else if(DisplaySubMode == 10)
			{
				if(CurrentKey == YES_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else if(CurrentKey == NO_KEY)
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
				else
				{
					strcpy((char*)DisplayTempBuffer,"Yes         No");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
				}
			}
			break;
/*			else
			{
				L_DisplayROMStr("Pin  :   ",10,ROW_USER_ENTRY);
			}
			break; */
	}
}

/*---------------------------------------------------------------------------------------*/
/*
void HandleCardFound(BYTE keytype)
{
	// This function is not in use same will be used in pin read mode
	switch(keytype)
	{
		case FUNCTION_KEY:
			NumericValue = 0;
			L_DisplayROMStr((BYTE *)&DISPLAY_MODE[0],16,ROW_USER_FUNCTION);
			L_DisplayROMStr("Pin  :   ",10,ROW_USER_ENTRY);
			L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			break;

		case NUMERIC_KEY:
			L_BlankDisplay(ROW_USER_ENTRY);
			L_DisplayROMStr("Pin  :   ",10,ROW_USER_ENTRY);
			L_DisplayDecimalInteger((WORD)NumericValue,10,ROW_USER_ENTRY);
			break;

		case TOUCH_KEY3:
		case ENTER_KEY:
			if(Carddata.CardPin == NumericValue)
			{
				L_DisplayROMStr("User Verified   ",16,ROW_USER_FUNCTION);
	//			L_DisplayROMStr("Access Granted    ",16,ROW_USER_FUNCTION);
				L_DisplayROMStr("UID:            ",16,ROW_USER_ENTRY);
				L_DisplayCardNumber(Carddata.CardNo,6,ROW_USER_ENTRY);
				StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)Carddata.CardNo,ReaderNo,EVENT_VALID_CARD);
				MakeSound(SOUND_CARD_FOUND);
				DisplayMode = MODE_WAIT_FOR_CARD;
				SendDoorOpen(1);
			}
			else
			{
				L_BlankDisplay(ROW_USER_ENTRY);
				L_DisplayROMStr("Pin Mismatch    ",16,ROW_USER_ENTRY);
				MakeSound(SOUND_USER_ERROR);
			}
			break;
	}
}
*/

/*----------------------------------------------------------------------------*/
/*
void L_DisplayDSUVerNo(void)
{
	PositionCursorOnRow2(0);
	WriteDataToDisplay('V');
	WriteDataToDisplay('e');
	WriteDataToDisplay('r');
	WriteDataToDisplay(':');
   	WriteDataToDisplay(MAJOR_VER);
	WriteDataToDisplay('.');
	WriteDataToDisplay(MINOR_VER);
   	WriteDataToDisplay(' ');
	WriteDataToDisplay('A');
	WriteDataToDisplay('D');
	WriteDataToDisplay('D');
	WriteDataToDisplay(':');
	WriteDataToDisplay(SysInfo.MySlaveNo+'0');
}
*/

#ifdef WEIGAND_OUT_READER
/*----------------------------------------------------------------------------*/
void HandleWeigandType(unsigned char keytype)
{
	struct RectInfo rectinfo;	
	switch(keytype)
	{
		case ENTER_KEY:
		case TOUCH_KEY3:	
ENTER:
		if(stRadioScrollData.CurrSeletion > MAX_WEIGAND_TYPE)
				stRadioScrollData.CurrSeletion  =0;

			SysInfo.WeigandOutCont = WEIGAND_TYPE_NO[(unsigned char)stRadioScrollData.CurrSeletion & 0x0F];
			WriteSysInfoToFlash();
			rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);
			L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);	
			DisplaySubMode = 1;		
			Delayandreturnback();
			break;
			
		case FUNCTION_KEY:
			NumericValue = WeiTypeToCount(SysInfo.WeigandOutCont);
			if(NumericValue > MAX_WEIGAND_TYPE)//ARMD0357
				NumericValue = 0;
			
				stRadioScrollData.MaxScrollElement = MAX_WEIGAND_TYPE;
				stRadioScrollData.PrevSeletion= -1;
				stRadioScrollData.CurrSeletion= NumericValue;
				stRadioScrollData.Array= (const char**)WEI_TYPE;
				DisplayRadioScroll();
				DisplaySubMode = 0;
			
//			L_DisplayROMStrLoc((BYTE*)&WEI_TYPE[(unsigned char)NumericValue],16,ROW_USER_ENTRY,0);
			break;
			
		case 	TOUCH_KEY2: 
UP:
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion > 0)
				{	
					stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
					stRadioScrollData.CurrSeletion--;								
				}
				DisplayRadioScroll();
			}
		break;
		case 	TOUCH_KEY4: 		
DOWN:
			if(DisplaySubMode == 0)
			{
				if(stRadioScrollData.CurrSeletion < MAX_WEIGAND_TYPE-1)
				{	
					stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
					stRadioScrollData.CurrSeletion++;								
				}
				DisplayRadioScroll();
			}
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse1&0xFF)],ROW_USER_ENTRY + TempUse1,1);			
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse&0xFF)],ROW_USER_ENTRY + TempUse,0);									
		break;

		case NUMERIC_KEY:
			if(DisplaySubMode == 0)
			{
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
			}
			break;
			
// 		case NUMERIC_KEY:
// 			if(CurrentKey <= 5)
// 				NumericValue = CurrentKey;
// 			else
// 				NumericValue = 0;
// 			L_DisplayROMStrLoc((BYTE*)&WEI_TYPE[(unsigned char)NumericValue],16,ROW_USER_ENTRY,0);
// 			break;
	}
}

/*----------------------------------------------------------------------------*/
unsigned char WeiTypeToCount(unsigned char weitype)
{
unsigned char i;
	for(i=0;i<MAX_WEIGAND_TYPE;i++)
	{
		if(WEIGAND_TYPE_NO[i] == weitype)
			return(i);
	}
	return(0);
}
#endif

/*----------------------------------------------------------------------------*/
void HandleReaderConfig(unsigned char keytype)		  //ARMD0156
{
	switch(keytype)
	{
		case FUNCTION_KEY:
			if(SysInfo.SlaveType == 2)
			{
				NumericValue = 0;
				L_DisplayROMStr("RS485-Converters",16,ROW_USER_ENTRY);
			}
			else
			{
				NumericValue = 1;
				L_DisplayROMStr("RS485-Readers   ",16,ROW_USER_ENTRY);
			}
			break;

		case NUMERIC_KEY:
			NumericValue = NumericValue % 2;
			if(NumericValue == 1)
				L_DisplayROMStr("RS485-Readers   ",16,ROW_USER_ENTRY);
			else
				L_DisplayROMStr("RS485-Converters",16,ROW_USER_ENTRY);
			break;

		case ENTER_KEY:
		case TOUCH_KEY3:			
			if(NumericValue == 1)
			{
				SysInfo.ControllerMode = 8;
				SysInfo.SlaveType = 1;
			}
			else
			{
				SysInfo.ControllerMode = 8;
				SysInfo.SlaveType = 2;
			}
			L_DisplayROMStr("ONOFF/RST System",16,ROW_USER_ENTRY);
			WriteSysInfoToFlash();
			break;
	}
}

/*----------------------------------------------------------------------------*/
void HandleSetFireTamper(unsigned char keytype)		
{
	struct RectInfo rectinfo;	
	switch(keytype)
	{
		case ENTER_KEY:
		case TOUCH_KEY3:
ENTER:			

				rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);		
//			if(DisplaySubMode == 0)
//			{
//				if(NumericValue <= 3)
//					DisplaySubMode = 0xFF;
//				else 
//					NumericValue = 0;
				if(stRadioScrollData.CurrSeletion > 7)
					stRadioScrollData.CurrSeletion = 0;
				SysInfo.InputED = (SysInfo.InputED & 0xF0) | ((BYTE)stRadioScrollData.CurrSeletion & 0x0F);
				WriteSysInfoToFlash();
				L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				Delayandreturnback();
//			}
			break;

		case FUNCTION_KEY:
//			if(DisplaySubMode == 0)
//			{
				NumericValue = SysInfo.InputED & 0x0F;
				if(NumericValue <= 7)
					NumericValue = SysInfo.InputED & 0x0F;
				else
					NumericValue = 0;
				stRadioScrollData.MaxScrollElement = MAX_FIRE_TAMP_MODE;
				stRadioScrollData.PrevSeletion= -1;
				stRadioScrollData.CurrSeletion= NumericValue;
				stRadioScrollData.Array= (const char**)FIRE_TAMPER_MODE;
				DisplayRadioScroll();
//				L_DisplayROMStr((BYTE *)&FIRE_TAMPER_MODE[(BYTE)(NumericValue&0xFF)],16,ROW_USER_ENTRY);
//			}
			break;

		case 	TOUCH_KEY2: 
UP:
			if(stRadioScrollData.CurrSeletion > 0)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
				stRadioScrollData.CurrSeletion--;								
			}
			DisplayRadioScroll();
		break;
		case 	TOUCH_KEY4: 		
DOWN:
			if(stRadioScrollData.CurrSeletion < MAX_FIRE_TAMP_MODE-1)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
				stRadioScrollData.CurrSeletion++;								
			}
			DisplayRadioScroll();
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse1&0xFF)],ROW_USER_ENTRY + TempUse1,1);			
// 			DisplayRadioButton((BYTE *)&POLL_TYPES[(BYTE)(TempUse&0xFF)],ROW_USER_ENTRY + TempUse,0);									
		break;

		case NUMERIC_KEY:
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
			break;
				
// 		case NUMERIC_KEY:
// 			NumericValue = NumericValue % 10;
// //			if(DisplaySubMode == 0)
// //			{
// 				if(NumericValue > 7)
// 					NumericValue = 0;
// 				L_DisplayROMStr((BYTE *)&FIRE_TAMPER_MODE[(BYTE)(NumericValue&0xFF)],16,ROW_USER_ENTRY);
// //			}
// 			break;
	}
}

//#ifdef BIO_METRIC
/*----------------------------------------------------------------------------*/
void HandleReaderInOutType(unsigned char keytype)
{
	struct RectInfo rectinfo;	
	switch(keytype)
	{
		case ENTER_KEY:
		case TOUCH_KEY3:	
ENTER:
				rectinfo.FillType = RCTFILL_PLAIN;
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].BackGroundColour;   
			rectinfo.Hight = 240 - (ThemeSelect.SubmenueTitleMSGHeight + STATUSBAR_HEIGHT + TOUCH_KEY_SECTION_HEIGHT+DUMMY_ZONE_HEIGHT) ;  // 240 - 35  = 205
			rectinfo.Width = 320;   // 320
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,0,STATUSBAR_HEIGHT + ThemeSelect.SubmenueTitleMSGHeight+DUMMY_ZONE_HEIGHT);			
			if(DisplaySubMode == 0)
			{
//				if(NumericValue < MAX_READERINOUT_TYPE)
//				{
//					DisplaySubMode = 0xFF;
//					SysInfo.ContInOut = NumericValue;				
//				}
//				else 
//					SysInfo.ContInOut = 0;
				if(stRadioScrollData.CurrSeletion >= MAX_READERINOUT_TYPE)
					stRadioScrollData.CurrSeletion = 0;
				SysInfo.ContInOut = stRadioScrollData.CurrSeletion;
				if(SysInfo.ContInOut == 2)
					InOutReader = 2;
				else
					InOutReader = 1;
				WriteSysInfoToFlash();
				L_CenterDisplaySubStr("Set Successfully",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				Delayandreturnback();
			}
			break;
		case FUNCTION_KEY:
//			if(DisplaySubMode == 0)
//			{
				NumericValue = SysInfo.ContInOut;
				if(NumericValue < MAX_READERINOUT_TYPE)
					NumericValue = SysInfo.ContInOut;
				else
					NumericValue = 0;
				stRadioScrollData.MaxScrollElement = MAX_READERINOUT_TYPE;
				stRadioScrollData.PrevSeletion= -1;
				stRadioScrollData.CurrSeletion= NumericValue;
				stRadioScrollData.Array= (const char**)READER_IN_OUT;
				DisplayRadioScroll();				
//				L_DisplayROMStr((BYTE *)&READER_IN_OUT[(BYTE)(NumericValue&0xFF)],16,ROW_USER_ENTRY);
//			}
			break;
				
		case 	TOUCH_KEY2: 
UP:
			if(stRadioScrollData.CurrSeletion > 0)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;
				stRadioScrollData.CurrSeletion--;								
			}
			DisplayRadioScroll();
		break;
		case 	TOUCH_KEY4: 		
DOWN:
			if(stRadioScrollData.CurrSeletion < MAX_READERINOUT_TYPE-1)
			{	
				stRadioScrollData.PrevSeletion = stRadioScrollData.CurrSeletion;			
				stRadioScrollData.CurrSeletion++;								
			}
			DisplayRadioScroll();
		break;

		case NUMERIC_KEY:
				if(CurrentKey == 2)
					goto UP;
				else if (CurrentKey == 8)
					goto DOWN;
				else if (CurrentKey == 5)
					goto ENTER;
			break;

// 		case NUMERIC_KEY:
// 			NumericValue = NumericValue % 10;
// //			if(DisplaySubMode == 0)
// //			{
// 				if(NumericValue >= MAX_READERINOUT_TYPE)
// 					NumericValue = 0;
// 				L_DisplayROMStr((BYTE *)&READER_IN_OUT[(BYTE)(NumericValue&0xFF)],16,ROW_USER_ENTRY);
// //			}
// 			break;
	}
}
//#endif

#ifndef BIO_METRIC
/*** BeginHeader HandleWaitForAdminCardKey */
void HandleWaitForAdminCardKey(unsigned char keytype);
/*** EndHeader */
void HandleWaitForAdminCardKey(unsigned char keytype)
{
int cardptr;
unsigned char tempdata1;
unsigned char count = 0;	
	switch(keytype)
	{
   case WEIGAND_DATA:
   	if(DisplaySubMode == 0xFF)
      	return;
      if(DisplaySubMode == 0)
      {
	      DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
#ifdef SUPPORT_8DIG_CARDNO_MODE
	      CardPositionCount = 1;
	      NumericKeyCount = 0;
#endif
//         L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
//         L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
         L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//		 sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);	
		 L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
         goto GOTO_PROCESS_ADMIN_FROM_WEIGAND;
	  }
	   break;

   case FUNCTION_KEY:
      NumericKeyCount = 0;
      L_BlankDisplay(ROW_USER_ENTRY);
      if(F_Password)
      {
		  //change to scroll format ,so no problem in back button
		DisplayFormat(FORMAT_SCROLL_SCREEN);
		DrawCenterText(	USER_LINE1_START_Y0,
			ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,    
			USER_TITLE_FONTINFO_PTR,
			(unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName);

         L_CenterDisplaySubStr("Enter to Log Out",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         DisplaySubMode = 2;
      }
      else
      {
         L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				 sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);	
				 L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
#ifdef SUPPORT_8DIG_CARDNO_MODE
      	if(Doorinfo.CardDigit == 8)
				PositionCursorOnRowNo(9,ROW_USER_ENTRY);
			CardPositionCount = 1;
         NumericKeyCount = 0;
         DisplayCardNo = NumericValue;
#endif
         DisplaySubMode = 0;
      }
      break;

   case NUMERIC_KEY:
      L_BlankDisplay(ROW_USER_ENTRY);
      if(F_Password)
         DisplaySubMode = 2;
      if(DisplaySubMode == 0)
      {
         if(NumericValue > 0xFFFFFFFF)
            NumericValue = 0;
//         L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
//#ifndef SUPPORT_8DIG_CARDNO_MODE	   //ARMD0373
//			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//#else
			CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
//#endif
         CurrentUser.InputType = INPUT_USER_FROM_KEYBOARD;
      }
      else if(DisplaySubMode == 1)
      {
         if(NumericValue > 0xFFFF)
            NumericValue = 0;
//         L_DisplayROMStr("Password:  ",10,ROW_USER_ENTRY);
         if(NumericValue != 0)
         {
            cardptr = 0;
						count = 0;
						for(cardptr =NumericKeyCount;cardptr >0 ;cardptr--)
            {
								DisplayTempBuffer[count++] = '*';
            }
								DisplayTempBuffer[count++] = '\0';						
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);	
//            while(NumericKeyCount > cardptr)
//             {
//                L_DisplayCharAtRow(14-cardptr,'*',ROW_USER_ENTRY);
// 									
// 								cardptr++;
//             }
//            PositionCursorOnRowNo(14,ROW_USER_ENTRY);
         }
         else
		 {
            //L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
				WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
		 }
      }
      if(DisplaySubMode == 2)
      {
         L_CenterDisplaySubStr("Enter to Log Out",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
      }
      break;

	case TOUCH_KEY3: //treat this key as enter key
	case ENTER_KEY:
   	if(DisplaySubMode == 0xFF)
      	return;
      L_BlankDisplay(ROW_USER_ENTRY);
      if(DisplaySubMode == 0)
      {
         if((NumericValue != 0) && (NumericValue <= 0xFFFFFFFF))
         {
            ReceivedCardNo = DisplayCardNo = NumericValue;//ARMD0273
            DisplaySubMode = 1;
            NumericValue = 0;
            NumericKeyCount = 0;
						//L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//            L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
			LongHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);

GOTO_PROCESS_ADMIN_FROM_WEIGAND:
            if(DisplayCardNo == 55555)
            {
				L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);  //to blank 1st row
				L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				goto GO_TO_CHECK_PIN_ADMIN;
			}
            //cardptr = SearchDisplayAdminUser(DisplayCardNo,&AdmCard);
			cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
            if(cardptr != CARD_NOT_FOUND)
            {
				NumericValue = 0;
				L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);  //to blank 1st row
				L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
               if((CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) && (AdmCard.AdmData.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED))
               {
                  L_CenterDisplaySubStr("Please Show Card",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
                  goto GOTO_ZERO_ERROR_CTYPE_ADMIN;
               }
               if((AdmCard.AdmData.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED) && (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
               {
                  L_CenterDisplaySubStr("Please Show Card",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
GOTO_ZERO_ERROR_CTYPE_ADMIN:
                  F_KeyIdleTime = CLR;
                  IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
                  DisplayMode = MODE_ADMIN_PASSWORD;
                  DisplaySubMode = 0;
                  break;
               }
//	            if((SysInfo.ChkPin != 0) && (AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN))
	            if(AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN)
               {
                  if((CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
                  {
                     if((ReceivedPin != AdmCard.AdmData.CardPin) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
                     {
                        MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
                        StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)AdmCard.AdmData.CardNo,ReaderNo,EVENT_PIN_VERIFICATION);
                        MakeSound(SOUND_CARD_NOT_FOUND);
                        HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
                        F_KeyIdleTime = CLR;
                        IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
                        DisplayMode = MODE_ADMIN_PASSWORD;
                        DisplaySubMode = 0;
                        break;
                     }
                  }
                  else
                  {
						WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
GO_TO_CHECK_PIN_ADMIN:
                     NumericValue = 0;
                     NumericKeyCount = 0;
                     ReceivedPin = 0;
                     DisplaySubMode = 1;
                     IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
                     F_KeyIdleTime = CLR;
                     break;
                  }
               }
//               if((SysInfo.ChkPin != 0) && (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))
               if(CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD)
               {
                  goto GO_TO_CHECK_PIN_ADMIN;
               }
               goto GOTO_VERIFY_ADMIN_CARD;
            }
            else
            {
               L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
				L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
               MakeSound(SOUND_USER_ERROR);
               DisplaySubMode = 0;
               break;
            }
         }
         else
         {
               L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
				L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	         MakeSound(SOUND_USER_ERROR);
            DisplaySubMode = 0;
	         break;
         }
      }
      else if(DisplaySubMode == 1)
      {
         if(DisplayCardNo == 55555)
         {
            if(NumericValue == 11111)
            {
               L_CenterDisplaySubStr("IP SET Login",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplayStatusIcon(STATUS_LOCKED,1);//ip log in
               F_Password = PASS_IPSET_LOGIN;
               AdminLogOutTimer = 0;
            	AdminMenuRight = BIT_IP_SET_ADMIN;
               StoreCardInTrDBFull(DisplayCardNo,0x1,EVENT_ADMIN_LOGIN,0x0A,AdminMenuRight);
				if(UserIntfData.ReturnFromFunction)
				{
					//DisplayBottomStatusIcon(0,"IP SET Login....");
					HandleWelcomeMode(FUNCTION_KEY);
				}
               break;
            }
         }
GOTO_VERIFY_ADMIN_CARD:
      	if(SysInfo.BlockKeyboard != 1)          //to take care f/w upgrade problem
         {
//            if((SysInfo.ChkPin != 0) && (AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN))
            if((AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN) || (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) || \
            ((AdmCard.AdmData.Info.CType & UTYPE_PIN_ON_FINGER_FAIL) && (CurrentUser.InputType & INPUT_USER_FAIL_FINGER_PIN)))
            {
               if(AdmCard.AdmData.CardPin == NumericValue)
               {
                  L_CenterDisplaySubStr ("Admin Login OK",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplayStatusIcon(STATUS_LOCKED,1);//log in
                  F_Password = PASS_ADMIN_LOGIN;
            		AdminMenuRight = AdmCard.AdminType;
					if(UserIntfData.ReturnFromFunction)
					{
						//DisplayBottomStatusIcon(0,"Admin Login OK");
						HandleWelcomeMode(FUNCTION_KEY);
					}
               }
               else
               {
					L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
					L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DisplaySubMode = 0;
					NumericValue=0;
					LongHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
					break;
               }
            }
            else
            {
               	L_CenterDisplaySubStr("Admin Login OK",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplayStatusIcon(STATUS_LOCKED,1);//log in
               	F_Password = PASS_ADMIN_LOGIN;
            	AdminMenuRight = AdmCard.AdminType;
				if(UserIntfData.ReturnFromFunction)
				{
					//DisplayBottomStatusIcon(0,"Admin Login OK");
					HandleWelcomeMode(FUNCTION_KEY);
				}
            }
         }
         else
         {
            L_CenterDisplaySubStr("Login Disabled",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
            F_Password = PASS_IPSET_LOGIN;
			DisplayStatusIcon(STATUS_LOCKED,1);//ip set log in
			if(UserIntfData.ReturnFromFunction)
			{
				HandleWelcomeMode(FUNCTION_KEY);
			}
         }
         AdminLogOutTimer = 0;
         tempdata1 = CurrentUser.InputType;
//         CurrentUser.InputType = F_Password;
         ReceivedPin = 0;
         StoreCardInTrDBFull(DisplayCardNo,0x1,EVENT_ADMIN_LOGIN,AdmCard.AdmData.Info.CType,AdmCard.AdminType);
         CurrentUser.InputType = tempdata1;
         DisplaySubMode = 0xFF;
		}
      if(DisplaySubMode == 2)
      {
         //L_CenterDisplaySubStr("Logged Out",16,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		 DisplayStatusIcon(STATUS_LOCKED,0);//log out
		  DisplayFormat(FORMAT_WELCOME_SCREEN);
		  UserIntfData.NewModeIndex = 0;
		  DoNotProcessThisKey = 1;
         F_Password = 0;
         DisplaySubMode = 0;
      }
      break;
		case TOUCH_KEY1:  	//home key
		{
			// go to welcome screen
			DisplayData.GridCurrentSelection=0;
			DisplayData.GridPreviousSelection=0;

			//display format 2
			DisplayFormat(FORMAT_WELCOME_SCREEN);
			DisplayMode = MODE_WAIT_FOR_CARD;
			
			//not req to clear grid icon
			//change string of touch keys
		}
		break;
		case TOUCH_KEY5:	//back button
		{
			GotoPreviousMenu(UserIntfData.NewModeIndex,FUNCTION_KEY);
//			return;
		}
		break;
	}
}
#endif

#ifdef BIO_METRIC
/*** BeginHeader HandleWaitForAdminCardKey */
void HandleWaitForAdminCardKey(unsigned char keytype);
/*** EndHeader */
void HandleWaitForAdminCardKey(unsigned char keytype)
{
int cardptr;
//static char returnSet=0;
unsigned char tempdata1;
unsigned char count = 0;	
	switch(keytype)
	{
   case WEIGAND_DATA:
   	if(DisplaySubMode == 0xFF)
      	return;
      if(DisplaySubMode == 0)
      {
	      DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
#ifdef SUPPORT_8DIG_CARDNO_MODE
	      CardPositionCount = 1;
	      NumericKeyCount = 0;
#endif
//         L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
//         L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
         L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//		 sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);	
		 L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
         goto GOTO_PROCESS_ADMIN_FROM_WEIGAND;
		}
	   break;

//	case RETURNABLE_FUNCTION_KEY:
   case FUNCTION_KEY:
      NumericKeyCount = 0;
      L_BlankDisplay(ROW_USER_ENTRY);
      if(F_Password)
      {
		  //change to scroll format ,so no problem in back button
		DisplayFormat(FORMAT_SCROLL_SCREEN);
		DrawCenterText(	USER_LINE1_START_Y0,
			ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,    
			USER_TITLE_FONTINFO_PTR,
			(unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName);
		 
         L_CenterDisplaySubStr("Enter to Log Out",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         DisplaySubMode = 2;
      }
      else
      {
         L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				 sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);	
				 L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
#ifdef SUPPORT_8DIG_CARDNO_MODE
      	if(Doorinfo.CardDigit == 8)
				PositionCursorOnRowNo(9,ROW_USER_ENTRY);
		CardPositionCount = 1;
         NumericKeyCount = 0;
         DisplayCardNo = NumericValue;
#endif
         DisplaySubMode = 0;
      }
      break;

   case NUMERIC_KEY:
      L_BlankDisplay(ROW_USER_ENTRY);
      if(F_Password)
         DisplaySubMode = 2;
      if(DisplaySubMode == 0)
      {
         if(NumericValue > 0xFFFFFFFF)
            NumericValue = 0;
//         L_DisplayROMStr("AdmID:    ",10,ROW_USER_ENTRY);
//#ifndef SUPPORT_8DIG_CARDNO_MODE//ARMD0373
//			L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//#else
			CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
//#endif
         CurrentUser.InputType = INPUT_USER_FROM_KEYBOARD;
      }
      else if((DisplaySubMode == 1) || (DisplaySubMode == 4) || (DisplaySubMode == 6))
      {//ARMD0312
         if(NumericValue > 0xFFFF)
            NumericValue = 0;
//         L_DisplayROMStr("Password:  ",10,ROW_USER_ENTRY);
         if(NumericValue != 0)
         {
            cardptr = 0;
						count = 0;
						for(cardptr =NumericKeyCount;cardptr >0 ;cardptr--)
            {
								DisplayTempBuffer[count++] = '*';
            }
								DisplayTempBuffer[count++] = '\0';						
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);	
//            while(NumericKeyCount > cardptr)
//             {
//                L_DisplayCharAtRow(14-cardptr,'*',ROW_USER_ENTRY);
// 									
// 								cardptr++;
//             }
//            PositionCursorOnRowNo(14,ROW_USER_ENTRY);
         }
         else
		 {
            //L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
				LongHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
		 }
      }
      if(DisplaySubMode == 2)
      {
         L_CenterDisplaySubStr("Enter to Log Out",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
      }
      break;
	  
	case TOUCH_KEY3: //treat this key as enter key
    case ENTER_KEY:
   	if(DisplaySubMode == 0xFF)
      	return;
      L_BlankDisplay(ROW_USER_ENTRY);
      if(DisplaySubMode == 0)
      {
         if((NumericValue != 0) && (NumericValue <= 0xFFFFFFFF))
         {
            ReceivedCardNo = DisplayCardNo = NumericValue;//ARMD0273
            DisplaySubMode = 1;
            NumericValue = 0;
            NumericKeyCount = 0;
						//L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//            L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
				LongHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);

GOTO_PROCESS_ADMIN_FROM_WEIGAND:
            if(DisplayCardNo == 55555)
            {
				L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);  //to blank 1st row
				L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				goto GO_TO_CHECK_PIN_ADMIN;
			}
            //cardptr = SearchDisplayAdminUser(DisplayCardNo,&AdmCard);
			cardptr = SearchNewDisplayAdminUser(DisplayCardNo,&AdmCard);
            if(cardptr != CARD_NOT_FOUND)
            {
				NumericValue = 0;
				L_CenterDisplaySubStr(" ",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);  //to blank 1st row
				L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
               if(SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY)
               {//ARMD0312
                  DISABLE_BIO_COMM();
                  if(F_BIO_COMM == CLR)
                     PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 1;
			   }
               if((CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) && (AdmCard.AdmData.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED))
               {
                  L_CenterDisplaySubStr("Please Show Card",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
                  goto GOTO_ZERO_ERROR_CTYPE_ADMIN;
               }
               if((AdmCard.AdmData.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED) && (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
               {
                  L_CenterDisplaySubStr("Please Show Card",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
GOTO_ZERO_ERROR_CTYPE_ADMIN:
                  F_KeyIdleTime = CLR;
                  IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
                  DisplayMode = MODE_ADMIN_PASSWORD;
                  DisplaySubMode = 0;
                  break;
               }
//	            if((SysInfo.ChkPin != 0) && (AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN))
	        if(AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN)
            {
                  if((CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
                  {
                     if((ReceivedPin != AdmCard.AdmData.CardPin) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
                     {
                        MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
                        StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)AdmCard.AdmData.CardNo,ReaderNo,EVENT_PIN_VERIFICATION);
                        MakeSound(SOUND_CARD_NOT_FOUND);
                        HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
                        F_KeyIdleTime = CLR;
                        IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
                        DisplayMode = MODE_ADMIN_PASSWORD;
                        DisplaySubMode = 0;
                        break;
                     }
				   }
	               else//ARMD0312
	               {
						WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
                     //L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
	                  if((CurrentUser.InputType == INPUT_USER_FROM_FINGER) ||       			\
	                     ((AdmCard.AdmData.Info.CType & UTYPE_CARD_ONLY_VERIFY) && 			\
	                     ((CurrentUser.InputType == INPUT_USER_FROM_WEIGAND) || 			  	\
                        (CurrentUser.InputType == INPUT_USER_FROM_SMART) || 				  	\
                        (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))))
	                  {
	                     DisplaySubMode = 4;
	                  }
                  else//ARMD0312
                  {
GO_TO_CHECK_PIN_ADMIN:
	                     DisplaySubMode = 6;   // Ask for finger verification....
	              }
	                  DisplayMode = MODE_ADMIN_CARD_FOUND;
 	                  NumericValue = 0;
	                  ReceivedPin = 0;
//	                  L_DisplayROMStr("Password:       ",16,ROW_USER_ENTRY);
	            	  AskAndVerifyPinForAdmin(FUNCTION_KEY);
	                  IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
	                  F_KeyIdleTime = CLR;
	                  break;
	               }
	            }
				
	            else//ARMD0312
	            {
	               if((CurrentUser.InputType == INPUT_USER_FROM_FINGER) || 				\
	               	((AdmCard.AdmData.Info.CType & UTYPE_CARD_ONLY_VERIFY) &&		\
	               	((CurrentUser.InputType == INPUT_USER_FROM_WEIGAND) || 			\
                     (CurrentUser.InputType == INPUT_USER_FROM_SMART) || 	 			\
	               	(CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) ||			\
                     (CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) ||	\
                     (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))))
	               {
//	                  if((SysInfo.ChkPin != 0) && (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD))
	                  if(CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD)
	                  {
//GOTO_ASK_Verify_Pin_Admin:
	                  	DisplayMode = MODE_ADMIN_CARD_FOUND;
	                    NumericValue = 0;
            			NumericKeyCount = 0;
	                    ReceivedPin = 0;
            			L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	            		AskAndVerifyPinForAdmin(FUNCTION_KEY);
	                    IdleKeyCounter = MAX_KEY_IDLE_TIME - 10;
	                    F_KeyIdleTime = CLR;
						DisplaySubMode = 4;
	                     break;
	                  }
	                  else
	                     goto GOTO_VERIFY_ADMIN_CARD;
	               }
	            }
               //goto GOTO_VERIFY_ADMIN_CARD;
	            L_CenterDisplaySubStr("Processing Card",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	            DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
	            DisplayMode = USER_VERIFY_MODE;
	            BioReaderNo = ReaderNo;
                    F_ChkAdminFinger = SET;
	            HandleUserVerifyMode(WEIGAND_DATA);
	            break;
            }
            else
            {
               L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
				L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
               MakeSound(SOUND_USER_ERROR);
               DisplaySubMode = 0;
               break;
            }
         }
         else
         {
               L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
				L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	         MakeSound(SOUND_USER_ERROR);
            DisplaySubMode = 0;
	         break;
         }
      }
      else if(DisplaySubMode == 1)
      {
         if(DisplayCardNo == 55555)
         {
            if(NumericValue == 11111)
            {
               L_CenterDisplaySubStr("IP SET Login",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplayStatusIcon(STATUS_LOCKED,1);//ip log in
               F_Password = PASS_IPSET_LOGIN;
               AdminLogOutTimer = 0;
            	AdminMenuRight = BIT_IP_SET_ADMIN;
               StoreCardInTrDBFull(DisplayCardNo,0x1,EVENT_ADMIN_LOGIN,0x0A,AdminMenuRight);
				if(UserIntfData.ReturnFromFunction)
				{
					//DisplayBottomStatusIcon(0,"IP SET Login....");
					HandleWelcomeMode(FUNCTION_KEY);
				}
               break;
            }
         }
GOTO_VERIFY_ADMIN_CARD:
      	if(SysInfo.BlockKeyboard != 1)          //to take care f/w upgrade problem
         {
//            if((SysInfo.ChkPin != 0) && (AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN))
            if((AdmCard.AdmData.Info.CType & UTYPE_CHECK_PIN) || (CurrentUser.InputType == INPUT_USER_FROM_KEYBOARD) || \
            ((AdmCard.AdmData.Info.CType & UTYPE_PIN_ON_FINGER_FAIL) && (CurrentUser.InputType & INPUT_USER_FAIL_FINGER_PIN)))
            {
               if(AdmCard.AdmData.CardPin == NumericValue)
               {
					L_CenterDisplaySubStr ("Admin Login OK",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
					DisplayStatusIcon(STATUS_LOCKED,1);//log in
					F_Password = PASS_ADMIN_LOGIN;
            		AdminMenuRight = AdmCard.AdminType;
					if(UserIntfData.ReturnFromFunction)
					{
						//DisplayBottomStatusIcon(0,"Admin Login OK");
						HandleWelcomeMode(FUNCTION_KEY);
					}
               }
               else
               {
                  //L_DisplayROMStr("User/Pass Fail..",16,ROW_USER_ENTRY);
					L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
					MakeSound(SOUND_USER_ERROR);
               }
            }
            else
            {
				L_CenterDisplaySubStr("Admin Login OK",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				DisplayStatusIcon(STATUS_LOCKED,1);//log in
				F_Password = PASS_ADMIN_LOGIN;
            	AdminMenuRight = AdmCard.AdminType;
				if(UserIntfData.ReturnFromFunction)
				{
					//DisplayBottomStatusIcon(0,"Admin Login OK");
					HandleWelcomeMode(FUNCTION_KEY);
				}
            }
         }
         else
         {
            L_CenterDisplaySubStr("Login Disabled",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
            F_Password = PASS_IPSET_LOGIN;
			DisplayStatusIcon(STATUS_LOCKED,1);//ip log in
            AdminMenuRight = 0;	//NGD00074
			if(UserIntfData.ReturnFromFunction)
			{
				HandleWelcomeMode(FUNCTION_KEY);
			}
         }
         FingerRechkCount = 0;
         AdminLogOutTimer = 0;
         tempdata1 = CurrentUser.InputType;
//         CurrentUser.InputType = F_Password;
         F_ChkAdminFinger = CLR;//ARMD0312
         ReceivedPin = 0;
         StoreCardInTrDBFull(DisplayCardNo,0x1,EVENT_ADMIN_LOGIN,AdmCard.AdmData.Info.CType,AdmCard.AdminType);
         CurrentUser.InputType = tempdata1;
         DisplaySubMode = 0xFF;
		}
      if(DisplaySubMode == 2)
      {
         //L_CenterDisplaySubStr("Logged Out",16,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		 DisplayStatusIcon(STATUS_LOCKED,0);//log out
		  DisplayFormat(FORMAT_WELCOME_SCREEN);
		  UserIntfData.NewModeIndex = 0;
          DoNotProcessThisKey = 1;
         F_Password = 0;
         DisplaySubMode = 0;
         F_ChkAdminFinger = CLR;//ARMD0312
      }
	  
      break;
		case TOUCH_KEY1:  	//home key
		{
			// go to welcome screen
			DisplayData.GridCurrentSelection=0;
			DisplayData.GridPreviousSelection=0;

			//display format 2
			DisplayFormat(FORMAT_WELCOME_SCREEN);
			DisplayMode = MODE_WAIT_FOR_CARD;
			
			//not req to clear grid icon
			//change string of touch keys
		}
		break;
		case TOUCH_KEY5:	//back button
		{
			GotoPreviousMenu(UserIntfData.NewModeIndex,FUNCTION_KEY);
//			return;
		}
		break;
	}
}

/*** BeginHeader AskAndVerifyPinForAdmin */
void AskAndVerifyPinForAdmin(unsigned char keytype);
/*** EndHeader */
void AskAndVerifyPinForAdmin(unsigned char keytype)//ARMD0312
{
unsigned char posstar,count;
	// This function is not in use same will be used in pin read mode

	switch(keytype)
	{
	case FUNCTION_KEY:
		CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_PIN;
		NumericValue = 0;
		NumericKeyCount = 0;
      PinReaderNo = ReaderNo;
      DisplayMode = MODE_ADMIN_CARD_FOUND;
// 		L_CenterDisplaySubStr("Enter Password",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
// 		sprintf((char*)DisplayTempBuffer,"%010d",NumericValue);
// 		L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
		break;

	case NUMERIC_KEY:
		L_BlankDisplay(2);
//		L_DisplayROMStr("Password:       ",16,ROW_USER_ENTRY);
      if(NumericValue > 65535)
	   	NumericValue = 0;
//		L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
/*-------------------------------------------*/
// Following code is added to show pin as password in *
			if(NumericValue != 0)
			{
				posstar = 0;
						count = 0;
						for(posstar =NumericKeyCount;posstar >0 ;posstar--)
				{
								DisplayTempBuffer[count++] = '*';
				}
						DisplayTempBuffer[count++] = '\0';		
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);	
				
// 				while(NumericKeyCount > posstar)
// 				{
// 					L_DisplayCharAtRow(14-posstar,'*',ROW_USER_ENTRY);
// 					posstar++;
// 				}
				PositionCursorOnRowNo(14,ROW_USER_ENTRY);
			}
			else
			{
				//L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
				WORDHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			}
/*-------------------------------------------*/
		break;
			
		case TOUCH_KEY3:
	case ENTER_KEY:
      if((DisplaySubMode == 4) || (DisplaySubMode == 6))
      {
      	if(NumericValue > 65535)
	      	NumericValue = 0;
         ReceivedPin = (unsigned int)NumericValue;
         ReaderNo = PinReaderNo;
         if(DisplayCardNo == 55555)//ARMD0363
		 {
         	AdmCard.AdmData.CardPin = 11111;
			DisplaySubMode = 4;
		 }
         if(ReceivedPin != AdmCard.AdmData.CardPin)
         {
            //L_DisplayROMStr("User/Pass Fail..",16,ROW_USER_ENTRY);
            L_CenterDisplaySubStr("Invalid Please Enter",ROW_USER_ENTRY,SUBMENUE_CHAR_FONTINFO_PTR);
			L_CenterDisplaySubStr("Admin ID",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
            MakeSound(SOUND_USER_ERROR);
            F_KeyIdleTime = CLR;
            IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
            DisplayMode = MODE_ADMIN_PASSWORD;
            DisplaySubMode = 0;
			 NumericValue=0  ;
			LongHextoDeciamal((char*)DisplayTempBuffer,NumericValue);
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
         }
         if(DisplaySubMode == 4)
         {
            DisplayMode = MODE_ADMIN_PASSWORD;
            DisplaySubMode = 1;
            HandleWaitForAdminCardKey(ENTER_KEY);
         }
         else if(DisplaySubMode == 6)
         {
            /*if(NextDisplayMode == USER_VERIFY_BY_HOST_MODE)
            {
               BioReaderNo = PinReaderNo;
               F_ChkAdminFinger = SET;
           		HandleUserHostVerify(INITIALISE_EVENT);
               NextDisplayMode = 0;
               break;
            }*/ 
            L_DisplayROMStr("Processing Card...",16,ROW_USER_ENTRY);
            DisplayCardNo = NumericValue= (CARDNO_DATA_STORAGE_TYPE )ReceivedCardNo;
            DisplayMode = USER_VERIFY_MODE;
//            L_DisplayROMStr("AdmID:          ",16,ROW_USER_FUNCTION);
//            L_DisplayCardNumber((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,6,ROW_USER_FUNCTION);
            BioReaderNo = PinReaderNo;
            F_ChkAdminFinger = SET;
            HandleUserVerifyMode(WEIGAND_DATA);
            break;
         }
      }
		break;
	}
}
#endif  //#ifdef BIO_METRIC

#ifndef BIO_METRIC
/*** BeginHeader HandleBulkCardAddDelkey */
void HandleBulkCardAddDelkey(unsigned char keytype);       
/*** EndHeader */
void HandleBulkCardAddDelkey(unsigned char keytype)
{
int cardptr;
unsigned char disptempbuffer[25];
	switch(keytype)
	{
   	case WEIGAND_DATA:
	      if((DisplaySubMode == 1) || (DisplaySubMode == 11))
	      {
	         DisplayCardNo = NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
//	         L_DisplayROMStr("CNo:            ",16,ROW_USER_ENTRY);
#ifdef SUPPORT_8DIG_CARDNO_MODE
	         CardPositionCount = 1;
	         NumericKeyCount = 0;
#endif
			  L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//			sprintf((char*)DisplayTempBuffer,"UID:%010u",DisplayCardNo);	
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
	      }
	      goto GOTO_BULK_CARD_ADD_DEL;

	   case FUNCTION_KEY:
				L_CenterDisplaySubStr("Bulk Card",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				strcpy((char*)DisplayTempBuffer,"Add        Del");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, DisplayTempBuffer)) / 2;
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,
												USER_NORMAL_LINE_COLOR,
												SUBMENUE_CHAR_FONTINFO_PTR,
												DisplayTempBuffer);
			 
//      	L_CenterDisplaySubStr("1:ADD      3:DEL",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//	      PositionCursorOnRowNo(0,ROW_USER_ENTRY);
	      NumericValue = 1;
		  DisplayMode = MODE_BULK_ADD_CARD;
	      DisplaySubMode = 0;
	      break;

	   case NUMERIC_KEY:
	      if(DisplaySubMode == 0)
	      {
	         if(CurrentKey == YES_KEY)
	         {
//	            PositionCursorOnRowNo(0,ROW_USER_ENTRY);
							strcpy((char*)DisplayTempBuffer,"Add        Del");
							Xdigts = 3;
							PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
	 						DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
	            NumericValue = 1;
	         }
	         else if(CurrentKey == NO_KEY)
	         {
//	            PositionCursorOnRowNo(11,ROW_USER_ENTRY);
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,
													USER_NORMAL_LINE_COLOR,
													SUBMENUE_CHAR_FONTINFO_PTR,
													"Add        Del");
	            NumericValue = 3;
	         }
	         else
	         {
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,
												USER_NORMAL_LINE_COLOR,
												SUBMENUE_CHAR_FONTINFO_PTR,
												"Add        Del");
	            CurrentKey = YES_KEY;
	            NumericValue = 1;
	         }
	      }
	      else if((DisplaySubMode == 1) || (DisplaySubMode == 11))
	      {
					CARD_FROM_KEYPAD();
					sprintf((char*)disptempbuffer,"UID:%s",DisplayTempBuffer);
					L_CenterDisplaySubStr(disptempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		  }
	      break;

		case TOUCH_KEY3:
	   case ENTER_KEY:
	      if(DisplaySubMode == 0)
	      {
	         if(NumericValue == 1)  //Add User
	         {
	            L_CenterDisplaySubStr("Add Card :",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						 
							L_CenterDisplaySubStr("CNo:          ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
	            DisplaySubMode = 1;
	            NumericValue = 0;
	         }
	         else if(NumericValue == 3)		//Del User
	         {
	            L_CenterDisplaySubStr("Del Card :",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//							L_CenterDisplaySubStr("CNo:          ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
	            DisplaySubMode = 11;
	            NumericValue = 0;
	         }
							CARD_FROM_KEYPAD();
							sprintf((char*)disptempbuffer,"UID:%s",DisplayTempBuffer);
							L_CenterDisplaySubStr(disptempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
// 							DISPLAY_CARD_FROM_KEYPAD(SUBMENUE_LINE3_START_X0,  // USER_NORMAL_FONT_WIDTH * 4 because UID: is 4 char 
// 																				SUBMENUE_LINE3_START_Y0,
// 																				USER_NORMAL_LINE_COLOR,
// 																				SUBMENUE_CHAR_FONTINFO_PTR,
// 																				ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour);	
//#endif
	      }
         else if((DisplaySubMode == 1) || (DisplaySubMode == 11))
         	goto GOTO_BULK_CARD_ADD_DEL;
         break;
	}
   return;

GOTO_BULK_CARD_ADD_DEL:
   if(DisplayCardNo == 0)
   {
      L_CenterDisplaySubStr("Card Number Err ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
      MakeSound(SOUND_USER_ERROR);
      return;
   }
	if((DisplaySubMode == 1))// && (keytype == WEIGAND_DATA))
	{
	   L_CenterDisplaySubStr("Adding Card...",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	   Carddata.CardNo = DisplayCardNo;
       if(Doorinfo.CardDigit == 8)//ARMD0340
		Carddata.CardPin = (WORD)((DWORD)(DisplayCardNo & 0x0000FFFFL) % (DWORD)10000);   
	   else
       Carddata.CardPin = (WORD)((DWORD)DisplayCardNo % (DWORD)10000);  
	   Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;              //shree 18Nov 0x0;
	   Carddata.CardInfo.Door1 = 0x01;
	   Carddata.CardInfo.Door2 = 0x01;
	   Carddata.CardInfo.Holiday = 0x0;
	   Carddata.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
	   Carddata.Info.BirthMonth = 0;
	   Carddata.Info.BirthDate = 0;
#endif
#ifdef EN_CARD_EXP_DATE
	   Carddata.ExpDT = 0;
#endif
#ifdef EN_DOORACCESS
		Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
      Carddata.Info.CType = UTYPE_CARD_ONLY_VERIFY;         //shree 13Oct default card add is card/UID
      cardptr = AddCard(Carddata);
      if(cardptr != -1)
      {
         AddCardNameToFlash(cardptr,"                ");
         MsgPrint(MSG_WARNING,cardptr,"Card Added");
         L_CenterDisplaySubStr("Card Added",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         NumericValue = 0;
      }
      else
      {
         MsgPrint(MSG_WARNING,cardptr,"Card Add Fail");
         L_CenterDisplaySubStr("Memory Full",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR); //DB001 If adding card after maximum card added, massage  display "Card Add Fai ",Can we display "User Memory Full" ?
         MakeSound(SOUND_USER_ERROR);
      }
	}

   if((DisplaySubMode == 11))// && (keytype == WEIGAND_DATA))
   {
	   Carddata.CardNo = DisplayCardNo;
	   cardptr = DelCard(Carddata);
	   if(cardptr == CARD_NOT_FOUND)
	   {
         MsgPrint(MSG_WARNING,cardptr,"Card not found");
         L_CenterDisplaySubStr("Card Not Found",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         MakeSound(SOUND_USER_ERROR);
      }
      else
      {
         L_CenterDisplaySubStr("Card Deleted",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         MsgPrint(MSG_WARNING,cardptr,"Card Deleted ptr=");
      }
   }
}
#endif

#ifndef BIO_METRIC
/*---------------------------------------------------------------------------------------*/
/*** BeginHeader AskAndVerifyPin */
void AskAndVerifyPin(unsigned char keytype);
/*** EndHeader */
void AskAndVerifyPin(unsigned char keytype)//ARMD0332
{
unsigned char posstar,count,tempbuff1[6];
	// This function is not in use same will be used in pin read mode
	switch(keytype)
	{
		case FUNCTION_KEY:
	      CurrentUser.InputType = CurrentUser.InputType | INPUT_USER_PIN;
	      NumericValue = 0;
			NumericKeyCount = 0;
			PinReaderNo = ReaderNo;
	        DisplayMode = MODE_CARD_FOUND;
			sprintf((char*)DisplayTempBuffer,"UserPin:%05d",NumericValue);
			L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY);
			F_authScreenTimerEnable = 1;
			F_authScreenTimer =11;			
			IdleKeyCounter	= CLR;	
		break;
		
		case NUMERIC_KEY:
//	      L_BlankDisplay(ROW_USER_ENTRY);
//	      L_DisplayROMStr("UserPin:   ",10,ROW_USER_ENTRY);
			F_authScreenTimerEnable = 1;
			F_authScreenTimer =11;			
	      if(NumericValue > 65535)
	         NumericValue =0;
//	      L_DisplayDecimalInteger((unsigned int)NumericValue,10,ROW_USER_ENTRY);
/*-------------------------------------------*/
// Following code is added to show pin as password in *
			if(NumericValue !=0)
			{
				posstar = 0;
				count = 0;
				for(posstar =NumericKeyCount;posstar >0 ;posstar--)
				{
					tempbuff1[count++] = '*';
				}
					tempbuff1[count++] = '\0';		

				sprintf((char*)DisplayTempBuffer,"User Pin:%5s",tempbuff1);
				L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY);					
			}
			else
			{
				sprintf((char*)DisplayTempBuffer,"User Pin:%05d",NumericValue);
				L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY);	
			}
/*-------------------------------------------*/
	      break;
		case ENTER_KEY:
      	if(NumericValue>65535)
	      	NumericValue =0;
         ReceivedPin = (unsigned int)NumericValue;
         ReaderNo=PinReaderNo;
         if((ReceivedPin != CurrentUser.SearchCard.CardPin) || ((ReceivedPin == 0) && (Doorinfo.UserRestrict == 1)))  	
         {
            MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
            StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,PinReaderNo,EVENT_PIN_VERIFICATION);
            MakeSound(SOUND_CARD_NOT_FOUND);
            HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
            F_KeyIdleTime = CLR;
            IdleKeyCounter = MAX_KEY_IDLE_TIME-4;
            DisplayMode = MODE_WAIT_FOR_CARD ;
            DisplaySubMode=0;
            break;
         }
         else
		 {
			L_DisplayROMStr(" ",16,ROW_USER_ENTRY);					
            UserAccessGranted(&CurrentUser);
		 }
			break;
	}
}
#endif

#ifdef ENABLE_GSM_GPRS
/*
1) Chk modem connectivity
	ATZ
	Modem Connected / Not connected

2) Display Operator and Signal Strength "Vodafone    S:05"
	Chk operator
	AT+COPS?
   "Vodafone"

3) Chk signal Strength
	AT+CSQ
   "S:05"
	Receivev signal streggth
	"AT+CSQ"
	+CSQ: 28,0
	OK

3) Get GPRS IP address
	AT+CIFSR
   Display Dynamic IP Address assigned by Operator

4) Connect GPRS
   Try to Connect for a GPRS connection

5) Disconnect GPRS
   Disconnect GPRS connection
*/
/*** BeginHeader HandleGPRSDiagnosis */
void HandleGPRSDiagnosis(unsigned char keytype);
/*** EndHeader */
void HandleGPRSDiagnosis(unsigned char keytype)
{
	switch(keytype)
	{
	   case ENTER_KEY:	//Execute selected diagnosis type
         L_BlankDisplay(ROW_USER_ENTRY);
         HandleGPRSDiagnosisType((unsigned char)NumericValue);
	   	break;
      case FUNCTION_KEY:	//Chk Modem connectivity
         HandleGPRSDiagnosisType(0);
	   	break;
	   case NUMERIC_KEY:	//Select diagnosis type
         L_BlankDisplay(ROW_USER_ENTRY);
	   	if(CurrentKey < MAX_DIAGNOSIS_MODES)
	   		NumericValue = CurrentKey;
	   	else
	   		NumericValue = 0;
         L_DisplayROMStrLoc((BYTE *)&GPRS_DIAGNOSIS_TYPE[(unsigned char)NumericValue],16,ROW_USER_FUNCTION,0);
	   	break;
	}
}
void CheckModemConnection(unsigned char type)
{
	HandleGPRSDiagnosisType(MODEM_CONNECTION);
}
void CheckDisplayOperator(unsigned char type)
{
	HandleGPRSDiagnosisType(MODEM_OPERATOR);
}
void CheckSignalStength(unsigned char type)
{
	HandleGPRSDiagnosisType(MODEM_SIGNAL_STRENGTH);
}
void GetModemIP(unsigned char type)
{
	HandleGPRSDiagnosisType(MODEM_GET_IP);
}
void ConnectGprs(unsigned char type)
{
	HandleGPRSDiagnosisType(MODEM_CONNECT_GPRS);
}
void DissconnectGprs(unsigned char type)
{
	HandleGPRSDiagnosisType(MODEM_DISSCONNECT_GPRS);
}

/*** BeginHeader HandleGPRSDiagnosisType */
void HandleGPRSDiagnosisType(unsigned char type);
/*** EndHeader */
void HandleGPRSDiagnosisType(unsigned char type)
{
unsigned char recbuffer[256],status,igsm=0,jgsm=0,i,count=0;
   DisableECHO();
	switch(type)
   {
   	case 0:	//Chk modem connectivity  
	//    status = SendCommandToModemAndCheck("ATZ",3,recbuffer,5,"OK");
		L_CenterDisplaySubStr("Checking Connection",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		status = SendCommandToModemAndCheck_2("AT+COPS?",10,recbuffer,5,"OK");
	      if(status == GPRS_OK)
            L_CenterDisplaySubStr("MODEM Connected",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
         else
            L_CenterDisplaySubStr("MODEM Not Found",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR); 
         break;
   	case 1:	//Display Operator
				L_CenterDisplaySubStr("Display Operator",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	      status = SendCommandToModemAndCheck_2("AT+COPS?",10,recbuffer,5,"OK");
         
         if(status == GPRS_OK)
         {
	         type = 0;
//	         ServiceProvider[0] = '\0';

	         for(igsm=0,jgsm=0;igsm<PortObj[MODEM_PORT].RxPtr;igsm++)
	         {
	            if(recbuffer[igsm] == '"')
	               type++;
	            else if(type == 1)
	            {
	               ServiceProvider[jgsm] = recbuffer[igsm];
	               jgsm++;
	            }
	            else if(type == 2)
	            {
	               ServiceProvider[jgsm] = '\0';
	               type = 0;
	               break;
	            }
	         }
	         L_CenterDisplaySubStr(ServiceProvider,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
         }
		 else
         {
            L_CenterDisplaySubStr("MODEM Not Found",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR); 
         }
      	break;
   	case 2:	//Display signal Strength
			L_CenterDisplaySubStr("Signal Strength:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR); 
      	ChkSignalStrength();
	      L_DisplayROMStr("SignalLevel     ",16,ROW_USER_ENTRY);
	      DisplaySignalStrength(SignalStrength,ROW_USER_ENTRY);
				sprintf((char*)DisplayTempBuffer,"SignalLevel  %d",SignalStrength);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
      	break;
   	case 3:	//Get GPRS IP address
					L_CenterDisplaySubStr("Modem IP Address:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR); 	
					L_CenterDisplaySubStr("Processing...",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR); 	
        	if(Doorinfo.GPRSEnable == 1)
         {
	         if(Doorinfo.ModemType == 1)
	            status = SendCommandToModemAndCheck("AT+CIFSR",8,recbuffer,5,NULL);
	         else
	            status = SendCommandToModemAndCheck("AT+QILOCIP",8,recbuffer,5,NULL);
	         
	        if(status == 1)
	     		{
						for(igsm=0;igsm<30;igsm++)
						{
							if(recbuffer[igsm]>='0' && recbuffer[igsm]<='9'|| recbuffer[igsm]=='.')
							{
								GPRSIPAddress[count] = recbuffer[igsm];
								++count;
							}
						}
						GPRSIPAddress[count]='\0';
						L_CenterDisplaySubStr(GPRSIPAddress,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				}		
			 else
	         {
							L_CenterDisplaySubStr("MODEM Not Found",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR); 
	         }
         }
         else
         	L_CenterDisplaySubStr("GPRS Dissabled",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
      	break;
   	case 4:	//Connect GPRS
      	if(Doorinfo.GPRSEnable == 1)
	      {
					InitialiseGPRS(1);
         	MainLoopGPRSHandle();
				}
		 else
         	L_CenterDisplaySubStr("GPRS Dissabled",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
      	break;
   	case 5:	//Disconnect GPRS
      	if(Doorinfo.GPRSEnable == 1)
      	 {
		   	F_100mSecCounterStart = SET;
				Temp_100mSec_Time_Counter = 0;
			while(Temp_100mSec_Time_Counter < 4)
			{
				#ifdef ENABLE_WATCHDOG
					WDTFeed();		//Clear watchdog timer
				#endif	
			}
			F_100mSecCounterStart = CLR;
		    status = ShutdownGPRS();
		   if(status == GPRS_OK)
		 	{
         		L_CenterDisplaySubStr("Disconnected GPRS",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
			}
		 }
		 else
           	L_CenterDisplaySubStr("GPRS Dissabled",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
    	break;
   	case 6:	//Enable GPRS
      	Doorinfo.GPRSEnable = 1;
         L_CenterDisplaySubStr("  GPRS Enabled  ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         WriteDoorInfoToFlash();
      	break;
   	case 7:	//Disable GPRS
      	Doorinfo.GPRSEnable = 0;
         L_CenterDisplaySubStr(" GPRS Disabled  ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
         WriteDoorInfoToFlash();
      	break;
   	default:
      	break;
   }
}
#endif//#ifdef ENABLE_GSM_GPRS

//==============================================================================================================================
/*** BeginHeader HandleServerMACEnDis */
void HandleServerMACEnDis(unsigned char type);
/*** EndHeader */
void HandleServerMACEnDis(unsigned char type)
{
	switch(type)
	{
	case TOUCH_KEY3:
	case ENTER_KEY:
		if(DisplaySubMode == 0xFF)	   		//ARMD0412
			break; 
		if(CurrentKey == NO_KEY)
		{
			Doorinfo.SecurityEnDis &= ~BIT_MAC_CHK;
			L_CenterDisplaySubStr("Disabled",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		}
		if(CurrentKey == YES_KEY)
		{
			Doorinfo.SecurityEnDis |= BIT_MAC_CHK;
			L_CenterDisplaySubStr("Enabled",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		}
		DisplaySubMode = 0xFF;			//ARMD0412
		WriteDoorInfoToFlash();
		Delayandreturnback();
	break;
	case FUNCTION_KEY:	
				L_CenterDisplaySubStr("Security",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				strcpy((char*)DisplayTempBuffer,"EN          DI");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
				Xdigts = 3;
				PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,
												USER_NORMAL_LINE_COLOR,
												SUBMENUE_CHAR_FONTINFO_PTR,
												DisplayTempBuffer);	
// 		L_DisplayROMStr("EN          DI",16,ROW_USER_ENTRY);
		NumericValue = 0;
		DisplaySubMode = 0;
		CurrentKey = YES_KEY;
	break;
	
	case NUMERIC_KEY:
	case TOUCH_KEY2:
	case TOUCH_KEY4:		
		if(type == TOUCH_KEY2)
			CurrentKey = YES_KEY;
		else if(type == TOUCH_KEY4)
			CurrentKey = NO_KEY;
		else{}
			
		//MsgPrint(MSG_WARNING,NumericValue,"HandleServerMACEnDis:NumericValue");
		if(DisplaySubMode == 0xFF)		 //ARMD0412
			break; 	
		if(DisplaySubMode == 0)
		{
			if(CurrentKey == YES_KEY)
			{
				strcpy((char*)DisplayTempBuffer,"EN          DI");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,
													USER_NORMAL_LINE_COLOR,
													SUBMENUE_CHAR_FONTINFO_PTR,
													DisplayTempBuffer);			
//					DisplaySubMode = 2;
			}
			if(CurrentKey == NO_KEY)
			{
					strcpy((char*)DisplayTempBuffer,"EN          DI");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
//					DisplaySubMode = 1;
			}
	   }
	break;
	}

}
//==============================================================================================================================

void HandleWeiCardDataDisplay(unsigned char keytype)	//*9997	  
{
//static CARDNO_DATA_STORAGE_TYPE reccardno = 0;
static __packed struct READERDATA_STRUCT RdrData;
unsigned char tempbuffer[20];	

	switch(keytype)
	{		
		case WEIGAND_DATA:
			if(DisplaySubMode==0)
			{
				CardPositionCount = 1;
		     	NumericKeyCount = 0;
				sprintf((char*)DisplayTempBuffer,"Reader No:%02d",(DspRdrNo+1));
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		
//				L_DisplayCharRow(1,DspRdrNo,ROW_USER_ENTRY);
				memcpy((char*)&RdrData,(char *)&ReaderData[DspRdrNo],sizeof(RdrData));
				DisplayCardNo= ReceivedCardNo;
				L_DisplayCardNumber(DisplayCardNo,4,ROW_USER_ENTRY);
				sprintf((char*)tempbuffer,"CardNo:%s",DisplayTempBuffer);				
				L_CenterDisplaySubStr(tempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
//				L_DisplayCardNumber(ReceivedCardNo,4,ROW_USER_ENTRY);
			}
		break;

		case FUNCTION_KEY:
GOTO_WEI_DSP_FUNC_KEY:
				DisplaySubMode = 0;
				DisplayCardNo = 0;
				DspRdrNo = 0;
				sprintf((char*)DisplayTempBuffer,"Reader No:%02d",DspRdrNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
				memcpy((char*)&RdrData,(char *)&ReaderData[DspRdrNo],sizeof(RdrData));
				DisplayCardNo= ReceivedCardNo = 0;
				L_DisplayCardNumber(DisplayCardNo,4,ROW_USER_ENTRY);
				sprintf((char*)tempbuffer,"CardNo:%s",DisplayTempBuffer);				
				L_CenterDisplaySubStr(tempbuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
			break;

		case NUMERIC_KEY:
			break;

		case TOUCH_KEY3:
		case ENTER_KEY:
			L_BlankDisplay(ROW_USER_FUNCTION);
			L_BlankDisplay(ROW_USER_ENTRY);
			if(DisplaySubMode == 0)
			{
//				L_DisplayROMStrLoc("Wei Count:      ",16,ROW_USER_FUNCTION,0);
				L_CenterDisplaySubStr("Wei Count:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
//				L_DisplayROMStrLoc("Bits :                ",16,ROW_USER_ENTRY,0);
				sprintf((char*)DisplayTempBuffer,"Bits:%02d",RdrData.WCount);
				L_CenterDisplaySubStr((unsigned char*)DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
//				L_DisplayCharRow(8,RdrData.WCount,ROW_USER_ENTRY);
				DisplaySubMode = 1;	
			}
			else if(DisplaySubMode == 1)
			{
//				L_DisplayROMStrLoc("Parity Chk:      ",16,ROW_USER_FUNCTION,0);
				L_CenterDisplaySubStr("Parity Chk:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
//				L_DisplayCharRow(1,RdrData.F_ParityError,ROW_USER_ENTRY);
//				WriteDataToDisplay(':');
				if(RdrData.F_ParityError == 0)
					sprintf((char*)DisplayTempBuffer,"%02d:GOOD",RdrData.WCount);
//					L_DisplayROMStrLoc("GOOD             ",16,ROW_USER_ENTRY,4);
				else
					sprintf((char*)DisplayTempBuffer,"%02d:ERROR",RdrData.WCount);
//					L_DisplayROMStrLoc("ERROR            ",16,ROW_USER_ENTRY,4);					
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);				
				L_CenterDisplaySubStr(" ",ROW_USER_ENTRY4,SUBMENUE_CHAR_FONTINFO_PTR);								
				DisplaySubMode = 2;	
			}
			else if(DisplaySubMode == 2)
			{
//				L_DisplayROMStrLoc("ei Raw Data:    ",16,ROW_USER_FUNCTION,0);				
				L_CenterDisplaySubStr("Wei raw Data:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_DisplayHexDouble((RdrData.WeigandData),0,ROW_USER_ENTRY3);
//				L_DisplayHexDouble(RdrData.WeigandData&0xFFFF,4,ROW_USER_ENTRY);
				DisplaySubMode = 3;	
			}
			else if(DisplaySubMode == 3)
			{
				L_CenterDisplaySubStr("Extra Data:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
				sprintf((char*)DisplayTempBuffer,"%010u",RdrData.WeigandExData);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);								
//				L_DisplayLong(RdrData.WeigandExData,0,ROW_USER_ENTRY);
				DisplaySubMode = 4;	
			}
			else if(DisplaySubMode == 4)
			{
//				L_DisplayROMStrLoc("CardNO:          ",16,ROW_USER_FUNCTION,0);
				L_CenterDisplaySubStr("Card No:",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);				
//				L_DisplayHexDouble((DisplayCardNo/0x10000),7,ROW_USER_FUNCTION);
//				WriteDataToDisplay('-');
//				L_DisplayHexDouble(DisplayCardNo&0xFFFF,12,ROW_USER_FUNCTION);
				L_DisplayCardNumber(DisplayCardNo,4,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);								
//				L_DisplayCardNumber(DisplayCardNo,5,ROW_USER_ENTRY); 
				DisplaySubMode = 5;	
			}
			else if(DisplaySubMode == 5)
			{
				goto GOTO_WEI_DSP_FUNC_KEY;	
			}
		break;
	}
}
	
//==============================================================================================================================

static char DispShrDOTL;
//	L_CenterDisplaySubStr("Security",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
void HandleSetSharedDOTL(unsigned char keytype)		  	  //*9998
{
char i;
	
	switch(keytype)
	{
		case FUNCTION_KEY:
GOTO_DOTL_FUNC_KEY:
			DisplaySubMode=0;
			DisplayCardNo=0;
			NumericValue = 0;
			L_CenterDisplaySubStr("EN/DI SharedDOTL",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
			ReadReaderInfoFromFlash();
			DispShrDOTL= ReaderInfo[DisplayCardNo].SharedDOTL;
			L_CenterDisplaySubStr("RdrNO: ALL ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);			
		break;

		case NUMERIC_KEY:
		case TOUCH_KEY2:
		case TOUCH_KEY4:		
		if(keytype == TOUCH_KEY2)
			CurrentKey = YES_KEY;
		else if(keytype == TOUCH_KEY4)
			CurrentKey = NO_KEY;
		else{}	
			
			if(DisplaySubMode == 0)
			{
				if(CurrentKey > MAX_READERS_SUPPORT)
					CurrentKey = 0;
//				L_CenterDisplaySubStr("RdrNO:           ",16,ROW_USER_ENTRY,0);
				if(CurrentKey==0)
					L_CenterDisplaySubStr("RdrNO: ALL ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				else
				{
					sprintf((char*)DisplayTempBuffer,"RdrNO: %02d",CurrentKey);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayCharRow(6,CurrentKey,ROW_USER_ENTRY);
				}	
				NumericValue = CurrentKey;
			}
			if(DisplaySubMode == 1)
			{
				if((CurrentKey) == YES_KEY)
				{
					DispShrDOTL = 1;
//					L_CenterDisplaySubStr(" 1:EN      3:DI ",16,ROW_USER_ENTRY);
					strcpy((char*)DisplayTempBuffer,"EN          DI");
					Xdigts = 3;
					PositionCursorOnRow(StartXpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,
												USER_NORMAL_LINE_COLOR,
												SUBMENUE_CHAR_FONTINFO_PTR,
												DisplayTempBuffer);			
					
//					PositionCursorOnRowNo(1,ROW_USER_ENTRY);
				}
				if((CurrentKey) == NO_KEY)
				{
					DispShrDOTL = 0;
//					L_CenterDisplaySubStr(" 1:EN      3:DI ",16,ROW_USER_ENTRY);
					strcpy((char*)DisplayTempBuffer,"EN          DI");
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
					PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
					DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_CHAR_FONTINFO_PTR,DisplayTempBuffer);
//					PositionCursorOnRowNo(11,ROW_USER_ENTRY);
				}
			}
		break;
		
		case ENTER_KEY:
		case TOUCH_KEY3:
			if(DisplaySubMode == 0)
			{
				if(NumericValue > MAX_READERS_SUPPORT)
					NumericValue = 0;
				DisplayCardNo=NumericValue;
				if(DisplayCardNo==0)
				{
					DispShrDOTL = ReaderInfo[0].SharedDOTL | ReaderInfo[1].SharedDOTL;
					L_CenterDisplaySubStr("DOTL:RdrNo:ALL ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				else
				{
					DispShrDOTL = ReaderInfo[DisplayCardNo-1].SharedDOTL;
					sprintf((char*)DisplayTempBuffer,"DOTL:RdrNo: %02d",DisplayCardNo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//					L_DisplayCharRow(13,DisplayCardNo,ROW_USER_FUNCTION);
				}
				
				strcpy((char*)DisplayTempBuffer,"EN          DI");
				StartXpos = (lcdGetWidth() - drawGetStringWidth(SUBMENUE_CHAR_FONTINFO_PTR, (char*)DisplayTempBuffer)) / 2;
				if(DispShrDOTL == 1)
				{
//					PositionCursorOnRowNo(1,ROW_USER_ENTRY);
					CurrentKey = YES_KEY;
					Xpos = StartXpos;
				}
				else
				{
//					PositionCursorOnRowNo(11,ROW_USER_ENTRY);
					CurrentKey = NO_KEY;
					Xpos = StartXpos + 12*SUBMENUE_CHAR_FONT_WIDTH;
				}
				Xdigts = 3;
				PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,
												USER_NORMAL_LINE_COLOR,
												SUBMENUE_CHAR_FONTINFO_PTR,
												DisplayTempBuffer);	
				
//				L_CenterDisplaySubStr(" 1:EN      3:DI     ",16,ROW_USER_ENTRY);
				DisplaySubMode = 1;
			}
			else if(DisplaySubMode == 1)
			{
				if(DispShrDOTL == 1)
				{
					L_CenterDisplaySubStr("DOTL Enabled ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
					ReaderInfo[DisplayCardNo].SharedDOTL = 1;
				}
				if(DispShrDOTL == 0)
				{
					L_CenterDisplaySubStr("DOTL Disabled ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				}
				if(DisplayCardNo==0)
				{
					for(i=0;i<MAX_READERS_SUPPORT;i++)
						ReaderInfo[i].SharedDOTL = DispShrDOTL;		
				}
				else
				{
					ReaderInfo[DisplayCardNo-1].SharedDOTL = DispShrDOTL;
				}
				WriteReaderInfoToFlash();
				DisplaySubMode = 2;
				Delayandreturnback();
			}
			else if(DisplaySubMode == 2)
			{
				goto GOTO_DOTL_FUNC_KEY;
			}
		break;
	}
}
//===========================================================================================================================
#ifdef	SMART_CARD
void HandleSerialReaderEnaDis(unsigned char keytype)
{
	switch(keytype)
	{
		case TOUCH_KEY3:
	case ENTER_KEY:
			if( DisplaySubMode == 0)
			{
				if((NumericValue == DIS_INOUT_SERIAL_RDR) || (NumericValue > 3))
				{
               SysInfo.SCReaderEnDis[0] = 0;
               SysInfo.SCReaderEnDis[1] = 0;
				}
				else if(NumericValue == ENA_IN_SERIAL_RDR)
				{
					SysInfo.SCReaderEnDis[0] = 1;
               SysInfo.SCReaderEnDis[1] = 0;
				}
				else if(NumericValue == ENA_OUT_SERIAL_RDR)
				{
					SysInfo.SCReaderEnDis[0] = 0;
               SysInfo.SCReaderEnDis[1] = 1;
				}
            else // if(NumericValue == ENA_INOUT_SERIAL_RDR)
            {
					SysInfo.SCReaderEnDis[0] = 1;
               SysInfo.SCReaderEnDis[1] = 1;
            }
				WriteSysInfoToFlash();
				L_DisplayROMStr("ONOFF/RST System ",16,ROW_USER_ENTRY);
			}
	break;

	case FUNCTION_KEY:
			if( DisplaySubMode == 0)
			{
				if(SysInfo.SCReaderEnDis[0] == 0)
            {
            	if(SysInfo.SCReaderEnDis[1] == 0)
               	NumericValue = DIS_INOUT_SERIAL_RDR;
               else if(SysInfo.SCReaderEnDis[1] == 1)
               	NumericValue = ENA_OUT_SERIAL_RDR;
            }
            else if(SysInfo.SCReaderEnDis[0] == 1)
            {
            	if(SysInfo.SCReaderEnDis[1] == 0)
               	NumericValue = ENA_IN_SERIAL_RDR;
               else if(SysInfo.SCReaderEnDis[1] == 1)
               	NumericValue = ENA_INOUT_SERIAL_RDR;
            }
            else
            	NumericValue = DIS_INOUT_SERIAL_RDR;
				L_DisplayROMStrLoc((BYTE *)&SERIAL_RDR_ENADIS[(unsigned int)NumericValue],16,ROW_USER_ENTRY,0);
			}
	break;

	case NUMERIC_KEY:
			NumericValue = NumericValue %10;
			if( DisplaySubMode == 0)
			{
				if(NumericValue > 3)
				{
					NumericValue = 0;
 				}
				L_DisplayROMStrLoc((BYTE *)&SERIAL_RDR_ENADIS[(unsigned int)NumericValue],16,ROW_USER_ENTRY,0);
			}
	break;
	}
}
#endif

//=====================================================================================================================
void HandleLANTest(unsigned char keytype)//ARMF0502
{
	switch(keytype)
	{
		case FUNCTION_KEY:
		{
			unsigned char iparr[4];
			
			sprintf((char*)DisplayTempBuffer,"%s",(char*)&(SysInfo.LOCAL_GATEWAY[0]));
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY,SUBMENUE_NUMBER_FONTINFO_PTR);
			L_CenterDisplaySubStr("Testing please wait!",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);

			StrToArr((char*)&(SysInfo.LOCAL_GATEWAY[0]),iparr);
			GenerateUserTimerEvent(5,EVENT_TIME_OUT);
			fnSendPing(iparr, MAX_TTL, TASK_DEBUG, MyUDP_Socket);    //gateway ping test
		}
		break;
		case NUMERIC_KEY:
			break;
		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0)
			{
				unsigned char iparr[4];
				
				L_CenterDisplaySubStr("Testing please wait!",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
				StrToArr((char*)&(SysInfo.LOCAL_GATEWAY[0]),iparr);
				GenerateUserTimerEvent(5,EVENT_TIME_OUT);
				fnSendPing(iparr, MAX_TTL, TASK_DEBUG, MyUDP_Socket);
			}
		break;
		case EVENT_TIME_OUT:
			L_CenterDisplaySubStr("Test Fail.",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
			Delayandreturnback();	// NGD00070
		break;
		case EVENT_SUCCESSFUL:
			ResetUserTimerEvent(EVENT_TIME_OUT);
			L_CenterDisplaySubStr("Test OK.",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
			Delayandreturnback(); // NGD00070
		break;
	}
}
//=====================================================================================================================
void HandleInternetTest(unsigned char keytype)//ARMF0502
{
	switch(keytype)
	{
		case FUNCTION_KEY:
		{
			unsigned char iparr[4];
			
			sprintf((char*)DisplayTempBuffer,"%s",(char*)&(Doorinfo.InternetTestIP[0]));
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY,SUBMENUE_NUMBER_FONTINFO_PTR);
			L_CenterDisplaySubStr("Testing please wait!",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);

			StrToArr((char*)&(Doorinfo.InternetTestIP[0]),iparr);
			GenerateUserTimerEvent(5,EVENT_TIME_OUT);
			fnSendPing(iparr, MAX_TTL, TASK_DEBUG, MyUDP_Socket);    //gateway ping test
		}
		break;
		case NUMERIC_KEY:
			break;
		case TOUCH_KEY3:
		case ENTER_KEY:
			if(DisplaySubMode == 0)
			{
				unsigned char iparr[4];
				
				L_CenterDisplaySubStr("Testing please wait!",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
				StrToArr((char*)&(Doorinfo.InternetTestIP[0]),iparr);
				GenerateUserTimerEvent(5,EVENT_TIME_OUT);
				fnSendPing(iparr, MAX_TTL, TASK_DEBUG, MyUDP_Socket);
			}
		break;
		case EVENT_TIME_OUT:
			L_CenterDisplaySubStr("Test Fail.",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
			Delayandreturnback(); // NGD00071
		break;
		case EVENT_SUCCESSFUL:
			ResetUserTimerEvent(EVENT_TIME_OUT);
			L_CenterDisplaySubStr("Test OK.",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
			Delayandreturnback(); // NGD00071
		break;
	}
}
//=====================================================================================================================
// void HandleNewFunctionKey(unsigned char key)
// {
// 	char i=0;
// 	MsgPrint(MSG_WARNING,key,"Special Function key pressed=");
//     //here traverse for struct and call respective function.
// 	//DisplayClr();
// 	while(i < MAX_DISPLAY_NEWMODE_MEMBER)
// 	{
// 		//if(UserInt1[i].ModeNo == CurrentModeNo)
// 		if(UserInt1[i].ModeNo == DisplayMode)
// 		{
// 		// MsgPrint(MSG_WARNING,i,"CallSplFunctionKeyHandle:i=");
// 	//		if(UserInt1[i].SpKey==key) //we don't go by special key,no spec. key available in NG bio.
// 			{
// 				//if(DeviceOpMode & UserInt1[i].DevOpMode)   //we can use this ,right now just forget it.
// 				{
// 		//					MsgPrint(MSG_WARNING,UserIntfData.NewModeIndex,"CallSplFunctionKeyHandle:ModeIndex1=");
// 					if(UserInt1[i].EvFunction==0)
// 					{
// 						L_DisplayROMStr("NULL Fucntion",20,4);
// 						IdleKeyCounter = MAX_KEY_IDLE_TIME -4;
// 						UserIntfData.NewModeIndex = 0;
// 						PrevMode=0;
// //						DisplayMode= UserInt1[UserIntfData.NewModeIndex].ModeNo;
// 					}
// 					else
// 					{
// //						MsgPrint(MSG_WARNING,i,"CallSplFunctionKeyHandle:i=");
// 						//CurrentModeNo = UserInt1[i].ModeNo; 
// 						//PrevMode=UserIntfData.NewModeIndex;
// 						if(UserInt1[i].Admin==0)
// 						{
// //							UserInt1[i].EvFunction(FUNCTION_KEY);
// //							DisplayMode= UserInt1[i].ModeNo;
// 							UserIntfData.NewModeIndex=i;
// 							GroupNo=UserInt1[i].Group;
// 							UserInt1[i].EvFunction(key);	
// 						}
// 						else if(F_Password & UserInt1[i].Admin) //	 (F_Password ==SET)
// 						{
// //							UserInt1[i].EvFunction(FUNCTION_KEY);	
// //							DisplayMode= UserInt1[i].ModeNo;
// 							UserIntfData.NewModeIndex=i;
// 							GroupNo=UserInt1[i].Group;
// 							UserInt1[i].EvFunction(key);	
// 						}
// 						else
// 						{
// 							//DisplayClr();
// 							DisplayFormat(FORMAT_WELCOME_SCREEN);
// 							L_DisplayROMStr("Need Admin Login   ",20,5);
// 						}
// 					}
// 				}
// // 				else
// // 				{
// // 					if(UserIntfData.NewModeIndex<=MAX_DISPLAY_NEWMODE_MEMBER)
// // 					{
// // 						L_DisplayROMStr("GO TO LOGIN KEY   ",20,5);
// // 						if(UserInt1[UserIntfData.NewModeIndex].EvFunction!=0)
// // 							UserInt1[UserIntfData.NewModeIndex].EvFunction(key);
// // 					}
// // 				}
// //			break;
// 			}
// 			break;
// 		}
// 		i++;
// 	}
// }
#ifdef ENABLE_DUAL_AUTH
int CardPtr = 0;
void HandleDUASearchCard(BYTE keytype)		  //ARMF2010
{
char pinfrom = 0;
extern struct DUEL_USER_DATA DuelUserData[2];
	if(Doorinfo.DuelUserAuth == 1)
	{
		switch(keytype)
		{
			case WEIGAND_DATA:
				if(DisplaySubMode == 0)
				{
					L_BlankDisplay(ROW_USER_ENTRY);
					NumericValue = (CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo;
					DisplayCardNo = NumericValue;
							CardPositionCount = 1;
							NumericKeyCount = 0;
				L_DisplayCardNumber(DisplayCardNo,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",DisplayCardNo);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);

					CardPositionCount = 1;
					NumericKeyCount = 0;
				}
				break;
			case FUNCTION_KEY:
	GOTO_DUASearch_FN_KEY:			
				L_CenterDisplaySubStr("DUA Search Card",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);			
//				L_DisplayROMStr("UID:            ",16,ROW_USER_ENTRY3);			
//				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
				L_DisplayCardNumber(NumericValue,6,ROW_USER_ENTRY);
//				sprintf((char*)DisplayTempBuffer,"%010u",NumericValue);
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				if(Doorinfo.CardDigit == 8)
//					PositionCursorOnRowNo(9,ROW_USER_ENTRY);
				CardPositionCount = 1;
				NumericKeyCount = 0;
				DisplayCardNo = NumericValue;
		 		DisplaySubMode = 0;
				DisplayMode = MODE_DUA_SEARCH_CARD;
				break;
			case NUMERIC_KEY:
				if(DisplaySubMode == 0)
				{
					L_BlankDisplay(ROW_USER_ENTRY);
// 					L_DisplayROMStr("UID:         ",10,ROW_USER_ENTRY);
// 					GET_CARD_FROM_KEYPAD();
					CARD_FROM_KEYPAD_Xpos(ROW_USER_ENTRY3,0);
				}
				else if(DisplaySubMode == 1)
				{
					if((NumericValue>3)||(NumericValue==2))
						NumericValue =0;
//					L_DisplayDecimalInteger(NumericValue,11,ROW_USER_ENTRY);
						sprintf((char*)DisplayTempBuffer,"%03u",NumericValue);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				}
				else if(DisplaySubMode == 2)
				{
					if((NumericValue>30)||(NumericValue == 0))
						NumericValue = 0;
//					L_DisplayDecimalInteger(NumericValue,11,ROW_USER_ENTRY);
						sprintf((char*)DisplayTempBuffer,"%03u",NumericValue);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
				}
				break;
		
		case TOUCH_KEY3:
			case ENTER_KEY:
				L_BlankDisplay(ROW_USER_ENTRY);
				if(DisplaySubMode == 0)
				{
					Carddata.CardNo = DisplayCardNo;
					MsgPrint(MSG_WARNING,DisplayCardNo,"search CardData");
					CardPtr = SearchDisplayCard(DisplayCardNo,&Carddata);
					if(CardPtr != CARD_NOT_FOUND)
					{
						DuelUserData[0].DuelCType = (Carddata.Info.MesgInfo & 0x60) >> 5;
						DuelUserData[0].GrpInfo = (Carddata.Info.MesgInfo & 0x1F);	
//						pinfrom = 'A';
						L_CenterDisplaySubStr("DUA Admin Type",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//						L_DisplayCardNumber(Carddata.CardNo,0,ROW_USER_ENTRY);
	//	            	L_DisplayCharAtRow(10,pinfrom,ROW_USER_ENTRY);
//						L_DisplayDecimalInteger(DuelUserData[0].DuelCType,11,ROW_USER_ENTRY);
						L_DisplayCardNumber(DuelUserData[0].DuelCType,0,ROW_USER_ENTRY);
//						sprintf((char*)DisplayTempBuffer,"%03u",DuelUserData[0].DuelCType);
						L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
						
						MakeSound(SOUND_KEY_PRESS);
						DisplaySubMode = 1;
						NumericValue=2;
					}
					else
					{
						L_CenterDisplaySubStr("User Search Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						MakeSound(SOUND_USER_ERROR);
					}
				}
				else if(DisplaySubMode == 1)
				{
					if(NumericValue == 2)
						NumericValue = DuelUserData[0].DuelCType;
					DuelUserData[0].DuelCType = NumericValue;
					pinfrom = 'G';
					L_CenterDisplaySubStr("DUA Card GROUP",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
// 					L_DisplayCardNumber(Carddata.CardNo,0,ROW_USER_ENTRY);
// 					L_DisplayCharAtRow(10,pinfrom,ROW_USER_ENTRY);
// 					L_DisplayDecimalInteger(DuelUserData[0].GrpInfo,11,ROW_USER_ENTRY);
					sprintf((char*)DisplayTempBuffer,"%03u",DuelUserData[0].GrpInfo);
					L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
					DisplaySubMode = 2;
					NumericValue = 0;
				}
				else if(DisplaySubMode == 2)
				{
					if(NumericValue == 0)
						NumericValue = DuelUserData[0].GrpInfo;				
					DuelUserData[0].GrpInfo = NumericValue;
//					L_DisplayROMStr("ChangeDUAGRP: > ",16,ROW_USER_FUNCTION);
//					L_DisplayROMStr("DUA_Group: SET  ",16,ROW_USER_ENTRY);
					L_CenterDisplaySubStr("Set Successful",ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
					if(DuelUserData[0].GrpInfo!=0)			
					{
						// indicates that we will use group functionality
				   		Carddata.Info.MesgInfo = (((DuelUserData[0].DuelCType<<5)&0x60) + (DuelUserData[0].GrpInfo & 0x1F)) | 0x80;			 
					}
					DisplaySubMode = 3;
				}
				if(DisplaySubMode == 3)
				{
					AddCard_Loc(CardPtr,Carddata);
					DisplaySubMode = 0;
					NumericValue = 0;
					goto GOTO_DUASearch_FN_KEY; 	
				}
				break;
		}
	}
} 		
#endif //#ifdef ENABLE_DUAL_AUTH
//=====================================================================================================================

void HandleWelcomeMode(unsigned char key)
{
//	unsigned char i;
	MsgPrint(MSG_WARNING,key,"HandleGridView:key=");
	F_authScreenTimerEnable = 0;
	F_authScreenTimer =0;
	
	switch(key)
	{
		case FUNCTION_KEY: 	//
		case TOUCH_KEY1:  	//menu/home key
		{
			if(F_Password == CLR)
			{//if not logged in
				NumericValue = 0;
				DisplaySubMode = 0;
				NumericKeyCount = 0;
				CardPositionCount = 1;
				DisplayMode = MODE_ADMIN_PASSWORD;
				DisplayFormat(FORMAT_EVENT_ICON);
				DrawCenterText(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							(unsigned char*)"Admin Login");
				UserIntfData.ReturnFromFunction = 1;
				HandleWaitForAdminCardKey(FUNCTION_KEY);
			}
			else
			{
				DisplayMode = MODE_GRID_VIEW;
				UserIntfData.ReturnFromFunction = 0;
				PrevMode = UserIntfData.NewModeIndex;
				UserIntfData.NewModeIndex =1; //index of grid menu
				UserIntfData.NewModeIndex =UserIntfData.NewModeIndex ;
				
				if(UserInt1[UserIntfData.NewModeIndex].EvFunction != 0)
				{
	//					DisplayMode= UserInt1[UserIntfData.NewModeIndex].ModeNo;
					GroupNo=UserInt1[UserIntfData.NewModeIndex].Group;
					UserInt1[UserIntfData.NewModeIndex].EvFunction(FUNCTION_KEY);  //it will call HandleGridView
				}
			}
		}
		break;
		case TOUCH_KEY2: 	//F1
		break;
		case TOUCH_KEY3: 	//F2
		break;
		case TOUCH_KEY4: 	//F3
		break;
		case TOUCH_KEY5: 	//F4
		break;
		case ENTER_KEY: 	//
		break;
		case NUMERIC_KEY: 	//
		break;
	}
}
void HandleEventIconMode(unsigned char key)
{
//	unsigned char i;
	MsgPrint(MSG_WARNING,key,"HandleGridView:key=");
	switch(key)
	{
		case FUNCTION_KEY: 	//
		case TOUCH_KEY1:  	//menu/home key
			{
				//display format 2
				DisplayFormat(FORMAT_WELCOME_SCREEN);
                DisplayMode = MODE_WAIT_FOR_CARD;
			}
		break;
		case TOUCH_KEY2: 	//F1
		break;
		case TOUCH_KEY3: 	//F2
		break;
		case TOUCH_KEY4: 	//F3
		break;
		case TOUCH_KEY5: 	//F4
		break;
		case ENTER_KEY: 	//
		break;
		case NUMERIC_KEY: 	//
		break;
	}
}
void HandleGridView(unsigned char key)
{
	unsigned char temp;
	MsgPrint(MSG_WARNING,key,"HandleGridView:key=");
GOTO_SWITCH_FOR_ENTER_KEY:
	switch(key)
	{
		case FUNCTION_KEY: 	//F4/back key
		case TOUCH_KEY1:  	//menu/home key
		{
			if(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN)
			{    //if grid is already displayed then go to welcome screen
				DisplayData.GridCurrentSelection=0;
				DisplayData.GridPreviousSelection=0;

				//display format 2
				DisplayFormat(FORMAT_WELCOME_SCREEN);
                DisplayMode = MODE_WAIT_FOR_CARD;
				
				//not req to clear grid icon
				//change string of touch keys
			}
			else
			{
					//display format 5
					//update mode index
					//jump to related function
					//display sub menu of highlighted scroll menu

	//				L_DisplayROMStr((unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName,32 ,ROW_USER_TITLE);
						
					//display format 3
					DisplayFormat(FORMAT_GRID_SCREEN);
					
					//show grid icon
					DisplayData.GridCurrentSelection=0;
					DisplayData.GridPreviousSelection=0;
					DisplayMode = MODE_GRID_VIEW;
					
					DisplayGridMenu();
			}
		}
		break;
		case TOUCH_KEY2: 	//F1/up key
		{
			//highlight and unhighlight perticular icon
			DisplayMode = MODE_GRID_VIEW;
			if(DisplayData.GridCurrentSelection==0)
			{
				DisplayData.GridCurrentSelection=1;
			}
			else
			{
				DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
				--DisplayData.GridCurrentSelection;
				if(DisplayData.GridCurrentSelection <1)
					DisplayData.GridCurrentSelection = MAX_GRID_ICON;
			}
			
			UpdateGridView();
		}
		break;

		case 5:
		case ENTER_KEY: 	
		case TOUCH_KEY3: 	//F2/select key
		{
			if(DisplayData.GridCurrentSelection == 0)
				break;

			temp = GetIndexFromGridSelection();
			if(UserInt1[temp].EvFunction != 0)
			{
				if(UserInt1[temp].Admin & AdminMenuRight)
				{
					//display sub menu of highlighted icon
					PrevMode = UserIntfData.NewModeIndex;
					UserIntfData.NewModeIndex = temp;
					CurrentKey = 0;

					GroupNo=UserInt1[UserIntfData.NewModeIndex].Group;
					UserInt1[UserIntfData.NewModeIndex].EvFunction(FUNCTION_KEY);
					UserIntfData.GridSelected = DisplayData.GridCurrentSelection;
				}
				else
				{//admin right is insuffisient
					DisplayBottomStatusIcon(0,"Need privileged Login",0,0);
				}
			}
			else
			{
				//no function available.
			}
		}
		break;

		case TOUCH_KEY4: 	//F3/down key
		{
			//highlight and unhighlight perticular icon
			DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
			++DisplayData.GridCurrentSelection;
			if(DisplayData.GridCurrentSelection >MAX_GRID_ICON)
				DisplayData.GridCurrentSelection = 1;
			
			UpdateGridView();
		}
		break;
		case TOUCH_KEY5: 	//F4/back key
		{
			//clear grid icons
			//display format 2
			DisplayFormat(FORMAT_WELCOME_SCREEN);
			DisplayMode=0;
		}
		break;
		case NUMERIC_KEY: 	//F4/back key
		{
			switch (CurrentKey)
			{
				case 4://key 4 is pressed
				{//move left
					if(DisplayData.GridCurrentSelection == 0)
					{
						DisplayData.GridCurrentSelection =1;
					}
					else if(DisplayData.GridCurrentSelection > MAX_GRID_ICON/2)
					{//menu is 5 to 8
						//highlight and unhighlight perticular icon
						DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
						--DisplayData.GridCurrentSelection;
						if(DisplayData.GridCurrentSelection <MAX_GRID_ICON/2+1)
							DisplayData.GridCurrentSelection = MAX_GRID_ICON;
						
					}
					else
					{//menu is 1 to 4
						//highlight and unhighlight perticular icon
						DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
						--DisplayData.GridCurrentSelection;
						if(DisplayData.GridCurrentSelection <1)
							DisplayData.GridCurrentSelection = MAX_GRID_ICON/2;
					}
			
					UpdateGridView();
				}
				break;
				case 6:
				{//move right
					if(DisplayData.GridCurrentSelection == 0)
					{
						DisplayData.GridCurrentSelection =1;
					}
					else if(DisplayData.GridCurrentSelection > MAX_GRID_ICON/2)
					{//menu is 5 to 8
						//highlight and unhighlight perticular icon
						DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
						++DisplayData.GridCurrentSelection;
						if(DisplayData.GridCurrentSelection > MAX_GRID_ICON )
							DisplayData.GridCurrentSelection =  MAX_GRID_ICON/2 +1 ;
					}
					else
					{//menu is 1 to 4
						//highlight and unhighlight perticular icon
						DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
						++DisplayData.GridCurrentSelection;
						if(DisplayData.GridCurrentSelection > MAX_GRID_ICON/2 )
							DisplayData.GridCurrentSelection = 1 ;
					}
			
					UpdateGridView();
				}
				break;
				case 2: //move up
				case 8:
				{//move down
					if(DisplayData.GridCurrentSelection == 0)
					{
						DisplayData.GridCurrentSelection =1;
					}
					else if(DisplayData.GridCurrentSelection > MAX_GRID_ICON/2)
					{//menu is 5 to 8
						//highlight and unhighlight perticular icon
						DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
						DisplayData.GridCurrentSelection -= MAX_GRID_ICON/2;
					}
					else
					{//menu is 1 to 4
						//highlight and unhighlight perticular icon
						DisplayData.GridPreviousSelection = DisplayData.GridCurrentSelection;
						DisplayData.GridCurrentSelection += MAX_GRID_ICON/2;
					}
			
					UpdateGridView();
				}
				break;
				case 5:
				{//enter key
					key = 5; //switch will jump to case 5:
					goto GOTO_SWITCH_FOR_ENTER_KEY;
				}
//				break;
			}
		}
		break;
	}
}
/**
this is recursive function because we can have scroll screen in another scroll screen
*/
void HandleSubMenuScroll(unsigned char key)
{
	unsigned char temp;
//	struct RectInfo rectinfo;
	
	MsgPrint(MSG_WARNING,key,"HandleSubMenuScroll:key=");
GOTO_SWITCH_FOR_ENTER_KEY:
	switch(key)
	{
		case TOUCH_KEY1:  	//menu/home key
		{
			    // go to welcome screen
				DisplayData.GridCurrentSelection=0;
				DisplayData.GridPreviousSelection=0;

				//display format 2
				DisplayFormat(FORMAT_WELCOME_SCREEN);
                DisplayMode = MODE_WAIT_FOR_CARD;
				
				//not req to clear grid icon
				//change string of touch keys
			
		}
		break;
		
		case 2:
		case TOUCH_KEY2: 	//F1/up key
		{
			--ScrollMenuData.ScrollMenuCurrentSelection;
			if(ScrollMenuData.ScrollMenuCurrentSelection <1)
				ScrollMenuData.ScrollMenuCurrentSelection = ScrollMenuData.MaxMenuNum;
			
			UpdateScrollMenu(UserIntfData.NewModeIndex);
		}
		break;
		
		case ENTER_KEY: 	//F4/back key
		case 5:
		case TOUCH_KEY3: 	//F2/select key
		{
			temp = GetModeIndexFromSelection(UserIntfData.NewModeIndex,ScrollMenuData.ScrollMenuCurrentSelection);
			if(UserInt1[temp].EvFunction != 0)
			{
				//check for login
				if(UserInt1[temp].Admin ==0 || (UserInt1[temp].Admin & AdminMenuRight) )
				{
					//display format 5
					DisplayFormat(FORMAT_SUBMENU_SCREEN);
					//update mode index
					//jump to related function
					//display sub menu of highlighted scroll menu
					CurrentKey = 0;
					NumericValue = 0;
					DisplaySubMode = 0;
					NumericKeyCount = 0;
					CardPositionCount = 1;
					PrevMode = UserIntfData.NewModeIndex;
					UserIntfData.NewModeIndex = temp;

//					DisplayMode= UserInt1[UserIntfData.NewModeIndex].ModeNo;
					GroupNo=UserInt1[UserIntfData.NewModeIndex].Group;
					if(UserInt1[UserIntfData.NewModeIndex].DSPMode != 0)
					{
						DisplayMode = UserInt1[UserIntfData.NewModeIndex].DSPMode;
					}
					else
					{
						DisplayMode = MODE_UNKNOWN;
					}					
					
	//				L_DisplayROMStr((unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName,32 ,ROW_USER_TITLE);
					DrawCenterText(	USER_LINE1_START_Y0,
								ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
								USER_TITLE_FONTINFO_PTR,
								(unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName);
					
					UserIntfData.NewModeIndex =UserIntfData.NewModeIndex ;
					UserInt1[UserIntfData.NewModeIndex].EvFunction(FUNCTION_KEY);
				}
				else
				{
					DisplayBottomStatusIcon(0,"Need Privilege Login",0,0);
				}
			}
			else
			{
				//no function available.
				UserIntfData.NewModeIndex = PrevMode;
				UserIntfData.NewModeIndex =UserIntfData.NewModeIndex ;
			}
		}
		break;
		
		case 8: 
		case TOUCH_KEY4: 	//F3/down key
		{
			++ScrollMenuData.ScrollMenuCurrentSelection;
			if(ScrollMenuData.ScrollMenuCurrentSelection > ScrollMenuData.MaxMenuNum)
				ScrollMenuData.ScrollMenuCurrentSelection = 1 ;
			
			UpdateScrollMenu(UserIntfData.NewModeIndex);
		}
		break;
		case TOUCH_KEY5: 	//F4/back key or exit
		{
			//display format 2
			//DisplayFormat(FORMAT_WELCOME_SCREEN);
			//DisplayMode=0;
			CurrentKey = 0;
			GotoPreviousMenu(UserIntfData.NewModeIndex,FUNCTION_KEY);			
		}
		break;
		case FUNCTION_KEY: 	//F4/back key
		{
			if(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN && CurrentKey == FUNCTION_KEY)
			{    //if grid is already displayed then go to welcome screen
				DisplayData.GridCurrentSelection=0;
				DisplayData.GridPreviousSelection=0;

				//display format 2
				DisplayFormat(FORMAT_WELCOME_SCREEN);
                DisplayMode = MODE_WAIT_FOR_CARD;
				
				//not req to clear grid icon
				//change string of touch keys
			}
			else
			{
				//display format4
				DisplayFormat(FORMAT_SCROLL_SCREEN);
				UserIntfData.ScrollLevel = 0;
				//Display Menu Title  
// 				rectinfo.FillType = RCTFILL_PLAIN;
// 				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TitleMSGBackgroundColour;
// 				rectinfo.Hight = TITLEMSG_HEIGHT;  
// 				rectinfo.Width = TITLEMSG_WEIGHT;  
// 				rectinfo.BorderColor = 0;
// 				DrawRect(&rectinfo,DISP_TITLEMSG_X0,DISP_TITLEMSG_Y0);
		
				DrawCenterText(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							(unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName);

//				L_DisplayROMStr((unsigned char*)UserInt1[UserIntfData.NewModeIndex].MenuName,32 ,ROW_USER_TITLE);
				//display all scroll menu
				ScrollMenuData.MaxMenuNum = GetMaxScrollMenu(UserIntfData.NewModeIndex);
				ScrollMenuData.firstMenuNum = 1;
				ScrollMenuData.ScrollMenuCurrentSelection = 1;
				ScrollMenuData.ScrollMenuPreviousSelection = 0;
				
				ScreenFormatData.F_ScrollMenuVisible = 1;
				DisplayScrollMenu(UserIntfData.NewModeIndex);
			}
		}
		break;
		case NUMERIC_KEY: 	//F4/back key
		{
			switch (CurrentKey)
			{
				case 2: //up key
				case 8: //down key
				case 5: //enter key
				{//enter key
					key = CurrentKey; //switch will jump to case 5:
					goto GOTO_SWITCH_FOR_ENTER_KEY;
				}
				break;
			}
		}
		break;
	}
}
// void HandleSubMenuScroll_2(unsigned char key)
// {
// 	UserIntfData.ScrollLevel = 1;
// 	switch(key)
// 	{
// 		{
// 			if(ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN)
// 			{    //if grid is already displayed then go to welcome screen
// 	HandleSubMenuScroll(key);
// }
/**
this function searches for previous menu,
if found goto prev function 
else goto welcome screen.
*/
void GotoPreviousMenu(unsigned char MenuIndex,unsigned char Key)
{
	char i=MenuIndex;

	if(MenuIndex == 0 || MenuIndex >=MAX_DISPLAY_NEWMODE_MEMBER)
	{
		UserIntfData.NewModeIndex = 0;
		HandleWelcomeMode(Key);
	}
	
	while(i>0)
	{
		i--;
		if(UserInt1[MenuIndex].ModeNo-1 == UserInt1[i].ModeNo)
		{
			UserIntfData.NewModeIndex = i;
			UserInt1[i].EvFunction(Key);
			return;
		}
	}

	UserIntfData.NewModeIndex = 0;
	HandleWelcomeMode(Key);
}

void HandleCalibrateTouch(unsigned char keytype)			  //NG004
{
	switch(keytype)
	{
		case FUNCTION_KEY:
		{
			L_CenterDisplaySubStr("Start Calibrate  ",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
		}
		break;
		case NUMERIC_KEY:
			break;
		
		case TOUCH_KEY3:
		case ENTER_KEY:
			Doorinfo.TScalibrated = 0;		
			HandleTouchScreenKey();		
//			L_CenterDisplaySubStr("Testing please wait!",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
		break;
	}

}

#ifdef INSERT_SDCARD
void HandleDeleteSDTrans(unsigned char keytype)			  //
{
char tmpdata,day,month,year,endday,endmonth,endyear;	
static unsigned int startdate;
unsigned char i,Filename[12];	
	switch(keytype)
	{
		case FUNCTION_KEY:
			TempUse = 1;
			startdate =0;
			DDateTime.Date.Day = DDateTime.Date.Month = DDateTime.Date.Year = 0;
			sprintf((char*)DisplayTempBuffer,"From Date: %02d/%02d%/%02d",DDateTime.Date.Day, 
																			DDateTime.Date.Month, 
																			DDateTime.Date.Year );
			Xpos = (320 - drawGetStringWidth(SUBMENUE_NUMBER_FONTINFO_PTR, (char*)DisplayTempBuffer))/2; // it decides start of Str position
			Xpos = Xpos + 12*SUBMENUE_NUMBER_FONT_WIDTH;
			Xdigts = 2;   // it will heghlight 2 char 
			StartXpos = Xpos;		
			PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY2,1,SUBMENUE_NUMBER_FONTINFO_PTR);				
			DrawCenterText(SUBMENUE_LINE2_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);

			sprintf((char*)DisplayTempBuffer,"  To Date: %02d/%02d%/%02d",DDateTime.Date.Day,	
																			DDateTime.Date.Month,	
																			DDateTime.Date.Year );
			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
			DisplaySubMode = 0;
			NumericValue = 0;		
		break;
		
		case NUMERIC_KEY:
			switch(DisplaySubMode/2)
			{
				case POS_DATE_DAY:
					DDateTime.Date.Day = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode++;
					if(tmpdata > 31)
					{
						NumericValue = DDateTime.Date.Day = 1;
						DisplaySubMode = POS_DATE_DAY;
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == (POS_DATE_MONTH*2))
					{
						Xpos += (SUBMENUE_NUMBER_FONT_WIDTH*3);
					}
					if(TempUse==1)
						PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY2,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
					else
						PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
				break;
					
				case POS_DATE_MONTH:
					DDateTime.Date.Month = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode++;
					if(tmpdata > 12)
					{
						NumericValue = DDateTime.Date.Month = 1;
						DisplaySubMode = (POS_DATE_MONTH*2);
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode == (POS_DATE_YEAR*2))
					{
						Xpos += (SUBMENUE_NUMBER_FONT_WIDTH*3);
					}
					if(TempUse==1)
						PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY2,1,SUBMENUE_NUMBER_FONTINFO_PTR);															
					else
						PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
				break;
					
				case POS_DATE_YEAR:
					DDateTime.Date.Year = tmpdata = (WORD)NumericValue & 0x00FF;
					DisplaySubMode++;
					if(tmpdata > 99)
					{
						NumericValue = DDateTime.Date.Year = 0;
						DisplaySubMode = (POS_DATE_YEAR*2);
						MakeSound(SOUND_USER_ERROR);
					}
					if(DisplaySubMode >= MAX_POS_DATE)
					{
						Xpos = StartXpos;
						DisplaySubMode = 0;
					}
					if(TempUse==1)
						PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY2,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
					else
						PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);										
				break;
			}

			if(!(DisplaySubMode % 2))
			{
				NumericValue = 0;
			}				
			if(TempUse==1)
			{
				sprintf((char*)DisplayTempBuffer,"From Date: %02d/%02d/%02d",DDateTime.Date.Day,
															DDateTime.Date.Month,
															DDateTime.Date.Year	);
				DrawCenterText(SUBMENUE_LINE2_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);
			}
			else
			{
				sprintf((char*)DisplayTempBuffer,"  To Date: %02d/%02d/%02d",DDateTime.Date.Day,
															DDateTime.Date.Month,
															DDateTime.Date.Year	);
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);
				
			}				
//			L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY3,SUBMENUE_NUMBER_FONTINFO_PTR);
			break;
		
		case TOUCH_KEY3:			
		case ENTER_KEY:
			if(TempUse==1)
			{
				TempUse = 2;
				sprintf((char*)DisplayTempBuffer,"From Date: %02d/%02d%/%02d",DDateTime.Date.Day,
																				DDateTime.Date.Month,
																				DDateTime.Date.Year );
				L_CenterDisplaySubStr(DisplayTempBuffer,ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				
				Xpos = StartXpos;
				startdate = DDateTime.Date.Day*10000 + DDateTime.Date.Month*100 + DDateTime.Date.Year;
				PositionCursorOnRow(Xpos,Xdigts,ROW_USER_ENTRY3,1,SUBMENUE_NUMBER_FONTINFO_PTR);				
				sprintf((char*)DisplayTempBuffer,"  To Date: %02d/%02d/%02d",DDateTime.Date.Day,
															DDateTime.Date.Month,
															DDateTime.Date.Year	);				
				DrawCenterText(SUBMENUE_LINE3_START_Y0,USER_NORMAL_LINE_COLOR,SUBMENUE_NUMBER_FONTINFO_PTR,DisplayTempBuffer);

			}
			else if(TempUse==2)
			{
				
				TempUse = 0;
				
				endday = DDateTime.Date.Day;
				endmonth = DDateTime.Date.Month;
				endyear = DDateTime.Date.Year;				
				L_CenterDisplaySubStr("Deleting Transaction",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
				L_CenterDisplaySubStr("Pleasewait...",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
				
				day = startdate/10000;
				startdate = startdate%10000;
				month = startdate/100;
				startdate = startdate%100;
				year = startdate;
				
				for(i=0;i<12;i++)
					Filename[i] = '\0';

#ifdef ENABLE_WATCHDOG
							WDTFeed();		//Clear watchdog timer
#endif	
				
				if(endyear > year)
				{
					while(1)
					{
						if((endyear == year) && (endmonth == month) && (endday == day))	
							break;
						sprintf((char*)Filename,"%02d%02d%02d.txt",day,month,year);						
						ucFnDeleteFile(Filename); 
						day++;
						if(day>31)
						{
							day = 1;
							month++;
#ifdef ENABLE_WATCHDOG
							WDTFeed();		//Clear watchdog timer
#endif	
						}	
//#ifdef ENABLE_WATCHDOG
// 						if(day%14 == 0)
// 						{	
// 							WDTFeed();		//Clear watchdog timer
// 						}
//#endif	
						
						if(month>12)
						{
							month = 1;
							year++;
						}
						if(year>99)
							year = 1;		
					}
				}
				else if(endyear == year)
				{
					while(1)
					{
						if((endmonth == month) && (endday == day))	
							break;
						sprintf((char*)Filename,"%02d%02d%02d.txt",day,month,year);						
						ucFnDeleteFile(Filename); 
						day++;
						if(day>31)
						{
							day = 1;
							month++;
#ifdef ENABLE_WATCHDOG
							WDTFeed();		//Clear watchdog timer
#endif	
						}	
						if(month>12)
						{
							month = 1;
						}		
					}
				}
				Delayandreturnback();

			}
			else{}
				
			
			
//			L_CenterDisplaySubStr("Testing please wait!",ROW_USER_ENTRY2,SUBMENUE_NUMBER_FONTINFO_PTR);
		break;
	}

}
#endif
// Following function will delay current operation and then jump to back key
void Delayandreturnback()
{

	BackKeyCounter=15;	 		//NG0001
	F_GenerateBackKey=CLR;

/*	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
	while(Temp_Time_Counter < 2);
		F_TempCounterStart = CLR;
	KeyBuff[KeyWritePtr++] = 0x14;
	if(KeyWritePtr >= 4)
		KeyWritePtr = 0; */

}

//This function will just call back key 
void GenerateBackKey(void)				//NG0001
{	
	KeyBuff[KeyWritePtr++] = TOUCH_BACK_KEY;
	if(KeyWritePtr >= 4)
		KeyWritePtr = 0;
}


