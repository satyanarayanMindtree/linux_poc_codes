/*
Card Management as per new Hash logic.

*/

#define SRC_CARDMGMT


#include <stdio.h>
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include <string.h>
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "spi.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "Cardmgmt.h"
#include "Serial.h"
#include "Access.h"
#include "memmap.h"
#include "memory.h"
#include "Rdcont.h"
#include "TemplatesonFlash.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif
#include "DriverSpeech_IC.h"


extern struct DOOR_INFO Doorinfo;   //PANKAJ
extern unsigned char F_DoNotCheckAPBForCard,DoNotCheckAPBTime,SpecialCardRdNo;
extern unsigned char CurrentInputType; 

/*

List of changes which needs to do in improvement
1) Cadd card at last card position
2) Improve speed by keeping lastadded pointer for each block
3) Consider last card position for each block for search
4) Add TotalCards per block
5) Update access time properly
6) Add name and other information.
*/

extern void LogData(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event,unsigned char LogCmd);

int GetCardByLocation(unsigned int loc,struct CARD_DATA *empcard);

// Following function will initialise all card management structures
unsigned int IniCardInfo(void)
{
	// PANKAJ :::: If we are calling only one function why to call in other function we can directly call 
	IniCardDataStrt();	
	return(0);
}

// This is initialise basic Hash card structure 

unsigned char IniCardDataStrt(void)
{
	BYTE block;
	F_DoNotCheckAPBForCard=CLR;
	SpecialCardRdNo=0xFF;
	MsgPrint(MSG_MEM,sizeof(struct CARD_FLASH_DB),"sizeof(struct CARD_FLASH_DB)=");
	for(block=0;block<MAX_CARD_BLOCKS;block++)
   	{
	   	CardMemHashTable[block].MaxCards = MAX_CARD_PER_BLOCK;
   		CardMemHashTable[block].BlankCardPtr  = 0;
		CardMemHashTable[block].StartPageNo = FL_CARDDATA_PAGE_NO + (FL_PAGES_PER_CARD_BLOCK*block);
//		MsgPrint(MSG_MEM,block,"Flash Block No");
//		MsgPrint(MSG_MEM,CardMemHashTable[block].StartPageNo,"Flash Page");
   	}
//   	printf("****** Total CARD PAGES %d and END PAGE number %d *********\n",(FL_PAGES_PER_CARD_BLOCK*10),FL_CARDDATA_PAGE_NO + (FL_PAGES_PER_CARD_BLOCK*10));
	return(0);
}

//=================SPL card Initialisation====================	//281210-2
/*** BeginHeader SplCardInit*/
void SplCardInit(void);
/*** EndHeader */
void SplCardInit(void)
{
unsigned int temp1;
struct SPL_CARD_DATA RAMSplcard;
//unsigned long rampos;
   temp1 = 0;
   TotalSplCards = 0;
	F_FlashSelect=0;
/*
ARMD0400 :: Need to slove We should add loop here so we read all Blocks where special cards are stored.
*/
	MainMem_ReadPage(FL_SPL_CARDDATA_PAGE_NO,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
	while(temp1 < MAX_SPL_CARD)
   	{
	  	memcpy((unsigned char *)&RAMSplcard, &tempwrbuf[temp1*(sizeof(struct SPL_CARD_DATA))],sizeof(struct SPL_CARD_DATA));
	  	if(RAMSplcard.CardNo != 0)
	      TotalSplCards++;
	   	temp1++;
   	}
   return;
}
//==============================================================================
extern int AddCardExtraData(unsigned int cardindex,_CExtraInfo *tmpinfobuff);
unsigned int TestCardMgmt(unsigned int maxcards,unsigned long cardstart,unsigned int ptr,unsigned char wrt_rd,unsigned char port)
{

//when wrt_rd = 0 --> used for write
//wrt_rd = 1 --> used for read

unsigned long cardno;
unsigned int totalcards,cardsadded,nameloc;
CardData empcard;
unsigned char block,error=0;
unsigned short olddummy,oldpin;

_CExtraInfo  tcardExtInfo;
//struct CARD_FLASH_DB cardflash;
//WORD pos;
	if(maxcards>MAX_NO_OF_CARD)
		maxcards=MAX_NO_OF_CARD; //ARMD0325
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_ADD_CARD;
#endif

	memset((unsigned char*)&Carddata,0,sizeof(Carddata));
	memset((unsigned char*)&tcardExtInfo,0,sizeof(tcardExtInfo));		
	if((cardstart==0)&&(ptr==0))
		cardno=1;
	else
		cardno=cardstart;
   if(ptr==0)
   {
	   for(block=0;block<MAX_CARD_BLOCKS;block++)
	   {
         CardMemHashTable[block].BlankCardPtr  = 0;
	   }
	}
MsgPrint(MSG_WARNING,maxcards,"TestCardMgmt:maxcards=");
	if(wrt_rd == 0)
	{
		empcard.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
		empcard.CardInfo.Door1 = 1;
		empcard.CardInfo.Door2 = 255;   // so it uses Access Level function.
		empcard.CardInfo.Holiday = 0;
		empcard.Info.MesgInfo = 5;
		empcard.ExpDT = 0;
		empcard.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
		empcard.Info.Group=0;  
		empcard.DoorAccess=0x0F;
		tcardExtInfo.Image_TemplateSD_Flag = 0; // no template in sd & sensor
		cardsadded=0;
	   for(totalcards=0;totalcards < maxcards;totalcards++)
	   {
				empcard.CardNo = cardno;
	   			empcard.CardPin = (WORD) cardno%10000;
		   		empcard.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
				empcard.CardPin =0;
				empcard.CardPin =GetCheckSum((unsigned char*)&empcard,sizeof(empcard));
	  		if( WriteCardDataToFlashBlock((unsigned char)(cardno%10L),CardMemHashTable[(unsigned char) (cardno%10L)].BlankCardPtr,empcard)==0)
				{								//(block no.(0 to 9)	, Card position	(0 to 1199 for 12000 cards)					, EmpCard)
					cardsadded++;
				}
				nameloc = CardMemHashTable[(unsigned char) (cardno%10L)].BlankCardPtr + ((unsigned char)(cardno%10L) * MAX_CARD_PER_BLOCK);
				CardMemHashTable[(unsigned char) (cardno%10L)].BlankCardPtr++ ;
				tcardExtInfo.JoiningDate = cardno;
				tcardExtInfo.AccessDate 	= 0;
				tcardExtInfo.BirthDate  	= cardno%10;	
				tcardExtInfo.dummy = 0;				
				sprintf((char*)tcardExtInfo.Name,"CN:%d",cardno);
				tcardExtInfo.dummy =GetCheckSum((unsigned char*)&tcardExtInfo,sizeof(tcardExtInfo));
				AddCardExtraData(nameloc,&tcardExtInfo);

	
	      	if((totalcards%10)==0)
	      		MsgPrint(MSG_WARNING,cardno,"Card adding  block ");
	      	cardno++;
#ifdef ENABLE_WATCHDOG
			if(totalcards % 100 == 0)	//NGD00081
				WDTFeed();		//Clear watchdog timer
#endif
	   }
	}
	else if((wrt_rd == 1)||(wrt_rd == 3))
	{
			cardsadded=0;
			TransmitCharToX('S',port);
   		TransmitCharToX(',',port);
   		SendDecimalToPC3CharToX(97,port);
   		TransmitCharToX(',',port);
	   	for(totalcards=0;totalcards < maxcards;totalcards++)
	   	{
	  		if(ReadCardDataFromFlashBlock((unsigned char)(cardno%10L),CardMemHashTable[(unsigned char) (cardno%10L)].BlankCardPtr,&empcard)==0)
				{
				oldpin = empcard.CardPin;
				empcard.CardPin = 0;
				if(empcard.CardNo != cardno)
					error=error | 0x01;
				if(GetCheckSum((unsigned char*)&empcard,sizeof(empcard)) !=oldpin)
					error=error | 0x02;
				nameloc = CardMemHashTable[(unsigned char) (cardno%10L)].BlankCardPtr + ((unsigned char)(cardno%10L) * MAX_CARD_PER_BLOCK);
				ReadCardTemplateInfoFromFlash(nameloc,&tcardExtInfo);
				olddummy=tcardExtInfo.dummy;
				tcardExtInfo.dummy=0;
				tcardExtInfo.AccessDate=0; 	// this may get changed when card is accessed
				if(tcardExtInfo.JoiningDate != cardno)
					error=error | 0x04;
				if(GetCheckSum((unsigned char*)&tcardExtInfo,sizeof(tcardExtInfo))!= olddummy)
					error=error | 0x08;
				if(error)
				{
						TransmitCharToX('F',port);
	      		TransmitCharToX('C',port);
	      		TransmitCharToX('>',port);
						SendDecimalLongToX(empcard.CardNo,port);   	//read cardno
	      		TransmitCharToX('=',port);
						SendDecimalLongToX(cardno,port);   			//actual cardno
						TransmitCharToX(',',port);
						SendDecimalToPC3CharToX(error,port);
						TransmitCharToX(TERMINATOR,port);	 //TERMINATOR
				}
					cardsadded++;
				}
				error=0;
				CardMemHashTable[(unsigned char) (cardno%10L)].BlankCardPtr++ ;	
				if((totalcards%10)==0)
						MsgPrint(MSG_WARNING,cardno,"Card reading  block ");
				cardno++;
		#ifdef ENABLE_WATCHDOG
			if(totalcards % 200 == 0)
				WDTFeed();		//Clear watchdog timer
		#endif
	 }
	}
	return(cardsadded);
}
//==============================================================================
//   WriteAllCardDataToRamFromFlash();
  
/*	for(block=0;block<MAX_CARD_BLOCKS;block++)
   	{
   		for(pos=0;pos<MAX_CARD_PER_BLOCK;pos++)
		{
      		ReadCardDataFromFlashBlock(block,pos,&empcard);
	        PrintCardData(&empcard);
      	}
   	}  */

/*   for(cards=100;cards < 125;cards++)
   {
		empcard.CardNo = cards ;
   		empcard.CardPin = (unsigned int) cards;
		empcard.Info.CType = 0;
		empcard.CardInfo.Door1 = cards%10;
	   	empcard.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
		AddCard(empcard);
   }
   	empcard.CardNo = 1;
	DelCard(empcard);
   	empcard.CardNo = 11;
	DelCard(empcard);
	for(pos=0;pos<25;pos++)
	{	if( BlockCardSearch(pos%10,pos,&cardflash) !=CARD_NOT_FOUND)
		{
			empcard.CardNo 		= cardflash.CardNo ;
   			empcard.CardPin 	= cardflash.CardPin;
			empcard.CardInfo.Door1 	= cardflash.TZ1;
			PrintCardData(&empcard);					
		}
		else
		{
		 	MsgPrint(MSG_WARNING,pos,"****** Card Not FOUND *****= ");	
		}
	}
   	empcard.CardNo = 2;
	DelCard(empcard);
	empcard.CardNo = 22;
	DelCard(empcard);
	for(pos=0;pos<25;pos++)
	{			
		if( SearchDisplayCard(pos,&empcard) !=CARD_NOT_FOUND)
		{
			MsgPrint(MSG_WARNING,pos,"###### SearchDisplayCard ########");		
			PrintCardData(&empcard);					
		}
*//*		else
		{
		 	MsgPrint(MSG_WARNING,pos,"****** Card Not FOUND *****= ");	
		}*/
//	}

   //printf("==============================================================\n");
/*	pos = BlockCardSearch(1,9991);
   if(pos !=CARD_NOT_FOUND)
   {
      	ReadCardDataFromFlashBlock(1,pos,&empcard);
         PrintCardData(empcard);
   }
	pos = BlockCardSearch(5,5);
   if(pos !=CARD_NOT_FOUND)
   {
      	ReadCardDataFromFlashBlock(1,pos,&empcard);
         PrintCardData(empcard);
   }
   pos = BlockCardSearch(9,9999);
   if(pos !=CARD_NOT_FOUND)
   {
      	ReadCardDataFromFlashBlock(5,pos,&empcard);
         PrintCardData(empcard);
   }  */
//#endif
//}



//==============================================================================
// This function writes Card data to Flash memory and as this is page write so we have to read page and
// then modiy that page with new data and write.
unsigned char WriteCardDataToFlashBlock(unsigned char block,unsigned int cardpos,struct CARD_DATA empcard)
{				                 //(block no.(0 to 9),Card position(0 to 1199 for 12000 cards), EmpCard)
unsigned int cardpage;//actual or physical page of card to be written
unsigned int CardPageInBlock;//this range from 0 onwards,it gives index of page in which this card must be written in this block
unsigned int CardPosInPage;//actual or physical location of byte in page for writting card
struct CARD_FLASH_DB cardflash;
	F_FlashSelect=0;

   	if(block >= MAX_CARD_BLOCKS)
   		return(1);
   	if(cardpos>CardMemHashTable[block].MaxCards)
   		return(1);

	if(cardpos == 0)//ARMD0398 
	{
		CardPageInBlock = 0;
		CardPosInPage = 0;
	}
	else
	{
//		CardPageInBlock = (int) ( (long)( ( (long)cardpos*(long)CARD_FLASH_DB_BYTES )+CARD_FLASH_DB_BYTES ) / FLSH_APP_PAGE_SZ);//taking care of fractional value
		CardPageInBlock = (unsigned int) (cardpos/MAX_CARD_PER_PAGE) ;
		CardPosInPage = cardpos - CardPageInBlock*MAX_CARD_PER_PAGE;//find card slot position
		CardPosInPage *= CARD_FLASH_DB_BYTES;//find card byte position for card.
	}
	cardpage = CardMemHashTable[block].StartPageNo+ CardPageInBlock;

	MainMem_ReadPage(cardpage,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);

   	cardflash.CardNo  = empcard.CardNo;
   	cardflash.CardPin = empcard.CardPin;
	cardflash.APB     = empcard.CardInfo.APB;
	cardflash.TZ1     = empcard.CardInfo.Door1;
	cardflash.TZ2     = empcard.CardInfo.Door2;
	cardflash.Holiday = empcard.CardInfo.Holiday;
	cardflash.MesgInfo= empcard.Info.MesgInfo;
#ifdef EN_CARD_EXP_DATE
   	cardflash.ExpDT	  = empcard.ExpDT;
#endif
	cardflash.CType   = empcard.Info.CType;
#ifdef EN_DOORACCESS
	cardflash.DrAccess = empcard.DoorAccess;	//ARMF2002://Implement DoorAccess
#endif//#endif EN_DOORACCESS
	cardflash.Group = empcard.Info.Group;
	memcpy(&tempwrbuf[CardPosInPage],(BYTE*)&cardflash, CARD_FLASH_DB_BYTES);

//	if(block ==0)
//	{
//		MsgPrint(MSG_MEM,empcard.CardNo,"card No.=");
//		MsgPrint(MSG_MEM,cardpage,"cardpage=");
//		MsgPrint(MSG_MEM,CardPageInBlock,"CardPageInBlock=");
//		MsgPrint(MSG_MEM,CardPosInPage,"Byte=");
//		MsgPrint(MSG_MEM,cardpos,"cardpos=");
//	}
	
	MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
	BuffWrt_MainMem(cardpage,1);

//	MsgPrint(MSG_MEM,cardpos,"WriteCardDataToFlash pos= ");
//	MsgPrint(MSG_MEM,cardpage,"WriteCardDataToFlash: cardpage= ");
//	MsgPrint(MSG_MEM,cardpage+CardMemHashTable[block].StartPageNo,"WriteCardDataToFlash: FlashPage= ");
	return(0);
}

//============================================================================================================
// Following function is for APB info to be written to acard and we will change only APB info
unsigned char WriteCardDataForAPBToFlashBlock(unsigned char block,unsigned int cardpos,struct CARD_DATA empcard)
{				                 //(block no.(0 to 9),Card position(0 to 1199 for 12000 cards), EmpCard)
unsigned int cardpage;//actual or physical page of card to be written
unsigned int CardPageInBlock;//this range from 0 onwards,it gives index of page in which this card must be written in this block
unsigned int CardPosInPage;//actual or physical location of byte in page for writting card
struct CARD_FLASH_DB cardflash;
	
	F_FlashSelect=0;
   	if(block >= MAX_CARD_BLOCKS)
   		return(1);
   	if(cardpos>CardMemHashTable[block].MaxCards)
   		return(1);

	if(cardpos == 0)//ARMD0398 
	{
		CardPageInBlock = 0;
		CardPosInPage = 0;
	}
	else
	{
//		CardPageInBlock = (int) ( (long)( ( (long)cardpos*(long)CARD_FLASH_DB_BYTES )+CARD_FLASH_DB_BYTES ) / FLSH_APP_PAGE_SZ);//taking care of fractional value
		CardPageInBlock = (unsigned int) (cardpos/MAX_CARD_PER_PAGE) ;
		CardPosInPage = cardpos - CardPageInBlock*MAX_CARD_PER_PAGE;//find card slot position
		CardPosInPage *= CARD_FLASH_DB_BYTES;//find card byte position for card.
	}
	cardpage = CardMemHashTable[block].StartPageNo+ CardPageInBlock;
	MainMem_ReadPage(cardpage,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
  	memcpy((BYTE*)&cardflash,&tempwrbuf[CardPosInPage],CARD_FLASH_DB_BYTES);
	if(cardflash.CardNo == empcard.CardNo)
	{
		cardflash.APB = empcard.CardInfo.APB;
		memcpy(&tempwrbuf[CardPosInPage],(BYTE*)&cardflash, CARD_FLASH_DB_BYTES);	
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		BuffWrt_MainMem(cardpage,1);
		return(0);
	}
	else
	{//card number doesn't match
		return(1);
	}

}

//========================================SPL==============================================	//281210-2
//This Function will writes spl card data to Flash memory
/*** BeginHeader WriteSplCardDataToFlashBlock*/
unsigned char WriteSplCardDataToFlashBlock(unsigned int cardpos,struct SPL_CARD_DATA empcard);
/*** EndHeader */
unsigned char WriteSplCardDataToFlashBlock(unsigned int cardpos,struct SPL_CARD_DATA empcard)
{
//unsigned char *infoptr;
unsigned int cardpage,cardposblock;
struct SPL_CARD_DATA cardflash;
	F_FlashSelect=0;

   	if(cardpos > MAX_SPL_CARD)
		return(1);
   	cardposblock = (int)((long)((long)cardpos * (long)SPL_CARDDATA_BYTES) / FLSH_APP_PAGE_SZ );
   	cardpage = FL_SPL_CARDDATA_PAGE_NO;

	MainMem_ReadPage(cardpage,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
     // Now we have full page of card data in memory where we have to store our card.

	cardflash.CardNo = empcard.CardNo;
	cardflash.CardType = empcard.CardType;
	cardflash.CardInfo = empcard.CardInfo;
	cardflash.ExtraInfo = empcard.ExtraInfo;

// 	memcpy(&tempwrbuf[(cardpos*SPL_CARDDATA_BYTES) - (cardposblock*256)],(unsigned char*)&cardflash,SPL_CARDDATA_BYTES);
	memcpy(&tempwrbuf[(cardpos*SPL_CARDDATA_BYTES) - (cardposblock*FLSH_APP_PAGE_SZ)],(BYTE*)&cardflash, SPL_CARDDATA_BYTES);
//   sf_writeRAM(tempwrbuf11,0,256);
//   sf_RAMToPage(cardpage);
	MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
	BuffWrt_MainMem(cardpage,1);

   	MsgPrint(MSG_MEM,cardpos,"WriteSplCardDataToFlash pos= ");
	MsgPrint(MSG_MEM,cardpage,"WriteSplCardDataToFlash: RamPage= ");
	MsgPrint(MSG_MEM,cardpage+((cardpos*SPL_CARDDATA_BYTES) - (cardposblock*256)),"WriteSplCardDataToFlash: FlashPage= ");
	return(0);
}

//=============================================================================================================

unsigned char ReadCardDataFromFlashBlock(unsigned char block,unsigned int cardpos,struct CARD_DATA *empcard1)
{
unsigned int cardpage,CardPageInBlock;
struct CARD_FLASH_DB cardflash;
unsigned int CardPosInPage;//actual or physical location of byte in page for writting card
	F_FlashSelect=0;

   	if(block >= MAX_CARD_BLOCKS)
   		return(1);
   	if(cardpos > CardMemHashTable[block].MaxCards)
   		return(1);

	if(cardpos == 0)//ARMD0398 
	{
		CardPageInBlock = 0;
		CardPosInPage = 0;
	}
	else
	{
//   	CardPageInBlock = (int)((long)((long)cardpos * (long)CARD_FLASH_DB_BYTES) / FLSH_APP_PAGE_SZ);
		CardPageInBlock = (unsigned int) (cardpos/MAX_CARD_PER_PAGE) ;
		CardPosInPage = cardpos - CardPageInBlock*MAX_CARD_PER_PAGE;//find card slot position
		CardPosInPage *= CARD_FLASH_DB_BYTES;//find card byte position for card.
	}
   	cardpage = CardMemHashTable[block].StartPageNo + CardPageInBlock;
 
 	MainMem_ReadPage(cardpage,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);  	
//	memcpy((unsigned char *) &cardflash, &tempwrbuf[(cardpos*CARD_FLASH_DB_BYTES) - (CardPageInBlock*FLSH_APP_PAGE_SZ)],CARD_FLASH_DB_BYTES);   				  
	memcpy((unsigned char *) &cardflash, &tempwrbuf[CardPosInPage],CARD_FLASH_DB_BYTES);   				  
	empcard1->CardNo = cardflash.CardNo  ;
   	empcard1->CardPin = cardflash.CardPin ;
   	empcard1->CardInfo.APB = cardflash.APB    ;
	empcard1->CardInfo.Door1 = cardflash.TZ1;
	empcard1->CardInfo.Door2 = cardflash.TZ2;
	empcard1->CardInfo.Holiday = cardflash.Holiday ;
	empcard1->Info.MesgInfo = cardflash.MesgInfo;
#ifdef EN_CARD_EXP_DATE
   	empcard1->ExpDT = cardflash.ExpDT;
#endif
	empcard1->Info.CType = cardflash.CType;
	empcard1->Info.Group = cardflash.Group;
#ifdef EN_DOORACCESS
	empcard1->DoorAccess = cardflash.DrAccess;		 //ARMF2002://Implement DoorAccess
#endif//#endif EN_DOORACCESS

	//MsgPrint(MSG_MEM,cardpos,"ReadCardDataFromFlashBlock pos= ");
//	MsgPrint(MSG_MEM,cardpage,"ReadCardDataFromFlashBlock: cardpage= ");
//	MsgPrint(MSG_MEM,cardpage+CardMemHashTable[block].StartPageNo,"ReadCardDataFromFlashBlock: FlashPage= ");
	return(0);
}

void PrintCardData(CardData *empcard)
{
	MsgPrint(MSG_MEM,empcard->CardNo,"CardNo=");
	MsgPrint(MSG_MEM,empcard->CardPin,"Pin=");
	MsgPrint(MSG_MEM,empcard->CardInfo.Door1,"Door1");
} 

//=============================================================================================================
/* this searches card in perticular block and return index(starting from 0 to max card in block) of that card .
*/
int BlockCardSearch(unsigned char block,CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_FLASH_DB *cardflash)
{
	WORD maxcards;
   	WORD i,temp1,pageno;
	F_FlashSelect=0;
   	temp1 = 0;
   	maxcards = CardMemHashTable[block].MaxCards;
   	pageno = CardMemHashTable[block].StartPageNo;
	while(temp1 < maxcards)
	{
		MainMem_ReadPage(pageno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);  	
		for(i=0;i<MAX_CARD_PER_PAGE;i++)
		{
			memcpy((unsigned char *)cardflash, &tempwrbuf[i*CARD_FLASH_DB_BYTES],CARD_FLASH_DB_BYTES);
			if(cardflash->CardNo== cardno)
				return(temp1);
			temp1++;
			if(temp1>=maxcards)
				return(CARD_NOT_FOUND);
		}
		pageno++;
#ifdef ENABLE_WATCHDOG
		if( (temp1%100) == 0)  			 
			WDTFeed();
#endif
	}
	return(CARD_NOT_FOUND);
}
//=========================SPL CARD SEARCH==============================//
/*** BeginHeader SpecialCardSearch*/
int SpecialCardSearch(CARDNO_DATA_STORAGE_TYPE cardno);
/*** EndHeader */
int SpecialCardSearch(CARDNO_DATA_STORAGE_TYPE cardno)
{
//Following function will search and read the card data from the flash and store it into struct SpecialCardData
int temp1;
//struct SPL_CARD_DATA RAMSplcard;
//unsigned long rampos;
	F_FlashSelect=0;
   temp1 = 0;
   MainMem_ReadPage(FL_SPL_CARDDATA_PAGE_NO, 0,(BYTE* )&tempwrbuf ,FLSH_APP_PAGE_SZ);  // Now we have full page of card data in memory where we have to store our card.
	while(temp1 < MAX_SPL_CARD)
   	{
		memcpy((unsigned char *)&SpecialCardData,&tempwrbuf[temp1*(sizeof(struct SPL_CARD_DATA))],sizeof(struct SPL_CARD_DATA));
		if(cardno == SpecialCardData.CardNo)
			return(temp1);
		temp1++;
   	}
   	return(-1);  // return spl card inidex no.		  
}

//=============Special card search by Index=======================	//281210-2
/*** BeginHeader SplCardSearchByIndex*/
int SplCardSearchByIndex(unsigned int index);
/*** EndHeader */
int SplCardSearchByIndex(unsigned int index)
{
	F_FlashSelect=0;
	if(index > MAX_SPL_CARD)
   		return(CARD_NOT_FOUND);
   	MainMem_ReadPage(FL_SPL_CARDDATA_PAGE_NO, 0,(BYTE* )&tempwrbuf ,FLSH_APP_PAGE_SZ);  // Now we have full page of card data in memory where we have to store our card.
   	memcpy((unsigned char *)&SpecialCardData,&tempwrbuf[index*(sizeof(struct SPL_CARD_DATA))],sizeof(struct SPL_CARD_DATA));
	if(SpecialCardData.CardNo == 0)
   		return(CARD_NOT_FOUND);
   	return((int)index);
}

//=============================================================================================================
/* this searches card in full memory and return index(starting from 0 to total max card) of that card .
*/
int CardSearch(CARDNO_DATA_STORAGE_TYPE Cardno)
{
	int tempret;
	struct CARD_FLASH_DB cardflash;
	F_FlashSelect=0;
   	tempret = BlockCardSearch((unsigned char)(Cardno%10),Cardno,&cardflash);
   	if(tempret == CARD_NOT_FOUND)
   		return(CARD_NOT_FOUND);
	tempret = tempret+(unsigned char)(Cardno%10)*MAX_CARD_PER_BLOCK ;
	return(tempret);
}

//=============================================================================================================
int SearchDisplayCard(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)
{
	struct CARD_FLASH_DB cardflash;
	int temp;
	F_FlashSelect=0;
   if(cardno !=0)
   { 	
   		temp = BlockCardSearch((unsigned char)(cardno%10),cardno,&cardflash);
	   if(temp == CARD_NOT_FOUND)
	   {
	      MsgPrint(MSG_WARNING,temp,"SearchDisplayCard:Card not found ptr=");
	      return(CARD_NOT_FOUND);
	   }
	   else
	   {
			empcard->CardNo 	= cardflash.CardNo;
		   	empcard->CardPin 	= cardflash.CardPin;
		   	empcard->CardInfo.APB 	= cardflash.APB;
			empcard->CardInfo.Door1 = cardflash.TZ1;
			empcard->CardInfo.Door2 = cardflash.TZ2;
			empcard->CardInfo.Holiday 	= cardflash.Holiday;
			empcard->Info.MesgInfo 		= cardflash.MesgInfo;	
			empcard->Info.CType = cardflash.CType;
#ifdef EN_CARD_EXP_DATE
		   	empcard->ExpDT = cardflash.ExpDT;
#endif		
            empcard->Info.Group = cardflash.Group;	
#ifdef EN_DOORACCESS 			
			empcard->DoorAccess	= cardflash.DrAccess;		 //ARMF2002://Implement DoorAccess
#endif//#endif EN_DOORACCESS
      		MsgPrint(MSG_WARNING,temp,"SearchDisplayCard:Card found ptr=");
	   }
      	temp = temp + (unsigned char)(cardno%10)*MAX_CARD_PER_BLOCK;
     	return(temp);
   }
   return(CARD_NOT_FOUND);
}

//=====================================================================================================
int AddCard(struct CARD_DATA empcard)   // Add card Return card no from start of Add card base page no
{
unsigned char block;
int temp;
struct CARD_FLASH_DB cardflash;
	F_FlashSelect=0;

	MsgPrint(MSG_WARNING,empcard.CardNo,"AddCard:Card No is=");
   	block	= (unsigned char)(empcard.CardNo%10);
   	temp 	= BlockCardSearch(block,empcard.CardNo,&cardflash);	//return value range is from 0 t0 ...in that block
	if(temp == CARD_NOT_FOUND)
	{
		temp = BlockCardSearch(block,0,&cardflash);
		if(temp == CARD_NOT_FOUND)
		{
         	MsgPrint(MSG_WARNING,temp,"AddCard:No mem for card add ptr=");
         	return(-1);
		}
		MsgPrint(MSG_WARNING,temp,"AddCard:New card to be added ptr=");
		TotalCards++;
	}
	//MsgPrint(MSG_WARNING,empcard.CardNo,"AddCard:Card No is=");
   WriteCardDataToFlashBlock(block,temp,empcard);
   MsgPrint(MSG_WARNING,temp,"AddCard:Card updated Loc=");
   temp = temp + (block*MAX_CARD_PER_BLOCK);
   return(temp);
}

//=====================================================================================================
int DelCard(struct CARD_DATA empcard)
{
int temp,spltemp;
unsigned int nameloc;
unsigned char block;
struct CARD_FLASH_DB cardflash;
	F_FlashSelect=0;

   block = (unsigned char)(empcard.CardNo%10);
   temp = BlockCardSearch(block,empcard.CardNo,&cardflash);
	if(temp == CARD_NOT_FOUND)
	{
		MsgPrint(MSG_WARNING,temp,"DelCard:Card Not found");
	 	return(CARD_NOT_FOUND);
	}
	else
	{
   		MsgPrint(MSG_WARNING,temp,"DelCard:Card found");
#ifdef SUPPORT_NSERIES2
//============SPL Card Search to Delete===============	//281210-2
		if(cardflash.Holiday & CARD_BIT_SPECIAL_CARD)
		{
			spltemp = SpecialCardSearch(empcard.CardNo);     //Search Special card
			if(spltemp != CARD_NOT_FOUND)
				DelSplCard(spltemp);
		}
//====================================================
#endif
		memset((unsigned char *)&empcard,0,sizeof(empcard));
		nameloc = temp + (block * MAX_CARD_PER_BLOCK);
      	AddCardNameToFlash(nameloc,"                ");
		MsgPrint(MSG_WARNING,empcard.CardNo,"DelCard:empcard.CardNo");
      	WriteCardDataToFlashBlock(block,temp,empcard);
      	TotalCards--;
      	MsgPrint(MSG_WARNING,temp,"DelCard:Card Deleted");
 	}
  	return(temp);
}

//==================================Delete SPL Card==========================	//281210-2
/*** BeginHeader DelSplCard*/
int DelSplCard(int temp);
/*** EndHeader */
int DelSplCard(int temp)	//ARMF0285
{
	char status;
	struct SPL_CARD_DATA empcard;
	F_FlashSelect=0;
	
	empcard.CardNo = 0;
	empcard.CardType = 0;
	empcard.CardInfo = 0;
	empcard.ExtraInfo = 0;
	status = WriteSplCardDataToFlashBlock(temp,empcard);  //temp = card position
	TotalSplCards--;
	return((int)status);
}
/*** BeginHeader DelOnlySplCard*/		//281210-2
int DelOnlySplCard(CARDNO_DATA_STORAGE_TYPE CardNo);
/*** EndHeader */
int DelOnlySplCard(CARDNO_DATA_STORAGE_TYPE CardNo)//ARMF0285 //ARMD0295 
{
	//This function will delete SPL card info from Flash memory and the card now work as normal card
	unsigned char block,err;
	int temp;
	struct CARD_FLASH_DB cardflash;
	//First Search Card in card database if it is not then send Error
	F_FlashSelect=0;
	block = (unsigned char)(CardNo%10);
	temp = BlockCardSearch(block,CardNo,&cardflash);
	if(temp == CARD_NOT_FOUND)
		return(-1);
//	err = ReadCardDataFromFlashBlock(block,temp,&Carddata);//read normal card from flash block to update //ARMD0295 
//	if(err != 0)
//		return(-1);
	//Special card bit in holiday byte becomes disable(0)
//	Carddata.CardInfo.Holiday = (Carddata.CardInfo.Holiday & 0x7F);
//	err = WriteCardDataToFlashBlock(block,temp,Carddata);
//	if(err != 0)
//		return(-1);
	
	MsgPrint(MSG_WARNING,CardNo,"DelOnlySplCard:Card No is=");
	temp = SpecialCardSearch(CardNo);
	
	if(temp == CARD_NOT_FOUND)
		return(-1);
	
	err = DelSplCard(temp);
	return(err); 	//error becomes 0 or 1
}

//==============================================================================
// Following function gets card number from perticular index in card memory
// This function returns total no of cards read to get that index card
// if we give index no as 0xFFFF which is not possible as total noof cards is less than 0xFFFF so it will read memory for
// all programmed card which is nothing but total noof cards
//==============================================================================
/*** BeginHeader GetCardByIndexNo*/
int GetCardByIndexNo(int index,struct CARD_DATA *empcard);
/*** EndHeader */
int GetCardByIndexNo(int index,struct CARD_DATA *empcard)
{
	int cardpos,totalcards;
   	unsigned char block;
   	totalcards = 0;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_GET_CARD_BY_INDEXNO;
#endif
   	for(block=0;block<MAX_CARD_BLOCKS;block++)
   	{
   		for(cardpos=0;cardpos<CardMemHashTable[block].MaxCards;cardpos++)
      	{
			ReadCardDataFromFlashBlock(block,cardpos,empcard);
	      	if(empcard->CardNo!=0)
	      	{
	         	index--;
	         	totalcards ++;
	      	}			
      		if(index == 0)
         	{
      			return(0);
         	}
#ifdef ENABLE_WATCHDOG
			if(!(cardpos % 100))
				WDTFeed();		//Clear watchdog timer
#endif
      }
	}
	return(totalcards);
}

/***************************************************************************/
/*** BeginHeader GetCardByIndexNo*/
int GetTotalNumberOfCards(void);
/*** EndHeader */
int GetTotalNumberOfCards(void)
{
//struct CARD_DATA *empcard;  THIS IS BAD .. This will cause memory overwrite :-(
// This can not be pointer as pointer needs memory :-(
struct CARD_FLASH_DB tempcard;
int maxcards,i,pageno,temp1;
int totalcards;
char blocksearch=0;
	totalcards=0x00;
	F_FlashSelect=0;
 	for(blocksearch=0;blocksearch<=MAX_CARD_BLOCKS;blocksearch++)
	{
	   	maxcards = CardMemHashTable[blocksearch].MaxCards; //max card in this block, there are 10 blocks
	   	pageno = CardMemHashTable[blocksearch].StartPageNo;//start page no. of this block
		temp1=0x00;
		while(temp1 < maxcards)
		{
			MainMem_ReadPage(pageno,0,(unsigned char * )&tempwrbuf,FLSH_APP_PAGE_SZ);  	
			for(i=0;i<MAX_CARD_PER_PAGE;i++)
			{
				memcpy((unsigned char *)&tempcard, &tempwrbuf[i*CARD_FLASH_DB_BYTES],CARD_FLASH_DB_BYTES);
				if(tempcard.CardNo != 0x00000000L)
					totalcards ++;
				temp1++;
			}
			pageno++;
#ifdef ENABLE_WATCHDOG
			if(!(temp1%30))
				WDTFeed();		//Clear watchdog timer
#endif
		}//while(temp1 < maxcards)
	}
	return(totalcards);	
}
/***************************************************************************/

/*-------------------------------------------------------------------------*/
/*** BeginHeader DelAllCards*/
void DelAllCards(void);
/*** EndHeader */
void DelAllCards(void)
{
//unsigned char block;
unsigned int cardpage,cardpos=0;//,oldcardpage,cardposblock;

	if( !(InitialiseFlags & DELETE_ALL_CARDS) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_CARDS;
	F_FlashSelect=0;

#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_DEL_ALL_CARDS;
#endif	
	memset(tempwrbuf,0,FLSH_APP_PAGE_SZ);	
	for(cardpage=FL_CARDDATA_PAGE_NO; cardpage<=(MAX_PAGES+FL_CARDDATA_PAGE_NO); cardpage++)
	{				    
			MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
			BuffWrt_MainMem(cardpage,1);
#ifdef ENABLE_WATCHDOG
			if((cardpos%80) == 0)	// NGD00080 
				WDTFeed();		//Clear watchdog timer
#endif
	}
	
/*	for(block=0;block<MAX_CARD_BLOCKS;block++)
	{
   		oldcardpage = 0;
    	for(cardpos=0;cardpos<CardMemHashTable[block].MaxCards;cardpos++)
		{
			cardposblock = (int) ( (long)((long)cardpos * (long) CARD_FLASH_DB_BYTES)  /FLSH_APP_PAGE_SZ);
   			cardpage = CardMemHashTable[block].StartPageNo+ cardposblock;
         	if(oldcardpage!=cardpage)
         	{
				oldcardpage=cardpage;
		      	memset(tempwrbuf,0,FLSH_APP_PAGE_SZ);	
				MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
				BuffWrt_MainMem(cardpage,1);
         	}
#ifdef ENABLE_WATCHDOG
			if(!(cardpos%100))
				WDTFeed();		//Clear watchdog timer
#endif
		}
   }*/
   TotalCards = 0;
   return;
}

//====================================SPL Card Delete=======================================	//281210-2
/*** BeginHeader DelAllSplCard*/
void DelAllSplCard(void);
/*** EndHeader */
void DelAllSplCard(void)
{
	unsigned int cardposblock,cardpos;
    struct SPL_CARD_DATA cardflash;

	if( !(InitialiseFlags & DELETE_ALL_SPL_CARD) )	//ARMF0377
		return ;			
	F_FlashSelect=0;
	InitialiseFlags &= ~DELETE_ALL_SPL_CARD ;
 	for(cardpos=0x00;cardpos<MAX_SPL_CARD;cardpos++)
   	{
	   	cardposblock = (int)((long)((long)cardpos * (long)SPL_CARDDATA_BYTES) / FLSH_APP_PAGE_SZ );
	    cardflash.CardNo    = 0x00;
	    cardflash.CardType  = 0x00;
		cardflash.CardInfo  = 0x00;
		cardflash.ExtraInfo = 0x00;
		memcpy(&tempwrbuf[(cardpos*SPL_CARDDATA_BYTES) - (cardposblock*FLSH_APP_PAGE_SZ)],(BYTE*)&cardflash, SPL_CARDDATA_BYTES);
	}
	MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);	   //ARMD0459
	BuffWrt_MainMem(FL_SPL_CARDDATA_PAGE_NO,1);
   	TotalSplCards = 0;
	return;
}

/*** BeginHeader GetCardByLocation*/
int GetCardByLocation(unsigned int loc,struct CARD_DATA *empcard);
/*** EndHeader */
int GetCardByLocation(unsigned int loc,struct CARD_DATA *empcard)
{
	if(loc>(MAX_CARD_PER_BLOCK*MAX_CARD_BLOCKS))
		return(0xFFFFFFFF);			// We will support card more than 1L then we need this

	if( ReadCardDataFromFlashBlock(loc/MAX_CARD_PER_BLOCK,loc%MAX_CARD_PER_BLOCK,empcard)==1)
		return(0xFFFFFFFF);
 	if(empcard->CardNo==0)//IF we search card with card number as '0' then return 0xfffffffe
   		return(0xFFFFFFFE);
   else
   		return(loc);
}


/*
unsigned char ReadCardNoFromFlash(unsigned int cardpos,struct CARD_DATA *empcard);
unsigned char ReadCardNoFromFlash(unsigned int cardpos,struct CARD_DATA *empcard)
{
unsigned int cardpage,pagepos;
	cardpage = (unsigned int) (cardpos/MAX_CARD_PER_PAGE);
   	//cardpage = (int)((long)((long)cardpos * (long) CARD_DATA_BYTES)  /FLSH_APP_PAGE_SZ); 	
	MainMem_ReadPage(cardpage,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);  
//  	sf_pageToRAM(FL_CARDDATA_PAGE_NO+cardpage);
//		sf_readRAM(tempwrbuf11, 0, 256);
	pagepos = (unsigned int)((cardpos* (long)CARD_DATA_BYTES) %FLSH_APP_PAGE_SZ );
	if((pagepos + CARD_DATA_BYTES) >FLSH_APP_PAGE_SZ)
   {
   	// Read next page
//	  	sf_pageToRAM(FL_CARDDATA_PAGE_NO+cardpage+1);
	    //sf_readRAM(&tempwrbuf11[256],0,CARD_DATA_BYTES );
		MainMem_ReadPage(cardpage,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ); 
   }
   memcpy((unsigned char *) empcard,&tempwrbuf[pagepos],CARD_DATA_BYTES);
//	printf(" ReadCardNoFromFlash cardpos %d pagepos %d Flash Page no %d   \n",cardpage,pagepos,FL_CARDDATA_PAGE_NO+cardpage);
return(0);
} */

/*** BeginHeader SearchCardFromFlash*/
int SearchCardFromFlash(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)    ;
/*** EndHeader */
int SearchCardFromFlash(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)
{
	return(SearchDisplayCard(cardno,empcard));
}

/*** BeginHeader HandleAPBSetting*/
unsigned char HandleAPBSetting(unsigned char rdno,unsigned int cardptr,struct CARD_DATA carddata);
/*** EndHeader */
unsigned char HandleAPBSetting(unsigned char rdno,unsigned int cardptr,struct CARD_DATA carddata)
{
int tdata;
	cardptr = cardptr - (unsigned char)(carddata.CardNo%10)*MAX_CARD_PER_BLOCK;
	MsgPrint(MSG_WARNING,carddata.CardInfo.APB,"my:HandleAPBSetting:APB");
	if(Doorinfo.APBEANABLE & BIT_APB_CHK && (F_Spl_Crd_Dr_open == CLR)) 	//FA00087
	{
		if(ReaderInfo[rdno].APBEnDis == SET)
		{
			if(Doorinfo.APBEANABLE & BIT_AREAWISE_APB_CHK)
			{
//This is Area wise APB setting in which we check reader connectivity and check APB depending on reader location and nexting of APB is check in this
//To do this we check user last access reader which gives us current location ( from reader information database AreaTo field) of user in area number
//and now we check on which reader card is swiped and if this reader AreaFrom marches to old reader Area To then we provide access grant else this is
//access denied. If last reader access field is zero then we treat this as new user and he is allowed to access the area.
				if(((F_DoNotCheckAPBForCard == 1) && ((rdno+1) == SpecialCardRdNo)) ||	\
					(carddata.CardInfo.APB == APB_NOWHERE_USERWISE_CHK) ||				\
					(carddata.CardInfo.APB == APB_NOWHERE_USERWISE_NOCHK) ||			\
					(carddata.CardInfo.APB & APB_NO_CHK)) //FA00130
					goto GOTO_HandleAPB;
				if(carddata.CardInfo.APB > MAX_READERS_SUPPORT+1)
					goto GOTO_HandleAPB;
				else
				{
//          		carddata.CardInfo.APB = carddata.CardInfo.APB-1;
					if(ReaderInfo[rdno].AreaNoFrom == ReaderInfo[carddata.CardInfo.APB].AreaNoTo)
						goto GOTO_HandleAPB;
					else
					{
						MsgPrint(1,rdno,"RDR:APB Error=");
						MsgPrint(1,ReaderInfo[rdno].AreaNoFrom,"RDR:APB Error New Area=");
						MsgPrint(1,ReaderInfo[rdno].AreaNoTo,"RDR:APB Error Old Area=");
						HandleDisplayErrorMessages(APB_Err);
						return(APB_Err);
					}
				}
			}
			else
			{
				if(((F_DoNotCheckAPBForCard == 1) && ((rdno+1) == SpecialCardRdNo)) ||	\
					(carddata.CardInfo.APB == APB_NOWHERE_USERWISE_CHK) ||				\
					(carddata.CardInfo.APB == APB_NOWHERE_USERWISE_NOCHK) ||			\
					(carddata.CardInfo.APB & APB_NO_CHK))		// FA00130
					goto GOTO_HandleAPB;
				if(carddata.CardInfo.APB%2 != rdno%2)
					goto GOTO_HandleAPB;
				else
				{
					MsgPrint(1,rdno,"RDR:APB Error=");
//					PlaySoundMsg(APB_ERROR);
					if(rdno == 0)
						HandleDisplayErrorMessages(APB_Err);					
					return(APB_Err);
				}
			} 
		}
		else
		{
// APB is not required for this reader but we have to write current reader info in to card APB field
			goto GOTO_HandleAPB;
		}
	}
	return(0);
	
GOTO_HandleAPB:
	if((rdno+1) == SpecialCardRdNo)       	// FA00130
		F_DoNotCheckAPBForCard = CLR;
	if(carddata.CardInfo.APB & APB_NO_CHK)
		carddata.CardInfo.APB = APB_NO_CHK | rdno;
	else
		carddata.CardInfo.APB = rdno;	
	if(WriteCardDataForAPBToFlashBlock((unsigned char)(carddata.CardNo%10),cardptr,carddata)!=0)
	{
		MsgPrint(1,1,"APB:card not matched1");

		tdata = SearchDisplayCard(carddata.CardNo,&carddata);
		cardptr = tdata;
		cardptr = cardptr - (unsigned char)(carddata.CardNo%10)*MAX_CARD_PER_BLOCK;
		if(carddata.CardInfo.APB & APB_NO_CHK)
			carddata.CardInfo.APB = APB_NO_CHK | rdno;
		else
			carddata.CardInfo.APB = rdno;
		if(WriteCardDataForAPBToFlashBlock((unsigned char)(carddata.CardNo%10),cardptr,carddata)!=0)
		{
//			MsgPrint(1,carddata.CardNo,"APB:card not matched2");
//			CurrentInputType = LOG_TYPE_INTERNAL;
//			LogData(carddata.CardNo ,rdno ,EVENT_LOGGING ,LOG_APB_ERROR);
		
			return(APB_Err);			
		}
	}
	MsgPrint(1,rdno,"Just save APB data=");
//	tmpRAMcard.CardNo = carddata.CardNo;
//	tmpRAMcard.APB = carddata.CardInfo.APB;
//	tmpRAMcard.AccessTime ++;
//	WriteCardDataToRamPos((unsigned char)(carddata.CardNo%10),cardptr,&tmpRAMcard);
//	MsgPrint(1,rdno,"APB OK so allow access=");
	return(0);
}

//------------------------------------------------------------------------------
// Following function will write Name to Flash we have to give Page index to write same.
/*** BeginHeader AddCardNameToFlash*/
unsigned char AddCardNameToFlash(unsigned int cardindex,BYTE *name);
/*** EndHeader */
unsigned char AddCardNameToFlash(unsigned int cardindex,BYTE *name)
{
WORD cpos;

#ifdef SUPPORT_NAME_FROM_FLASH
unsigned int cardnamepno;
struct CARD_EXTRA_INFO	 CardExtraInfo;
	F_FlashSelect=0;
if(cardindex <= MAX_NO_OF_CARD)	  
{	
		cardnamepno = FL_CARD_EXTRA_DATA_PAGE_NO + cardindex/EXDATA_CARDS_PERPAGE; // (CARD_EXTRA_DATA_BYTES * cardindex)/FLSH_APP_PAGE_SZ;
		MainMem_ReadPage(cardnamepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);	
		cpos = ((cardindex%EXDATA_CARDS_PERPAGE));//CARD_EXTRA_DATA_BYTES)%FLSH_APP_PAGE_SZ); //
	
		memcpy((unsigned char*)&CardExtraInfo,&tempwrbuf[cpos*CARD_EXTRA_DATA_BYTES],CARD_EXTRA_DATA_BYTES);
		memcpy((unsigned char*)&CardExtraInfo.Name,name,CARD_NAME_BYTES );
		memcpy((char *)&tempwrbuf[cpos*CARD_EXTRA_DATA_BYTES],(unsigned char*)&CardExtraInfo,CARD_EXTRA_DATA_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		BuffWrt_MainMem(cardnamepno,1);
		MsgPrint(MSG_WARNING,cardindex,"AddCardNameToFlash: cardindex  =");
      	return(0);
}	 
  /* {
   		cardnamepno = FL_CARD_NAME_PAGE_NO + (CARD_NAME_BYTES * cardindex)/FLSH_APP_PAGE_SZ;
		MainMem_ReadPage(cardnamepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
		cpos = ((cardindex*CARD_NAME_BYTES)%FLSH_APP_PAGE_SZ);
		memcpy((char *)&tempwrbuf[cpos],name,CARD_NAME_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		BuffWrt_MainMem(cardnamepno,1);
		MsgPrint(MSG_WARNING,cardindex,"AddCardNameToFlash: cardindex  =");
      	return(0);
   }*/
   else
   	return(1);
#else
	return(0);
#endif
}

// Following function will Read Name from  Flash we have to give Page index to read same.
/*** BeginHeader ReadCardNameFromFlash*/
unsigned char ReadCardNameFromFlash(unsigned int cardindex,BYTE *name);
/*** EndHeader */
unsigned char ReadCardNameFromFlash(unsigned int cardindex,BYTE *name)
{
WORD cpos;
#ifdef SUPPORT_NAME_FROM_FLASH
unsigned int cardnamepno;
	struct CARD_EXTRA_INFO	 CardExtraInfo;
	F_FlashSelect=0;
   if(cardindex <= MAX_NO_OF_CARD)		
   {
   		cardnamepno = FL_CARD_EXTRA_DATA_PAGE_NO + cardindex/EXDATA_CARDS_PERPAGE;
			MainMem_ReadPage(cardnamepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);		 
//			cpos = ((cardindex*CARD_NAME_BYTES)%(FLSH_APP_PAGE_SZ));
			cpos = ((cardindex%EXDATA_CARDS_PERPAGE));		 
			memcpy((unsigned char*)&CardExtraInfo,(char *)&tempwrbuf[cpos*CARD_EXTRA_DATA_BYTES],CARD_EXTRA_DATA_BYTES);
			memcpy(name,(unsigned char*)&CardExtraInfo.Name,CARD_NAME_BYTES );
			name[CARD_NAME_BYTES-1]='\0';		// NG0012
			MsgPrint(MSG_WARNING,cardindex,"ReadCardNameFromFlash: cardindex =");
      	return(0);
   }
   else
   {
   		memset(name,' ',CARD_NAME_BYTES);
      	name[CARD_NAME_BYTES-1]='\0';
   		return(1);
   }
#else
	name[0]='\0';
#endif
}

// Following function will Read Name from  Flash we have to give Page index to read same.
/*** BeginHeader DelAllNamesFromFlash*/
void DelAllNamesFromFlash(void);
/*** EndHeader */
void DelAllNamesFromFlash(void)
{
#ifdef SUPPORT_NAME_FROM_FLASH
unsigned int maxpages,count;//,cardnamepno;
//   maxpages = (CARD_NAME_BYTES * MAX_NO_OF_CARD)/FLSH_APP_PAGE_SZ;
	F_FlashSelect=0;
   count =maxpages= 0;
//   memset(tempwrbuf,' ',FLSH_APP_PAGE_SZ);
#ifdef ENABLE_WATCHDOG
   WDTHandleType = WDT_DEL_ALL_NAMES_FROM_FLASH;
#endif

	if( !(InitialiseFlags & DELETE_ALL_NAME_FROM_FLASH) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_NAME_FROM_FLASH ;

/*	
while(count<=10)
{	
	for(i=0;i<EXDATA_MAX_CARD_PER_BLOCK;i++)
	{
			MainMem_ReadPage(FL_CARD_EXTRA_DATA_PAGE_NO+,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
			for(j=0;j<=EXDATA_CARDS_PERPAGE;j++)
			{
					memcpy(Extradata,tempbff[i*ExtraDataByte],ExtraDataByte)
					memset(ExtraData->names,' ',Fla);
				
			}
		}
			count++
}	*/	
/*   while(count<maxpages)
   {
	   	memset(tempwrbuf,' ',FLSH_APP_PAGE_SZ);
		cardnamepno = FL_CARD_NAME_PAGE_NO + (CARD_NAME_BYTES * count)/FLSH_APP_PAGE_SZ;
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
		BuffWrt_MainMem(cardnamepno,1);
      	count++;
#ifdef ENABLE_WATCHDOG
		if(!(count % 100))
		  	WDTFeed();
#endif
   }   */
#endif
}

/*** BeginHeader AddCard_Loc*/
int AddCard_Loc(int loc,struct CARD_DATA empcard);
/*** EndHeader */
int AddCard_Loc(int loc,struct CARD_DATA empcard)
{
	if(loc>(MAX_CARD_PER_BLOCK*MAX_CARD_BLOCKS))
		return(-1);
   if(loc == -1)
   		return(-1);
   WriteCardDataToFlashBlock(loc/MAX_CARD_PER_BLOCK,loc%MAX_CARD_PER_BLOCK,empcard);
   MsgPrint(MSG_WARNING,0,"AddCard:Card updated Loc=");
   return(loc);
}

//===============================================================================================
/*** BeginHeader AddCardAtLastAddedLoc*/
int AddCardAtLastAddedLoc(struct CARD_DATA empcard);
/*** EndHeader */
int AddCardAtLastAddedLoc(struct CARD_DATA empcard)
{
  	return(AddCard(empcard));
}

/*** BeginHeader SearchCardLastCard*/
int SearchCardLastCard(void);
/*** EndHeader */
int SearchCardLastCard(void)
{
  	return(0);
}
/*----------------------------------------------------------------------*/

//==================================ADD SPL CARD=============================================	//281210-2
/*** BeginHeader AddSpecialCard*/
int AddSpecialCard(struct SPL_CARD_DATA empcard);
/*** EndHeader */
int AddSpecialCard(struct SPL_CARD_DATA empcard)
{
unsigned char error;
int temp,tmpspl;
struct CARD_FLASH_DB cardflash;

	temp = SearchDisplayCard(empcard.CardNo,&Carddata);
  	if(temp == CARD_NOT_FOUND)
   		return(temp);
   	temp = BlockCardSearch((unsigned char)(empcard.CardNo%10),empcard.CardNo,&cardflash);
//	Special card bit in holiday byte becomes enable(1)
   Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | CARD_BIT_SPECIAL_CARD;
   Carddata.CardInfo.APB = 0;	//ARMD0274 ,other wise it works as escort card for all special card
   //Normal card now becomes spl one
	MsgPrint(MSG_WARNING,empcard.CardNo,"AddSplCard:Card No is=");
   	tmpspl = SpecialCardSearch(empcard.CardNo);
   	if(tmpspl == CARD_NOT_FOUND)
	{
		tmpspl = SpecialCardSearch(0);
		if(tmpspl == CARD_NOT_FOUND)
		{
	      MsgPrint(MSG_WARNING,tmpspl,"AddSplCard:No mem for card add ptr=");
	      return(-1);
		}
      TotalSplCards++;
   }
   WriteSplCardDataToFlashBlock(tmpspl,empcard);  //temp = card position
// If all success then write normal card to make that card spl card
   error = WriteCardDataToFlashBlock((unsigned char)(empcard.CardNo%10),temp,Carddata);
   if(error != 0)
   		return(-1);
   return(tmpspl);
}
//===========================================================================================================================
#ifdef TESTSTSTST
int AddDummyCards(int location,int offset)
{

	   	memset((unsigned char*)&Carddata,0,sizeof(Carddata));
	   	Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
		Carddata.CardInfo.Door1 = 1;
		Carddata.CardInfo.Door2 = 255;   // so it uses Access Level function.
		Carddata.CardInfo.Holiday = 0;
		Carddata.Info.MesgInfo = 5;
		Carddata.ExpDT = 0;
		Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
		Carddata.Info.Group=0;  
		Carddata.DoorAccess=0x0F;
		memset((unsigned char*)&tcardExtInfo,0,sizeof(tcardExtInfo));
		tcardExtInfo.AccessDate 	= 0;		
		tcardExtInfo.BirthDate  	= 10+(ptrdata%10);		
		tcardExtInfo.dummy = 0;
		tcardExtInfo.Image_TemplateSD_Flag = 0; // no template in sd & sensor
      	while(1)
	  	{
	      	TempTotalNosTrans --;
	      	if(ptrdata >= MAX_NO_OF_CARD)
	        	 break;
	      	Carddata.CardNo = ptrdata;
			tcardExtInfo.JoiningDate = ptrdata;
			Carddata.CardPin =0;
			Carddata.CardPin =GetCheckSum((unsigned char*)&Carddata,sizeof(Carddata));
	      	AddCard_Loc(ptrdata,Carddata);
		  	sprintf(tcardExtInfo.Name,"CN:%d",ptrdata);
			Carddata.dummy =GetCheckSum((unsigned char*)&tcardExtInfo,sizeof(tcardExtInfo));
			err = AddCardExtraData(ptrdata,&tcardExtInfo);
	      	ptrdata++;		
	      	if(TempTotalNosTrans==0)
	        	break;
#ifdef ENABLE_WATCHDOG
			if(ptrdata % 200 == 0)
				WDTFeed();		//Clear watchdog timer
#endif
	   }
}

#endif  //TESTSTSTST


#ifdef DISABLE_BELOW_CODE
	
	// Following function gets card number from perticular index in card memory
	// This function returns total no of cards read to get that index card
	// if we give index no as 0xFFFF which is not possible as total noof cards is less than 0xFFFF so it will read memory for
	// all programmed card which is nothing but total noof cards
	
	/*** BeginHeader GetCardByIndexNo1*/
	int GetCardByIndexNo1(unsigned int index,struct CARD_DATA *empcard);
	/*** EndHeader */
	int GetCardByIndexNo1(unsigned int index,struct CARD_DATA *empcard)
	{
	unsigned int temp1,totalcards;
	unsigned long tmpptr;
	   temp1 = 0;
	   totalcards = 0;
	   if(LastCardAddedPtr >  CARD_DATA_MAX)
	   	LastCardAddedPtr =CARD_DATA_MAX;
		VdHitWd(WatchDogHndl);
		while(temp1< CARD_DATA_MAX)
		{
	   	tmpptr = (long)((long)CARD_DATA_BASE+(long)((long)temp1*(long)CARD_DATA_BYTES));
	      xmem2root( (unsigned char *)empcard,tmpptr,CARD_DATA_BYTES);
	   	if(empcard->CardNo!=0)
	      {
	        	index--;
				totalcards ++;
	      }
	      if(index == 0)
	      	return(0);
			if(LastCardAddedPtr == temp1 )
				return(totalcards);
			temp1++;
		}
		return(totalcards);
	}
	
	//==============================================================================
	/*** BeginHeader CardSearch1*/
	int CardSearch1(CARDNO_DATA_STORAGE_TYPE Cardno);
	/*** EndHeader */
	int CardSearch1(CARDNO_DATA_STORAGE_TYPE Cardno)
	{
	unsigned int temp1;
	struct CARD_DATA empcard;
	   	temp1 = 0;
	   	if(LastCardAddedPtr > CARD_DATA_MAX)
	   	LastCardAddedPtr =CARD_DATA_MAX;
		while(temp1< CARD_DATA_MAX)
		{
	      	xmem2root((unsigned char *)&empcard,((unsigned long)CARD_DATA_BASE+((unsigned long)temp1*(unsigned long)CARD_DATA_BYTES)),CARD_DATA_BYTES);
	   		if(empcard.CardNo == Cardno)
	         	return(temp1);
			if(LastCardAddedPtr == temp1)
				return(CARD_NOT_FOUND);
			temp1++;
		}
		return(CARD_NOT_FOUND);
	}
	//==============================================================================
	/*** BeginHeader SearchDisplayCard1*/
	//int SearchDisplayCard(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard);
	/*** EndHeader */
	/*int SearchDisplayCard(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)
	{
	unsigned int temp;
	   if(cardno !=0)
	   { 	temp = CardSearch(cardno);
		   if(temp == CARD_NOT_FOUND)
		   {
		      MsgPrint(MSG_WARNING,temp,"SearchDisplayCard:Card not found ptr=");
		      return(CARD_NOT_FOUND);
		   }
		   else
		   {
		      xmem2root( (unsigned char *)empcard,((unsigned long)CARD_DATA_BASE+((unsigned long)temp*(unsigned long)CARD_DATA_BYTES)),CARD_DATA_BYTES);
		      MsgPrint(MSG_WARNING,temp,"SearchDisplayCard:Card found ptr=");
		   }
	     	return(temp);
	   }
	   return(CARD_NOT_FOUND);
	}
	*/
	//==============================================================================
	/*** BeginHeader AddCard1*/
//	int AddCard(struct CARD_DATA empcard);
//	/*** EndHeader */
//	int AddCard(struct CARD_DATA empcard)
//	{
//		int temp;
//	   long memptr;
//	   unsigned char tmpcarddata[20];
//	   memset(tmpcarddata,0,CARD_DATA_BYTES);
//		MsgPrint(MSG_WARNING,empcard.CardNo,"AddCard:Card No is=");
//	    temp = CardSearch(empcard.CardNo);
//		if(temp == CARD_NOT_FOUND)
//		{
//			temp = CardSearch(0);
//			if((temp >= MAX_NO_OF_CARD)||(temp == CARD_NOT_FOUND))
//			{
//	      	if(LastCardAddedPtr <= MAX_NO_OF_CARD)
//				{
//		         LastCardAddedPtr = MAX_NO_OF_CARD;
//					temp = CardSearch(0);
//	            if(temp !=CARD_NOT_FOUND)
//						LastCardAddedPtr = temp+1;
//	            else
//	            	return(-1);
//	         }
//				if((temp >= MAX_NO_OF_CARD)||(temp == CARD_NOT_FOUND))
//	      	{
//	         	MsgPrint(MSG_WARNING,temp,"AddCard:No mem for card add ptr=");
//					return(-1);
//	         }
//			}
//			MsgPrint(MSG_WARNING,temp,"AddCard:New card to be added ptr=");
//			TotalCards++;
//		}
//	   if(temp>=LastCardAddedPtr)
//		{
//			LastCardAddedPtr = temp+1;
//			MsgPrint(MSG_WARNING,LastCardAddedPtr,"AddCard:LastCardAddedPtr=");
//		}
//	
//	
//		MsgPrint(MSG_WARNING,empcard.CardInfo.APB,"my:AddCard:APB");
//		memcpy(tmpcarddata,(char *)&empcard,CARD_DATA_BYTES);
//		memptr = (CARD_DATA_BASE+(temp*CARD_DATA_BYTES));
//		memptr = ((unsigned long)CARD_DATA_BASE+(unsigned long)((unsigned long)temp*(unsigned long)CARD_DATA_BYTES));
//		root2xmem(memptr,tmpcarddata,CARD_DATA_BYTES);
//		//PRINTF_REMOVE   printf("Mem Write Loc %06lx %06lx \n",(CARD_DATA_BASE+(temp*CARD_DATA_BYTES))/0x10000,(CARD_DATA_BASE+(temp*CARD_DATA_BYTES))%0x10000) ;
//		MsgPrint(MSG_WARNING,temp,"AddCard:Card updated Loc=");
//		WriteCardDataToFlash(temp);
//		return(temp);
//	}
	
	//================================================================================
	///*** BeginHeader WriteAllCardDataToFlash*/
	//unsigned char WriteAllCardDataToFlash(void);
	// /*** EndHeader */
	unsigned char WriteAllCardDataToFlash(void)
	{
	unsigned int cardmaxflashpage,i;
	unsigned long memptr;
	 	cardmaxflashpage = ((long) MAX_NO_OF_CARD * (long) CARD_DATA_BYTES)/(long)FLSH_APP_PAGE_SZ;
	  	for(i=0;i<cardmaxflashpage;i++)
		{
			if(!(i%50))
				VdHitWd(WatchDogHndl);
			memptr = (long)CARD_DATA_BASE+(long)((long)i * (long)FLSH_APP_PAGE_SZ) ;
			xmem2root(tempwrbuf1,memptr,FLSH_APP_PAGE_SZ);
			sf_writeRAM(tempwrbuf1,0,FLSH_APP_PAGE_SZ);
			sf_RAMToPage(FL_CARDDATA_PAGE_NO+i);
	   }
		MsgPrint(MSG_MEM,0,"WriteAllCardDataToFlash ");
	}

	/*--------------------------------------------------------------------------*/
	///*** BeginHeader ReadAllCardDataFromFlash*/
	//unsigned long ReadAllCardDataFromFlash(void);
	///*** EndHeader */
	unsigned long ReadAllCardDataFromFlash(void)
	{
	unsigned int cardmaxflashpage,i,*chkint,j;
	unsigned char WritePage[FLSH_APP_PAGE_SZ];
	unsigned long memptr;
	unsigned long chksum;
	
		chksum = CHK_SUM_MOD_VALUE;
		cardmaxflashpage = ((long) MAX_NO_OF_CARD * (long) CARD_DATA_BYTES)/(long)FLSH_APP_PAGE_SZ;
		for(i=0;i<cardmaxflashpage;i++)
		{
			if(!(i%50))
				VdHitWd(WatchDogHndl);     //DA00028
			sf_pageToRAM(FL_CARDDATA_PAGE_NO+i);
			sf_readRAM(WritePage, 0, FLSH_APP_PAGE_SZ);
			chkint = (unsigned int *)WritePage;  
			for(j=0;j<128;j++)
				chksum = chksum + chkint[j];
			memptr = (long)CARD_DATA_BASE+(long)((long)i * (long)FLSH_APP_PAGE_SZ) ;
			root2xmem(memptr,WritePage,FLSH_APP_PAGE_SZ);
	//      printf("Page = %d Chksum = %8lx \n",i,chksum);
	   }
	//	MsgPrint(MSG_MEM,chksum,"ReadAllCardDataFromFlash chksum =");
	   return(chksum);
	}
	
	ssss


#endif //#ifdef DISABLE_BELOW_CODE


