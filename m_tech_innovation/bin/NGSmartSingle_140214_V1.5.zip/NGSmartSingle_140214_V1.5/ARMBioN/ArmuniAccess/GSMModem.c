/*** BeginHeader GSMModem*/
/*
Essential requirement for Vodafone GPRS data call

1) SIM card Settings:
SIM card must have enabled with "Mobile connect" service.
To activate above service send following SMS to 111
ACT VMC199

To de-activate above service send following SMS to 111
CAN VMC199

Vodafone Mobile connect formly called as Hutch Access. For those wondering what is the difference between these two GPRS connections, 
Vodafone Live is limited to browsing websites on Phone. But Vodafone Mobile Connect allows complete access to internet such as IMAP/POP access,
 ability to use VoIP Clients (ex: Fring) & also can be used to access internet on your Laptop or Computer.

Here are the settings:
Connection Name: Anything
Data Bearer: Packet Data
Access Point Name: www
User Name: None (I mean leave it blank!)
Password: None
Authentication: Normal
Homepage: You can set any website

Advanced Settings:
Network Type: IPv4
Phone IP Address: Automatic
DNS Address: Automatic
Proxy Server Address: None
Proxy Port Number: 0
Settings alone can't do anything, you have to activate Vodafone Mobile Connect first to use this service. Tariff for Vodafone Mobile Connect is as follows:

Prepaid pack
Monthly rental: Rs 199
Usage charges @ 5p / 10KB

Postpaid pack
Monthly rental (Rs)	199	499	699
Free data	-	500MB	1GB
Usage charges	5p / 10KB	5p / 10KB	5p / 10KB
To activate this service call to Vodafone Customer Care (Happy to help ! ?????) at 111


2) Unit Settings:
Parameter No ' Parameter info.
42 ' 122.170.15.14 ' static ip address (Airtel)
44 ' 1647 ' Port forwarded port No
76 ' 1 ' GPRS enable
77 ' 0 ' Trnx based connect
78 ' 1 ' Time based connect

AT+CSQ command will give signal quality i.e. n/w


3) Port forwarding Settings for Smart-I "Airtel" Static IP:

Type 122.170.15.14 in address bar in internet explorer
1)	Enter user name = admin and password = P@$$w0rd
2)	Go to advanced setup options
3)	Go to NAT option
4)	Click on Add option
5)	Select customized service and give a sample name as "GPRS"
6)	Select protocol as TCP/UDP
7)	Enter port no to be forwarded in the unit for e.g. 1647.
8)	Enter Internal server IP address i.e. on which data downloading software is installed.
9)	Press "Apply" button
10)	Now new port is forwarded with static IP


4) "AT" command sequence for GPRS communication:

a) GPRS Operation for Airtel
We need APN from service provider for GPRS to work command sequence used is as follows
AIRTEL:     airtelgprs.com
Command sequence	Description
ATZ
at+CIPSHUT	Shutdown connection
AT+CGDCONT=1,"IP","airtelgprs.com","",0,0	Following command do now matter much as this is already created in mobile
at+CIPMODE=1	Transparent mode
at+cstt="airtelgprs.com","",""	Set APN for GPRS communication   at+cstt=APN,username,password  (for airtel username is blank and password is blank)
(Note: We have observed that if APN is not set properly we may get error as +PDP: DEACT so check this APN properly)
at+CIICR	Connect to internet
AT+CIFSR	Get dynamic IP address
at+cipstart="tcp","209.85.231.104","80"	Connect to web site in this ip indicated is Google IP and port 80 which web page port
Once we get connect we should send following data to get web page
GET /index.html HTTP/1.1
Host: www.google.com

+++  and enter	To close connection +++ should be send very fast ( cut-paste)
at+cipstart="tcp","209.85.231.104","80"	You can re-connect using
AT+CIPCLOSE	To close connection
AT+CIPSHUT	To close connection



b) GPRS Operation for Vodafone:
We need APN from service provider for GPRS to work command sequence used is as follows
Required service: Mobile connect
Vodafone:     WWW
Command sequence	Description
ATZ
at+CIPSHUT	Shutdown connection
AT+CGDCONT=1,"IP","live.vodafone.in","",0,0	Following command do now matter much as this is already created in mobile
at+CIPMODE=1	Transparent mode
at+cstt="www","",""	Set APN for GPRS communication   at+cstt=APN,username,password  (for Vodafone username and password are blank)
(Note: We have observed that if APN is not set properly we may get error as +PDP: DEACT so check this APN properly)
at+CIICR	Connect to internet
AT+CIFSR	Get dynamic IP address
at+cipstart="tcp","122.170.15.14","1647"	Connect to static IP and port
AT+CIPCLOSE	To close connection
AT+CIPSHUT	To close connection

c) How to test if modem works in PC case (Not tested Yet)
network connection
create new connection
connect to internet
set-up manually
connect using dial up
provide any name
provide following number   *99***1#
no user name and password
done

You can say open terminal window in security settings   to look what is happening.

Use this connection to dial internet and we should get internet connected
Rabbit:

#1u,042,124.030.138.011,5D,
#1u,044,03001,49,

#1u,076,001,4B,	
#1u,077,00000,4B,
#1u,078,00001,45,
#1p,010,001,4E,
#1p,011,live.vodafone.in ,51,
#1p,012,www,0A,
#1p,013,,7C,
 #1p,014,,7B,
 
ARM:
#1u,042,124.030.138.011,5D,

#1u,044,03001,49,
#1u,076,001,4B,
#1u,077,00000,4B,
#1u,078,00001,45,
#1p,010,001,4E,
#1p,011,live.vodafone.in,71,
 for docomo TATA.DOCOMO.INTERNET
 for airtel airtelgprs.com
for BSNL bsnlnet 
 #1p,012,www,0A,
#1p,013,,62,
#1p,014,,7B,

*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "LPC23xx.h"
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "spi.h"
#include "uart.h"
#include "smartbio.h"
#include "cardmgmt.h"
#include "memmap.h"
#include "rtc.h"
#include "access.h"
#include "tranxmgmt.h" 
#include "userintf.h" 
#include "memory.h"
#include "rdcont.h"
#include "portlcd.h"
//#include "rdpoll.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "GSMModem.h"
#include "wdt.h"
#include "serial.h"
#include "userIntfGLCD.h"
#include "../../GLCD/BMPImage/sea3_565.h"

#ifdef ENABLE_GSM_GPRS
extern volatile WORD ReceiveCount, UART1Count,ToReceiveCount;
extern unsigned char WDTHandleType;
//extern unsigned char DisplayMode,NextDisplayMode;
extern unsigned char F_GPRSData;
volatile BYTE F_MainLoopGPRSHandle;
extern char SendWithoutDelay;

extern unsigned int GetPendingTrans(unsigned int readptr,unsigned int writeptr);

//unsigned char GPRSReInit,ModemTimeOut,GPRSStatus,GPRSIPAddress[20];
//volatile unsigned char F_ModemDataProxy;
//unsigned char F_100mSecCounterStart,Temp_100mSec_Time_Counter;
//unsigned char GPRSSBuffer[MAX_GPRS_BUFFER];
//unsigned int GPRSReceiveCount;
#define GPRSReceiveCount PortObj[MODEM_PORT].RxPtr
//unsigned int GPFSAutoConnectTimer,GPFSInitialiseTimer;
unsigned char ServiceProvider[32];
//unsigned char F_ReceiveGPRSPortData;


void GPRSDelay(void)
{
	unsigned long int i=500;
	while(--i)
	{}
}

/*** BeginHeader InitialiseModemData*/
void InitialiseModemData(void);
/*** EndHeader */
void InitialiseModemData(void)
{
	ModemTimeOut=0;
	GPRSReInit=0;
	GPFSAutoConnectTimer=0;
	F_ModemDataProxy=0;
	GPFSInitialiseTimer=0;
	GPRSNoDataTime=0;
	GPRSStatus=STATUS_GPRS_NOTCONNECT;
	GPRSReceiveCount=0;
	SignalStrength = 0;
//	memset(GPRSSBuffer,0,sizeof(GPRSSBuffer));
	memset(PortObj[MODEM_PORT].RxBuffer,0,PortObj[MODEM_PORT].MAXINBUF);
	memset(GPRSIPAddress,0,sizeof(GPRSIPAddress));
	PortObj[MODEM_PORT].F_SerProxy = CLR;
	PortObj[MODEM_PORT].BufPtr = 0;
	PortObj[MODEM_PORT].RxPtr = 0;
	SendWithoutDelay=0;
}
//==============================================================================

/*** BeginHeader ClearModemPort*/
unsigned char ClearModemPort(void);
/*** EndHeader */
unsigned char ClearModemPort(void)
{
//UARTInit(MODEM_PORT,9600);
//unsigned int n ;
//	n = SER_MODEM_RDUSED();	 //PRASOON CHANGE THIS
  /* if(F_GPRSData!=0)
   {
	   while(1)
   	{
//      	n = SER_MODEM_GETC();  //PRASOON CHANGE THIS
	      if( F_GPRSData == -1)
		      break;
    }
	}*/	 
	PortObj[MODEM_PORT].F_SerProxy = CLR;
	PortObj[MODEM_PORT].BufPtr = 0;
	PortObj[MODEM_PORT].RxPtr = 0;
	memset(PortObj[MODEM_PORT].RxBuffer,0,PortObj[MODEM_PORT].MAXINBUF);
	F_ModemDataProxy = CLR;
return 0;
}

//==============================================================================
/*** BeginHeader InitialiseGPRS*/
unsigned char InitialiseGPRS(unsigned char reinit);	 //
/*** EndHeader */
unsigned char InitialiseGPRS(unsigned char reinit)
{
unsigned char recbuffer[256],sendstr[50],status;
#ifdef BIO_METRIC
   if((DisplayMode == MODE_WAIT_FOR_CARD) || (USER_IDENTIFY_MODE == DisplayMode) || (DisplayMode == MODE_GPRS_DIAGNOSIS))
#else
   if((DisplayMode == MODE_WAIT_FOR_CARD))
#endif
	GPRSReInit = reinit;
   	GPRSStatus = STATUS_GPRS_NOTCONNECT;
	F_100mSecCounterStart = SET;
	Temp_100mSec_Time_Counter = 0;
	while(Temp_100mSec_Time_Counter < 4)
	{
		#ifdef ENABLE_WATCHDOG
			WDTFeed();		//Clear watchdog timer
		#endif	
	}
		F_100mSecCounterStart = CLR;
	{
//	    LCD_cls();
		L_CenterDisplaySubStr("GPRS Connecting",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	}
	status = DisableECHO();
	if(status == GPRS_FAIL)
		return(status);  //modem not connected

//	L_DisplayROMStr("get",16,ROW_USER_ENTRY);
//	L_DisplayROMStr("GetSignal Streng",16,ROW_USER_ENTRY);
	GPRSDelay();
//	GPRSDelay();
	GPRSDelay();
	status = ChkSignalStrength();
	if(status == GPRS_FAIL)
		return(status);//no signal strength									  
	GPRSDelay();
GPRSDelay();	
	if(Doorinfo.ModemType == 1)   //old Modem
	{
//		L_DisplayROMStr("SELECT TCP MODE ",16,ROW_USER_ENTRY);
		status = SendCommandToModemAndCheck_3("AT+CIPMODE=1",5,recbuffer,10,"OK");
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
//		GPRSDelay();
//		L_DisplayROMStr("DEACT PDP CONTEX",16,ROW_USER_ENTRY);
		status = SendCommandToModemAndCheck_3("AT+CIPSHUT",10,recbuffer,20,"OK");

//		L_DisplayROMStr("DEFINE PDP CONTE",16,ROW_USER_ENTRY);
		sprintf((char*)sendstr,"AT+CGDCONT=1,\"IP\",\"%s\"",(char*)Doorinfo.PDPContext);	//define PDP Context LIVE.VODAFONE.IN
		status = SendCommandToModemAndCheck_3(sendstr,strlen((char*)sendstr),recbuffer,2,(char*)"OK");

//		L_DisplayROMStr("START TCP TASK  ",16,ROW_USER_ENTRY);
		sprintf((char*)sendstr,"AT+CSTT=\"%s\",\"%s\",\"%s\"",(char*)Doorinfo.APNType,(char*)Doorinfo.APNUserName,(char*)Doorinfo.APNPassword);	//start task and set apn, username, password	"WWW","",""
		status = SendCommandToModemAndCheck_3(sendstr,strlen((char*)sendstr),recbuffer,5,(char*)"OK");

//		L_DisplayROMStr("WIRELESS CONNECT",16,ROW_USER_ENTRY);
		status = SendCommandToModemAndCheck_3("AT+CIICR",8,recbuffer,5,"OK");
   
	}
	else	//New Modem
	{
//		L_CenterDisplaySubStr("SELECT TCP MODE ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		status = SendCommandToModemAndCheck_3("AT+QIMODE=1",5,recbuffer,10,"OK");
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
		GPRSDelay();
//		L_CenterDisplaySubStr("DEACT PDP CONTEX",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		status = SendCommandToModemAndCheck_3("AT+QIDEACT",10,recbuffer,20,"OK");
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
GPRSDelay();
		
//		L_CenterDisplaySubStr("DEFINE PDP CONTE",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		sprintf((char*)sendstr,"AT+CGDCONT=1,\"IP\",\"%s\"",(char*)Doorinfo.PDPContext);	//define PDP Context LIVE.VODAFONE.IN
		status = SendCommandToModemAndCheck_3(sendstr,strlen((char*)sendstr),recbuffer,2,(char*)"OK");
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
GPRSDelay();
//		L_CenterDisplaySubStr("START TCP TASK",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		sprintf((char*)sendstr,"AT+QIREGAPP=\"%s\",\"%s\",\"%s\"",(char*)Doorinfo.APNType,(char*)Doorinfo.APNUserName,(char*)Doorinfo.APNPassword);	//start task and set apn, username, password	"WWW","",""
		status = SendCommandToModemAndCheck_3(sendstr,strlen((char*)sendstr),recbuffer,5,(char*)"OK");
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
GPRSDelay();
//GPRSDelay();
GPRSDelay();
//GPRSDelay();
//		L_CenterDisplaySubStr("WIRELESS CONNECT",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
		status = SendCommandToModemAndCheck_3("AT+QIACT",8,recbuffer,6,(char*)"OK");
//GPRSDelay();
//GPRSDelay();
GPRSDelay();
	}
	GPRSStatus = STATUS_GPRS_CONNECTING;
	F_MainLoopGPRSHandle = 1;   	
   return(0);
}

//==============================================================================
/*** BeginHeader ShutdownGPRS*/
unsigned char ShutdownGPRS(void);
/*** EndHeader */
unsigned char ShutdownGPRS(void)
{
unsigned char recbuffer[256],status;
   GPRSStatus = STATUS_GPRS_NOTCONNECT;
   status = DisableECHO();
   if(status == GPRS_FAIL)
      return(status);
   if(Doorinfo.ModemType == 1)
		status = SendCommandToModemAndCheck_3("AT+CIPCLOSE",10,recbuffer,20,(char*)"OK");
   else
		status = SendCommandToModemAndCheck_3("AT+QICLOSE",10,recbuffer,20,(char*)"OK");
   if(Doorinfo.ModemType == 1)
		status = SendCommandToModemAndCheck("AT+CIPSHUT",10,recbuffer,20,(char*)"OK");
   else
		status = SendCommandToModemAndCheck("AT+QIDEACT",10,recbuffer,20,(char*)"OK");
   GPRSStatus = STATUS_GPRS_NOTCONNECT;
   return(status);
}

//==============================================================================
/*** BeginHeader SendCommandToModem*/
char SendCommandToModem(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout);
/*
it returns return value of function "WaitModemResponse()"
*/
/*** EndHeader */
char SendCommandToModem(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout)
{
unsigned char status;
	ClearModemPort();
	//printf("MODEM SEND:%d:<%s>\n",strlen(senddata),senddata);
	TransmitStrToX(senddata,MODEM_PORT);
	TransmitCharToX(MODEM_TERMINATOR2,MODEM_PORT);
	TransmitCharToX(MODEM_TERMINATOR1,MODEM_PORT);


	status = WaitModemResponse(timeout,NULL);
//	GPRSDelay();

//	if(ReceiveCount >= 254)
//		ReceiveCount = 0;
	memcpy(recdata,(BYTE *)(PortObj[MODEM_PORT].RxBuffer),PortObj[MODEM_PORT].RxPtr);
	recdata[PortObj[MODEM_PORT].RxPtr+1] = '\0';
	//printf("MODEM REC:%d:<%s>\n",ReceiveCount,SBuffer);
	return(status);
}

//==============================================================================
/*** BeginHeader SendCommandToModemAndCheck*/
char SendCommandToModemAndCheck(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata);
/*it returns only two results
#define GPRS_OK			0	//given s
#define GPRS_FAIL		1
*/
/*** EndHeader */
char SendCommandToModemAndCheck(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata)
{
unsigned char status; 

	ClearModemPort();
	//   printf("MODEM SEND:%d:<%s>\n",strlen(senddata),senddata);
	TransmitStrToX(senddata,MODEM_PORT);
//GPRSDelay();
	TransmitCharToX(MODEM_TERMINATOR2,MODEM_PORT);
	TransmitCharToX(MODEM_TERMINATOR1,MODEM_PORT);
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
//    GPRSDelay();
										   // after swtatic ip recived  next command status =0x02
	status = WaitModemResponse(timeout,chkdata); // may be 0 or 3 in status
//	if(FlagDynamicIP==1)
//	{
//	   ClearModemPort();
//	   status = WaitModemResponse(timeout,chkdata); // may be 0 or 3 in status
//	}
	MsgPrintX(MSG_WARNING,status,"SendCommandToModemAndCheck:status=",SER_TCPIP_PORT);
	memcpy(recdata,(BYTE *)PortObj[MODEM_PORT].RxBuffer,PortObj[MODEM_PORT].RxPtr);
//	TransmitStrToX(recdata,PC_PORT);
//	recdata[PortObj[MODEM_PORT].RxPtr+1] = '\0';
	if(status == GPRS_RECEIVED)	  // 0x03  recived 
	{
		if(strstr((const char*)recdata,(const char*)chkdata) != NULL)	// recdata shold not have base adrsess of NULL 
			return(GPRS_OK);	   //string doesn,t match(or OK not received)
		else
			return(GPRS_FAIL);		//string gets match
	}
	else if(status == GPRS_TIME_OUT)
	{
		 return	GPRS_FAIL;
	}
	return(status);
}
char SendCommandToModemAndCheck_2(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata)
{
unsigned char status; 

#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
	ClearModemPort();
	TransmitStrToX(senddata,MODEM_PORT);
	TransmitCharToX(MODEM_TERMINATOR2,MODEM_PORT);	
 	status = WaitModemResponse_2(timeout,chkdata); // may be 0 or 3 in status

	memcpy(recdata,(BYTE *)PortObj[MODEM_PORT].RxBuffer,PortObj[MODEM_PORT].RxPtr);
//	recdata[PortObj[MODEM_PORT].RxPtr+1] = '\0';
	if(status == GPRS_RECEIVED)	  // 0x03  recived 
	{
		if(strstr((const char*)recdata,(const char*)chkdata) != NULL)	// recdata shold not have base adrsess of NULL 
			return(GPRS_OK);	   //string doesn,t match(or OK not received)
		else
			return(GPRS_FAIL);		//string gets match
	}
	else if(status == GPRS_TIME_OUT)
	{
		 return	GPRS_FAIL;
	}
	return(status);
}

char SendCommandToModemAndCheck_3(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata)
{
unsigned char status; 

	ClearModemPort();
	TransmitStrToX(senddata,MODEM_PORT);
	TransmitCharToX(MODEM_TERMINATOR2,MODEM_PORT);
	TransmitCharToX(MODEM_TERMINATOR1,MODEM_PORT);
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
	status = WaitModemResponse_3(timeout,chkdata); // may be 0 or 3 in status
	MsgPrintX(MSG_WARNING,status,"SendCommandToModemAndCheck:status=",SER_TCPIP_PORT);
	memcpy(recdata,(BYTE *)PortObj[MODEM_PORT].RxBuffer,PortObj[MODEM_PORT].RxPtr);
	if(status == GPRS_RECEIVED)	  // 0x03  recived 
	{
		if(strstr((const char*)recdata,(const char*)chkdata) != NULL)	// recdata shold not have base adrsess of NULL 
			return(GPRS_OK);	   //string doesn,t match(or OK not received)
		else
			return(GPRS_FAIL);		//string gets match
	}
	else if(status == GPRS_TIME_OUT)
	{
		 return	GPRS_FAIL;
	}
	return(status);
}

char WaitModemResponse_3(unsigned int timeout,unsigned char *checkstr)
{
	ReceiveCount = 0;
	ModemTimeOut = 0;
	while(1)
	{
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
		if(F_ModemDataProxy == SET)
		{
			F_ModemDataProxy = CLR;
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
	     GPRSDelay();			
			PortObj[MODEM_PORT].F_SerProxy = CLR;
			if(strstr((char*)(PortObj[MODEM_PORT].RxBuffer),(const char*)checkstr) !=NULL)
	      	{
  		    	return(GPRS_OK);
	   		}
			if(strstr((char*)(PortObj[MODEM_PORT].RxBuffer),"ERROR") !=NULL)
	      	{
  		    	return(GPRS_FAIL);
	   		}
		}
		if((ModemTimeOut >= timeout))// && (PortObj[MODEM_PORT].F_SerProxy == CLR))
		{
			if(PortObj[MODEM_PORT].RxPtr > 2)
			{
//				PortObj[MODEM_PORT].RxBuffer[PortObj[MODEM_PORT].RxPtr] = '\0';
				PortObj[MODEM_PORT].RxPtr++ ;
				return(GPRS_RECEIVED);
			}

			MsgPrint(MSG_WARNING,ModemTimeOut,"GSM Modem Time Out");
			return(GPRS_TIME_OUT);
		}
	}
}

/*** BeginHeader SendCommandToModem*/
char WaitModemResponse(unsigned int timeout,unsigned char *checkstr);
/*
this function will send only three status
#define GPRS_OK			0	//string is matched
#define GPRS_TIME_OUT	2	//time out
#define GPRS_RECEIVED	3	//string doesn't matched
*/
/*** EndHeader */
char WaitModemResponse(unsigned int timeout,unsigned char *checkstr)
{
	ReceiveCount = 0;
	ModemTimeOut = 0;
//	memset((BYTE *)SBuffer,0,sizeof(SBuffer));
//	F_ModemDataProxy = CLR;
//   WDTHandleType = WDT_WAIT_MODEM_RESPONSE;
//   ClearModemPort();
	while(1)
	{
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
//		if(PortObj[MODEM_PORT].F_SerProxy == SET)
		if(F_ModemDataProxy == SET)
		{
			F_ModemDataProxy = CLR;

//		   GPRSIPAddress =  PortObj[MODEM_PORT].RxBuffer[PortObj[port].RxPtr];	
//		  memcpy(recdata,(BYTE *)PortObj[MODEM_PORT].RxBuffer,PortObj[MODEM_PORT].RxPtr);
//		  strncpy(GPRSIPAddress,&recdata,16);	
//		L_DisplayROMStr("                 ",16,ROW_USER_ENTRY);
//		L_DisplayROMStr((BYTE *)PortObj[MODEM_PORT].RxBuffer,16,ROW_USER_ENTRY2); 
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
	     GPRSDelay();
//			PortObj[MODEM_PORT].RxBuffer[PortObj[MODEM_PORT].RxPtr] = '\0';
//			PortObj[MODEM_PORT].RxPtr++ ;
			
			PortObj[MODEM_PORT].F_SerProxy = CLR;
			if(strstr((char*)(PortObj[MODEM_PORT].RxBuffer),(const char*)checkstr) !=NULL)
	      	{
  		    	return(GPRS_OK);
					}
		}
		if((ModemTimeOut >= timeout))// && (PortObj[MODEM_PORT].F_SerProxy == CLR))
		{
			if(PortObj[MODEM_PORT].RxPtr > 2)
			{
//				PortObj[MODEM_PORT].RxBuffer[PortObj[MODEM_PORT].RxPtr] = '\0';
				PortObj[MODEM_PORT].RxPtr++ ;
				return(GPRS_RECEIVED);
			}

			MsgPrint(MSG_WARNING,ModemTimeOut,"GSM Modem Time Out");
			return(GPRS_TIME_OUT);
		}
	}
}

char WaitModemResponse_2(unsigned int timeout,unsigned char *checkstr)
{
   ReceiveCount = 0;
	ModemTimeOut = 0;
	TransmitCharToX(MODEM_TERMINATOR1,MODEM_PORT);
	while(1)//wait for response
	{
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
		if(F_ModemDataProxy == SET)	 // ok
		{
//			L_DisplayROMStr("                 ",16,ROW_USER_ENTRY);
//			L_DisplayROMStr((BYTE *)PortObj[MODEM_PORT].RxBuffer,16,ROW_USER_ENTRY); 
			GPRSDelay();
			if(strstr(( char*)(PortObj[MODEM_PORT].RxBuffer),(const char*)checkstr) !=NULL)
	      	{
				F_ModemDataProxy = CLR;	    	
				return(GPRS_OK);
				
	   		}
		}
		if((ModemTimeOut >= timeout))// && (PortObj[MODEM_PORT].F_SerProxy == CLR))
		{
			if(PortObj[MODEM_PORT].RxPtr > 2)
			{
				F_ModemDataProxy = CLR;
				return(GPRS_RECEIVED);
			}

			F_ModemDataProxy = CLR;
			return(GPRS_TIME_OUT);
		}
	}

}


//==============================================================================

/*** BeginHeader MainLoopGPRSHandle*/
void MainLoopGPRSHandle(void);
/*** EndHeader */
void MainLoopGPRSHandle(void)
{
unsigned char sendstr[255];
unsigned char recbuffer[256],status,icnt;
char ipstartIndex=0;
char count=0;
//unsigned char tempbuffer[]="#1i,001,0000000000,000,7A,"; 
//unsigned char tempbuffer2[]="#1J,001,005,006,001,001,001,000,007,000,000,001,001,002,005,006,000,000,000,001,000,70,";


//	if((data == '\n') || (data == '\r'))
//	{
//      GPRSReceiveCount = 0;
//   }
//	GPRSSBuffer[GPRSReceiveCount] = data;
//   GPRSReceiveCount++;
//   if(GPRSReceiveCount >= MAX_SERIAL_BUFFER)
//		GPRSReceiveCount = 0;
//	GPRSSBuffer[GPRSReceiveCount] = '\0';
//	if(F_MainLoopGPRSHandle != 1)
//	{
//		return 0;
//	}
//	F_MainLoopGPRSHandle = 0;
//	if(PortObj[MODEM_PORT].F_SerProxy != SET)
//	{
//		return 0;
//	}
//	PortObj[MODEM_PORT].F_SerProxy = CLR;

   if(GPRSStatus == STATUS_GPRS_CONNECTING)
   {
			GPRSStatus = STATUS_GPRS_CONNECTED_WAIT;
			GPRSReceiveCount = 0;
			ReceiveCount = 0;
			memset(recbuffer,0,sizeof(recbuffer));	 
//			L_DisplayROMStr("Get Local IP    ",16,ROW_USER_FUNCTION);
			if(Doorinfo.ModemType == 1)
			{
				status = SendCommandToModemAndCheck("AT+CIFSR",8,recbuffer,5,NULL);	 // status =  0x01
			}
			else
			{
				status = SendCommandToModemAndCheck("AT+QILOCIP",8,recbuffer,5,NULL);
			}
			if(status == 0x01)  // match found = 0x01
			{
				for(icnt=0;icnt<30;icnt++)
				{
					if(recbuffer[icnt]>='0' && recbuffer[icnt]<='9'|| recbuffer[icnt]=='.')
					{
						if(ipstartIndex == 0)
							ipstartIndex = 1;
						GPRSIPAddress[count] = recbuffer[icnt];
						++count;
					}
					else
					{
						if(ipstartIndex != 0)
							break;					
					}
				}
				GPRSIPAddress[count]='\0';
#ifdef BIO_METRIC
   		if((DisplayMode == MODE_WAIT_FOR_CARD) || (USER_IDENTIFY_MODE == DisplayMode) || (DisplayMode == MODE_GPRS_DIAGNOSIS))
#else
   		if((DisplayMode == MODE_WAIT_FOR_CARD))
#endif
				{
				L_CenterDisplaySubStr("GPRS IP",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
//				L_DisplayROMStr("                 ",16,ROW_USER_ENTRY);
				L_CenterDisplaySubStr(GPRSIPAddress,ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);  //// gprsipaddress = 40001F62 lcd =AT+CIfsr
				}
			}
			else
			{
				L_DisplayROMStr("No IP Received  ",16,ROW_USER_ENTRY);
			} 
	      GPRSStatus = STATUS_GPRS_CONNECTED_WAIT;
		  
	      if(Doorinfo.ModemType == 1)
	      {
		     sprintf((char *)sendstr,"AT+CIPSTART=\"TCP\",\"%s\",\"%d\"",(char*)SysInfo.PUSH_TCP_ServAdd1,SysInfo.PUSH_TCP_Port1);
				}
		  else
		  {
	         	sprintf((char *)sendstr,"AT+QIOPEN=\"TCP\",\"%s\",\"%d\"",(char*)SysInfo.PUSH_TCP_ServAdd1,SysInfo.PUSH_TCP_Port1);
	    }
		  status = SendCommandToModemAndCheck_2(sendstr,strlen((char *)sendstr),recbuffer,50,"CONNECT");
//	      status = SendCommandToModemAndCheck((char*)sendstr,strlen(sendstr),recbuffer,50,"OK");
	    
		  if(status == 0x00)	   // check status  = 0x01
	      {
//	         	L_DisplayROMStr("GPRS Connected  ",16,ROW_USER_FUNCTION);
						L_CenterDisplaySubStr("GPRS Connected",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
						L_CenterDisplaySubStr(" ",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
						GPRSStatus = STATUS_GPRS_CONNECTED;
	         	sprintf((char *)recbuffer,"#%cm,%s,%d,\r\n",SysInfo.MySlaveNo+'0',GPRSIPAddress,Doorinfo.ControllerNo);
	         	TransmitStrToX(recbuffer,MODEM_PORT);	  // #1mAT+cifsr,655,\r\n
	
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif				
				GPRSDelay();
	      }
		  else
		  {
#ifdef BIO_METRIC
   			if((DisplayMode == MODE_WAIT_FOR_CARD) || (USER_IDENTIFY_MODE == DisplayMode) || (DisplayMode == MODE_GPRS_DIAGNOSIS))
#else
   			if((DisplayMode == MODE_WAIT_FOR_CARD))
#endif
	            {
					L_CenterDisplaySubStr("Connection Fail",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);		// enter in this loop 
				}
		  }
	      ReceiveCount = 0;
	      GPFSInitialiseTimer = 0;
	      GPRSNoDataTime = 0;
		  memset(GPRSSBuffer,0,sizeof(GPRSSBuffer));
   }
   else
   {
//	   if(strstr(GPRSSBuffer,"CONNECT") != NULL)
//	   {
//	      GPRSStatus = STATUS_GPRS_CONNECTED;
//	      GPRSReceiveCount = 0;
//	      sprintf(sendstr,"#%cm,%s,%d,\r\n",SysInfo.MySlaveNo+'0',GPRSIPAddress,Doorinfo.ControllerNo);
//	      TransmitStrToX(sendstr,MODEM_PORT);
//	      GPFSAutoConnectTimer = 0;
//	      GPRSNoDataTime = 0;
//	      {
//	         L_DisplayROMStr("GPRS Connected ",16,ROW_USER_FUNCTION);
//	      }
//	   }
	   if(strstr((char*)GPRSSBuffer,(char*)"CLOSE") != NULL)
//	   if(strstr(GPRSSBuffer,"CLOSED") != NULL)
	   {
	      GPRSStatus = STATUS_GPRS_NOTCONNECT;
	      GPRSReceiveCount = 0;
	      GPFSAutoConnectTimer = 0;
	      GPRSNoDataTime = 0;
#ifdef BIO_METRIC
   		if((DisplayMode == MODE_WAIT_FOR_CARD) || (USER_IDENTIFY_MODE == DisplayMode) || (DisplayMode == MODE_GPRS_DIAGNOSIS))
#else
   		if((DisplayMode == MODE_WAIT_FOR_CARD))
#endif
	      {
	         L_CenterDisplaySubStr("GPRS Close ",ROW_USER_ENTRY2,SUBMENUE_CHAR_FONTINFO_PTR);
	      }
	   }
   }
}


//==============================================================================
/*
1) if GPRS is enabled then check for transaction threashold and if threashold is reached then connect to GPRS
2) If time is reached to programmed time then connect GPRS
3) If while connecting error happens keep trying one more time after 1 min
*/

/*** BeginHeader AutoConnectGPRS*/
void AutoConnectGPRS(void);
/*** EndHeader */
void AutoConnectGPRS(void)
{
	struct RectInfo rectinfo;	
	if(Doorinfo.GPRSEnable == 1)
   	{
	   	if((GPRSNoDataTime >= Doorinfo.GPRSTime) && (GPRSStatus == STATUS_GPRS_CONNECTED))
	   	{
//    	As no communication so disconnect
			PortObj[MODEM_PORT].ChkSum = 0;
			PortObj[MODEM_PORT].F_ChkSum = SET;
			TransmitReplyStartToX(MODEM_PORT);
			TransmitCharToX(C_NEW_SEND_MODEM_COMMAND,MODEM_PORT);
			TransmitCharToX(',',MODEM_PORT);
			SendDecimalIntToX(3,MODEM_PORT);
			TransmitCharToX(',',MODEM_PORT);
			SendDecimalIntToX(0,MODEM_PORT);
			TransmitCharToX(',',MODEM_PORT);
			TransmitCheckSumX(MODEM_PORT);
			TransmitCharToX(',',MODEM_PORT);
			TransmitCharToX(TERMINATOR,MODEM_PORT);
			GPFSAutoConnectTimer = 0;
			GPFSInitialiseTimer = 0;
			F_100mSecCounterStart = SET;
			Temp_100mSec_Time_Counter = 0;
			while(Temp_100mSec_Time_Counter < 4)
			{
				#ifdef ENABLE_WATCHDOG
					WDTFeed();		//Clear watchdog timer
				#endif	
			}
			F_100mSecCounterStart = CLR;	
			ShutdownGPRS();
	   	}
	   	else if(GPRSStatus == STATUS_GPRS_NOTCONNECT)
	   	{
	      	if((Doorinfo.GPRSThreshold != 0) && (GPFSInitialiseTimer >= MAX_GPRS_INITIALISE_TIMEOUT))
	      	{//if we have given threshold it will connect GPRS afeter every  MAX_GPRS_INITIALISE_TIMEOUT
	         	if(GetPendingTrans(TransReadPtr,TransWritePtr) >= Doorinfo.GPRSThreshold)
	         	{
//	            printf("GPRS Transaction threashold reached connect GPRS %d\n",GetPendingTrans(TransReadPtr,TransWritePtr));							
							DisplayFormat(FORMAT_CONNECT_GPRS);
							DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							320,
							(unsigned char*)"Connect GPRS",
							ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
							
	           	InitialiseGPRS(1);							
	         	}
	      	}
			if(Doorinfo.GPRSTime != 0)
			{
				if((MAX_GPRS_INITIALISE_TIMEOUT <= GPFSAutoConnectTimer) || (GPRSNoDataTime==0))
				{
					GPFSAutoConnectTimer = 0;
					//	            printf("GPRS Time Threashold Reached %d \n",GPFSAutoConnectTimer);
							DisplayFormat(FORMAT_CONNECT_GPRS);
							DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
							ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
							USER_TITLE_FONTINFO_PTR,
							320,
							(unsigned char*)"Connect GPRS",
							ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
							
								InitialiseGPRS(1);
				}
			}
		}
	   	else if((GPRSStatus == STATUS_GPRS_CONNECTED_WAIT) || (GPRSStatus == STATUS_GPRS_ERROR))
	   	{
	      if(GPFSInitialiseTimer >= MAX_GPRS_INITIALISE_TIMEOUT) 
	      {
	         if(GPRSReInit != 0)
	         {
	            GPRSReInit--;
//	            printf("GPRS Reinit connect %d \n",GPRSReInit);
	            InitialiseGPRS(GPRSReInit);
	         }
	         else
	         {
	            GPRSStatus = STATUS_GPRS_NOTCONNECT;
	         }
	      }
	   }
	}
}

/*** BeginHeader DisableECHO */
unsigned char DisableECHO(void);
/*** EndHeader */
unsigned char DisableECHO(void)
{
unsigned char recbuffer[256],status=0;

	TransmitStrToX("+++",MODEM_PORT);

	F_100mSecCounterStart = SET;
	Temp_100mSec_Time_Counter = 0;
	while(Temp_100mSec_Time_Counter < 2);
		F_100mSecCounterStart = CLR;

	TransmitStrToX("\r\n",MODEM_PORT);

	F_100mSecCounterStart = SET;
	Temp_100mSec_Time_Counter = 0;
	while(Temp_100mSec_Time_Counter < 3)
	{
		#ifdef ENABLE_WATCHDOG
			WDTFeed();		//Clear watchdog timer
		#endif	
	}
		F_100mSecCounterStart = CLR;
					
   status = SendCommandToModemAndCheck_3("ATE0",5,recbuffer,15,"OK");

	if(status == GPRS_FAIL)
	{
		L_CenterDisplaySubStr("MODEM Not Found",ROW_USER_ENTRY3,SUBMENUE_CHAR_FONTINFO_PTR);
		GPRSStatus = STATUS_GPRS_ERROR;
		GPFSInitialiseTimer = 0;
		GPRSNoDataTime = 0;
		MakeSound(SOUND_SYS_ERROR);
		F_100mSecCounterStart = SET;
		Temp_100mSec_Time_Counter = 0;
		while(Temp_100mSec_Time_Counter < 2);
		F_100mSecCounterStart = CLR;

		return(status);
	}
	return(GPRS_OK);
}

/*** BeginHeader ChkSignalStrength */
unsigned char ChkSignalStrength(void);
/*** EndHeader */
unsigned char ChkSignalStrength(void)
{
unsigned char recbuffer[256],status,igsm,jgsm;
	jgsm = 0;
//	GPRSDelay();
	status = SendCommandToModemAndCheck_2("AT+CSQ",6,recbuffer,15,"OK");
//	status = SendCommandToModem("AT+CSQ",6,recbuffer,15);
	if(status == GPRS_FAIL || status == GPRS_TIME_OUT)
	{
	   	GPRSStatus = STATUS_GPRS_ERROR;
	   	GPFSInitialiseTimer = 0;
	   	GPRSNoDataTime = 0;
      	MakeSound(SOUND_SYS_ERROR);
//      L_DisplayROMStr("MODEM Not Found ",16,ROW_USER_ENTRY);
      	return(GPRS_FAIL);
	}
	else
	{
		for(igsm=0; igsm<PortObj[MODEM_PORT].RxPtr; igsm++)
		{
			if(recbuffer[igsm] == ':')
			{
				jgsm = (AsciiToHex(recbuffer[igsm+2])*10) + AsciiToHex(recbuffer[igsm+3]);
				break;
			}
		}
	}
	if(((jgsm >= 0) && (jgsm < 8)) || (jgsm == 99))
		SignalStrength = 0;     //No network
	else if((jgsm >= 8) && (jgsm < 13))
		SignalStrength = 1;      //Min. range
	else if((jgsm >= 13) && (jgsm < 18))
		SignalStrength = 2;
	else if((jgsm >= 18) && (jgsm < 23))
		SignalStrength = 3;
	else if((jgsm >= 23) && (jgsm < 27))
		SignalStrength = 4;
	else if((jgsm >= 27) && (jgsm < 31))
		SignalStrength = 5;     //Max. range
	else
		SignalStrength = 0;      //No network

//	L_DisplayROMStr("SignalLevel     ",16,ROW_USER_ENTRY);
//	DisplaySignalStrength(SignalStrength,ROW_USER_FUNCTION);

   	return(SignalStrength);
}

/*** BeginHeader DisplaySignalStrength */
void DisplaySignalStrength(unsigned char rssi,unsigned char row);
/*** EndHeader */
void DisplaySignalStrength(unsigned char rssi,unsigned char row)
{
#ifdef BIO_METRIC
   if((DisplayMode == MODE_WAIT_FOR_CARD) || (USER_IDENTIFY_MODE == DisplayMode) || (DisplayMode == MODE_GPRS_DIAGNOSIS))
#else
   if((DisplayMode == MODE_WAIT_FOR_CARD))
#endif
   {
	   L_DisplayCharAtRow(12,'S',row);
	   L_DisplayCharAtRow(13,':',row);
	   L_DisplayCharRow(14,rssi,row);
   }
}
#endif

