

#include "LPC23xx.H"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "rdcont.h"
#include "serial.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "rdpoll.h"
#include "portlcd.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "userintf.h"


//__packed struct READER_STRUCT ReaderInfo[MAX_READERS_SUPPORT*2];    // Added to avoid any memory overwrite as this also contains code of 8 door :-(
#define MAX_EVENT_BUFFER	5
//__packed struct DOOR_CONTROL DRStruct[MAX_READERS_SUPPORT];
//__packed struct DOOR_ALARM_STATUS DoorAlStatus[MAX_READERS_SUPPORT];

extern struct DOOR_INFO Doorinfo;   //PANKAJ
//unsigned int olddata;
//unsigned char F_SendFireClose,F_RdrOtherSendCommand;
extern BYTE F_ChangeInInput;
extern unsigned char F_DISIndicator,F_DMZBuz;//F_DMZOccur;
unsigned int ReadDrInput(void);

unsigned int ReadDrInput(void)
{
char drmul;
	if(SysInfo.ControllerMode == 8)
		drmul = 2;
	else
		drmul = 1;
	if(F_ChangeInInput == 1)
	{
		MsgPrint(MSG_DOOR_CONT,(IOInput+IOInput2*0x100),"Change In Input=");
		F_ChangeInInput = 0;
	}

	if((ReaderInfo[0].DOTLEn_Dis == 1) && (Doorinfo.EXTDOTL_EN == 1))
    {
		if(DRStruct[0].DRMCStatus != IN_Dotl1)
		{
			if(IN_Dotl1==CLR)
				StoreCardInTrDB(DRStruct[0].LastCardNo,0+1,EVENT_PHYSICAL_DOOR_CLOSE);	//ARMF2011
			else
				StoreCardInTrDB(DRStruct[0].LastCardNo,0+1,EVENT_PHYSICAL_DOOR_OPEN);	//ARMF2011
		}
	  	DRStruct[0].DRMCStatus = IN_Dotl1;
   	}
	else
		DRStruct[0].DRMCStatus = CLR;
	DRStruct[0].DREgressStatus = (~IN_Egress1) & 0x0001;	 //ARMD0313
// For door two by default all inputs are made no active
	DRStruct[1].DREgressStatus = CLR;	 //ARMD0313
	DRStruct[1].DRMCStatus = CLR;  // By default DOTL for door 2 is not detected..
	return(0);
}

/*** BeginHeader DoorConditionControl*/
char DoorConditionControl(unsigned char drno,unsigned char opentype,unsigned char time,unsigned char dotltime);
/*** EndHeader */
char DoorConditionControl(unsigned char drno,unsigned char opentype,unsigned char time,unsigned char dotltime)
{
unsigned char  actualdoor;
	if(drno >= SysInfo.ControllerMode)
   		return(0xFF);
	MsgPrint(MSG_DOOR_CONT,opentype,"Door Open Requested ");
	MsgPrint(MSG_DOOR_CONT,drno,"Door No ");
	ReadDrInput();
	actualdoor = drno;
	DRStruct[drno].ShRdNo = actualdoor;
	if(CHECK_SHARED_DOTL(drno))
		drno= (drno/2)*2 ;
	if(opentype != DR_EXT_RLY_ON)
		DRStruct[drno].ShRdNo = actualdoor;
   	if(drno >= SysInfo.ControllerMode)
   		return(0xff);
	if(DRStruct[drno].DRStatus == DR_PC_USER_CLOSE)// NGD00078
	{	
		if((opentype == DR_FIRE_OPEN)||(opentype == DR_PC_USER_OPEN)||(opentype == DR_PC_NORMAL)||(opentype == DR_PC_USER_OPEN))
   			goto SWITCH_DOOR_CONTROL;
		else
			return(EVENT_DR_PC_USER_CLOSE);
	}
	if(DRStruct[drno].DRStatus == DR_PC_USER_OPEN)//NGD00078
	{	
		if((opentype == DR_FIRE_OPEN)||(opentype == DR_PC_USER_OPEN)||(opentype == DR_PC_NORMAL)||(opentype == DR_PC_USER_CLOSE))
   			goto SWITCH_DOOR_CONTROL;
		else
			return(EVENT_DR_PC_USER_OPEN);
	}
//	if((DisplayMode == MODE_MEMORY_FULL) || (F_TrnxMemFull == SET))        		 //D0011
//   	return(0xff);
SWITCH_DOOR_CONTROL:
	switch(opentype)
	{
		case DR_EGRESS_OPEN:
		case DR_ACCESS_OPEN:
		case DR_TZ_OPEN:
		DRStruct[drno].DROpenedChk = CLR;        //D0033
		if(CHECK_SHARED_DOTL(drno))
			DRStruct[actualdoor].DROpenedChk = CLR;        //D0033
		if((DRStruct[drno].DRStatus == DR_TZ_OPEN) || (DRStruct[drno].DRStatus == DR_FIRE_OPEN) || (DRStruct[drno].DRStatus == DR_USER_OPEN))
		{
			if(DRStruct[drno].DRCurrentStatus == CLR)
			{
				DoorOpen(drno);
//				if(CHECK_SHARED_DOTL(drno))
//					DRStruct[actualdoor].DRCurrentStatus = SET;					
				DRStruct[drno].DRCurrentStatus = SET;
	    		MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRStatus,"Door Status");
	    		MsgPrint(MSG_DOOR_CONT,opentype,"Old Door Status");
				if(CHECK_SHARED_DOTL(actualdoor))
				{
					DRStruct[actualdoor].DRStatus = opentype;
				}
			}
			if(DR_EGRESS_OPEN == opentype)
         	{
         		if(CHECK_SHARED_DOTL(drno))
				{
            		WeigandLedOn(drno);
            		WeigandLedOn(drno+1);
            	}
         	}
			WeigandLedOn(actualdoor);
		}
		else if(DRStruct[drno].DRStatus == DR_USER_CLOSE)
		{
	    	MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRStatus,"Door User Close so no action");
		}
		else
		{
			if(DRStruct[drno].Dotl_Alarm == SET)
			{
				DRStruct[drno].Dotl_Alarm=CLR;
				DRStruct[drno].ResetAlarm = CLR;
               	DoorAlStatus[drno].DOTLAlarm =CLR;
	    		MsgPrint(MSG_DOOR_CONT,opentype,"SAVE::DOTL ALARM RESET");
				StoreCardInTrDB(DRStruct[actualdoor].LastCardNo,drno+1,EVENT_DOTL1_ALARM_OFF);
			}
			if(DRStruct[drno].Force_Alarm==SET)
			{
				DRStruct[drno].Force_Alarm=CLR;
				DRStruct[drno].ResetAlarm = CLR;
				DoorAlStatus[drno].ForceAlarm =CLR;
				MsgPrint(MSG_DOOR_CONT,opentype,"SAVE::Force_Alarm RESET");
				StoreCardInTrDB(DRStruct[actualdoor].LastCardNo,drno+1,EVENT_DOTL1_ALARM_OFF);
			}
			DRStruct[drno].DRStatus = opentype;
			DRStruct[drno].RDOpTimer = time;
			DRStruct[drno].RDDotlTimer = dotltime;
			DoorOpen(drno);
			DRStruct[drno].DRCurrentStatus = SET;
			if(CHECK_SHARED_DOTL(drno))
				DRStruct[actualdoor].DRCurrentStatus = SET;	
/*			if(CHECK_SHARED_DOTL(actualdoor))
			{
				DRStruct[actualdoor].DRStatus = opentype;
				DRStruct[actualdoor].RDOpTimer = time;
			}
*/
			if(DR_EGRESS_OPEN == opentype)
			{
				if(CHECK_SHARED_DOTL(drno))
				{
					WeigandLedOn(drno);
					WeigandLedOn(drno+1);
				}
			}
			WeigandLedOn(actualdoor);
		}
		break;

		case DR_FIRE_OPEN:
		case DR_USER_OPEN:
		case DR_PC_USER_OPEN:
			DRStruct[drno].DRStatus = opentype;
			DoorOpen(drno);
			if(CHECK_SHARED_DOTL(actualdoor))
			{
				DRStruct[actualdoor].DRStatus = opentype;
	            WeigandLedOn((actualdoor/2)*2);
	            WeigandLedOn(((actualdoor/2)*2) + 1);
			}
			else
				WeigandLedOn(actualdoor);
         	if((DRStruct[drno].Dotl_Alarm==SET)||(DRStruct[drno].Force_Alarm==SET))
	      		StoreCardInTrDB(DRStruct[actualdoor].LastCardNo,drno+1,EVENT_DOTL1_ALARM_OFF );
			if(opentype == DR_PC_USER_OPEN)
	      		StoreCardInTrDB(00,drno+1,EVENT_DR_PC_USER_OPEN );	   //ARMF2011
			DRStruct[drno].DRCurrentStatus = SET;
			DRStruct[drno].ResetAlarm = CLR;
			DRStruct[drno].Dotl_Alarm=CLR;
			DRStruct[drno].Force_Alarm=CLR;
         	DoorAlStatus[drno].DOTLAlarm =CLR;
			DoorAlStatus[drno].ForceAlarm =CLR;
		break;

		case DR_EXT_RLY_ON:
			DRStruct[actualdoor].DRStatus = opentype;
			DRStruct[actualdoor].RDOpTimer = time;
			DRStruct[actualdoor].RDDotlTimer = dotltime;
			DoorOpen(actualdoor);
			DRStruct[actualdoor].DRCurrentStatus = SET;
			DRStruct[actualdoor].Dotl_Alarm = CLR;
			DRStruct[actualdoor].Force_Alarm = CLR;
			DRStruct[actualdoor].ResetAlarm = CLR;
         	DoorAlStatus[actualdoor].DOTLAlarm = CLR;
			DoorAlStatus[actualdoor].ForceAlarm = CLR;
		break;

		case DR_NORMAL:
		case DR_PC_NORMAL:
			DRStruct[drno].DRStatus = opentype;
			DoorClose(drno);
			if(CHECK_SHARED_DOTL(actualdoor))
			{
				DRStruct[actualdoor].DRStatus = opentype;
	            //if((Doorinfo.FREETIMEENABLE == CLR) || (!(CHECK_FREE_TZ(actualdoor)))) //NGD00174
	            {
					WeigandLedOff((actualdoor/2)*2);
					WeigandLedOff(((actualdoor/2)*2) + 1);
				}
			}
         	else
				WeigandLedOff(actualdoor);
			if(opentype == DR_PC_NORMAL)
	      		StoreCardInTrDB(00,drno+1,EVENT_DR_PC_NORMAL );	//ARMF2011	   
		break;

      	case DR_INTRUSION_CLOSE:     //F0011 Checking of Intrusion Alarm
		case DR_USER_CLOSE:
		case DR_PC_USER_CLOSE:
			DRStruct[drno].DRStatus = opentype;
			DoorClose(drno);
			if(CHECK_SHARED_DOTL(actualdoor))
			{
				DRStruct[actualdoor].DRStatus = opentype;
				WeigandLedOff((actualdoor/2)*2);
				WeigandLedOff(((actualdoor/2)*2) + 1);
			}
         	else
        		WeigandLedOff(actualdoor);
			if(opentype == DR_PC_USER_CLOSE)
	      		StoreCardInTrDB(00,drno+1,EVENT_DR_PC_USER_CLOSE );	 //ARMF2011 

			DRStruct[drno].Force_Alarm =CLR;
			DRStruct[drno].ResetAlarm = CLR;
			DRStruct[drno].Dotl_Alarm = CLR;
			DoorAlStatus[drno].DOTLAlarm =CLR;
			DoorAlStatus[drno].ForceAlarm =CLR;
			DRStruct[drno].DRChkDOTL = CLR;
		break;
	}
	return(DRStruct[drno].DRStatus);
}

/*** BeginHeader HandelDoorControlInputs*/
void HandelDoorControlInputs(unsigned char drno);
/*** EndHeader */
void HandelDoorControlInputs(unsigned char drno)
{
unsigned char i;
// IF Door open send... and door opened.. now dotl time over and door open time over still door is in open state
// Open and close door on following controls
// Fire input
// Egress
// TimeEvent
// TimeZoneOver
// Check DOTL and Fore door open Status
	if(drno >= SysInfo.ControllerMode)
		goto END;
//	if((DisplayMode == MODE_MEMORY_FULL) || (F_TrnxMemFull == SET))        		 //D0011
//   	return 0;

	ReadDrInput();
	if(CombinedIOInput != olddata)
	{
		olddata = CombinedIOInput;
	}
	if((DRStruct[drno].DRStatus == DR_ACCESS_OPEN) || (DRStruct[drno].DRStatus == DR_EGRESS_OPEN))
	{
		if(DRStruct[drno].RDOpTimer == 0)
		{
			//when door time out is happend 
			if(DRStruct[drno].DREgressStatus == CLR)
			{
				if((DRStruct[drno].DROpenedChk == CLR) || ((CHECK_SHARED_DOTL(drno) && DRStruct[(drno/2)*2].DROpenedChk == CLR)))
//				if(DRStruct[drno].DROpenedChk==CLR)
				{
  					MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRStatus,"SAVE::Door Not Opened on card/ egress ");
					if((ReaderInfo[drno].DOTLEn_Dis == 1) && (Doorinfo.EXTDOTL_EN == 1))			//D0007
	            	{
	                   	StoreCardInTrDB(0,DRStruct[drno].ShRdNo+1,EVENT_DOOR_NOT_OPEN);//DB002  Set card no. "00000" in 45 event transaction.
						DRStruct[drno].DROpenedChk = SET;
						if(CHECK_SHARED_DOTL(drno))
							DRStruct[(drno/2)*2].DROpenedChk = SET;
					}
				}
//				if(SysInfo.ContInOut != 5)
				{
					if(CHECK_SHARED_DOTL(drno))				  //ARMD0109
					{
	         			if((DRStruct[(drno/2)*2].RDOpTimer == 0) && (DRStruct[((drno/2)*2)+1].RDOpTimer == 0))
						{
							DoorClose(drno);
							WeigandLedOff((drno/2)*2);
							WeigandLedOff(((drno/2)*2)+1);
						}
					}
					else
					{
						DoorClose(drno);
						WeigandLedOff(drno);
		         	}
				}
				if(DR_EGRESS_OPEN == DRStruct[drno].DRStatus)
	         	{
		         	if(CHECK_SHARED_DOTL(drno))
		         	{
		            	WeigandLedOff((drno/2)*2) ;
		            	WeigandLedOff(((drno/2)*2)+1);
		         	}
				}
				if(WeigandOutLEdStatus != 1)	// NGD00077
				{
					DRStruct[drno].DRStatus = DR_NORMAL;
				}
				MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRMCStatus,"Door Time Closed  ");
			}
		}
	}
	else if(DRStruct[drno].DRStatus == DR_EXT_RLY_ON)
	{
		if(DRStruct[drno].RDOpTimer == 0)
		{
			DoorClose(drno);
			DRStruct[drno].DRStatus = DR_NORMAL;
		}
	}

// Check Magnetic contact of door
	if(DRStruct[drno].DRMCStatus == CLR)
	{
		if(DRStruct[drno].RDDotlTimer == 0)
			DRStruct[drno].DRChkDOTL = CLR;		// indicates that door is close before DOTL alarm so next alarm is door open alarm
		// Indicates that door is closed
		if((DRStruct[drno].Dotl_Alarm == SET) || (DRStruct[drno].Force_Alarm == SET))
		{
			DRStruct[drno].ResetAlarm = CLR;
			DRStruct[drno].DRChkDOTL = CLR;
			DRStruct[drno].Force_Alarm = CLR;
			DRStruct[drno].Dotl_Alarm = CLR;
			DoorAlStatus[drno].DOTLAlarm = CLR;
			DoorAlStatus[drno].ForceAlarm = CLR;
			MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRMCStatus,"CLEARED ALARM ");
			MsgPrint(MSG_DOOR_CONT,drno,"SAVE::Force Alarm RESET");
			StoreCardInTrDB(DRStruct[drno].LastCardNo,drno+1,EVENT_DOTL1_ALARM_OFF);
		}
	}
	else
	{
/*    	if(CHECK_SHARED_DOTL(drno))
      {
   		DRStruct[((drno/2)*2)+1].DROpenedChk=SET;
			DRStruct[(drno/2)*2].DROpenedChk=SET;
      }  */
		DRStruct[drno].DROpenedChk = SET;

	// Door in open state
		if((DRStruct[drno].Dotl_Alarm == CLR) && (DRStruct[drno].Force_Alarm == CLR))
		{
			if(DRStruct[drno].RDDotlTimer == 0)
			{ // As DoTL timer is zero indicates there is dotl or other alarm as door is still in open state
				switch(DRStruct[drno].DRStatus)
				{
					case DR_FIRE_OPEN:
					case DR_USER_OPEN:
					case DR_TZ_OPEN:
					case DR_PC_USER_CLOSE:	// NGD00175
					case DR_PC_USER_OPEN:   // NGD00175
						MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRMCStatus,"Door Open Alarm NO** DoorMode=");
						break;
               		case DR_INTRUSION_CLOSE:
	               		MsgPrint(MSG_DOOR_CONT,DRStruct[drno].DRMCStatus,"Door Close Alarm NO** DoorMode=");
               			break;
					default:
						if(DRStruct[drno].DRChkDOTL == SET)
						{
//							MsgPrint(MSG_DOOR_CONT,ReceivedCardNo,"ALARM::DOTL Alarm CardNo=");
							DRStruct[drno].Dotl_Alarm = SET;
							DoorAlStatus[drno].DOTLAlarm = SET;
							DRStruct[drno].DRChkDOTL = CLR;
							MsgPrint(MSG_DOOR_CONT,drno,"SAVE::DOTLAlarm");
							StoreCardInTrDB(DRStruct[DRStruct[drno].ShRdNo].LastCardNo,drno+1,EVENT_DOTL1_ALARM);
						}
						else
						{
							DRStruct[drno].Force_Alarm = SET;
							DoorAlStatus[drno].ForceAlarm = SET;
							StoreCardInTrDB(DRStruct[DRStruct[drno].ShRdNo].LastCardNo,drno+1,EVENT_FORCE1_ALARM);
						}
						break;
				}
			}
		}

	}
//#ifdef SUPPORT_NSERIES2
  //	DoorInterlockIndicator(drno);    //281210-1 DIS Reader LED Indicator
//#endif

	if(((DRStruct[drno].Dotl_Alarm == SET)||(DRStruct[drno].Force_Alarm == SET)) && (DRStruct[drno].ResetAlarm == CLR))
		DOTLLedOn(drno);
	else
		DOTLLedOff(drno);
//-------------------------------------------------------------
//Check Egress Input Pin
//  if(IN_Intrusion == SET) //F0011 Checking of Intrusion Alarm
	if(!(INTRUSION_STATUS == SET))
	{
	   if(DRStruct[drno].DREgressStatus == SET)
	   {
	   // indicates that egress pin pressed
	      if(DR_NORMAL == DRStruct[drno].DRStatus)              //defect : D0003
	      {
	   		if(DRStruct[drno].DRCurrentStatus == CLR)
	   		{
	//          MsgPrint(MSG_DOOR_CONT,drno,"SAVE::Egress Open");
	   			StoreCardInTrDB(0,drno+1,EVENT_DOOR_OPEN_EGRESS);
//				AddToSendQueue(drno,QUEUE_CMD_WEI_LED_ON,(drno%2)+1,ReaderInfo[drno].DOpTime,ReaderInfo[drno].DOTLTime,(drno%2)+1,1);
			//	if(CHECK_SHARED_DOTL(drno))
				//	AddToSendQueue(drno+1,QUEUE_CMD_WEI_LED_ON,((drno+1)%2)+1,ReaderInfo[drno].DOpTime,ReaderInfo[drno].DOTLTime,((drno+1)%2)+1,1);
	   		}
	//       MsgPrint(MSG_DOOR_CONT,drno,"Egress Open Receive");
	   	}
// for panel devices this is not required
//#ifdef SUPPORT_NSERIES2
         //if(DoorInterlockCheck(drno) == 0)	//281210-1
//#endif
	   	DoorConditionControl(drno,DR_EGRESS_OPEN,ReaderInfo[drno].DOpTime,ReaderInfo[drno].DOTLTime);
	//    MsgPrint(MSG_DOOR_CONT,IOInput,"HandelDoorControlInputs:Change In Input=");
	//    MsgPrint(MSG_DOOR_CONT,CurrentInput,"HandelDoorControlInputs:Change In CurrentInput=");
	//    MsgPrint(MSG_DOOR_CONT,drno," Egress Open Dr No");
	   }
  }
//------------------------------------------------------------------------------------
	if((ENDI_INPUT_TAMPER & SysInfo.InputED) == ENDI_INPUT_TAMPER)
	{
		// indicates that tamper happned
		if(((IN_Tamper == CLR)&&(TAMPER_ALARM_RESET == CLR))||(AlarmGenerateFlg[1] == SET))
      	{
	      	if(TAMPER_STATUS != SET)
 	         	StoreCardInTrDB(0,1,EVENT_TAMPER_ALARM_HIGH);
         	TAMPER_STATUS = SET;
         	MakeSound(50);                    //A00015 Buzzer should be ON for TAMPER
			if(AlarmGenerateFlg[1] == SET)
				TAMPER_ALARM_RESET = SET;                     
      	}
	   else if((TAMPER_STATUS == SET)&&(TAMPER_ALARM_RESET == CLR))
	   {
	      MakeSound(50);                      //A00015 Buzzer should be ON for TAMPER
	   }
	   if(((IN_Tamper == SET)&&(TAMPER_ALARM_RESET == SET))&&(AlarmGenerateFlg[1] == CLR))			  	// Shivraj
		{
			if(TAMPER_ALARM_RESET == SET)
				StoreCardInTrDB(0,1,EVENT_TAMPER_ALARM_LOW);
		    TAMPER_STATUS = CLR;
			TAMPER_ALARM_RESET = CLR;
		}
	   if((TAMPER_STATUS == SET) && (IN_Tamper == SET) && ((Doorinfo.FireType & ENDI_INPUT_TAMPER) == 0x02)&&(AlarmGenerateFlg[1] == CLR))     //A00016
	   {
 	   	StoreCardInTrDB(0,1,EVENT_TAMPER_ALARM_LOW);
	      TAMPER_STATUS = CLR;
	   }
	   if((TAMPER_STATUS == SET) && (TAMPER_ALARM_RESET == SET) && (AlarmGenerateFlg[1] == CLR))        //Shivraj
	   {
 	   	StoreCardInTrDB(0,1,EVENT_TAMPER_ALARM_LOW);
	      TAMPER_STATUS = CLR;
	   }
	}
	else if(TAMPER_STATUS == SET)
	{
      StoreCardInTrDB(0,1,EVENT_TAMPER_ALARM_LOW);
      TAMPER_STATUS = CLR;
	}
//------------------------------------------------------------------------------------
//   if(SysInfo.ContInOut != 5) 	//NGD00161  Do not check fire alarm if Unit as a Reader
//   {
	if((ENDI_INPUT_FIRE & SysInfo.InputED) == 0x01)
	{
		// indicates that Fire happned
      	if(((IN_Fire == CLR)&&(FIRE_ALARM_RESET == CLR))||(AlarmGenerateFlg[0] == SET))	   	//fire
      	{
	      	if(FIRE_STATUS != SET)
	         	StoreCardInTrDB(0,1,EVENT_FIRE_ALARM_HIGH);
	      	if(INTRUSION_STATUS == SET)
	      	{
	         	StoreCardInTrDB(0,1,EVENT_INTRUSION_ALARM_LOW);
	         	INTRUSION_STATUS = CLR;
	 		}
         	FIRE_STATUS = SET;
			F_RdrOtherSendCommand = SET;
			for(i=0;i<SysInfo.ControllerMode;i++)
			{
			 	DoorConditionControl(i,DR_FIRE_OPEN,1,1);
         		if((DRStruct[i].Dotl_Alarm==SET)||(DRStruct[i].Force_Alarm==SET))
					StoreCardInTrDB(0,i+1,EVENT_DOTL1_ALARM_OFF);
				DRStruct[i].Dotl_Alarm = CLR;
				DRStruct[i].ResetAlarm = CLR;
				DRStruct[i].Force_Alarm = CLR;
				DoorAlStatus[i].DOTLAlarm = CLR;
				DoorAlStatus[i].ForceAlarm = CLR;
			}
         	MakeSound(50);                    //A00015 Buzzer should be ON for FIRE
			if(AlarmGenerateFlg[0] == SET)
				FIRE_ALARM_RESET = SET;                   
      	}
		else if((FIRE_STATUS == SET)&&(FIRE_ALARM_RESET == CLR))		  //NO fire
	  	{
			F_RdrOtherSendCommand = SET;
			for(i=0;i<SysInfo.ControllerMode;i++)
			{
				DoorConditionControl(i,DR_FIRE_OPEN,1,1);
				if((DRStruct[i].Dotl_Alarm==SET)||(DRStruct[i].Force_Alarm==SET))
					StoreCardInTrDB(0,i+1,EVENT_DOTL1_ALARM_OFF);
				DRStruct[i].Dotl_Alarm = CLR;
				DRStruct[i].Force_Alarm = CLR;
				DRStruct[i].ResetAlarm = CLR;
				DoorAlStatus[i].DOTLAlarm = CLR;
				DoorAlStatus[i].ForceAlarm = CLR;
			}
	        MakeSound(50);                    //A00015 Buzzer should be ON for FIRE
		}
		if(((IN_Fire == SET)&&(FIRE_ALARM_RESET == SET))&&(AlarmGenerateFlg[0] == CLR))			  	// Shivraj
		{
			if(FIRE_ALARM_RESET == SET)
				StoreCardInTrDB(0,1,EVENT_FIRE_ALARM_LOW);
		    FIRE_STATUS = CLR;
			for(i=0;i<SysInfo.ControllerMode;i++)
				DoorConditionControl(i,DR_NORMAL,1,1);
	        F_SendFireClose = SET;
			FIRE_ALARM_RESET = CLR;
		}
		if((FIRE_STATUS == SET) && (IN_Fire == SET) && ((Doorinfo.FireType & ENDI_INPUT_FIRE)  == 0x01)&&(AlarmGenerateFlg[0] == CLR))        //Shivraj
		{
			StoreCardInTrDB(0,1,EVENT_FIRE_ALARM_LOW);
		    FIRE_STATUS = CLR;
			for(i=0;i<SysInfo.ControllerMode;i++)
				DoorConditionControl(i,DR_NORMAL,1,1);
	        F_SendFireClose = SET;	  
		}
		if((FIRE_STATUS == SET) && (FIRE_ALARM_RESET == SET) && (AlarmGenerateFlg[0] == CLR))        //Shivraj
		{
			StoreCardInTrDB(0,1,EVENT_FIRE_ALARM_LOW);
		    FIRE_STATUS = CLR;
			for(i=0;i<SysInfo.ControllerMode;i++)
				DoorConditionControl(i,DR_NORMAL,1,1);
	         F_SendFireClose = SET;	  
		}
	}
	else if(FIRE_STATUS == SET)
	{
		StoreCardInTrDB(0,1,EVENT_FIRE_ALARM_LOW);
		FIRE_STATUS = CLR;
		for(i=0;i<SysInfo.ControllerMode;i++)
			DoorConditionControl(i,DR_NORMAL,1,1);
        F_SendFireClose = SET;
		F_RdrOtherSendCommand = SET;
	}
//  }
//--------------------------------------------------------------------------------------
	if(((ENDI_INPUT_INTRUSION & SysInfo.InputED) == 0x04)  && (FIRE_STATUS == CLR))  //F0011 Checking of Intrusion Alarm
	{	
		// indicates that Intrusion happned
		if(((IN_Intrusion == CLR)&&(INTRUSN_ALARM_RESET == CLR))||(AlarmGenerateFlg[2] == SET))
		{
			if(INTRUSION_STATUS != SET)
				StoreCardInTrDB(0,1,EVENT_INTRUSION_ALARM_HIGH);
			INTRUSION_STATUS = SET;
			for(i=0;i<SysInfo.ControllerMode;i++)
			{
				DoorConditionControl(i,DR_INTRUSION_CLOSE,1,1);
				if(DRStruct[i].DREgressStatus == SET)
					DRStruct[i].DREgressStatus = CLR;
			}
			MakeSound(50);
			if(AlarmGenerateFlg[2] == SET)
				INTRUSN_ALARM_RESET = SET;
		}
		else if((INTRUSION_STATUS == SET)&&(INTRUSN_ALARM_RESET == CLR))
		{
			for(i=0;i<SysInfo.ControllerMode;i++)
			{
				DoorConditionControl(i,DR_INTRUSION_CLOSE,1,1);
				if(DRStruct[i].DREgressStatus == SET)
					DRStruct[i].DREgressStatus = CLR;
			}
			MakeSound(50);
		}
		
		if(((IN_Intrusion == SET)&&(INTRUSN_ALARM_RESET == SET))&&(AlarmGenerateFlg[2] == CLR))			  	// Shivraj
		{
			if(INTRUSN_ALARM_RESET == SET)
				StoreCardInTrDB(0,1,EVENT_INTRUSION_ALARM_LOW);
		    INTRUSION_STATUS = CLR;
			for(i=0;i<SysInfo.ControllerMode;i++)
				DoorConditionControl(i,DR_NORMAL,1,1);
			INTRUSN_ALARM_RESET = CLR;
		}
		
		if((INTRUSION_STATUS == SET) && (IN_Intrusion == SET) && ((Doorinfo.FireType & ENDI_INPUT_INTRUSION) == 0x04)&&(AlarmGenerateFlg[2] == CLR))     //A00016
		{
			StoreCardInTrDB(0,1,EVENT_INTRUSION_ALARM_LOW);
			INTRUSION_STATUS = CLR;
			for(i=0;i<SysInfo.ControllerMode;i++)
				DoorConditionControl(i,DR_NORMAL,1,1);
		}
		if((INTRUSION_STATUS == SET) && (INTRUSN_ALARM_RESET == SET) && (AlarmGenerateFlg[2] == CLR))        //Shivraj
		{
			StoreCardInTrDB(0,1,EVENT_INTRUSION_ALARM_LOW);
			INTRUSION_STATUS = CLR;
			for(i=0;i<SysInfo.ControllerMode;i++)
				DoorConditionControl(i,DR_NORMAL,1,1);
		}
	}
	else if(INTRUSION_STATUS == SET)
	{
	   	StoreCardInTrDB(0,1,EVENT_INTRUSION_ALARM_LOW);
	   	INTRUSION_STATUS = CLR;
	   	for(i=0;i<SysInfo.ControllerMode;i++)
	   		DoorConditionControl(i,DR_NORMAL,1,1);
	}
//indicates that Finger sense i/p detected
END:
	if((IN_IRSense == CLR) && (F_Poll_Bio_Sensor == SET))  
	{
		F_FingerSense = SET;
	}	
}



/*** BeginHeader InitialiseDrData*/
void InitialiseDrData(void);
/*** EndHeader */
void InitialiseDrData(void)
{
unsigned char idoor;

	CombinedIOInput = NO_INPUT_VALUE;
	IOInput = NO_INPUT_VALUE&0xFF;
	IOInput2 = NO_INPUT_VALUE/0x100;

	for(idoor=0;idoor<SysInfo.ControllerMode;idoor++)
	{
		DRStruct[idoor].LastCardNo = 0;
		DRStruct[idoor].FCode = 0;
		DRStruct[idoor].DRMCStatus = CLR;
		DRStruct[idoor].DREgressStatus = CLR;
		DRStruct[idoor].RDDotlTimer = 0;
		DRStruct[idoor].RDOpTimer = 0;
		DRStruct[idoor].ResetAlarm = CLR;
		DRStruct[idoor].LastCardTimer = 0;
		DRStruct[idoor].DRLastCardChk = CLR;
		DRStruct[idoor].DRStatus = DR_NORMAL;
		DRStruct[idoor].Force_Alarm = CLR;
		DRStruct[idoor].Dotl_Alarm = CLR;
		DoorAlStatus[idoor].DOTLAlarm = CLR;
		DoorAlStatus[idoor].ForceAlarm = CLR;
		DRStruct[idoor].DRCurrentStatus = CLR,
		DRStruct[idoor].DRChkDOTL = CLR;
		DRStruct[idoor].DROpenedChk = SET;
//		DRStruct[idoor].FireTamper = CLR;
		DOTLLedOff(idoor);
		FIRE_ALARM_RESET 	= CLR;
		TAMPER_ALARM_RESET 	= CLR;
		INTRUSN_ALARM_RESET	= CLR;
 		if(ReaderInfo[idoor].DOpTime==0)
	    	ReaderInfo[idoor].DOpTime =1;
		if(ReaderInfo[idoor].DOTLTime==0)
           	ReaderInfo[idoor].DOTLTime = 1;
#ifdef ENABLE_PIN_PROX
	  	ReaderData[idoor].PinTimeOut = MAX_PIN_READ_TIME_OUT;		
#endif
	//	AddEventToBuffer(SL_EV_SLAVE_RESTART,1,1,0);
		if(DRStruct[idoor].DRStatus == DR_USER_OPEN)         //D0044
			DoorConditionControl(idoor,DR_USER_OPEN,1,1);
		else if(DRStruct[idoor].DRStatus == DR_USER_CLOSE)
			DoorConditionControl(idoor,DR_USER_CLOSE,1,1);
		else
			DoorConditionControl(idoor,DR_NORMAL,1,1);
	}
	TAMPER_STATUS = FIRE_STATUS = INTRUSION_STATUS = CLR;
	F_SendFireClose = CLR;
}

#ifdef SUPPORT_NSERIES2
//====================================DIS check =======================================	//281210-1
/*** BeginHeader DoorInterlockCheck*/
//unsigned char DoorInterlockCheck(unsigned char doorno);
/*** EndHeader */
/*unsigned char DoorInterlockCheck(unsigned char doorno)
{
// following function valid only for 2 door system
	if((Doorinfo.DoorInterlock == 1) && (!CHECK_SHARED_DOTL(doorno)))
	{
      ReadDrInput();    //Read Door status
      if(DRStruct[!doorno].DRMCStatus != CLR)
         return(1);
	}
   return(0);
}
 */
//============================DIS LED blinker===================================	//281210-1
/*** BeginHeader DoorInterlockIndicator*/
//void DoorInterlockIndicator(unsigned char doorno);
/*** EndHeader */
/*void DoorInterlockIndicator(unsigned char doorno)
{
	if((Doorinfo.DoorInterlock == 1) && (!CHECK_SHARED_DOTL(doorno)))
   {
      switch(F_DISIndicator)           //toggle LED
      {
         case 0:
            if(DRStruct[doorno].DRMCStatus != CLR)
               WeigandLedOn(!doorno);
            else
            {
               if(DRStruct[!doorno].DRCurrentStatus == CLR)
                  WeigandLedOff(!doorno);
            }
            break;
         case 1:
            if((DRStruct[doorno].DRMCStatus != CLR) && (DRStruct[!doorno].DRCurrentStatus == CLR))
               WeigandLedOff(!doorno);
            break;
      }
   }
}*/
#endif

#ifdef UNDER_TESTING
/*--------------------------------------------------------------------------*/
/*** BeginHeader MakeWeigandBuzON*/
void MakeWeigandBuzON(unsigned char rdrno, unsigned char type);
/*** EndHeader */
void MakeWeigandBuzON(unsigned char rdrno, unsigned char type)
{
	rdrno--;
	DRStruct[rdrno].SoundType = type;
	if(DRStruct[rdrno].SoundType == SOUND_DOUBLE_BEEP)
	{
//		DRStruct[rdrno].SoundTimer = TIME_SOUND_DOUBL_BEEP * 14;
		DRStruct[rdrno].SoundTimer = TIME_SOUND_DOUBL_BEEP / 5;
	}
	else
	{
//		DRStruct[rdrno].SoundTimer = type * 14;
		DRStruct[rdrno].SoundTimer = type / 5;
	}
	WeigandBuzOn(rdrno);
}

/*--------------------------------------------------------------------------*/
/*** BeginHeader WeigandBuzControl*/
void WeigandBuzControl(unsigned char rdno);
/*** EndHeader */
void WeigandBuzControl(unsigned char rdno)
{	   
	if(SysInfo.ControllerMode == 8)
	{
		if(rdno % 2)
			return;
		rdno = rdno / 2;
	}
	if(DRStruct[rdno].SoundTimer == 0)									
	{																
		if(DRStruct[rdno].SoundType == SOUND_DOUBLE_BEEP)				
		{															
//			DRStruct[rdno].SoundTimer = TIME_SOUND_DOUBL_BEEP * 14;		
			DRStruct[rdno].SoundTimer = TIME_SOUND_DOUBL_BEEP / 5;		
			DRStruct[rdno].SoundType = SOUND_DOUBLE_BEEP_OFF;			
			WeigandBuzOff(rdno);										
		}															
		else if(DRStruct[rdno].SoundType == SOUND_DOUBLE_BEEP_OFF)		
		{															
			WeigandBuzOn(rdno);										
//			DRStruct[rdno].SoundTimer = TIME_SOUND_DOUBL_BEEP * 14;		
			DRStruct[rdno].SoundTimer = TIME_SOUND_DOUBL_BEEP / 5;		
			DRStruct[rdno].SoundType = 0;								
		}															
		else if(DRStruct[rdno].F_BuzzerOn != CLR)						
		{															
			WeigandBuzOff(rdno);										
		}															
	}																
}
#endif
