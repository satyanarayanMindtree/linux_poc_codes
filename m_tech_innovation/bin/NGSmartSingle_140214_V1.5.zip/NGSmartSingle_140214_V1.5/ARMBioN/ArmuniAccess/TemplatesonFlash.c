#include <stdio.h>
#include <string.h>
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "timer.h"
#include "spi.h"
#include "serial.h"
#include "cardmgmt.h"
#include "access.h"
#include "memory.h"
#include "memmap.h"
#include "portlcd.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "TemplatesonFlash.h"
#include "../../SDCard/SD_routines.h"
#include "wdt.h"

__packed extern unsigned char  SDbuf1[260], SDbuf2[260];//, SDbuf1[260], SDbuf2[260];

//_CExtraInfo tExtInfo;
///////////////////////////////////////// start of SD related function ////////////////////////////////////////////////
/*-----------------------------------------------------------------------------------------*/
/* following function will store template data to SD card 
// first 2 byte is template size then 8 byte  for future use .
// then we store template data */

int AddTemplateToSD( struct SD_TEMPLATE_DATA SDtemplateinfo, unsigned int cardindex,unsigned char Tno)
{
unsigned int i,BlockNo;
	if(Tno>MAX_TEMPLATE_SD_PERUSER)
		return (0);
	if(Tno==0)							 //NG0021
		return (0);		
	Tno--;							 //NG0021
	// We will assume that per one page we will sotre one template to start with them we will mody this function
//			Store received template at this location 
#ifdef	INSERT_SDCARD
			SDtemplateinfo.ChkSum = 0;
			SDtemplateinfo.ChkSum = GetCheckSum((unsigned char*)&SDtemplateinfo,sizeof(SDtemplateinfo));   //NGD00028
			memcpy((char*)&SDbuf1,(char*)&SDtemplateinfo,10);
			for(i=10;i<512;i++)
			{				
				if(i <= 259) 
				{
					SDbuf1[i] = SDtemplateinfo.TData[i-10];
				}
				else
				{
					SDbuf2[i - 260] = SDtemplateinfo.TData[i-10];		
				}				
			}
// Every template uses 1 Page so for 1 user 
			BlockNo = SD_START_BLOCK_TEMPLATE + cardindex*MAX_TEMPLATE_SD_PERUSER + Tno;
			if(BlockNo < SD_START_BLOCK_USERIMAGE )
			{	
				if(SD_writeSingleBlock(BlockNo))
				{ // return 0 if error is generated 
					return 0;
				}
			}
	return(cardindex);		
#endif			
}
/*-----------------------------------------------------------------------------------------*/
/* following function will read template data from SD */
/*-----------------------------------------------------------------------------------------*/
unsigned char ReadTemplateFromSD(unsigned int tindex,struct SD_TEMPLATE_DATA *tmpinfobuff,unsigned char tno)
{
//unsigned short cardtemplatepno;
unsigned int BlockNo;	
#ifdef INSERT_SDCARD
	if(tno>MAX_TEMPLATE_SD_PERUSER)
		return (1);
	if(tno==0)					  //NG0021
		return (1);		
	tno--;						  //NG0021
 	if(tindex <= MAX_NO_OF_CARD)		
   	{
		BlockNo = SD_START_BLOCK_TEMPLATE + tindex*MAX_TEMPLATE_SD_PERUSER + tno;
  		//cardtemplatepno = FL_TEMPLATE_DATA_PAGE_NO + tindex;
		//MainMem_ReadPage(cardtemplatepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
		if(BlockNo < SD_START_BLOCK_USERIMAGE)	
			SD_readSingleBlock ( BlockNo );// Read from sector 
		else
			return (1);
		memcpy((char *)tmpinfobuff,(char *)&SDbuffer,sizeof(struct SD_TEMPLATE_DATA));	//NGD00036	
      	return(0);
	}
   else 
   		return(1);
#endif	 
}
/*-----------------------------------------------------------------------------------------*/
/* Following function will return index of cno's template no. from SD,
if Template no is zero it will search for all templates for that card and return index of 1st template*/
/*-----------------------------------------------------------------------------------------*/
// int SearchTemplateFromSD(CARDNO_DATA_STORAGE_TYPE cno,char tno)
// {
// struct TEMPLATE_DATA  *tmpdata;	
// short temp1;
//    	temp1 = 0;
// #ifdef INSERT_SDCARD	
// 	while(temp1 < MAX_TEMPLATES)
// 	{
// 		//MainMem_ReadPage(FL_TEMPLATE_DATA_PAGE_NO+temp1,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);  
// 		SD_readSingleBlock( SD_START_BLOCK_TEMPLATE + temp1 );// Read from sector 
// 		tmpdata = (struct TEMPLATE_DATA  *)SDbuffer;				
// 		if((tmpdata->CardNo == cno) &&(tmpdata->TemplateNo ==tno))
// 		{
// 			return(temp1);
// 		}
// 		temp1++;
// #ifdef ENABLE_WATCHDOG
// 		if( (temp1%100) == 0)  			 
// 			WDTFeed();
// #endif		
// 	}
// 	return(CARD_NOT_FOUND);
// #endif
// 	
// }
/*-----------------------------------------------------------------------------------------*/
/* Following function will delete all templates available in SD 
*/
/*-----------------------------------------------------------------------------------------*/
char DelAllTempletSD(void)	   //NOTE: Delete this info also when any card will get deleted 
								//also Add to InitialiseDefaultSelect()
{
//    struct TEMPLATE_DATA tdata;	
   	unsigned int  temp1,i,err;
   	temp1 = 0;
//	memset(&tdata,0,sizeof(tdata));
#ifdef INSERT_SDCARD
	for(i=0;i<512;i++)
	{
		if(i <= 259) 
		{
			SDbuf1[i] = temp1;//((BYTE *)&tdata)[i];
		}
		else
		{
			SDbuf2[i - 260] = temp1;//((BYTE *)&tdata)[i];		
		}
	}
	while(temp1 < MAX_TEMPLATES)
	{
		if((SD_START_BLOCK_TEMPLATE + temp1) < SD_START_BLOCK_USERIMAGE)
			err = SD_writeSingleBlock(SD_START_BLOCK_TEMPLATE + temp1);
		if(err != 0)
			return(ERROR_SD_WRITE_FAIL);
		temp1++;	
#ifdef ENABLE_WATCHDOG
		if( (temp1%100) == 0)  			 
			WDTFeed();
#endif		
	}
#endif
	return(0);
}
/*-----------------------------------------------------------------------------------------*/
/* Following function will delete all template of Sigle user */
/*-----------------------------------------------------------------------------------------*/
int DelTempletSD(unsigned int cardindex)	 								
{
unsigned int i,BlockNo,temp1;
	temp1 = 0;
#ifdef INSERT_SDCARD
	for(i=0;i<512;i++)
	{
		if(i <= 259) 
		{
			SDbuf1[i] = temp1;//((BYTE *)&tdata)[i];
		}
		else
		{
			SDbuf2[i - 260] = temp1;//((BYTE *)&tdata)[i];		
		}
	}
	BlockNo = SD_START_BLOCK_TEMPLATE + cardindex*MAX_TEMPLATE_SD_PERUSER;

	for(i=0;i<MAX_TEMPLATE_SD_PERUSER;i++)	 //NG0021
	{
		if(BlockNo < SD_START_BLOCK_USERIMAGE )	 		
		{	
			if(SD_writeSingleBlock(BlockNo + i))
			{
				return 1;//error is generated
			}
		}
	}
	return(0);		
#endif			
}

/*-----------------------------------------------------------------------------------------*/
/* Following function will add card template info to _CExtraInfo structure */
/*-----------------------------------------------------------------------------------------*/
//in below index starts from 0
int AddCardTemplateInfoToFlash(unsigned int cardindex,_CExtraInfo  *ExtInfoBuff)  // tno 0000 1111 4 template
{
	unsigned int tpos,cardtemplatepno;
  	if(cardindex <= MAX_NO_OF_CARD)
   	{					
		cardtemplatepno = GET_CARD_XTRA_DATA_PAGE_NUMBER_FROMINDEX(cardindex);
		MainMem_ReadPage(cardtemplatepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);		 //NG005
		tpos = GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_BYTE(cardindex);
//		CardExtraData.TemplateData = ((CardExtraData.TemplateImageData&0xF0) | (tno&0x0F));		
		memcpy((BYTE *)&tempwrbuf[tpos],(BYTE *)ExtInfoBuff,CARD_EXTRA_DATA_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		BuffWrt_MainMem(cardtemplatepno,1);
		MsgPrint(MSG_WARNING,cardindex,"AddCardNameToFlash: cardindex  =");
      	return(0);
   }
   else
   		return(1);
}
/*-----------------------------------------------------------------------------------------*/
/* Following function will read template info from cardindex location and stores in 
_CExtraInfo strucure */
/*-----------------------------------------------------------------------------------------*/
unsigned char ReadCardTemplateInfoFromFlash(unsigned int cardindex,_CExtraInfo  *ExtInfoBuff)
{	
	unsigned int tpos,cardtemplatepno;
 	if(cardindex <= MAX_NO_OF_CARD)		
   	{
  		cardtemplatepno = GET_CARD_XTRA_DATA_PAGE_NUMBER_FROMINDEX(cardindex);
		MainMem_ReadPage(cardtemplatepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
		tpos = GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_BYTE(cardindex);
		memcpy((char *)ExtInfoBuff,(char *)&tempwrbuf[tpos],CARD_EXTRA_DATA_BYTES);
      	return(0);
    }
   else 
   		return(1);
}
/*-----------------------------------------------------------------------------------------*/
/* NOTE: Delete all Extra info of Card 
delete in InitialiseDefaultSelect() fn for initialisatiion
*/
/*-----------------------------------------------------------------------------------------*/
void DelAllCardTemplateInfoFromFlash(void)
{
unsigned int maxpages,count;
   	maxpages = MAX_PAGES_OF_EXTRA_CARD_DATA;
   	count = 0;
	memset(tempwrbuf,0x00,sizeof(tempwrbuf));
	while(count < maxpages)
	{
		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    	BuffWrt_MainMem(FL_CARD_EXTRA_DATA_PAGE_NO+count,1); 
		count++;	
#ifdef ENABLE_WATCHDOG
		if((count%100) == 0)  			 
			WDTFeed();
#endif		
	}
}
/*-----------------------------------------------------------------------------------------*/
// NOTE: Delete Single CardData-> Extra info 
/*-----------------------------------------------------------------------------------------*/
// get page no and pos->from index ->read page no in buff -> append buf[pos] ->0x00-> write that page 

int DelCardTemplateInfoFromFlash(unsigned int cardindex)
{
unsigned int tpos,cardtemplatepno;

  	if(cardindex <= MAX_NO_OF_CARD)
   	{					
		cardtemplatepno = GET_CARD_XTRA_DATA_PAGE_NUMBER_FROMINDEX(cardindex);
		MainMem_ReadPage(cardtemplatepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
		tpos = GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_BYTE(cardindex);
//		CardExtraData.TemplateData = ((CardExtraData.TemplateImageData&0xF0) | (tno&0x0F));		
//		memcpy((BYTE *)&tempwrbuf[tpos],(BYTE *)ExtInfoBuff,CARD_EXTRA_DATA_BYTES);
		memset((BYTE *)&tempwrbuf[tpos],0x00,CARD_EXTRA_DATA_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		BuffWrt_MainMem(cardtemplatepno,1);
		MsgPrint(MSG_WARNING,cardindex,"AddCardNameToFlash: cardindex  =");
      	return(0);
   }
   else
   		return(1);
}
/*-----------------------------------------------------------------------------------------*/
/** this function is called after addCard function, this function takes index.
it stores extra data at that index in extra card data location(flash1).
*/
int AddCardExtraData(unsigned int cardindex,_CExtraInfo *tmpinfobuff)
{
	unsigned int tpos,cardtemplatepno;
  	if(cardindex <= MAX_NO_OF_CARD)
   	{		
		MsgPrint(MSG_WARNING,cardindex,"AddCardExtraData:cardindex=");
		cardtemplatepno = GET_CARD_XTRA_DATA_PAGE_NUMBER_FROMINDEX(cardindex);
		MsgPrint(MSG_WARNING,cardtemplatepno,"Pageno.=");

		MainMem_ReadPage(cardtemplatepno,0,(BYTE* )&tempwrbuf,FLSH_APP_PAGE_SZ);
		tpos = GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_BYTE(cardindex);
		MsgPrint(MSG_WARNING,tpos,"pos in page with bytes=");

		memcpy((char *)&tempwrbuf[tpos],(char *)tmpinfobuff,CARD_EXTRA_DATA_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		BuffWrt_MainMem(cardtemplatepno,1);
		MsgPrint(MSG_WARNING,0,"AddCardNameToFlash---------");
      	return(0);
   }
   else
   		return(1);
}


