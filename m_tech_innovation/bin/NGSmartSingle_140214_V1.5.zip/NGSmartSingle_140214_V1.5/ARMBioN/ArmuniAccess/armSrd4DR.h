/*
This file is created to hold hardware information for board 8RD
This is for 4 Door 8 Reader board where reader is connected on serial
*/
// HW_ARM_8RD1_0
												
#define B_BUZZER_PIN		1 << 28	
#define DIR_BUZZER_BIT()	{FIO0DIR |= B_BUZZER_PIN;} 	
#define BUZZER_LOW()		{FIO0CLR |= B_BUZZER_PIN;} 	
#define BUZZER_HIGH()		{FIO0SET |= B_BUZZER_PIN;} 
#define BUZZER_OFF()		{DIR_BUZZER_BIT(); BUZZER_LOW();}	
#define BUZZER_ON()			{DIR_BUZZER_BIT(); BUZZER_HIGH();}

//===========================================================================
/* LCD Display */

/* LCD IO definitions */
//#define PIN_LCD_E     0x02000000	//0x80000000     02       /* Enable control pin                */
//#define PIN_LCD_RW    0x00000000	//0x00000000	//0x20000000     01       /* Read/Write control pin            */
//#define PIN_LCD_RS    0x00800000	//0x10000000     008       /* Data/Instruction control          */
//#define PIN_LCD_CTRL  0x02800000	//0x03800000   38       /* Control lines mask                */

#define PINO_P1_LCD_E     0x02000000	//0x80000000     02       /* Enable control pin                */
#define PINO_P1_LCD_RW    0x00000000	//0x00000000	//0x20000000     01       /* Read/Write control pin            */
#define PINO_P1_LCD_RS    0x00800000	//0x10000000     008       /* Data/Instruction control          */


#define DIR_LCD_PORT_BITS()		{ FIO1DIR |= PINO_P1_LCD_E | PINO_P1_LCD_RW | PINO_P1_LCD_RS;}
#define DIR_LCD_OUT_PORT()		{ FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000; }



#define B_LCD_E(X)	{ (X==SET)? (FIO1SET |= PINO_P1_LCD_E  ) : (FIO1CLR |= PINO_P1_LCD_E ) ;}
#define B_LCD_RW(X)	{ (X==SET)? (FIO1SET |= PINO_P1_LCD_RW ) : (FIO1CLR |= PINO_P1_LCD_RW ) ;}
#define B_LCD_RS(X) { (X==SET)? (FIO1SET |= PINO_P1_LCD_RS ) : (FIO1CLR |= PINO_P1_LCD_RS ) ;}

//LCD OUT Port is created using Port 2 and port 3 
//port 2 = 0000 0000 0000 0000 0000 0000 1111 1100	 
//port 3 = 0000 0110 0000 0000 0000 0000 0000 0000	
#define BYTE_LCD_OUT(x) 	{ DIR_LCD_OUT_PORT(); FIO2PIN &= ~0x000000FC; 	\
							  FIO3PIN &= ~0x06000000; 						\
							  FIO2PIN |= (x & 0x3F)<<2; FIO3PIN |= (x & 0xC0) << 19;}

//=================================================================================================
/* Input Output Selection using 138 IC */
#define CS_IPCS1	0
#define CS_IPCS2	1
#define CS_OPCS1	2
#define CS_OPCS2	3
#define CS_IPCS3	4
#define CS_OPCS3	5
#define CS_BUZZER	7
#define CS_NO_SEL 	8

// Decoder selection pints
#define PINO_P4_DEC0	0x10000000	  		// P4.28
#define PINO_P1_DEC1   	0x01000000			//P1.24
#define PINO_P1_DEC2	0x80000000			// P1.31

#define DIR_IO_DEC_PINS()		{ FIO4DIR |= PINO_P4_DEC0; FIO1DIR |= PINO_P1_DEC1; FIO1DIR |= PINO_P1_DEC2; }

#define DIR_IO_OUT_PORT()		{ FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000; }
#define DIR_IO_IN_PORT()		{ FIO2DIR &= ~0x000000FC; FIO3DIR &= ~0x06000000; }

#define BYTE_IO_OUT_PORT(x)		{DIR_IO_OUT_PORT(); FIO2PIN &= ~0x000000FC; 	\
							  	  FIO3PIN &= ~0x06000000; 						\
							      FIO2PIN |= (x & 0x3F)<<2; FIO3PIN |= (x & 0xC0) << 19;}

/*#define BYTE_IO_READ_PORT(X)		{ DIR_IO_IN_PORT();X=(FIO2PIN >>2)&0x0000003F; X = X | ((FIO3PIN >>19)& 0x000000D0);	}
*/

#define BYTE_IO_READ_PORT(X)	{DIR_IO_IN_PORT(); X=(FIO2PIN&0x000000FC)>>2; \
									X = X | ((FIO3PIN&0x06000000)>>19);}	   //ARMD0063

#define PINO_P2_CS1		0x00

extern volatile unsigned int BuffOPCS1Latch,BuffOPCS2Latch;			// Buffer to keep data which needs to be output to OPCS1 Latch

// Following is just to define the Latch 1 Output which we will use 
#define DEFAULT_CS1_OUT		0x55

#define CS1_IO_DOOR1	0x01
#define CS1_IO_DOTL1	0x02
#define CS1_IO_DOOR2	0x04
#define CS1_IO_DOTL2	0x08
#define CS1_IO_DOOR3	0x10
#define CS1_IO_DOTL3	0x20
#define CS1_IO_DOOR4	0x40
#define CS1_IO_DOTL4	0x80

#define DOOR_OPEN(X)	{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch &= ~CS1_IO_DOOR##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define DOOR_CLOSE(X)	{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch |= CS1_IO_DOOR##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define SET_DOTL(X)		{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch |= CS1_IO_DOTL##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define CLR_DOTL(X)		{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch &= ~CS1_IO_DOTL##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#ifdef ENABLE_TESTING
#define MAKE_OUTPUT_ON(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~X;	\
						  		BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
							}

#define MAKE_OUTPUT_OFF(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= X;	\
						  		BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
							}
#endif

	#define BIT_PORT_EGRESS1	 0
	#define BIT_PORT_DORL1	     1
	#define BIT_PORT_EGRESS2     2
	#define BIT_PORT_DORL2		 3
	#define BIT_PORT_FIRE		 4
	#define BIT_PORT_TAMPER		 5
	#define BIT_PORT_INTRUSION	 6    //F0011 Checking of Intrusion Alarm
	#define BIT_PORT_INPUT2		 7
	
	#define BIT_PORT_EGRESS3     0
	#define BIT_PORT_DORL3	     1
	#define BIT_PORT_EGRESS4     2
	#define BIT_PORT_DORL4		 3
	
	#define IN_Egress1		((IOInput >> BIT_PORT_EGRESS1) & 0x1)	//bit(&IOInput,BIT_PORT_EGRESS1)
	#define IN_Egress2		((IOInput >> BIT_PORT_EGRESS2) & 0x1)	//bit(&IOInput,BIT_PORT_EGRESS2)
	#define IN_Dotl1		((IOInput >> BIT_PORT_DORL1) & 0x1)		//bit(&IOInput,BIT_PORT_DORL1)
	#define IN_Dotl2		((IOInput >> BIT_PORT_DORL2) & 0x1)		//bit(&IOInput,BIT_PORT_DORL2)
	#define IN_Fire			((IOInput >> BIT_PORT_FIRE) & 0x1)		//bit(&IOInput,BIT_PORT_FIRE)
	#define IN_Tamper		((IOInput >> BIT_PORT_TAMPER) & 0x1)	//bit(&IOInput,BIT_PORT_TAMPER)
	#define IN_Intrusion	((IOInput >> BIT_PORT_INTRUSION) & 0x1)	//bit(&IOInput,BIT_PORT_INTRUSION)
	#define IN_Input2		((IOInput >> BIT_PORT_INPUT2) & 0x1)	//bit(&IOInput,BIT_PORT_INPUT2)
	
	#define IN_Egress3		((IOInput2 >> BIT_PORT_EGRESS3) & 0x1)	//bit(&IOInput2,BIT_PORT_EGRESS3)
	#define IN_Egress4		((IOInput2 >> BIT_PORT_EGRESS4) & 0x1)	//bit(&IOInput2,BIT_PORT_EGRESS4)
	#define IN_Dotl3		((IOInput2 >> BIT_PORT_DORL3) & 0x1)	//bit(&IOInput2,BIT_PORT_DORL3)
	#define IN_Dotl4		((IOInput2 >> BIT_PORT_DORL4) & 0x1)	//bit(&IOInput2,BIT_PORT_DORL4)
extern volatile unsigned int readinput;

#define READ_INPUT(X)								\
{   												\
	SelectIOCS(CS_IPCS1);							\
	BYTE_IO_READ_PORT(readinput);					\
	X = readinput; 									\
	SelectIOCS(CS_IPCS2);							\
	BYTE_IO_READ_PORT(readinput);					\
	X = X + readinput*0x100;						\
	SelectIOCS(CS_NO_SEL);							\
}		  

extern unsigned char F_OutPutLock;
extern void SelectIOCS(unsigned char iotype);
extern void DoorClose(unsigned char drno);
extern void DoorOpen(unsigned char drno);
extern void DOTLLedOff(unsigned int rdno);
extern void DOTLLedOn(unsigned int rdno);
extern void WeigandLedOff(unsigned char rdno);
extern void WeigandLedOn(unsigned char rdno);
extern void WeigandBuzOn(unsigned char rdno);
extern void WeigandBuzOff(unsigned char rdno);
extern void InitialiseIO(void);
extern void MakeWeigandBuzON(unsigned char rdrno, unsigned char type);
extern void WeigandBuzControl(unsigned char rdno);
