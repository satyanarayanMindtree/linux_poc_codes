/*****************************************************************************
 *   portlcd.c:  4-bit port LCD C file for NXP LPC23xx/34xx Family 
 *   Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.12  ver 1.00    Prelimnary version, first Release
 *
*****************************************************************************/
#include "LPC23xx.H"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "irq.h"
#include "serial.h"
#include "portlcd.h"
#include "Keypad.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusans9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusansbold9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusanscondensed9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/veramonobold11.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerifBold20.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif22pts_Bold.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif20pts.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerifBold16.h"
#include "userIntfGLCD.h"
#include "../../GLCD/BMPImage/sea3_565.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif26ptsBold_Time.h"
//#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif48pts_Bold.h"
#include "../../GLCD/drivers/lcd/tft/fonts/NewMicrosoftSansSerif36ptsBold.h"
#include"string.h"
/******************************************************************************/
void DrawRadioButton(unsigned short x0,unsigned short y0,char Highlight) ;

//external variables
extern SYSInfo SysInfo;
extern const char WEEK_DAY[7][4];

/* Local variables */
WORD lcd_ptr;
//extern SYSInfo SysInfo;

extern struct DOOR_INFO Doorinfo;


extern unsigned char DisplayTempBuffer[50];



/******************************************************************************
** Function name:		lcd_read_stat
**
** Descriptions:		Read status of LCD controller (ST7066)		
**
** parameters:			None
** Returned value:		status
** 
******************************************************************************/
// DWORD lcd_read_stat( void ) 
// {
//   DWORD stat;
//   	stat = 0;

// //IO1DIR &= ~LCD_DATA;
// //Input  output 2,3,4,5,6,7.
// 	FIO2DIR &= ~0x000000FC;			// FC
// //port 2 = 0000 0000 0000 0000 0000 0000 1111 1100	 
// //port 3 = 0000 0110 0000 0000 0000 0000 0000 0000	
// //25,26	ARE USED as  input output
// 	FIO3DIR &= ~0x06000000;  
// 		
// 	B_LCD_RS(CLR);
// 	B_LCD_RW(SET);		
// 	Delay(10);		
// 	B_LCD_E(SET);
// 	Delay(10);
// 	stat    = ((FIO2PIN >> 2) & 0x3f);
// 	stat	= ((FIO3PIN >> 19) & 0xc0);							
// 	B_LCD_E(CLR);
// 	Delay(10);
// 	return (stat);
// }

void PositionCursorOnRowNo(BYTE position,BYTE row)
{
}
void L_BlankDisplay(unsigned char line)
{
//	LCD_cls();
//	L_DisplayMessage("                 ",16,line );
}

/*------------------------------------------------------------------------*/
void L_DisplayMessage(BYTE *strdata,BYTE len,BYTE row )
{
	L_DisplayROMStrLoc(strdata, len, row,0);
}
/*------------------------------------------------------------------------*/
/*void L_DisplayString(BYTE stringtype,BYTE row )
{
BYTE tcount,position;
if(row == 1)
	PositionCursorOnRow1(MESSAGE_POSITION);
else
	PositionCursorOnRow2(MESSAGE_POSITION);
    position = 0;
    tcount = stringtype * (MESSAGEOFFSET+1);
    while( position < (MESSAGEOFFSET+1))
    {
		if(Standard_STRING[tcount]== '\0')
			break;
		else
			WriteDataToDisplay(Standard_STRING[tcount]);
		position++;
		tcount++;
    }

} */
/*------------------------------------------------------------------------*/
void L_DisplayChar2(BYTE pos, BYTE data1)
{

//	PositionCursorOnRow2(position);
//	WriteDataToDisplay( data1 / 10 +'0');
//	WriteDataToDisplay( data1 % 10 +'0');
	L_DisplayCharAtRow(pos,  ( data1 / 10 +'0'),ROW_USER_ENTRY);
	L_DisplayCharAtRow(pos+1,( data1 % 10 +'0'),ROW_USER_ENTRY);
}

/*------------------------------------------------------------------------*/
void L_DisplayChar1(BYTE pos, BYTE data1)
{
	L_DisplayCharAtRow(pos,data1,ROW_USER_FUNCTION);
}
/*------------------------------------------------------------------------*/

void L_DisplayCharAt2(BYTE pos,BYTE data1 )
{
	L_DisplayCharAtRow(pos,data1,ROW_USER_ENTRY);
}
/*------------------------------------------------------------------------*/
void L_DisplayCharAtRow(BYTE pos,BYTE data1,BYTE row )
{
//	unsigned short  charWidth, characterToOutput,y;
	unsigned short   y;
	const FONT_CHAR_INFO *charInfo;
//	unsigned short charOffset;

	
	switch(row)
	{
	case BOOT_MSG1:
	break;
	case BOOT_MSG2:	
	break;
	case BOOT_MSG3:	
	break;
	
	//////BELOW CASES ARE USED FOR SUB MENU AFTER SCROLL MENU.
	case ROW_USER_TITLE:
	{
		// set current x, y to that of requested
		y = USER_LINE1_START_Y0 + ((USER_TITLE_FONTINFO_PTR)->heightPages*8 /2);   //this is added because string write is always top shifted
		// get char info
		charInfo = (USER_TITLE_FONTINFO_PTR)->charInfo;
		// get correct char offset
		charInfo += (data1 - (USER_TITLE_FONTINFO_PTR)->startChar);

		//clear char
		DisplayBackGround(	USER_LINE1_START_X0 + pos*USER_TITLE_FONT_WIDTH,
							USER_LINE1_START_Y0,
							charInfo->widthBits+1, 
							USER_LINE1_SECTION_SIZE_Y,
							image16) ;
		// Send individual characters
		drawCharBitmap(USER_LINE1_START_X0 + pos*USER_TITLE_FONT_WIDTH,
						y+1,
						USER_TITLE_LINE_COLOR,
						&((USER_TITLE_FONTINFO_PTR)->data[charInfo->offset]), 
						(USER_TITLE_FONTINFO_PTR)->heightPages, 
						charInfo->widthBits);
    }
	break;
	case ROW_USER_FUNCTION:	
	{
		// set current x, y to that of requested
		y = USER_LINE2_START_Y0 + ((USER_NORMAL_FONTINFO_PTR)->heightPages*8 /2);   //this is added because string write is always top shifted
		// get char info
		charInfo = (USER_NORMAL_FONTINFO_PTR)->charInfo;
		// get correct char offset
		charInfo += (data1 - (USER_NORMAL_FONTINFO_PTR)->startChar);

		//clear 
		DisplayBackGround(	USER_LINE2_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
							USER_LINE2_START_Y0,
							charInfo->widthBits+1, 
							USER_LINE2_SECTION_SIZE_Y,
							image16) ;
		//write 
		drawCharBitmap(USER_LINE2_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
						y+1,
						USER_NORMAL_LINE_COLOR,
						&((USER_NORMAL_FONTINFO_PTR)->data[charInfo->offset]), 
						(USER_NORMAL_FONTINFO_PTR)->heightPages, 
						charInfo->widthBits);
    }
	break;
	case ROW_USER_ENTRY:	
	{
		// set current x, y to that of requested
		y = USER_LINE3_START_Y0 + ((USER_NORMAL_FONTINFO_PTR)->heightPages*8 /2);   //this is added because string write is always top shifted
		// get char info
		charInfo = (USER_NORMAL_FONTINFO_PTR)->charInfo;
		// get correct char offset
		charInfo += (data1 - (USER_NORMAL_FONTINFO_PTR)->startChar);

		//clear 
		DisplayBackGround(	USER_LINE3_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
							USER_LINE3_START_Y0,
							charInfo->widthBits+1,
							USER_LINE3_SECTION_SIZE_Y,
							image16) ;
		//write 
		drawCharBitmap(USER_LINE3_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
						y+1,
						USER_NORMAL_LINE_COLOR,
						&((USER_NORMAL_FONTINFO_PTR)->data[charInfo->offset]), 
						(USER_NORMAL_FONTINFO_PTR)->heightPages, 
						charInfo->widthBits);
    }
	break;
// 	case ROW_USER_ENTRY2:	
// 	{
// 		//clear line
// 		DisplayBackGround(	USER_LINE4_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
// 							USER_LINE4_START_Y0,
// 							USER_LINE4_SECTION_SIZE_X, 
// 							USER_LINE4_SECTION_SIZE_Y,
// 							image16) ;
// 		//write line
// 		drawString(	USER_LINE4_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
// 					USER_LINE4_START_Y0,
// 					USER_NORMAL_LINE_COLOR,
// 					USER_NORMAL_FONTINFO_PTR,
// 					strdata);
//     }
// 	break;
// 	case ROW_USER_ENTRY3:	
// 	{
// 		//clear line
// 		DisplayBackGround(	USER_LINE5_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
// 							USER_LINE5_START_Y0,
// 							USER_LINE5_SECTION_SIZE_X, 
// 							USER_LINE5_SECTION_SIZE_Y,
// 							image16) ;
// 		//write line
// 		drawString(	USER_LINE5_START_X0 + pos*USER_NORMAL_FONT_WIDTH,
// 					USER_LINE5_START_Y0,
// 					USER_NORMAL_LINE_COLOR,
// 					USER_NORMAL_FONTINFO_PTR,
// 					strdata);
//     }
// 	break;
// 	case ROW_USER_ENTRY4:	
// 	break;
	}
}
/*------------------------------------------------------------------------*/

/*------------------------------------------------------------------------*/

void L_DisplayCharAt1(BYTE position,BYTE data1 )
{
}
/*------------------------------------------------------------------------*/

void L_DisplayROMStr(unsigned char *strdata,BYTE len,BYTE row)
{
	L_DisplayROMStrLoc(strdata, len, row,0);
}
void DisplayRadioButton(unsigned char *strdata,BYTE row,char Highlight)
{

	switch(row)
	{
// 	case BOOT_MSG1:
// 		drawString(BOOT_MSG1_X0,BOOT_MSG1_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
// 	break;
// 	case BOOT_MSG2:	
// 		drawString(BOOT_MSG2_X0,BOOT_MSG2_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
// 	break;
// 	case BOOT_MSG3:	
// 		drawString(BOOT_MSG3_X0,BOOT_MSG3_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
// 	break;
// 	
// 	//////BELOW CASES ARE USED FOR SUB MENU AFTER SCROLL MENU.
// 	case ROW_USER_TITLE:
// 	{
// 		DisplayBackGround(	USER_LINE1_START_X0,
// 							USER_LINE1_START_Y0,
// 							USER_LINE1_SECTION_SIZE_X, 
// 							USER_LINE1_SECTION_SIZE_Y,
// 							image16) ;
// 		//write line
// 		drawString(	USER_LINE1_START_X0,
// 					USER_LINE1_START_Y0,
// 					USER_TITLE_LINE_COLOR,
// 					USER_TITLE_FONTINFO_PTR,
// 					strdata);
//     }
// 	break;
// 	case ROW_USER_FUNCTION:	
// 	{
// 		//clear line
// 		DisplayBackGround(	USER_LINE2_START_X0,
// 							USER_LINE2_START_Y0,
// 							USER_LINE2_SECTION_SIZE_X, 
// 							USER_LINE2_SECTION_SIZE_Y,
// 							ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour) ;
// 		
// 		//write line
// 		drawString(	USER_LINE2_START_X0,
// 					USER_LINE2_START_Y0,
// 					USER_NORMAL_LINE_COLOR,
// 					USER_NORMAL_FONTINFO_PTR,
// 					strdata);
//     }
// 	break;
	case ROW_USER_ENTRY:	
	{
// 					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
// 					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
// 					rectinfo.Hight = USER_LINE3_SECTION_SIZE_Y;  
// 					rectinfo.Width = USER_LINE3_SECTION_SIZE_X ;   
// 					rectinfo.BorderColor = 0;
// 					DrawRect(&rectinfo,USER_LINE3_START_X0 ,USER_LINE3_START_Y0);		
		
//void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
        DrawRadioButton(USER_LINE3_START_X0+CENTRE_OFFSET,
					USER_LINE3_START_Y0+CENTRE_OFFSET,
					Highlight);

//write line
		drawString(	USER_LINE3_START_X0+STRING_OFFSET,
					USER_LINE3_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);
    }
	break;
	case ROW_USER_ENTRY2:	
	{
		//clear line
// 		DisplayBackGround(	USER_LINE4_START_X0,
// 							USER_LINE4_START_Y0,
// 							USER_LINE4_SECTION_SIZE_X, 
// 							USER_LINE4_SECTION_SIZE_Y,
// 							COLOR_WHITE) ;
//void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
        DrawRadioButton(USER_LINE4_START_X0+CENTRE_OFFSET,
					USER_LINE4_START_Y0+CENTRE_OFFSET,
					Highlight);

//write line
		drawString(	USER_LINE4_START_X0+STRING_OFFSET,
					USER_LINE4_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);    }
	break;
	case ROW_USER_ENTRY3:	
	{
		//clear line
// 		DisplayBackGround(	USER_LINE5_START_X0,
// 							USER_LINE5_START_Y0,
// 							USER_LINE5_SECTION_SIZE_X, 
// 							USER_LINE5_SECTION_SIZE_Y,
// 							ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour) ;
//void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
        DrawRadioButton(USER_LINE5_START_X0+CENTRE_OFFSET,
					USER_LINE5_START_Y0+CENTRE_OFFSET,
					Highlight);
//write line
		drawString(	USER_LINE5_START_X0+STRING_OFFSET,
					USER_LINE5_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);    }
	break;
	case ROW_USER_ENTRY4:	
// 		DisplayBackGround(	USER_LINE6_START_X0,
// 							USER_LINE6_START_Y0,
// 							USER_LINE6_SECTION_SIZE_X, 
// 							USER_LINE6_SECTION_SIZE_Y,
// 							ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour) ;
	
//void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
        DrawRadioButton(USER_LINE6_START_X0+CENTRE_OFFSET,
					USER_LINE6_START_Y0+CENTRE_OFFSET,
					Highlight);

//write line
		drawString(	USER_LINE6_START_X0+STRING_OFFSET,
					USER_LINE6_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);		
	break;
	case ROW_USER_ENTRY5:	
// 		DisplayBackGround(	USER_LINE6_START_X0,
// 							USER_LINE6_START_Y0,
// 							USER_LINE6_SECTION_SIZE_X, 
// 							USER_LINE6_SECTION_SIZE_Y,
// 							ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour) ;
	
//void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
        DrawRadioButton(USER_LINE7_START_X0+CENTRE_OFFSET,
					USER_LINE7_START_Y0+CENTRE_OFFSET,
					Highlight);

//write line
		drawString(	USER_LINE7_START_X0+STRING_OFFSET,
					USER_LINE7_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);		
	break;	
	}
}
void DrawRadioButton(unsigned short x0,unsigned short y0,char Highlight)
{
	unsigned short ColourRadiobutton;
if(Highlight == 0)    // unHighlight 
	ColourRadiobutton = STR_UNHIGHLIGHT_COLOUR;
else
	ColourRadiobutton = STR_HIGHLIGHT_COLOUR;

		drawCircle(x0,
					y0,
					RADIOBUTTON_RADIUS1,
					RADIOBUTTON_BORDER1_COLOR);
        drawCircleFilled(x0,
					y0,
					RADIOBUTTON_RADIUS2,
					RADIOBUTTON_BORDER2_COLOR);
//         drawCircle(x0,
// 					y0,
// 					RADIOBUTTON_RADIUS2-1,
// 					RADIOBUTTON_BORDER2_COLOR);
//         drawCircle(x0,
// 					y0,
// 					RADIOBUTTON_RADIUS2,
// 					RADIOBUTTON_BORDER2_COLOR);
		
        drawCircleFilled(x0,
						y0,
						RADIOBUTTON_RADIUS4,
						ColourRadiobutton);
}
/*------------------------------------------------------------------------*/

void L_DisplayRAMStr(BYTE *strdata,BYTE len,BYTE row)
{
	L_DisplayROMStrLoc(strdata,len,row,0);
}

/*------------------------------------------------------------------------*/
void L_DisplayDecimalInteger(WORD intdata,BYTE pos,BYTE row)
{
	sprintf( (char*)DisplayTempBuffer,"%d",intdata);
	
    L_DisplayROMStrLoc(DisplayTempBuffer,sizeof(DisplayTempBuffer),row,pos);
}

/*------------------------------------------------------------------------*/
//  This funtion dispaly string on row and pos -> X position

void L_DisplayROMStrLoc(unsigned char *strdata,BYTE len,BYTE row, BYTE pos)
{
	struct RectInfo rectinfo;
	switch(row)
	{
	case BOOT_MSG1:	
		drawString(BOOT_MSG1_X0,BOOT_MSG1_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
	break;
	case BOOT_MSG2:	
		drawString(BOOT_MSG2_X0,BOOT_MSG2_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
	break;
	case BOOT_MSG3:	
		drawString(BOOT_MSG3_X0,BOOT_MSG3_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,strdata);
	break;
	
	//////BELOW CASES ARE USED FOR SUB MENU AFTER SCROLL MENU.
	case ROW_USER_TITLE:
	{
		rectinfo.FillType = RCTFILL_PLAIN;   
		rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
		rectinfo.Hight = USER_LINE1_SECTION_SIZE_Y;  
		rectinfo.Width = USER_LINE1_SECTION_SIZE_X ;   
		rectinfo.BorderColor = 0;
		DrawRect(&rectinfo,USER_LINE1_START_X0 ,USER_LINE1_START_Y0);				

		if(pos != 0)
		{
			//write line
			drawString(	USER_LINE1_START_X0 + pos,
						USER_LINE1_START_Y0,
						USER_TITLE_LINE_COLOR,
						USER_TITLE_FONTINFO_PTR,
						strdata);
		}
		else
		{
			DrawCenterText(	USER_LINE1_START_Y0,
							USER_TITLE_LINE_COLOR,
							USER_TITLE_FONTINFO_PTR,
							strdata);
		}
	}
	break;
	case ROW_USER_FUNCTION:	
	{
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE2_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE2_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE2_START_X0,USER_LINE2_START_Y0);				
		//write line
					drawString(	USER_LINE2_START_X0 + pos,
								USER_LINE2_START_Y0,
								USER_NORMAL_LINE_COLOR,
								USER_NORMAL_FONTINFO_PTR,
								strdata);
   }
	break;
	case ROW_USER_ENTRY:	//  Start at y = 68 
	{
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE3_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE3_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE3_START_X0 ,USER_LINE3_START_Y0);				
	
					drawString(	USER_LINE3_START_X0 + pos,
								USER_LINE3_START_Y0,
								USER_NORMAL_LINE_COLOR,
								USER_NORMAL_FONTINFO_PTR,
								strdata);
    }
	break;
	case ROW_USER_ENTRY2:	
	{
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE4_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE4_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE4_START_X0 ,USER_LINE4_START_Y0);		
		//write line
		drawString(	USER_LINE4_START_X0 + pos,
					USER_LINE4_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);
    }
	break;
	case ROW_USER_ENTRY3:	
	{
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE5_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE5_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE5_START_X0 ,USER_LINE5_START_Y0);			
		//write line
		drawString(	USER_LINE5_START_X0 + pos,
					USER_LINE5_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);
    }
	break;
	case ROW_USER_ENTRY4:	
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE6_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE6_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE6_START_X0 ,USER_LINE6_START_Y0);			
		//write line
		drawString(	USER_LINE6_START_X0 + pos,
					USER_LINE6_START_Y0,
					USER_NORMAL_LINE_COLOR,
					USER_NORMAL_FONTINFO_PTR,
					strdata);
		
	break;
	}
}
/******************************************************************************/
void L_DisplayWelcomeMessage(unsigned char *strdata,BYTE len,BYTE row, BYTE pos)
{
	struct RectInfo rectinfo;
	if(ScreenFormatData.CurrentFormat == FORMAT_GRID_SCREEN || 
		ScreenFormatData.CurrentFormat == FORMAT_SCROLL_SCREEN || 
		ScreenFormatData.CurrentFormat == FORMAT_SUBMENU_SCREEN ||
		ScreenFormatData.CurrentFormat == FORMAT_BOOT_SCREEN)
	{
		return;
	}


	switch(row)
	{
		case ROW_USER_FUNCTION:	
		{
			if(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN || ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)
			{
				//clear line
// 				SDDisplaySpecificGround(WELCOME_LINE1_START_X0 + pos*WELCOME_FONT_WIDTH,
// 										WELCOME_LINE1_START_Y0,
// 										WELCOME_LINE1_SECTION_SIZE_X - pos*WELCOME_FONT_WIDTH, 
// 										WELCOME_LINE1_SECTION_SIZE_Y,
// 										ScreenFormatData.F_ImageNo) ;
				rectinfo.FillType = RCTFILL_PLAIN;     // gRID sCREEN 
				rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour;   
				rectinfo.Hight = 15;  
				rectinfo.Width = ThemeSelect.SatusMSGWidth;   // 320
				rectinfo.BorderColor = 0;
				DrawRect(&rectinfo,ThemeSelect.SatusMSGStartXO,ThemeSelect.SatusMSGStartYO);
			}
			else
			{
				//clear line
				DisplayBackGround(	WELCOME_LINE1_START_X0 + pos*WELCOME_FONT_WIDTH,
									WELCOME_LINE1_START_Y0,
									WELCOME_LINE1_SECTION_SIZE_X - pos*WELCOME_FONT_WIDTH, 
									WELCOME_LINE1_SECTION_SIZE_Y,
									image16) ;
			}
			//write line
			drawString(	WELCOME_LINE1_START_X0 + pos*WELCOME_FONT_WIDTH,
						WELCOME_LINE1_START_Y0,
						WELCOME_LINE_COLOR,
						WELCOME_FONTINFO_PTR,
						strdata);
		}
		break;
		case ROW_USER_ENTRY:	
		{
			if(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN || ScreenFormatData.CurrentFormat == FORMAT_EVENT_ICON)
			{
				//clear line
// 				SDDisplaySpecificGround(WELCOME_LINE2_START_X0 + pos*WELCOME_FONT_WIDTH,
// 										WELCOME_LINE2_START_Y0,
// 										WELCOME_LINE2_SECTION_SIZE_X - pos*WELCOME_FONT_WIDTH, 
// 										WELCOME_LINE2_SECTION_SIZE_Y,
// 										ScreenFormatData.F_ImageNo) ;
			}
			else
			{
				//clear line
				DisplayBackGround(	WELCOME_LINE2_START_X0 + pos*WELCOME_FONT_WIDTH,
									WELCOME_LINE2_START_Y0,
									WELCOME_LINE2_SECTION_SIZE_X - pos*WELCOME_FONT_WIDTH, 
									WELCOME_LINE2_SECTION_SIZE_Y,
									image16) ;
			}
			//write line
			drawString(	WELCOME_LINE2_START_X0 + pos*WELCOME_FONT_WIDTH,
						WELCOME_LINE2_START_Y0,
						WELCOME_LINE_COLOR,
						WELCOME_FONTINFO_PTR,
						strdata);
		}
		break;
	}
}
/******************************************************************************/
void L_DisplayCardNumber(CARDNO_DATA_STORAGE_TYPE intdata,BYTE position,BYTE row)
{
	CARDNO_DATA_STORAGE_TYPE tempdata1,tempdata2;
// 	PositionCursorOnRowNo(position,row);
//   RSSET;
#ifdef CARD_NO_8_DIGIT
//   if(sizeof(CARDNO_DATA_STORAGE_TYPE)> sizeof(int))
	{
   	if(Doorinfo.CardDigit ==8)
	{
      	// Display with facility code
		intdata = intdata & 0x00FFFFFFL;		// We support this only for 26 bit cards
        tempdata1 = intdata / 0x10000; //take higher 8 bit i.e. facility code
		tempdata2 = (intdata & 0x0000FFFFL);
		sprintf( (char*)DisplayTempBuffer,"%03u-%05u",tempdata1,tempdata2 );
	}
	else if(Doorinfo.CardDigit != 5)
    {
#ifdef CARD_NO_10_DIGIT
		LongHextoDeciamal((char*)DisplayTempBuffer,intdata);
#else	//#ifdef CARD_NO_10_DIGIT
		sprintf( (char*)DisplayTempBuffer,"%08u",intdata );
#endif	//#else	//#ifdef CARD_NO_10_DIGIT
	}
    else if(Doorinfo.CardDigit ==5)
      {
      	intdata = (unsigned int) (intdata & 0x0000FFFF);
		WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)intdata);  
      }
   }
//   else
#else	//#ifdef CARD_NO_8_DIGIT
	{
//		sprintf( (char*)DisplayTempBuffer,"%05u",intdata );
		WORDHextoDeciamal((char*)DisplayTempBuffer,(unsigned short)intdata);  		
	}
#endif	//#else	//#ifdef CARD_NO_8_DIGIT

	++position;
//	L_DisplayROMStrLoc(DisplayTempBuffer,50,row,position);
}

/*****************************************************************************/
void L_DisplayLong(DWORD  intdata,BYTE position,BYTE row)
{

}
void L_DisplayCharRow(unsigned char position,unsigned char data1,unsigned char row)
{
}

void LCDDisplayTimeData(RTCTime timedate,BYTE blinkpos,BYTE weekday)
{
}

/*****************************************************************************
**                            End Of File
******************************************************************************/

/*** BeginHeader LCDDisplayTimeDataAtRow */
void LCDDisplayTimeDataAtRow(struct DATE_TIME timedate,unsigned char blinkpos,unsigned char weekday,unsigned char row);
/*** EndHeader */
void LCDDisplayTimeDataAtRow(struct DATE_TIME timedate,unsigned char blinkpos,unsigned char weekday,unsigned char row)
{
}

/*------------------------------------------------------------------------------*/
/*** BeginHeader L_DisplayDecimalByte*/
void L_DisplayDecimalByte(unsigned char intdata,unsigned char pos,unsigned char row);
/*** EndHeader */
void L_DisplayDecimalByte(unsigned char intdata,unsigned char pos,unsigned char row)
{
	sprintf( (char*)DisplayTempBuffer,"%3d",intdata);
    L_DisplayROMStrLoc(DisplayTempBuffer,sizeof(DisplayTempBuffer),row,pos);
}

/*------------------------------------------------------------------------------*/
void L_DisplayHexDouble(unsigned long intdata,unsigned char position,unsigned char row)
{
	unsigned char temp1,temp2,temp3,temp4,temp5,temp6,temp7,temp8;	
unsigned int 	tempdata;
	temp1 = HexToAscii(intdata/0x10000000);
	tempdata = intdata%0x10000000;
	temp2 =(HexToAscii(tempdata/0x1000000));
	tempdata = tempdata%0x1000000;
	temp3 = (HexToAscii(tempdata/0x100000));
	tempdata = tempdata%0x100000;
	temp4 = (HexToAscii(tempdata/0x10000));
	tempdata = tempdata%0x10000;
	temp5 = (HexToAscii(tempdata/0x1000));
	tempdata = tempdata%0x1000;
	temp6 = (HexToAscii(tempdata/0x100));
	tempdata = tempdata%0x100;
	temp7 = (HexToAscii(tempdata/0x10));
	temp8 = (HexToAscii(intdata&0x0F));

	sprintf((char*)DisplayTempBuffer,"%c%c%c%c%c%c%c%c",temp1,temp2,temp3,temp4,temp5,temp6,temp7,temp8);
	L_CenterDisplaySubStr(DisplayTempBuffer,row,SUBMENUE_CHAR_FONTINFO_PTR);				
	
}
/*------------------------------------------------------------------------------*/
/**				THIS FUNCTION displays string on centre of string.				*/
void DrawCenterText(unsigned short y ,unsigned short color, const FONT_INFO *fontInfo,unsigned char* text)
{
  drawString((lcdGetWidth() - drawGetStringWidth(fontInfo, (char*)text)) / 2, y, color, fontInfo, text);
}
/*------------------------------------------------------------------------------*/
/**				THIS FUNCTION displays string on centre with Background colour .				*/
void DrawCenterTextWithBackGround(unsigned short y ,unsigned short color,const FONT_INFO *fontInfo,unsigned short TotalWidth,unsigned char* text,unsigned int BackGroundColour)
{
  drawStringWithBackground((TotalWidth - drawGetStringWidth(fontInfo, (char*)text)) / 2, y, color, fontInfo, text,BackGroundColour);
}

void L_NewDisplayROMStrLoc(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo,unsigned char *str,uint16_t bkColor)
{
  drawStringWithBackground(x, y, color, fontInfo, str,bkColor);
}

/// this dispaly string at center of row 
void L_CenterDisplayROMStrLoc(unsigned char *strdata,BYTE row)
{
	struct RectInfo rectinfo;
	switch(row)
	{
	case ROW_USER_TITLE:
	{
			rectinfo.FillType = RCTFILL_PLAIN;   
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
			rectinfo.Hight = USER_LINE1_SECTION_SIZE_Y;  
			rectinfo.Width = USER_LINE1_SECTION_SIZE_X ;   
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,USER_LINE1_START_X0 ,USER_LINE1_START_Y0);				

			DrawCenterText(	USER_LINE1_START_Y0,
							USER_NORMAL_LINE_COLOR,
							USER_NORMAL_FONTINFO_PTR,
							strdata);
	}
	break;
	case ROW_USER_FUNCTION:	
	{
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE2_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE2_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE2_START_X0,USER_LINE2_START_Y0);				
		//write line
			DrawCenterText(	USER_LINE2_START_Y0,
							USER_NORMAL_LINE_COLOR,
							USER_NORMAL_FONTINFO_PTR,
							strdata);
   }
	break;
	case ROW_USER_ENTRY:	//  Start at y = 68 
	{
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE3_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE3_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE3_START_X0 ,USER_LINE3_START_Y0);				
	
			DrawCenterText(	USER_LINE3_START_Y0,
							USER_NORMAL_LINE_COLOR,
							USER_NORMAL_FONTINFO_PTR,
							strdata);
    }
	break;
	case ROW_USER_ENTRY2:	
	{
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE4_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE4_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE4_START_X0 ,USER_LINE4_START_Y0);		
		//write line
			DrawCenterText(	USER_LINE4_START_Y0,
							USER_NORMAL_LINE_COLOR,
							USER_NORMAL_FONTINFO_PTR,
							strdata);
    }
	break;
	case ROW_USER_ENTRY3:	
	{
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE5_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE5_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE5_START_X0 ,USER_LINE5_START_Y0);			
		//write line
			DrawCenterText(	USER_LINE5_START_Y0,
							USER_NORMAL_LINE_COLOR,
							USER_NORMAL_FONTINFO_PTR,
							strdata);

    }
	break;
	case ROW_USER_ENTRY4:	
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE6_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE6_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE6_START_X0 ,USER_LINE6_START_Y0);			
		//write line
			DrawCenterText(	USER_LINE6_START_Y0,
							USER_NORMAL_LINE_COLOR,
							USER_NORMAL_FONTINFO_PTR,
							strdata);

	break;
	}
}

// funtion display string at center with selected font size 
void L_CenterDisplayROMStrFont(unsigned char *strdata,BYTE row,const FONT_INFO *fontInfo)
{
	struct RectInfo rectinfo;
	switch(row)
	{
	case ROW_USER_TITLE:
	{
			rectinfo.FillType = RCTFILL_PLAIN;   
			rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
			rectinfo.Hight = USER_LINE1_SECTION_SIZE_Y;  
			rectinfo.Width = USER_LINE1_SECTION_SIZE_X ;   
			rectinfo.BorderColor = 0;
			DrawRect(&rectinfo,USER_LINE1_START_X0 ,USER_LINE1_START_Y0);				

			DrawCenterText(	USER_LINE1_START_Y0,
							USER_NORMAL_LINE_COLOR,
							fontInfo,
							strdata);
	}
	break;
	case ROW_USER_FUNCTION:	
	{
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE2_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE2_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE2_START_X0,USER_LINE2_START_Y0);				
		//write line
			DrawCenterText(	USER_LINE2_START_Y0,
							USER_NORMAL_LINE_COLOR,
							fontInfo,
							strdata);
   }
	break;
	case ROW_USER_ENTRY:	//  Start at y = 68 
	{
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE3_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE3_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE3_START_X0 ,USER_LINE3_START_Y0);				
	
			DrawCenterText(	USER_LINE3_START_Y0,
							USER_NORMAL_LINE_COLOR,
							fontInfo,
							strdata);
    }
	break;
	case ROW_USER_ENTRY2:	
	{
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE4_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE4_SECTION_SIZE_X ;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE4_START_X0 ,USER_LINE4_START_Y0);		
		//write line
			DrawCenterText(	USER_LINE4_START_Y0,
							USER_NORMAL_LINE_COLOR,
							fontInfo,
							strdata);
    }
	break;
	case ROW_USER_ENTRY3:	
	{
		//clear line
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE5_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE5_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE5_START_X0 ,USER_LINE5_START_Y0);			
		//write line
			DrawCenterText(	USER_LINE5_START_Y0,
							USER_NORMAL_LINE_COLOR,
							fontInfo,
							strdata);

    }
	break;
	case ROW_USER_ENTRY4:	
					rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
					rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
					rectinfo.Hight = USER_LINE6_SECTION_SIZE_Y;  
					rectinfo.Width = USER_LINE6_SECTION_SIZE_X;   
					rectinfo.BorderColor = 0;
					DrawRect(&rectinfo,USER_LINE6_START_X0 ,USER_LINE6_START_Y0);			
		//write line
			DrawCenterText(	USER_LINE6_START_Y0,
							USER_NORMAL_LINE_COLOR,
							fontInfo,
							strdata);
		
	break;
	}
}

// funtion display string at center with selected font size  --  this is for Submnue    
void L_CenterDisplaySubStr(unsigned char *strdata,BYTE row,const FONT_INFO *fontInfo)
{
	struct RectInfo rectinfo;
	switch(row)
	{
		case ROW_USER_ENTRY:	//  Start at y = 68 
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE1_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE1_SECTION_SIZE_X;   
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE1_START_X0 ,SUBMENUE_LINE1_START_Y0);				
		
				DrawCenterText(	SUBMENUE_LINE1_START_Y0,
								USER_NORMAL_LINE_COLOR,
								fontInfo,
								strdata);
			}
		break;
			
		case ROW_USER_ENTRY2:	
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE2_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE2_SECTION_SIZE_X;   
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE2_START_X0 ,SUBMENUE_LINE2_START_Y0);				
		
				DrawCenterText(	SUBMENUE_LINE2_START_Y0,
								USER_NORMAL_LINE_COLOR,
								fontInfo,
								strdata);			
			}
		break;
			
		case ROW_USER_ENTRY3:	
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE3_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE3_SECTION_SIZE_X;      
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE3_START_X0 ,SUBMENUE_LINE3_START_Y0);				
		
				DrawCenterText(	SUBMENUE_LINE3_START_Y0,
								USER_NORMAL_LINE_COLOR,
								fontInfo,
								strdata);			
			}
		break;
			
		case ROW_USER_ENTRY4:	
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE4_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE4_SECTION_SIZE_X;   
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE4_START_X0 ,SUBMENUE_LINE4_START_Y0);				
		
				DrawCenterText(	SUBMENUE_LINE4_START_Y0,
								USER_NORMAL_LINE_COLOR,
								fontInfo,
								strdata);
				//draw touch screen
				//display touch key
				TouchKeyPad.CurrentSelection = 0;
				TouchKeyPad.PreviousSelection = 0;
				TouchKeyPad.IsVisible = 1;
				DispTouchKeyPad(FORMAT_SUBMENU_SCREEN);
		}
		break;
	}
}
void PositionCursorOnRow(WORD Xpos,BYTE Xdigts,BYTE row,BYTE select,const FONT_INFO *fontInfo)
{
	struct RectInfo rectinfo;
unsigned short bkColor;	
unsigned char stemp[10];	
	
if(select == 0)    // unHighlight 
	bkColor = STR_UNHIGHLIGHT_COLOUR;
else
	bkColor = STR_HIGHLIGHT_COLOUR;

if(Xdigts == 2)
	strcpy((char*)stemp,"  ");
else if(Xdigts == 3)
	strcpy((char*)stemp,"   ");
else if(Xdigts == 4)
	strcpy((char*)stemp,"    ");
else if(Xdigts == 6)
	strcpy((char*)stemp,"      ");
else
{}
	
	switch(row)
	{
		case ROW_USER_ENTRY:	//  Start at y = 68 
		{						
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE1_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE1_SECTION_SIZE_X;   
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE1_START_X0 ,SUBMENUE_LINE1_START_Y0);			
			
						drawStringWithBackground(Xpos, 
												SUBMENUE_LINE1_START_Y0, 
												USER_NORMAL_LINE_COLOR, 
												fontInfo, 
												stemp,bkColor);		
			}
		break;
			
		case ROW_USER_ENTRY2:	
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE2_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE2_SECTION_SIZE_X;   
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE2_START_X0 ,SUBMENUE_LINE2_START_Y0);		
			
					drawStringWithBackground(Xpos, 
								SUBMENUE_LINE2_START_Y0, 
								USER_NORMAL_LINE_COLOR, 
								fontInfo, 
								stemp,bkColor);		
			}
		break;
			
		case ROW_USER_ENTRY3:	
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE3_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE3_SECTION_SIZE_X;      
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE3_START_X0 ,SUBMENUE_LINE3_START_Y0);				
	
			  drawStringWithBackground(Xpos, 
								SUBMENUE_LINE3_START_Y0, 
								USER_NORMAL_LINE_COLOR, 
								fontInfo, 
								stemp,bkColor);					
			}
		break;
			
		case ROW_USER_ENTRY4:	
		{
						rectinfo.FillType = RCTFILL_PLAIN;   // //display  background   DisplayBackGround
						rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].SubmenuBackgroundColour;   
						rectinfo.Hight = SUBMENUE_LINE4_SECTION_SIZE_Y;  
						rectinfo.Width = SUBMENUE_LINE4_SECTION_SIZE_X;   
						rectinfo.BorderColor = 0;
						DrawRect(&rectinfo,SUBMENUE_LINE4_START_X0 ,SUBMENUE_LINE4_START_Y0);						
		
			  drawStringWithBackground(Xpos, 
								SUBMENUE_LINE4_START_Y0, 
								USER_NORMAL_LINE_COLOR, 
								fontInfo, 
								stemp,bkColor);					
		}
		break;
	}
		
}
