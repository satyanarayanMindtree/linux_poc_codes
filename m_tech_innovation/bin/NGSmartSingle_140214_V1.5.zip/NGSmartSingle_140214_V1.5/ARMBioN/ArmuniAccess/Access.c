#include <stdio.h>
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include <string.h>
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "target.h"
#include "serial.h"
#include "Access.h"
#include "userintf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "smartcard.h"
#include "portlcd.h"
#include "memory.h"
#include "spi.h"
#include "INOUT.h"
#include "CardMgmt.h"
#include "memmap.h"
#include "RDcont.h"
#include "RDPoll.h"
//#include "tcpip.h"
#include "weigand.h"
#include "ProcessWeiCard.h"
#include "wdt.h"

#ifdef ENABLE_SLAVE_SUPPORT            //FA00090
#include "TransparentSlave.h"
#endif
#include "IOEventMgmt.h"
#include "SplCardMgnt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "ServerCheck.h"
#include "TemplatesonFlash.h"
#include "IClassRdr.h"
#include "userIntfGLCD.h"
#ifdef SUPPORT_SPEECHIC
	#include "DriverSpeech_IC.h"
#endif
#include "../../GLCD/drivers/lcd/tft/fonts/veramonobold11.h"

#define MODE_WAIT_FOR_CARD				0
//extern	SERVER_QUEUE SerQue[MAX_READERS];

#ifdef DISP_EVENT_MSGS_FROM_FLASH
const char ERROR_MESSAGE[MAX_ERROR_MSGS][17]=
	{
	   "FacilityCode Err",   	//0
#ifdef SUPPORT_WEIGAND_OUT
	   "Verifying User..",     //1
#else
	   "Access Granted  ",     //1
#endif
	   "Access Denied",   	//2
	   "Validity Expired", 		//3
	   "Time Zone Error ",   	//4
	   "User Restricted ",   	//5
	   "Finger Not Match",    	//6
	   "Holiday NoAccess",  	//7
	   "DOTL Alarm ON   ",  	//8
	   "DOTL 2 Alarm ON ",  	//9
	   "DOTL Alarm OFF  ",   	//10
	   "DOTL 2 Alarm OFF",   	//11
	   "Door Force Open ",  	//12
	   "Door2 ForceOpen ",  	//13
	   "System Restarted",  	//14
	   "    APB Error   ",  	//15
	   " Pin Mismatch   ",   	//16
	   "Invalid UserType",    	//17
	   "                ",    	//18
	   "                ",    	//19
	   " DUAL AUTH FAIL ",    	//20
#ifdef BIO_METRIC
	   "Show 2nd Finger.",    	//21
#else
	   "Show 2nd Card...",    	//21
#endif
	   "                ",    	//22
	   "                ",    	//23
	   " Invalid Card   ",    	//24
	   "Admin Login OK  ",    	//25
	   "Egress Door open",    	//26
	   "SystemInitialise",    	//27
	   "Special Card    ",    	//28
	   "Door Inter Lock ",    	//29 		//281210-1 DIS Mesg in flash
	   "Door Not Opened ",    	//30
	   "Same Card Error ",    	//31
	   "                ",    	//32
	   "Finger Retry    ",    	//33
	   "Duress Access   ",    	//34
	   "                ",    	//35
	   " DEAD MAN ZONE  ",    	//36		//201210-1
	   " Occupancy Full ",    	//37		//Occupancy Full
	   "IntrusionALM ON ",    	//38
	   "IntrusionALM OFF",    	//39
	   "Fire Alarm ON   ",    	//40
	   "Fire Alarm OFF  ",    	//41
	   "Tamper Alarm ON ",    	//42
	   "Tamper Alarm OFF",    	//43
	   "                ",      //44
	};
#endif

//extern BYTE tempwrbuf[SPIBUFSIZE];
/*---------------------------------------------------------------------------*/
//local variable


/*---------------------------------------------------------------------------*/
//external Variable
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo,LastCardNo1,LastCardNo2;
extern BYTE CWeekDay,ReaderNo,LastCardTime,AccessType;
extern BYTE DOTLTimeOut1,DOTLTimeOut2,Door2OpenTimeOut,Door1OpenTimeOut;
extern DWORD CARD_DATA_BASE;
extern SYSInfo SysInfo;
extern struct DOOR_INFO Doorinfo;
extern _TRANSData UExTrnxData; 
extern _TIMEZONE Timezone;
//extern Date Holiday;
extern RTCTime Datetime;
//extern Date CDate;
extern CardData Carddata;

extern SmartCardData CurrentCard;

extern int LastCardAddedPtr;
extern BYTE FCode,IdleKeyCounter,tdata,Card_Found;
extern BYTE F_Dotl1_Alarm_Made_Off,F_Dotl2_Alarm_Made_Off;
extern BYTE UserName[20];
extern BYTE InOutReader ,InOutReaderTime,F_DisplayINOutToggle;
extern BYTE F_TransCrossOver,F_BIO_COMM,F_KeyIdleTime;
extern BYTE LastFCode1, LastFCode2,FaclityCode1,FaclityCode2;

extern BYTE F_Door1_Open_TimeOut,F_Door2_Open_TimeOut,F_OneSec,F_Dotl1_TimeOut;
extern BYTE F_Dotl2_TimeOut,F_Is_Dotl1_Alarm,F_Is_Dotl2_Alarm,F_Channel1_DoorClose;
extern BYTE F_Dotl1_Alarm,F_Dotl2_Alarm,F_Facility,F_Door1IsOpen,F_Door2IsOpen,F_LastCardCheck;
extern BYTE F_Channel2_DoorClose,F_Egrase1_SW_Pressed,F_Egrase2_SW_Pressed,F_Dotl1_set;
extern BYTE F_Dotl2_set,F_Door1Alarm,F_Door2Alarm,F_TempCounterStart,F_Keyscan,F_FIRE;
extern BYTE F_CardFound1,F_CardFound2;
extern unsigned char F_DoNotCheckAPBForCard,DoNotCheckAPBTime,SpecialCardRdNo;

//extern PORTINRD DoorInput;
extern void Reset_Handler(void);
extern void MakeWeigandBuzON(unsigned char rdrno, unsigned char type);
unsigned char ValidateTZ(struct TIME_ZONE_STR *tzstend);
unsigned char ValidateTZCrossover(struct TIME_ZONE_STR tzstend);
extern unsigned int ReceivedPin;
#ifdef SUPPORT_NSERIES2
extern unsigned char F_DuelUserAuth;				//281210-4		//DUA
//static unsigned char DuelUserCounter;
//extern unsigned char F_FirstInUser;									//FIU First In user rule flag
#endif
extern BYTE F_FirmwareUpgrade;
extern BYTE DspRdrNo;
extern unsigned char buff[PAGE_SIZE];
//extern struct TIME_BASED_ACTION ;
struct TIME_BASED_ACTION (*pTimeBasedAction)[] = (struct TIME_BASED_ACTION (*)[])buff;
extern unsigned char F_authScreenTimer,F_authScreenTimerEnable;				

/*---------------------------------------------------------------------------*/
void SendDoorOpen(BYTE channelno)
{
/*
   OutputLatch();
   if(channelno == 1)
	 {	
	 	LOCK_1(0);
		READER_LED_1(1);
//		READER_BUZ_1(1);
//		DOTL_BUZ_1(1);
		F_Door1IsOpen = SET;

	 }
	if(channelno ==2)
   { 	  
   		LOCK_2(0);
		READER_LED_2(1);
//		READER_BUZ_2(1);
//		DOTL_BUZ_2(1);
		F_Door2IsOpen = SET;

	}
*/
	return;
}

/*-------------------------------------------------------------------------*/
/*
void SendDoorClose(BYTE channelno)
{
  OutputLatch();
   if((channelno ==1)||((Doorinfo.EXShareDotl != 0)))
	{
	  	if(!Doorinfo.PC_D00R1_OPEN)
		{
            LOCK_1(1);
			READER_LED_1(0);
//			READER_BUZ_1(0);
//			DOTL_BUZ_1(0);
           	F_Door1IsOpen = CLR;
		}
	   if(Doorinfo.EXShareDotl)
		{  	
			LOCK_2(1);
		  	READER_LED_2(0);
//			READER_BUZ_2(0);
//			DOTL_BUZ_2(0);
            F_Door1IsOpen = CLR;
		}
	}
	else
	{
		if(!Doorinfo.PC_D00R2_OPEN)
		{
 			LOCK_2(1);
		  	READER_LED_2(0);
//			READER_BUZ_2(0);
//			DOTL_BUZ_2(0);
           	F_Door2IsOpen = CLR;
		}

	}
 
  	return;
}  */
/*-------------------------------------------------------------------------*/
int Check_Holiday(unsigned rno)
{
unsigned int i;
//unsigned int hdayend;
	rno--;	
	if(Doorinfo.ChkHoliday == 1)      //Holiday enable
	{
		for(i=0;i<MAX_RDR_HOLIDAY;i++)
		{  
			GetHoliday(i,0,&StrHoliday);
			if(StrHoliday.Year == Datetime.Date.Year)
				if(StrHoliday.Month == Datetime.Date.Month)
					if(StrHoliday.Day == Datetime.Date.Day)
						return(HOLIDAY_NO_ACCESS);
		}
	}
	else if(Doorinfo.ChkHoliday == 2)      //Readerwise Holiday enable
	{
		for(i=0;i<MAX_RDR_HOLIDAY;i++)
		{  //read data from xmem for holiday check
			GetHoliday(i,rno,&StrHoliday);
			if(StrHoliday.Year == Datetime.Date.Year)
				if(StrHoliday.Month == Datetime.Date.Month)
					if(StrHoliday.Day == Datetime.Date.Day)
						return(HOLIDAY_NO_ACCESS);
		}
	}
	return(0);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader CheckFreeTimeZone*/
void CheckFreeTimeZone(unsigned char TWeekDay);
/*** EndHeader */
void CheckFreeTimeZone(unsigned char TWeekDay)
{
unsigned char rdno;
	if(Doorinfo.FREETIMEENABLE)
   	{
		for(rdno=0;rdno<MAX_READERS_SUPPORT;rdno++)
		{
			if(ReaderInfo[rdno].FreeTZEnDis == 1)
	        {
				if(Check_TimeZone(ReaderInfo[rdno].FreeTZ,TWeekDay) == TimeZone_OK)
	            {
                	DoorConditionControl(rdno,DOOR_FREE_TIMEZONE,1,1);
	            }
	            else
	            {
					if(DRStruct[rdno].DRStatus == DR_TZ_OPEN)
	               	{
	                  	DoorConditionControl(rdno,DR_NORMAL,1,1);
	               	}
	            }
	        }
			else if(DRStruct[rdno].DRStatus == DR_TZ_OPEN)
			{
	        	DoorConditionControl(rdno,DR_NORMAL,1,1);
	       	}
      	}
	}
   	else
   	{
		for(rdno=0;rdno<MAX_READERS_SUPPORT;rdno++)
			if(DRStruct[rdno].DRStatus == DR_TZ_OPEN)
	   			DoorConditionControl(rdno,DR_NORMAL,1,1);
	}
	return;
}

/*-------------------------------------------------------------------------------------------------*/
unsigned char DoorOpenForTime(BYTE channelno)
{
char temp;
	if(channelno == 0)
		return(0xFF);
	if(channelno <= SysInfo.ControllerMode)
	{	
		temp = DoorConditionControl(channelno-1,DR_ACCESS_OPEN,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime);
		if(temp == EVENT_DR_PC_USER_CLOSE)
			return(EVENT_DR_PC_USER_CLOSE);	 
		if(temp == EVENT_DR_PC_USER_OPEN)
			return(EVENT_DR_PC_USER_OPEN);
	}
	else
		return(0xFF);
//	if( SendDoorOpenRdr(ReaderInfo[channelno-1].SlaveContNo,ReaderInfo[channelno-1].DoorNo,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime,(channelno-1)%2) !=0)
//	   	if( SendDoorOpenRdr( ReaderInfo[channelno-1].SlaveContNo,ReaderInfo[channelno-1].DoorNo,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime,(channelno-1)%2) !=0)
// NEED TO TAKE CARE OF THIS NOT TO SEND COMMAND IF POLL IN PROGRESS

//	if( SendDoorOpenRdr(((channelno-1)/2)+1,((channelno-1)%2)+1,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime,((channelno-1)%2)+1) !=0)
//	   	if(SendDoorOpenRdr(((channelno-1)/2)+1,((channelno-1)%2)+1,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime,((channelno-1)%2)+1) !=0)
/*#ifndef BIO_METRIC
	if(SendDoorOpenChannel(channelno-1) != 0)
		if(SendDoorOpenChannel(channelno-1) != 0)
			return(0xff);
#endif
*/
	return(0);

/*
//	Temp1SecCounter=0;
	if((channelno ==1) ||(Doorinfo.EXShareDotl != 0))
	{	Door1OpenTimeOut =Doorinfo.EXDOP_TIM1;
		DOTLTimeOut1 = Doorinfo.EXDOTL_DLY1;
		F_Door1_Open_TimeOut = SET;
		F_Dotl1_TimeOut = SET;
		F_Door1Alarm =CLR;
		F_Is_Dotl1_Alarm =CLR;
	   SendDoorOpen(1);
      if(Doorinfo.EXShareDotl != 0)
	      SendDoorOpen(2);   // In case of shared DOTL Make both Relay on but do not sense magnetic contact for door 2
	}


	if(channelno ==2)
	{
		Door2OpenTimeOut = Doorinfo.EXDOP_TIM2;
		DOTLTimeOut2 = Doorinfo.EXDOTL_DLY2;
		F_Door2_Open_TimeOut = SET;
		F_Dotl2_TimeOut = SET;
		F_Door2Alarm =CLR;
		F_Is_Dotl2_Alarm =CLR;
	   SendDoorOpen(2);
	}
*/

}

/*
short CardSearch2(CARDNO_DATA_STORAGE_TYPE Cardno)
{
unsigned int temp1,temp2;
struct CARD_DATA empcard;
unsigned char tempwrbuf[SPIBUFSIZE];
	temp1 = 0;
   	MsgPrint(MSG_MEM,Cardno,"Card No to search ");
	while(temp1< MAX_CARD_PAGE)
	{	
		MsgPrint(MSG_MEM,temp1,"Card Data Page No ");
		MainMem_ReadPage(FL_CARDDATA_PAGE_NO+temp1,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
//			for(temp2 = 0;temp2<sizeof(tempwrbuf);temp2++)
//  				MsgPrint(MSG_MEM,tempwrbuf[temp2],"Card Data ");
		 	temp2 = 0;
//		MsgPrint(MSG_MEM,MAX_CARDP_PERPAGE,"Card per Page ");
		while(temp2< MAX_CARDP_PERPAGE)
		{
		    xmem2root( (BYTE *) &empcard,(BYTE *)&tempwrbuf +(temp2 * CARD_DATA_BYTES),CARD_DATA_BYTES);
   			MsgPrint(MSG_MEM,empcard.CardNo,"Current Card No ");
			if(empcard.CardNo==Cardno)
         	{	MsgPrint(MSG_ERROR,temp1*MAX_CARDP_PERPAGE+temp2,"CARD_FOUND ");
				return(temp1*MAX_CARDP_PERPAGE+temp2);
			}
			if(LastCardAddedPtr == (temp1 * temp2) )
				return(CARD_NOT_FOUND);
			//	MsgPrint(MSG_MEM,temp2,"Card No PerPage ");
				temp2++;
			
		}						   
		temp1++;						  
	}
	MsgPrint(MSG_ERROR,CARD_NOT_FOUND,"CARD_NOT_FOUND ");
	return(CARD_NOT_FOUND);
}


short SearchDisplayCard2(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)
{
	short temp;
   if(cardno !=0)
   { 	temp = CardSearch(cardno);
	   if(temp == CARD_NOT_FOUND)
	   {
	      MsgPrint(MSG_WARNING,temp,"SearchDisplayCard:Card not found ptr=");
	      return(CARD_NOT_FOUND);
	   }
	   else
	   {
//	      xmem2root( (unsigned char *)&empcard,((unsigned long)CARD_DATA_BASE+((unsigned long)temp*(unsigned long)CARD_DATA_BYTES)),CARD_DATA_BYTES);
	      MsgPrint(MSG_WARNING,temp,"SearchDisplayCard:Card found ptr=");
	   }
     	return(temp);
   }
   return(CARD_NOT_FOUND);
}



short SearchCardLastCard2(void)
{
	int temp;
//   unsigned char temp1[100];
	temp = CARD_DATA_MAX-1;
	while(temp>0)
	{
//		MsgPrint(MSG_WARNING,temp,"Temp=");
//		MsgPrint(MSG_WARNING,ReadDataFromSE2_16(CARD_DATA_BASE+(CARD_DATA_BYTES*temp))*0x100 + ReadDataFromSE2_16(CARD_DATA_BASE+(CARD_DATA_BYTES*temp)+1),"X=");
//      xmem2root( &Carddata,((unsigned long)CARD_DATA_BASE+(unsigned long)((unsigned long)temp*(unsigned long)CARD_DATA_BYTES)),CARD_DATA_BYTES);
      if(Carddata.CardNo != 0)
      {
//      	xmem2root(temp1,((unsigned long)CARD_DATA_BASE+(unsigned long)((unsigned long)temp*(unsigned long)CARD_DATA_BYTES)),sizeof(temp1));
//         printf("%d %d \n", (CARD_DATA_BASE+(temp*CARD_DATA_BYTES))/0x1000,(CARD_DATA_BASE+(temp*CARD_DATA_BYTES))%0x1000 );
//         for(i=0;i<99;i++)
//         {
//         	printf("%x ",temp1[i]);
//         }

         return(temp);
      }
		temp--;
	}
	return(CARD_NOT_FOUND);
}
 */
/*-------------------------------------------------------------------------*/

short VerifyCardInDB(DWORD cardno,BYTE channelno,BYTE TWeekDay)
{
	return(0);	 
}
/*-------------------------------------------------------------------------*/

/*** BeginHeader Check_TimeZone*/
int Check_TimeZone(unsigned char TZ_No,unsigned char WeekDay);
/*** EndHeader */
int Check_TimeZone(unsigned char TZ_No,unsigned char WeekDay)
{
unsigned char SlotNo;
unsigned int chk;
struct TIME_ZONE_STR TZStEndTime;

	TZ_No--;
	if(TZ_No >= MAX_TIME_ZONE)
		return(-1);
	if(WeekDay >= 8)//ARMD0264
		WeekDay = 1;

	MsgPrint(1,TZ_No,"TZ No=");
	MsgPrint(1,WeekDay,"Week Day=");

	GetTimeZone(TZ_No,&Timezone);
	//xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE + (unsigned long)((unsigned long)sizeof(Timezone)* (unsigned long)TZ_No),sizeof(Timezone));

	for(SlotNo=0;SlotNo<MAX_TZ_SLOTS;SlotNo++)
	{
		TZStEndTime = Timezone.TimeZone[WeekDay].TZSlotNo[SlotNo];
		memcpy((unsigned char *)&TZStEndTime,(unsigned char *)&Timezone.TimeZone[WeekDay].TZSlotNo[SlotNo],sizeof(TZStEndTime));
//	   MsgPrint(1,TZStEndTime.StarHours,"STZ Hours=");
//	   MsgPrint(1,TZStEndTime.StarMin,"STZ Min=");
//	   MsgPrint(1,TZStEndTime.EndHours,"ETZ Hours=");
//	   MsgPrint(1,TZStEndTime.EndMin,"ETZ Min=");

		chk = TZStEndTime.EndHours + TZStEndTime.EndMin + TZStEndTime.StarHours + TZStEndTime.StarMin; //DA00123
		if(chk != 0)		//DA00123  Do not allow for 00:00 to 00:00
		{
#ifdef ENABLE_NIGHTSHIFT_TZ                    //F0010
			if(TZStEndTime.EndHours > TZStEndTime.StarHours)
			{
				if(ValidateTZ(&TZStEndTime) == TimeZone_OK)
					return(TimeZone_OK);
			}
			else if(TZStEndTime.EndHours == TZStEndTime.StarHours)
			{
				if(TZStEndTime.EndMin >= TZStEndTime.StarMin)
				{
					if(ValidateTZ(&TZStEndTime) == TimeZone_OK)
						return(TimeZone_OK);
				}
				else
				{
					if(ValidateTZCrossover(TZStEndTime) == TimeZone_OK)
						return(TimeZone_OK);
				}
			}
			else
			{
				if(ValidateTZCrossover(TZStEndTime) == TimeZone_OK)
					return(TimeZone_OK);
			}
#else
			if(ValidateTZ(&TZStEndTime) == TimeZone_OK)
				return(TimeZone_OK);
#endif
		}
	}
	return(EVENT_TimeZone_Err);        // time zone do not match
}

/*----------------------------------------------------------------------*/
/*
char CheckAPB(struct CARD_DATA empcard,BYTE ReaderNo )
{
   // check this function from flah read
	if(ReaderNo == 1)
	{
      if(empcard.CardInfo.APB != SET)
		{  empcard.CardInfo.APB = SET;
        // root2xmem((unsigned long)CARD_DATA_BASE+(unsigned long)((unsigned long)temp*(unsigned long)CARD_DATA_BYTES),&empcard,CARD_DATA_BYTES);
         return(0);
		}
		else
			return(APB_Err);
	}
	else if(ReaderNo == 2)
	{
		if(empcard.CardInfo.APB != CLR)
		{  empcard.CardInfo.APB = CLR;
       //  root2xmem((unsigned long)CARD_DATA_BASE+((unsigned long)temp*(unsigned long)CARD_DATA_BYTES),&empcard,CARD_DATA_BYTES);
         return(0);
		}
		else
			return(APB_Err);
	}
	else
		return(APB_Err);
}
*/
/*--------------------------------------------------------------------------------------*/
// Following will check lastcard error and sent all required lastcard error parameters...
/*** BeginHeader CheckLastCardError*/
unsigned char CheckLastCardError(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char readerno);
/*** EndHeader */
unsigned char CheckLastCardError(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char readerno)
{
	if((readerno == 0) || (readerno > MAX_READERS_SUPPORT))
	   return(EVENT_LAST_CARD_ERROR);
   if((SysInfo.LastCardTime != 0) && (DRStruct[readerno-1].LastCardTimer != 0) && (DRStruct[readerno-1].DRLastCardChk == SET))
   {
	   if(cardno == DRStruct[readerno-1].LastCardNo)
          return(EVENT_LAST_CARD_ERROR);
   }
   DRStruct[readerno-1].DRLastCardChk = SET;
   DRStruct[readerno-1].LastCardTimer = SysInfo.LastCardTime;
   return(0);
}

/*--------------------------------------------------------------------------------------*/
int VerifyCardData(struct CARD_DATA verifycard,BYTE readerno,BYTE CWeekDay)
{
int tempdata;
#ifdef EN_CARD_EXP_DATE
time_t time;  
#endif

#ifdef ENABLE_PIN_VERIFICATION
	if(empcard.CardPin==UserPin)
	{
		MsgPrint(MSG_WARNING,empcard.CardNo,"CardNo");
		MsgPrint(MSG_WARNING,empcard.CardPin,"Card Pin");
	}
	else
	{
		MsgPrint(MSG_WARNING,0,"Card Pin Error");
		HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
		return(EVENT_PIN_VERIFICATION);
	}
#endif
	if((CurrentUser.SearchCard.Info.CType == 0) && (Doorinfo.UserRestrict == 1)) //ARMD0251       //shree 23Jan09         //shree 13Oct
	{
		MsgPrint(MSG_WARNING,EVENT_INVALID_ACCESS,"Invalid Access returncode=");      //shree 19Jan09
		MakeSound(SOUND_CARD_NOT_FOUND);
		if(DisplayMode == MODE_WAIT_FOR_CARD)
		{
			F_KeyIdleTime = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME-4;
			DisplayMode = MODE_WAIT_FOR_CARD;
			DisplaySubMode=0;
			HandleDisplayErrorMessages(EVENT_INVALID_ACCESS);     //shree 19Jan09
		}
		return(EVENT_INVALID_ACCESS);

	}
#ifdef ENABLE_PIN_PROX
	if((CurrentUser.SearchCard.Info.CType & UTYPE_KEYBOARD_NOT_ALLOWED)&&(CurrentUser.InputType==INPUT_USER_FROM_PIN_PROX))//ARMD0251
	{	         
		if(DisplayMode == MODE_WAIT_FOR_CARD)
		{
	        F_KeyIdleTime = CLR;
	        IdleKeyCounter = MAX_KEY_IDLE_TIME-4;
	        DisplayMode = MODE_WAIT_FOR_CARD ;
	        DisplaySubMode=0;
			L_DisplayROMStr("Please Show Card",16,ROW_USER_ENTRY);
	        return(1);
		}
	}
   if((SysInfo.ChkPin != 0) && (ReaderInfo[readerno-1].PinEnDis != 0))
   {
      if(CurrentUser.SearchCard.Info.CType & UTYPE_CHECK_PIN)
      {
         if((CurrentUser.InputType == INPUT_USER_FROM_PIN_CARD_WEIGAND) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
         {
            if((ReceivedPin != CurrentUser.SearchCard.CardPin) || (CurrentUser.InputType == INPUT_USER_FROM_PIN_PROX))
            {
               MsgPrint(MSG_WARNING,EVENT_PIN_VERIFICATION,"Invalid Access returncode=");
               HandleDisplayErrorMessages(EVENT_PIN_VERIFICATION);
               return(EVENT_PIN_VERIFICATION);
            }
         }
      }
   }
#endif

//This to check whether user has access or not, on particular holiday.
	if((verifycard.CardInfo.Holiday & CARD_BIT_DURESS_CHK) && (Doorinfo.EnableDuress != 0))     //Need to add alarm o/p's
	{
		MsgPrint(MSG_WARNING,EVENT_DURESS_ACCESS,"Error:Duress Access =");
		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,readerno,EVENT_DURESS_ACCESS);
	}
#ifdef EN_CARD_EXP_DATE
	if(verifycard.ExpDT!=0)
   	{
		time = verifycard.ExpDT;
		gmtime_r(&time,&CurrentCard.VDate);

	   	if(verifycard.ExpDT <= CurrentTimeInt)
	   	{
//			HandleDisplayErrorMessages(EVENT_Card_Expired);
	      	return(EVENT_Card_Expired);
		}
	}
#endif
	if(verifycard.CardInfo.Holiday & CARD_BIT_HOLIDAY_CHK)
	{
	   tempdata = Check_Holiday(readerno);
	   if(tempdata == HOLIDAY_NO_ACCESS)
	   {
		   if(readerno == 1)
		   {
				MsgPrint(MSG_WARNING,HOLIDAY_NO_ACCESS,"Error:Holiday No Access =");
#ifdef SUPPORT_SPEECHIC
				PlaySoundMsg(HOLIDAY_NO_ACESS);  
#endif		   
		   }		  
		   HandleDisplayErrorMessages(EVENT_HOLIDAY_NO_ACCESS);
	      return(EVENT_HOLIDAY_NO_ACCESS);
	   }
	}
	else if(verifycard.CardInfo.Holiday == 0)
	{
		MsgPrint(MSG_WARNING,verifycard.CardInfo.Holiday,"Holiday Checking Disabled:Holiday=");
	}
	MsgPrint(1,readerno,"VerifyCardData:ReaderNo=");

//==============================================
#ifdef EN_DOORACCESS
	//ARMF2002://Implement DoorAccess
	if(!(verifycard.DoorAccess & (0x01<<readerno-1))) 	 //ARMF2002,0x01 shifted by (readerno-1) positions 
		return(Door_Not_Valid);		 
	
#endif//#endif EN_DOORACCESS
//==============================================
#ifdef SUPPORT_ACCESS_LEVEL
	if(verifycard.CardInfo.Door2 == 255)
   {									
   	// Indicates this is AccessLevel Logic
      if(verifycard.CardInfo.Door1 == 0)
		 	return(Door_Not_Valid);
      else if(verifycard.CardInfo.Door1 == 255)
      {
	 		return(0);
      }
	//  GetAccessLevel( (verifycard.CardInfo.Door1-1)-1,&AccessLevel);//Added to solve above bug.
		if( GetAccessLevel(verifycard.CardInfo.Door1-1,&AccessLevel) !=0)
			return(Door_Not_Valid);			
		if (AccessLevel.TimeZone[readerno-1]==0)
			return(Door_Not_Valid);
		 if (Check_TimeZone(AccessLevel.TimeZone[readerno-1],CWeekDay)== TimeZone_OK)
       		return(0);
		 else
		 {
			 if(readerno == 1)
#ifdef SUPPORT_SPEECHIC				 
				PlaySoundMsg(TIMEZONE_ERROR); 
#endif			 
		 	return(EVENT_TimeZone_Err);
		 }		
   }
   #ifdef SUPPORT_NSERIES2
   	if(verifycard.CardInfo.Door2 == CHK_ACCESS_MONTH)
	{
      if((verifycard.CardInfo.Door1 == 0) || ((verifycard.CardInfo.Door1 > 32) && (verifycard.CardInfo.Door1 < 255)))
         return(Door_Not_Valid);
      else if(verifycard.CardInfo.Door1 == 255)       // no timezone associates to this card.
      {
         goto GoToVALIDCARD;
      }

      GetAccessMonth(verifycard.CardInfo.Door1-1,&AccessMonth);   // read and store the info into the struct access month
     /* if(AccessMonth.AccessMonthLevel[Datetime.Date.Day-1] == 0)        // compare data with current date
         return(Door_Not_Valid);  
      else*/ if(AccessMonth.AccessMonthLevel[Datetime.Date.Day-1] == 255)
      {
         goto GoToVALIDCARD;           // if access level is 255 then access granted
      }
      GetAccessLevel(AccessMonth.AccessMonthLevel[Datetime.Date.Day-1],&AccessLevel);
	 if( AccessLevel.TimeZone[readerno-1] == 0x00 )//ARMF0278
	 return(Door_Not_Valid);//restricted user if time zone == 0x00.
      if(Check_TimeZone(AccessLevel.TimeZone[readerno-1],0) == TimeZone_OK)
         goto GoToVALIDCARD;
      else
         return(EVENT_TimeZone_Err);
	}	
	#endif
   else
   {
	   if((readerno%2)==1)
	      tempdata = verifycard.CardInfo.Door1;
	   else
	      tempdata = verifycard.CardInfo.Door2;
	   if(tempdata != 0)
	      tempdata = Check_TimeZone(tempdata,(CWeekDay));
	   else
	   {
	      MsgPrint(1,tempdata,"Door Invalid =");
	      HandleDisplayErrorMessages(EVENT_Door_Not_Valid);
	      return(EVENT_Door_Not_Valid);
	   }
   }
#endif
	if(tempdata == EVENT_TimeZone_Err)
		return(EVENT_TimeZone_Err);
	else
   	if(tempdata == TimeZone_OK)
      {
	  GoToVALIDCARD:
      	return(0);
	        //CheckZoneAPB(readerno);
      }
	return(0);
}

/*--------------------------------------------------------------------------------------*/
void HandleDisplayErrorMessages(short errorvalue)
{
unsigned char dispstr[20];
	memset(dispstr,'\0',sizeof(dispstr));
//	L_DisplayROMStr("                ",16,ROW_USER_ENTRY);	
	if(ReaderNo == 1)
	{
		F_authScreenTimerEnable = 1;
		F_authScreenTimer =4;	
		IdleKeyCounter	= CLR;	
	}
	switch(errorvalue)
	{
		case EVENT_Card_Expired:
		if(ReaderNo == 1)
		{
	#ifdef SUPPORT_SPEECHIC
			PlaySoundMsg(CARD_EXPIRED);  // Speech code
	#endif		
				sprintf((char *)dispstr,"%02d/%02d/%02d %02d:%02d   ",CurrentCard.VDate.tm_mday,	\
				CurrentCard.VDate.tm_mon,CurrentCard.VDate.tm_year-YEAR_BASE_VALUE,CurrentCard.VDate.tm_hour,CurrentCard.VDate.tm_min);
				L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY);
		}
#ifdef DISP_EVENT_MSGS_FROM_FLASH
         GetMessageFromFlash(ERROR_MESSAGE_BASE+EVENT_Card_Expired,dispstr);
//         L_DisplayROMStr(dispstr,16,ROW_CARD_ERROR_DISP);
	if(ReaderNo == 1)
		 L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY2);
	else
		DisplayBottomStatusIcon(0,dispstr,0,0);
#else
	if(ReaderNo == 1)
         L_DisplayROMStr("Validity Expired  ",16,ROW_USER_ENTRY2);
	else
		DisplayBottomStatusIcon(0,"Validity Expired  ",0,0);
#endif//#ifdef DISP_EVENT_MSGS_FROM_FLASH
		break;
		case EVENT_DR_PC_USER_CLOSE:
			if(ReaderNo == 1)
					L_DisplayROMStr("DOOR LOCKED: PC",16,ROW_USER_ENTRY2);
			else
				DisplayBottomStatusIcon(0,"DOOR LOCKED: PC",0,0);
		break;

		case EVENT_VALID_CARD:  	
			if(ReaderNo == 1)
			{
				 GetMessageFromFlash(ERROR_MESSAGE_BASE+errorvalue,dispstr);
				 L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY2);
				 DisplayEventIcon(errorvalue) ;			
			}
		
/*			if(CHECK_ATT_NOCARD(DspRdrNo) || CHECK_ATT_CARD_ONLY(DspRdrNo))
				L_DisplayROMStr("User Verified   ",16,ROW_CARD_ERROR_DISP);
			else
				L_DisplayROMStr("Access Granted  ",16,ROW_CARD_ERROR_DISP);  */
			break;

		case MAX_TIME_ZONE:
			if(ReaderNo == 1)
				L_DisplayROMStr("Invalid Time Zone",16,ROW_USER_ENTRY2);
			else
				DisplayBottomStatusIcon(0,"Invalid Time Zone",0,0);
				
#ifdef SUPPORT_SPEECHIC
		PlaySoundMsg(TIMEZONE_ERROR);  // Speech code
			waitX10ms(100);
#endif		
			break;

		case INITIALIZATION_ERROR:
			if(ReaderNo == 1)
				L_DisplayROMStr("System Init Err ",16,ROW_USER_ENTRY2);
			break;
#ifndef DISP_EVENT_MSGS_FROM_FLASH
		case EVENT_FACLITY_ERR:
			if(ReaderNo == 1)
				L_DisplayROMStr("FacilityCode Err",16,ROW_USER_ENTRY2);
			else
				DisplayBottomStatusIcon(0,"FacilityCode Err",0,0);
			break;

		case EVENT_VALID_CARD:
#ifdef BIO_METRIC
			if(CHECK_ATT_NOCARD() || CHECK_ATT_CARD_ONLY())//if(CHECK_ATT_SC_NOCARD()||CHECK_ATT_NOCARD()||CHECK_ATT_CARD_ONLY())
#else
			if(CHECK_ATT_NOCARD() || CHECK_ATT_CARD_ONLY())
#endif//#ifdef BIO_METRIC
		if(ReaderNo == 1)
		{
			PlaySoundMsg(AUTHERISED);  // Speech code
			GetMessageFromFlash(ERROR_MESSAGE_BASE+errorvalue,dispstr);
			L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY2);
			DisplayEventIcon(errorvalue) ;							
		}
			break;

		case CARD_NOT_FOUND:
		case EVENT_CARD_NOT_FOUND:
			if(ReaderNo == 1)
			{
				L_DisplayROMStr("UserUnauthorised",16,ROW_USER_ENTRY2);
				PlaySoundMsg(NOT_AUTHERISED);
			}
			break;

		case EVENT_TimeZone_Err:
			if(ReaderNo == 1)
			{
				L_DisplayROMStr("Time Zone Error ",16,ROW_USER_ENTRY2);
				PlaySoundMsg(TIMEZONE_ERROR);  // Speech code
			}
			else
				DisplayBottomStatusIcon(0,"Time Zone Error ",0,0);
			break;

		case EVENT_Door_Not_Valid:
			if(ReaderNo == 1)
				L_DisplayROMStr("User Restricted ",16,ROW_USER_ENTRY2);
			else
				DisplayBottomStatusIcon(0,"User Restricted ",0,0);
			break;

		case EVENT_LAST_CARD_ERROR:
			if(ReaderNo == 1)
				L_DisplayROMStr("Same Card Error",16,ROW_USER_ENTRY2);
			else
				DisplayBottomStatusIcon(0,"Same Card Error",0,0);
			break;

		case EVENT_FINGER_NOT_MATCH:
			if(ReaderNo == 1)
				L_DisplayROMStr("Finger Not Match",16,ROW_USER_ENTRY2);
			break;

		case HOLIDAY_NO_ACCESS:
		case EVENT_HOLIDAY_NO_ACCESS:
			if(ReaderNo == 1)
			{
				L_DisplayROMStr("Holiday NoAccess",16,ROW_USER_ENTRY2);
				PlaySoundMsg(HOLIDAY_NO_ACESS);  // Speech code
			}
			else
				DisplayBottomStatusIcon(0,"Holiday NoAccess",0,0);
			break;

		case EVENT_APB_ERROR:
			if(ReaderNo == 1)
			{
				L_DisplayROMStr("APB Error",16,ROW_USER_ENTRY2); 
				PlaySoundMsg(APB_ERROR);
			}
			else
				DisplayBottomStatusIcon(0,"APB Error",0,0);
  		break;

		case EVENT_PIN_VERIFICATION:
			if(ReaderNo == 1)
			{
				L_DisplayROMStr("Pin Mismatch",16,ROW_USER_ENTRY2);
				PlaySoundMsg(INVALID_PIN);
			}
			else
				DisplayBottomStatusIcon(0,"Pin Mismatch",0,0);
			break;

		case EVENT_INVALID_ACCESS:
			if(ReaderNo == 1)
				L_DisplayROMStr("Invalid UserType",16,ROW_USER_ENTRY2);
			break;

//		case EVENT_SPECIAL_CARD: 
		case EVENT_ESCORT_CARD:			 
		case EVENT_INTRUSION_CARD		 :
		case EVENT_OCCUPANCY_CONTROL_CARD :
		case EVENT_OVERRIDE_ACCESS_CARD	  :
		case EVENT_FIRST_INUSER_CARD	:	 
		case EVENT_EMERGENCY_CARD		: 
		case EVENT_DONOT_DISTURB_CARD	: 
		case EVENT_ALERT_CARD			: 
		case EVENT_NORMAL_CARD			:  //ARMF0283 
		case EVENT_DMZ_RESET_CARD		:
		case EVENT_DONOT_DISTURBZONE_CARD :
			if(ReaderNo == 1)
				L_DisplayROMStr("Special Card   ",16,ROW_USER_ENTRY2);
#ifdef SUPPORT_NSERIES2
		if(ReaderNo == 1)
	      L_DisplayDecimalByte(SpecialCardData.CardType,13,ROW_USER_ENTRY); //281210-2 //SPL  Card Type Display
#endif//#ifdef SUPPORT_NSERIES2
			break;
#endif//#ifndef DISP_EVENT_MSGS_FROM_FLASH
	case EVENT_FIRST_INCARD_NOT_FOUND ://must be done user programmable and seperate case in next release.
	 	if(ReaderNo == 1)
			L_DisplayROMStr("Show Access Card",16,ROW_CARD_ERROR_DISP);		   //ARMD0288
	  break;
	   default:
#ifdef DISP_EVENT_MSGS_FROM_FLASH
			if((errorvalue >= 0) && (errorvalue < MAX_ERROR_MSGS) && (errorvalue != EVENT_ESCORT_CARD))	//ARMD0274
         {
			 GetMessageFromFlash(ERROR_MESSAGE_BASE+errorvalue,dispstr);
			if(ReaderNo == 1)
			{
			 L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY2);
			 DisplayEventIcon(errorvalue) ;
			}
			else if(ReaderNo == 2)
				DisplayBottomStatusIcon(0,dispstr,0,0);

		}
#ifdef SUPPORT_NSERIES2
         if(errorvalue == EVENT_ESCORT_CARD 			|| errorvalue == EVENT_INTRUSION_CARD       || 
		 	errorvalue == EVENT_OCCUPANCY_CONTROL_CARD 	|| errorvalue == EVENT_OVERRIDE_ACCESS_CARD || 
		 	errorvalue == EVENT_FIRST_INUSER_CARD		|| errorvalue == EVENT_EMERGENCY_CARD       || 
		 	errorvalue == EVENT_DONOT_DISTURB_CARD		|| errorvalue == EVENT_ALERT_CARD	        ||
			errorvalue == EVENT_NORMAL_CARD		        || errorvalue == EVENT_DMZ_RESET_CARD        ||  
			errorvalue == EVENT_DONOT_DISTURBZONE_CARD )	//281210-2 //ARMD0274  //ARMF0283 
		{
	         //GetMessageFromFlash(ERROR_MESSAGE_BASE+EVENT_ESCORT_CARD,dispstr);	 //	EVENT_ESCORT_CARD is location for msg of special card
		  if(ReaderNo == 1)
		  {
			GetSpecialCardMSG(errorvalue,dispstr);//ARMD0275 
	        L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY2);
		  }
		     //L_DisplayDecimalByte(SpecialCardData.CardType,13,ROW_USER_ENTRY);	//SPL  Card Type Display
		}
		else if(errorvalue == EVENT_SPCL_CARD_NOT_FOUND)
		{ 
		 if(ReaderNo == 1)
		  {
			GetSpecialCardMSG(errorvalue,dispstr);//ARMD0275 
	        L_DisplayROMStr(dispstr,16,ROW_USER_ENTRY2);
		  }
		}
#endif//#ifdef SUPPORT_NSERIES2
#endif//#ifdef DISP_EVENT_MSGS_FROM_FLASH

	   		break;
	}
}

/*-----------------------------------------------------------------------------*/
/*
Following all functions are for admin users
*/
/*short AddAdminUser(struct CARD_DATA empcard)
{
	short temp;
//	BYTE tempwrbuf[SPIBUFSIZE];
	MsgPrint(MSG_WARNING,empcard.CardNo,"AddAdminCUser:Card No is=");
   	temp = SearchAdminUser(empcard.CardNo);
  	if(temp == CARD_NOT_FOUND)
	{
		temp = SearchAdminUser(0);
		if(temp >= MAX_ADMIN_USER)
		{
			temp = SearchAdminUser(0xFFFF);
			if(temp >= MAX_ADMIN_USER)
			{
				MsgPrint(MSG_WARNING,temp,"AddAdminUser:No mem for card add ptr=");
				return(-1);
			}
		}
		MsgPrint(MSG_WARNING,temp,"AddAdminUser:New card to be added ptr=");
	}
	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);	
	memcpy(&tempwrbuf[temp*ADMIN_DATA_BYTES],&empcard,ADMIN_DATA_BYTES);
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1);   		
   	return(temp);

}
*/
/*----------------------------------------------------------------------*/
/*short SearchAdminUser(CARDNO_DATA_STORAGE_TYPE cardno)
{ 	
unsigned int temp;
struct CARD_DATA empcard;
	temp = 0;
	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
	while(temp < MAX_ADMIN_USER)
	{
//      xmem2root((BYTE*)&empcard,(BYTE* )&tempwrbuf +(temp*ADMIN_DATA_BYTES),ADMIN_DATA_BYTES);
		memcpy((BYTE*)&empcard,(BYTE* )&tempwrbuf +(temp*ADMIN_DATA_BYTES),ADMIN_DATA_BYTES);
		if(empcard.CardNo == cardno)
			return(temp);
		temp++;
    }
    return(CARD_NOT_FOUND);
}
*/
/*----------------------------------------------------------------------*/
/*short SearchDisplayAdminUser(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)
{
int temp;
	temp = SearchAdminUser(cardno);
	if(temp == CARD_NOT_FOUND)
	{
//		MsgPrint(MSG_WARNING,temp,"SearchDisplayAdminUser:Card not found ptr=");
		return(CARD_NOT_FOUND);
	}
	else
	{	
		MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
     	memcpy((BYTE *)empcard,(BYTE* )&tempwrbuf + (temp*ADMIN_DATA_BYTES),ADMIN_DATA_BYTES);
	}
	return(temp);
}
*/
/*----------------------------------------------------------------------*/
/*short DelAdminUser(struct CARD_DATA empcard)
{
	int temp;
  	temp = SearchAdminUser(empcard.CardNo);
	if(temp == CARD_NOT_FOUND)
	{
		MsgPrint(MSG_WARNING,temp,"DelAdminUser:Card Not found");
	 	return(CARD_NOT_FOUND);
	}
	else
	{
      	empcard.CardNo = 0x0;
		empcard.CardInfo.APB = 0x0 ;
		empcard.CardInfo.Door1 = 0x0 ;
        empcard.CardInfo.Door2 = 0x0 ;
        empcard.CardInfo.Holiday = 0x0 ;
#ifdef ENABLE_PIN
		empcard.CardPin = 0x0;
#endif
		empcard.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
        empcard.Info.BirthMonth = 0;
        empcard.Info.BirthDate = 0;
#endif
		MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		memcpy(&tempwrbuf[temp*ADMIN_DATA_BYTES],&empcard,ADMIN_DATA_BYTES);
		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    	BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1); 
	}
  return(temp);
}
*/
/*----------------------------------------------------------------------*/
/*short DelAdminUserByLocation(int location)
{
CardData empcard;
	if(location <=MAX_ADMIN_USER)
	{
      	empcard.CardNo = 0x0;
		empcard.CardInfo.APB = 0x0 ;
        empcard.CardInfo.Door1 = 0x0 ;
        empcard.CardInfo.Door2 = 0x0 ;
        empcard.CardInfo.Holiday = 0x0 ;
		empcard.CardPin = 0x0;
		empcard.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
        empcard.Info.BirthMonth = 0;
        empcard.Info.BirthDate = 0;
#endif
		MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		memcpy(&tempwrbuf[location*ADMIN_DATA_BYTES],&empcard,ADMIN_DATA_BYTES);
		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    	BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1); 
		return(location);
	}
	else
		return(-1);
}
*/
/*----------------------------------------------------------------------*/
/*** BeginHeader CheckFacilityCode*/
int CheckFacilityCode(unsigned char readerno, unsigned char fcode);
/*** EndHeader */
int CheckFacilityCode(unsigned char readerno, unsigned char fcode)
{
BYTE i;
	if(Doorinfo.FaclityCode_Chk)
	{
      if(ReaderInfo[readerno-1].FacCheck == 1)          //D0042
      {
         for(i=0;i<8;i++)
         {
            if(fcode == SysInfo.FacilityCodeNo[i])
               return(0);
         }
         return(-1);
      }
      else
         return(0);
	}
  	return(0);
}

/*----------------------------------------------------------------------*/
/*void DelAllAdminUser(void)
{  
unsigned char location;
struct CARD_DATA empcard;
	for(location = 0;location <=MAX_ADMIN_USER;location++)
	{
    	empcard.CardNo = 0x0;
		empcard.CardInfo.APB = 0x0 ;
        empcard.CardInfo.Door1 = 0x0 ;
        empcard.CardInfo.Door2 = 0x0 ;
        empcard.CardInfo.Holiday = 0x0 ;
		empcard.CardPin = 0x0;
		empcard.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
        empcard.Info.BirthMonth = 0;
        empcard.Info.BirthDate = 0;
#endif
		memcpy (&tempwrbuf[location *ADMIN_DATA_BYTES], (char *)&empcard, ADMIN_DATA_BYTES);
	}
	MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
	BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1);	
	empcard.CardNo = 11111;
	if( SearchDisplayAdminUser(empcard.CardNo,&empcard) == CARD_NOT_FOUND)
	{
		empcard.CardNo = 11111;
	    empcard.CardPin = 12345;
	    AddAdminUser(empcard);
	}
}*/
/*----------------------------------------------------------------------*/

void DelAllFacilityCode(void)
{

	unsigned char temp1;
	if( !(InitialiseFlags & DELETE_ALL_FACILITY_CODE) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_FACILITY_CODE;
	for(temp1=0;temp1<8;temp1++)
		SysInfo.FacilityCodeNo[temp1] = 0xFF;
   	WriteSysInfoToFlash();
}


/*----------------------------------------------------------------------*/
void IniDefaultSysInfo(void)
{ 
//BYTE i;
int i;

	if( !(InitialiseFlags & DELETE_ALL_INI_DEF_SYSTEM) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_INI_DEF_SYSTEM ;
   	SysInfo.MySlaveNo = 1;
	SysInfo.BannerMsg = 0;
   	SysInfo.ContInOut = 0;
	SysInfo.InOutToggle = 0;
   	SysInfo.IdentifyMode = SET;
	SysInfo.GlobleMsg = 0;
	SysInfo.LastCardTime = 0;
	SysInfo.NameType = 0;
	SysInfo.MemMgmt = 0;
#ifdef BIO_METRIC
for(i=0;i<MAX_LOCAL_DOORS;i++)
//	ReaderInfo[i].CntrolrType = 0;	   	//FOR BIO Default weigand controller type
	ReaderInfo[i].CntrolrType = 0;	   	//FOR BIO Default weigand controller type       For Demo 
	SysInfo.ControllerType = ReaderInfo[0].CntrolrType;	  //ARMD0463
#else
for(i=0;i<MAX_LOCAL_DOORS;i++)		 	//For ACS
	ReaderInfo[i].CntrolrType = 1;
	SysInfo.ControllerType = ReaderInfo[0].CntrolrType;	  //ARMD0463
#endif
	for(i=0;i<4;i++)
	{
		SysInfo.InOutTimeZone[i] = i+61;
		SysInfo.TZInOut[i] = 1;
	}
   	SysInfo.InputED = 0;
	//SysInfo.ChkPin = 1;
   	SysInfo.ChkPin = 0;	//As after default init asking for pin for non proxy reader in A2R F/W.			
	SysInfo.TransWriteCheck = 1;	//ARMD0135
   	SysInfo.PushNoOfTrans = 5;
   	SysInfo.PushThreshold = 5;
   	SysInfo.PushTransDelay = 1;
   	SysInfo.PushWaitDelay = 60;
	SysInfo.SelAccessType = 0;
	for(i=0;i<6;i++)
		SysInfo.TransType[i] = i+95;
//	SysInfo.SCCardNoType = 0;	   //ARMF0514
//	SysInfo.CardDataSource = 0;
	SysInfo.SCKeyType[0] = 0;  		// 1 indicates Key B   0 = Key B
	SysInfo.SCKeyType[1] = 0;
	SysInfo.SCKeySector[0] = 0;
	SysInfo.SCKeySector[1] = 1;

#ifndef SUPPORT_OLD_VERSION2_0
	SysInfo.SCReaderEnDis[0] = 0;
	SysInfo.SCReaderEnDis[1] = 0;
#endif

#ifdef BIO_METRIC
#ifndef SUPPORT_SUPREMA
	SysInfo.BioEnrollType = BIO_SINGLE_ENROLL;		//ARMD0135
#endif
#endif
	SysInfo.AuthIP = 0;
   	SysInfo.BaudRate[SER_BAUD_BIO] = 57600;
   	SysInfo.BaudRate[SER_BAUD_SC1] = 38400;//9600;
   	SysInfo.BaudRate[SER_BAUD_SC2] = 38400;//9600;
   	SysInfo.BaudRate[SER_BAUD_PC]  = 38400;//9600;
//#ifdef ENABLE_TCP_PUSH
   	memcpy(SysInfo.PUSH_TCP_ServAdd1,TCP_PUSH_SERVER1,16);
   	memcpy(SysInfo.PUSH_TCP_ServAdd2,TCP_PUSH_SERVER2,16);
	SysInfo.PUSH_TCP_Port1 = TCP_PUSH_PORT1;
	SysInfo.PUSH_TCP_Port2 = TCP_PUSH_PORT2;
//#endif

   	memcpy(SysInfo.LOCAL_IP,PRIMARY_STATIC_IP,16);
	memcpy(SysInfo.UDP_IPAdd,UDP_IP,16);
	memcpy(SysInfo.LOCAL_NETMASK,PRIMARY_NETMASK,16);
	memcpy(SysInfo.LOCAL_GATEWAY,PRIMARY_MY_GATEWAY,16);
	memcpy(SysInfo.LOCAL_DOMAINNAME,PRIMARY_LOCAL_DOMAINNAME,16);
	SysInfo.UDP_PushPort = UDP_DEFAULT_PORT;
	SysInfo.ETH_Port = TCP_DEFAULT_PORT;

	Doorinfo.UDPHeartBeat = 60;
	memcpy(Doorinfo.HeartBeatIP,"192.168.0.3",16);
	Doorinfo.HBPort=UDP_DEFAULT_PORT;
	Doorinfo.UDPServerPort=UDP_DEFAULT_PORT;

	memcpy(SysInfo.SB_AUTH_ServAdd1,"192.168.0.3",16);
	memcpy(SysInfo.SB_AUTH_ServAdd2,"192.168.0.3",16);
   	SysInfo.SB_AUTH_Port1 =	TCP_PUSH_PORT1;
  	SysInfo.SB_AUTH_Port2 = TCP_PUSH_PORT1;

	Doorinfo.EnableEmail=0;
	Doorinfo.DontDisturb = 0;			
	Doorinfo.OccupancyCount = 0;
	Doorinfo.UserRestrict = 0;						//ARMD0453
	Doorinfo.SecurityEnDis = 0;						//ARMD0453
	SysInfo.ServerAuthType = 0;
	SysInfo.BlockKeyboard = 0;
	SysInfo.EnDisUserMsg = 0;
//	SysInfo.PinProxFCode = 0;
//    Doorinfo.OccupancyCount = MAX_EMP_IN_COUNT;
    Doorinfo.FirstInUserRule = 0;
	Doorinfo.F_FirstInUser = 0;			//ARMD0336
    Doorinfo.DuelUserAuth = 0;
    Doorinfo.EnDisDeadManZone = 0;
	Doorinfo.DeadManZoneTime = 10;
	Doorinfo.BulkAddDelCard = 0;
    Doorinfo.AnyDualFinger =0;
	Doorinfo.BeepEnable = 3;		//ARMD0135
	Doorinfo.NoCheckAPBTimer = 20;
	Doorinfo.EnDisEmpInDispCount = 0;
	Doorinfo.GPRSEnable = 0;
	Doorinfo.EnDisEMPNoTrnx = 1;//0;
	Doorinfo.AllowKeypadCard = 0;
	#ifdef SUPPORT_NSERIES2
	Doorinfo.E_InEmpCount = InEmpCount = InEmpCount_Back = 0;
	#endif
	#ifndef ENABLE_PIN_PROX
	Doorinfo.GlobalPinProx = 0;
	#endif
	#ifdef ENABLE_SLAVE_SUPPORT
    	Doorinfo.EnDisTransparentMode = 0;//dont change this
		Doorinfo.SlaveRespMode = 1;//dont change this
#else
	Doorinfo.EnDisTransparentMode = 0;//dont change this	 
	Doorinfo.SlaveRespMode = 0;
#endif

	for(i=0 ;i<8 ;i++)
	{
		if( SysInfo.SystemEventTimer[i]==0 )
			SysInfo.SystemEventTimer[i]=5;//default time
	}
	SysInfo.WeigandOutCont = 26;
	SysInfo.PushEnable = 0;
//	Doorinfo.CardDigit = 10;		//ARMF0514
//	Doorinfo.CardMask = 32;			//ARMF0514
	SysInfo.TransAdjMode = 1;
	Doorinfo.FireType = 1;
	Doorinfo.GPRSThreshold = 0;
	Doorinfo.GPRSTime = 1;
	Doorinfo.PushConnectTimeout = 10;
	Doorinfo.PushCloseDelay = 10;
	Doorinfo.PollSlaveNo = 0;
	Doorinfo.DoorInterlock = 0;
	SysInfo.EnableSDWrite = 1;
	SysInfo.EnableAccessDate = 1;

   	memcpy(Doorinfo.InternetTestIP,INTERNET_TEST_IP,16);//ARMF0502
//	MainMem_BuffWrt(0,1,(BYTE *)&SysInfo,SPIBUFSIZE);
//	BuffWrt_MainMem(FL_SYSINFO_PAGE,1);
	WriteDoorInfoToFlash();
	WriteSysInfoToFlash();
	for(i=0;i<=MAX_EVENT_IO;i++)
		IOEventInfo[i]=0x00;
	WriteIOEventInfoToFlash(); 
}

/*----------------------------------------------------------------------*/
void DelAllDoorInfo(void)
{

	if( !(InitialiseFlags & DELETE_ALL_DOORINFO) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_DOORINFO;
	Doorinfo.FREETIMEENABLE = 1;	//ARMD0135
	Doorinfo.APBEANABLE = 0;		//ARMD0135
	Doorinfo.F2keymode = 0;			//ARMD0135
	Doorinfo.EXTDOTL_EN = 1;		
// #ifdef SUPPORT_SUPREMA
	// Doorinfo.TemplateSize = 384;	//ARMD0135
// #else
	// Doorinfo.TemplateSize = 859;	//ARMD0135
// #endif
	//Doorinfo.FingerRecheck = 0;		//ARMD0135
	Doorinfo.MaxBacklitOnTime = 0;
	Doorinfo.SocketCloseTime = 40;
//	Doorinfo.ControllerNo = 0;
	Doorinfo.ChkHoliday = 1; //as we need to take reader1 holday.
	Doorinfo.EnableDuress = 1;
	Doorinfo.FREETIMEDOOR1 = 0;
	Doorinfo.FREETIMEDOOR2 = 0;
	Doorinfo.EXShareDotl = 0;
	Doorinfo.FaclityCode_Chk = 0;
	Doorinfo.PINPROXENABLE_DOOR1 = 0;
	Doorinfo.PINPROXENABLE_DOOR2 = 0;
	Doorinfo.EXDOTL_DLY1 = 5;	 			/* Door open too long delay stored which is programmed from pc*/
	Doorinfo.EXDOTL_DLY2 = 5;
	Doorinfo.EXDOP_TIM1 = 5;		   	    /* Door open delay stored which is programmed from pc*/
	Doorinfo.EXDOP_TIM2 = 5;
    Doorinfo.PC_D00R1_OPEN = CLR;
    Doorinfo.PC_D00R2_OPEN = CLR;
	Doorinfo.EnDisWeiParity = 1;  //as per rabbit code
	Doorinfo.ModemType = 0;
	Doorinfo.PDPContext[0] = 0;
	Doorinfo.APNType[0] = 0;
	Doorinfo.APNUserName[0] = 0;
	Doorinfo.APNPassword[0] = 0;
	Doorinfo.ServerMACAdress[0] = 0;
#ifdef SUPPORT_ICLASS_RDR
  	Doorinfo.IClassCardType = SUPPORT_16K_16CARD;      //Default 16/16 for NRL
#endif
//	Doorinfo.EXTDOTL2_EN = SET;
	//MainMem_BuffWrt(0,1,(BYTE *)&Doorinfo,SPIBUFSIZE);
    //BuffWrt_MainMem(FL_DOORINFO_PAGE,1);
	WriteDoorInfoToFlash();
	MsgPrint(MSG_WARNING,0,"Default Door Info writen.");
//	ReadDoorInfoFromFlash();    
}

/*----------------------------------------------------------------------*/
void DelAllTimeZone(void)
{
unsigned char tzno, dayofweek, slotno;
unsigned char alno, rdno,amno,date;
struct TIME_ZONE timezone;
	tzno = 0;
	if( !(InitialiseFlags & DELETE_ALL_TIMEZONE) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_TIMEZONE;

	while(tzno < MAX_TIME_ZONE)
	{
	   dayofweek = 0;
	   while(dayofweek < 7)
	   {
	      timezone.TimeZone[dayofweek].TZSlotNo[0].StarHours = 0;
	      timezone.TimeZone[dayofweek].TZSlotNo[0].StarMin = 0;
	      timezone.TimeZone[dayofweek].TZSlotNo[0].EndHours = 23;
	      timezone.TimeZone[dayofweek].TZSlotNo[0].EndMin = 59;
	      for(slotno=1;slotno<MAX_TZ_SLOTS;slotno++)
	      {
	         timezone.TimeZone[dayofweek].TZSlotNo[slotno].StarHours = 0;
	         timezone.TimeZone[dayofweek].TZSlotNo[slotno].StarMin = 0;
	         timezone.TimeZone[dayofweek].TZSlotNo[slotno].EndHours = 0;
	         timezone.TimeZone[dayofweek].TZSlotNo[slotno].EndMin = 0;
	      }
	      dayofweek++;
	   }
	   if( SaveTimeZone(tzno,&timezone)!=0)
		      MsgPrint(MSG_WARNING,tzno,"DelAllTimeZone: Time zone write fail tz=");
		
		
	   tzno++;
	}
	alno = 0;
	GetAccessLevel(alno,&AccessLevel);
	for(rdno=0;rdno<MAX_READERS_SUPPORT;rdno++)
		AccessLevel.TimeZone[rdno] = 1;
	StoreAccessLevel(alno,&AccessLevel);
         for(date=0;date<=MAX_ACCESS_MONTH_DAYS;date++)	//ARMF0278 
         {
            AccessMonth.AccessMonthLevel[date] = 0x00; 
         }
		 for(amno=0;amno<=MAX_ACCESS_MONTH_LEVEL;amno++)	 
         StoreAccessMonth(amno,&AccessMonth);
		
/*	BYTE tempwrbuf[SPIBUFSIZE];
	BYTE tzno, dayofweek,page,i;
   struct TIME_ZONE timezone;
	tzno = 0;
	page = 0; 
	i = 0;
	while(tzno < MAX_TIME_ZONE)
	{
		dayofweek = 0;
		while(dayofweek < 7)
		{
      		timezone.TimeZone[dayofweek].StarHours = 00;
			timezone.TimeZone[dayofweek].StarMin = 00;
			timezone.TimeZone[dayofweek].EndHours = 23;
			timezone.TimeZone[dayofweek].EndMin = 59;
			dayofweek++;
		}
		memcpy (tempwrbuf+(i *TIME_ZONE_BYTES), (char *)&timezone+(i *TIME_ZONE_BYTES), TIME_ZONE_BYTES);			
		i++;
		if(( tzno % 8 ) == 0)
		{	i=0;
			MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
			
			BuffWrt_MainMem(FL_TIME_ZONE_PAGE+page,1);	
//			MsgPrint(MSG_WARNING,page,"Time Zone Page Deleted:");
			page++;
		 }
//		 MsgPrint(MSG_WARNING,tzno,"Time Zone No Deleted:");
		tzno++;

	 }

*/
}

/* -----------------------------------------------------------------------------*/
/* Add message to message buffer in Flash */
 char AddMessageToFlash(BYTE msgno,BYTE *message)
{
//	unsigned char tempwrbuf[264];
unsigned int msgpageno;
	if(msgno <= MAX_MESSAGE_NO)
	{
		msgpageno = FL_MESSAGE_PAGE_NO + (MESSAGE_BYTES * msgno)/PAGE_SIZE;
// 		sf_pageToRAM(msgpageno);
//   	sf_readRAM((char *)&tempwrbuf, 0, 264);	// Read old messages of same page
		MainMem_ReadPage(msgpageno,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		msgpageno = ((msgno*MESSAGE_BYTES)%PAGE_SIZE);
		memcpy((char *)&tempwrbuf[msgpageno],message,MESSAGE_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
//		sf_writeRAM(tempwrbuf,0,264);
		msgpageno = FL_MESSAGE_PAGE_NO + (MESSAGE_BYTES * msgno)/PAGE_SIZE;
		BuffWrt_MainMem(msgpageno,1);
//   	sf_RAMToPage(msgpageno);
		MsgPrint(MSG_WARNING,msgno,"AddMessageToFlash: msg no =");
		return(0);
	}
	else
		return(1);
}

/* -----------------------------------------------------------------------------*/
/* Add message to message buffer in Flash */

char GetMessageFromFlash(BYTE msgno,BYTE *message)
{
//	unsigned char tempwrbuf[SPIBUFSIZE];
unsigned int msgpageno;
	if(msgno <= MAX_MESSAGE_NO)
	{
		msgpageno = FL_MESSAGE_PAGE_NO + (MESSAGE_BYTES * msgno)/PAGE_SIZE;
		MainMem_ReadPage(msgpageno,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		msgpageno = ((msgno*MESSAGE_BYTES)%(PAGE_SIZE));
		memcpy(message,(char *)&tempwrbuf[msgpageno],MESSAGE_BYTES);
		message[MESSAGE_BYTES] = '\0';		//NG0016
		MsgPrint(MSG_WARNING,msgno,"GetMessageFromFlash: msg no =");
		return(0);
	}
	else
	{
		memset(message,' ',MESSAGE_BYTES);
		message[MESSAGE_BYTES] = '\0';		// NG0016
		return(1);
	}
}

/*----------------------------------------------------------------------*/
void DelAllMessageToFlash(void)
{
unsigned char totalpages,count;

	if( !(InitialiseFlags & DELETE_ALL_MSG_TO_FLASH) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_MSG_TO_FLASH ;

	totalpages = (MAX_MESSAGE_NO*MESSAGE_BYTES)/PAGE_SIZE;
	count = 0;
	memset(tempwrbuf,' ',sizeof(tempwrbuf));
	while(count <= totalpages)
	{
//		printf("Delete Message Page no %d  totalpages %d \n",count,totalpages);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
		BuffWrt_MainMem(FL_MESSAGE_PAGE_NO + count,1);
		count++;
#ifdef ENABLE_WATCHDOG
		if(!(count%100))
		  	WDTFeed();
#endif
	}
}

/*----------------------------------------------------------------------*/
// Following function gets card number from perticular index in card memory
// This function returns total no of cards read to get that index card
// if we give index no as 0xFFFF which is not possible as total noof cards is less than 0xFFFF so it will read memory for
// all programmed card which is nothing but total noof cards
 //needs to check mukund

/*short GetCardByIndexNo2(WORD index,struct CARD_DATA *empcard)
{
	WORD temp1,totalcards;
   DWORD tmpptr;
   temp1 = 0;
   totalcards = 0;
   if(LastCardAddedPtr >  CARD_DATA_MAX )
   	LastCardAddedPtr =CARD_DATA_MAX;
	while(temp1< CARD_DATA_MAX)
	{
   	tmpptr = (CARD_DATA_BASE+(temp1 * CARD_DATA_BYTES));
//      xmem2root( (unsigned char *)empcard,tmpptr,CARD_DATA_BYTES);
   	if(empcard->CardNo!=0)
      {
        	index--;
			totalcards ++;
      }
      if(index == 0)
      	return(0);
		if(LastCardAddedPtr == temp1 )
			return(totalcards);
		temp1++;
	}
	return(totalcards);
}
*/

/*----------------------------------------------------------------------*/

/*short GetCardByLocationNo(WORD loc,struct CARD_DATA *empcard)
{  //needs to check mukund
	DWORD tmpptr;
   if(loc >  MAX_NO_OF_CARD )
   	loc =MAX_NO_OF_CARD;
	tmpptr = (CARD_DATA_BASE+(loc*CARD_DATA_BYTES));
//	tmpptr = (long)((long)CARD_DATA_BASE+(long)((long)loc*(long)CARD_DATA_BYTES));
//	xmem2root( (unsigned char *)empcard,tmpptr,CARD_DATA_BYTES);
 	if(empcard->CardNo!=0)
   	return(0);
   else
   	return(loc);
}
*/

/*----------------------------------------------------------------------*/
/*
char ReadCardNoFromFlash2(WORD cardpos,struct CARD_DATA *empcard)
{
unsigned char tempwrbuf[SPIBUFSIZE];
unsigned int cardpage,pagepos;
 
   cardpage = (cardpos * CARD_DATA_BYTES)/PAGE_SIZE;
   MainMem_ReadPage(FL_CARDDATA_PAGE_NO+cardpage,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
//  	sf_pageToRAM(FL_CARDDATA_PAGE_NO+cardpage);
//   sf_readRAM(tempwrbuf, 0, 256);
	pagepos = ((cardpos* CARD_DATA_BYTES) %PAGE_SIZE );
	if((pagepos + CARD_DATA_BYTES) >PAGE_SIZE)
   {
   	// Read next page
	   MainMem_ReadPage(FL_CARDDATA_PAGE_NO+cardpage+1,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
	 // 	sf_pageToRAM(FL_CARDDATA_PAGE_NO+cardpage+1);
	  // sf_readRAM(&tempwrbuf[256],0,CARD_DATA_BYTES );
   }
   memcpy((unsigned char *) empcard,&tempwrbuf[pagepos],CARD_DATA_BYTES);
//	printf(" ReadCardNoFromFlash cardpos %d pagepos %d Flash Page no %d   \n",cardpage,pagepos,FL_CARDDATA_PAGE_NO+cardpage);
	return(0);
}
*/

/*----------------------------------------------------------------------*/

/*short SearchCardFromFlash2(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard)
{
unsigned int temp1;
//	struct CARD_DATA empcard;
   temp1 = 0;
   if(LastCardAddedPtr >  CARD_DATA_MAX )
   	LastCardAddedPtr =CARD_DATA_MAX;
	while(temp1< CARD_DATA_MAX)
	{
      ReadCardNoFromFlash( temp1,empcard);
   	if(empcard->CardNo==cardno)
         return(temp1);
//		if(LastCardAddedPtr == temp1 )
//			return(CARD_NOT_FOUND);
		temp1++;
	}
	return(CARD_NOT_FOUND);

}*/

//------------------------------------------------------------------------------
// Following function will write Name to Flash we have to give Page index to write same.
/*char AddCardNameToFlash1(WORD cardindex,BYTE *name)
{
//   BYTE tempwrbuf[SPIBUFSIZE];	
   WORD cardnamepno;
   if(cardindex <= MAX_NO_OF_CARD)
   {
   	cardnamepno = FL_CARD_NAME_PAGE_NO + (CARD_NAME_BYTES * cardindex)/PAGE_SIZE;
// 		sf_pageToRAM(cardnamepno);    // Read from Flash memory
//   	sf_readRAM((char *)&tempwrbuf, 0, 264);	// Read name data from FlashRam to ram
		MainMem_ReadPage(cardnamepno,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		cardnamepno = ((cardindex*CARD_NAME_BYTES)%PAGE_SIZE);
		memcpy((char *)&tempwrbuf[cardnamepno],name,CARD_NAME_BYTES);
		MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
//		sf_writeRAM(tempwrbuf,0,264);		// Write data back to FlashRam
		cardnamepno = FL_CARD_NAME_PAGE_NO + (CARD_NAME_BYTES * cardindex)/PAGE_SIZE;
//   	sf_RAMToPage(cardnamepno);
	    BuffWrt_MainMem(cardnamepno,1);
		MsgPrint(MSG_WARNING,cardindex,"AddCardNameToFlash: cardindex  =");
      return(0);
   }
   else
   	return(1);
}*/

/*----------------------------------------------------------------------*/
// Following function will Read Name from  Flash we have to give Page index to read same.
/*
char ReadCardNameFromFlash1(WORD cardindex,BYTE *name)
{
//	BYTE tempwrbuf[SPIBUFSIZE];
   WORD cardnamepno;
   if(cardindex <= MAX_NO_OF_CARD)
   {
   	cardnamepno = FL_CARD_NAME_PAGE_NO + (CARD_NAME_BYTES * cardindex)/PAGE_SIZE;
		MainMem_ReadPage(cardnamepno,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
//   	sf_readRAM((char *)&tempwrbuf, 0, 264);	// Read old messages of same page
		cardnamepno = ((cardindex*CARD_NAME_BYTES)%(PAGE_SIZE));
		memcpy(name,(char *)&tempwrbuf[cardnamepno],CARD_NAME_BYTES);
      name[CARD_NAME_BYTES]='\0';
		MsgPrint(MSG_WARNING,cardindex,"ReadCardNameFromFlash: cardindex =");
      return(0);
   }
   else
   {
   	memset(name,' ',CARD_NAME_BYTES);
      name[CARD_NAME_BYTES]='\0';
   	return(1);
   }
}
*/
/*----------------------------------------------------------------------*/
/*
void DelAllNamesFromFlash1(void)
{
unsigned int maxpages,count,cardnamepno;
unsigned char tempwrbuf[SPIBUFSIZE];
   maxpages =  (CARD_NAME_BYTES * MAX_NO_OF_CARD)/PAGE_SIZE;
   count = 0;
   memset(tempwrbuf,' ',PAGE_SIZE);
//   printf("Del all Flash Names Total name %d, Flash statrt %d, Total Pages %d \n",MAX_NO_OF_CARD,FL_CARD_NAME_PAGE_NO,maxpages);
   while(count<maxpages)
   {
	   memset(tempwrbuf,' ',PAGE_SIZE);
	   MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE );
		cardnamepno = FL_CARD_NAME_PAGE_NO + (CARD_NAME_BYTES * count)/PAGE_SIZE;
	   BuffWrt_MainMem(cardnamepno,1);
		count++;
   }
}*/
/*----------------------------------------------------------------------*/
char InitialiseDefaultSelect(BYTE ini)
{
char i;
	switch(ini)
	{
		case 0: // Delete all data
			TotalNosOfTrans = TransWritePtr = TransReadPtr = 0;
			F_TransCrossOver = CLR;
			InitialiseFlags = 0;
			InitialiseFlags = DELETE_ALL_CARDS | DELETE_ALL_DOORINFO | DELETE_ALL_TIMEZONE | 
							DELETE_ALL_FACILITY_CODE | DELETE_ALL_ADMIN_USER | DELETE_ALL_HOLIDAY |
							DELETE_ALL_INI_DEF_SYSTEM | DELETE_ALL_NAME_FROM_FLASH | DELETE_ALL_MSG_TO_FLASH |
							DELETE_ALL_DEF_READER_INFO | DELETE_ALL_FINGER | DELETE_ALL_SPL_CARD | DELETE_ALL_TIME_ACTION; //ARMF0377
			DelAllCards();
			DelAllCardTemplateInfoFromFlash();  // Delete all Extra card info 
			DelAllDoorInfo();
			DelAllTimeZone();
			DelAllFacilityCode();
			DelAllAdminUser();
			DelAllHoliday();
			IniDefaultSysInfo();		
//			DelAllNamesFromFlash();		
//			DelAllTempletSD();  // Delete Template from SD card 
//			DelAllCardTemplateInfoFromFlash();   // Delete Extra Info Card struct from Flash 
//			DelAllMessageToFlash();			//ARMD0068		
#ifdef DISP_EVENT_MSGS_FROM_FLASH                  //DA00125 This indicates that user will require to re-program messages
			//	InitialiseDisplayErrorMsg();
				for(i=0;i<MAX_ERROR_MSGS;i++)
				AddMessageToFlash(i+ERROR_MESSAGE_BASE,(BYTE *)ERROR_MESSAGE[i]);//make default err msgs dont check junk.
#endif
			WriteDefaultReaderInfo();     
#ifdef BIO_METRIC
			DelAllFingers();
#endif
#ifdef SUPPORT_NSERIES2
			DelAllSplCard();
#endif
			DelAllTimeBasedActions();
			DelAllPhas2Setting();
			break;
		case 1:  //Delete Transaction
			TotalNosOfTrans = TransWritePtr = TransReadPtr = 0;
			F_TransCrossOver = CLR;
			break;
		case 2:  // Delete all 
			InitialiseFlags = DELETE_ALL_CARDS | DELETE_ALL_NAME_FROM_FLASH | DELETE_ALL_MSG_TO_FLASH |
							DELETE_ALL_SPL_CARD ; //ARMF0377
#ifdef ENABLE_WATCHDOG
			WDTFeed();		//Clear watchdog timer
#endif		
			DelAllCards();
#ifdef BIO_METRIC
			DelAllFingers();
#endif		
			DelAllCardTemplateInfoFromFlash();  // Delete all Extra card info 		
//			DelAllNamesFromFlash();
//			DelAllMessageToFlash();			//ARMD0068
//			DelAllTempletSD();
//			DelAllCardTemplateInfoFromFlash();
			#ifdef DISP_EVENT_MSGS_FROM_FLASH                  //DA00125 This indicates that user will require to re-program messages
			for(i=0;i<MAX_ERROR_MSGS;i++)
				AddMessageToFlash(i+ERROR_MESSAGE_BASE,(BYTE *)ERROR_MESSAGE[i]);//make default err msgs dont check junk.
			#endif
			DelAllSplCard();		//281210-2
			break;
		case 3:  // Delete All system parameter
			InitialiseFlags = DELETE_ALL_DOORINFO | DELETE_ALL_TIMEZONE | 
							DELETE_ALL_FACILITY_CODE | DELETE_ALL_ADMIN_USER | DELETE_ALL_HOLIDAY |
							DELETE_ALL_INI_DEF_SYSTEM | DELETE_ALL_DEF_READER_INFO ; //ARMF0377
			WriteDefaultReaderInfo();     
			DelAllDoorInfo();
			DelAllTimeZone();
			DelAllFacilityCode();
			DelAllAdminUser();
			DelAllHoliday();
			IniDefaultSysInfo();
			DelAllPhas2Setting();
			break;
		case 4:  // Delete SystemInfo
			InitialiseFlags = DELETE_ALL_INI_DEF_SYSTEM ; //ARMF0377
			IniDefaultSysInfo();
			break;
		case 5:  // Delete TimeZone
			InitialiseFlags =  DELETE_ALL_TIMEZONE ; //ARMF0377
			DelAllTimeZone();
			break;
		case 6: // Delete Holiday
			InitialiseFlags = DELETE_ALL_HOLIDAY ; //ARMF0377
			DelAllHoliday();
			break;
		case 7: //Delete Facility Code
			InitialiseFlags = DELETE_ALL_FACILITY_CODE ; //ARMF0377
			DelAllFacilityCode();
			break;
		case 8: // Delete Door info
			InitialiseFlags = DELETE_ALL_DOORINFO | DELETE_ALL_DEF_READER_INFO ; //ARMF0377
			DelAllDoorInfo();
			WriteDefaultReaderInfo();     
			break;
		case 9: // Delete all admin user
			InitialiseFlags = DELETE_ALL_ADMIN_USER ; //ARMF0377
			DelAllAdminUser();
			break;
		case 10:
		    if(F_FirmwareUpgrade == 0x00)
		    	StoreCardInTrDBFull(ini,0x01,EVENT_SYSTEM_INI,0,0);
		 //Reset_Handler();
		// {
		//    void (*abc)() = 0;
		//    abc();
		// }
#ifdef ENABLE_WATCHDOG
		   if(F_FirmwareUpgrade == 0x01)
				DisplayBottomStatusIcon(0,"BOOTING NEW F/W",0,0);	 
//		   L_DisplayROMStr("BOOTING NEW F/W ",16,ROW_USER_ENTRY);
		   WDTInit(1); //watchdog initialization for secs
		   while(1) ;
#else
				DisplayBottomStatusIcon(0,"RESTART FAIL",0,0);
//				L_DisplayROMStr(" RESTART FAIL   ",16,ROW_USER_ENTRY);
#endif
		  break;
		case 11:  // Del Just Cards
			InitialiseFlags = DELETE_ALL_CARDS | DELETE_ALL_NAME_FROM_FLASH | DELETE_ALL_SPL_CARD ; //ARMF0377
			DelAllCards();
			DelAllCardTemplateInfoFromFlash();  // Delete all Extra card info 
//			DelAllNamesFromFlash();
//			DelAllTempletSD();
//			DelAllCardTemplateInfoFromFlash();
			DelAllSplCard(); 
			break;
#ifdef BIO_METRIC
		case 12:  // Del All Fingers
			InitialiseFlags = DELETE_ALL_FINGER ; //ARMF0377
			DelAllFingers();
			break;
#endif
      case 13:
			#ifdef DISP_EVENT_MSGS_FROM_FLASH                  //DA00125 This indicates that user will require to re-program messages
			for(i=0;i<MAX_ERROR_MSGS;i++)
	        AddMessageToFlash(i+ERROR_MESSAGE_BASE,(BYTE *)ERROR_MESSAGE[i]);//make default err msgs dont check junk.
			break;		//B4DR4RD200 
#endif
		default:
		InitialiseFlags = 0;
			return(1);
	}
	InitialiseFlags = 0;
    if(F_FirmwareUpgrade == 0x00)
    {
			DisplayBottomStatusIcon(0,"Data Deleted",0,0);
//			L_DisplayROMStr("  Data Deleted  ",16,ROW_USER_ENTRY);
			StoreCardInTrDBFull(ini,0x01,EVENT_SYSTEM_INI,0,0); 
	 }                       
	return(0);
}

/*----------------------------------------------------------------------*/
char DelAllFingers(void)
{
#ifdef BIO_METRIC
BYTE err;

	if( !(InitialiseFlags & DELETE_ALL_FINGER) )	//ARMF0377
		return 0;			
	InitialiseFlags &= ~DELETE_ALL_FINGER ;

	if(F_BIO_COMM == SET)
	{
		CancelBioCommand();
		F_BIO_COMM = CLR;
	}
	ENABLE_BIO_COMM();
	if(DeleteAllBioUserID() != 0)
	{
		DisplayBottomStatusIcon(0,"Finger Del Fail",0,0);
//	   	L_DisplayROMStr("Finger Del Fail ",16,ROW_USER_ENTRY);
		err = 1;
		IdleKeyCounter = MAX_KEY_IDLE_TIME;
		F_KeyIdleTime = CLR;
	}
	else
	{
		DisplayBottomStatusIcon(0,"Fingers Deleted",0,0);
//		L_DisplayROMStr("Fingers Deleted ",16,ROW_USER_ENTRY);
		err = 0;
		IdleKeyCounter = MAX_KEY_IDLE_TIME;
		F_KeyIdleTime = CLR;
	}
	DISABLE_BIO_COMM();
	return(err);
#else
	return(0);
#endif
}


/*----------------------------------------------------------------------*/
BYTE GetCurrentReaderNo(void)
{
	if(SysInfo.ContInOut != 0)
	{
		if(SysInfo.ContInOut <= 2)
			return(SysInfo.ContInOut);
		else if(SysInfo.ContInOut == 3)
			return(InOutReader);
		else if(SysInfo.ContInOut == 4)
			return(InOutReader);
	}
	return(ReaderNo);
}

/*----------------------------------------------------------------------*/
void ManageAutoInOut(void)
{  
BYTE i;
	if(SysInfo.ContInOut > 2)
	{
		if((SysInfo.ContInOut == 4) && (InOutReaderTime == 0))
		{
			for(i=0;i<4;i++)
			{
				if(SysInfo.InOutTimeZone[i] != 0)
				{
					if(Check_TimeZone(SysInfo.InOutTimeZone[i],CWeekDay) == TimeZone_OK)
					{
						InOutReader = (SysInfo.TZInOut[i]==2)?2:1;
						break;
					}
				}
			}
		}
	
#ifdef BIO_METRIC
		if((F_DisplayINOutToggle == SET) && ((DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == USER_IDENTIFY_MODE)))
#else
		if((F_DisplayINOutToggle == SET) && (DisplayMode == MODE_WAIT_FOR_CARD))
#endif
		{
			F_DisplayINOutToggle = CLR;
			InOutReaderTime = 0;
			if(SysInfo.ContInOut == 3)
			{
				InOutReader = 1;
#ifdef EXTENDED_KEYPAD
				LunchODInOut = 0;
#endif
			}
			else if(SysInfo.ContInOut == 4)
			{
				for(i=0;i<4;i++)
				{
					if(SysInfo.InOutTimeZone[i] != 0)
					{
						if(Check_TimeZone(SysInfo.InOutTimeZone[i],CWeekDay) == TimeZone_OK)
						{
							InOutReader = (SysInfo.TZInOut[i]==2)?2:1;
							break;
						}
					}
				}
			}
		}
	}
}
//------------------------------------------------------------------------------//

void UpdateSCDataStructure(struct USER_CARD_INFO *empcard)
{
	if(SysInfo.CardDataSource & CDATA_SOURCE_VALIDITY)
		if((CurrentCard.VDate.tm_mday != 0)&&(CurrentCard.VDate.tm_mon != 0))
			empcard->SearchCard.ExpDT = mktime(&CurrentCard.VDate);
	if(SysInfo.CardDataSource & CDATA_SOURCE_PIN)
		empcard->SearchCard.CardPin = CurrentCard.Pin;
	if(SysInfo.CardDataSource & CDATA_SOURCE_USER_TYPE)
		empcard->SearchCard.Info.CType = CurrentCard.CType;
	if((SysInfo.NameType == NAME_AS_ZICOM_EMP_NO) || (SysInfo.CardDataSource & CDATA_SOURCE_NAME))
    	memcpy((unsigned char *)empcard->UserName,CurrentCard.Name,16);
	else if(CHK_READ_NAME_FROM_FLASH())
    {
		ReadCardNameFromFlash(empcard->SearchCardPtr,(unsigned char *)empcard->UserName);
		if(empcard->UserName[0] == 0xFF)
   			memset((unsigned char*) empcard->UserName,' ',16);
	}

}

int GetUserInfoAndProcess(CARDNO_DATA_STORAGE_TYPE cardno,struct USER_CARD_INFO *empcard,unsigned char inputtype)
{
//unsigned char temp;	
_CExtraInfo  tExtInfo;
struct tm vDate;	
int tdata,Card_Found;//,Xdate;
//struct RectInfo rectinfo;	
extern unsigned char DisplayTempBuffer[50];
unsigned char 	tempdispbuffer[25];

if(ReaderNo == 1)
{	
		ScreenFormatData.CurrentFormat = FORMAT_WELCOME_SCREEN; // to clear data in User Access Mode  if mode is already FORMAT_EVENT_ICON then it will not clear data 
		DisplayFormat(FORMAT_EVENT_ICON);  //for authorised,unauthorised,enter uid,select function
		DrawCenterTextWithBackGround(	USER_LINE1_START_Y0,
				ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
				USER_TITLE_FONTINFO_PTR,
				320,
				(unsigned char*)"User Access",
				ThemeColour[SysInfo.ThemeSelectNo].TimeDateColour);
//			F_authScreenTimerEnable = 1;
//			F_authScreenTimer =5;								
//			IdleKeyCounter	= CLR;	
	
}
	F_Spl_Crd_Dr_open = CLR;
	if(F_TrnxMemFull == SET)//ARMD0346
	{
	    return(-2);	//ARMD0346
	}//if(F_TrnxMemFull == SET)
	DRStruct[ReaderNo-1].FCode = empcard->FCode;
	if(inputtype != INPUT_USER_FROM_FINGER)		  //ARMD0539
	{
	if(CheckFacilityCode(ReaderNo,empcard->FCode) == -1)      //D0042
	   {
			StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)cardno,ReaderNo,EVENT_FACLITY_ERR);
			if(ReaderNo == 1)
			{
				L_DisplayCardNumber(cardno,6,ROW_USER_FUNCTION);
				sprintf((char*)tempdispbuffer,"UID: %s",DisplayTempBuffer);
				L_DisplayROMStr(tempdispbuffer,16,ROW_USER_ENTRY3);			
				MakeSound(SOUND_CARD_NOT_FOUND);
			}
			HandleDisplayErrorMessages(EVENT_FACLITY_ERR);
			F_KeyIdleTime = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;
			MsgPrint(1,DRStruct[ReaderNo-1].FCode,"ERROR Facility Code ..=");
			DRStruct[ReaderNo-1].LastCardNo = cardno;			// D0019
			return(-1);               //D0015
	    }
    }
	memset((unsigned char*) empcard->UserName,' ',16);
   	empcard->InputType = inputtype;
	empcard->SearchCard.CardNo = cardno;
	empcard->SearchCardPtr = 0;
	empcard->SearchCard.CardInfo.Holiday = 0;        //ARMD0089
#ifdef BIO_METRIC                                                       //DA00116
	empcard->SearchCard.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
#else
	empcard->SearchCard.Info.CType = UTYPE_CARD_ONLY_VERIFY;
#endif
	empcard->SearchCard.CardPin = 11111;
	if(CheckLastCardError(cardno,ReaderNo) == EVENT_LAST_CARD_ERROR)      //D0042
	{
		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)cardno,ReaderNo,EVENT_LAST_CARD_ERROR);
		MakeSound(SOUND_CARD_NOT_FOUND);
		HandleDisplayErrorMessages(EVENT_LAST_CARD_ERROR);
		F_KeyIdleTime = CLR;
		IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;
		DRStruct[ReaderNo-1].LastCardNo = cardno;			// D0019
		return(-1);               //D0015
	}
	DRStruct[ReaderNo-1].LastCardNo = cardno;			// D0019
   	if(CHECK_ATT_NOCARD(ReaderNo-1) || (CHECK_ATT_SC_NOCARD(ReaderNo-1) && (empcard->InputType == INPUT_USER_FROM_SMART)))   
	{  // Attendance system no need to check the card locally
	//	MsgPrint(MSG_WARNING,ReaderInfo[ReaderNo-1].CntrolrType,,"Attendance No Card check");
		tdata = 0;
		empcard->SearchCard.CardNo = cardno;
		empcard->SearchCardPtr = 0;					  
		if(CHECK_ATT_NOCARD(ReaderNo-1))
			goto go_ERROR_Card_Access;
	}
	else
	{
		tdata = SearchDisplayCard(cardno,&empcard->SearchCard);
		empcard->SearchCardPtr = tdata;
	}
   	if(tdata != CARD_NOT_FOUND)
   	{
// we can Search Extra card info for NG feature 		
//  what to show in Birth date & to impliment acess date &name
		ReadCardTemplateInfoFromFlash(tdata,&tExtInfo);		
		
		vDate.tm_hour = Datetime.Time.Hour;
		vDate.tm_min = 	Datetime.Time.Min;
		vDate.tm_sec = Datetime.Time.Secs;
		vDate.tm_mday = Datetime.Date.Day;
		vDate.tm_mon = Datetime.Date.Month;
		vDate.tm_year = YEAR_BASE_VALUE + Datetime.Date.Year;
		vDate.tm_wday = 0;
		tExtInfo.AccessDate  = mktime(&vDate);
		if(SysInfo.EnableAccessDate)
			AddCardTemplateInfoToFlash(tdata,&tExtInfo);
		
// 		vDate.tm_hour = 0;
// 		vDate.tm_min = 	0;
// 		vDate.tm_sec = 0;
// 		vDate.tm_mday = Datetime.Date.Day;
// 		vDate.tm_mon = 	Datetime.Date.Month;
// 		vDate.tm_year = YEAR_BASE_VALUE + Datetime.Date.Year;
// 		vDate.tm_wday = 0;
// 		 Xdate = mktime(&vDate);

		if(ReaderNo == 1)
		if((tExtInfo.BirthDate == Datetime.Date.Day) && ((tExtInfo.BirthMonth == Datetime.Date.Month)))
		{
 			L_DisplayROMStr("Happy Birhday :)",16,ROW_USER_ENTRY);								
		}
		Card_Found = EVENT_VALID_CARD;
	   	if((INPUT_USER_FROM_KEYBOARD==inputtype) || (INPUT_USER_FROM_FINGER==inputtype) || (inputtype==INPUT_USER_FROM_WEIGAND)||\
	      	(inputtype==INPUT_USER_FROM_PIN_CARD_WEIGAND) || (inputtype==INPUT_USER_FROM_PIN_PROX))
	   	{
			if(ReaderNo == 1)
			{
			 if(CHK_READ_NAME_FROM_FLASH()==1)
	      	  {
//				ReadCardNameFromFlash(empcard->SearchCardPtr,(unsigned char *)empcard->UserName);
				  
			  	if(tExtInfo.Name[0] == 0xFF)
	   		   		memset((unsigned char*) empcard->UserName,' ',16);
				L_DisplayROMStr((unsigned char*)tExtInfo.Name,16,ROW_USER_ENTRY3);
	          }
	      	empcard->UserName[MESSAGE_BYTES] = '\0';
		   }
		}
    if(inputtype == INPUT_USER_FROM_SMART)  
		{
			UpdateSCDataStructure(empcard);
			if((SysInfo.NameType == NAME_AS_ZICOM_EMP_NO) || (SysInfo.CardDataSource & CDATA_SOURCE_NAME))
			{
				L_BlankDisplay(ROW_USER_FUNCTION);//ARMD0335
				if(ReaderNo == 1)
					L_DisplayROMStr((unsigned char*)empcard->UserName,16,ROW_USER_ENTRY3);
			}
		}
		if(CHECK_ATT_CARD_ONLY(ReaderNo-1) || CHECK_ATT_SC_NOCARD(ReaderNo-1))
	   	{  // Attendance system no need to Time zone and other parameters
				tdata = 0;
				MsgPrint(MSG_WARNING,ReaderInfo[ReaderNo-1].CntrolrType,"Attendance No TZ/Ho/APB Check");
	   	}
	   	else
		{
			tdata = VerifyCardData(empcard->SearchCard,ReaderNo,CWeekDay);
			if(tdata != 0)
				goto GOTO_ERROR_CARD_ERROR;
		}
   	}
  	else
   	{
   		Card_Found = tdata = EVENT_CARD_NOT_FOUND;
#ifdef SUPPORT_NSERIES2
	    F_DuelUserAuth = CLR;        //281210-4 //Clear Duel User Auth DUA
	   	DuelUserCounter = 0;        //DUA Reset counter
#endif
       	if((SysInfo.SelAccessType) == 0x01) //ARMD0315 
        	AccessType = 0;

   	if(inputtype == INPUT_USER_FROM_SMART)  
		{
			UpdateSCDataStructure(empcard);
			if((SysInfo.NameType == NAME_AS_ZICOM_EMP_NO) || (SysInfo.CardDataSource & CDATA_SOURCE_NAME))
			{
				L_BlankDisplay(ROW_USER_FUNCTION);//ARMD0335
				if(ReaderNo == 1)
				  L_DisplayROMStr((unsigned char*)empcard->UserName,16,ROW_USER_ENTRY3);
			}
		}
   	}
go_ERROR_Card_Access:
	empcard->Status = 1;
	if(CHECK_DENY_LIST(ReaderNo-1) && (tdata == EVENT_CARD_NOT_FOUND))
	{
		tdata = 0;
	}
//================================
/* IN THIS CASE WE WILL RESET dmz TIMER FOR ANY VALID CARD AND DO NOT GENERATE TRANSACTION */
	if((Doorinfo.EnDisDeadManZone == 2) &&(ReaderInfo[ReaderNo-1].DeadManZoneEnDis == SET))	   //ARMF2003N
	{
		GlobalDMZReset(ReaderNo);
	}
//--------------------------------
// Process special Card and act                    //FA00130
	if(CHECK_ATT_NOCARD(ReaderNo-1))	//ARMF0276 
	{  // Attendance system but special card need to check
		tdata = SearchDisplayCard(cardno,&empcard->SearchCard);
		empcard->SearchCardPtr = tdata;
		tdata = 0;
		empcard->SearchCard.CardNo = cardno;
		empcard->SearchCardPtr = 0;
	}
	if(empcard->SearchCard.CardInfo.Holiday & CARD_BIT_SPECIAL_CARD)
	{
		//to support old spl escort card which was done for Phase 1 and no need to have special card buffer
//		if(empcard->SearchCard.CardInfo.APB & SP_CARD_APB_ESCORT_TYPE)   //to support old spl escort card
//		{
//			ProcessEscortCard(ReaderNo);
//			SpecialCardData.CardType = SP_CARD_APB_ESCORT_TYPE;	//ARMD0259 
//			tdata = EVENT_ESCORT_CARD ;
//		}
#ifdef SUPPORT_NSERIES2
//		else
			tdata = ProcessSpecialCard(empcard->SearchCard.CardNo,ReaderNo);
#endif
		goto GOTO_SPECIAL_CARD_PROCESSED;
		// PANKAJ : I feel we should jump to bottom as it may cause issues in other modes..
	}
#ifdef SUPPORT_NSERIES2
	else if(empcard->SearchCard.CardInfo.Holiday & CHECK_FIRST_IN_USER_FOR_THIS_CRD )
	{
    	tdata = Check1stInUseCard(empcard->SearchCard.Info.Group,Card_Found);
		if(tdata == EVENT_FIRST_INCARD_NOT_FOUND)
			goto GOTO_ERROR_CARD_ERROR;			// User unauthorised
	}
//========================================DUA 1st user check===================================	//281210-4

	if((tdata == 0)&&(Doorinfo.DuelUserAuth == 1))		// we should check dual auth only if all above conditions are properly meet
	{	
		tdata = CheckDualUser(empcard->SearchCard.CardNo,empcard->SearchCard.Info.MesgInfo);
		if(tdata == EVENT_DUEL_USER_2)
			goto GOTO_ERROR_CARD_ERROR;
	}
//========================================DIS===================================	//281210-1

// For Biometric system Door interloc is not required
   /*if((Doorinfo.DoorInterlock == 1) && ((empcard->SearchCard.CardInfo.Holiday & CARD_BIT_SPECIAL_CARD) == 0))
   {
      temp = DoorInterlockCheck(ReaderNo - 1);                 // reader number starts from 1 and door no starts from 0
      if(temp != 0)
      	tdata = EVENT_DOOR_INTER_LOCK;
   }*/

   	if((InEmpCount >= (Doorinfo.OccupancyCount)) && (ReaderNo == 1) && (Doorinfo.EnDisEmpInDispCount != 0))	//281210-3
   		tdata = EVENT_OCCUPANCY_FULL;				//OFULL check
#endif
GOTO_SPECIAL_CARD_PROCESSED:
	if(tdata != 0)
   	{
GOTO_ERROR_CARD_ERROR:
    	if(((tdata == EVENT_DUEL_USER_2) || (EVENT_OCCUPANCY_FULL == tdata) || (EVENT_FACLITY_ERR == tdata) || (EVENT_CARD_NOT_FOUND == tdata) || (EVENT_DUEL_USER_ACCESS_FAIL == tdata)) && (empcard->InputType != INPUT_USER_FROM_SMART))	//281210-2
      	{
	  		if( !(CHK_NAME_DISPLAY()) )//ARMD0341
	     	{
//	      		L_BlankDisplay(ROW_USER_FUNCTION);
#ifndef SUPPORT_SEVEN_BYTE_CARD_NO
				if(ReaderNo == 1)		
				{
						L_DisplayCardNumber(cardno,6,ROW_USER_FUNCTION);
						sprintf((char*)tempdispbuffer,"UID: %s",DisplayTempBuffer);
						L_DisplayROMStr(tempdispbuffer,16,ROW_USER_ENTRY3);// 						L_DisplayCardNumber(cardno,6,ROW_USER_FUNCTION);			
// 						strcpy((char*)CardDispaly,(char*)DisplayTempBuffer);
// 						sprintf((char*)DisplayTempBuffer,"UID: %lu",CardDispaly);
// 						L_DisplayROMStr(DisplayTempBuffer,16,ROW_USER_ENTRY3);					
				}	
#else
				L_DisplaySevenByteCardNo(ReaderData[ReaderNo-1].WeigandExData,ReaderData[ReaderNo-1].WeigandData,0,ROW_USER_FUNCTION); //Mandar
#endif
          	}//if( !(CHK_NAME_DISPLAY()) )
       	}//if(((tdata == EVENT_DUEL_USER_2) ||
      	else if(CHK_NAME_DISPLAY())
	   	{
				if(ReaderNo == 1)
				{
					L_BlankDisplay(ROW_USER_FUNCTION);
//	     		 	L_DisplayROMStr((unsigned char*)empcard->UserName,16,ROW_USER_FUNCTION);
					L_DisplayROMStr((unsigned char*)empcard->UserName,16,ROW_USER_ENTRY3);
				}
	   	}
	   	else
	   	{
//	      	L_BlankDisplay(ROW_USER_FUNCTION);
//	      	L_DisplayROMStr("UID:        ",16,ROW_USER_FUNCTION);
				if(ReaderNo == 1)
				{
						L_DisplayCardNumber(cardno,6,ROW_USER_FUNCTION);
						sprintf((char*)tempdispbuffer,"UID: %s",DisplayTempBuffer);
						L_DisplayROMStr(tempdispbuffer,16,ROW_USER_ENTRY3);
// 						L_DisplayCardNumber(cardno,6,ROW_USER_FUNCTION);				
// 						sprintf((char*)CardDispaly,"UID: %lu",DisplayTempBuffer)	;
// 						L_DisplayROMStr(CardDispaly,16,ROW_USER_ENTRY3);
				}
	   	}
		MsgPrint(MSG_WARNING,tdata,"Invalid Access returncode=");
	   	StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)cardno,ReaderNo,tdata);
//      if((Doorinfo.EnDisEMPNoTrnx == 1) && ((CurrentUser.InputType == INPUT_USER_FROM_SMART) || (CurrentUser.InputType == INPUT_USER_FROM_SMART_FINGER)))	//shree 12June
// change this prasoon			StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentCard.EMP_NO,ReaderNo,EVENT_EMPNO_TRNX);	//shree 12June
      	if((Doorinfo.BeepEnable & INVALID_CARD_BEEP_ON) == 0x01) //A00017
      	{
      		//MakeSound(SOUND_CARD_NOT_FOUND);
			//	MakeWeigandBuzON(ReaderNo,SOUND_CARD_NOT_FOUND); 		//A00010
      	}
//		if(ReaderNo == 1)		
		HandleDisplayErrorMessages(tdata);
			
		F_KeyIdleTime = CLR;
		IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
//        DisplayMode = MODE_WAIT_FOR_CARD;	//NGD00140
		memset(UserName,'*',sizeof(UserName));
		
		if( tdata == EVENT_DMZ_RESET_CARD)//ARMD0342
	   	if( F_Spl_Crd_Dr_open == DOOR_OPEN_BY_DMZ_CARD )
		{
			return(0);
		}//if( F_Spl_Crd_Dr_open == DOOR_OPEN_BY_DMZ_CARD )
		
//SHIVRAJ DUA CHK 
	
/*		 #ifdef SUPPORT_NSERIES2//use this for asking finger of first user in card+finger mode 
			 if((tdata == EVENT_DUEL_USER_2) &&(Doorinfo.DuelUserAuth == 1) && (F_DuelUserAuth == SET) && (Doorinfo.AnyDualFinger==1))
			 	return(0);//verify first user finger exists or not.
		 #endif  */
      return(tdata);
	}
	return(0);
}
//=================================================================================================
int FinalAccessGranted(struct USER_CARD_INFO *empcard,char chno)
{
unsigned char temp;     
	 if((F_DuelUserAuth == CLR) && (Doorinfo.DuelUserAuth == 1))     //281210-4 // DUA Access //ARMF2008
	 {
     	DuelUserCounter = 0; //ARMD0325
	 }
#ifdef WEIGAND_OUT_READER
		SendWeigandData(empcard,WCount);	
//	MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo/0x10000,"xSend Access on Weigend C MSB");
//	MsgPrint(MSG_WARNING,(CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo&0xFFFF,"xSend Access on Weigend C MSB");
	if(SysInfo.ContInOut == 5)
	{
//		L_DisplayROMStr("Verifying Access",16,2);
		if(ReaderNo == 1)
		L_DisplayROMStr("Verifying Access",16,ROW_USER_ENTRY);	
		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_VALID_CARD);
		if(ReaderInfo[0].DOpTime < MAX_FINGER_POLL_TIME_OUT )	//ARMF0388  
		{
			PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - ReaderInfo[0].DOpTime;
		}
		else
			PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 5;
	
		goto GOTO_ERROR_CHK_WEIGAND_OUT; 
	}
#endif
 	if(CheckDoNotDisturb(empcard->SearchCard.CardNo,chno) == SET)		 // This can be moved to Process Card
  		return 0;
	MsgPrint(MSG_WARNING,EVENT_VALID_CARD,"Valid User Access =");
	if((Doorinfo.BeepEnable & VALID_CARD_BEEP_ON) == 0x02)//A00017
   	{
  		 MakeSound(SOUND_CARD_FOUND);
   	}
#ifdef BIO_METRIC
	if((CHECK_ATT_NOCARD(chno) == 0) || (!(CHECK_ATT_SC_NOCARD(chno) && (empcard->InputType == INPUT_USER_FROM_SMART))))
#else
	if(CHECK_ATT_NOCARD(chno) == 0)
#endif
   	{
	   	if(HandleAPBSetting(chno,empcard->SearchCardPtr,empcard->SearchCard) != APB_Err || F_Spl_Crd_Dr_open == SET)
	   	{
GOTO_ALLOW_ACCESS_FOR_SOFT_APB:
#ifdef SUPPORT_NSERIES2
			if((F_DuelUserAuth == CLR) && (Doorinfo.DuelUserAuth == 1))     //281210-4 // DUA Access //ARMF2008
			{
	        	DoorOpenForTime(chno+1);
				//DuelUserCounter = 0; //ARMD0325
			}
	        else if(Doorinfo.DuelUserAuth == 0)
	#endif
		        temp = DoorOpenForTime(chno+1);				  //DOOR OPENS HERE
				if(temp == EVENT_DR_PC_USER_CLOSE)
				{
					HandleDisplayErrorMessages(EVENT_DR_PC_USER_CLOSE);
					return(EVENT_DR_PC_USER_CLOSE);
				}
	//			DoorConditionControl(1,DR_NORMAL,1,1);  
		    if((AccessType == 0) || (SysInfo.SelAccessType == 0))
			{
	#ifdef EXTENDED_KEYPAD
					if(LunchODInOut == 1)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_IN);
					else if(LunchODInOut == 2)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_OUT);
					else if(LunchODInOut == 3)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_IN);
					else if(LunchODInOut == 4)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_OUT);
					else
	#endif
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_VALID_CARD);
			}
			else
	        {
	            if((AccessType >= 1) && (AccessType <= 6))
	               StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_DIFFERENT_ACCESS_1+(AccessType-1));
	            else
				{
#ifdef EXTENDED_KEYPAD
					if(LunchODInOut == 1)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_IN);
					else if(LunchODInOut == 2)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_OUT);
					else if(LunchODInOut == 3)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_IN);
					else if(LunchODInOut == 4)
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_OUT);
					else
#endif
		        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_VALID_CARD);
				}
	        }
	#ifdef SUPPORT_NSERIES2
			 IncDecInEmpCount(chno+1);
	#endif
	#ifdef SUPPORT_7SEG_DISPLAY                        //A00014
         if(Doorinfo.EnDisEmpInDispCount & 0x01)
            SendINOUTCountToDisplay(InEmpCount,EMP_DISPLAY_PORT);
    #endif
			if(F_Spl_Crd_Dr_open == CLR)//ARMD0342
//			if(ReaderNo == 1)		// NGARM01
				HandleDisplayErrorMessages(EVENT_VALID_CARD);
		//	MakeSound(SOUND_CARD_FOUND);
//			MakeWeigandBuzON(ReaderNo,SOUND_CARD_FOUND); 		//A00010
	    	AccessType = 0;
			F_Spl_Crd_Dr_open = CLR;
	   	}
		else
	   	{
	     	StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,APB_Err);
         	if((Doorinfo.APBEANABLE & BIT_APB_CHK) && (Doorinfo.APBEANABLE & BIT_SOFT_APB_CHK))			//If Soft APB is Enabled then open door
         		goto GOTO_ALLOW_ACCESS_FOR_SOFT_APB;
			if(F_Spl_Crd_Dr_open == CLR)//ARMD0342
					HandleDisplayErrorMessages(APB_Err);
				if(chno == 0)		// NGARM01
				{
				
#ifdef SUPPORT_SPEECHIC
					PlaySoundMsg(APB_ERROR);
#endif			
				}					
	   		MakeSound(SOUND_CARD_NOT_FOUND);
//			MakeWeigandBuzON(ReaderNo,SOUND_CARD_NOT_FOUND); 		//A00010
	   	}
   	}
   else
   {
#ifdef SUPPORT_NSERIES2
      if((F_DuelUserAuth == CLR) && (Doorinfo.DuelUserAuth == 1))     //281210-4 // DUA Access
	      DoorOpenForTime(chno+1);
      else if(Doorinfo.DuelUserAuth == 0)
#endif
        DoorOpenForTime(chno+1);
        if((AccessType == 0) || (SysInfo.SelAccessType == 0))
		{
#ifdef EXTENDED_KEYPAD
			if(LunchODInOut == 1)
        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_IN);
			else if(LunchODInOut == 2)
        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_OUT);
			else if(LunchODInOut == 3)
        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_IN);
			else if(LunchODInOut == 4)
        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_OUT);
			else
#endif
        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_VALID_CARD);
		}
        else
        {
            if((AccessType >= 1) && (AccessType <= 6))
               StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_DIFFERENT_ACCESS_1+(AccessType-1));
            else
			{
#ifdef EXTENDED_KEYPAD
				if(LunchODInOut == 1)
	        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_IN);
				else if(LunchODInOut == 2)
	        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_LUNCH_OUT);
				else if(LunchODInOut == 3)
	        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_IN);
				else if(LunchODInOut == 4)
	        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_OD_OUT);
				else
#endif
	        		StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)empcard->SearchCard.CardNo,chno+1,EVENT_VALID_CARD);
			}
        }
		#ifdef SUPPORT_NSERIES2
		IncDecInEmpCount(chno+1);
		#endif
		#ifdef SUPPORT_7SEG_DISPLAY                        //A00014
         if(Doorinfo.EnDisEmpInDispCount & 0x01)
            SendINOUTCountToDisplay(InEmpCount,EMP_DISPLAY_PORT);
        #endif
		if(F_Spl_Crd_Dr_open == CLR)//ARMD0342
//		if(ReaderNo == 1)		// NGARM01
			HandleDisplayErrorMessages(EVENT_VALID_CARD);
		MakeSound(SOUND_CARD_FOUND);
//		MakeWeigandBuzON(ReaderNo,SOUND_CARD_FOUND); 		//A00010
        AccessType = 0;
		F_Spl_Crd_Dr_open = CLR;
	}

//#ifdef BIO_METRIC			 //ARMD0333	   dont uncomment this.
	if(CHECK_ATT_NOCARD(chno) || (CHECK_ATT_SC_NOCARD(chno) && (empcard->InputType == INPUT_USER_FROM_SMART)))
	{
		UserMessage = 0;
		F_UserMessageDisplay = 0;
	}
	else
	{
		if(SysInfo.EnDisUserMsg != 0)
		{
			UserMessage = empcard->SearchCard.Info.MesgInfo;
			F_UserMessageDisplay = SET;
		}
		else
		{
			UserMessage = 0;
			F_UserMessageDisplay = CLR;
		}
	}
#ifdef BIO_METRIC			 
	if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
	{
  		DISABLE_BIO_COMM();   	//A00012
		if(F_BIO_COMM == CLR)
			PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 1;	// earlier it was -3
	}
	FingerRechkCount = 0;		//A00006
#endif//#ifdef BIO_METRIC			
#ifdef WEIGAND_OUT_READER	//ARMD0356
GOTO_ERROR_CHK_WEIGAND_OUT:
#endif
	F_KeyIdleTime = CLR;
	IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
	if(chno != 1)	// NGD40
	{	
		DisplayMode = MODE_WAIT_FOR_CARD;
		DisplaySubMode = 0;
	}
	memset(UserName,'*',sizeof(UserName));
	if(SysInfo.ContInOut > 2)
		F_DisplayINOutToggle = SET;		// Just to make inout to normal mode i.e. to remove from bypass inout mode...
	return(0);
}
//=================================================================================================
// This functional is implemented to take care of Server type authentication after all processing is done
// We have implemented function called FinalAccessGranted which has old code of  UserAccessGranted

//=================================================================================================
int UserAccessGranted(struct USER_CARD_INFO *empcard)
{	 
	
	if(SysInfo.ServerAuthType != 0)
	{
#ifdef BIO_METRIC			 
		if((DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == USER_IDENTIFY_MODE)||(DisplayMode == USER_VERIFY_MODE))
#else
		if(DisplayMode == MODE_WAIT_FOR_CARD)
#endif
		{
	#ifdef BIO_METRIC			 
			if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
			{
		  		DISABLE_BIO_COMM();   	
				if(F_BIO_COMM == CLR)
					PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 6;	
			}
			FingerRechkCount = 0;		
	#endif	
			F_KeyIdleTime = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
			L_DisplayRAMStr("Verifying Server   ",16,ROW_CARD_ERROR_DISP);
		}
		SendMessageToServer(empcard,ReaderNo-1,EVENT_VALID_CARD);	//ARMF2004
	}
	else
		return(FinalAccessGranted(empcard,ReaderNo-1));
	return(0);

}

//=================================================================================================
/*** BeginHeader ValidateTZ*/             //F0010 old Timezone check logic
unsigned char ValidateTZ(struct TIME_ZONE_STR *tzstend);
/*** EndHeader */
unsigned char ValidateTZ(struct TIME_ZONE_STR *tzstend)
{
   if(Datetime.Time.Hour > tzstend->StarHours)
   {
    if(Datetime.Time.Hour < tzstend->EndHours)
       return(TimeZone_OK);
    if(Datetime.Time.Hour == tzstend->EndHours)
       if(Datetime.Time.Min <= tzstend->EndMin)
          return(TimeZone_OK);
   }
   else if(Datetime.Time.Hour == tzstend->StarHours)
   {
      // Modification to take care of bug where end hrs is same as start hrs
      if(Datetime.Time.Min >= tzstend->StarMin)
      {
         if(Datetime.Time.Hour == tzstend->EndHours)
         {
            if(Datetime.Time.Min <= tzstend->EndMin)
               return(TimeZone_OK);
            else
               return(EVENT_TimeZone_Err);
         }
         else
            return(TimeZone_OK);
      }
   }
   return(EVENT_TimeZone_Err);
}

/*** BeginHeader ValidateTZCrossover*/        //F0010 added to support night shift TZ
unsigned char ValidateTZCrossover(struct TIME_ZONE_STR tzstend);
/*** EndHeader */
unsigned char ValidateTZCrossover(struct TIME_ZONE_STR tzstend)
{
   if((Datetime.Time.Hour <= tzstend.EndHours) && (Datetime.Time.Hour >= 0))
   {
      if(Datetime.Time.Hour == tzstend.EndHours)
      {
         if((Datetime.Time.Min <= tzstend.EndMin) && (Datetime.Time.Min >= 0))
            return(TimeZone_OK);
         else if((Datetime.Time.Min > tzstend.EndMin) && (Datetime.Time.Min >= 0))
         {
	         if((Datetime.Time.Hour > tzstend.StarHours) && (Datetime.Time.Hour <= 23))
	            return(TimeZone_OK);
	         else if((Datetime.Time.Hour == tzstend.StarHours) && (Datetime.Time.Hour <= 23))
	         {
	            if((Datetime.Time.Min >= tzstend.StarMin) && (Datetime.Time.Min <= 59))
	               return(TimeZone_OK);
	            else
	               return(EVENT_TimeZone_Err);
	         }
	         else
	            return(EVENT_TimeZone_Err);
			}
      }
      else
         return(TimeZone_OK);
	}
   else if((Datetime.Time.Hour > tzstend.EndHours) && (Datetime.Time.Hour >= 0))
	{
		if((Datetime.Time.Hour > tzstend.StarHours) && (Datetime.Time.Hour <= 23))
	   	return(TimeZone_OK);
		else if((Datetime.Time.Hour == tzstend.StarHours) && (Datetime.Time.Hour <= 23))
      {
         if((Datetime.Time.Min >= tzstend.StarMin) && (Datetime.Time.Min <= 59))
            return(TimeZone_OK);
         else
            return(EVENT_TimeZone_Err);
      }
      else
         return(EVENT_TimeZone_Err);
   }
   return(TimeZone_OK);
}

#ifdef DISP_EVENT_MSGS_FROM_FLASH
/*** BeginHeader InitialiseDisplayErrorMsg*/
void InitialiseDisplayErrorMsg(void);
/*** EndHeader */
void InitialiseDisplayErrorMsg(void)
{
unsigned char i, dispstr[16];
   GetMessageFromFlash(ERROR_MESSAGE_BASE+1,dispstr);    //Check for Access granted message
// If Event data from Flash is junk we will write default event data in flash
   if(((dispstr[0] >= 0x20) && (dispstr[0] < 0x7F)) && ((dispstr[1] >= 0x20) && (dispstr[1] < 0x7F)))
   	return;
   else
   {
	   for(i=0;i<MAX_ERROR_MSGS;i++)
	      AddMessageToFlash(i+ERROR_MESSAGE_BASE,(BYTE *)ERROR_MESSAGE[i]);
   }
}
#endif

/*----------------------------------------------------------------------*/
/*
Following all functions are for admin users
*/
/*** BeginHeader AddNewAdminUser*/
int AddNewAdminUser(struct ADMIN_INFO admcard);
/*** EndHeader */
int AddNewAdminUser(struct ADMIN_INFO admcard)
{
int temp;
	MsgPrint(MSG_WARNING,admcard.AdmData.CardNo,"AddAdminCUser:Card No is=");
	temp = SearchNewAdminUser(admcard.AdmData.CardNo);
  	if(temp == CARD_NOT_FOUND)
	{
		temp = SearchNewAdminUser(0);
		if(temp >= MAX_ADMIN_USER_NEW)
		{
			temp = SearchNewAdminUser(0xFFFF);
			if(temp >= MAX_ADMIN_USER_NEW)
			{
				MsgPrint(MSG_WARNING,temp,"AddAdminUser:No mem for card add ptr=");
				return(-1);
			}
		}
		MsgPrint(MSG_WARNING,temp,"AddAdminUser:New card to be added ptr=");
	}
	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);	
	memcpy(&tempwrbuf[temp*ADMIN_DATA_BYTES_NEW],&admcard,ADMIN_DATA_BYTES_NEW);
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1); 
	return(temp);
}


/*----------------------------------------------------------------------*/
/*** BeginHeader SearchNewAdminUser*/
int SearchNewAdminUser(CARDNO_DATA_STORAGE_TYPE cardno);
/*** EndHeader */
int SearchNewAdminUser(CARDNO_DATA_STORAGE_TYPE cardno)
{
unsigned int  temp;
struct ADMIN_INFO admcard;
	temp = 0;
	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
	while(temp < MAX_ADMIN_USER_NEW)
	{
//      xmem2root((BYTE*)&empcard,(BYTE* )&tempwrbuf +(temp*ADMIN_DATA_BYTES),ADMIN_DATA_BYTES);
		memcpy((BYTE*)&admcard,(BYTE* )&tempwrbuf +(temp*ADMIN_DATA_BYTES_NEW),ADMIN_DATA_BYTES_NEW);
		if(admcard.AdmData.CardNo == cardno)
			return(temp);
		temp++;
    }
    return(CARD_NOT_FOUND);
}

/*----------------------------------------------------------------------*/
/*** BeginHeader SearchNewDisplayAdminUser*/
int SearchNewDisplayAdminUser(CARDNO_DATA_STORAGE_TYPE cardno,struct ADMIN_INFO *admcard);
/*** EndHeader */
int SearchNewDisplayAdminUser(CARDNO_DATA_STORAGE_TYPE cardno,struct ADMIN_INFO *admcard)
{
int temp;
	temp = SearchNewAdminUser(cardno);
	if(temp == CARD_NOT_FOUND)
	{
		MsgPrint(MSG_WARNING,temp,"SearchNewDisplayAdminUser:Card not found ptr=");
		return(CARD_NOT_FOUND);
	}
	else
	{
		MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
     	memcpy((BYTE *)admcard,(BYTE* )&tempwrbuf + (temp*ADMIN_DATA_BYTES_NEW),ADMIN_DATA_BYTES_NEW);
     	MsgPrint(MSG_WARNING,temp,"SearchNewDisplayAdminUser:Card found ptr=");
	}
	return(temp);
}

/*** BeginHeader GetAdminUserByLoc*/
int GetAdminUserByLoc(short loc,struct ADMIN_INFO *admcard);
/*** EndHeader */
int GetAdminUserByLoc(short loc,struct ADMIN_INFO *admcard)
{	
	if(loc>MAX_ADMIN_USER_NEW)
		return(-1);
	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
    memcpy((BYTE *)admcard,(BYTE* )&tempwrbuf + (loc*ADMIN_DATA_BYTES_NEW),ADMIN_DATA_BYTES_NEW);
	MsgPrint(MSG_WARNING,loc,"SearchNewDisplayAdminUser:Card found ptr=");

	return(loc);
}

/*----------------------------------------------------------------------*/
/*** BeginHeader DelNewAdminUser*/
int DelNewAdminUser(struct ADMIN_INFO admcard);
/*** EndHeader */
int DelNewAdminUser(struct ADMIN_INFO admcard)
{
int temp;
  	temp = SearchNewAdminUser(admcard.AdmData.CardNo);
	if(temp == CARD_NOT_FOUND)
	{
		MsgPrint(MSG_WARNING,temp,"DelAdminUser:Card Not found");
	 	return(CARD_NOT_FOUND);
	}
	else
	{
      admcard.AdminType = 0x0;
      admcard.DownloadID = 0x0;
      admcard.AdmData.CardNo = 0x0;
      admcard.AdmData.CardInfo.APB = 0x0;
      admcard.AdmData.CardInfo.Door1 = 0x0;
      admcard.AdmData.CardInfo.Door2 = 0x0;
      admcard.AdmData.CardInfo.Holiday = 0x0;
#ifdef ENABLE_PIN
      admcard.AdmData.CardPin = 0x0;
#endif
      admcard.AdmData.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
      admcard.AdmData.Info.BirthMonth = 0;
      admcard.AdmData.Info.BirthDate = 0;
#endif
#ifdef EN_CARD_EXP_DATE
      admcard.AdmData.ExpDT = 0x0;
#endif
	   	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		memcpy(&tempwrbuf[temp*ADMIN_DATA_BYTES_NEW],&admcard,ADMIN_DATA_BYTES_NEW);
		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    	BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1); 
	    MsgPrint(MSG_WARNING,temp,"DelAdminUser:Card Deleted");
	}
	return(temp);
}

/*----------------------------------------------------------------------*/
/*** BeginHeader DelNewAdminUserByLocation*/
int DelNewAdminUserByLocation(int location);
/*** EndHeader */
int DelNewAdminUserByLocation(int location)
{
struct ADMIN_INFO admcard;
	if(location <= MAX_ADMIN_USER_NEW)
	{
      admcard.AdminType = 0x0;
      admcard.DownloadID = 0x0;
      admcard.AdmData.CardNo = 0x0;
      admcard.AdmData.CardInfo.APB = 0x0;
      admcard.AdmData.CardInfo.Door1 = 0x0;
      admcard.AdmData.CardInfo.Door2 = 0x0;
      admcard.AdmData.CardInfo.Holiday = 0x0;
#ifdef ENABLE_PIN
      admcard.AdmData.CardPin = 0x0;
#endif
      admcard.AdmData.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
      admcard.AdmData.Info.BirthMonth = 0;
      admcard.AdmData.Info.BirthDate = 0;
#endif
#ifdef EN_CARD_EXP_DATE
      admcard.AdmData.ExpDT = 0x0;
#endif
	   	MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
		memcpy(&tempwrbuf[location*ADMIN_DATA_BYTES_NEW],&admcard,ADMIN_DATA_BYTES_NEW);
		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,SPIBUFSIZE);
    	BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1); 
		MsgPrint(MSG_WARNING,location,"DelAdminUserLocation:Card Deleted");
	    return(location);
	}
	else
		return(-1);
}

/*----------------------------------------------------------------------*/
void DelAllAdminUser(void)
{  
unsigned char location;
struct ADMIN_INFO admcard;

	if( !(InitialiseFlags & DELETE_ALL_ADMIN_USER) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_ADMIN_USER;

	for(location = 0;location <=MAX_ADMIN_USER_NEW;location++)
	{
     	admcard.AdminType = 0x0;			//ARMD0261
      	admcard.DownloadID = 0x0;
    	admcard.AdmData.CardNo = 0x0;
		admcard.AdmData.CardInfo.APB = 0x0 ;
        admcard.AdmData.CardInfo.Door1 = 0x0 ;
        admcard.AdmData.CardInfo.Door2 = 0x0 ;
        admcard.AdmData.CardInfo.Holiday = 0x0 ;
		admcard.AdmData.CardPin = 0x0;
		admcard.AdmData.Info.MesgInfo = 0;
#ifndef NEW_CARD_FORMAT
        admcard.Info.BirthMonth = 0;
        admcard.Info.BirthDate = 0;
#endif
#ifdef EN_CARD_EXP_DATE
      	admcard.AdmData.ExpDT = 0x0;
#endif
		memcpy (&tempwrbuf[location *ADMIN_DATA_BYTES_NEW], (char *)&admcard, ADMIN_DATA_BYTES_NEW);	//ARMD0261
	}
	MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
	BuffWrt_MainMem(FL_ADMIN_DATA_PAGE,1);	
	admcard.AdmData.CardNo = 11111;  
	if( SearchNewDisplayAdminUser(admcard.AdmData.CardNo,&admcard) == CARD_NOT_FOUND)	  
	{
		admcard.AdmData.CardNo = 11111;
	    admcard.AdmData.CardPin = 12345;
      	admcard.AdmData.Info.CType = 0x0A;    //UID + PIN								  //ARMD0261
      	admcard.AdminType = BIT_SUPER_ADMIN;      //Added default admin as super Admin	  //ARMD0261
	    AddNewAdminUser(admcard);
	}
}
/***************** Start of TIME BASED ACTIONS ***********************/
/*** BeginHeader TimeBasedActions*/
void TimeBasedActions(void);
//$1ln,1,ActionNo,ActionType,ActionData,StHr,StMin,EndHr,
//EndMin,Date,Month,Year,Dummy1,Dummy2,Dummy3,Dummy4,chksum,enter
/*** EndHeader */
void TimeBasedActions(void)	//ARMF0252
{
unsigned int block,pageno,startpage,i;
unsigned char temp;
WORD CurrentTime=0,StartTime=0,EndTime=0;
struct CARD_DATA empcard;
//=(TIME_BASED_ACTION (*pTimeBasedAction)[])buff;	//ARMF0317

	ReadTimeBasedAction(pTimeBasedAction);//ARMF0317
	for(temp=0;temp<MAX_TIME_BASED_ACTIONS;temp++) //Check for all structures
	{
		if( (*pTimeBasedAction)[temp].ActionType != 0 )
		{
			// This will create problem as if date moves from 31 to 1 we will not generate any actions.
			//Simple method is to check if day is not matching or check full dat, month and year
//			if(Datetime.Date.Day != TimeBasedAction[temp].ActionCompleteDate.Day)
			if( (*pTimeBasedAction)[temp].ActionCompleteDate.Year <= Datetime.Date.Year &&
				(*pTimeBasedAction)[temp].ActionCompleteDate.Month <= Datetime.Date.Month &&
				(*pTimeBasedAction)[temp].ActionCompleteDate.Day < Datetime.Date.Day     )
			{
				//this change is for proper comparision of time
				CurrentTime = Datetime.Time.Hour;
				CurrentTime <<= 8;
				CurrentTime |= Datetime.Time.Min;
				
				StartTime = (*pTimeBasedAction)[temp].TimeAction.StarHours;
				StartTime <<= 8;
				StartTime |= (*pTimeBasedAction)[temp].TimeAction.StarMin;
				
				EndTime = (*pTimeBasedAction)[temp].TimeAction.EndHours;
				EndTime <<= 8;
				EndTime |= (*pTimeBasedAction)[temp].TimeAction.EndMin;


//				if( (Datetime.Time.Hour >= TimeBasedAction[temp].TimeAction.StarHours)  && 
//					(Datetime.Time.Min >= TimeBasedAction[temp].TimeAction.StarMin)		&&
//					(Datetime.Time.Hour <= TimeBasedAction[temp].TimeAction.EndHours)  && 
//					(Datetime.Time.Min <= TimeBasedAction[temp].TimeAction.EndMin) )//we need to start event in case if unit is started after start time of event

				if(CurrentTime >= StartTime && CurrentTime <= EndTime)
				{
					MsgPrint(MSG_WARNING,(*pTimeBasedAction)[temp].ActionType,"TimeBasedActions:ActionType");
					switch((*pTimeBasedAction)[temp].ActionType)
					{
					case TIMED_APB_RESET:     //For Global APB Reset
						L_DisplayROMStr("RESET ALL APB....",16,ROW_USER_FUNCTION);
						L_DisplayCharAtRow(15,(temp)+'1',ROW_USER_FUNCTION);
						for(block=0; block<MAX_CARD_BLOCKS; block++) //Loop for all blocks
						{
							MsgPrint(MSG_WARNING,block,"TimeBasedActions:block");
							startpage = CardMemHashTable[block].StartPageNo;
							for(pageno=0; pageno<FL_PAGES_PER_CARD_BLOCK; pageno++,startpage++)//Loop for all pages in that block
							{
							#ifdef ENABLE_WATCHDOG
								WDTFeed();		//Clear watchdog timer
							#endif
								MsgPrint(MSG_WARNING,pageno,"TimeBasedActions:pageno");
								//ReadCardDataFromFlashBlock(block,pos,&empcard);//in rabbit, it is not effiecient function
								MainMem_ReadPage(startpage,0,(unsigned char * )&tempwrbuf,PAGE_SIZE);//read one page  	
								for(i=0;i<MAX_CARD_PER_PAGE;i++)//Loop for each card in One page
								{
									memcpy((unsigned char *)&empcard, &tempwrbuf[i*CARD_FLASH_DB_BYTES],CARD_FLASH_DB_BYTES);	
									if(empcard.CardNo != 0)	// Do not store APB data if card no is zero this will increase speed.
									{
										if((empcard.CardInfo.APB & APB_NO_CHK) == 0)//entertain only cards which has APB enabled
										{
											empcard.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;//it will not check APB for first time.
											memcpy(&tempwrbuf[i*CARD_FLASH_DB_BYTES], (unsigned char *)&empcard,CARD_FLASH_DB_BYTES);	
											MsgPrint(MSG_WARNING,empcard.CardNo,"TimeBasedActions:CardNo");
										}
									}
								}//Loop for each card in One page
								//write one page
								MainMem_BuffWrt(0,1,(BYTE *)&tempwrbuf,PAGE_SIZE);	//write into temp flash buffer
							    BuffWrt_MainMem(startpage,1);		//write into actual flash location
							}//Loop for all pages in that block
						}//Loop for all blocks
					break;
					
					case TIMED_EVENT_GENERATE: //ARMF0378
					{
						L_DisplayROMStr("Scheduled SIREN.",16,ROW_USER_FUNCTION);
						L_DisplayCharAtRow(15,(temp)+'1',ROW_USER_FUNCTION);
						GenerateEvent((*pTimeBasedAction)[temp].Dummy1,0);//event num,channel num						
					}
					break;

					case TIMED_DOTL_RESET:
					break;
					
					default:
					break;
					}
					(*pTimeBasedAction)[temp].ActionCompleteDate.Day = Datetime.Date.Day;
					(*pTimeBasedAction)[temp].ActionCompleteDate.Month = Datetime.Date.Month;
					(*pTimeBasedAction)[temp].ActionCompleteDate.Year = Datetime.Date.Year;
					WriteTimeBasedAction(pTimeBasedAction);
					StoreCardInTrDBFull(temp+1,1,EVENT_TIME_BASED_ACTION,(*pTimeBasedAction)[temp].ActionType,0);
				}
			}
		}
	}
}
/*** BeginHeader DelAllTimeBasedActions*/
void DelAllTimeBasedActions(void);
/*** EndHeader */
void DelAllTimeBasedActions(void)	//ARMF0252
{
//struct TIME_BASED_ACTION (*pTimeBasedAction)[] = (struct TIME_BASED_ACTION (*)[])buff;

	if( !(InitialiseFlags & DELETE_ALL_TIME_ACTION) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_TIME_ACTION;
//	for(itemp=0;itemp<MAX_TIME_BASED_ACTIONS;itemp++)
//   {
//	   TimeBasedAction[itemp].ActionType = 0;
//	   TimeBasedAction[itemp].TimeAction.StarHours = 0;
//      TimeBasedAction[itemp].TimeAction.StarMin = 0;
//	   TimeBasedAction[itemp].TimeAction.EndHours = 0;
//      TimeBasedAction[itemp].TimeAction.EndMin = 0;
//      TimeBasedAction[itemp].ActionCompleteDate.Day = 0;
//      TimeBasedAction[itemp].ActionCompleteDate.Month = 0;
//      TimeBasedAction[itemp].ActionCompleteDate.Year = 0;
//   }
	ReadTimeBasedAction(pTimeBasedAction);//ARMF0317
	memset((*pTimeBasedAction),0,sizeof(struct TIME_BASED_ACTION)*MAX_TIME_BASED_ACTIONS);
	WriteTimeBasedAction(pTimeBasedAction);
}
/***************** End of TIME BASED ACTIONS ***********************/
void GetSpecialCardMSG(BYTE EventNum,BYTE* message)
{
memset( message,0x00,sizeof(message) ) ;
	switch(EventNum)
	{
	case EVENT_SPCL_CARD_NOT_FOUND:
	 	memcpy(message,"SPLCard NotFound",16);
	break;
	case  EVENT_ESCORT_CARD:
		memcpy(message,"Escort Card",16);
	break;
	case  EVENT_INTRUSION_CARD:
		memcpy(message,"Intrusion Card",16);
	break;
	case  EVENT_OCCUPANCY_CONTROL_CARD:
	if(Doorinfo.EnDisEmpInDispCount == 0x00)
		memcpy(message,"Ocupancy ctrl OFF",16);
	else if(Doorinfo.EnDisEmpInDispCount == 0x01 || Doorinfo.EnDisEmpInDispCount == 0x02)
		memcpy(message,"Ocupancy ctrl ON",16);
	break;
	case  EVENT_OVERRIDE_ACCESS_CARD:
		memcpy(message,"Override Access",16);
	break;
	case  EVENT_FIRST_INUSER_CARD:
		L_DisplayROMStr("First In User",16,ROW_USER_ENTRY);
//		PositionCursorOnRow2(15);
//	    WriteDataToDisplay( ReaderNo +'0');
	break;
	case  EVENT_EMERGENCY_CARD:
		memcpy(message,"Emergency Card",16);
	break;
	case  EVENT_DONOT_DISTURB_CARD:
		if(SplCrdFlag.DNDCFlag == SET)
			memcpy(message,"Do Not Dsturb ON",16);
		if(SplCrdFlag.DNDCFlag == CLR)
			memcpy(message,"Do Not Dstrb OFF",16);
	break;
	case  EVENT_ALERT_CARD:
		memcpy(message,"Alert Card",16);
	break;
	case  EVENT_NORMAL_CARD: //ARMF0283 
		memcpy(message,"Door Normal Card",16);
	break;
	case  EVENT_DMZ_RESET_CARD:
		L_DisplayROMStr("DMZ RESET DOOR",16,ROW_USER_ENTRY);
//   		PositionCursorOnRow2(15);
//    	WriteDataToDisplay( ReaderNo +'0');
	break;
	case EVENT_DONOT_DISTURBZONE_CARD:
		if(SplCrdFlag.DNDZoneFlag == SET)
		memcpy(message,"DND ZONE ON",16);
	   	if(SplCrdFlag.DNDZoneFlag == CLR)
		memcpy(message,"DND ZONE OFF",16);
	break;
	}
	message[16-1] = '\0';		// NG0012
}

void DelAllPhas2Setting(void)
{
#ifdef DISABLE_PHASE2_FUNCTIONALITY_FOR_THIS_CODE
	int i;
	for(i=0;i<MAX_READERS;i++)
	{
		ReaderInfo[i].DNDTZ = 0x00;	
		ReaderInfo[i].DeadManZoneEnDis = 0x00;
	}
	Doorinfo.DontDisturb=0;
	Doorinfo.FirstInUserRule=0;
	Doorinfo.DoorInterlock=0;
#else
#endif //#ifdef DISABLE_PHASE2_FUNCTIONALITY_FOR_THIS_CODE
}
			
		

	
		
		





