

#ifdef  VERSION_HEAD
	
	#ifdef ARM_BIOSMART_HW
		#ifdef BIO_METRIC
				extern const unsigned char ProdVerStr[]="ABW";
				extern const unsigned char ProductStr[]="Arm BioSmart    ";
		  #else
			    extern const unsigned char ProdVerStr[]="A2R";		//"SAR";	//"A4D";
				extern const unsigned char ProductStr[]="SmartSingle2RW    ";
		#endif
	#else//#ifdef ARM_BIOSMART_HW
		
		#ifdef	HARDWARE_SI065 //NG
		 	#ifdef BIO_METRIC
				#ifdef	SMART_CARD
					extern const unsigned char ProdVerStr[]="GBC";
					extern const unsigned char ProductStr[]="Arm BioSmartS";   
				#else
// 					extern const unsigned char ProdVerStr[]="ANB";
// 					extern const unsigned char ProductStr[]="Arm BioSmartW";
					extern const unsigned char ProdVerStr[]="GBW";		// GNB withoy 2nd phase feature GBW with 2nd phase 
					extern const unsigned char ProductStr[]="Arm NGBioSmartW";
				#endif // end of SMART_CARD
			#else
				    extern const unsigned char ProdVerStr[]="GSW";
					extern const unsigned char ProductStr[]="SmartSingle2R";
	    	#endif // end of BIO_METRIC
		#endif
		

	  #ifdef HARDWARE_SI049
		 	#ifdef BIO_METRIC
				#ifdef	SMART_CARD
					extern const unsigned char ProdVerStr[]="ABS";
					extern const unsigned char ProductStr[]="Arm BioSmartS  ";   
				#else
					extern const unsigned char ProdVerStr[]="ANB";
					extern const unsigned char ProductStr[]="Arm BioSmartW  ";
				#endif // end of SMART_CARD
			#else
				    extern const unsigned char ProdVerStr[]="ANS";
					extern const unsigned char ProductStr[]="SmartSingle2R  ";
	    	#endif // end of BIO_METRIC
		#endif  // end of HARDWARE_SI049
		
		#ifdef	HARDWARE_SI032
			#ifdef BIO_METRIC
				#ifdef SUPPORT_SUPREMA 
					extern const unsigned char ProdVerStr[]="BLS";
					extern const unsigned char ProductStr[]="ARM BIOlite:S    ";		 		    
				#else
					extern const unsigned char ProdVerStr[]="BLV";
					extern const unsigned char ProductStr[]="ARM BIOlite:V    ";		 		    
				#endif
			#endif
		#endif
		
	
	#endif//#ifdef ARM_BIOSMART_HW
#else
	extern const unsigned char ProdVerStr[];
#endif //#ifdef  VERSION_HEAD

#define		MAJOR_VER	'1'
#define		MINOR_VER	'5'

#define	CONTROLLER_TYPE_ACCESS		'A'
#define CONTROLLER_TYPE				CONTROLLER_TYPE_ACCESS
