#include "config.h"
#ifdef  ENABLE_TCP_PUSH

#include "type.h"
#include"uart.h"
#include "smartbio.h"
#include "cardmgmt.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "memmap.h"
#include "protocol.h"
#include"serial.h"
#include "TcpPush.h"

//extern USOCKET USER_TCP_socket;
extern SYSInfo SysInfo;
//unsigned char PushServerNo,PushServerErroCount;
extern USOCKET fnTCP_close(USOCKET TCP_Socket);
extern USOCKET fnTCP_Connect(USOCKET TCP_socket, unsigned char *RemoteIP, unsigned short usRemotePort, unsigned short usOurPort, unsigned short usMaxWindow);
//int fnUserListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen);
//extern QUEUE_TRANSFER fnSendBufTCP(USOCKET TCP_socket, unsigned char *ptrBuf, unsigned short usDataLen, unsigned char ucCommand);

//#define MSG_TCPPUSH 	MSG_DISP_ALWAYS
#define MSG_TCPPUSH 	MSG_WARNING


/*** BeginHeader IniPushTCPSocket*/
//int IniPushTCPSocket(unsigned char * iparr, unsigned int port);
/*** EndHeader */
// int IniPushTCPSocket(unsigned char * iparr, unsigned int port)
// {
// 	if(USER_TCP_socket <0)
// 	{									  //(set the type of service required from socket,usIdleTimeout,listener)
// 		if ((USER_TCP_socket = fnGetTCP_Socket(TOS_MINIMISE_DELAY, TCP_DEFAULT_TIMEOUT, fnUserListener)) >= 0) 
// 		{
// 			fnTCP_Connect(USER_TCP_socket, iparr , port, 0, 0);
// 		}
//    	}
// 	else
// 	{
// 		fnTCP_Connect(USER_TCP_socket, iparr , port, 0, 0);
// 	}
// 	return(USER_TCP_socket);
// }

//=================================================================================
// Following function will establish connection with reamot server and same is managed in state level
// Return code STATE_PUSH_ESTAB indicates that connection is established and we can push data or read data from that socket

/*** BeginHeader CheckTCPPushSocket*/
//int CheckTCPPushSocket(unsigned char *recbuffer,int *len,unsigned char server);
/*** EndHeader */
// int CheckTCPPushSocket(unsigned char *recbuffer,int *len,unsigned char server)
// {
// //unsigned char buffer[100];
// int status;
// //MsgPrint(MSG_TCPPUSH,PushConnected,"CheckTCPPushSocket:PushConnected");
// 	switch(PushConnected)
// 	{
// 		case STATE_PUSH_INI://initial state get socket here and connect
// 		{
// 			//unsigned char iparr[4]={192,168,0,17};
// 			BYTE iparr[4];
// 			StrToArr((char*)&(SysInfo.PUSH_TCP_ServAdd1[0]),iparr);
// 	
// 			if(server==0)	//connect to server
// 				status = IniPushTCPSocket(iparr,SysInfo.PUSH_TCP_Port1);
// 			else
// 				status = IniPushTCPSocket(iparr,SysInfo.PUSH_TCP_Port2);
// 			if( status>=0)//we got socket and send sync for connection
// 			{
// 				PushConnected = STATE_PUSH_PROGRESS1;
// 				PushConnTimeOut = Doorinfo.PushConnectTimeout;		//shree 17Nov PUSH_CONNECT_TIME_OUT;
// 			}
// 			else
// 			{
// 				PushConnected = STATE_PUSH_INI;
// 			}
// 			MsgPrint(MSG_TCPPUSH,status,"STATE_PUSH_INI:status");
// 		}
// 		break;
// 	case STATE_PUSH_PROGRESS3:    // This is just to add delay to get connection established
// 	case STATE_PUSH_PROGRESS2:
// 	case STATE_PUSH_PROGRESS1:
// //		if(USER_TCP_socket < 0)//if socket not found
// 		MsgPrint(MSG_TCPPUSH,EVENT_TCPPUSH,"STATE_PUSH_PROGR:EVENT_TCPPUSH");
// 		if(EVENT_TCPPUSH != STATE_PUSH_CONNECTED)//connected status is taken from EventListner
// 		{
// 			if( PushConnTimeOut == 0)
// 			{
// 				PushConnected ++;
// 				PushConnTimeOut = Doorinfo.PushConnectTimeout;		//shree 17Nov PUSH_CONNECT_TIME_OUT;
// 			}
// 			if(PushConnected == STATE_PUSH_PROGRESS3)
// 			{
// 				PushConnected = STATE_PUSH_ERROR;
// 				fnTCP_close(USER_TCP_socket);
// 				PushConnected =0;
// 				return(STATE_PUSH_ERROR);
// 			}
// 		}
// 		else
// 		{
// 			//      	printf("CheckTCPPushSocket Connection established \n");
// 			PushConnected =STATE_PUSH_ESTAB;
// 		}
// 	break;
// 	case STATE_PUSH_ERROR:
// 		fnTCP_close(USER_TCP_socket);
// 		PushConnected =0;
// 	break;
// 	default:
// 		fnTCP_close(USER_TCP_socket);
// 		PushConnected =0;
// 	break;
// 	}
// 	return(PushConnected);
// }
//==============================================================================================
// Following is used to send and delete transaction in puch method
/*
   #<deviceno char >P,<deviceno>,<no of transactions sent>,<Total pending>,<current Readpointer>,<write pointer>,!,
    T,<ChannelNo>,<event type>,<cardno>,<time>,<data>,<readpointer >,<sequence no>,!,
	T,<ChannelNo>,<event type>,<cardno>,<time>,<data>,<readpointer >,<sequence no>,!,
*/
/*** BeginHeader PushAndDeleteTransPacket*/
void PushAndDeleteTransPacket(unsigned char nooftrans,unsigned char port);
/*** EndHeader */
void PushAndDeleteTransPacket(unsigned char nooftrans,unsigned char port)
{
	struct TRNX_DATA trans;
	unsigned int totalavailable,tempread;
	unsigned char count;
	unsigned long ipaddress;
	
	ipaddress = aton((char*)SysInfo.LOCAL_IP);
	totalavailable = GetPendingTrans(TransReadPtr,TransWritePtr);
	if(totalavailable <nooftrans)
		nooftrans = totalavailable;
	tempread=TransReadPtr;
	TransmitReplyStartToX(port);
	TransmitCharToX('P',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(SysInfo.MySlaveNo,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(nooftrans,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TotalNosOfTrans-nooftrans,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TransReadPtr,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TransWritePtr,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX(ipaddress,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	TransmitCharToX('!',port);
	TransmitCharToX(',',port);
	count =0;
	while(1)
	{
		if(tempread ==TransWritePtr)
		{
			nooftrans = count;
			break;
		}
		ReadData(tempread,(unsigned char*)&trans);	  //ReadTemplateData
		TransmitCharToX('T',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(trans.Chnl,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(trans.Event,port);
		TransmitCharToX(',',port);
		SendDecimalLongToX(trans.CardNo,port);
		TransmitCharToX(',',port);
		SendDecimalToX(trans.Datetime.Time.Hour,port);
		SendDecimalToX(trans.Datetime.Time.Min,port);
		SendDecimalToX(trans.Datetime.Time.Secs,port);
		TransmitCharToX(',',port);
		SendDecimalToX(trans.Datetime.Date.Day,port);
		SendDecimalToX(trans.Datetime.Date.Month,port);
		SendDecimalToX(trans.Datetime.Date.Year,port);
		TransmitCharToX(',',port);
		SendDecimalIntToX(tempread,port);
		TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
		SendDecimalToPC3CharToX(trans.CType,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(trans.InputType,port);
		TransmitCharToX(',',port);
#else
		TransmitCharToX('0',port);
		TransmitCharToX(',',port);
		TransmitCharToX('0',port);
		TransmitCharToX(',',port);
#endif
		TransmitCharToX('!',port);
		TransmitCharToX(',',port);
		tempread++;
		if(tempread >=MAX_TRANS)
		{
			tempread = 0;
		}
		count++;
		if(count>=nooftrans)
			break;
	}
	TransmitCharToX('G',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(count,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	TotalNosOfTrans = TotalNosOfTrans-nooftrans;
	TransReadPtr=tempread;
//ERRORPushData:
	return;
}

//void ManagePushLogic(void)
//{	
/*
   1) Check if we have more then "PushThreshold" transaction in buffer to sent if no go to step 10
   2) If more then "PushNoOfTrans" transaction are there then
   3) open connection with server
   4) If connection not established go to step 7
   5) Connection established : Push "PushNoOfTrans" or available transaction less then "PushNoOfTrans" transaction in device to server and delete sent transactions.
   6) Close connection and set "PushWaitTimer" to Programmabed "PushWaitTime"
   7) Try to establish connection with second server
   8) If connection established go to step 4

   Time driven
   10)If "PushWaitTimer" =0
   11) Check some transactions are available
   11) go to step 3
  */
// int status;
// //unsigned char buffer[100];
// unsigned int backreadptr,backwrptr,backtotaltaans; 		

// 	if(PushConnected == STATE_PUSH_CLOSING)               
// 	{
// 		if(PushCloseTimeOut == 0)
// 		{
// 			MsgPrint(MSG_TCPPUSH,0x26,"Push soc Closed"); 	
//          	//sock_close(&PushSocket);
// 			fnTCP_close(USER_TCP_socket);
// 		   	PushConnected = STATE_PUSH_INI;
// 		}
// 		else
// 		    return;
// 	}

// 	if(((SysInfo.PushThreshold <= GetPendingTrans(TransReadPtr,TransWritePtr)) || (PushWaitTimer == 0)) && (PushDelayTimer == 0))
// 	{
// 		if(GetPendingTrans(TransReadPtr,TransWritePtr) != 0)
// 		{
// 	      	status = CheckTCPPushSocket(NULL,NULL,PushServerNo);
// 	      	if( STATE_PUSH_ESTAB == status )
// 	      	{
// 	         	// indicates that connection established
//             	//MsgPrint(0x80,CurrentSocket,"Conn Established"); 		
//    				PortObj[SER_TCPPUSH_PORT].BufPtr = 0;
// 	            backreadptr = TransReadPtr;
// 	            backwrptr = TransWritePtr;
// 	            backtotaltaans = TotalNosOfTrans;
// 	            //MsgPrint(MSG_NETWORK,PushServerNo+1,"Push Svr"); 	
// 				PushAndDeleteTransPacket(SysInfo.PushNoOfTrans,SER_TCPPUSH_PORT);   
// 				fnSendBufTCP(USER_TCP_socket, (unsigned char *)PortObj[SER_TCPPUSH_PORT].Buffer, PortObj[SER_TCPPUSH_PORT].BufPtr, TCP_BUF_SEND);
// 			
// //	            printf("Data Sent no of bytes %d  Data %s \n",status,buffer);
// 		    	PushConnected = STATE_PUSH_CLOSING;
// 		    	PushCloseTimeOut = Doorinfo.PushCloseDelay;  	
// 		    	PushServerErroCount = 0;
// 	         	PushDelayTimer = SysInfo.PushTransDelay;
// 			
// 			}				
// 	      	else if(STATE_PUSH_ERROR == status)
// 	      	{
//          		PushServerErroCount++;
//             	if(PushServerErroCount >= 5)
//             	{
// 	            	if(PushServerNo == 0)
// 	               		PushServerNo = 1;
// 	            	else
// 	               		PushServerNo = 0;
// 					PushServerErroCount = 0;
//             	}
// 	         // Try for second server IP address to connect
// 	         	PushWaitTimer = SysInfo.PushWaitDelay;
// 	         	PushDelayTimer = SysInfo.PushTransDelay;
// 	      	}
//       	}
//       	else
//       	{
// 	      	PushWaitTimer = SysInfo.PushWaitDelay;
// 	      	PushDelayTimer = SysInfo.PushTransDelay;
// 		}		
// 	}
// }
void ManagePushLogic(void) //call this every 1 sec.
{
/* 1) Check if we have more then "PushThreshold" transaction in buffer to sent if no go to step 10
   2) If more then "PushNoOfTrans" transaction are there then
   3) open connection with server
   4) If connection not established go to step 7
   5) Connection established : Push "PushNoOfTrans" or available transaction less then "PushNoOfTrans" transaction in device to server and delete sent transactions.
   6) Close connection and set "PushWaitTimer" to Programmabed "PushWaitTime"
   7) Try to establish connection with second server
   8) If connection established go to step 4

   Time driven
   10)If "PushWaitTimer" =0
   11) Check some transactions are available
   11) go to step 3 */
	
unsigned int NumOfTrnx = GetPendingTrans(TransReadPtr,TransWritePtr);
unsigned int backreadptr,backwrptr,backtotaltaans;   
	
	switch(TPushState ){
		case TPUSH_STATE_INI :	break;
		case TPUSH_STATE_CONNECT:{
			if(TPushTempWaitDelay==0){//check for delay between two transaction
					unsigned char iparr[4]={0};
					
					if(TPushServerNum == 1){
						StrToArr((char*)&(SysInfo.PUSH_TCP_ServAdd1[0]),iparr);
						fnTCP_Connect(TCP_PUSH_socket, iparr , SysInfo.PUSH_TCP_Port1, 0, 0);//connect with server 1
						}
					else{
						StrToArr((char*)&(SysInfo.PUSH_TCP_ServAdd2[0]),iparr);
						fnTCP_Connect(TCP_PUSH_socket, iparr , SysInfo.PUSH_TCP_Port2, 0, 0);//connect with server 2
						}
					TPushState = TPUSH_STATE_CONNECTING;
					MsgPrint(MSG_WARNING,TPushServerNum,"TPUSH_STATE_CONNECTING");
				}
			}
			return;//no need to run below code
			//add state for connect fail to try second server.
// 		case TPUSH_STATE_CONNECTED:{
// 			}
// 			break;
		case TPUSH_STATE_CONNECT_FAIL:{
			MsgPrint(MSG_WARNING,TPushServerNum,"TPUSH_STATE_CONNECT_FAIL");
			++TPushServerNum;
			if(TPushServerNum>2)    //two tcp server are supported
				TPushServerNum =1;
			TPushState=TPUSH_STATE_CONNECT;
			}return;
		case TPUSH_STATE_DATA_SENDING:{ //bussy state so return from here
			}
			return;
		case TPUSH_STATE_DATA_SENT_OK:{ //data is sent and received by server so close connection
			MsgPrint(MSG_WARNING,TPushServerNum,"TPUSH_STATE_DATA_SENT_OK");
			if(FContSend != 1){//if we want continuos send then do not close.
				if(TPushTempCloseDelay == 0){//check for close delay
						MsgPrint(MSG_WARNING,TPushServerNum,"Tpush close");
						fnTCP_close(TCP_PUSH_socket);
						TPushState =  TPUSH_STATE_INI;
					}
					return;
				}
			else{//delay for continuous send
				if(TPushTempTransDelay == 0){
					TPushTempTransDelay = SysInfo.PushTransDelay;
					break;//timer is reached so continue with sending
					}
				else{
					return;//else return and timer will decrease in timer wvent
					}
				}
//			break;
			//we have not released socket bec it is used in next send
			}
		case TPUSH_STATE_CLOSED:{ //closed by server application
			MsgPrint(MSG_WARNING,TPushServerNum,"TPUSH_STATE_CLOSED");
			TPushState =  TPUSH_STATE_INI;
			}
			return;
		case TPUSH_STATE_DATA_SENT_FAIL:{
			TransReadPtr = backreadptr;
			TransWritePtr = backwrptr ;
			TotalNosOfTrans = backtotaltaans;
			MsgPrint(MSG_WARNING,TPushServerNum,"Tpush sent fail");
			fnTCP_close(TCP_PUSH_socket);
			TPushState =  TPUSH_STATE_INI;
			}
			return;
			
		}
				
	if(SysInfo.PushThreshold <= NumOfTrnx ){	//{1}
//		FContSend = 1;
		if( (SysInfo.PushNoOfTrans != 0)&&(SysInfo.PushNoOfTrans <= NumOfTrnx) ){	//{2}
			if(TPushState ==  TPUSH_STATE_INI){
				TPushTempWaitDelay = SysInfo.PushWaitDelay;
				if(TCP_PUSH_socket < 0){//if TCP_PUSH_socket  is not a socket number
					if((TCP_PUSH_socket = fnGetTCP_Socket(TOS_MINIMISE_DELAY, TCP_DEFAULT_TIMEOUT, TPushTestListener)) >= 0) {   //get socket
						//we got socket so connect to server
						TPushState = TPUSH_STATE_CONNECT;
						TPushServerNum =1;//connect with server 1
						}
					else{
						//we fail to get free socket
						MsgPrint(MSG_WARNING,TCP_PUSH_socket,"socket not found");
						}
					}
				else{//we have valid socket so start connecting
						TPushState = TPUSH_STATE_CONNECT;
						TPushServerNum =1;// connect start from server 1
					}
				}
			else if(TPushState==TPUSH_STATE_CONNECTED || TPushState==TPUSH_STATE_DATA_SENT_OK){
	         	// indicates that connection established
   				PortObj[SER_TCPPUSH_PORT].BufPtr = 0;
	            backreadptr = TransReadPtr;
	            backwrptr = TransWritePtr;
	            backtotaltaans = TotalNosOfTrans;
	            //MsgPrint(MSG_NETWORK,PushServerNo+1,"Push Svr"); 	
				PushAndDeleteTransPacket(SysInfo.PushNoOfTrans,SER_TCPPUSH_PORT); 
				//TPushData.TcpPushSendBuffer[0]='H';
				//TPushData.TcpPushSendBuffer[1]='I';
            	MsgPrint(MSG_WARNING,TPushServerNum,"TPush send data:"); 		
				fnSendTCP(TCP_PUSH_socket, (unsigned char *)&TPushData, PortObj[SER_TCPPUSH_PORT].BufPtr, TCP_FLAG_PUSH);
                TPushState = TPUSH_STATE_DATA_SENDING;
				TPushTempCloseDelay = Doorinfo.PushCloseDelay;
				TPushTempTransDelay = SysInfo.PushTransDelay;
				FContSend = 1;
				}
			}
			else{
				FContSend = 0;
			}
		}
		else{
			FContSend = 0;
		}
}
int TPushTestListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen) 
{
//   TCP_MESSAGE test_message;
	MsgPrint(MSG_WARNING,ucEvent,":List:event:");

    switch (ucEvent) {
    case TCP_EVENT_CONREQ:                                              
    case TCP_EVENT_CLOSE:
    case TCP_EVENT_PARTIAL_ACK:
        break;
//    case TCP_EVENT_REGENERATE:
    case TCP_EVENT_DATA:
//         if ((ucEvent == TCP_EVENT_REGENERATE) || (!uMemcmp((CHAR*)ucIp_Data, "TEST" , 4))) {
//             uStrcpy((CHAR*)test_message.ucTCP_Message, "Hi!!");
//             if (fnSendTCP(Socket, (unsigned char *)&test_message.tTCP_Header, 4, TCP_FLAG_PUSH) > 0) {
//                 return APP_SENT_DATA;
//             }
//         }
        break;
    case TCP_EVENT_ACK:{ //come here when data is received to server and ack is received to client
		TPushState = TPUSH_STATE_DATA_SENT_OK;
		}
		break;
    case TCP_EVENT_ARP_RESOLUTION_FAILED: //server IP not found
	case TCP_EVENT_ABORT:	//when we are trying to connect server but server application is not running.
		TPushState = TPUSH_STATE_CONNECT_FAIL;
		break;
    case TCP_EVENT_CLOSED:	//when server has sent close to client and server app is closed.
//        fnTCP_Listen(Socket, ++usTestPort, 0);                    // go back to listening state on next port number
		TPushState = TPUSH_STATE_CLOSED;
        break;
    case TCP_EVENT_REGENERATE:  //this state come when sent data would not received ack.
		TPushState = TPUSH_STATE_DATA_SENT_FAIL;
		break;
    case TCP_EVENT_CONNECTED:
		{	//send data here
// 			static TCP_MESSAGE TestData;
// 			TestData.ucTCP_Message[0] = 0x31;
// 			TestData.ucTCP_Message[1] = 0x32;
// 			TestData.ucTCP_Message[2] = 0x33;
// 			TestData.ucTCP_Message[3] = 0x34;
// 			if(fnSendTCP(test_client_socket, (unsigned char *)&TestData, 4, TCP_FLAG_PUSH))
// 			{	//successful
// 				MsgPrint(MSG_WARNING,TCP_EVENT_CONNECTED,":sent:");	
// 			}
			TPushState = TPUSH_STATE_CONNECTED;
		break;
		}
    }
    return APP_ACCEPT;
}


#endif	//ENABLE_TCP_PUSH

