/*****************************************************************************
 *   timer.c:  Timer C file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "irq.h"
#include "target.h"
#include "timer.h"
//#include "tcpip.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "access.h"
#include "Keypad.h"
#include "INOUT.h"
#include "userintf.h"
#include "rdcont.h"
#include "RdPoll.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "ProcessWeiCard.h"
#ifdef ENABLE_GSM_GPRS
#include "GSMModem.h"
#endif
#include "Timer.h"

#ifdef SUPPORT_SPEECHIC
	#include "DriverSpeech_IC.h"
#endif	

/*----------------------------------------------------------------------------*/
//external vriables
extern BYTE F_KeyIdleTime,F_Password,F_UserTimeOut,F_WeigandInterrupt1,F_WeigandInterrupt2;
extern BYTE F_WeigandStarted1,F_WeigandStarted2;


extern BYTE WeigandTimeOut1,WeigandTimeOut2,LastCardTime;
extern BYTE DOTLTimeOut1,DOTLTimeOut2,Door2OpenTimeOut,Door1OpenTimeOut;
extern SYSInfo SysInfo;

extern BYTE InOutReaderTime,F_DisplayINOutToggle,F_KeyPressed;
extern BYTE SC1_PollTime,SC2_PollTime,SmartCardTimeOut;
extern BYTE	F_OneSec,F_LastCardCheck,F_TempCounterStart,F_Keyscan,F_100mSec;
extern BYTE F_Is_Dotl2_Alarm,F_Dotl2_TimeOut,F_Channel2_DoorClose,F_Door2_Open_TimeOut;
extern BYTE F_Is_Dotl1_Alarm,F_Door1_Open_TimeOut,F_Dotl1_TimeOut,F_Channel1_DoorClose;
extern BYTE F_ChangeInInput;
extern int PageWriteTimer;
int TemplatePageWriteTimer;
extern unsigned char IdleKeyCounter,AdminLogOutTimer;
extern unsigned char F_DoNotCheckAPBForCard,DoNotCheckAPBTime;
extern BYTE EmpMinCount,InEmpDispCount;
extern volatile unsigned char PushWaitTimer,PushDelayTimer;
extern volatile unsigned char PushConnTimeOut,PushCloseTimeOut;
extern unsigned char F_DuelUserAuth;
extern unsigned char DuelUserCounter;
extern struct DOOR_INFO Doorinfo;
extern unsigned char F_ImageUploadInProcess;
//local variable
extern int F_SCAN_KEY ;
extern unsigned char F_authScreenTimer,F_authScreenTimerEnable;				

volatile BYTE counter=0;

#ifdef ENABLE_TCP_PUSH
	extern unsigned char TPushTempWaitDelay,TPushTempTransDelay,TPushTempCloseDelay;
#endif
#ifdef SUPPORT_ICLASS_RDR	
extern volatile unsigned char ICR1_PollTime,ICRTimeOut;		//,ICR1_F_Poll; 
#endif 
volatile unsigned int iDelayX10ms=0;
void Delay_X10ms(unsigned int value);
/*****************************************************************************
** Function name:		delayMs
**
** Descriptions:		Start the timer delay in milo seconds
**						until elapsed
**
** parameters:			timer number, Delay value in milo second			 
** 						
** Returned value:		None
** 
*****************************************************************************/
void delayMs(BYTE timer_num, DWORD delayInMs)
{
  if ( timer_num == 0 )
  {
	/*
	* setup timer #0 for delay
	*/
	T0TCR = 0x02;		/* reset timer */
	T0PR  = 0x00;		/* set prescaler to zero */
	T0MR0 = delayInMs * (Fpclk / 1000-1);
	T0IR  = 0xff;		/* reset all interrrupts */
	T0MCR = 0x04;		/* stop timer on match */
	T0TCR = 0x01;		/* start timer */
  
	/* wait until delay time has elapsed */
	while (T0TCR & 0x01);
  }
  else if ( timer_num == 1 )
  {
	/*
	* setup timer #1 for delay
	*/
	T1TCR = 0x02;		/* reset timer */
	T1PR  = 0x00;		/* set prescaler to zero */
	T1MR0 = delayInMs * (Fpclk / 1000-1);
	T1IR  = 0xff;		/* reset all interrrupts */
	T1MCR = 0x04;		/* stop timer on match */
	T1TCR = 0x01;		/* start timer */
  
	/* wait until delay time has elapsed */
	while (T1TCR & 0x01);
  }
  return;
}

/******************************************************************************
** Function name:		Timer0Handler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**						executes each 10ms @ 60 MHz CPU Clock
**
** parameters:			None
** Returned value:		None
** 
******************************************************************************/
void Timer0Handler (void) __irq 
{  
  T0IR = 1;			/* clear interrupt flag */
  IENABLE;			/* handles nested interrupt */

  timer0_counter++;


  IDISABLE;
  VICVectAddr = 0;	/* Acknowledge Interrupt */
}

// easyWEB internal function
// function executed every 0.210s by the CPU. used for the
// inital sequence number generator (ISN) and the TCP-timer
#ifdef ENABLE_ETHERNET_OLD 
void TCPClockHandler (void) __irq                // Keil: interrupt service routine for timer 0
{ 
	T0IR = 1;                               	// Clear interrupt flag
//	IENABLE;			/* handles nested interrupt */
  
	ISNGenHigh++;                                  // upper 16 bits of initial sequence number
	TCPTimer++;  
                                    				// timer for retransmissions
//	IDISABLE;
	VICVectAddr = 0;                               // Acknowledge Interrupt
}
#endif

/******************************************************************************
** Function name:		Timer1Handler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**						executes each 10ms @ 60 MHz CPU Clock
**
** parameters:			None
** Returned value:		None
** 
******************************************************************************/
void Timer1Handler (void) __irq 
{  
//int i;
	T1IR = 1;			/* clear interrupt flag */
//	IENABLE;			/* handles nested interrupt */
	
	Temp10mSecCounter ++;
#ifdef SUPPORT_SPEECHIC
	SoundDelay_10++;
#endif	
	if(iDelayX10ms)
		--iDelayX10ms;

	WEIGAND_TIMER_HNDLx(0);			//check for Weigand input for reader 0
	WEIGAND_TIMER_HNDLx(1);			//check for Weigand input for reader 1
    F_SCAN_KEY = 1;	//every 10msec
	if(Temp10mSecCounter >= MAX100mSECCOUNT)
	{
		Temp10mSecCounter = 0;
		Temp100mSecCounter ++;
		F_100mSec = SET;
//		if(FIO1PIN & KEY_SEL) 	   //P1.26	 chekc key press
//			F_KeyPressed = 1;
		F_KeyPressed = SET;
	
#ifdef SMART_CARD
	#ifndef SUPPORT_ICLASS_RDR       
			SmartCardTimeOut ++;
	#else
			ICRTimeOut++;
	#endif
#endif
		if(F_OutPutLock == 0)// We shbould not control Buzzer when LOCK is taken
		{
			PROCESS_INPUT_DEBOUNCE_INTERRUPT();	 //read input with debounce of 100msec.
 #ifdef ENABLE_SLAVE_SUPPORT
		SlaveWaitTimeOut ++;
#endif
			if(SoundTimer != 0)	//ARMD0057 as timer interrupt occurs after every 100msecs
			{
				SoundTimer --;
				if(SoundTimer == 0)
				{
					if(SoundType == SOUND_DOUBLE_BEEP)
					{
						//SoundTimer = TIME_SOUND_DOUBL_BEEP * 14;
						SoundTimer = TIME_SOUND_DOUBL_BEEP / 5;
						SoundType = SOUND_DOUBLE_BEEP_OFF;
						BUZZER_OFF();
					}
					else if(SoundType == SOUND_DOUBLE_BEEP_OFF)
					{
						BUZZER_ON();
	//					SoundTimer = TIME_SOUND_DOUBL_BEEP * 14;
						SoundTimer = TIME_SOUND_DOUBL_BEEP / 5;
						SoundType = 0;
					}
					else
					{
						BUZZER_OFF();
					}
				}
			}
			else
			{
				BUZZER_OFF();
			}
		}

#ifdef BIO_METRIC
		FingerWaitTimeOut ++;
#endif
		if(BackKeyCounter!=0)					 //NG0001
		{
			BackKeyCounter--;
			if(BackKeyCounter==0)
				F_GenerateBackKey = SET;
		}

		if(Temp100mSecCounter >= MAX100mSECCOUNT)
		{     						  ////enters every 1sec
			if(F_ImageUploadInProcess!=0)
				F_ImageUploadInProcess--;
			Temp100mSecCounter = 0;
			Temp1SecCounter++;
			counter++;
			if(counter > 4)
			{
				counter = 0;	
				timer0_counter = 0;
			}
			DOOR_CONT_1SEC_INTERRUPT(0);
			DOOR_CONT_1SEC_INTERRUPT(1);
	        F_OneSec = SET;
			ScrollImageTime++;
			DispWall_IdealTime++;
	#ifdef ENABLE_GSM_GPRS
			ModemTimeOut++;
			if(F_100mSecCounterStart)
    		{
         		Temp_100mSec_Time_Counter ++;
      		}
	#endif 
 	        TempSecCount ++;
			InEmpDispCount++;

			if(TempSecCount == 60)
			{
				EmpMinCount ++;
				DMZMinCounter ++;
				TempSecCount = 0;
			}
#ifdef ENABLE_LCD_BACKLITE
			if(BacklitOnTime < 0xFFFE)					//defect X0048
				BacklitOnTime++;
#endif
			PageWriteTimer++;
			TemplatePageWriteTimer++;
			DONOT_CHECK_APB_INT();	//FA00130
#ifdef BIO_METRIC
			if(F_UserTimeOut == SET)
			{
				if(UserTimeOut != 0)
					UserTimeOut --;
			}
#endif
//			if(Temp1SecCounter >= MAX1SEC)
			{
				Temp1SecCounter = 0;
				if(LastCardTime != 0)
				{
					LastCardTime --;
					if(LastCardTime == 0)
						F_LastCardCheck = CLR;
				}
				if(SysInfo.ContInOut >= 2)
				{// after inout time out reader will go in in mode
					if(InOutReaderTime != 0)
					{
						InOutReaderTime--;
						if(InOutReaderTime == 0)
							F_DisplayINOutToggle = SET;
					}
				}
#ifdef SMART_CARD
	#ifndef SUPPORT_ICLASS_RDR       
					SC1_PollTime++;
					SC2_PollTime++;
	#else
					ICR1_PollTime++;
	#endif
#endif						   
#ifdef ENABLE_POLL_BIO
				PollBioSensorTimeOut ++;
				if(PollBioSensorTimeOut >= MAX_FINGER_POLL_TIME_OUT)
				{
					PollBioSensorTimeOut = 0;
					F_Poll_Bio_Sensor = SET;
				} 
#endif
				AllSlaveRestartTime++;
				if(AllSlaveRestartTime >= 10)
				{
					F_RestartPollSelective = SET;
					AllSlaveRestartTime = 0;
				}
				if(F_TempCounterStart)
				{
					Temp_Time_Counter ++;
				}
				#ifdef ENABLE_GSM_GPRS
		        	GPRS_1SEC_TIMER_INTERRUPT();
                #endif
				if(F_KeyIdleTime == CLR)
				{	
					if(IdleKeyCounter <= MAX_KEY_IDLE_TIME)
					{
						IdleKeyCounter ++;	 
						if(IdleKeyCounter == MAX_KEY_IDLE_TIME)
							F_KeyIdleTime = SET;
					}
				}
				if(F_Password)
				{
					AdminLogOutTimer ++;    //no log out with time
				}
				if(F_Door1_Open_TimeOut)
				{  
					Door1OpenTimeOut --;
					if(Door1OpenTimeOut == 0)
					{  
						F_Channel1_DoorClose = SET;
						F_Door1_Open_TimeOut = CLR;
					}
				}
				if(F_Dotl1_TimeOut)
				{  
					DOTLTimeOut1 --;
					if(DOTLTimeOut1 == 0)
					{
						F_Dotl1_TimeOut = CLR;
						F_Is_Dotl1_Alarm = SET;
					}
				}
				if(F_Door2_Open_TimeOut)
				{  
					Door2OpenTimeOut --;
					if(Door2OpenTimeOut == 0)
					{  
						F_Channel2_DoorClose = SET;
						F_Door2_Open_TimeOut = CLR;
					}
				}
				if(F_Dotl2_TimeOut)
				{  
					DOTLTimeOut2 --;
					if(DOTLTimeOut2 == 0)
					{
						F_Dotl2_TimeOut = CLR;
						F_Is_Dotl2_Alarm = SET;
					}
				}
			}
		
#ifdef ENABLE_TCP_PUSH
			if(TPushTempWaitDelay){
				--TPushTempWaitDelay;
				}
			if(TPushTempTransDelay ){
				--TPushTempTransDelay ;
				}
			if(TPushTempCloseDelay){
				--TPushTempCloseDelay;
				}
#endif
			if(F_authScreenTimerEnable && F_authScreenTimer!=0)
				F_authScreenTimer--;
		}//if(Temp100mSecCounter >= MAX100mSECCOUNT) every 1 second
	}//if(Temp10mSecCounter >= MAX100mSECCOUNT) every 100msec
//  IDISABLE;
	VICVectAddr = 0;	/* Acknowledge Interrupt */
}

/******************************************************************************
** Function name:		enable_timer
**
** Descriptions:		Enable timer
**
** parameters:			timer number: 0 or 1
** Returned value:		None
** 
******************************************************************************/
void enable_timer( BYTE timer_num )
{
  if ( timer_num == 0 )
  {
	T0TCR = 1;
  }
  else
  {
	T1TCR = 1;
  }
  return;
}

/******************************************************************************
** Function name:		disable_timer
**
** Descriptions:		Disable timer
**
** parameters:			timer number: 0 or 1
** Returned value:		None
** 
******************************************************************************/
void disable_timer( BYTE timer_num )
{
  if ( timer_num == 0 )
  {
	T0TCR = 0;
  }
  else
  {
	T1TCR = 0;
  }
  return;
}

/******************************************************************************
** Function name:		reset_timer
**
** Descriptions:		Reset timer
**
** parameters:			timer number: 0 or 1
** Returned value:		None
** 
******************************************************************************/
void reset_timer( BYTE timer_num )
{
  DWORD regVal;

  if ( timer_num == 0 )
  {
	regVal = T0TCR;
	regVal |= 0x02;
	T0TCR = regVal;
  }
  else
  {
	regVal = T1TCR;
	regVal |= 0x02;
	T1TCR = regVal;
  }
  return;
}

/******************************************************************************
** Function name:		init_timer
**
** Descriptions:		Initialize timer, set timer interval milisec, reset timer,
**						install timer interrupt handler
**
** parameters:			timer number and timer interval
** Returned value:		true or false, if the interrupt handler can't be
**						installed, return false.
** 
******************************************************************************/
DWORD init_timer ( BYTE timer_num, DWORD TimerInterval ) 
{
//  if ( timer_num == 0 )
//  {
//	timer0_counter = 0;
//	T0MR0 = TimerInterval;
//	T0MCR = 3;				/* Interrupt and Reset on MR0 */
//	if ( install_irq( TIMER0_INT, (void *)Timer0Handler, HIGHEST_PRIORITY ) == FALSE )
//	{
//	  return (FALSE);
//	}  
//	else
//	{
//	  return (TRUE);
//	}
//  }
//  else
  if ( timer_num == 1 )
  {	 
	timer1_counter = 0;
	T1MR0 = TimerInterval * (Fpclk / 1000-1); // milisec 
	T1MCR = 3;				/* Interrupt and Reset on MR1 */
	T1TCR = 1;		//start timer
	if ( install_irq( TIMER1_INT, (void *)Timer1Handler, HIGHEST_PRIORITY ) == FALSE )
	{
	  return (FALSE);
	}  
	else
	{
	  return (TRUE);
	}				
  }		   
  return (FALSE);
}
void Delay_X10ms(unsigned int value)
{
	iDelayX10ms = value;
	while(iDelayX10ms);
}
/******************************************************************************
**                            End Of File
******************************************************************************/
