/*
Copyright(C)  Smart I Electronic Systems
This file contains all memory maps for FLASH memory and for internal Ram if same is required

*/
/************************************************************************************
Total Pages 
for 32 Mbit or 4MByte
Pages 7943 of 528 bytes
Pages 8192 of 512 bytes
We considered  7943 pages 
//For One Lakh Users,One lakh User Names,Fifty Thousand Transactions:
For each user card data we need 16Bytes.
card data structures that can be stored in one page = 528/16 = 33 

we need to support 1lac users,
	but we create block for hashing using (card number % 10), so we get 10 blocks
	for each block we store 10000 user (idealy ) to support 1lac user
	so how many pages required in one block to store 10000 cards= 10000/33 = 303.03 which is approx 304
	so we support 304 * 33 = 10032 cards in one block
	so total cards supported is 10032*10 = 100320 in 3040 pages
	so if card data start page is 94    then end page is 94+3040-1   = 3133
	   if card name start page is 3134  then end page is 3134+3040-1 = 6173
	   we are wasting one page per block so increase end boundry by 10
	   so end page of card data is 3143
we are supporting name for card also
	so start page of name is 3144 and end page is 6193	
we need to support 50000 transaction also
	1 transaction structure requires 14 bytes
	so one page will write 528/14 = 37.7 take 36 transactions
	to store 50000 transactions how many pages required 50000/36 = 1388.8 take 1389 pages
	so if transaction start page is 6194 then end page is 6194+1389-1 = 7582

still we have free space starting from 7582 to 7943 = 361 pages
*/
#define FL_MODEL_SERIAL_NO          1
#define FL_SYSINFO_PAGE             3
#define FL_DOORINFO_PAGE            5
#define FL_ADMIN_DATA_PAGE          7
#define FL_TIME_ZONE_PAGE           12		//9
#define FL_HOLIDAY_PAGE             42		// 42,43,44,45
#define FL_SPL_CARDDATA_PAGE_NO     47		//special card 
#define FL_MESSAGE_PAGE_NO          52		//22    // 22 +7 = 29  ( 16*100)
#define FL_ACCESS_LEVEL_PAGE_NO     79		//29    // 29  ( 128 * 2 )
#define FL_ACCESS_MONTH_PAGE_NO     82    //31*32 = 992 bytes
#define FL_NEWREADER_INFO_PAGE_NO   88		//38    // 38 to 39 ( 2023 + (16*16)/256) //FA00076 Door setting by reader info command same as 4DR 4RD.
#define FL_EVENT_ID_INFO            90		//40    // 2 pages  //shree 080909
#define FL_EMAIL_ADD_INFO			94		// We have total 16 email address with size of 32 so we need total 256 bytes
#define FL_TIME_BASED_ACTION_PAGE   95		// 1page i.e. 528bytes
#define FL_SPL_CARD_FLAG_PAGE		97
#define FL_CARDDATA_PAGE_NO         100		//46    // Base address for card database

#ifdef HARDWARE_SI065	//NG biosmart
//			#define FL_CARD_NAME_PAGE_NO        	1004		
//			#define FL_CARD_TEMPLATE_INFO_PAGE_NO	1	//2854	//this is starting page 	
//			#define FL_TEMPLATE_DATA_PAGE_NO       	500	//3306 
			#define FL_TRANS_DATA_BASE          	1		//second flash
			#define FL_CARD_EXTRA_DATA_PAGE_NO		2800	// First flash		
#else
#ifdef ONE_LK_TXN_30K_CARDS
	#define FL_CARD_NAME_PAGE_NO        1004    //910 pages reqd for 30000 names	 
	#define FL_TRANS_DATA_BASE          1914 	 
#else
	#ifdef BIOLITE_LOW_END
		#define FL_CARD_NAME_PAGE_NO        847			
		#define FL_TRANS_DATA_BASE          1600	
	#else
		#ifdef BIOLITE_HIGH_END
			#define FL_CARD_NAME_PAGE_NO        847		 
			#define FL_TRANS_DATA_BASE          1600	
		#else	
			#define FL_CARD_NAME_PAGE_NO        	1004		
			#define FL_TRANS_DATA_BASE          	1914
				//#define FL_CARD_TEMPLATE_INFO_PAGE_NO	1	//2854		
			#define FL_TEMPLATE_DATA_PAGE_NO       	500	//3306 
		#endif//#ifdef BIOLITE_HIGH_END
	#endif//#ifdef BIOLITE_LOW_END
#endif//#ifdef ONE_LK_TXN_30K_CARDS
#endif
#define CARD_NAME_SIZE				16

//#define MAX_PAGES_FOR_CARD_NAME (unsigned int)((CARD_NAME_SIZE*MAX_NO_OF_CARD)/FLSH_APP_PAGE_SZ)  // for 50000 ,15623 page 
//IN ABOVE ,CARD_NAME_SIZE	OTHER THEN 16 MIGHT GIVE UNPROPER RESULT.

#define FL_NEW_FW_CODE_INFO			6900	//change to 7000 ,to add more flash programming // Second Flash 
#define FL_NEW_FW_BASE_ADDRESS		6901	//We will use 542 pages for new f/w i.e. 271K program size	 // Second Flash
   
#define TRANS_DATA_BASE		        FL_TRANS_DATA_BASE	
#define TEMPLATE_DATA_BASE       	FL_TEMPLATE_DATA_BASE

/***********************************************************************************/
#define TransReadPtr 	(*((unsigned int *) 0xE0084000))
#define TransWritePtr   (*((unsigned int *) 0xE0084004)) 
#define TotalNosOfTrans (*((unsigned int *) 0xE0084008)) 
#define TotalCards		(*((unsigned int *) 0xE008400C)) 
/**********************************************************************************
#define TemplateReadPtr 	(*((unsigned int *) 0xE0085000))
#define TemplateWritePtr   	(*((unsigned int *) 0xE0085004)) 
#define TotalNosOfTemplates (*((unsigned int *) 0xE0085008)) 
**********************************************************************************/

//below #defines must be same as in "sbl_main.c" in boot code
//#define WDTResetType	(*((unsigned int *) 0xE0084010))   //defined in wdt.h file
#define MEM_ADD_BOOT_STRING  		(((char *) 0xE0084014))
#define BOOT_STRING_LENGTH	8
extern BYTE tempwrbuf[FLSH_APP_PAGE_SZ];

#define BOOT_STRING					"BOOTVER1"			// Just to program that entered boot path
#define BOOT_STRING_2				"bootVER1"			// Just to know that it entered different code path
#define BOOT_STRING_COMPLETE		"DONEVER1"			// Just to know that Bootloading done 
#define BOOT_STRING_UPGRADE			"SMARTUPG"
#define BOOT_STRING_INITDONE		"INITDONE"			//it changes to this string when initialise after upgrade is done
////////////////////////////////////////////////////////////
/**
SD card has block size of 512 bytes
2gb card has 2M blocks from 0 to 0x1FFFFF
out of this 1GB is used for transaction so block no. 0 to 0x3FFFFF
one template is stored in one page
1lack pages is reserved for template: block from 0x300000 TO 0x320000
*/


#define SD_START_BLOCKNO_SD_BMP  0x2A0000   //  IMAGE OF SIZE 320*240
//1 image = 300 blocks  10 images = 3000 blocks +10 Blocks
#define SD_START_BLOCKNO_EVENT_ICON  0x2A0BC2   //  IMAGE OF SIZE 16*16  	0x2A0834
//1 Block for 1 Event Icon 

 
#define SD_START_BLOCKNO_ICON  0x2B0000   // Start block no 6001 . iCON OF SIZE 64 X 60  grid ICon
//.FOR 64000 CARDS IT TAKES ARROUND 25 Mb OF SIZE and 256000 pages for per user 4 Template 
// For User Image of 80x80 we need arround 1.1 Gb Size 
//for 1Lac Template it Takes 49 Mb and 10Lack template 489MB

//  Default 4 GB pendrive 
// 1 GB for Transaction 
//then Icons 0.5 Gb 
//after image we have to add icons ...
#define SD_START_BLOCK_TEMPLATE		0x300000		//start location to store template
// for 76000 user = 76000*8 template or page  = 76000*8/2 = 304000kb =304 mb -> reserve 500 mb  

// for image of 80*80
// it takes 80*80*2/512 no of pages result /2 kb/image = 12.5kb/image
// for 1 Lackuser it takes 1221 kb ie 1.22GB

#define SD_START_BLOCK_USERIMAGE	0x6567E0		//start location to store User Image 

//#define SD_END_RAW_DATA           0x7E7000 //  0x800000 for 4 Gb, 0x7E7000 is 50mb less than 0x800000

//#define TOTAL_SD_MEM				  0x3AF600	 // For 4 GB SD Card after Debugg we get
// This Size is in MByte
//#define LIMIT_SD_FATSYSTEM  0xEBD80   // NGD00027 // For 1GB        // to limit FAT File System for Text File 
// This Size is in MByte
//924 


/*-----------------------------------
Conclusion we will reserve 1Gb for trasaction from 1.5 gb to 1.9 Gb All icons 
from 2.1 gb to 2.2 Gb for Template from 2.5 to 3.8 for User Images 

1 GB has 2097152 pages*/

