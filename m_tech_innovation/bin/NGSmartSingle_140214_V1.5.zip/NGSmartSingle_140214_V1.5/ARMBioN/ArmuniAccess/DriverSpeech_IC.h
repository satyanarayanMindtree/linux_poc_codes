#include <LPC23xx.h>


#define SOUND_PIN_CS		0x00000080		// P0.7  SI065 1.1
#define SOUND_PIN_SCK		0x00000100		// P0.8
#define SOUND_PIN_DOUT		0x00000200	// P0.9\

//#DEFINE PIN_DIR_IO_SPEECH 	0x00000380
#define DIR_IO_SPEECH()  {FIO0DIR |= SOUND_PIN_CS | SOUND_PIN_SCK | SOUND_PIN_DOUT;}

#define SOUND_CLR_CS() 		{FIO0CLR |= SOUND_PIN_CS;}
#define SOUND_CLR_SCK() 	{FIO0CLR |= SOUND_PIN_SCK;}
#define SOUND_CLR_DOUT() 	{FIO0CLR |= SOUND_PIN_DOUT;}

#define SOUND_SET_CS() 		{FIO0SET |= SOUND_PIN_CS;}
#define SOUND_SET_SCK() 	{FIO0SET |= SOUND_PIN_SCK;}
#define SOUND_SET_DOUT() 	{FIO0SET |= SOUND_PIN_DOUT;}

// #define SOUND_CLR_CS() 		{FIO0DIR = SOUND_PIN_CS; FIO0CLR |= SOUND_PIN_CS;}
// #define SOUND_CLR_SCK() 	{FIO0DIR = SOUND_PIN_SCK; FIO0CLR |= SOUND_PIN_SCK;}
// #define SOUND_CLR_DOUT() 	{FIO0DIR = SOUND_PIN_DOUT; FIO0CLR |= SOUND_PIN_DOUT;}

// #define SOUND_SET_CS() 		{FIO0DIR = SOUND_PIN_CS; FIO0SET |= SOUND_PIN_CS;}
// #define SOUND_SET_SCK() 	{FIO0DIR = SOUND_PIN_SCK; FIO0SET |= SOUND_PIN_SCK;}
// #define SOUND_SET_DOUT() 	{FIO0DIR = SOUND_PIN_DOUT; FIO0SET |= SOUND_PIN_DOUT;}

#define AUTHERISED 				    0
#define NOT_AUTHERISED 				1
#define PLACE_FINGER	 			2
#define FINGER_VERIFIED				3
#define FINGER_NOT_VERIFIED			4
#define DOTL						5
#define DOOR_FORCEOPEN				6
#define APB_ERROR					7
#define TODAY_EARLY					8
#define TODAY_LATE					9
#define HAPPY_BIRHDAY				10
#define FIRE_ALARM					11
#define TIMEZONE_ERROR				12 
#define INVALID_PIN			    	13 
#define CARD_EXPIRED			    14 
#define HOLIDAY_NO_ACESS		    15 

extern unsigned int  SoundDelay_10;

extern void InitSoundIC(void);
extern void SoundDelay(unsigned int count);
extern void waitX10ms(unsigned int i);
extern void PlaySoundMsg(unsigned char SoundNum);   //hw pin driver
extern void SendSerialByte(unsigned char byte);
extern void SendSerialCmd1(unsigned char cmd); 
extern void SendSerialCmd2(unsigned char cmd,unsigned char dat);
