#ifndef __TEMPLATEONFLASH_H
#define __TEMPLATEONFLASH_H


/*** BeginHeader Variables*/
#define NO_TEMPLATE_TO_DELETE	-1
#define NO_TEMPLATE_FOUND		-1

/*-----------------------------------------------------------------------------------------*/
#define TEMPLATE_OFFSET				10    // we add max template in sensor  = MAX templateSensor Support - TEMPLATE_OFFSET
#define MAX_TEMPLATE_SD_PERUSER		8
#define MAX_TEMPLATE_SIZE  	384
#define MAX_TEMPLATES				(MAX_NO_OF_CARD*MAX_TEMPLATE_SD_PERUSER)

/*-----------------------------------------------------------------------------------------*/
/* Following is sotred in different location in memory [ in seconf Flash memory]
If Card number is Zero we will assume that no templete is stored at that Location */

/*-----------------------------------------------------------------------------------------*/
// __packed struct TEMPLATE_DATA		 //  384 +9 =  393
// {
// 	CARDNO_DATA_STORAGE_TYPE CardNo;  		//4
// 	unsigned short TemplateSize;				//4
// 	unsigned char TemplateNo;				//1
// 	unsigned char TemplateData[MAX_TEMPLATE_SIZE]; //1
// };

__packed  struct SD_TEMPLATE_DATA		
{
	unsigned short TSZ;				// 2
	CARDNO_DATA_STORAGE_TYPE CardNo;
	short ChkSum;
	unsigned char dummy[2];		  // for future use reserve 2 byte 
	unsigned char TData[502];     //502
};

extern struct  SD_TEMPLATE_DATA	SDtemplateinfo;
/*-----------------------------------------------------------------------------------------*/
/* Following function will be used to store template info for that card
This will be saved in memory same as card data with same index number like name is stored */
/*-----------------------------------------------------------------------------------------*/
__packed typedef struct CARD_TEMPLATE_INFO	//10
{
	unsigned short NoOfTemp;		//2
	unsigned short TLoc[4];		   	//8
}_CTemplateInfo;
/*-----------------------------------------------------------------------------------------*/
//#define TEMPLATE_DATA_BYTES 		sizeof(struct TEMPLATE_DATA)
//#define CARD_TEMPLATE_INFO_BYTES 	sizeof(	_CTemplateInfo)
/*-----------------------------------------------------------------------------------------*/

/* Following struct will be used to store extra info for that card
This will be saved in memory same as card data (i.e. flash)with same index number */
/*-----------------------------------------------------------------------------------------*/

__packed typedef struct CARD_EXTRA_INFO	 // 30  
{
	unsigned char Name[CARD_NAME_BYTES];//16
	time_t JoiningDate;    //4
	unsigned char BirthDate; // 1
	unsigned char BirthMonth;// 1
	unsigned char TemplateData;//1 //bit wise for checking template no 0000 1111 means 4 template on SD  
	time_t AccessDate;//4
	unsigned char Image_TemplateSD_Flag; /// LSB  4  for template on sd or sensor msb 4 bit for image is available or not  
	unsigned short dummy;  //2 future purpose 
}_CExtraInfo;


//extern struct  CARD_EXTRA_INFO tExtInfo;
//32	
#define FIRST_TEMPLATE  	0x01 	// 00000001b
#define SECOND_TEMPLATE 	0x02   //00000010b
#define THIRD_TEMPLATE  	0x04   //00000100b
#define FOURTH_TEMPLATE 	0x08   // 
#define FIFTH_TEMPLATE  	0x10
#define SIXTH_TEMPLATE  	0x20
#define SEVENTH_TEMPLATE	0x40
#define EIGHTH_TEMPLATE  	0x80
/*-----------------------------------------------------------------------------------------*/

#define CARD_EXTRA_DATA_BYTES 		(sizeof(struct CARD_EXTRA_INFO))  //32
#define CARD_XTRA_DATA_PER_PAGE		((BYTE)(FLSH_APP_PAGE_SZ/CARD_EXTRA_DATA_BYTES))  //NOof card in a page  16
#define EXDATA_CARDS_PERPAGE        (FLSH_APP_PAGE_SZ/ CARD_EXTRA_DATA_BYTES)    

#define GET_CARD_XTRA_DATA_PAGE_NUMBER_FROMINDEX(index) 		(FL_CARD_EXTRA_DATA_PAGE_NO + (unsigned int)(index/CARD_XTRA_DATA_PER_PAGE))
#define GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_INDEX(index) 	(index%CARD_XTRA_DATA_PER_PAGE)
#define GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_BYTE(index) 	(GET_CARD_XTRA_DATA_POSITION_IN_PAGE_FROM_INDEX(index)*CARD_EXTRA_DATA_BYTES)
#define MAX_PAGES_OF_EXTRA_CARD_DATA 							((MAX_NO_OF_CARD/CARD_XTRA_DATA_PER_PAGE + 1))

/*-----------------------------------------------------------------------------------------*/
extern _CExtraInfo tExtInfo;
extern int AddTemplateToSD( struct SD_TEMPLATE_DATA SDtemplateinfo, unsigned int cardindex,unsigned char Tno);
extern unsigned char ReadTemplateFromSD(unsigned int tindex,struct SD_TEMPLATE_DATA *tmpinfobuff,unsigned char tno);
extern int SearchTemplateFromSD(CARDNO_DATA_STORAGE_TYPE cno,char tno);
extern char DelAllTempletSD(void);

extern int TestingFlash(unsigned int guintBlockNum);
extern void TestFlash(void);

extern int AddCardTemplateInfoToFlash0(unsigned int cardindex,unsigned int tindex,unsigned char tno);
extern unsigned char ReadCardTemplateInfoFromFlash(unsigned int cardindex,_CExtraInfo  *ExtInfoBuff);
extern void DelAllCardTemplateInfoFromFlash(void);
extern int AddCardTemplateInfoToFlash(unsigned int cardindex,_CExtraInfo  *ExtInfoBuff);
extern int DelTempletSD(unsigned int cardindex);
extern int DelCardTemplateInfoFromFlash(unsigned int cardindex);
//==============================================================================================================================
//General Errors Defination 
#define ERR_TEMPLATE_EXCEEDS	10
#define ERR_SD_WRITE FAIL		11
#define ERR_SD_READ_FAIL        12 
#define ERR_FLASH_WRITEFAIL     13  
#define ERR_FLASH_FULL			14	

#endif  //#ifndef __TRANXMGMT_H




