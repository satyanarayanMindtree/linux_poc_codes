#ifdef WEI_DEF
#define EXTERN_WEI   
#else

#define EXTERN_WEI	extern

#endif

#define WEI_OUT_26BIT	26
#define WEI_OUT_32BIT	32
#define WEI_OUT_34BIT	34

#define WEI_SAME_AS_WEI_IN	0x80

#define ENABLE_INTERRUPT()	
#define DISABLE_INTERRUPT()	

extern unsigned char F_WeigandAccesGrantedCheck;

extern void SendWeigandData(struct USER_CARD_INFO *empcard,unsigned char weiin);
extern void SendToWeigend(unsigned char *cardno);
extern void SendToWeigend34(unsigned char *cardno);
extern unsigned char CardArry[4];
extern void SendTransparentWeigendData(void);
