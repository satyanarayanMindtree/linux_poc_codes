/****************************************************************************
 *   uart.c:  UART API file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.12  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "LPC23xx.h"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "target.h"
#include "irq.h"
#include "rtc.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"

#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "smartcard.h"
#include "INOUT.h"
#include "rdpoll.h"
#ifdef ENABLE_SLAVE_SUPPORT            //FA00090
#include "TransparentSlave.h"
#endif
#ifdef ENABLE_GSM_GPRS
#include "GSMModem.h"
#endif
#include "TcpPush.h"
#include"wdt.h"
/*------------------------------------------------------------------*/
//Local variable
volatile WORD UART0Status, UART1Status,Dummy;
volatile BYTE UART0TxEmpty = 1, UART1TxEmpty = 1;
volatile WORD UART2Status, UART3Status;
volatile BYTE UART2TxEmpty = 1, UART3TxEmpty = 1;
unsigned char BioBuffer[BIO_BUFFER_LENGTH];


//unsigned char TcpSendBuffer[1024];//removed to save RAM
unsigned char UdpSendBuffer[1024+sizeof(UDP_HEADER)]; //UDP and TCP protocol uses this buffer
unsigned char UdpPushSendBuffer[1024+sizeof(UDP_HEADER)];
#ifdef	ENABLE_EMAIL_SEND
unsigned char EmailSendBuffer[1024];
#endif

//unsigned char TcpPushSendBuffer[1024]; //removed not in use

//External Varible

extern SYSInfo SysInfo;

extern SerPort PortObj[MAX_SER_PORT];

extern volatile BYTE SBuffer[BUFSIZE];

extern volatile WORD ReceiveCount, UART1Count,ToReceiveCount;
extern volatile WORD UART2Count, UART3Count;

extern volatile BYTE F_Receiver_Data ,F_Check_Slave_No,F_Receive_Serial_Data,F_Global_Command,F_Get_Slave_Data;
extern volatile BYTE F_SerialCommandProxy,F_secsend,F_TransCrossOver,F_EthernetReceived;


extern BYTE F_CheckSum,F_CheckSumC,F_CheckSumD,F_CheckSumE,F_CheckSumB;
extern WORD ReceiveCountSERPC;
extern BYTE CheckSumE,CheckSumC,CheckSumD,CheckSumB,CheckSum;


extern  BYTE  SmartCardTimeOut;
extern  char SCError;

extern  BYTE  SCReaderNo;
extern  BYTE F_SerialSmartCardPollProxy;
extern volatile BYTE F_MainLoopGPRSHandle;

extern BYTE F_SerialECheckSum,F_SMARTCardFound;
extern  char SMARTReaderNo,SerialECheckSum;
extern  WORD SerialEReceiveCount;
extern struct DOOR_INFO Doorinfo;
extern char F_SerialICRProxy,ICRTimeOut,gReccount;
#define USE_UART2	0x01000000		//PCONP.24
#define USE_UART3	0x02000000		//PCONP.25



void (*SerialHandler[MAX_SER_PORT+1])(unsigned char port);//array of function pointers
void DummyHandle(unsigned char port);

/*****************************************************************************
** Function name:		UART0Handler
**
** Descriptions:		UART0 interrupt handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/

void SerIntPCHandle(unsigned char port)
{
		F_Receiver_Data = SET;
		if(Dummy == STX)
		{
			F_Check_Slave_No = SET;
			F_Receive_Serial_Data = CLR;
			F_Global_Command = CLR;
			ReceiveCount = 0;
#ifdef ENABLE_GSM_GPRS
			GPRSNoDataTime = 0;
#endif
			F_Get_Slave_Data = 1;
		}
		else if(F_Check_Slave_No)
		{
			if(ReceiveCount == 0)
			{
				SBuffer[ReceiveCount] = Dummy;
				if(SysInfo.MySlaveNo == (SBuffer[0]- CNTRBASEADD))
				{
					F_Receive_Serial_Data = SET;
				}
			#ifdef ENABLE_SLAVE_SUPPORT
	            else if(((Doorinfo.PollSlaveNo == (SBuffer[ReceiveCount] - CNTRBASEADD)) || (Doorinfo.PollSlaveNo == 0)) && (Doorinfo.EnDisTransparentMode == 1))
	            {
	               F_PollSlave_Serial_Data = SET;
				  // HandleSlaveSerialData(Dummy);
	            }
            #endif
				if(SBuffer[ReceiveCount]== GLOBAL_COMMAND)
				{
					F_Receive_Serial_Data = SET;
				    #ifdef ENABLE_SLAVE_SUPPORT
	                   if((Doorinfo.PollSlaveNo == 0) && (Doorinfo.EnDisTransparentMode == 1))
	                   F_PollSlave_Serial_Data = SET;
                    #endif
					F_Global_Command = SET;
				}
				F_Check_Slave_No = CLR;
				ReceiveCount = ReceiveCount + 1;
//	            abort;
			}
		}
		else if(F_Receive_Serial_Data)
		{
			if((Dummy == ETX)||(Dummy == ETX1))
			{
				F_SerialCommandProxy = SET;
				if(port == PC_PORT)
				{
					F_SerialCommandProxy = 1;
				}
				else if(port == MODEM_PORT)
				{
					F_SerialCommandProxy = 3;
				}
				else
				{}
				ToReceiveCount = ReceiveCount;
				SBuffer[ReceiveCount] = Dummy;
				SBuffer[ReceiveCount+1] = '\0';
				ReceiveCount = 0;
			#ifdef ENABLE_SLAVE_SUPPORT
		       if(F_PollSlave_Serial_Data == SET)
		       {
                   F_SerialPollSlaveProxy = SET;
                   F_PollSlave_Serial_Data = CLR;
               }
              #endif
				F_EthernetReceived = CLR;
				F_Receive_Serial_Data = CLR;
//	            abort;
			}
            else
            {
				SBuffer[ReceiveCount] = Dummy;
				ReceiveCount ++;
            }
		}
#ifdef ENABLE_SLAVE_SUPPORT
      else if(F_PollSlave_Serial_Data)
      {
         if(Dummy == ETX)
        {
            F_SerialPollSlaveProxy = SET;
            ToReceiveCount = ReceiveCount;
            SBuffer[ReceiveCount] = Dummy;
            SBuffer[ReceiveCount+1] = '\0';
            ReceiveCount = 0;
            F_PollSlave_Serial_Data = CLR;
         
        }
         else
         {
            SBuffer[ReceiveCount] = Dummy;
            ReceiveCount ++;
		 }
      }
#endif
}
#ifdef ENABLE_GSM_GPRS
void SerIntGPRSModemHandle(unsigned char port)
{
//	if(F_ReceiveGPRSPortData == CLR)
//	{
//		PortObj[port].RxBuffer[PortObj[port].RxPtr] = Dummy;
//		PortObj[port].RxPtr = 1;	
//	   	F_ReceiveGPRSPortData = SET;           
//	}
//	else if(F_ReceiveGPRSPortData == SET)		MODEM_PORT	   PC_PORT
	SerIntPCHandle(MODEM_PORT);//call pc serial port handler to handle serial commands
	//this stores data in sbuffer[] 
	{
		if( PortObj[port].RxPtr >= PortObj[port].MAXINBUF)
		{
			PortObj[port].RxPtr= PortObj[port].MAXINBUF;
			F_ReceiveGPRSPortData = CLR;
			PortObj[port].F_SerProxy = SET;
		}
		else
		{
			PortObj[port].RxBuffer[PortObj[port].RxPtr] = Dummy;
			PortObj[port].RxPtr ++;
		}
		if((Dummy == SMART_TERMINATOR1) || (Dummy == SMART_TERMINATOR2))
		//if(Dummy == SMART_TERMINATOR2)
		{  
//			if(PortObj[port].RxPtr >2)
//			{
				PortObj[port].F_SerProxy = SET;
//				F_ReceiveGPRSPortData = CLR;
//				PortObj[port].RxBuffer[PortObj[port].RxPtr] = '\0';
				F_ModemDataProxy = SET;
//			}
		}
	}
}
#endif	//#ifdef ENABLE_GSM_GPRS
#ifdef SMART_CARD
#ifdef SUPPORT_ICLASS_RDR	
void SerIntIClassCardHandle(unsigned char port)
{
	 if(F_SerialICRProxy == CLR)
	 {
			 if(PortObj[port].RxPtr >= MAX_ICR_SER_BUFF)
			 {
					PortObj[port].RxPtr = MAX_ICR_SER_BUFF;
					F_SerialICRProxy = CLR;
			 }
			 else
			 {
					PortObj[port].RxBuffer[PortObj[port].RxPtr] = Dummy;
					PortObj[port].RxPtr ++;
					
			 }
	 }
}
#else

void SerIntSmartCardHandle(unsigned char port)
{
	if(Dummy == SMART_START_RESPONSE_CHAR)
	{
		PortObj[port].RxPtr = 0;
		PortObj[port].RxBuffer[PortObj[port].RxPtr] = Dummy;
		PortObj[port].RxPtr = 1;	
	   	PortObj[port].F_SerProxy = CLR;
	   	F_ReceiveSmartCardPortData = SET;           
	}
	else if(F_ReceiveSmartCardPortData == SET)
	{
		if(PortObj[port].RxPtr >= PortObj[port].MAXINBUF)
		{
			PortObj[port].RxPtr = PortObj[port].MAXINBUF;
			F_ReceiveSmartCardPortData = CLR;
			PortObj[port].F_SerProxy = SET;
		}
		else
		{
			PortObj[port].RxBuffer[PortObj[port].RxPtr] = Dummy;
			PortObj[port].RxPtr ++;
		}
		if((Dummy == SMART_TERMINATOR1) || (Dummy == SMART_TERMINATOR2))
		{  
			PortObj[port].F_SerProxy = SET;
			F_ReceiveSmartCardPortData = CLR;
		}
	}
}
#endif //else SUPPORT_ICLASS_RDR

#endif	//#ifdef SMART_CARD

void UART0Handler (void) __irq 
{
BYTE IIRValue, LSRValue;
//BYTE Dummy;;

//  IENABLE;				/* handles nested interrupt */	
	IIRValue = U0IIR;
	
	IIRValue >>= 1;			/* skip pending bit in IIR */
	IIRValue &= 0x07;			/* check bit 1~3, interrupt identification */
	if(IIRValue == IIR_RLS)		/* Receive Line Status */
	{
		LSRValue = U0LSR;
		/* Receive Line Status */
		if(LSRValue & (LSR_OE|LSR_PE|LSR_FE|LSR_RXFE|LSR_BI))
		{
			/* There are errors or break interrupt */
			/* Read LSR will clear the interrupt */
			UART0Status = LSRValue;
			Dummy = U0RBR_THR;		/* Dummy read on RX to clear 
								interrupt, then bail out */
//			IDISABLE;
			VICVectAddr = 0;		/* Acknowledge Interrupt */
			return;
		}
	}
	else if(IIRValue == IIR_RDA)	/* Receive Data Available */
	{
		/* Receive Data Available */
		Dummy = U0RBR_THR;	

// #ifdef INSERT_SDCARD
// 	UART0Buffer[UART0Count] = U0RBR_THR;   // U0RBR;
// 	U0DataPending++;
// 	UART0Count++;
// 	if ( UART0Count == UARTBUFSIZE )
// 	{
// 	  UART0Count = 0;		/* buffer overflow */
// 	}
// #endif	
		
//			SerIntPCHandle(0);
//#ifdef	SMART_CARD
//		SerIntSmartCardHandle(0);
//#else
//	#ifdef ENABLE_GSM_GPRS 
//		SerIntGPRSModemHandle(0);
//	#else
//		SerIntPCHandle(0);
//	#endif
//#endif
		SerialHandler[0](0);
	
	}
	else if(IIRValue == IIR_CTI)	/* Character timeout indicator */
	{
		/* Character Time-out indicator */
		UART0Status |= 0x100;		/* Bit 9 as the CTI error */
	}
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		UART1Handler
**
** Descriptions:		UART1 interrupt handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void UART1Handler (void) __irq 
{
BYTE IIRValue, LSRValue;
//BYTE Dummy;

//	IENABLE;				/* handles nested interrupt */	
	IIRValue = U1IIR;
	
	IIRValue >>= 1;			/* skip pending bit in IIR */
	IIRValue &= 0x07;			/* check bit 1~3, interrupt identification */
	if(IIRValue == IIR_RLS)		/* Receive Line Status */
	{
		LSRValue = U1LSR;
		/* Receive Line Status */
		if(LSRValue & (LSR_OE|LSR_PE|LSR_FE|LSR_RXFE|LSR_BI))
		{
			/* There are errors or break interrupt */
			/* Read LSR will clear the interrupt */
			UART1Status = LSRValue;
			Dummy = U1RBR_THR;		/* Dummy read on RX to clear 
								interrupt, then bail out */
//			IDISABLE;
			VICVectAddr = 0;		/* Acknowledge Interrupt */
			return;
		}
	}
	else if(IIRValue == IIR_RDA)	/* Receive Data Available */
	{
		/* Receive Data Available */
		Dummy = U1RBR_THR;

		SerialHandler[1](1);
		
// 	#ifdef ENABLE_SLAVE_SUPPORT
// 		if(Doorinfo.EnDisTransparentMode == 0x01)
// 		{
// 		if(F_Get_Slave_Data==1)	//ARMD0334 get data from slave only if command sent from master.
// 		                        //avoid data thrown by slave on startup.
// 			HandleSlaveSerialData(Dummy);
// 		}//if(Doorinfo.EnDisTransparentMode == 0x01)
// 	#endif
		
/*#ifndef BIO_METRIC
        if(Dummy == SMART_START_RESPONSE_CHAR)
    	{
			F_ReceiveSlaveCardPortData = SET;
			PortObj[SER_SLAVE_PORT].RxPtr = 0;
	    }
       	if(F_ReceiveSlaveCardPortData == SET)
        {
			if(PortObj[SER_SLAVE_PORT].RxPtr >= MAX_SLAVE_SER_BUFF)
			{
				PortObj[SER_SLAVE_PORT].RxPtr = MAX_SMART_SER_BUFF - 1;
				F_ReceiveSlaveCardPortData = CLR;
				F_SerialSlaveDataProxy = SET;
			}
			else
			{
				SlaveSerBuffer[PortObj[SER_SLAVE_PORT].RxPtr] = Dummy;
				PortObj[SER_SLAVE_PORT].RxPtr ++;
			}
			if((Dummy == SLAVE_TERMINATOR1) || (Dummy == SLAVE_TERMINATOR2))
			{  
				F_SerialSlaveDataProxy = SET;
				F_ReceiveSlaveCardPortData = CLR;
			}
		}
#else */
//		UARTSendByte(1,Dummy);		 //Send echo  
//#endif
	}
	else if(IIRValue == IIR_CTI)	/* Character timeout indicator */
	{
		UART1Status |= 0x100;		/* Bit 9 as the CTI error */
	}
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}


/*****************************************************************************
** Function name:		UART2Handler
**
** Descriptions:		UART2 interrupt handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void UART2Handler (void) __irq 
{
BYTE IIRValue, LSRValue;
BYTE Dummy = Dummy;
	
	//IENABLE;				/* handles nested interrupt */	
	IIRValue = U2IIR;
	
	IIRValue >>= 1;			/* skip pending bit in IIR */
	IIRValue &= 0x07;			/* check bit 1~3, interrupt identification */
	if(IIRValue == IIR_RLS)		/* Receive Line Status */
	{
		LSRValue = U2LSR;
		/* Receive Line Status */
		if(LSRValue & (LSR_OE|LSR_PE|LSR_FE|LSR_RXFE|LSR_BI))
		{
			/* There are errors or break interrupt */
			/* Read LSR will clear the interrupt */
			UART2Status = LSRValue;
			Dummy = U2RBR_THR;		/* Dummy read on RX to clear 
								interrupt, then bail out */
//			IDISABLE;
			VICVectAddr = 0;		/* Acknowledge Interrupt */
			return;
		}
//		if(LSRValue & LSR_RDR)	/* Receive Data Ready */			
//		{
//			/* If no error on RLS, normal ready, save into the data buffer. */
//			/* Note: read RBR will clear the interrupt */
//			UART2Buffer[UART2Count] = U2RBR_THR;
//			UART2Count++;
//			if(UART2Count == BUFSIZE)
//			{
//				UART2Count = 0;		/* buffer overflow */
//			}	
//		}
	}
	else if(IIRValue == IIR_RDA)	/* Receive Data Available */
	{
		Dummy = U2RBR_THR;
//		if(DeabugLevel)
//			printf("%x",Dummy);
#ifdef BIO_METRIC
		if(PortObj[SER_BIO_PORT].RxPtr == 0)
		{
			if(Dummy == BIO_START_CMD)
			{
				PortObj[SER_BIO_PORT].RxBuffer[PortObj[SER_BIO_PORT].RxPtr] = Dummy;
				PortObj[SER_BIO_PORT].RxPtr = 1;
			}
		}
		else if(F_Template_Download == SET)
		{
			PortObj[SER_BIO_PORT].RxBuffer[PortObj[SER_BIO_PORT].RxPtr] = Dummy;
			PortObj[SER_BIO_PORT].RxPtr ++;
			if(PortObj[SER_BIO_PORT].RxPtr == BIO_REC_PACKET_SIZE)
#ifdef SUPPORT_SUPREMA
				BioCmdSize = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+5] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+6]*0x100;
#else
				BioCmdSize = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+11] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+12]*0x100;
#endif
//			tmpdata = PortObj[SER_BIO_PORT].RxPtr; 
#ifdef SUPPORT_SUPREMA
			if((PortObj[SER_BIO_PORT].RxPtr >= (BioCmdSize+BIO_REC_PACKET_SIZE+BIO_REC_PACKET_SIZE_2)) || (PortObj[SER_BIO_PORT].RxPtr >= PortObj[SER_BIO_PORT].MAXINBUF))
#else
			if((PortObj[SER_BIO_PORT].RxPtr >= (BioCmdSize+BIO_REC_PACKET_SIZE)) || (PortObj[SER_BIO_PORT].RxPtr >= PortObj[SER_BIO_PORT].MAXINBUF))
#endif
				F_SerialCommandBio = SET;
		}
		else if(F_Template_Download == 2)
		{
			PortObj[SER_BIO_PORT].RxBuffer[PortObj[SER_BIO_PORT].RxPtr] = Dummy;
			PortObj[SER_BIO_PORT].RxPtr ++;
			if(PortObj[SER_BIO_PORT].RxPtr == BIO_REC_PACKET_SIZE + BIO_REC_PACKET_SIZE_2)
#ifdef SUPPORT_SUPREMA
				BioCmdSize = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+5+15] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+6+15]*0x100;
//			BioCmdSize = 384;
#else
				BioCmdSize = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+11] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+12]*0x100;
#endif
//			tmpdata = PortObj[SER_BIO_PORT].RxPtr; 
#ifdef SUPPORT_SUPREMA
			if((PortObj[SER_BIO_PORT].RxPtr >= (BioCmdSize+BIO_REC_PACKET_SIZE+BIO_REC_PACKET_SIZE_2)) || (PortObj[SER_BIO_PORT].RxPtr >= PortObj[SER_BIO_PORT].MAXINBUF))
#else
			if((PortObj[SER_BIO_PORT].RxPtr >= (BioCmdSize+BIO_REC_PACKET_SIZE)) || (PortObj[SER_BIO_PORT].RxPtr >= PortObj[SER_BIO_PORT].MAXINBUF))
#endif
					F_SerialCommandBio = SET;
		}
		else
		{
			PortObj[SER_BIO_PORT].RxBuffer[PortObj[SER_BIO_PORT].RxPtr] = Dummy;
			PortObj[SER_BIO_PORT].RxPtr++;
			if(PortObj[SER_BIO_PORT].RxPtr >= BIO_REC_PACKET_SIZE)
			{   
				PortObj[SER_BIO_PORT].RxPtr = BIO_REC_PACKET_SIZE;
				F_SerialCommandBio = SET;
			}
		}
#else
		UARTSendByte(2,Dummy);			//Send echo
#endif
	}
	else if(IIRValue == IIR_CTI)	/* Character timeout indicator */
	{
		/* Character Time-out indicator */
		UART2Status |= 0x100;		/* Bit 9 as the CTI error */
	}
//	else if(IIRValue == IIR_THRE)	/* THRE, transmit holding register empty */
//	{
//		/* THRE interrupt */
//		LSRValue = U2LSR;		/* Check status in the LSR to see if
//								valid data in U0THR or not */
//		if(LSRValue & LSR_THRE)
//		{
//			UART2TxEmpty = 1;
//		}
//		else
//		{
//			UART2TxEmpty = 0;
//		}
//	}
//	IDISABLE;
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		UART3Handler
**
** Descriptions:		UART3 interrupt handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void UART3Handler (void) __irq 
{
BYTE IIRValue, LSRValue;
//BYTE Dummy = Dummy;

//	IENABLE;				/* handles nested interrupt */	
	IIRValue = U3IIR;
	
	IIRValue >>= 1;			/* skip pending bit in IIR */
	IIRValue &= 0x07;			/* check bit 1~3, interrupt identification */
	if(IIRValue == IIR_RLS)		/* Receive Line Status */
	{
//		LSRValue = U1LSR;
		LSRValue = U3LSR;
		/* Receive Line Status */
		if(LSRValue & (LSR_OE|LSR_PE|LSR_FE|LSR_RXFE|LSR_BI))
		{
			/* There are errors or break interrupt */
			/* Read LSR will clear the interrupt */
			UART3Status = LSRValue;
			Dummy = U3RBR_THR;		/* Dummy read on RX to clear 			
								interrupt, then bail out */
//			IDISABLE;
			VICVectAddr = 0;		/* Acknowledge Interrupt */
			return;
		}
//		if(LSRValue & LSR_RDR)	/* Receive Data Ready */			
//		{
//			/* If no error on RLS, normal ready, save into the data buffer. */
//			/* Note: read RBR will clear the interrupt */
//			UART3Buffer[UART3Count] = U3RBR;
//			UART3Count++;
//			if(UART3Count == BUFSIZE)
//			{
//				UART3Count = 0;		/* buffer overflow */
//			}	
//		}
	}
	else if(IIRValue == IIR_RDA)	/* Receive Data Available */
	{
		/* Receive Data Available */
		Dummy = U3RBR_THR;
//		UART3Buffer[UART3Count] = Dummy;
		
		SerialHandler[3](3); // WE 

//		UART3Count++;
//		if(UART3Count == BUFSIZE)
//		{
//			UART3Count = 0;		/* buffer overflow */
//		}
	}
	else if(IIRValue == IIR_CTI)	/* Character timeout indicator */
	{
		/* Character Time-out indicator */
		UART3Status |= 0x100;		/* Bit 9 as the CTI error */
	}
//  else if(IIRValue == IIR_THRE)	/* THRE, transmit holding register empty */
//  {
//	/* THRE interrupt */
//	LSRValue = U3LSR;		/* Check status in the LSR to see if
//								valid data in U0THR or not */
//	if(LSRValue & LSR_THRE)
//	{
//	  UART3TxEmpty = 1;
//	}
//	else
//	{
//	  UART3TxEmpty = 0;
//	}
//  }
//  IDISABLE;
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		UARTInit
**
** Descriptions:		Initialize UART0 port, setup pin select,
**						clock, parity, stop bits, FIFO, etc.
**
** parameters:			portNum(0 or 1) and UART baudrate
** Returned value:		true or false, return false only if the 
**						interrupt handler can't be installed to the 
**						VIC table
** 
*****************************************************************************/
short UARTInit(BYTE PortNum,unsigned int baudrate,BYTE parity)
{
DWORD Fdiv;

  switch(PortNum)
  {
  	case 0:
		PINSEL0 |= 0x00000050;       /* RxD0 and TxD0 */
//		PINSEL1 |= 0x00000000;
//		IODIR0	|= 0x02000000;
//		IOPIN0 |= 0x02000000;
//		PORT0232()
		if(parity ==0)
			U0LCR = 0x83;		/* 8 bits, no Parity, 1 Stop bit, DLAB = 1 */
		else if (parity ==2)
			U0LCR = 0x9f;		/* 8 bits, Even Parity, 2 Stop bits, DLAB = 1*/

		Fdiv = (Fpclk / 16) / baudrate;	/*baud rate */
	    U0DLM = Fdiv / 256;							
	    U0DLL = Fdiv % 256;
		if(parity ==0)
			U0LCR = 0x03;		/* DLAB = 0 */
		else if (parity ==2)
			U0LCR = 0x1f;		/* DLAB = 0 , Even Parity,*/

		U0FCR = 0x07;		/* Enable and reset TX and RX FIFO. */
	
	    if(install_irq(UART0_INT,(void *)UART0Handler,HIGHEST_PRIORITY) == FALSE)
	    {
			return (FALSE);
	    }
	    U0IER = IER_RBR | IER_RLS;	/* Enable UART0 interrupt */
	    break;

	case 1:
  		PINSEL4 |= 0x0000000A;	/* Enable TxD1 P2.0 */
//		PINSEL1 |= 0x00000001;	/* Enable RxD1 P2.1 */
	    U1LCR = 0x83;		/* 8 bits, no Parity, 1 Stop bit */
	    Fdiv = (Fpclk / 16) / baudrate;	/*baud rate */
	    U1DLM = Fdiv / 256;							
	    U1DLL = Fdiv % 256;
		U1LCR = 0x03;		/* DLAB = 0 */
	    U1FCR = 0x07;		/* Enable and reset TX and RX FIFO. */
//		Disable interrupt for polling mode
	    if(install_irq(UART1_INT,(void *)UART1Handler,HIGHEST_PRIORITY) == FALSE)
	    {
				return (FALSE);
	    }
	    U1IER = IER_RBR | IER_RLS;	/* Enable UART1 interrupt */
	    break;

	case 2:
		PCONP |= USE_UART2; 		// Turn on UART2 power
	 	PINSEL0 |= 0x00500000;       /* for RxD2 and TxD2  P0.10 P0.11*/ 
		PCONP   |= 0x01000000;  // UART2 Power-ON
	    U2LCR = 0x83;		/* 8 bits, no Parity, 1 Stop bit */
	    Fdiv = (Fpclk / 16) / baudrate;	/*baud rate */
	    U2DLM = Fdiv / 256;							
	    U2DLL = Fdiv % 256;
		U2LCR = 0x03;		/* DLAB = 0 */
	    U2FCR = 0x07;		/* Enable and reset TX and RX FIFO. */
//		Interrupt are diseable to use in pollmode	
	    if(install_irq(UART2_INT,(void *)UART2Handler,HIGHEST_PRIORITY) == FALSE)
	    {
			return (FALSE);
	    }
	    U2IER = IER_RBR | IER_RLS;	/* Enable UART2 interrupt */
	    break;

	case 3:
//		PCONP |= USE_UART3; 		// Turn on UART3 power
		PINSEL0 &= 0xFFFFFFF0; 
//		PINSEL0 |= 0x00000005;       /* for RxD3 and TxD3   P0.0,P0.1*/
		PINSEL0 |= 0x00000002;  // Select P0.0 = TxD(UART3) 
		PINSEL0 |= 0x00000008;  // Select P0.1 = RxD(UART3) 
		PCONP   |= 0x02000000;        // power on uart 3
	    
		U3LCR = 0x83;		/* 8 bits, no Parity, 1 Stop bit */
	    Fdiv = (Fpclk / 16) / baudrate ;	/*baud rate */
	    U3DLM = Fdiv / 256;							
	    U3DLL = Fdiv % 256;
		U3LCR = 0x03;		/* DLAB = 0 */
	    U3FCR = 0x07;		/* Enable and reset TX and RX FIFO. */
	    if(install_irq(UART3_INT,(void *)UART3Handler,HIGHEST_PRIORITY) == FALSE)
	    {
			return (FALSE);
	    }
	    U3IER = IER_RBR | IER_RLS;	/* Enable UART3 interrupt */
	    break;
	}
	return(TRUE);
}

/*****************************************************************************
** Function name:		UARTSend
**
** Descriptions:		Send a block of data to the UART 0 port based
**						on the data length
**
** parameters:			portNum, buffer pointer, and data length
** Returned value:		None
** 
*****************************************************************************/
void UARTSend(DWORD portNum, BYTE *BufferPtr, DWORD Length)
{
	switch(portNum)
	{
		case 0:
			while(Length != 0)
		    {
			  /* THRE status, contain valid data */
//				while ( !(UART0TxEmpty & 0x01) );	
				while(!(U0LSR & 0x20));
					U0RBR_THR = *BufferPtr;
				BufferPtr++;
				Length--;
			}
			break;
		case 1:
			while(Length != 0)
			{
			/* THRE status, contain valid data */
//				while ( !(UART1TxEmpty & 0x01) );	
				while(!(U1LSR & 0x20));
					U1RBR_THR = *BufferPtr;
				BufferPtr++;
				Length--;
			}
			break;
		case 2:
			while(Length != 0)
			{
			/* THRE status, contain valid data */
//				while ( !(UART2TxEmpty & 0x01) );	
				while(!(U2LSR & 0x20));
					U2RBR_THR = *BufferPtr;
				BufferPtr++;
				Length--;
			}
			break;
		case 3:
			while(Length != 0)
			{
			/* THRE status, contain valid data */
//				while ( !(UART3TxEmpty & 0x01) );	
				while(!(U3LSR & 0x20));
					U3RBR_THR = *BufferPtr;
				BufferPtr++;
				Length--;
			}
			break;		
	}
	return;
}

/*****************************************************************************
** Function name:		UARTSend Byte
**
** Descriptions:		Send a Byte of data to the UARTS port 
**
** parameters:			portNum and data 
** Returned value:		None
** 
*****************************************************************************/
void UARTSendByte(BYTE portNum, BYTE data)
{
	switch(portNum)
	{
	 	case 0:
			while(!(U0LSR & 0x20));
  			U0RBR_THR = data;
			break;
		case 1:
			while(!(U1LSR & 0x20));
  			U1RBR_THR = data;
			break;
		case 2:
			while(!(U2LSR & 0x20));
  			U2RBR_THR = data;
			break;
		case 3:
			while(!(U3LSR & 0x20));
	  		U3RBR_THR = data;
			break;
	}
	return;
}

/*****************************************************************************
** Function name:		UARTRead Byte
**
** Descriptions:		Read a Byte of data from the UARTS port 
**
** parameters:			portNum and data 
** Returned value:		None
** 
*****************************************************************************/
short serDgetc(void)                     /* Read character from Serial Port   */
{
BYTE data;
	while(!(U1LSR & 0x01));
		data = U1RBR_THR;
	U2FCR = 0x07;
	return(data);
}

/*****************************************************************************
** Function name:		UARTRead Byte
**
** Descriptions:		Read a Byte of data from the UARTS port 
**
** parameters:			portNum and data 
** Returned value:		None
** 
*****************************************************************************/
short serCgetc(void)                     /* Read character from Serial Port   */
{
	while(!(U2LSR & 0x01));
	return(U2RBR_THR);
}

// unsigned char receiveByte(void)
// {
// 	while (!(U0LSR & 0x01));
//   if( UART0Count == 0)
// 	{
// 		return UART0Buffer[UARTBUFSIZE - 1];
// 	}
// 	else
// 	{		
// 		return UART0Buffer[UART0Count - 1];
// 	}		
// 	
// 	//return (U0RBR);
// }

void InitialiseSerialObj(void)
{
char cTemp;
#ifdef BIO_METRIC
//int x;
   	PortObj[SER_BIO_PORT].RxBuffer = BioBuffer;
	PortObj[SER_BIO_PORT].F_ChkSum = CLR;
   	PortObj[SER_BIO_PORT].ChkSum = 0;
	PortObj[SER_BIO_PORT].BufPtr = 0;
   	PortObj[SER_BIO_PORT].RxPtr = 0;
	PortObj[SER_BIO_PORT].MAXINBUF = sizeof(BioBuffer);
//	x = PortObj[SER_BIO_PORT].MAXINBUF;
   	PortObj[SER_BIO_PORT].Type = PORT_TYPE_BIO;
#endif
#ifdef	SMART_CARD
	PortObj[SER_SMART_RD1_PORT].BufPtr = 0;
	PortObj[SER_SMART_RD1_PORT].RxBuffer = SmartCardSerBuffer;
	PortObj[SER_SMART_RD1_PORT].F_ChkSum = CLR;
   	PortObj[SER_SMART_RD1_PORT].ChkSum = 0;
	PortObj[SER_SMART_RD1_PORT].BufPtr = 0;
   	PortObj[SER_SMART_RD1_PORT].RxPtr = 0;
	PortObj[SER_SMART_RD1_PORT].MAXINBUF = sizeof(SmartCardSerBuffer);
#endif

//   PortObj[SER_TCPIP_PORT].RxBuffer=NWTxBuffer;
	PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
   	PortObj[SER_TCPIP_PORT].ChkSum = 0;
	PortObj[SER_TCPIP_PORT].BufPtr = 0;
   	PortObj[SER_TCPIP_PORT].RxPtr = 0;
	PortObj[SER_TCPIP_PORT].MAXINBUF = 2000;	//1024;
   	PortObj[SER_TCPIP_PORT].Type = SER_TCPIP_PORT;


//	PortObj[SER_TCPIP_PORT].MAXOUTBUF = sizeof(TcpSendBuffer);//ARMF0249
//	PortObj[SER_TCPIP_PORT].Buffer = TcpSendBuffer;

	PortObj[SER_TCPIP_PORT].MAXOUTBUF = sizeof(UdpSendBuffer)-sizeof(UDP_HEADER);
	PortObj[SER_UDP_PORT].MAXOUTBUF = sizeof(UdpSendBuffer)-sizeof(UDP_HEADER);
	PortObj[SER_TCPIP_PORT].Buffer = UdpSendBuffer; 
	PortObj[SER_UDP_PORT].Buffer = UdpSendBuffer;

#ifdef ENABLE_EMAIL_SEND
	PortObj[SER_EMAIL_PORT].MAXOUTBUF = sizeof(EmailSendBuffer);
	PortObj[SER_EMAIL_PORT].Buffer = EmailSendBuffer;
#endif

#ifdef ENABLE_TCP_PUSH
	PortObj[SER_TCPPUSH_PORT].MAXOUTBUF = sizeof(TPushData.TcpPushSendBuffer);
	PortObj[SER_TCPPUSH_PORT].Buffer = TPushData.TcpPushSendBuffer ;
#endif

	PortObj[SER_UDP_PUSH_PORT].MAXOUTBUF = sizeof(UdpPushSendBuffer)-sizeof(UDP_HEADER);
	PortObj[SER_UDP_PUSH_PORT].Buffer = UdpPushSendBuffer ;


#ifdef ENABLE_GSM_GPRS
   	PortObj[MODEM_PORT].RxBuffer = GPRSSBuffer;
	PortObj[MODEM_PORT].F_ChkSum = CLR;
   	PortObj[MODEM_PORT].ChkSum = 0;
	PortObj[MODEM_PORT].BufPtr = 0;
   	PortObj[MODEM_PORT].RxPtr = 0;
	PortObj[MODEM_PORT].MAXINBUF = sizeof(GPRSSBuffer);
   	PortObj[MODEM_PORT].Type = PORT_TYPE_GPRS;
#endif

	for(cTemp =0; cTemp<MAX_SER_PORT ;cTemp++)
	{
		SerialHandler[cTemp] = DummyHandle;	//to avoid crash of code
	}
	SerialHandler[PC_PORT]=SerIntPCHandle ;
#ifdef 	SMART_CARD
	#ifdef SUPPORT_ICLASS_RDR	
	SerialHandler[SER_SMART_RD1_PORT]= SerIntIClassCardHandle ;
	#else
	SerialHandler[SER_SMART_RD1_PORT]= SerIntSmartCardHandle ;
	#endif 

#endif
#ifdef	ENABLE_GSM_GPRS
	SerialHandler[MODEM_PORT]=SerIntGPRSModemHandle ;
#endif
}
/*-------------------------------------------------------------------------------------------------*/
void SerialInt(void)
{
// //#ifdef BIO_METRIC //ARMD0344:
//   SysInfo.BaudRate[SER_BAUD_BIO] = 57600;		//uart2
// //#endif  
//    SysInfo.BaudRate[SER_BAUD_SC1] = 9600;		//uart1	
//    SysInfo.BaudRate[SER_BAUD_SC2] = 9600;		//uart3
//    SysInfo.BaudRate[SER_BAUD_PC] = 9600;	 	//uart0

#ifdef BIO_METRIC
   SER_BIO_BAUDRATE(SysInfo.BaudRate[SER_BAUD_BIO]);
#endif
}
void UARTDelay(void)
{
	int i=15000;
	while(--i)
	{}
}
char TransmitCharToX(unsigned char t_data,unsigned char port)
{
	if(port > MAX_SER_PORT)
		return(1);
	if(PortObj[port].F_ChkSum == SET)
   	{
		if(PortObj[port].Type == PORT_TYPE_BIO)
		   PortObj[port].ChkSum = PortObj[port].ChkSum + t_data;
		else
		   PortObj[port].ChkSum = PortObj[port].ChkSum ^ t_data;
	}
	switch(port)
	{
	case SER_PORT_C:
//		UARTDelay();
		if(F_CheckSumC == SET)
   			PortObj[SER_PORT_C].ChkSum = PortObj[SER_PORT_C].ChkSum ^ t_data;
		UARTSendByte(port,t_data);	 
#ifdef ENABLE_GSM_GPRS
		if(SendWithoutDelay==0)
		{
			#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
			#endif
			UARTDelay();
		}
			GPRSNoDataTime = 0;
#endif		  	
		break;

	case SER_PORT_D:
		if(F_CheckSumD == SET)
   			PortObj[SER_PORT_D].ChkSum = PortObj[SER_PORT_D].ChkSum ^ t_data;
		UARTSendByte(port,t_data);	
		break;

	case SER_PORT_E:
		if(F_CheckSumE == SET)
   			PortObj[SER_PORT_E].ChkSum = PortObj[SER_PORT_E].ChkSum ^ t_data;
		UARTSendByte(port,t_data);	
#ifdef ENABLE_GSM_GPRS		
		if(SendWithoutDelay==0)
		{
#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
#endif
			UARTDelay();
		}
			GPRSNoDataTime = 0;
#endif		  	
		
		break;

	case SER_PORT_F:
		if(F_CheckSumE == SET)
   			PortObj[SER_PORT_F].ChkSum = PortObj[SER_PORT_F].ChkSum ^ t_data;
		UARTSendByte(SER_PORT_F,t_data);	
#ifdef ENABLE_GSM_GPRS
		if(SendWithoutDelay==0)
		{
			#ifdef ENABLE_WATCHDOG
			 	WDTFeed();		//Clear watchdog timer
			#endif
			UARTDelay();
		}
			GPRSNoDataTime = 0;
#endif
		break;

	case SER_TCPIP_PORT:
		PortObj[SER_TCPIP_PORT].Buffer[PortObj[SER_TCPIP_PORT].BufPtr] = t_data;
		PortObj[SER_TCPIP_PORT].BufPtr ++;
		if(PortObj[SER_TCPIP_PORT].BufPtr > PortObj[SER_TCPIP_PORT].MAXOUTBUF)
		{
//			SendStringToNW(NWTxBuffer,NoOfNWTxData);
			PortObj[SER_TCPIP_PORT].BufPtr = 0;
		}
		break;
	case SER_UDP_PORT:
		if(PortObj[SER_UDP_PORT].BufPtr == 0)
			PortObj[SER_UDP_PORT].BufPtr = DUMMY_UDP_HEADER_SIZE;	//Added dummy UDP header
		PortObj[SER_UDP_PORT].Buffer[PortObj[SER_UDP_PORT].BufPtr] = t_data;
		PortObj[SER_UDP_PORT].BufPtr++;
		if(PortObj[SER_UDP_PORT].BufPtr >= PortObj[SER_UDP_PORT].MAXOUTBUF )
			PortObj[SER_UDP_PORT].BufPtr = 0;
		break;
      case SER_TCPPUSH_PORT:
         PortObj[SER_TCPPUSH_PORT].Buffer[PortObj[SER_TCPPUSH_PORT].BufPtr] = t_data;
         PortObj[SER_TCPPUSH_PORT].BufPtr++;
         if(PortObj[SER_TCPPUSH_PORT].BufPtr >= PortObj[SER_TCPPUSH_PORT].MAXOUTBUF )
			PortObj[SER_TCPPUSH_PORT].BufPtr = 0;
      break;
		case SER_UDP_PUSH_PORT:		//ARMD0409
			if(PortObj[SER_UDP_PUSH_PORT].BufPtr == 0)
				PortObj[SER_UDP_PUSH_PORT].BufPtr = DUMMY_UDP_HEADER_SIZE;	//Added dummy UDP header
			PortObj[SER_UDP_PUSH_PORT].Buffer[PortObj[SER_UDP_PUSH_PORT].BufPtr] = t_data;
			PortObj[SER_UDP_PUSH_PORT].BufPtr++;
			if(PortObj[SER_UDP_PUSH_PORT].BufPtr >= PortObj[SER_UDP_PUSH_PORT].MAXOUTBUF )
				PortObj[SER_UDP_PUSH_PORT].BufPtr = 0;
	  	break;
#ifdef ENABLE_EMAIL_SEND
      case SER_EMAIL_PORT:

         PortObj[SER_EMAIL_PORT].Buffer[PortObj[SER_EMAIL_PORT].BufPtr] = t_data;
         PortObj[SER_EMAIL_PORT].BufPtr++;
         if(PortObj[SER_EMAIL_PORT].BufPtr >= PortObj[SER_EMAIL_PORT].MAXOUTBUF )
				PortObj[SER_EMAIL_PORT].BufPtr = 0;
      break;
#endif
/*			if(TCPPushObj.BufPtr ==0 )
         {
          	TCPPushObj.F_ChkSum=SET;
          	TCPPushObj.ChkSum=0;
         }
			if(TCPPushObj.F_ChkSum == SET)
         {
	         TCPPushObj.ChkSum = TCPPushObj.ChkSum ^ t_data;
         }
         TCPPushObj.Buffer[TCPPushObj.BufPtr]=t_data;
         TCPPushObj.BufPtr++;
         if(TCPPushObj.BufPtr>=MAX_SEND_BUFFER)
				TCPPushObj.BufPtr=0;
      break;
*/
	}
	return(0);
}

void DummyHandle(unsigned char port)
{}

/******************************************************************************
**                            End Of File
******************************************************************************/
