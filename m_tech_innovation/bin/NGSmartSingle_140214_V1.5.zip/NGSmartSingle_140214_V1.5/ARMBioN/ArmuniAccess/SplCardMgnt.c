/**************************************************************************
File Name : SplCardMgnt.c

Purpose: All of the SpecialCard,Phase3 Functions are handled here

Technical Lead,Guidance : Pankaj Sir.

Developer: Prasoon Marla.

*****************************************************************************/


#include <stdio.h>
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include <string.h>
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "target.h"
#include "serial.h"
#include "Access.h"
#include "userintf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "smartcard.h"
#include "portlcd.h"
#include "memory.h"
#include "spi.h"
#include "INOUT.h"
#include "CardMgmt.h"
#include "memmap.h"
#include "RDcont.h"
#include "RDPoll.h"
//#include "tcpip.h"
#include "weigand.h"
#include "ProcessWeiCard.h"
#include "wdt.h"
#include "IOEventMgmt.h"
#include "Timer.h"
#include "userIntfGLCD.h"

#define DMZ_PREWARNING_TIME	   5
#define DONOT_DISTURB_MODE_ON  1
#define DONOT_DISTURB_ZONE_ON  2

//void SpecialCrdBasedErr(unsigned char count,char chno);
unsigned char CheckDoNotDisturbZone(unsigned char TWeekDay, unsigned char rdno);
extern SYSInfo SysInfo;
extern struct DOOR_INFO Doorinfo;
extern unsigned char F_DuelUserAuth;
extern BYTE ReaderNo,F_OneSec;
extern unsigned char F_DuelUserAuth;
extern BYTE F_KeyIdleTime,IdleKeyCounter;
extern unsigned char F_DISIndicator,F_DMZBuz,F_DMZOccur;
//BYTE DMZ_Cntr;
extern unsigned char F_DoNotCheckAPBForCard,DoNotCheckAPBTime,SpecialCardRdNo;

//extern void WeigandLedBuzzOff(unsigned char rdno);
//extern void WeigandLedBuzzOn(unsigned char rdno);
//unsigned char SplLedBlink[MAX_READERS];
/*-------------------------------------------------------------------------*/
/*** BeginHeader CheckDoNotDisturbZone*/
unsigned char CheckDoNotDisturbZone(unsigned char TWeekDay, unsigned char rdno);
/*** EndHeader */
unsigned char CheckDoNotDisturbZone(unsigned char TWeekDay, unsigned char rdno)
{
	if((Doorinfo.DontDisturb == DONOT_DISTURB_ZONE_ON) && (ReaderInfo[rdno-1].DNDTZ) != 0x00)
	{	        
		if(Check_TimeZone(ReaderInfo[rdno-1].DNDTZ,TWeekDay) == TimeZone_OK)
			return(1); 
	} 	
  	return(0); 		
}

/*** BeginHeader Check1stInUseCard*/
unsigned char Check1stInUseCard(unsigned char Group,unsigned char CrdFound);
/*** EndHeader */	
unsigned char Check1stInUseCard(unsigned char Group,unsigned char CrdFound)
{ 
    if((Doorinfo.FirstInUserRule == 1) && (CrdFound != EVENT_CARD_NOT_FOUND) )
    {
	   if(SplCrdFlag.FirstInUser[Group] == CLR)//CHECKING GROUP WISE FIU.
	    {
//	  		SpecialCrdBasedErr(5,ReaderNo-1);
	      return(EVENT_FIRST_INCARD_NOT_FOUND);			//FIU   action if not spl card before First In user card
	      			// User unauthorised
	    }
    }// else if((Doorinfo.FirstInUserRule == 1))
	return 0;
}			

/*** BeginHeader CheckDoNotDisturb*/
//unsigned char CheckDoNotDisturb(CARDNO_DATA_STORAGE_TYPE cardno);
/*** EndHeader */	
unsigned char CheckDoNotDisturb(CARDNO_DATA_STORAGE_TYPE cardno,char chno)
{

	if( (Doorinfo.DontDisturb == DONOT_DISTURB_MODE_ON)&& F_Spl_Crd_Dr_open == CLR )
	{
		if(SplCrdFlag.DNDCFlag == SET)
		{
//		 	SpecialCrdBasedErr(5,chno);				 //ARMD0404
		  	StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)cardno,ReaderNo,EVENT_DONOT_DSTRB_MODE);
		   	L_DisplayROMStr("DONT DISTRB MODE",16,ROW_USER_ENTRY2);
			if((Doorinfo.BeepEnable ) )
		   {
		  		 MakeSound(SOUND_CARD_FOUND);
		   }		    
		   return(1);
		}
	}
	if((Doorinfo.DontDisturb == DONOT_DISTURB_ZONE_ON) && (F_Spl_Crd_Dr_open == CLR))
	{
		if(SplCrdFlag.DNDZoneFlag == SET)	
	 	{
	 		if(CheckDoNotDisturbZone(CWeekDay,ReaderNo) == SET)
	    	{
//				SpecialCrdBasedErr(5,chno);					 //ARMD0404
		    	StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)cardno,ReaderNo,EVENT_DONOT_DSTRB_MODE);
		   		L_DisplayROMStr("DONT DISTRB ZONE",16,ROW_USER_ENTRY2);
				if((Doorinfo.BeepEnable ) )
		    	{
		  			MakeSound(SOUND_CARD_FOUND);
		    	}		    
		   		return(1);
	    	}//if(CheckDoNotDisturbZone() == SET)
	 	}//if(SplCrdFlag.DNDCFlag == SET)
		return 0;
	}//if((Doorinfo.DontDisturb == SET)
	
		return 0;
}	

/*-------------------------------------------------------------------------*/
/*** BeginHeader CheckDualUser */
unsigned char CheckDualUser(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char msginfo);

unsigned char CheckDualUser(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char msginfo)	 //ARMF2008
{ 		
	if(Doorinfo.DuelUserAuth == 1) 
	{
		if(F_DuelUserAuth == CLR)
	   	{
   			DuelUserCounter = 0; //start count from Zero for any first finger. to avoid the bug of 2nd fngr time out variation.
	        DuelUserData[0].CardNo = cardno;
	      	DuelUserData[0].DuelCType = ((msginfo) & 0x60) >> 5;
			DuelUserData[0].GrpInfo  = ((msginfo) & 0x1F);	 //0x0F
			if(Doorinfo.AnyDualFinger == 1)
			{
				F_DuelUserAuth = SET;
				return EVENT_DUEL_USER_2;	
			}

			switch(DuelUserData[0].DuelCType)
		    {
			/* 	#define SUPER_ADMIN		0x03   >> 01100000
				#define GROUP_ADMIN		0x01   >> 00100000
				#define NORMAL_USER		0x00   >> 00000000 */

				case NORMAL_USER: //0
	        		return EVENT_DUEL_USER_ACCESS_FAIL;
				case GROUP_ADMIN://1
					F_DuelUserAuth = SET;
		            return EVENT_DUEL_USER_2;
				case SUPER_ADMIN://3
					F_DuelUserAuth = SET;
					return EVENT_DUEL_USER_2;
		        default:
		        	return EVENT_DUEL_USER_ACCESS_FAIL;
			}
		}
		else //(F_DuelUserAuth == SET)
		{
   			F_DuelUserAuth = CLR;
			DuelUserData[1].CardNo = cardno;
	      	DuelUserData[1].DuelCType = ((msginfo) & 0x60) >> 5;
			DuelUserData[1].GrpInfo  = ((msginfo) & 0x1F);;	 //0x0F

			if(Doorinfo.AnyDualFinger == 1)
        	{
         		return 0;
        	}
			else
			{
				if(DuelUserData[1].DuelCType == SUPER_ADMIN)
					return 0;
				else if((DuelUserData[0].DuelCType == SUPER_ADMIN)||((DuelUserData[1].DuelCType == GROUP_ADMIN)&& \
				(DuelUserData[0].CardNo != DuelUserData[1].CardNo)&&(DuelUserData[0].GrpInfo == DuelUserData[1].GrpInfo)))
				  	return 0;
				else if((DuelUserData[0].DuelCType == SUPER_ADMIN)||((DuelUserData[1].DuelCType == NORMAL_USER)&&  \
				(DuelUserData[0].CardNo != DuelUserData[1].CardNo)&&(DuelUserData[0].GrpInfo == DuelUserData[1].GrpInfo)))
				  	return 0;
				else 
					return EVENT_DUEL_USER_ACCESS_FAIL;	
			}
	   	}
	}
	return 0;
}
/*-------------------------------------------------------------------------*/

void DualUserMainLoopManager(void) 
{
//unsigned char FIU_Cntr,i;

			if((Doorinfo.DuelUserAuth == 1))
		//	for(i=0;i<MAX_LOCAL_DOORS;i++)
			{
				if(F_DuelUserAuth == SET)
				{
					DuelUserCounter++;
				}
			}

	#ifdef MODE_ANY_DUAL_MODE_FINGER//dont delete this.
		if((DuelUserCounter == TIMEOUT_DUAL_FINGER-1) &&(Doorinfo.DuelUserAuth == 1) && (F_DuelUserAuth == SET))
	    {
			L_DisplayROMStr("2ndFingerTimeOut ",16,ROW_USER_ENTRY2);
	        F_KeyIdleTime = CLR;
	        IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
			MakeSound(SOUND_USER_ERROR);
			F_DuelUserAuth = CLR;
			DuelUserCounter = 0;
	    }
	#endif
		 
		#ifndef MODE_ANY_DUAL_MODE_FINGER
		if(Doorinfo.DuelUserAuth == 1)
		if((DuelUserCounter >= TIMEOUT_DUAL_FINGER) && (F_DuelUserAuth == SET))
	    {
			L_DisplayROMStr("2nd card TimeOut",16,ROW_USER_ENTRY2);
	        F_KeyIdleTime = CLR;
	        IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
			MakeSound(SOUND_USER_ERROR);
			F_DuelUserAuth = CLR;
			DuelUserCounter = 0;
	    }
	   #endif
	//	if(Doorinfo.DoorInterlock == 1)     //ARMF0247 
	//	{
		//	F_DISIndicator = !F_DISIndicator;
	//	}
}
/*-------------------------------------------------------------------------*/

void GlobalDMZReset(unsigned char rdno)
{
	DeadMenZoneMinCounter = 0;
	DMZMinCounter = 0;
	F_DeadManZone = CLR;
	F_Spl_Crd_Dr_open = CLR;
	F_DMZOccur = CLR;
//	WeigandLedBuzzOff(rdno-1);
}
/*-------------------------------------------------------------------------*/

void DMZMainLoopManager(void)		  //ARMF2003:	DMZ Implementation
{ 
char  DMZ_rdr;
	for(DMZ_rdr=0;DMZ_rdr<MAX_LOCAL_READER;DMZ_rdr++)
	{
		if((Doorinfo.EnDisDeadManZone != 0) && (ReaderInfo[0].DeadManZoneEnDis != 0) && (ReaderInfo[0].DMZ_Time>=0x00))	//ARMD0248    
	{
	   	F_DMZBuz = !F_DMZBuz;
		if(DMZMinCounter == 0x01)
		{
			DeadMenZoneMinCounter++;
			DMZMinCounter = 0x00;
		}
		if(ReaderInfo[0].DMZ_Time < 10)	  //taking reader1 dmz time.
		{
			ReaderInfo[0].DMZ_Time = 10;
			WriteReaderInfoToFlash();
		}
		if(DeadMenZoneMinCounter >= ReaderInfo[0].DMZ_Time - (DMZ_PREWARNING_TIME))//prewarning before 5 minutes
			{	
				F_DeadManZone = SET;//comment below two lines for pre warning b4 5 min. and uncomment this.
//				WeigandLedBuzzOn(DMZ_rdr);
			}
			if(DeadMenZoneMinCounter >= ReaderInfo[0].DMZ_Time)
				F_DeadManZone = SET;
			if(F_DMZBuz == 1)  //handle this in HandleDisplayTimeOuts() for displaying all door dmz.
			{
//	    		WeigandLedBuzzOff(DMZ_rdr);
	 		}
		if(F_DeadManZone == SET)
		{
		    F_DMZOccur = SET;
		    if((F_DMZBuz == 1)&&((DisplayMode == USER_IDENTIFY_MODE) || (DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == USER_VERIFY_MODE)))  
			{
//			    L_DisplayROMStr("DEAD MAN ZONE   ",16,ROW_USER_ENTRY);
					DisplayBottomStatusIcon(0,"DEAD MAN ZONE",0,0);
			}
		    if( ( Doorinfo.BeepEnable != 0x00) &&  (Doorinfo.BeepEnable < 0x04) )//control on board buzzer.
			{
				MakeSound(SOUND_USER_ERROR);
			}

            if(DeadMenZoneMinCounter >= ReaderInfo[0].DMZ_Time)
			{ 
				if((F_TrnxMemFull == CLR) && (DeadMenZoneMinCounter >= ReaderInfo[0].DMZ_Time))
				{
					DeadMenZoneMinCounter = 0;
					StoreCardInTrDB(0,(0+1),EVENT_DEAD_MAN_ZONE);  //assuming reader1 as it is controller wise.
				}
			}//if(DeadMenZoneMinCounter >= ReaderInfo[0].DMZ_Time)
		}//if(F_DeadManZone == SET)
	} //if(Doorinfo.EnDisDeadManZone
	}
}//void DMZMainLoopManager(void)

/*-------------------------------------------------------------------------*/
// Some of the Special Card actual functionality is not implemented but added in code so it is easy in future.
// Following function is used to process special cards
/*** BeginHeader ProcessSpecialCard*/
int ProcessSpecialCard(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char rdno);
/*** EndHeader */
int ProcessSpecialCard(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char rdno)
{
	int i,temp,temp2;
	unsigned char doorno;

	temp2 = 0x01;
	temp = SpecialCardSearch(cardno); //do not modify this variable after this.
	if(temp == CARD_NOT_FOUND)
		return(EVENT_SPCL_CARD_NOT_FOUND);
	
	switch(SpecialCardData.CardType)
	{
		case SP_CARD_APB_ESCORT_TYPE:
			F_DoNotCheckAPBForCard = 1;
			DoNotCheckAPBTime = Doorinfo.NoCheckAPBTimer;
			SpecialCardRdNo = rdno;
			temp2 = EVENT_ESCORT_CARD;
		break;
	   	case SP_CARD_ALERT_TYPE:    //Alert Type Card
			temp2 = EVENT_ALERT_CARD;
      	break;
		case SP_CARD_EMERGENCY_TYPE: //Emergency open / user open
			temp2 = 0x1; //ARMD0274
			for(doorno=0;doorno<MAX_LOCAL_DOORS;doorno++)//ARMD0274 
			{
				if(SpecialCardData.CardInfo & temp2)
					DoorConditionControl(doorno,DR_USER_OPEN,1,1);     //Special card Door open
				temp2 = temp2<<1;
			}
			temp2 = EVENT_EMERGENCY_CARD;
		break;
	    case SP_CARD_INTRUSION_TYPE: //Intrusion type card
	         INTRUSION_STATUS = SET;

	         //DRStruct[0].IntrusionInput = SET;
			if(SpecialCardData.CardInfo & 0x01)//pankaj sir
			{
			   SysInfo.InputED = 0x04;//set intrusion parameter ON else access is granted for valid cards if 
			                         //SysInfo.InputED != 0x04
			   WriteSysInfoToFlash();
				for(i=0;i<SysInfo.ControllerMode;i++)
				{
					DoorConditionControl(i,DR_INTRUSION_CLOSE,1,1);
					if(DRStruct[i].DREgressStatus == SET)
						DRStruct[i].DREgressStatus = CLR;
				}
			}
//			if(SpecialCardData.CardInfo & 0x01)
//			{
//				DoorConditionControl(0,DR_INTRUSION_CLOSE,1,1);
//				if(!CHECK_SHARED_DOTL(0))
//					DoorConditionControl(1,DR_INTRUSION_CLOSE,1,1);
//				if(DRStruct[0].DREgressStatus == SET)
//					DRStruct[0].DREgressStatus = CLR;
//			}
			 if(SpecialCardData.CardInfo & 0x10)
	         {		// NEED TO CHECK WHAT IT MEAN BY CardInfo as 0x10 ?????
	         	DoorConditionControl(1,DR_INTRUSION_CLOSE,1,1);
	         }
	         MakeSound(50);
			temp2 = EVENT_INTRUSION_CARD;
		break;
//	    case SP_CARD_OCCUPANCY_RESET_TYPE: //Occupancy Control card
//			Doorinfo.E_InEmpCount = InEmpCount = InEmpCount_Back = 0;
//			#ifdef SMART_SENSOR_DISPLAY
//			SendINOUTCountToDisplay(InEmpCount,EMP_DISPLAY_PORT);
//			#endif
//			WriteDoorInfoToFlash();
//			temp2 = EVENT_OCCUPANCY_CONTROL_CARD;
//		break;

		 case SP_CARD_OCCUPANCY_TYPE: //Occupancy Control card
			if(Doorinfo.EnDisEmpInDispCount != 0)	//this need to change
			{
				Doorinfo.OccupancyCount = SpecialCardData.CardInfo;
				WriteDoorInfoToFlash();
			}
			temp2 = EVENT_OCCUPANCY_CONTROL_CARD;
		break;


	      case SP_CARD_OVERRIDE_ACCESS_TYPE: //Override Access policy
				ReaderInfo[rdno-1].CntrolrType =  SpecialCardData.CardInfo;
		    	WriteSplCardDataToFlashBlock(temp,SpecialCardData);  //temp = card position
	         	WriteReaderInfoToFlash();
	         	WriteSysInfoToFlash();
			 	temp2 = EVENT_OVERRIDE_ACCESS_CARD;
		break;

			case SP_CARD_FIRST_IN_USER_TYPE: // First in user Rule groupwise   
				if(Doorinfo.FirstInUserRule == SET)
				{
					//SpecialCardData.CardInfo contains the group number of SP_CARD_FIRST_IN_USER_TYPE
					SplCrdFlag.FirstInUser[SpecialCardData.CardInfo] = !( SplCrdFlag.FirstInUser[SpecialCardData.CardInfo] );     //FIU Flag reset //ARMD0296 
					temp2 = EVENT_FIRST_INUSER_CARD;
					WriteSplCardFlagInfoToFlash();
				}
				else 
					temp2 = EVENT_CARD_NOT_FOUND;
	        break;

		case SP_CARD_NORMAL_TYPE:  //ARMF0283 
			INTRUSION_STATUS = CLR;
			if(SpecialCardData.CardInfo & 0x01)
			{
				for(i=0;i<SysInfo.ControllerMode;i++)
				{
					DoorConditionControl(i,DR_NORMAL,1,1);
				}
			}
			temp2 = EVENT_NORMAL_CARD;
		break;
		case SP_CARD_DMZ_RESET_TYPE:
            //================ Dead Man Zone ===============//
				if(Doorinfo.EnDisDeadManZone != 0)		//201210-1
				{
					DeadMenZoneMinCounter = 0;
					F_DeadManZone = CLR;
					temp2 = EVENT_DMZ_RESET_CARD;
					F_Spl_Crd_Dr_open = CLR;
					F_DMZOccur = CLR;
					if(SpecialCardData.CardInfo & 0x01)
					{
						 F_Spl_Crd_Dr_open = DOOR_OPEN_BY_DMZ_CARD ;  //ARMD0343
					}
				}//if(Doorinfo.EnDisDeadManZone == 0x01)
				else 
				{
					temp2 = 0;//DMZ not enabled and DMZ card shown in that case assuming the card as invalid card.
				}
//			   	WeigandLedBuzzOff(rdno-1);	change this prasoon
		break;
        case SP_CARD_DONOT_DSTRB_TYPE:
			if( (Doorinfo.DontDisturb == DONOT_DISTURB_MODE_ON) )
			{
				SplCrdFlag.DNDCFlag = !( SplCrdFlag.DNDCFlag );     //FIU Flag reset //ARMD0296 
				temp2 = EVENT_DONOT_DISTURB_CARD;
				WriteSplCardFlagInfoToFlash();
			}
			else 
				temp2 = EVENT_CARD_NOT_FOUND;
			break;

		case SP_CARD_DONOT_DSTRB_ZONE_TYPE:
			if( (Doorinfo.DontDisturb == DONOT_DISTURB_ZONE_ON) )
		    {
				SplCrdFlag.DNDZoneFlag = !( SplCrdFlag.DNDZoneFlag );   
				temp2 = EVENT_DONOT_DISTURBZONE_CARD;
				WriteSplCardFlagInfoToFlash();
			}
			else
				temp2 = EVENT_CARD_NOT_FOUND;
		break;

		default:
			temp2 = 0;
		break;
	}
	ReadSplCardFlagInfoFromFlash();
	return (temp2);
}
/*-------------------------------------------------------------------------*/

// Following function is used to process special cards 
// This is required to support old NSeries Phase 1 support...

/*** BeginHeader ProcessEscortCard*/
int ProcessEscortCard(unsigned char rdno);
/*** EndHeader */
int ProcessEscortCard(unsigned char rdno)
{
   F_DoNotCheckAPBForCard = 1;
   DoNotCheckAPBTime = Doorinfo.NoCheckAPBTimer;
   SpecialCardRdNo = rdno;
   return(0);
}

/*-------------------------------------------------------------------------*/

/*** BeginHeader IncDecInEmpCount*/
void IncDecInEmpCount(unsigned char readerno);
/*** EndHeader */
void IncDecInEmpCount(unsigned char readerno)
{
	if(readerno == 1)
   		InEmpCount ++;
	else if(readerno == 2 && InEmpCount!=0)		//ARMD0480
   		InEmpCount --;
//	else if(InEmpCount != 0x00)//ARMD0306		//commented because of ARMD0480
//   	InEmpCount --;
   	if(InEmpCount > MAX_EMP_IN_COUNT)
   		InEmpCount = MAX_EMP_IN_COUNT;			//shree 28Aug 0 if count reached to max, it will remain MAX_EMP_IN_COUNT
	InEmpCount_Back = InEmpCount;
// We will remove following and implement logic indicated by me..
}
/*-------------------------------------------------------------------------*/

/*** BeginHeader ValidateInEmpCount*/
void ValidateInEmpCount(void);
/*** EndHeader */
void ValidateInEmpCount(void)
{
// This will be called at startup to validate if data is not corrupt and if same is corrupt we will take from EEPROM
// we will use three variabled to store this value.....
   	InEmpCount = Doorinfo.E_InEmpCount;//load the value read from flash memory on every stsrtup to avoid zero count/garbage value.
   	if(InEmpCount_Back != InEmpCount)
   	{
		InEmpCount = InEmpCount_Back;
   	}
   	if(InEmpCount > MAX_EMP_IN_COUNT)
   	{
      	InEmpCount = InEmpCount_Back = 0;
   	}
   	SaveInEmpCount();//if any changes then new value is written in InitialiseSystem();----->WriteDoorInfoToFlash();
}
/*-------------------------------------------------------------------------*/

/*** BeginHeader SaveInEmpCount*/
void SaveInEmpCount(void);
/*** EndHeader */
void SaveInEmpCount(void)
{
//	This will be called in main loop and will save employee count every 15 min if there is change in count
	if(Doorinfo.E_InEmpCount != InEmpCount)
	{
	   Doorinfo.E_InEmpCount = InEmpCount;
	   WriteDoorInfoToFlash();
	}
}

/*-------------------------------------------------------------------------*/
