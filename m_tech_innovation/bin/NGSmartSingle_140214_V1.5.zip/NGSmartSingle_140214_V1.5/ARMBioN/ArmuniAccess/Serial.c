
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "version.h"
#include "type.h"
#include "config.h"
#include "portdef.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "Access.h"
#include "serial.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "memory.h"
//#include "tcpip.h"
#include "spi.h"
#include "protocol.h"
#include "cardmgmt.h"
#include "memmap.h"
#include "portlcd.h"
#include "rdcont.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif

#ifndef TELNET_TEST
//#define NETWORK_HANDLE (BYTE)(0 - 1)
typedef unsigned short QUEUE_TRANSFER;
extern unsigned short fnPrint (unsigned char *ucToSend, unsigned char ucID,QUEUE_TRANSFER ucLen);
#endif

extern void DoorOpen(unsigned char drno);
extern void DoorClose(unsigned char drno);
/*---------------------------------------------------------------------------*/
//local variable


/*---------------------------------------------------------------------------*/
//external Variable
extern _TIMEZONE Timezone;

void SendLongBCDToPC(unsigned int data1);

extern BYTE F_CheckSum,F_BIO_COMM;

extern BYTE CWeekDay, DeabugLevel,FaclityCode1,FaclityCode2;
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;


extern SYSInfo SysInfo;
extern struct DOOR_INFO Doorinfo;
extern _TRANSData UExTrnxData; 
extern Date Holiday;
extern RTCTime Datetime;
//extern Date CDate;
extern CardData Carddata;
extern volatile BYTE SBuffer[BUFSIZE];

extern WORD enetptr;
extern BYTE CheckSumE,CheckSumC,CheckSumD,CheckSumB;
extern BYTE CheckSum,TempTotalDnTrnxNo;
//extern BYTE trnsbuffer[800];
extern BYTE F_CheckSumC,F_CheckSumD,F_CheckSumE,F_CheckSumB;
extern WORD NoOfNWTxData  ;
extern WORD EXCARD_COUNT,PrevBulkDownload;

extern int LastCardAddedPtr;

extern volatile BYTE F_TransCrossOver;

//extern BYTE F_CardFound1,F_Facility,F_EthernetReceived;
extern BYTE F_Door1_Open_TimeOut,F_Door2_Open_TimeOut;

extern unsigned char  CurrentIP[IPV4_LENGTH],CurrentUDPIP[IPV4_LENGTH];  // This will store ip address which called protocol communication..

extern TCP_CONTROL *PresentTcpPtr ;
extern USOCKET Socket_TCP;
extern unsigned char ActiveDebugPort;


/*---------------------------------------------------------------------------*/
/*
   FUNCTION: CheckSum

   PARAMETERS: character received

   DESCRIPTION: this function calculates checksum for the character received
        Last two bytes are checksum in ascii convert to hex.

   RETURNS: O checksum Failed 1 checksum correct.

 */


char Checksum(WORD ReceiveCount)
{ BYTE checksum;
	WORD i;

   checksum = STX;
   for(i=0;i<ReceiveCount-2;i++)
   {   checksum = checksum ^ SBuffer[i];

   }
         if(checksum == ConvertAsciiToHex(ReceiveCount-2))
      return (1);
   else
      return(0);


}
/*--------------------------------------------------------------------------*/

BYTE AsciiToHex( BYTE temp)
{
   if( (temp >= '0' )&& (temp <= '9'))
      return(temp - '0');
   if((temp >= 'A') && (temp <= 'F'))
      return((temp+10) - 'A');
   if((temp >= 'a') && (temp <= 'f'))
      return((temp+10) - 'a');
   return(0);
}
/*---------------------------------------------------------------------------*/


BYTE ConvertAsciiToHex(BYTE position)
{
BYTE tmpdata;
   tmpdata = AsciiToHex(SBuffer[position]);
   tmpdata = (tmpdata * 16) + AsciiToHex(SBuffer[position+1]);
   return(tmpdata);
}
/*---------------------------------------------------------------------------*/

BYTE ConvertAsciiSbuffToHex(BYTE position)
{
BYTE tmpdata;
   tmpdata = SBuffer[position] - '0';
   tmpdata = (tmpdata * 10) + SBuffer[position+1] - '0';
   return(tmpdata);
}
/*-----------------------------------------------------------*/
/* this routine tranimit data in sbuffer */

/*void Trnsdata(BYTE count)
{     BYTE tdata;

      for(tdata=0;tdata<count;tdata++)
      {  CheckSum ^= trnsbuffer[tdata];
         TransmitChar(trnsbuffer[tdata]);
      }
       return;
}
*/

/*--------------------------------------------------------------------------*/

BYTE SwapChar(BYTE data1)
{
data1 = data1>>4;
return data1;
}
/*--------------------------------------------------------------------------*/

BYTE HexToAscii(BYTE temp)
{
   if( temp > 9)
      return(temp - 10 +'A');
   return(temp +'0');
}


/*-------------------------------------------------------------------------*/

#define PANK_TEST

void HandleSerialCmd(unsigned char port)
{
WORD TempTransReadPtr,TempTotalNosTrans;
unsigned char *buptr;
_TRANSData trans;
int ptrdata;
BYTE temp1;
	GLOBAL_PORT = port;
	PortObj[port].BufPtr = 0;
	PortObj[port].ChkSum = 0;
	PortObj[port].F_ChkSum = SET;
	       
	enetptr = 0;
//	memset(trnsbuffer, 0, sizeof(trnsbuffer));
	PortObj[SER_TCPIP_PORT].BufPtr = 0;
	if(port == SER_TCPIP_PORT)//ARMF0249
	 	memcpy(CurrentIP,PresentTcpPtr->ucRemoteIP,sizeof(CurrentIP));
	if(port == SER_UDP_PORT)
		memcpy(CurrentIP,CurrentUDPIP,sizeof(CurrentIP));

	PortObj[port].ChkSum = 0;
	PortObj[port].F_ChkSum = SET;
	if(C_NEW_COMMAND_GROUP == SBuffer[COMMAND_POSITION])
	{
		if(C_NEW_ENHANCED_PROTO == SBuffer[COMMAND_POSITION+1])				//ARMF2005
		{
			buptr = HandleEnhancedProtocol((unsigned char *)SBuffer,port);	 
			if(buptr != NULL)
			{
				if(C_NEW_COMMAND_GROUP == buptr[COMMAND_POSITION])
				{
					HandleNewCommandGroup((unsigned char *)buptr,port);
					return;  // Here we return as ethernet handle is done in above function
				}
				else
					return;
			}	 
		}
		else
			HandleNewCommandGroup((unsigned char *)SBuffer,port);
		return;  // Here we return as ethernet handle is done in above function
	}
	if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
	{
		// as ethernet so check authentication is done or now else do not allow access
		if(HandleSerialAuthCheck(SECURE_AUTH_ADMIN,port) == 1)
			goto goto_serial_end;
	}

	switch(SBuffer[COMMAND_POSITION])
	{
		case C_CARD_FROM_SERIAL:
            // This is to generate card no from serial port this is used for testing
            ReceivedCardNo = FiveAsciiToHex(&SBuffer[2]);
            ReaderData[0].F_CardFound = SET;
            TransmitReplyStart();
            TransmitChar('z');
            MsgPrint(1,ReceivedCardNo,"Dummy Card = ");
/*			if(ReceivedCardNo ==10)
			{
			  SelectIOCS(CS_OPCS1);
			  BuffOPCS1Latch = 00;
			  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	
			  SelectIOCS(CS_NO_SEL); 	
              MsgPrint(1,BuffOPCS1Latch,"Dummy CardBuffOPCS1Latch = ");
              MsgPrint(1,FIO2PIN,"Dummy Card FIO2PIN = ");
			  Delay(100000);
			}
			else if(ReceivedCardNo ==20)
			{
			  SelectIOCS(CS_OPCS1);
			  BuffOPCS1Latch = 0x000000FF;
			  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	
			  SelectIOCS(CS_NO_SEL); 		
              MsgPrint(1,BuffOPCS1Latch,"Dummy CardBuffOPCS1Latch = ");
              MsgPrint(1,FIO2PIN,"Dummy Card FIO2PIN = ");
			  Delay(100000);								  				
			}
			else if(ReceivedCardNo <=9)
				DoorOpen(ReceivedCardNo%04);
			else
				DoorClose(ReceivedCardNo%04);
*/
            TransmitCheckSum();
            TransmitChar(TERMINATOR);
//			StoreCardInTrDB(ReceivedCardNo,1,1);
            break;
		case C_READ_TRANS:
		case C_SEND_TRANS_SEC:
            // Same as FS2000
            if(SBuffer[COMMAND_POSITION+1] == '1')
            	F_Facility = SET;
            TransmitReplyStart();
            SendTransaction();
             DeleteTransaction();
            break;
		case C_DEL_TRNX:
			if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
			{
				if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
					break;
			}
            // Same as FC2000
            DeleteTransaction();	//	  check function
            TransmitReplyStart();
            TransmitChar(DELETETRNX);
            TransmitCheckSum();
            TransmitChar(TERMINATOR);
            break;
		case C_INITIALISE :
            // Same as FS2000
            // This will delete all cards and initialise all pointer to zero
          //   TransWritePtr = TransReadPtr = TotalNosOfTrans = 0;
          //   F_TransCrossOver = CLR;
            HandelSerialInitialise();

			InitialiseFlags = DELETE_ALL_FINGER ; //ARMF0377
			DelAllFingers();	//mukund check function
            TransmitReplyStart();
            TransmitChar(INITIALISE);
            if(ptrdata == 1)
               TransmitChar('1');
            TransmitCheckSum();
            TransmitChar(TERMINATOR);
			InitialiseFlags = 0;
            break;
		case C_CARDDELETE:
			InitialiseFlags = DELETE_ALL_CARDS;
           DelAllCards();	//mukund check function
#ifdef BIO_METRIC
			if(F_BIO_COMM == SET)
			{
				CancelBioCommand();  //     mukund check function
				F_BIO_COMM =CLR;
			}
			ENABLE_BIO_COMM();	//mukund check function
			if(DeleteAllBioUserID() !=0)	//mukund check functiopn
			{
			   MsgPrint(MSG_WARNING,1,"Finger Del Fail!=0");
			}
			DISABLE_BIO_COMM(); //mukund check function
#endif
           TransmitReplyStart();
           TransmitChar(INITIALISE);
           TransmitCheckSum();
           TransmitChar(TERMINATOR);
		   InitialiseFlags = 0;
           break;
      case C_TRNXDELETE:
            TotalNosOfTrans = 0;
            TransWritePtr = 0;
            TransReadPtr = 0;
            // BioFlag = 0;
            F_TransCrossOver = CLR;
#ifndef IMMEDIATE_WRITE_TRANS
            memset(WritePage.PBuffer, 0, sizeof(WritePage.PBuffer));
#endif
            TransmitReplyStart();
           TransmitChar(INITIALISE);
           TransmitCheckSum();
           TransmitChar(TERMINATOR);
           break;
/*      case C_SET_TRANS_READ_PTR:
            // Same as FS2000
            TransReadPtr = FiveAsciiToHex(&SBuffer[2]);
           //  WriteIntToRTC(RTC_TRANS_RD_PTR_LOC,TransReadPtr);
            TransmitReplyStart();
            TransmitChar(SBuffer[COMMAND_POSITION]);
            TransmitCheckSum();
            TransmitChar(TERMINATOR);
         break;
      case C_SET_TRANS_WRITE_PTR:
         // Same as FS2000
         TransWritePtr = FiveAsciiToHex(&SBuffer[2]);
        //  WriteIntToRTC(RTC_TRANS_WR_PTR_LOC,TransWritePtr);
         TransmitReplyStart();
         TransmitChar(SBuffer[COMMAND_POSITION]);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_SET_TRANS_TOTAL_PTR:
         // Same as FS2000
         TotalNosOfTrans =FiveAsciiToHex(&SBuffer[2]);
         //WriteIntToRTC(RTC_TRANS_TOTAL_PTR_LOC,TotalNosOfTrans);
         TransmitReplyStart();
         TransmitChar(SBuffer[COMMAND_POSITION]);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
*/
      case C_ADD_CARD:
         // Same as FS2000
         Carddata.CardNo = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         Carddata.CardPin = (WORD) Carddata.CardNo;
         Carddata.CardInfo.Door1 = SBuffer[COMMAND_POSITION + 6] - '0';
         Carddata.CardInfo.Door2 = SBuffer[COMMAND_POSITION + 7] - '0';
         Carddata.CardInfo.Holiday=SBuffer[COMMAND_POSITION + 8] - '0';
         ptrdata = AddCard(Carddata);	//  mukund check

         TransmitReplyStart();
         if(ptrdata > 0)
         {
          	MsgPrint(MSG_WARNING,ptrdata,"Card Added ");
            TransmitChar(CARDADDED);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,GLOBAL_PORT);
#else			
	         SendDecimalIntToX(TotalCards,GLOBAL_PORT);
#endif
         }
         else
         {
          	MsgPrint(MSG_WARNING,ptrdata,"Card Added Fail");
            TransmitChar(CARDBUFF_FULL);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,GLOBAL_PORT);
#else			
	         SendDecimalIntToX(TotalCards,GLOBAL_PORT);
#endif
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_DELETE_CARD:
         // Same as FS2000
         TransmitReplyStart();
         Carddata.CardNo = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         Carddata.CardPin = (WORD)Carddata.CardNo;
#ifdef BIO_METRIC
		 if(F_BIO_COMM == SET)
         {
			CancelBioCommand();
			F_BIO_COMM =CLR;
         }
#endif
         ptrdata= DelCard(Carddata);
         if(ptrdata == CARD_NOT_FOUND)
         {
            TransmitChar(CARDNOTPRESENT);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,GLOBAL_PORT);
#else			
	         SendDecimalIntToX(TotalCards,GLOBAL_PORT);
#endif
         }
         else
         {

            TransmitChar(CARDDELETE);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,GLOBAL_PORT);
#else			
	         SendDecimalIntToX(TotalCards,GLOBAL_PORT);
#endif
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         if(ptrdata != CARD_NOT_FOUND)
         {
#ifdef BIO_METRIC
            ENABLE_BIO_COMM();
            DeleteBioUserID(Carddata.CardNo);
            DISABLE_BIO_COMM();
#endif
         }
         break;
      case C_SEARCH_CARD:
         // This is new command to search card in eeprom
         //$1s<card no>
         // $1s12345          this will search card no and print its all relevent data same as add card data
         Carddata.CardNo = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         ptrdata  = SearchDisplayCard(Carddata.CardNo,&Carddata);
         if(ptrdata != CARD_NOT_FOUND)
         {
            MsgPrint(MSG_WARNING,ptrdata,"search CardData ptr=");
            MsgPrint(MSG_WARNING,Carddata.CardNo,"CardNo");
            MsgPrint(MSG_WARNING,Carddata.CardPin,"Card Pin");
         }
         else
         {
            MsgPrint(MSG_WARNING,ptrdata,"Card not found ptr=");
         }

         TransmitReplyStart();
         if(ptrdata != CARD_NOT_FOUND)
         {
            TransmitChar(CARDPRESENT);
            SendDecimalIntToPC((WORD)Carddata.CardNo);
            TransmitChar(HexToAscii(Carddata.CardInfo.Door1));
            TransmitChar(HexToAscii(Carddata.CardInfo.Door2));
            TransmitChar(HexToAscii(Carddata.CardInfo.Holiday));
            SendDecimalIntToPC(Carddata.CardPin);
         }
         else
         {
            TransmitChar(CARDNOTPRESENT);
            SendDecimalIntToPC((WORD)Carddata.CardNo);
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_SET_DATE_TIME:
       	{  // Same as FS2000				 //ARMD0214
		struct DATE_TIME tmpdatetime;
		unsigned char temptime;
			temptime = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+1]);//hour
		if( temptime > 23 )
			goto fun_SetTimeDate_ERROR;
		tmpdatetime.Time.Hour = temptime;
		temptime  = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+3]);//minute
		if( temptime > 59 )
			goto fun_SetTimeDate_ERROR;
		tmpdatetime.Time.Min  =  temptime;
		tmpdatetime.Time.Secs =  0;
		temptime = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+6]);//day
		if( temptime > 31 )
			goto fun_SetTimeDate_ERROR;
		tmpdatetime.Date.Day = temptime; 
		temptime = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+8]);//month
		if( temptime > 12 )
			goto fun_SetTimeDate_ERROR;
		tmpdatetime.Date.Month = temptime;
		tmpdatetime.Date.Year = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+10]);
		temptime=SBuffer[COMMAND_POSITION+5]-'1'; //week day
		if( temptime > 6 )     					  //0=Sunday  6=Saturday
			goto fun_SetTimeDate_ERROR;
		Datetime.Time.Hour	=tmpdatetime.Time.Hour;
		Datetime.Time.Min	=tmpdatetime.Time.Min; 
		Datetime.Time.Secs	=tmpdatetime.Time.Secs;
		Datetime.Date.Day	=tmpdatetime.Date.Day;
		Datetime.Date.Month	=tmpdatetime.Date.Month;
		Datetime.Date.Year	=tmpdatetime.Date.Year; 
		SetRTCTimeDate( Datetime ,temptime );
         TransmitReplyStart();
         TransmitChar(C_SET_DATE_TIME);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         MsgPrint(MSG_WARNING,0,"Time Date Set");
		break;
fun_SetTimeDate_ERROR:
		TransmitReplyStart();
		TransmitChar('e');
		TransmitCheckSum();
		TransmitChar(TERMINATOR);
		MsgPrint(MSG_WARNING,0,"Time Date err");
		}
         break;
      case C_STATUS_SEC:
         // Same as Fc2000
         TransmitReplyStart();
         TransmitChar(STATUS);
         SendDecimalToPC(Datetime.Date.Day);
         SendDecimalToPC(Datetime.Date.Month);
         SendDecimalToPC(Datetime.Date.Year);
         TransmitChar(CWeekDay+'0');
         SendDecimalToPC(Datetime.Time.Hour);
         SendDecimalToPC(Datetime.Time.Min);
         SendDecimalToPC(Datetime.Time.Secs);
         SendDecimalLongToX6digit(TotalCards,GLOBAL_PORT);
         SendDecimalLongToX6digit(TotalNosOfTrans,GLOBAL_PORT);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_DOOROPEN_TIM :
         // Same as Fc2000
         Doorinfo.EXDOP_TIM1 = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+1]);
         Doorinfo.EXDOP_TIM2 = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+3]);
         Doorinfo.EXDOTL_DLY1 = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+5]);
         Doorinfo.EXDOTL_DLY2 = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+7]);
//       DoorInfo.DoorSetting.All = SerialAsciiToHex(&SBuffer[COMMAND_POSITION+9]);
         temp1 = SBuffer[COMMAND_POSITION +9] - '0';
         Doorinfo.EXShareDotl = 0;
         Doorinfo.FaclityCode_Chk =0;
         Doorinfo.APBEANABLE =0;
         if(temp1 & 0x01)
            Doorinfo.EXShareDotl = 1;
         if(temp1 & 0x02)
            Doorinfo.APBEANABLE=1;
         if(temp1 & 0x04)
               Doorinfo.FaclityCode_Chk = 1;

         temp1= SBuffer[COMMAND_POSITION +10] - '0';
         Doorinfo.FREETIMEENABLE = 0;
         Doorinfo.FREETIMEDOOR1 = 0;
         Doorinfo.FREETIMEDOOR2=0;
         if(temp1 & 0x01)
         {
            Doorinfo.FREETIMEENABLE = 1;
            if((SBuffer[COMMAND_POSITION +11] - '0')&0x01)
               Doorinfo.FREETIMEDOOR1 = 1;
            if((SBuffer[COMMAND_POSITION +11] - '0')&0x02)
               Doorinfo.FREETIMEDOOR2=1;
         }
         WriteDoorInfoToFlash();
         TransmitReplyStart();
         TransmitChar(C_DOOROPEN_TIM);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_GET_COMMANDS:
         // This is new command to get different valuse from eeprom look in to following function
         HandleGetCommands(SBuffer[COMMAND_POSITION+1],port);
         break;
      case C_DEABUG_LEVE:
         // This command is used to enable deabug command
         // in deabug mode system will print more messanges on serial port
         // $1dFF      this will enable deabug mode
         // $1d00       disable deabug mode
         DeabugLevel = SerialAsciiToHex(&SBuffer[COMMAND_POSITION+1]);
         TransmitReplyStart();
         TransmitChar(C_DEABUG_LEVE);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_FIRMWAREVER:
         TransmitReplyStart();
         TransmitStrToPC((BYTE *)ProdVerStr); 
         TransmitChar(MAJOR_VER);
         TransmitChar('.');
         TransmitChar(MINOR_VER);
         TransmitChar('A');
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
//		 while(1){}			//Added for watchdog testing
         break;
     /* case C_ADMIN_USER_ADD:
         // This command is to add admin user . Admin user is used to do admin function in stand alone controller
         // in keyboard mode
         //<5 char user no><5 char user password>
         //$1a1234522222
         // this will add user 12345 with pin 22222
         // there are max 8 users possible
         Carddata.CardNo  = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         Carddata.CardPin = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +6]);
         ptrdata = AddAdminUser(Carddata);
         TransmitReplyStart();
         if(ptrdata > 0)
         {
            TransmitChar(C_ADMIN_USER_ADD);
         }
         else
         {
            TransmitChar('E');
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_ADMIN_USER_DEL:
         // Delete admin user
         //<5 char user no>
         //$1b12345
         //this will delete user no 12345
         Carddata.CardNo = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         ptrdata = DelAdminUser(Carddata);
         TransmitReplyStart();

         if(ptrdata > 0)
         {
            TransmitChar(C_ADMIN_USER_DEL);
         }
         else
         {
            TransmitChar('E');
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_ADMIN_USER_DEL_BY_LOC:
         // this woll delete admin user from eeprom by giving location.. total 0 to 7 locations are possible
         // <location 1 char>
         //$1c1      this will delete admin user no 1
         //$1c0      this will delete admin user no 0
         DelAdminUserByLocation(SBuffer[COMMAND_POSITION +1]-'0');

         TransmitReplyStart();
         TransmitChar(C_ADMIN_USER_DEL_BY_LOC);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;*/
      case C_SET_SLAVE_NO:
         // This command is to set slave no
         // $1e<two digit decimal no>
         // $1e01    this will set slave no to 1
         // $1e08    this will set slave no to 8
         // slave no starts from 1 to 32

         ptrdata = SerialDecimalToHex(&SBuffer[COMMAND_POSITION+1]);

        

         if((ptrdata >=1 ) &&(ptrdata<=64))
         {
            SysInfo.MySlaveNo = ptrdata &0x00FF;
            TransmitReplyStart();
            TransmitChar(C_SET_SLAVE_NO);
            TransmitCheckSum();
            TransmitChar(TERMINATOR);

         }
         else
         {
            TransmitReplyStart();
            TransmitChar('E');
            TransmitCheckSum();
            TransmitChar(TERMINATOR);
         }
         WriteSysInfoToFlash();
         break;
/*
      case C_PREV_TRNX:
            if(F_BulkDownload == SET)
            {
              //  WriteIntToRTC(RTC_TRANS_RD_PTR_LOC,PrevReadPtr);
              //  WriteIntToRTC(RTC_TRANS_TOTAL_PTR_LOC,PrevTotalTrans);
               ptrdata = PrevBulkDownload;
               while(ptrdata--)
               {
                  CheckSum =0;
                  F_CheckSum = SET;
                  TransmitReplyStart();
                  if( SendTransaction() == -1)
                  {
                     break;
                  }
                  DeleteTransaction();
               }
            }
            else
            {
               TransmitReplyStart();
               TransmitChar('E');
               TransmitCheckSum();
               TransmitChar(TERMINATOR);
            }
            break;
*/
      case C_DUMP_TRNX:
			if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
			{
				if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
					return;
			}
			ptrdata = temp1 = (ThreeAsciiToHex(&SBuffer[COMMAND_POSITION +2]))&0xFF;
       		TempTransReadPtr = TransReadPtr;
			TempTotalNosTrans = TotalNosOfTrans;
			if(temp1 == 0)
			{
				TransmitReplyStart();
				TransmitChar('E');
				TransmitCheckSum();
				TransmitChar(TERMINATOR);
				break;
			}
			while(1)
			{
				if(ReadCurrentTransaction(&trans) == -1)
					break;
				else
				{
					CheckSum =0;
					F_CheckSum = SET;
					enetptr = 0;
//					memset(trnsbuffer, 0, sizeof(trnsbuffer));
					TransmitReplyStart();
					HandelSerialSendTrans(trans);
					TransmitCheckSum();
					TransmitChar(TERMINATOR);
#ifdef ETHERNET_OLD
     				SendtoEthernet();
#endif
					if(F_EthernetReceived)
					{
#ifdef ETHERNET
						SendSerialDataToEthernetPort(1);
#else
#ifndef TELNET_TEST
						F_CheckSum = CLR;
						PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
						fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE,PortObj[SER_TCPIP_PORT].BufPtr);
#endif
#endif
					}
					DeleteTransaction();
				}
				temp1--;
				if(temp1 == 0)
					break;
			}
			CheckSum = 0;
         	enetptr = 0;
			F_CheckSum = SET;
			TransmitReplyStart();
			TransmitChar('G');
			SendDecimalIntToPC((ptrdata- temp1));
			TransmitCheckSum();
			TransmitChar(TERMINATOR);
			TransReadPtr = TempTransReadPtr;
			TotalNosOfTrans = TempTotalNosTrans;
        	break;
/*
            ptrdata = ThreeAsciiToHex(&SBuffer[COMMAND_POSITION +2]);
            F_BulkDownload = SET;
            PrevReadPtr  = ReadIntFromRTC(RTC_TRANS_RD_PTR_LOC);
            PrevTotalTrans = ReadIntFromRTC(RTC_TRANS_TOTAL_PTR_LOC);
            PrevBulkDownload = ptrdata ;
             if(ReceiveCount>6)
             {
               while(ptrdata--)
               {
                  CheckSum =0;
                  F_CheckSum = SET;
                  TransmitReplyStart();
                  if( SendTransaction() == -1)
                  {
                     break;
                  }
                  DeleteTransaction();
               }
             } 
         break;*/
	case C_TRNX_STORE:

		TotalNosOfTrans = 0;
		TransWritePtr = 0;
		TransReadPtr = 0;
#ifdef ENABLE_WATCHDOG
		WDTHandleType = WDT_C_TRNX_STORE;
#endif

        ptrdata = 0;
		while(1)
		{
			ptrdata++;
			StoreCardInTrDB(ptrdata ,0x1,EVENT_VALID_CARD);
			if(ptrdata >= MAX_TRANS-1)
				break;
#ifdef ENABLE_WATCHDOG
			if(ptrdata % 20 == 0)
			{
				WDTFeed();		//Clear watchdog timer
			}
#endif
		}
#ifdef ETHERNET_ENABLE
			(MULTISTART_TABLE*)uTaskerSchedule();
#endif						
		TransmitReplyStart();
		TransmitChar(C_TRNX_STORE);
		TransmitCheckSum();
		TransmitChar(TERMINATOR);
		break;

      case C_FACILITYCODE:
         //This Command is used to set facility code
         //$1h0111 where 111 is facility code
         //Facility code Min:0 - Max:254
         ptrdata = ThreeAsciiToHex(&SBuffer[COMMAND_POSITION+2]);
         if((SBuffer[COMMAND_POSITION +1]-'0') <= 7)
         {
			if((ptrdata >= 0) && (ptrdata <= 0xFF))
			{
				//ptrdata = ptrdata &0x0FFF;
				SysInfo.FacilityCodeNo[SBuffer[COMMAND_POSITION+1]-'0'] = ptrdata;
				TransmitReplyStart();
				TransmitChar(C_FACILITYCODE);
				TransmitCheckSum();
				TransmitChar(TERMINATOR);
				MsgPrint(1,(SysInfo.FacilityCodeNo[SBuffer[COMMAND_POSITION+1]-'0']),"Facility Code=");
				WriteSysInfoToFlash();
			}
         }
         else
         {
            TransmitReplyStart();
            TransmitChar('E');
            TransmitCheckSum();
            TransmitChar(TERMINATOR);
         }
         break;

      case C_ADD_CARD_PIN:
         //This Command is uded to add card with VF and NVF setting.
         //$1ECCCCCTTHPPPPPV where CCCCC is card no TT is time zone for two doors H is Holiday
         //PPPPP is pin no. and V is VF or NVF information.
         Carddata.CardNo = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         Carddata.CardPin = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +9]);
         Carddata.CardInfo.Door1 = SBuffer[COMMAND_POSITION + 6] - '0';
         Carddata.CardInfo.Door2 = SBuffer[COMMAND_POSITION + 7] - '0';
         Carddata.CardInfo.Holiday=SBuffer[COMMAND_POSITION + 8] - '0';
         TransmitReplyStart();
/*         if(((SBuffer[COMMAND_POSITION + 14] - '0')==0)||((SBuffer[COMMAND_POSITION + 14] - '0')==1))
         {*/
            Carddata.Info.CType = SBuffer[COMMAND_POSITION + 14] - '0';
            ptrdata = AddCard(Carddata);

            if(ptrdata > 0)
            {
               TransmitChar(C_ADD_CARD_PIN);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,PC_PORT);
#else			
	         SendDecimalIntToX(TotalCards,PC_PORT);
#endif
            }
            else
            {
               TransmitChar(CARDBUFF_FULL);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,PC_PORT);
#else			
	         SendDecimalIntToX(TotalCards,PC_PORT);
#endif
            }
/*         }
        else
         {
            TransmitChar('E');
         }
*/
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;

      case C_DELETE_DUMP_TRNX:
		if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))
		{
			if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
				break;
		}
         TempTotalNosTrans = TotalNosOfTrans;
         ptrdata = ThreeAsciiToHex(&SBuffer[COMMAND_POSITION +1]);
         while(ptrdata--)
         {
            if(DeleteTransaction() != 0)
               break;
         }
         TransmitReplyStart();
         TransmitChar(C_DELETE_DUMP_TRNX);
         SendDecimalLongToX6digit((TempTotalNosTrans - TotalNosOfTrans),PC_PORT);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_CARD_DATA:
         TransmitReplyStart();
         TransmitChar(C_CARD_DATA);
         if(FaclityCode2 ==1)
	         SendDecimalToPC3Char(FaclityCode1);
         else
	         SendDecimalToPC3Char(FaclityCode2);
         SendDecimalIntToPC((WORD )ReceivedCardNo  );
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
/*      case C_UNLOCK_DOOR:
         //$1OUD           where U = 0 Open , U = Close          D= Door number 1 , 2
         HandelSerialUnlockDoor();
         TransmitReplyStart();
         TransmitChar(C_UNLOCK_DOOR);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;*/
      case C_SET_TIME_ZONE:
         ptrdata = SBuffer[COMMAND_POSITION +1] - '0';
         ptrdata = ptrdata &0xFF;
         ptrdata --;
         temp1 = SBuffer[COMMAND_POSITION +2] - '0';
         temp1--;
		 GetTimeZone(ptrdata,&Timezone);
         Timezone.TimeZone[temp1].TZSlotNo[0].StarHours = ConvertAsciiSbuffToHex(COMMAND_POSITION+3);
         Timezone.TimeZone[temp1].TZSlotNo[0].StarMin = ConvertAsciiSbuffToHex(COMMAND_POSITION+5);
         Timezone.TimeZone[temp1].TZSlotNo[0].EndHours =ConvertAsciiSbuffToHex(COMMAND_POSITION+7 );
         Timezone.TimeZone[temp1].TZSlotNo[0].EndMin = ConvertAsciiSbuffToHex(COMMAND_POSITION+9);
		
//		 MainMem_ReadPage(msgpageno,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);	
//         root2xmem((unsigned long)TIME_ZONE_BASE+(unsigned long)((unsigned long)sizeof(Timezone)*(unsigned long)ptrdata), &Timezone,sizeof(Timezone));
//         TimeZoneBackup();
		 SaveTimeZone(ptrdata,&Timezone);
         TransmitReplyStart();
         TransmitChar(C_SET_TIME_ZONE);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
      case C_HOLIDAY:
 /*        temp1 = ConvertAsciiSbuffToHex(COMMAND_POSITION+1);
         temp1  --;
         Holiday.Day = ConvertAsciiSbuffToHex(COMMAND_POSITION+3);
         Holiday.Month = ConvertAsciiSbuffToHex(COMMAND_POSITION+5);
         Holiday.Year = ConvertAsciiSbuffToHex(COMMAND_POSITION+7);
         root2xmem((unsigned long)HOLIDAY_BASE+(unsigned long)((unsigned long)temp1*(unsigned long)sizeof(Holiday)),(BYTE *)&Holiday, sizeof(Holiday));
         HolidayBackup();
         TransmitReplyStart();
         TransmitChar(C_HOLIDAY);
         TransmitCheckSum();
         TransmitChar(TERMINATOR); */
         break;
#ifdef ETHERNET
      case C_ETHERNETSETTING:
//           xmem2root(&SysInfo,SYSTEMINFO_BASE,SYSTEM_INFO_BYTES);
           switch(SBuffer[COMMAND_POSITION+1])
   		  {
           		case '1':
                  for(temp1=0;temp1<15;temp1++)
	                   SysInfo.LOCAL_IP[temp1] =SBuffer[COMMAND_POSITION+(2+temp1)];
	                   SysInfo.LOCAL_IP[temp1] ='\0';
               break;
               case '2':
                  for(temp1=0;temp1<15;temp1++)
	                   SysInfo.LOCAL_NETMASK[temp1] =SBuffer[COMMAND_POSITION+(2+temp1)];
	                   SysInfo.LOCAL_IP[temp1] ='\0';
	            break;
               case '3':
                  for(temp1=0;temp1<15;temp1++)
	                   SysInfo.LOCAL_GATEWAY[temp1] =SBuffer[COMMAND_POSITION+(2+temp1)];
	                   SysInfo.LOCAL_IP[temp1] ='\0';
	            break;
               case '4':
                      SysInfo.ETH_Port = FiveAsciiToHex(&SBuffer[COMMAND_POSITION +2]);
               break;
	            case '5':
#ifdef ETHERNET
//   						SocketTcpPort = SysInfo.ETH_Port;
							InitialiseSocket(aton(SysInfo.LOCAL_IP),aton(SysInfo.LOCAL_NETMASK),aton(SysInfo.LOCAL_GATEWAY));
#endif

              break;
	        }
           TransmitReplyStart();
           TransmitChar(C_ETHERNETSETTING);
           TransmitCheckSum();
           TransmitChar(TERMINATOR);
           WriteSysInfoToFlash();
           break;
#endif
      default:
         TransmitReplyStart();
         TransmitChar(SBuffer[COMMAND_POSITION]);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         MsgPrint(1,SBuffer[COMMAND_POSITION],"default serial");
         break;
      }
goto_serial_end:
#ifdef ETHERNET_OLD
		SendtoEthernet();
#endif
	if(F_EthernetReceived)
	{
#ifdef ETHERNET
		SendSerialDataToEthernetPort(1);
#else
#ifndef TELNET_TEST
		F_CheckSum = CLR;
		PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
		fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE,PortObj[SER_TCPIP_PORT].BufPtr);
#endif
#endif
	}

}

#ifdef ETHERNET

ss
/*-----------------------------------------------------------*/
void SendtoEthernet(void)
{
// for check sum and termenator
      if(F_EthernetReceived)
      {
      	F_CheckSum = CLR;
	      trnsbuffer[enetptr] =  HexToAscii( SwapChar(CheckSum)  & 0x0f) ;
	      enetptr++;
	      trnsbuffer[enetptr] = HexToAscii( CheckSum & 0x0f);
	      enetptr++;
	      trnsbuffer[enetptr] = TERMINATOR;
	      enetptr++;
	//      sock_write( state->s, trnsbuffer, enetptr );
      }
	 
}

/*--------------------------------------------------------------------------------------------*/
void SendSerialDataToEthernetPort( WORD socketno)
{
	// for check sum and termenator
      	  F_CheckSum = CLR;
		 PortObj[SER_TCPIP_PORT].F_ChkSum=CLR;
		 memcpy(TCP_TX_BUF, PortObj[SER_TCPIP_PORT].Buffer,PortObj[SER_TCPIP_PORT].BufPtr);
         TCPTxDataCount = PortObj[SER_TCPIP_PORT].BufPtr;   // bytes to xfer
         TCPTransmitTxBuffer();                   // xfer buffer

//         WriteDataToSocket(socketno,trnsbuffer,enetptr);

}
#endif


/*-------------------------------------------------------------------------*/



/*
void HandelSerialUnlockDoor(void)
{  BYTE tempdata;
   tempdata = SBuffer[COMMAND_POSITION +1] - '0';
   if(tempdata == 1)
   {  if((SBuffer[COMMAND_POSITION +2] - '0')==1)
      {  F_Door1_Open_TimeOut = CLR;
         Doorinfo.PC_D00R1_OPEN = SET;
         SendDoorOpen(1);
      }
      if((SBuffer[COMMAND_POSITION +2] - '0')==2)
      {  F_Door2_Open_TimeOut = CLR;
         Doorinfo.PC_D00R2_OPEN = SET;
         SendDoorOpen(2);
      }
      if((SBuffer[COMMAND_POSITION +2] - '0')==3)
      {  F_Door1_Open_TimeOut = CLR;
         Doorinfo.PC_D00R1_OPEN = SET;
         Doorinfo.PC_D00R2_OPEN = SET;
         SendDoorOpen(1);
         F_Door2_Open_TimeOut = CLR;
         SendDoorOpen(2);
      }
   }
   else if(tempdata == 0)
   {
      if((SBuffer[COMMAND_POSITION +2] - '0')==1)
      {
         Doorinfo.PC_D00R1_OPEN = CLR;
         SendDoorClose(1);

      }
      if((SBuffer[COMMAND_POSITION +2] - '0')==2)
      {
         Doorinfo.PC_D00R2_OPEN = CLR;
         SendDoorClose(2);

      }
      if((SBuffer[COMMAND_POSITION +2] - '0')==3)
      {  Doorinfo.PC_D00R1_OPEN = CLR;
         Doorinfo.PC_D00R2_OPEN = CLR;
         SendDoorClose(1);
         SendDoorClose(2);
      }

   }
  // root2xmem(DOORINFO_BASE,&Doorinfo,sizeof(Doorinfo));
 //  SendAckData(UNLOCKDOOR);

   return;

}

*/

/*-------------------------------------------------------------------------*/

void Hexto5Ascii(WORD tdata)
{  SBuffer[0]=(tdata/10000)+'0';
   tdata%=10000;
   SBuffer[1]=(tdata/1000)+'0';
   tdata%=1000;
   SBuffer[2]=(tdata/100)+'0';
   tdata%=100;
   SBuffer[3]=(tdata/10)+'0';
   tdata%=10;
   SBuffer[4]=tdata+'0';
   return;
}
/*--------------------------------------------------------------------------------------*/

void Hexto3Ascii(BYTE tempdata)
{
   SBuffer[0]=(tempdata/100)+'0';
   tempdata%=100;
   SBuffer[1]=(tempdata/10)+'0';
   tempdata%=10;
   SBuffer[2]=tempdata+'0';
   return;
}

/*--------------------------------------------------------------------------------------*/

void Hexto2Ascii(BYTE tempdata)
{
   SBuffer[0]=(tempdata/10)+'0';
   tempdata%=10;
   SBuffer[1]=tempdata+'0';
   return;
}

/*--------------------------------------------------------------------------*/

 WORD FiveAsciiToHex(volatile BYTE *ptr)
{    WORD temp,tdata;
   temp =  AsciiToHex(*ptr);
   temp*=10000;
   ptr++;
   tdata = AsciiToHex(*ptr);
   temp += tdata*1000;
   ptr++;
   tdata = AsciiToHex(*ptr);
   tdata *= 100;
   temp += tdata;
   ptr++;
   tdata = AsciiToHex(*ptr);
   tdata *= 10;
   temp += tdata;
   ptr++;
   tdata = AsciiToHex(*ptr);
   tdata += temp;

   return(tdata);
}
/*-------------------------------------------------------------------------*/

BYTE ThreeAsciiToHex(volatile BYTE *ptr)
{  BYTE tdata,temp;
   temp = 0;
   tdata = AsciiToHex(*ptr);
   tdata *= 100;
   temp += tdata;
   ptr++;
   tdata = AsciiToHex(*ptr);
   tdata *= 10;
   temp += tdata;
   ptr++;
   tdata = AsciiToHex(*ptr);
   tdata += temp;
   return(tdata);
}

/*--------------------------------------------------------------------------*/

WORD HexNoToInteger(BYTE *ptr)
{
   WORD temp;
   temp = AsciiToHex(*ptr) * 4096;
   ptr++;
    temp = temp + AsciiToHex(*ptr) * 256;
   ptr++;
      temp = temp + AsciiToHex(*ptr) * 16;
   ptr++;
    temp = temp + AsciiToHex(*ptr);
   return(temp);
}


/*----------------------------------------------------------------------*/

void HandelSerialInitialise(void)
{
   
   TotalNosOfTrans = TransWritePtr = TransReadPtr = 0;
   F_TransCrossOver = CLR;
   
	InitialiseFlags = DELETE_ALL_CARDS | DELETE_ALL_DOORINFO | DELETE_ALL_TIMEZONE | 
					DELETE_ALL_FACILITY_CODE | DELETE_ALL_ADMIN_USER | DELETE_ALL_HOLIDAY |
					DELETE_ALL_INI_DEF_SYSTEM ; //ARMF0377
   DelAllCards();
    MsgPrint(MSG_WARNING,1,"Card Deleted");
   DelAllDoorInfo();
  	MsgPrint(MSG_WARNING,1,"Door Info Deleted");
   DelAllTimeZone();
   MsgPrint(MSG_WARNING,1,"Time Zone Deleted");
   DelAllFacilityCode();
   MsgPrint(MSG_WARNING,1,"Falicity Code Deleted");
   DelAllAdminUser();
   MsgPrint(MSG_WARNING,1,"Admin User Deleted");
   DelAllHoliday();
   MsgPrint(MSG_WARNING,1,"Holiday Deleted");
   IniDefaultSysInfo();
   MsgPrint(MSG_WARNING,1,"Default System Info");
   InitialiseFlags = 0;
return;
}


/*---------------------------------------------------------------------*/



void HandleAllCardDelete(void)
{
//    DeleteAllCards();

//   SendAckData(INITIALISE);

   return;
}
/*-------------------------------------------------------------------------*/


void HandleAllTrnxDelete(void)
{  WORD i;
   TotalNosOfTrans = 0;
   TransWritePtr = 0;
   TransReadPtr = 0;
   F_TransCrossOver = CLR;
   memset((BYTE *)SBuffer, PAGE_SIZE, 0);
   for(i=0;i<(MAX_TRANS/MaxBuffTrnx) ;i++)
   {
		MainMem_BuffWrt(0,1,(BYTE *)SBuffer,PAGE_SIZE );
	    BuffWrt_MainMem(i,1);
//            sf_writeRAM(WritePage, 0, sf_blocksize);
//            sf_RAMToPage(i);

   }
//   SendAckData(INITIALISE);

   return;
}

/*---------------------------------------------------------------------*/


void HandelSerialMemoryMap(void)
{
BYTE tempdata;
WORD i,address;
   address = FiveAsciiToHex(SBuffer+COMMAND_POSITION + 1);
//   sf_pageToRAM(address);
//   tempdata = sf_readRAM(readflash_buf, 0, sf_blocksize);

   for(i=0;i<SPIBUFSIZE;i++)
   {
      if(!(i%16) )
      {
         TransmitChar('\n');
         SendIntBCDToPC(address+i);
         TransmitChar(':');

      }
//      tempdata=readflash_buf[i];
      TransmitChar(HexToAscii(SwapChar(tempdata) &0x0f));
      TransmitChar(HexToAscii(tempdata &0x0f));
  }
   TransmitChar('\n');

//   SendAckData(MEMORYMAP);

      return;
}
/*---------------------------------------------------------------------*/


void SendIntBCDToPC(register WORD data1)
{  
   TransmitChar( HexToAscii((unsigned char) (data1/0x01000)  & 0x000F)) ;
   TransmitChar(HexToAscii( (unsigned char)(data1/ 0x100)& 0x00F));
   TransmitChar( HexToAscii((unsigned char)(data1/0x10)  & 0x00F)) ;
   TransmitChar(HexToAscii((unsigned char) (data1& 0x000F)));
}

void SendLongBCDToPC(unsigned int data1)
{  
	SendIntBCDToPC(data1 / 0x10000);
	SendIntBCDToPC(data1 &0x0000FFFF);
}
/*---------------------------------------------------------------------*/

void MsgPrint(BYTE msgtype, long msgdata,  BYTE *str)
{
   BYTE tempsum;
//   BYTE tmpstr[10];
   tempsum = PortObj[GLOBAL_PORT].F_ChkSum;
   PortObj[GLOBAL_PORT].F_ChkSum = CLR;
   if(msgtype & DeabugLevel)
   {
		TransmitStrToPC(str);
		TransmitChar('<');
		if(msgdata<=0xFFFF)
			SendIntBCDToPC((WORD)msgdata);
		else
			SendLongBCDToPC(msgdata);
		TransmitChar('H');
		TransmitChar('>');
		TransmitChar('<');
		if(msgdata<=0xFFFF)
			SendDecimalIntToX(msgdata,PC_PORT);
		else
			SendDecimalLongToX(msgdata,PC_PORT);
		TransmitChar('>');
		TransmitChar('\r');
   }
   if(tempsum == 1)
      	PortObj[GLOBAL_PORT].F_ChkSum = SET;
}
/*---------------------------------------------------------------------*/

void SendDecimalIntToPC(WORD tdata)
{
   TransmitChar((tdata/10000)+'0');

   tdata%=10000;
   TransmitChar((tdata/1000)+'0');

   tdata%=1000;
   TransmitChar((tdata/100)+'0');

   tdata%=100;
   TransmitChar((tdata/10)+'0');

   tdata%=10;
   TransmitChar(tdata+'0');
  //  printf("%d",tdata);
}
/*---------------------------------------------------------------------*/

void TransmitStrToPC(BYTE *str)
{
   while(1)
   {
      if(*str == '\0')
         break;
    //  printf("%c",*str);
      TransmitChar(*str);
      str++;
   }
}
/*--------------------------------------------------------------------*/

short SendBulkTransaction(void)
{
/*   _TRANSData trans;
   int ptr;
  // ptr = ReadAndDelTransaction(trans);
   if(ptr == -1)
   {
      // Transaction not found
      TransmitChar('T');
      TransmitCheckSum();
      TransmitChar(TERMINATOR);
   }
   else
   {
      HandelSerialSendTrans(trans);
      TransmitCheckSum();
      TransmitChar(TERMINATOR);
   }		   */
   return(0);
}
/*-----------------------------------------------------------*/


short  SendTransaction(void)
{ // _TRANSData trans;
   int ptr;
   ptr = ReadCurrentTransaction(&UExTrnxData);
//    MsgPrint(MSG_MEM,UExTrnxData.CardNo,"READ TRNX 1:cardNo =");
   if(ptr == -1)
   {
      // Transaction not found
      TransmitChar('T');
      TransmitCheckSum();
      TransmitChar(TERMINATOR);
   }
   else
   {
      HandelSerialSendTrans(UExTrnxData);
      TransmitCheckSum();
      TransmitChar(TERMINATOR);
   }
   return(ptr);
}
/*-----------------------------------------------------------*/


void HandleGetCommands(BYTE command ,unsigned char port)
{

WORD TempTransReadPtr,TempTotalNosTrans,tdata;
short location,t_data;
_TRANSData trans;
_TIMEZONE timezone;

   switch(command)
   {

   case C_ADD_CARD_PIN:
         TransmitReplyStart();
         TransmitChar(C_ADD_CARD_PIN);
        if(SBuffer[COMMAND_POSITION +2]=='S')
		  {
	         LastCardAddedPtr =SearchCardLastCard();
	         if( LastCardAddedPtr== CARD_NOT_FOUND)
	         {
	            MsgPrint(MSG_WARNING,LastCardAddedPtr,"Main:LastCardAddedPtr");
	            LastCardAddedPtr = 01;
	         }
				else
            	LastCardAddedPtr++;
	         	MsgPrint(MSG_WARNING,LastCardAddedPtr,"Main:LastCardAddedPtr");
				SendDecimalIntToPC(LastCardAddedPtr);
        }
        else if(SBuffer[COMMAND_POSITION +2]=='D')
        {
        		DumpAllCardData();
        }
        else if((SBuffer[COMMAND_POSITION +2]=='X')&&(SBuffer[COMMAND_POSITION +3]=='x'))
        {
        		t_data = AddMultipleTestCards(FiveAsciiToHex(&SBuffer[COMMAND_POSITION +4]));
            if(t_data == -1)
	            TransmitChar('E');
            else
               SendDecimalIntToPC(tdata);
        }
        else if (SBuffer[COMMAND_POSITION +2]=='E')
        {
//	        AddCard_Loc(FiveAsciiToHex(&SBuffer[COMMAND_POSITION +3]),SBuffer[COMMAND_POSITION +8]-'0');
        }
        TransmitCheckSum();
        TransmitChar(TERMINATOR);
   break;
   case C_DOOROPEN_TIM :
        //  ReadStringFromSE2(DOORINFO_BASE,(BYTE *)&DoorInfo,DOOR_INFO_BYTE);
       //  xmem2root((BYTE *) &Doorinfo,DOORINFO_BASE,DOORINFO_BYTES);
         TransmitReplyStart();
         TransmitChar(C_DOOROPEN_TIM);
         SendDecimalToPC(Doorinfo.EXDOP_TIM1);
         SendDecimalToPC(Doorinfo.EXDOP_TIM2 );
         SendDecimalToPC(Doorinfo.EXDOTL_DLY1);
         SendDecimalToPC(Doorinfo.EXDOTL_DLY2);
         t_data =0;
         if(Doorinfo.EXShareDotl == 1)
            t_data = 0x01;
         if(Doorinfo.FaclityCode_Chk ==1)
            t_data = t_data | 0x02;
         if(Doorinfo.APBEANABLE ==1)
            t_data = t_data | 0x04;
         TransmitChar(t_data+'0');
         if( Doorinfo.FREETIMEENABLE==1)
            TransmitChar('1');
         else
            TransmitChar('0');
         t_data = 0;
         if(Doorinfo.FREETIMEDOOR1==1)
            t_data = 0x01;
         if(Doorinfo.FREETIMEDOOR2 ==1)
            t_data = t_data|0x02;
         TransmitChar(t_data + '0');
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
   case C_SET_TRANS_READ_PTR:
        //  TransReadPtr = ReadIntFromRTC(RTC_TRANS_RD_PTR_LOC);
         TransmitReplyStart();
         TransmitChar(command);
         SendDecimalIntToPC(TransReadPtr);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
   case C_SET_TRANS_WRITE_PTR:
       //   TransWritePtr = ReadIntFromRTC(RTC_TRANS_WR_PTR_LOC);
         TransmitReplyStart();
         TransmitChar(command);
         SendDecimalIntToPC(TransWritePtr);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
   case C_SET_TRANS_TOTAL_PTR:
      // TotalNosOfTrans = ReadIntFromRTC(RTC_TRANS_TOTAL_PTR_LOC);
         TransmitReplyStart();
         TransmitChar(command);
         SendDecimalIntToPC(TotalNosOfTrans );
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
   case C_READ_ALL_PTR:
       //   TransReadPtr = ReadIntFromRTC(RTC_TRANS_RD_PTR_LOC);
      // TransWritePtr = ReadIntFromRTC(RTC_TRANS_WR_PTR_LOC);
     //     TotalNosOfTrans = ReadIntFromRTC(RTC_TRANS_TOTAL_PTR_LOC);
         TransmitReplyStart();
         TransmitChar(C_READ_ALL_PTR);
         TransmitChar('R');
         SendDecimalLongToX6digit(TransReadPtr,GLOBAL_PORT);
         TransmitChar('W');
         SendDecimalLongToX6digit(TransWritePtr,GLOBAL_PORT);
         TransmitChar('T');
         SendDecimalLongToX6digit(TotalNosOfTrans,GLOBAL_PORT);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
   case C_FACILITYCODE:
         TransmitReplyStart();
         TransmitChar(command);
         for(location=0;location<=7;location++)
         {
            SendDecimalToPC3Char(SysInfo.FacilityCodeNo[location]);
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;

   case C_HOLIDAY:
         TransmitReplyStart();
         TransmitChar(command);
         t_data = ConvertAsciiSbuffToHex(COMMAND_POSITION+2);
         t_data  --;
//         xmem2root(&Holiday,HOLIDAY_BASE+(t_data*sizeof(Holiday)), sizeof(Holiday));
         SendDecimalToPC(Holiday.Day);
         SendDecimalToPC(Holiday.Month);
         SendDecimalToPC(Holiday.Year);
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;

/*   case C_ADMIN_USER_ADD:		 //ARMD0262
         TransmitReplyStart();
         location = SBuffer[COMMAND_POSITION+2]-'0';
         if((location >=0)&&(location <=7))
         {
            TransmitChar(command);
			MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);	
			memcpy(&Carddata,&tempwrbuf[location*ADMIN_DATA_BYTES],ADMIN_DATA_BYTES);
            MsgPrint(1,1,"ERROR C_ADMIN_USER_ADD ");
            SendDecimalIntToPC((WORD)Carddata.CardNo);
            SendDecimalIntToPC(Carddata.CardPin);
         }
         else
         {
            TransmitChar('E');
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         break;
*/
   case C_SET_TIME_ZONE:
   //To get the time zone of the Controller for Reader1 & Reader2 $3lI<Timezone no><Dayofweek>
//In response it will send #3I<Start time><End time>
//If weekday is sent zero along with any time-zone value(1 to 7) it
//returns seven weekday's time-zone values for that particular time-zone.
         CheckSum = 0;
         F_CheckSum = SET;
         TransmitReplyStart();
         location = SBuffer[COMMAND_POSITION +2] - '1';
         t_data = SBuffer[COMMAND_POSITION +3] - '0';
       	location--;
		GetTimeZone(location,&Timezone);
//         xmem2root(&timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)location),TIME_ZONE_BYTES);
         if(t_data == 0)
         {
            TransmitChar(C_SET_TIME_ZONE);
            if((location >= 0)&&(location <= 7))
            {
               for(t_data = 0;t_data < 7;t_data++)
               {
                  if(t_data > 0)
                     TransmitChar(' ');
                  SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].StarHours);
                  SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].StarMin);
                  SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].EndHours);
                  SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].EndMin);
               }
            }
            else
            {
               TransmitChar('E');
            }
         }
         else if((location <= 8)&&(t_data <= 7))
         {
            if(location>=0)
            {
               t_data--;
               TransmitChar(C_SET_TIME_ZONE);
               SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].StarHours);
               SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].StarMin);
               SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].EndHours);
               SendDecimalToPC(timezone.TimeZone[t_data].TZSlotNo[0].EndMin);
            }
            else
               TransmitChar('E');
         }
         else
         {
            TransmitChar('E');
         }
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         MsgPrint(1,location,"Timezone=");
         MsgPrint(1,t_data,"Day of Week=");
         break;
   case C_DUMP_TRNX:
			if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))
			{
				if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
					return;
			}
//This command will download specified no of transactions without deleting them.
//Command format
//          $1lj<no. of transactions>
         location = t_data = (ThreeAsciiToHex(&SBuffer[COMMAND_POSITION +2]))&0xFF;
        //  TransReadPtr = ReadIntFromRTC(RTC_TRANS_RD_PTR_LOC);
       //   TransWritePtr = ReadIntFromRTC(RTC_TRANS_WR_PTR_LOC);
        //  TotalNosOfTrans = ReadIntFromRTC(RTC_TRANS_TOTAL_PTR_LOC);
         TempTransReadPtr = TransReadPtr;
         TempTotalNosTrans = TotalNosOfTrans;
         while(1)
         {
            if(ReadCurrentTransaction(&trans) == -1)
               break;
            else
            {
               CheckSum =0;
               F_CheckSum = SET;
               TransmitReplyStart();
               HandelSerialSendTrans(trans);
               TransmitCheckSum();
               TransmitChar(TERMINATOR);
               DeleteTransaction();
            }
            t_data--;
            if(t_data ==0 )
               break;
         }
         CheckSum =0;
         F_CheckSum = SET;
         TransmitReplyStart();
         TransmitChar('t');
         SendDecimalIntToPC((location - t_data));
         TransmitCheckSum();
         TransmitChar(TERMINATOR);
         TransReadPtr = TempTransReadPtr;
         TotalNosOfTrans = TempTotalNosTrans;
       //   WriteIntToRTC(RTC_TRANS_TOTAL_PTR_LOC,TotalNosOfTrans);
      // WriteIntToRTC(RTC_TRANS_RD_PTR_LOC,TransReadPtr);
         break;
#ifdef ETHERNET
      case C_ETHERNETSETTING:


           if(SBuffer[COMMAND_POSITION+2] == '1')
              memcpy(&SBuffer,&SysInfo.LOCAL_IP,15);
           else if(SBuffer[COMMAND_POSITION+2] == '2')
              memcpy(&SBuffer,&SysInfo.LOCAL_NETMASK,15);
           else if(SBuffer[COMMAND_POSITION+2] == '3')
              memcpy(&SBuffer,&SysInfo.LOCAL_GATEWAY,15);

         CheckSum =0;
         F_CheckSum = SET;
         TransmitReplyStart();
         TransmitChar('G');
         for(t_data = 0;t_data<15;t_data++)
         {
          	TransmitChar(SBuffer[t_data]);
         }
          TransmitCheckSum();
	       TransmitChar(TERMINATOR);
          break;
#endif
   }

}

/*-----------------------------------------------------------*/

void TransmitCheckSum(void)
{
//   F_CheckSum = CLR;
//   SendAsciiToPC(CheckSum);
   PortObj[GLOBAL_PORT].F_ChkSum = CLR;
   SendAsciiToPC(PortObj[GLOBAL_PORT].ChkSum);
}
/*-----------------------------------------------------------*/

void TransmitReplyStart(void)
{

   TransmitChar(REPLY_START_CMD);
   TransmitChar(SysInfo.MySlaveNo+CNTRBASEADD);
}
/*-----------------------------------------------------------*/


void TransmitReplyStartToX(BYTE port)
{
   TransmitCharToX(REPLY_START_CMD,port);
   TransmitCharToX(SysInfo.MySlaveNo+CNTRBASEADD,port);
}

/*-----------------------------------------------------------*/

void TransmitChar(BYTE t_data)
{
/*
   if(F_CheckSum == SET)
   {
   	CheckSum = CheckSum ^ t_data;
   }
   if(F_EthernetReceived)
   {
   	trnsbuffer[enetptr] =  t_data ;
      enetptr++;
      return;
   }
   if(!F_EthernetReceived)
   {
   	   while(1)
	      {
	         UARTSend( 0, &t_data, 1 ) ;		 //check for proper uart
	            break;
	      }
   }
*/
	TransmitCharToX(t_data,GLOBAL_PORT);
	return;
}
/*--------------------------------------------------------------------------*/

BYTE SerialAsciiToHex(volatile BYTE *ptr)
{
   BYTE temp;
   temp = AsciiToHex(*ptr) * 16;
   ptr++;
        temp = temp + AsciiToHex(*ptr);
   return temp;
}

/*--------------------------------------------------------------------------*/

BYTE SerialDecimalToHex(volatile BYTE *ptr)
{  BYTE temp;
   temp = AsciiToHex(*ptr) * 10;
   ptr++;
        temp = temp + AsciiToHex(*ptr);
   return temp;
}

/*-------------------------------------------------------------------------*/

void SendDecimalToPC(BYTE temp)
{
/* if(temp /100)
   {
      TransmitCharToPC( (temp /100) +'0') ;

   }

*/ temp = temp %100 ;
   TransmitChar( (temp /10)+'0') ;
   TransmitChar((temp%10)+'0');
   return;
}
/*-------------------------------------------------------------------------*/


void SendDecimalToPC3Char(BYTE temp)
{

      TransmitChar( (temp /100) +'0') ;
      temp = temp%100;
      TransmitChar( (temp /10)+'0') ;
      TransmitChar((temp%10)+'0');
      return;
}
/*-------------------------------------------------------------------------*/


void SendAsciiToPC(BYTE temp)
{
   TransmitChar( HexToAscii( SwapChar(temp)  & 0x0f)) ;
   TransmitChar(HexToAscii( temp & 0x0f));
   return;
}
/*-------------------------------------------------------------------------*/
short DumpAllCardData(void)
{
WORD temp1;
struct CARD_DATA empcard;
	temp1 = 0;
	while(temp1< CARD_DATA_MAX)
	{
//		xmem2root( (BYTE *) &empcard,((unsigned long)CARD_DATA_BASE+((unsigned long)temp1*(unsigned long)CARD_DATA_BYTES)),CARD_DATA_BYTES);
		if(empcard.CardNo != 0)
		{
//			SendCardDataToPC(temp1,CardData empcard);
			if(F_EthernetReceived)
			{
#ifdef ETHERNET
				SendSerialDataToEthernetPort(1);
//				WriteDataToSocket(DataSocketNo,trnsbuffer,enetptr);
#else
#ifndef TELNET_TEST
				F_CheckSum = CLR;
				PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
				fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE,PortObj[SER_TCPIP_PORT].BufPtr);
#endif
#endif
			}

			enetptr = 0;
			F_CheckSum = SET;
		}
		temp1++;
	}
	return(0);
}

/*--------------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------*/

short AddMultipleTestCards(int cardnos)
{
	int i ,ptrdata;
	for(i=1;i<cardnos;i++)
	{
	         Carddata.CardNo = i;
	         Carddata.CardPin = i;
	         Carddata.CardInfo.Door1 = 1;
	         Carddata.CardInfo.Door2 = 1;
	         Carddata.CardInfo.Holiday=0;
	         Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
	         ptrdata = AddCard(Carddata);
	         if(ptrdata == -1)
            	return(-1);
	}
   return(i);
}
/*--------------------------------------------------------------------------------------------*/

void SendDecimalLongToX(DWORD tdata,BYTE port)
{
	TransmitCharToX((BYTE)(tdata/1000000000)+'0', port);
	tdata%=1000000000;
	TransmitCharToX((BYTE)(tdata/100000000)+'0', port);
	tdata%=100000000;
	TransmitCharToX((BYTE)(tdata/10000000)+'0',port);
	tdata%=10000000;
	TransmitCharToX((BYTE)(tdata/1000000)+'0', port);
	tdata%=1000000;
	TransmitCharToX((BYTE)(tdata/100000)+'0', port);
	tdata%=100000;
	TransmitCharToX((BYTE)(tdata/10000)+'0', port);
	tdata%=10000;
	TransmitCharToX((BYTE)(tdata/1000)+'0', port);
	tdata%=1000;
	TransmitCharToX((BYTE)(tdata/100)+'0', port);
	tdata%=100;
	TransmitCharToX((BYTE)(tdata/10)+'0',port);
	tdata%=10;
	TransmitCharToX((BYTE)tdata+'0', port);
}

void SendDecimalLongToX6digit(DWORD tdata,BYTE port)
{
   TransmitCharToX((BYTE)(tdata/100000)+'0', port);
   tdata%=100000;
   TransmitCharToX((BYTE)(tdata/10000)+'0', port);
   tdata%=10000;
   TransmitCharToX((BYTE)(tdata/1000)+'0', port);
   tdata%=1000;
   TransmitCharToX((BYTE)(tdata/100)+'0', port);
   tdata%=100;
   TransmitCharToX((BYTE)(tdata/10)+'0',port);
   tdata%=10;
   TransmitCharToX((BYTE)tdata+'0', port);
}

/*-----------------------------------------------------------*/
/*
char TransmitCharToX(BYTE t_data,BYTE port)
{
  switch(port)
  {
  	   case SER_PORT_D:
		   if(F_CheckSum == SET)
		   {
	      	CheckSum = CheckSum ^ t_data;
		   }
		   if( F_EthernetReceived)
		   {
		   	trnsbuffer[enetptr] =  t_data ;
		      enetptr++;
		   }
			if(F_CheckSumD == SET)
	   			CheckSumD = CheckSumD ^ t_data;
			if( F_EthernetReceived ==CLR)
//	         	 UARTSend( SER_PORT_D, (BYTE *)t_data, 1 ) ;
				 UARTSendByte( SER_PORT_D, t_data );
			break;
       case SER_PORT_C:
		   if(F_CheckSumC == SET)
   		      CheckSumC = CheckSumC ^ t_data;
//		   UARTSend( SER_PORT_C, (BYTE *)t_data, 1 ) ;
		   UARTSendByte( SER_PORT_C, t_data );
	       break;
	   case SER_PORT_G:
		   if(F_CheckSumB == SET)
   		      CheckSumB = CheckSumB ^ t_data;
//		   UARTSend( SER_PORT_C, (BYTE *)t_data, 1 ) ;
		   UARTSendByte( SER_PORT_G, t_data );
	       break;
       case SER_PORT_E:
		   if(F_CheckSumE == SET)
   		      CheckSumE = CheckSumE ^ t_data;
//		   UARTSend( SER_PORT_E, (BYTE *)t_data, 1 ) ;
		   UARTSendByte( SER_PORT_E, t_data );
	       break;
  		case SER_TCPIP_PORT:
      	NoOfNWTxData ++;
         if(NoOfNWTxData >MAX_NW_TX_BUFF )
         {
//           SendStringToNW(NWTxBuffer,NoOfNWTxData);
				NoOfNWTxData =0;
         }
         else
//      		NWTxBuffer[NoOfNWTxData] = t_data;

      break;
      }		  
	return(0);
}
   */
/*-----------------------------------------------------------*/

void TransmitCheckSumX(BYTE port)
{
BYTE chksum;
	PortObj[port].F_ChkSum = CLR;
	chksum = PortObj[port].ChkSum;
	SendAsciiToX(chksum,port);
}

/*--------------------------------------------------------------------------------------------*/
unsigned long StrDecToLong(BYTE *str, BYTE len)
{
	char strdata[11];
   if(len>=11)
   	len = 10;
   memcpy(strdata,str,len);
   strdata[len]='\0';
//   return(1);     //check later
//	return(atol(strdata));
	return(strtoul((char *)strdata,NULL,10));
}

/*--------------------------------------------------------------------------------------------*/
void SendIntBCDToX(register WORD data1,BYTE port)
{
	BYTE tempdata;
	tempdata = data1>>8;
  	TransmitCharToX( HexToAscii( SwapChar(tempdata)  & 0x0f),port) ;
	TransmitCharToX(HexToAscii(tempdata & 0x0f),port);
	tempdata =(BYTE)data1;
	TransmitCharToX( HexToAscii(SwapChar(tempdata)  & 0x0f),port) ;
	TransmitCharToX(HexToAscii(tempdata & 0x0f),port);
}

/*---------------------------------------------------------------------*/
void MsgPrintX(BYTE msgtype, long msgdata,  BYTE *str,BYTE port)
{
	F_CheckSum = CLR;
	if(msgtype & DeabugLevel)
	{
		TransmitStrToX(str,port);
		TransmitCharToX('<',port);
		SendIntBCDToX(msgdata,port);
		TransmitCharToX('H',port);
		TransmitCharToX('>',port);
		TransmitCharToX('<',port);
		SendDecimalIntToX(msgdata,port);
		TransmitCharToX('>',port);
		TransmitCharToX('\r',port);
	}
	F_CheckSum = SET;
}

/*---------------------------------------------------------------------*/
void SendDecimalIntToX(WORD tdata,BYTE port)
{
	TransmitCharToX((tdata/10000)+'0',port);
	tdata%=10000;
	TransmitCharToX((tdata/1000)+'0',port);
	tdata%=1000;
	TransmitCharToX((tdata/100)+'0',port);
	tdata%=100;
	TransmitCharToX((tdata/10)+'0',port);
	tdata%=10;
	TransmitCharToX(tdata+'0',port);

}

/*---------------------------------------------------------------------*/
void TransmitStrToX(BYTE *str,BYTE port)
{
	while(1)
	{
		if(*str == '\0')
			break;
    //  printf("%c",*str);
      TransmitCharToX(*str,port);
		str++;
	}
}

void TransmitStrNToX(BYTE *str,int count,BYTE port)
{
	if(count!=0)		
	while(count--)
	{
		if(*str == '\0')
			break;
    //  printf("%c",*str);
      TransmitCharToX(*str,port);
		str++;
	}
}

/*--------------------------------------------------------------------------------------------*/
void SendDecimalToPC3CharToX(BYTE temp,BYTE port )
{

      TransmitCharToX( (temp /100) +'0',port) ;
      temp = temp%100;
      TransmitCharToX( (temp /10)+'0',port) ;
      TransmitCharToX((temp%10)+'0',port);
      return;
}

/*--------------------------------------------------------------------------------------------*/
void SendDecimalToX(BYTE temp,BYTE port )
{
/* if(temp /100)
   {
      TransmitCharToPC( (temp /100) +'0') ;

   }

*/ temp = temp %100 ;
   TransmitCharToX( (temp /10)+'0',port) ;
   TransmitCharToX((temp%10)+'0',port);
   return;
}

/*--------------------------------------------------------------------------------------------*/
void SendAsciiToX(BYTE temp,BYTE port)
{
   TransmitCharToX( HexToAscii( (unsigned char) ((temp&0xf0)/0x0010) & 0x0f),port) ;
   TransmitCharToX(HexToAscii(temp & 0x0f),port);
   return;
}

/*--------------------------------------------------------------------------------------------*/
void TransmitNStrToX(BYTE *str,BYTE len,BYTE port)
{
   if(len ==0)
   	return;
	while(1)
	{
		if(*str == '\0')
			break;
    //  printf("%c",*str);
      TransmitCharToX(*str,port);
		str++;
      len --;
      if(len ==0)
	      break;
	}
}

/*--------------------------------------------------------------------------------------------*/
void LongToStr(BYTE *datastr,unsigned long tdata,BYTE dcpt)
{
	*datastr =(BYTE) (tdata/1000000000)+'0';
   datastr++;
   tdata%=1000000000;
	*datastr= (BYTE)(tdata/100000000)+'0';
   datastr++;
   tdata%=100000000;
   *datastr = (tdata/10000000)+'0';
   datastr++;
   tdata%=10000000;
   *datastr= (tdata/1000000)+'0';
   datastr++;
   tdata%=1000000;
   *datastr= (tdata/100000)+'0';
   datastr++;
   tdata%=100000;
   *datastr= (tdata/10000)+'0';
   datastr++;
   tdata%=10000;
   *datastr=(tdata/1000)+'0';
   datastr++;
   tdata%=1000;
   *datastr= (tdata/100)+'0';
   datastr++;
   tdata%=100;
   if(dcpt !=0)
	{
   	*datastr= '.';
   	datastr++;
   }
   *datastr= (tdata/10)+'0';
   datastr++;
   tdata%=10;
   *datastr= tdata+'0';
   datastr++;
	*datastr = '\0';
}


void reverse(char s[])
{
int i, j;
char c;

    for(i = 0, j = strlen(s)-1; i<j; i++, j--) 
	{
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

/*------------------------------------------------------------------------------*/
/* itoa:  convert n to characters in s */
void itoa(int n, char s[])
{
int i, sign;

    if((sign = n) < 0)  /* record sign */
        n = -n;          /* make n positive */
    i = 0;				 /* generate digits in reverse order */
    do
	{       
        s[i++] = n % 10 + '0';   /* get next digit */
    } while((n /= 10) > 0);     /* delete it */
    if(sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    reverse(s);
} 

/*------------------------------------------------------------------------------*/
// Following function converts ip address string to long. Return as zero means error.
unsigned long aton(char str[])
{   
char *p;
int i;
unsigned char x;
long cur;
unsigned long ip;
	ip = 0;
	for(i=24;i>=0;i-=8) 
	{
		x = *str;
//   		if (isdigit(x)== 0) 	  some funny bug in code so replaced with following 
		if((x < '0') || (x > '9'))
		{
      		return 0;
  		}
   		cur = strtol(str,&p,10);
		str = p;
      	if((cur < 0) || (cur >= 256)) 
		{
      		return 0;
      	}
      	ip |= (cur << i);
      	if(!i) 
			break;
      	if (*str != '.' && *str != ',') 
		{
         	return 0;
      	}
      	++str;
	}
	return(ip);
}
// Following function converts ip address string to array of bytes. 
void StrToArr( char *str, BYTE arr[])//array must be long enough(4bytes of ip)
{   
char *p;
int i;
unsigned char x;
long cur;
unsigned long ip;
	ip = 0;
	for(i=24;i>=0;i-=8) 
	{
		x = *str;
//   		if (isdigit(x)== 0) 	  some funny bug in code so replaced with following 
		if((x < '0') || (x > '9'))
		{
      		return ;
  		}
   		cur = strtol(str,&p,10);
		str = p;
      	if((cur < 0) || (cur >= 256)) 
		{
      		return ;
      	}
      	ip |= (cur << i);
		//arr[(24-i)%8]=cur; //strore each byte in array ,starting from 0 to 3
      	if(!i) 
			break;
      	if (*str != '.' && *str != ',') 
		{
         	return ;
      	}
      	++(str);
	}
	arr[3] = ip&0x000000ff;
	arr[2] = (ip&0x0000ff00)>>8;
	arr[1] = (ip&0x00ff0000)>>16;
	arr[0] = (ip&0xff000000)>>24;
}
long ArrToLong(BYTE arr[])//array must be long enough(4bytes of ip)
{
	long num;
	num = arr[0];
	num <<= 8;
	num |= arr[1];
	num <<= 8;
	num |= arr[2];
	num <<= 8;
	num |= arr[3];

	return num;		
}
int check_string(const char *temp1Str,const char *temp2Str,int length)
{
// 	const char *temp1Str=MEM_ADD_BOOT_STRING;
//	const char *temp2Str=StrCheck;
//	const char *temp2Str="SMARTUPG";
//	int i=BOOT_STRING_LENGTH;

	while( (*temp2Str!='\0') && length--)
	{
		if(*temp1Str != *temp2Str)
			return 0;   //not equal
		temp1Str++;
		temp2Str++;
	}
	return 1;		//string is equal
}

void WORDHextoDeciamal(char* destination,unsigned short source)
{
	char i;
	for(i=4;i>=0;i--)
	{
		destination[i] = source%10 + 0x30;
		source = source/10;
	}	
	destination[5] = '\0';
}
void LongHextoDeciamal(char* destination,unsigned long source)
{
	char i;
	for(i=9;i>=0;i--)
	{
		destination[i] = source%10 + 0x30;
		source = source/10;
	}	
	destination[10] = '\0';
}
