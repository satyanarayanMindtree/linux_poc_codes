
#include "LPC23xx.h"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "type.h"
#include "irq.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "ProcessWeiCard.h"
#include "rdcont.h"
#include "portlcd.h"
#include "userintf.h"
#include "access.h"
#include "serial.h"
#include "inout.h"
#include "userIntfGLCD.h"

extern struct DOOR_INFO Doorinfo;
extern BYTE F_KeyIdleTime,IdleKeyCounter;
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;
#ifdef ENABLE_PIN_PROX
extern unsigned int ReceivedPin;
extern SYSInfo SysInfo;
#endif
extern unsigned char DisplayTempBuffer[50];
//extern unsigned char SplLedBlink[MAX_READERS];
/*** BeginHeader WeiProcessInit*/
void WeiProcessInit(void);
/*** EndHeader */
void WeiProcessInit(void)
{
unsigned char i;
	for(i=0;i<MAX_READERS_SUPPORT;i++)		   
	{
		ReaderData[i].F_WeigandInterrupt = 0;
		ReaderData[i].F_CardFound = 0;
		ReaderData[i].F_WeigandStarted = 0;
		ReaderData[i].WeigandData = 0;
		ReaderData[i].WCount = 0;
		ReaderData[i].WeigandTimeOut = 0;
      	ReaderData[i].WeigandExData = 0;
//		SplLedBlink[i] = 0;		// initially all Spcl led blink off 		
	}
	ParityErrCount = 0;
}

// Following function is used to take care of Weignd raw data processing
/*** BeginHeader HandleWeigandRawCard*/
CARDNO_DATA_STORAGE_TYPE HandleWeigandRawCard(unsigned char rdrno);
/*** EndHeader */
CARDNO_DATA_STORAGE_TYPE HandleWeigandRawCard(unsigned char rdrno)
{
unsigned char RecParity,CalParity;   		//DB037
#ifdef MAGNETIC_READER_SUPPORT
	unsigned char magdata[10];
#endif
	RecParity = 0;
	CalParity = 0;
	TransparentCardData.WCount = ReaderData[rdrno].WCount;    //ARMF0554
	TransparentCardData.WeigandData = ReaderData[rdrno].WeigandData;
	TransparentCardData.WeigandExData = ReaderData[rdrno].WeigandExData;
	MsgPrint(MSG_WARNING,(WORD)ReaderData[rdrno].WCount,"Weigand Count=");
	MsgPrint(MSG_WARNING,(WORD)ReaderData[rdrno].WeigandData&0xFFFF,"Raw WData LSB=");
	MsgPrint(MSG_WARNING,(WORD)(ReaderData[rdrno].WeigandData/0x10000),"Raw WData MSB=");
	MsgPrint(MSG_WARNING,(BYTE)ReaderData[rdrno].WeigandExData,"Raw Extra Data=");
//	MsgPrint(MSG_WARNING,(WORD)(ReaderData[rdrno].WeigandExData/0x10000),"Raw Extra MSB=");

//	if(DeabugLevel)
//		printf("Card No ""%d",(unsigned int)ReaderData[rdrno].WeigandData);
	WCount = (WORD)ReaderData[rdrno].WCount;
	ReaderData[rdrno].F_ParityError = 0;
	switch(ReaderData[rdrno].WCount)
	{
	case 26:
		if(Doorinfo.EnDisWeiParity != 0)           //DB037
		{
			//Get Received Odd parity
			RecParity = (BYTE)(ReaderData[rdrno].WeigandData & 0x01);
			//Get Received Even parity
			RecParity = (((ReaderData[rdrno].WeigandData / 0x02000000) == 0x01) ? (RecParity | 0x02) : (RecParity & 0x01));
			MsgPrint(MSG_WARNING,RecParity,"Received Parity Bits=");
		}
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData >> 1;
		ReaderData[rdrno].FacCode = (BYTE)(ReaderData[rdrno].WeigandData >> 16);
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData & 0x00FFFFFF;
#ifdef CHK_WEIGAND_PARITY                                 //DB037
		if(Doorinfo.EnDisWeiParity != 0)
		{
			//Calculate Odd parity for received card no
			CalParity = ((((CheckNoOfOneInInt((WORD)(ReaderData[rdrno].WeigandData % 0x1000))) % 2) == 0) ? 1 : 0);
			//Calculate Even parity for received card no
			CalParity = (((CheckNoOfOneInInt((WORD)((ReaderData[rdrno].WeigandData / 0x1000) % 0x1000)) % 2) == 0) ? (CalParity & 0x01) : (CalParity | 0x02));
			MsgPrint(MSG_WARNING,CalParity,"Calculated Parity Bits=");
			if(RecParity == CalParity)
			{
				MsgPrint(MSG_WARNING,RecParity,"Parity Matched");
				ReaderData[rdrno].F_ParityError = 0;
			}
			else
			{
				ReaderData[rdrno].FacCode = 1;
				ReaderData[rdrno].WeigandData = 0;
				ParityErrCount ++;
				MsgPrint(MSG_WARNING,RecParity,"Parity Error");
				MsgPrint(MSG_WARNING,ParityErrCount,"Parity Error Count=");       //parity error count we have check globally
				ReaderData[rdrno].F_ParityError = 1;
			}
		}
#endif
		break;
	case 34:
		if(Doorinfo.EnDisWeiParity != 0)                       //DB037
		{
			//Get Received Odd parity
			RecParity = (BYTE)(ReaderData[rdrno].WeigandExData & 0x01);
			//Get Received Even parity
			RecParity = (((ReaderData[rdrno].WeigandData / 0x80000000) == 0x01) ? (RecParity | 0x02) : (RecParity & 0x01));
			MsgPrint(MSG_WARNING,RecParity,"Received Parity Bits=");
		}
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData * 2;
		if(ReaderData[rdrno].WeigandExData & 0x02)
			ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData | 0x01;
		else
			ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData & 0xFFFFFFFE;
		ReaderData[rdrno].FacCode = (BYTE)(ReaderData[rdrno].WeigandData >> 24);
#ifdef CHK_WEIGAND_PARITY                                  //DB037
		if(Doorinfo.EnDisWeiParity != 0)
		{
			//Calculate Odd parity for received card no
			CalParity = ((((CheckNoOfOneInInt((WORD)(ReaderData[rdrno].WeigandData % 0x10000))) % 2) == 0) ? 1 : 0);
			//Calculate Even parity for received card no
			CalParity = (((CheckNoOfOneInInt((WORD)((ReaderData[rdrno].WeigandData / 0x10000) % 0x10000)) % 2) == 0) ? (CalParity & 0x01) : (CalParity | 0x02));
			MsgPrint(MSG_WARNING,CalParity,"Calculated Parity Bits=");
			if(RecParity == CalParity)
			{
				MsgPrint(MSG_WARNING,RecParity,"Parity Matched");
				ReaderData[rdrno].F_ParityError = 0;
			}
			else
			{
				ReaderData[rdrno].FacCode = 1;
				ReaderData[rdrno].WeigandData = 0;
				ReaderData[rdrno].WeigandExData = 0;
				ParityErrCount ++;
				MsgPrint(MSG_WARNING,RecParity,"Parity Error");
				MsgPrint(MSG_WARNING,ParityErrCount,"Parity Error Count=");
				ReaderData[rdrno].F_ParityError = 1;
			}
		}
#endif
		break;
	
	case 32:
		ReaderData[rdrno].FacCode = (BYTE) (ReaderData[rdrno].WeigandData >> 24);
		break;
	
	case 35:
		if(Doorinfo.EnDisWeiParity != 0)
		{
			//Get Received Even parity
			RecParity = (((ReaderData[rdrno].WeigandData & 0x40000000) != 0) ? (1) : (0));
			//Get Received Odd1 parity
			RecParity = RecParity | (BYTE)(ReaderData[rdrno].WeigandExData & 0x01)<<1;
			//Get Received Odd2 parity
			RecParity = (((ReaderData[rdrno].WeigandData & 0x80000000) != 0) ? (RecParity | 0x04) : (RecParity & 0x03));
			MsgPrint(MSG_WARNING,RecParity,"Received Parity Bits=");
		}
		ReaderData[rdrno].WeigandData = (ReaderData[rdrno].WeigandData *4) & 0xFFFFFFFC;			//1111 1100
		ReaderData[rdrno].WeigandExData = (ReaderData[rdrno].WeigandExData>>1) & 0x00000003;  	//0000 0011
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData | ReaderData[rdrno].WeigandExData;
		ReaderData[rdrno].FacCode = (BYTE)(ReaderData[rdrno].WeigandData >> 24);
#ifdef CHK_WEIGAND_PARITY
		if(Doorinfo.EnDisWeiParity != 0)
		{
			//Calculate Even parity for received card no
			CalParity = (((Check35BitEvenParity(ReaderData[rdrno].WeigandData) % 2) == 0) ? 0 : 1);       //Even parity
			//Calculate Odd parity1 for received card no
			CalParity = (((Check35BitOddParity1(ReaderData[rdrno].WeigandData,CalParity) % 2) != 0) ? (CalParity & 0x01) : (CalParity | 0x02));   //Odd parity 1
			//Calculate Odd parity2 for received card no
			CalParity = (((Check35BitOddParity2(ReaderData[rdrno].WeigandData,CalParity) % 2) != 0) ? (CalParity & 0x03) : (CalParity | 0x04));    //Odd parity 2
			MsgPrint(MSG_WARNING,CalParity,"Calculated Parity Bits=");
			if(RecParity == CalParity)
			{
				MsgPrint(MSG_WARNING,RecParity,"Parity Matched");
				ReaderData[rdrno].F_ParityError = 0;
			}
			else
			{
				ReaderData[rdrno].FacCode = 1;
				ReaderData[rdrno].WeigandData = 0;
				ReaderData[rdrno].WeigandExData = 0;
				ParityErrCount ++;
				MsgPrint(MSG_WARNING,RecParity,"Parity Error");
				MsgPrint(MSG_WARNING,ParityErrCount,"Parity Error Count=");
				ReaderData[rdrno].F_ParityError = 1;
			}
		}
#endif
		break;

	case 25:
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData >> 1;
		ReaderData[rdrno].FacCode = (BYTE) (ReaderData[rdrno].WeigandData >> 16);
		break;

#ifdef ENABLE_PIN_PROX
	case 4:
	case 8:
		if((SysInfo.ChkPin != 0) && (ReaderInfo[rdrno].PinEnDis != 0))
			ReaderData[rdrno].WeigandData = (ReaderData[rdrno].WeigandData) & 0x0F;
		else
		{
			ReaderData[rdrno].WeigandData = 0;
			ReaderData[rdrno].FacCode = 0;
		}
		break;
#endif
	default:
		ReaderData[rdrno].WeigandData = 0;
		break;
	}

 	MsgPrint(MSG_WARNING,(WORD)ReaderData[rdrno].WeigandData&0xFFFF,"Card LSB=");
 	MsgPrint(MSG_WARNING,(WORD)(ReaderData[rdrno].WeigandData/0x10000),"Card MSB=");
#ifdef CHK_WEIGAND_PARITY 
	if((Doorinfo.EnDisWeiParity != 0)&&(ReaderData[rdrno].F_ParityError))
	{
		ParityErrCount ++;
		return(0);
	}
	else
#endif
	{					  
#ifdef	CARD_NO_8_DIGIT
	#ifndef	CARD_NO_10_DIGIT
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData & 0x00FFFFFF;
	#endif
#else
		ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData & 0x0000FFFF;
#endif
		if(Doorinfo.CardMask == 16)
		{
			ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData & 0x0000FFFF;
		}
		if(Doorinfo.CardMask == 24)
		{
			ReaderData[rdrno].WeigandData = ReaderData[rdrno].WeigandData & 0x00FFFFFF;
		}
		return((CARDNO_DATA_STORAGE_TYPE)ReaderData[rdrno].WeigandData);
	}
}

/****** interrupt routines  ******/
/*-------------------------------------------------------------------------------
Following is weigand interrupt handling..
-------------------------------------------------------------------------------*/
/*****************************************************************************
** Function name:		EINT0_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT0_Handler (void) __irq 
{
unsigned int temp1;
unsigned char tmpwdata;
// weigand innterrupt

	EXTINT = EINT0;		/* clear interrupt */
	if(B_WINT1 == CLR)
	{
		temp1 = 4;
		while(temp1 == 0)                      //DB036
			temp1--;
		tmpwdata = B_W1D1; 
		if(ReaderData[1].F_WeigandStarted == CLR)
		{
			WEIGAND_INTERRUPT_HNDLx(0,tmpwdata);
			temp1 = 78;
			while(1)
			{
				temp1--;
				if(temp1 == 0)
					break;
			}
		}
	}
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		EINT1_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT1_Handler (void) __irq 
{
unsigned char temp1;
// weigand innterrupt
unsigned char tmpwdata2;

	EXTINT = EINT1;		/* clear interrupt */
	if(B_WINT2 == CLR)
	{
		temp1 = 4;
		while(temp1 == 0)              //DB036
			temp1--;
		tmpwdata2 = B_W2D1; 
		if(ReaderData[0].F_WeigandStarted == CLR)
		{
			WEIGAND_INTERRUPT_HNDLx(1,tmpwdata2);
			temp1 = 78;
			while(1)
			{
				temp1--;
				if(temp1 == 0)
					break;
			}
		}
	}
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		EINT2_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT2_Handler (void) __irq 
{
	EXTINT = EINT2;		/* clear interrupt */
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		EINT3_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT3_Handler (void) __irq 
{ 
	EXTINT |= EINT3;	   	/* clear interrupt */
    VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		EINTInit
**
** Descriptions:		Initialize external interrupt pin and
**				install interrupt handler
**
** parameters:			None
** Returned value:		true or false, return false if the interrupt
**				handler can't be installed to the VIC table.
** 
*****************************************************************************/
DWORD EINTInit(void)
{
//PORT 2 PINS USED 15 TO 0:	 0000 0101 0101 0000 0000 0000 0000 1010
	PINSEL4 |= 0x05500000;	/* 55 set P2.10,11,12,13 as EINT0,1,2,3 and 2.8
								P2.2~7 GPIO output */
   
	EXTMODE |= EINT0_EDGE;	/* INT0 edge trigger */
	
	EXTMODE |= EINT1_EDGE;	/* INT1 edge trigger */
   
 //  EXTMODE |= EINT2_EDGE;	/* INT2 edge trigger */
   
 //  EXTMODE |= EINT3_EDGE;	/* INT3 edge trigger */
   
  // IO2_INT_CLR |= 0x100;    /*clear if any interrupt is pending... */
  // IO2_INT_EN_R |= 0x100;	/* Port2.8 is Rising edge. keypad*/
      
	EXTPOLAR = 0;			/* INT3 is falling edge by default */
   
   //IO2_INT_CLR|= 0x0C00;	/* Port2.10, 11, 12, 13 is falling edge. for wiegand CLR */
   //IO2_INT_EN_F |= 0x3C00;	/* Port2.10, 11, 12, 13 is falling edge. for wiegand  */

	if(install_irq(EINT0_INT,(void *)EINT0_Handler,HIGHEST_PRIORITY) == FALSE)
	{
		return (FALSE);
	}
  //INT_EN 1 //enable the pin 2.11 as edge sensing input
	if(install_irq(EINT1_INT,(void *)EINT1_Handler,HIGHEST_PRIORITY) == FALSE)
	{
		return (FALSE);
	}
  //INT_EN 2 //enable the pin 2.12 as edge sensing input
 // if ( install_irq(EINT2_INT,(void *)EINT2_Handler,HIGHEST_PRIORITY )==FALSE)
 // {
//	return (FALSE);
//  }
////INT_EN 3 //enable the pin 2.8 as edge sensing input
//	  if ( install_irq(EINT3_INT,(void *)EINT3_Handler,HIGHEST_PRIORITY )==FALSE)
  {
//		return (FALSE);
  }
  return(TRUE);
}

#ifdef CHK_WEIGAND_PARITY                             //shree 20oct
/*-----------------------------------------------------------------------------------*/
unsigned char CheckNoOfOneInInt(unsigned int padata)
{
unsigned char i,Pdata;
	Pdata = 0;
	for(i=0;i<16;i++)
	{
		if(padata & 0x8000)
		{
			Pdata ++;
		}
		padata = padata << 1;
	}
	return(Pdata);
}

/*-----------------------------------------------------------------------------------*/
char Check35BitEvenParity(unsigned long padata)
{
unsigned char ibit,tdata;
	tdata = 0;
	for(ibit=0;ibit<32;ibit++)
	{
		if((ibit == 0) || (ibit == 1) || (ibit == 3) || (ibit == 4) || (ibit == 6) ||			\
			(ibit == 7) || (ibit == 9) || (ibit == 10) || (ibit == 12) || (ibit == 13) ||		\
			(ibit == 15) || (ibit == 16) || (ibit == 18) || (ibit == 19) || (ibit == 21) ||	\
			(ibit == 22) || (ibit == 24) || (ibit == 25) || (ibit == 27) || (ibit == 28) ||	\
			(ibit == 30) || (ibit == 31))
		{
			if(padata & 0x1)
			{
				tdata ++;
			}
		}
		padata = padata >> 1;
	}
	return(tdata);
}

/*-----------------------------------------------------------------------------------*/
char Check35BitOddParity1(unsigned long padata, unsigned char padata1)
{
unsigned char ibit,tdata;
	tdata = 0;
	for(ibit=0;ibit<32;ibit++)
	{
		if((ibit % 3) != 0)
		{
			if(padata & 0x1)
			{
				tdata ++;
			}
		}
		padata = padata >> 1;
	}
	if(padata1 & 0x1)		//Add even parity but
		tdata++;
	return(tdata);
}

/*-----------------------------------------------------------------------------------*/
char Check35BitOddParity2(unsigned long padata, unsigned char padata1)
{
unsigned char ibit,tdata;
	tdata = 0;
	for(ibit=0;ibit<32;ibit++)
	{
		if(padata & 0x1)
		{
			tdata ++;
		}
		padata = padata >> 1;
	}
	if(padata1 & 0x1)		//Add even parity bit
		tdata ++;
	if(padata1 & 0x2)		//Add odd parity1 bit
		tdata ++;
	return(tdata);
}
#endif

void PinProxOneSecTimer(void)
{
char i;
	for(i=0;i<MAX_LOCAL_READER;i++)
	{
		if(ReaderData[i].PinTimeOut < MAX_PIN_READ_TIME_OUT)
			ReaderData[i].PinTimeOut++;
	}
}
void CheckPinProxTimeout(void)
{
unsigned char i;
unsigned char tempbuffer[20];	
	for(i=0;i<MAX_LOCAL_READER;i++)
	{
		if((ReaderData[i].PinTimeOut >= MAX_PIN_READ_TIME_OUT) && (ReaderInfo[i].PinEnDis != 0))
		{
			if((ReaderData[i].PinCount != 0) || (ReaderData[i].F_PinRec == SET))
			{
//				L_DisplayROMStr("PinProx TimOutR ",16,ROW_USER_ENTRY3);
//				L_DisplayCharAtRow(15,i+'1',ROW_USER_ENTRY);
				
				sprintf((char*)DisplayTempBuffer,"PinProx TimOutR %02d",(i+1));
				DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);
				F_KeyIdleTime = CLR;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 3;
			}
			ReaderData[i].CardNo = 0;
			ReaderData[i].FacCode = 0;
			ReaderData[i].F_PinRec = CLR;
			ReaderData[i].PinCount = 0;
			ReaderData[i].CPin = 0;
			ReaderData[i].Pin = 0;
			ReaderData[i].PinTimeOut = 0;
//			MsgPrint(MSG_WARNING,i,"WeigandPinProxTimeOut Reader=");
		}
	}
}

void ProcessRecCarddata(unsigned char rdrno, unsigned long tmpcard)
{
#ifdef ENABLE_PIN_PROX
	if((ReaderInfo[rdrno].PinEnDis != 0) && (SysInfo.ChkPin != 0))
	{
		if((ReaderData[rdrno].WCount == 8) || (ReaderData[rdrno].WCount == 4))
		{
			MsgPrint(MSG_WARNING,ReaderData[rdrno].WCount,"HendleWeigandData:WCount=");
			ReaderData[rdrno].CPin = (unsigned char)tmpcard & 0x00FF;
			if(ReaderData[rdrno].CPin <= 9)
			{
				ReaderData[rdrno].Pin = (ReaderData[rdrno].Pin * 10) + (ReaderData[rdrno].CPin);
				if(ReaderData[rdrno].PinTimeOut > 3)
					ReaderData[rdrno].PinTimeOut = ReaderData[rdrno].PinTimeOut - 3;
				ReaderData[rdrno].PinCount++;
				MsgPrint(MSG_WARNING,ReaderData[rdrno].Pin,"HendleWeigandData:Pin=");
				MsgPrint(MSG_WARNING,ReaderData[rdrno].PinCount,"HendleWeigandData:PinCount=");
			}
			if(ReaderData[rdrno].CPin == 11)
			{
				ReaderData[rdrno].PinCount = 5;
			}
			if(ReaderData[rdrno].PinCount >= 5)
			{
				if(ReaderData[rdrno].F_PinRec == SET)
				{
					// We have received Full pin as before this we have received card.....
					CurrentUser.InputType = INPUT_USER_FROM_PIN_CARD_WEIGAND;
					ReceivedPin = ReaderData[rdrno].Pin;
					ReceivedCardNo = ReaderData[rdrno].CardNo;
					MsgPrint(MSG_WARNING,ReaderData[rdrno].Pin,"HendleWeigandData:PIN CARD WEI Pin=");
					//printf("INPUT_USER_FROM_PIN_CARD_WEIGAND card %d %d \n",ReceivedCardNo,ReaderData[rdrno].Pin);
				}
				else
				{
					MsgPrint(MSG_WARNING,ReaderData[rdrno].Pin,"HendleWeigandData:CARD from Key=");
					ReceivedCardNo = ReaderData[rdrno].Pin;
					CurrentUser.InputType = INPUT_USER_FROM_PIN_PROX;
					//printf("INPUT_USER_FROM_PIN_PROX card %d %d \n",ReceivedCardNo,ReaderData[rdrno].Pin);
				}
//	         	ReaderData[rdrno].F_CardFound = SET;
				ReaderData[rdrno].F_PinRec = CLR;
				ReaderData[rdrno].PinCount = 0;
				ReaderData[rdrno].CPin = 0;
				ReaderData[rdrno].Pin = 0;
				ReaderData[rdrno].PinTimeOut = 0;
				if(ReceivedCardNo != 0)
				{
					CurrentUser.RdrNo = rdrno+1;
					CurrentUser.SearchCard.CardNo = ReceivedCardNo;
					CurrentUser.FCode = ReaderData[rdrno].FacCode;
					ProcessCard(rdrno+1);
				}
			}
		}
		else
		{
			if((SysInfo.PinProxFCode == ReaderData[rdrno].FacCode) && (ReaderData[rdrno].WCount == 26))
			{
				//Indicates Pin Received
				if(ReaderData[rdrno].F_PinRec == SET)
				{
					MsgPrint(MSG_WARNING,ReaderData[rdrno].Pin,"HendleWeigandData:PIN CARD WEI Pin=");
					CurrentUser.InputType = INPUT_USER_FROM_PIN_CARD_WEIGAND;
					ReceivedCardNo = ReaderData[rdrno].CardNo;
					ReceivedPin = ReaderData[rdrno].Pin = (unsigned int)tmpcard & 0x0000FFFF;
//					printf("INPUT_USER_FROM_PIN_CARD_WEIGAND card %d %d \n",ReceivedCardNo,ReaderData[rdrno].Pin);
				}
				else
				{
					if(tmpcard != 0)
					{
						MsgPrint(MSG_WARNING,ReaderData[rdrno].Pin,"HendleWeigandData:CARD from Key=");
						ReceivedCardNo = ReaderData[rdrno].Pin = (unsigned int)tmpcard;
						CurrentUser.InputType = INPUT_USER_FROM_PIN_PROX;
//						printf("INPUT_USER_FROM_PIN_PROX card %d %d \n",ReceivedCardNo,ReaderData[rdrno].Pin);
					}
					else
						return;
				}
//	         	ReaderData[rdrno].F_CardFound = SET;
				ReaderData[rdrno].F_PinRec = CLR;
				ReaderData[rdrno].PinCount = 0;
				ReaderData[rdrno].CPin = 0;
				ReaderData[rdrno].Pin = 0;
				ReaderData[rdrno].PinTimeOut = 0;
				if(ReceivedCardNo != 0)
				{
					CurrentUser.RdrNo = rdrno+1;
					CurrentUser.SearchCard.CardNo = ReceivedCardNo;
					CurrentUser.FCode = ReaderData[rdrno].FacCode;
					ProcessCard(rdrno+1);
				}
				else
				{
					if(ReaderData[rdrno].F_ParityError == 1)
					{
						if(DisplayMode == MODE_WAIT_FOR_CARD)
						{
							L_DisplayROMStr("CardParity Err  ",16,ROW_CARD_ERROR_DISP);
							L_DisplayCharAtRow(15,rdrno+'1',ROW_USER_ENTRY);
							F_KeyIdleTime = CLR;
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;
							DisplayMode = MODE_WAIT_FOR_CARD;
							DisplaySubMode = 0;
						}
					}
				}
			}
			else
			{
				if(tmpcard != 0)
				{
					if(DisplayMode == MODE_ADMIN_PASSWORD)		//DA00135
					{
						ReceivedCardNo = ReaderData[rdrno].CardNo = tmpcard;
						CurrentUser.RdrNo = rdrno+1;
						CurrentUser.SearchCard.CardNo = ReaderData[rdrno].CardNo;
						CurrentUser.FCode = ReaderData[rdrno].FacCode;
						ProcessCard(rdrno+1);
					}
					else
					{
#ifndef BIO_METRIC	// for Standalone we need to take care as MSg display on Date time welocme screen 
						L_DisplayROMStr("EnterPin R      ",16,ROW_USER_ENTRY);						
						L_DisplayCharAtRow(10,rdrno+'1',ROW_USER_ENTRY);
#endif						
						F_KeyIdleTime = CLR;
						IdleKeyCounter = MAX_KEY_IDLE_TIME - 3;
						ReaderData[rdrno].CardNo = tmpcard;
						ReaderData[rdrno].F_PinRec = SET;
						ReaderData[rdrno].PinCount = 0;
						ReaderData[rdrno].CPin = 0;
						ReaderData[rdrno].Pin = 0;
						ReaderData[rdrno].PinTimeOut = 0;
					}
				}
			}
		}
	}
	else
	{
		ReceivedCardNo = tmpcard;
		if(ReceivedCardNo != 0)
		{
			CurrentUser.RdrNo = rdrno+1;
			CurrentUser.SearchCard.CardNo = ReceivedCardNo;
//			CurrentUser.InputType = INPUT_USER_FROM_WEIGAND;
			CurrentUser.FCode = ReaderData[rdrno].FacCode;
			ProcessCard(rdrno+1);
		}
		else
		{
			if(ReaderData[rdrno].F_ParityError == 1)
			{
				if(DisplayMode == MODE_WAIT_FOR_CARD)
				{
					L_DisplayROMStr("CardParity Err  ",16,ROW_CARD_ERROR_DISP);
					L_DisplayCharAtRow(15,rdrno+'1',ROW_USER_ENTRY);
					F_KeyIdleTime = CLR;
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;
					DisplayMode = MODE_WAIT_FOR_CARD;
					DisplaySubMode = 0;
				}
			}
		}
	}
#else
	ReceivedCardNo = tmpcard;
	if(ReceivedCardNo != 0)
	{
		CurrentUser.RdrNo = rdrno+1;
		CurrentUser.SearchCard.CardNo = ReceivedCardNo;
//		CurrentUser.InputType = INPUT_USER_FROM_WEIGAND;
		CurrentUser.FCode = ReaderData[rdrno].FacCode;
		ProcessCard(rdrno+1);
	}
	else
	{
		if(ReaderData[rdrno].F_ParityError == 1)
		{
			if(DisplayMode == MODE_WAIT_FOR_CARD)
			{
				L_DisplayROMStr("CardParity Err  ",16,ROW_CARD_ERROR_DISP);
				L_DisplayCharAtRow(15,rdrno+'1',ROW_USER_ENTRY);
				F_KeyIdleTime = CLR;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 2;
				DisplayMode = MODE_WAIT_FOR_CARD;
				DisplaySubMode = 0;
			}
		}
	}
#endif
}
