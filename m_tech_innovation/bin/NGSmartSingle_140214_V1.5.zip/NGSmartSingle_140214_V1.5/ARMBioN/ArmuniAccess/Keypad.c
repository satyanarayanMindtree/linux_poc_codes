/*****************************************************************************
 *   Keypad.c
 *
 *   History
 *   2008.11.23  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include <stdio.h>
#include "LPC23xx.h"		/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include <string.h>
#include "type.h"
#include "Keypad.h"
#include "uart.h"
#include "SmartBio.h"
#include "spi.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "Cardmgmt.h"
#include "Serial.h"
#include "userIntfGLCD.h"
#include "userIntf.h"
//#include "portlcd.h"
#ifdef SUPPORT_TOUCHKEYPAD
#ifdef NEW_TOUCH_KEYPAD	
	#include "../../Touch Keypad/i2cNew.h"
	#include "../../Touch Keypad/TouchKey.h"
#else	
	#include "../../Touch Keypad/i2c.h"
	BYTE I2CRxFlag;
#endif

#endif
//DWORD KeyIn;
//extern BYTE F_KeyPressed;

/*
void Init_Keypad(void)
{ 
  	IO1DIR |= KEY_DATA | KPD_BKLT;  
	IO1DIR |= ~KEY_SEL;
}
*/


/*****************************************************************************
**   Main Function  main()
******************************************************************************/
/*int ReadKey()
{
DWORD i;	
 	// Key_Counter=0;
	if(F_KeyPressed)
	{	 
   		F_KeyPressed=0;
		KeyIn=0;
		FIO1CLR  |= KEYOPENB;	   
		KEY_DATA_DIR_IN
		for(i=0;i<=100;i++);
			KeyIn = (FIO1PIN >> 19) & 0x0000000F;
		FIO1SET  |= KEYOPENB;
		switch (KeyIn)
		{ 	
		    case 0:
				UARTSend( 0, "Keydata 0\r\n", sizeof("Keydata 0\r\n") );
				break;
		    case 1:
				UARTSend( 0, "Keydata 1\r\n", sizeof("Keydata 1\r\n") );
				break;
		    case 2:
	  			UARTSend( 0, "Keydata 2\r\n", sizeof("Keydata 2\r\n") );
				break;
		    case 3:
				 UARTSend( 0, "Keydata 3\r\n", sizeof("Keydata 3\r\n") );
				break;
			case 4:
				UARTSend( 0, "Keydata 4\r\n", sizeof("Keydata 4\r\n") );
				break;
			case 5:
				UARTSend( 0, "Keydata 5\r\n", sizeof("Keydata 5\r\n") );
				break;
			case 6:
				UARTSend( 0, "Keydata 6\r\n", sizeof("Keydata 6\r\n") );
				break;
			case 7:
				UARTSend( 0, "Keydata 7\r\n", sizeof("Keydata 7\r\n") );
				break;
			case 8:
				UARTSend( 0, "Keydata 8\r\n", sizeof("Keydata 8\r\n") );
				break;
			case 9:
				UARTSend( 0, "Keydata 9\r\n", sizeof("Keydata 9\r\n") );
				break;
			case 10:
				UARTSend( 0, "Keydata 10\r\n", sizeof("Keydata 10\r\n") );
				break;
			case 11:
				UARTSend( 0, "Keydata 11\r\n", sizeof("Keydata 11\r\n") );
				break;
			case 12:
				UARTSend( 0, "Keydata 12\r\n", sizeof("Keydata 12\r\n") );
				break;
			case 13:
				UARTSend( 0, "Keydata 13\r\n", sizeof("Keydata 13\r\n") );
				break;
			case 14:
				UARTSend( 0, "Keydata 14\r\n", sizeof("Keydata 14\r\n") );
				break;
			case 15:
				UARTSend( 0, "Keydata 15\r\n", sizeof("Keydata 15\r\n") );
				break;
			case 16:
				UARTSend( 0, "Keydata 16\r\n", sizeof("Keydata 16\r\n") );
				break;
			
			default:
				UARTSend( 0, "Keydata 17\r\n", sizeof("Keydata 0\r\n") );
				break;
		}	 
  	} 
	return KeyIn;
}
*/
/******************************************************************************
**                            End Of File
******************************************************************************/

BYTE ReadKeyFromBuffer(void)
{
BYTE key;

	if(KeyWritePtr != KeyReadPtr)   
	{
		key = KeyMapping(KeyBuff[KeyReadPtr]);
		KeyReadPtr++;
		if(KeyReadPtr >= MAX_KEY_BUFFER)
			KeyReadPtr =0;
		return(key);
	}
	return(0xff);
}

void HandleKeyBoard(void)
{
#ifdef SUPPORT_TOUCHKEYPAD	
#ifndef NEW_TOUCH_KEYPAD		
//	I2CKeyData = check_cap_keypad();
	if(I2CRxFlag)   // For Touch keypad 
		{
				KeyBuff[KeyWritePtr++] = I2CKeyData;
				I2CRxFlag = 0;
		}
		if(KeyWritePtr >= 4)
			KeyWritePtr = 0;
		return;
#else		
	if(KeyChange == 1)
    {
 		KeyRecPat = KeyScan();
		if(KeyPrePat == KeyRecPat)
		{
			KeyChange = 0;
			KeyPrePat = KeyRecPat;
			if(KeyPrePat == 0xFF)
			{
//				KeyBuff[KeyWritePtr++] = DepresKey | 0x80;			 
			}
			else
			{  
				KeyBuff[KeyWritePtr++] = KeyRecPat;				
			}
			if(KeyWritePtr >= 4)
				KeyWritePtr = 0;
			return;
		}
		else
		{
			KeyPrePat = KeyRecPat;
			KeyChange = 1;
		}
	}
	else
	{
		KeyRecPat = KeyScan();
		if(KeyPrePat != KeyRecPat)
		{
			KeyChange = 1;
			KeyPrePat = KeyRecPat;

		}
    }
#endif
#endif	

 }

BYTE KeyMapping(BYTE key)
{
BYTE oldkey;
	oldkey = key;
#ifdef SUPPORT_TOUCHKEYPAD
	switch(key & 0x7F)
	{
	case 1:
		key = 1;
		break;
	case 2:
		key = 2;
		break;
	case 3:
		key = 3;
		break;
	case 4:
		key = 4;
		break;
	case 5:
		key = 5;
		break;
	case 6:
		key = 6;
		break;
	case 7:
		key = 7;
		break;
	case 8:
		key = 8;
		break;
	case 9:
		key = 9;
		break;
	case 10:
		key = FUNCTION_KEY;//menu key or function key
		break;
	case 11:
		key = 0x00;// '0' key         //0x0b is '*'key which is removed
		break;
	case 12:
		key = ENTER_KEY;//enter
		break;
	default:
		break;
	}
#else
	switch(key & 0x7F)
	{
	case 0:
		key = 1;
		break;
	case 1:
		key = 2;
		break;
	case 2:
		key = 3;
		break;
	case 3:
		key = 4;
		break;
	case 4:
		key = 5;
		break;
	case 5:
		key = 6;
		break;
	case 6:
		key = 7;
		break;
	case 7:
		key = 8;
		break;
	case 8:
		key = 9;
		break;
	case 9:
		key = 11;
		break;
	case 10:
		key = 0;
		break;
	case 11:
		key = 10;
		break;
	default:
		break;
	}

#endif	
  	key = key | (oldkey & 0x80) ;
  	return(key);
}


BYTE KeyScan(void)
{  	
#ifdef NEW_TOUCH_KEYPAD	
	I2CKeyData = check_cap_keypad();
	if(I2CRxFlag)   // For Touch keypad 
		{
			I2CRxFlag = 0;
			return(I2CKeyData);	
		}
   else {return(0xff);}
	
#else
DWORD i;
BYTE rdkey;
 
#ifdef BIO_METRIC
	for(i=0;i<15;i++)
#else
	for(i=0;i<12;i++)
#endif
	{
		FIO1DIR |= KEY_DATA;
		FIO1SET |= KEY_DATA;
		FIO1PIN &= ~KEY_DATA; 
		FIO1PIN |= (i << 19);
		FIO1DIR &= ~KEY_SEL;
		rdkey = ((FIO1PIN >> 26) & 0x01);
		
		if(KeyPadSenseLogic == 0x01)//Active high keypad
		  	if(!rdkey)
			return((BYTE)i);
		
		if(KeyPadSenseLogic == 0x00)//Active low keypad
			if(rdkey) 
			return((BYTE)i);
	}
	return(0xff);	//No keyread
#endif
}
