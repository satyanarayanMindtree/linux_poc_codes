#ifndef __SENDEMAIL_H
#define __SENDEMAIL_H

#define EMAIL_TYPE_NORMAL		0			// retry and send else discard

#ifdef	ENABLE_EMAIL_SEND
struct EMAIL_ADRESS {
	 char Adress[32];
};

extern struct EMAIL_ADRESS EmailAd[MAX_EMAIL_ADDRESS];

extern void EmailInitialise(void);
extern unsigned char EmailSendFromBuffer(void);
extern unsigned char EmailAddToBuffer(unsigned inttrans,unsigned char type);
extern unsigned int EmailTransactionSend(struct TRNX_DATA *trans,unsigned int nooftrans,unsigned char *emailstr);
extern void EmailOneSecLoop(void);
extern unsigned char WriteEmailAddToFlash(void);
extern unsigned char ReadEmailAddFromFlash(void);

#endif


#endif
