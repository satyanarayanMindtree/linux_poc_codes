/*** BeginHeader Protocol */

#include <string.h>
#include <stdlib.h>
#include "config.h"
#include "version.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "CardMgmt.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "TemplatesonFlash.h"
#include "serial.h"
#include "Access.h"
#include "userintf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "smartcard.h"
#include "memory.h"
#include "rdcont.h"
#include "memmap.h"
#include "portdef.h"	
#include "rdpoll.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif
#include "spi.h"
#include "portlcd.h"
#include "IOEventMgmt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "emailsend.h"
#include "IOEventMgmt.h"
#ifdef ENABLE_GSM_GPRS
#include "GSMModem.h"
#endif
#include "ServerCheck.h"
#include "Timer.h"

#ifdef INSERT_SDCARD
	#include "../../SDCard/fat32.h"
	#include "../../SDCard/SD_routines.h"
#endif
#include "userIntfGLCD.h"
#include "LPC23xx.h"				/* LPC23xx/24xx definitions */
#include "Keypad.h"
#include "IClassRdr.h"
#include "IClassRdrProcess.h"
#include "../../GLCD/drivers/lcd/tft/touchscreen.h"
#include "adc.h"
//#include "../../uTaskerV1.4_LPC/stack/tcpip.h"                                             // {46} LCD tests

//#ifndef TELNET_TEST
//#define NETWORK_HANDLE (BYTE)(0 - 1)
//extern unsigned short fnPrint (unsigned char *ucToSend, unsigned char ucID);
//#endif

extern unsigned char ucUDP_IP_Address[IPV4_LENGTH]; // address to send UDP test frames to
extern USOCKET MyUDP_Socket;
//extern UDP_MESSAGE *ptrUDP_Frame;

unsigned char bufptr[PAGE_SIZE];		// locally used variable

unsigned char InOutTime1;			// If ContInOut =4 then following will store time zone number to toggle
unsigned char InOutTime2;
unsigned char InOut1;            // If ContInOut =4 then following will store what to do for that time zone InoutTimeX
unsigned char InOut2;

void HandleSerialAuth(unsigned char *buffer,unsigned char port);
unsigned int GetNextValidTransPtr(void);
unsigned char CheckValidTrans(struct TRNX_DATA *trans);
void SendNewSerialTrans(struct TRNX_DATA *trans,unsigned char port,unsigned char protocolno,unsigned int readptr);
void SendAllInfoString(unsigned char port);
void InitNetworkParameter(void);
void InitParameters(void);
void SerialHandleEmailSend(unsigned char *buffer,unsigned char port);

//extern USOCKET TIME_TCP_socket;
extern USOCKET USER_TCP_socket;
//int fnTimeListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen);
int fnUserListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen);
int TPushTestListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen); 
extern USOCKET fnTCP_close(USOCKET TCP_Socket);
extern QUEUE_TRANSFER fnSendBufTCP(USOCKET TCP_socket, unsigned char *ptrBuf, unsigned short usDataLen, unsigned char ucCommand);


extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;
extern struct EMAIL_ADRESS EmailAd[MAX_EMAIL_ADDRESS];
#ifdef BIO_METRIC
extern BYTE F_TransCrossOver,F_BIO_COMM;
#else
extern BYTE F_CheckSum;
#endif
extern BYTE F_KeyIdleTime,IdleKeyCounter;

static BYTE W;
static WORD X;
static unsigned int Z;
static BYTE Y[200];
//char test2[50]="Pankaj Zanwar 123456789012345678901234567890";

extern unsigned char  CurrentIP[IPV4_LENGTH],CurrentUDPIP[IPV4_LENGTH];  // This will store ip address which called protocol communication..
extern unsigned char SocketStatus ;
extern unsigned	char RemoteIP[IPV4_LENGTH];
DWORD CheckSum32;
extern unsigned	short RemotePort;
#ifdef BIO_METRIC
//	extern unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE]; 
//	extern unsigned char BufferTemp[MAX_BIO_TEMPLATE_SIZE]; 
#endif
extern ETHERNET_FRAME rx_frame;
unsigned char  MY_ethernet_source_MAC[MAC_LENGTH];

unsigned long AuthIPList[NUM_SOCKS+1];			// one extra location to manage server IP address   

extern USOCKET Socket_TCP;
extern TCP_CONTROL *PresentTcpPtr ;

extern unsigned char buff[PAGE_SIZE];
extern struct TIME_BASED_ACTION (*pTimeBasedAction)[] ;
//extern struct TEMPLATE_DATA TemlpltData;			not required
extern unsigned char CurrentInputType; 

const __packed struct PROTOCOL_CMD_HNDL SetSysPara[] =
{
	{0,D_CHAR,5, &SysInfo.MySlaveNo,&X, &Z, Y,"Terminal ID",1},		// Terminal ID
	{1,D_STR,15,&W, &X, &Z,&SysInfo.LOCAL_IP[0],"IP Address",1},     // Terminal IP
	{2,D_STR,15,&W, &X, &Z,&SysInfo.LOCAL_NETMASK[0],"Net Mask",1},     // Terminal Mask
	{3,D_STR,15,&W, &X, &Z,&SysInfo.LOCAL_GATEWAY[0],"GateWay",1},     // Terminal TerminalGateway
	{4,D_STR,15,&W, &X, &Z,&SysInfo.SERVER_IP_ADD[0],"Server IP",1},     // Terminal TerminalServerIP
	{5,D_INT,5,&W, &SysInfo.ETH_Port, &Z,Y,"Port Number",1},
	{6,D_CHAR,3,&SysInfo.GlobleMsg, &X, &Z,Y,"Globle Msg",1},
	{7,D_CHAR,3,&SysInfo.BannerMsg, &X, &Z,Y,"Banner Msg",1},
	{8,D_CHAR,3,&SysInfo.ContInOut, &X, &Z,Y,"Cont InOut",1},
	{9,D_CHAR,3,&SysInfo.IdentifyMode, &X, &Z,Y,"IdentifyMode",1},
	{10,D_CHAR,3,&SysInfo.ControllerType, &X, &Z,Y,"ControllerType",1},
	{11,D_CHAR,3,&SysInfo.NameType,&X, &Z,Y,"User Name Loc.",1},
	{12,D_CHAR,3,&SysInfo.MemMgmt, &X, &Z,Y,"Memory Mgmt"},
	{13,D_CHAR,3,&SysInfo.LastCardTime, &X, &Z,Y,"Last Card Time",1},
	{14,D_CHAR,3,&SysInfo.InputED,&X, &Z,Y,"Input EnaDis",1},
	{15,D_ARRAY_CHAR,4,&W, &X, &Z,&SysInfo.InOutTimeZone[0],"INOutTimeZoneX",1},
	{16,D_ARRAY_CHAR,4,&W, &X, &Z,&SysInfo.TZInOut[0],"INOutForTZX",1},
	{17,D_CHAR,3,&SysInfo.InOutToggle, &X, &Z,Y,"InOut Toggle",1},
	{18,D_CHAR,3,&SysInfo.WeigandOutCont, &X, &Z,Y,"Wei OutControl",1},  					// this is not used in this device ....
	{19,D_CHAR,3,&SysInfo.ChkPin, &X, &Z,Y,"Check Pin",1},
	{20,D_CHAR,3,&Doorinfo.EnDisWeiParity, &X, &Z,Y,"Wei Parity Chk",1},
	{21,D_CHAR,3,&Doorinfo.FREETIMEENABLE, &X, &Z,Y,"FREETIMEENABLE",1},
	{22,D_CHAR,3,&Doorinfo.EnableDuress, &X, &Z,Y,"Enable Duress",1},
	{23,D_CHAR,3,&Doorinfo.SocketCloseTime, &X, &Z,Y,"SocketClose Time",1},
	{24,D_CHAR,3,&W, &X, &Z,Y,"Not Used",1},
	{25,D_CHAR,3,&Doorinfo.APBEANABLE, &X, &Z,Y," APB ENABLE ",1},//ARMD0362
	{26,D_CHAR,3,&Doorinfo.FaclityCode_Chk, &X, &Z,Y,"FaclityCode_Chk",1},
	{27,D_CHAR,3,&Doorinfo.GlobalPinProx, &X, &Z,Y,"GlobalPinProx",1},
	{28,D_STR,15,&W, &X, &Z,&(SysInfo.LOCAL_DOMAINNAME[0]),"Domain Name IP",1},
	{29,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
    {30,D_CHAR,3,&Doorinfo.EnableEmail, &X, &Z,Y,"Enable Email",1}, 
	{31,D_CHAR,3,&Doorinfo.ChkHoliday, &X, &Z,Y,"Global Holiday",1},
	{32,D_CHAR,3,&Doorinfo.SecurityEnDis, &X, &Z,Y,"Not in use",1},
	{33,D_CHAR,3,&Doorinfo.F2keymode, &X, &Z,Y,"F2 Key Mode",1},
	{34,D_CHAR,3,&Doorinfo.EXTDOTL_EN, &X, &Z,Y,"EXTDOTL_EN",1},
   	{35,D_CHAR,3,&Doorinfo.NoCheckAPBTimer, &X, &Z,Y,"APBNoCheckTime",1},
	{36,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{37,D_CHAR,3,&Doorinfo.AnyDualFinger, &X, &Z,Y,"Any Dual Finger",1},          				// We will use this for Any Dual Finger
	{38,D_INT,5,&W,&Doorinfo.TemplateSize,&Z,Y,"Template Size ",1},
	{39,D_CHAR,3,&SysInfo.PushEnable,&X,&Z,Y,"PUSH Enable",1},
	{40,D_STR,15,&W, &X, &Z,&SysInfo.UDP_IPAdd[0],"UDP IP Address",1},     	// UDP Push Port IP Address
	{41,D_INT,5,&W, &SysInfo.UDP_PushPort, &Z,Y,"UDP Port No.",1},               //UDP Push Port Number 
	{42,D_STR,15,&W, &X, &Z,&SysInfo.PUSH_TCP_ServAdd1[0],"PUSH SRV IP  1",1}, // PUSH Server IP ADDRESS 1
	{43,D_STR,15,&W, &X, &Z,&SysInfo.PUSH_TCP_ServAdd2[0],"PUSH SRV IP  2",1},     // PUSH Serv IP ADDRESS  2
	{44,D_INT,5,&W, &SysInfo.PUSH_TCP_Port1, &Z,Y,"PUSH Srv Port 1",1},    			// PUSH Serv Port 1
	{45,D_INT,5,&W, &SysInfo.PUSH_TCP_Port2, &Z,Y,"PUSH Srv Port 2",1},				// PUSH Serv Port 2
	{46,D_CHAR,3,&SysInfo.PushWaitDelay, &X, &Z,Y,"PushWaitDelay",1},
	{47,D_CHAR,3,&SysInfo.PushTransDelay, &X, &Z,Y,"PushTransDelay",1},
	{48,D_CHAR,3,&SysInfo.PushNoOfTrans, &X, &Z,Y,"NoOfPushTrans",1},
	{49,D_CHAR,3,&SysInfo.PushThreshold, &X, &Z,Y,"PushThreshold ",1},
	{50,D_CHAR,3,&SysInfo.BioEnrollType, &X, &Z,Y,"BioEnrollType ",1},		// Biometric enroll type
	{51,D_CHAR,3,&SysInfo.SCInfoBlock[0], &X, &Z,Y,"SCInfoBlock ",1},			//
	{52,D_CHAR,3,&SysInfo.SCNameBlock[0], &X, &Z,Y,"SCTemplateBlock",1},			//
	{53,D_CHAR,3,&SysInfo.SCTemplateBlock[0], &X, &Z,Y,"SCTemplateBlock",1},			//
	{54,D_CHAR,3,&SysInfo.SCOther1Block, &X, &Z,Y,"SCOther1Block",1},			//
	{55,D_CHAR,3,&SysInfo.SCOther2Block, &X, &Z,Y,"SCOther1Block",1},			//
	{56,D_CHAR,3,&SysInfo.SCCardNoType, &X, &Z,Y,"SCCardNoType",1},			//
	{57,D_INT,3,&W,&SysInfo.CardDataSource,&Z,Y,"CardDataSource",1},			// from where to take the card data ( Smartcard or Local database)
	{58,D_ARRAY_CHAR,6,&W,&X,&Z,&SysInfo.TransType[0],"TransType",1},
	{59,D_CHAR,3,&SysInfo.SelAccessType, &X, &Z,Y,"Access Type",1},			//
	{60,D_ARRAY_CHAR,2,&W,&X,&Z,&SysInfo.SCReaderEnDis[0],"SCReaderEnDis",1},
	{61,D_ARRAY_CHAR,3,&W,&X,&Z,&SysInfo.SCKeyType[0],"SCKeyType",1},
	{62,D_ARRAY_CHAR,3,&W,&X,&Z,&SysInfo.SCKeySector[0],"SCKeySEctor",1},
	{63,D_CHAR,3,&SysInfo.AuthIP, &X, &Z,Y,"Auth IP Add",1},			//
	{64,D_ARRAY_INT,4,&W, &X,&Z,(BYTE*)&SysInfo.BaudRate[0],"Baud Rate  ",1},			//
	{65,D_CHAR,3,&SysInfo.SmartCardLayout, &X, &Z,Y,"SmartCardLayout",1},			//
	{66,D_CHAR,3,&SysInfo.BlockKeyboard, &X, &Z,Y,"BlockKeyboard  ",1},			//
	{67,D_CHAR,3,&SysInfo.EnDisUserMsg, &X, &Z,Y,"EnDisUserMsg",1},			//
	{68,D_CHAR,3,&SysInfo.PinProxFCode, &X, &Z,Y,"PinProxFCode",1},			//
	{69,D_CHAR,3,&Doorinfo.CardDigit, &X, &Z,Y,"Card Digit",1},			//
	{70,D_CHAR,3,&Doorinfo.CardMask, &X, &Z,Y,"Card Mask",1},			//
	{71,D_CHAR,3,&Doorinfo.AllowKeypadCard, &X, &Z,Y,"Allow KDB Card",1},			//
	{72,D_INT,3,&W,&Doorinfo.ControllerNo, &Z,Y,"ControllerNo",1},			//
	{73,D_CHAR,3,&SysInfo.TransAdjMode,&X,&Z,Y,"Trans Dwn Mode",1},			//
	{74,D_CHAR,3,&Doorinfo.FireType,&X,&Z,Y,"Fire Type ",1},			//
	{75,D_CHAR,3,&Doorinfo.EnDisEMPNoTrnx,&X,&Z,Y,"EnDisEMPNoTrnx",1},
	{76,D_CHAR,3,&Doorinfo.GPRSEnable,&X,&Z,Y,"GPRS Enable",1},
	{77,D_INT,5,&W,&Doorinfo.GPRSThreshold,&Z,Y,"GPRSThreshold ",1},
	{78,D_INT,5,&W,&Doorinfo.GPRSTime,&Z,Y,"GPRS Time ",1},
	{79,D_CHAR,3,&Doorinfo.EnDisEmpInDispCount,&X,&Z,Y,"EnDisEmpInCount",1},
	{80,D_INT,5,&W,&Doorinfo.E_InEmpCount, &Z, Y,"Emp In Count",0},
	{81,D_CHAR,3,&Doorinfo.PushConnectTimeout,&X,&Z,Y,"Push Soc Timeout",1},
	{82,D_CHAR,3,&Doorinfo.PushCloseDelay,&X,&Z,Y,"PushSocCloseTime",1},
	{83,D_CHAR,3,&Doorinfo.UserRestrict,&X,&Z,Y,"User Restricted ",1},
	{84,D_CHAR,3,&Doorinfo.KeySenseLogic,&X,&Z,Y,"Key sense logic",1},		//A00001
	{85,D_CHAR,3,&Doorinfo.FingerRecheck,&X,&Z,Y,"Finger Recheck",1},     //A00006
	{86,D_CHAR,3,&Doorinfo.BeepEnable,&X,&Z,Y,"Beep Enable",1},				//A00017
	{87,D_CHAR,3,&SysInfo.TransWriteCheck,&X,&Z,Y,"Trans WR Check",1},
	{88,D_CHAR,3,&Doorinfo.MaxBacklitOnTime,&X,&Z,Y,"Backlite ON Time",1},		// LCDbacklit off time.	 defect X0048
	{89,D_CHAR,3,&Doorinfo.PollSlaveNo,&X,&Z,Y,"Transp Slave No ",1},
	{90,D_CHAR,3,&Doorinfo.EnDisTransparentMode,&X,&Z,Y,"Transparent Mode",1},
	{91,D_CHAR,3,&Doorinfo.SlaveRespMode,&X,&Z,Y,"Slave Resp Mode",1},
	{92,D_CHAR,3,&Doorinfo.IClassCardType,&X,&Z,Y,"I-ClassCard Type",1},
	{93,D_CHAR,3,&Doorinfo.BARCCardType,&X,&Z,Y,"BARC_CARD_TYPE",1},
	{94,D_CHAR,3,&Doorinfo.DoorInterlock, &X, &Z,Y,"Door InterLock",1},  //ARMF0247 
	{95,D_CHAR,3,&W,&X,&Z,Y,"DOTL Event",1},			//in rabbit
	{96,D_CHAR,3,&W,&X,&Z,Y,"WeigandLED Sense",1},
	{97,D_CHAR,5,&W,&X,&Z,Y,"Emp In CountR3R4",0},
};

#define MAX_OTHER_SYS_PARA 	46
// lp
const struct PROTOCOL_CMD_HNDL OtherSysPara[] =
{
	{0,D_CHAR,3,&Doorinfo.EnDisDeadManZone, &X, &Z,Y,"Dead Man Zone   ",1},     //201210-1
	{1,D_INT,5,&W,&Doorinfo.DeadManZoneTime,&Z,Y,"Dead Man Time   ",1},      //201210-1
	{2,D_CHAR,3,&Doorinfo.BulkAddDelCard, &X, &Z,Y,"Bulk AddDel Card",1},
	{3,D_CHAR,3,&Doorinfo.DuelUserAuth, &X, &Z,Y,"Duel User Auth  ",1},    //DUA
	{4,D_CHAR,3,&Doorinfo.FirstInUserRule, &X, &Z,Y,"First In User   ",1},  // FIU Defination decleration
	{5,D_INT,5,&W,&Doorinfo.OccupancyCount,&Z,Y,"Occupancy Count ",1},    //281210-3
	{6,D_CHAR,3,&Doorinfo.EnDisWeigandBits, &X, &Z,Y,"EnDisWeigandBits",1},  //	
	{7,D_ARRAY_CHAR,2,&W,&X,&Z,&SysInfo.SCInfoBlock[0],"SCInfoBlock  ",1},        //
	{8,D_ARRAY_CHAR,2,&W,&X,&Z,&SysInfo.SCNameBlock[0],"SCTemplateBlock",1},         //
	{9,D_ARRAY_CHAR,2,&W,&X,&Z,&SysInfo.SCTemplateBlock[0],"SCTemplateBlock",1},        //
	{10,D_CHAR,3,&Doorinfo.ModemType,&X,&Z,Y,"GSM MODEM Type  ",1},  //
	{11,D_STR,32,&W,&X,&Z,&Doorinfo.PDPContext[0],"PDP Context     ",1},
	{12,D_STR,32,&W,&X,&Z,&Doorinfo.APNType[0],"APN Type        ",1},
	{13,D_STR,8,&W,&X,&Z,&Doorinfo.APNUserName[0],"APN UserName    ",1},
	{14,D_STR,8,&W,&X,&Z,&Doorinfo.APNPassword[0],"APN Password    ",1},
    {15,D_CHAR,3,&Doorinfo.F_FirstInUser,&X,&Z,Y,"First In cond   ",1},//not used
	{16,D_CHAR,3,&Doorinfo.DontDisturb, &X, &Z,Y," Do not Disturb ",1},
 	{17,D_INT,3,&W,&Doorinfo.UDPHeartBeat,&Z,Y,"UDP HeartBeat",1}, 
	{18,D_STR,15,&W, &X, &Z,&Doorinfo.HeartBeatIP[0],"HB Server IP ",1},
	{19,D_INT,5,&W, &Doorinfo.HBPort, &Z,Y,"HB Port Number ",1},
	{20,D_ARRAY_CHAR,8,&W, &X, &Z,&(SysInfo.SystemEventTimer[0]),"Event Timers   ",1},
	{21,D_INT,5,&W, &Doorinfo.UDPServerPort, &Z,Y,"UDP Server Port ",1},	 //ARMF0385 
   	{22,D_STR,15,&W, &X, &Z,&SysInfo.SB_AUTH_ServAdd1[0],"AUTH SRV IP  1",1}, 		// Auth Server 1 IP address
	{23,D_INT,5,&W, &SysInfo.SB_AUTH_Port1, &Z,Y,"AUTH Srv Port 1",1},    			// Auth Server 1 Port
	{24,D_STR,15,&W, &X, &Z,&SysInfo.SB_AUTH_ServAdd2[0],"AUTH SRV IP  2",1},     	// Auth Server 2 IP address
	{25,D_INT,5,&W, &SysInfo.SB_AUTH_Port2, &Z,Y,"AUTH Srv Port 2",1},				// Auth Server 2 Port
	{26,D_CHAR,3,&SysInfo.ServerAuthType, &X, &Z,Y,"ServerAuthType",1},				// ServerAuthType
	{27,D_STR,12,&W, &X, &Z,&Doorinfo.ServerMACAdress[0],"MAC Address     ",1},
	{28,D_STR,15,&W, &X, &Z,&Doorinfo.InternetTestIP[0],"Internet Test IP",1},	 //ARMF0502 
	{29,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{30,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{31,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{32,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{33,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{34,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{35,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{36,D_CHAR,3,&SysInfo.ThemeSelectNo, &X, &Z,Y,"Theme Select",1},				// Theme Select 
	{37,D_CHAR,3,&SysInfo.DispIdealTime, &X, &Z,Y,"Ideal Time",1},	
	{38,D_CHAR,3,&SysInfo.EnableAccessDate, &X, &Z,Y,"Enb Access Date",1},				 // this will not write access date in card flash
	{39,D_CHAR,3,&SysInfo.EnableSDWrite, &X, &Z,Y,"Enb SD Write ",1},				 // enable disable SD transaction write	
	{40,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{41,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{42,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{43,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{44,D_CHAR,3,&W, &X, &Z,Y,"Not in use",1},
	{45,D_CHAR,3,&Doorinfo.TScalibrated, &X, &Z,Y,"Touch Screen",1},				// calibrate touch screen
};
// lr
const __packed struct PROTOCOL_CMD_HNDL OtherPara[] =
{
	{0,D_CHAR,3, &W,&X, &Z, Y,"NotToBeUsed",0},		// Terminal ID
	{1,D_LONG,5,&W,&X, &TransReadPtr, Y,"TransReadPtr",1},
	{2,D_LONG,5,&W,&X, &TransWritePtr, Y,"TransWritePtr",1},
	{3,D_LONG,5,&W,&X, &TotalNosOfTrans, Y,"TotalNosOfTrans",1},
	{4,D_LONG,5,&W,&X, &TotalCards, Y,"TotalCards   ",1},
	{5,D_CHAR,3,&PercentageMem,&X, &Z, Y,"PercentageMem ",0},
	{6,D_INT,5,&W,(WORD *)&LastCardAddedPtr, &Z, Y,"LastCardAddedPtr",1},
	{7,D_STR,16,&W,&X,&Z,&ModelInfo.ModelNo[0],"Model No        ",1},
	{8,D_STR,8,&W,&X,&Z,&ModelInfo.SerialNo[0],"Serial No       ",1},
	{9,D_STR,8,&W,&X,&Z,&ModelInfo.MfgDate[0],"Mfg. Date       ",1}, 	//shree 11June
	{10,D_CHAR,8,&W,&X,&Z,Y,"Mfg. Date       ",1},    // this is dummy rt now to make compitable with microcontroller.
	{11,D_INT,5,&W,&InEmpCount,&Z,Y,"Emp In Count    ",1},
//	{12,D_INT,5,&W,&ParityErrCount,&Z,Y,"Parity Err Count",1},        //DB037
	{12,D_INT,5,&W,&X,&Z,Y,"Parity Err Count",1},        //DB037
	{13,D_INT,5,&W,&BadDataCounter,&Z,Y,"Bad Data Counter",1},        
	{14,D_INT,5,&W,&SlaveNoResponseCounter,&Z,Y,"SLNoResp Counter",1},        
	{15,D_INT,5,&W,&BadDataDayCounter,&Z,Y,"BadDataDayCount ",1},        
	{16,D_INT,5,&W,&NoRespDayCounter,&Z,Y,"NoResp DayCount ",1},        
//  {17,D_INT,5,&W,&InEmpCountR3R4,&Z,Y,"Emp In CountR3R4",1},
};


#ifdef BIO_METRIC
	#define MAX_USEFUL_PARA  19
#else
	#define MAX_USEFUL_PARA  16
#endif

#ifdef BIO_METRIC
const __packed struct PROTOCOL_CMD_HNDL Usefulpara[] =    //F0018 Add New service menu to display useful system parameters
	{
	   {0,D_STR,12,&W,&X,&Z,&ModelInfo.ModelNo[0],"Model Number:",1},
	   {1,D_CHAR,5,&SysInfo.MySlaveNo,&X, &Z, Y,"Unit ID:",1},
	   {2,D_INT,5,&W,&Doorinfo.ControllerNo, &Z,Y,"Controller No:",1},
	   {3,D_LONG,5,&W,&X,&MaxNoOfCards,Y,"Card Buffer:",1}, //MAX_NO_OF_CARD
	   {4,D_LONG,5,&W,&X,&TotalCards,Y,"Used Card Buffer",1},
	   {5,D_LONG,5,&W,&X,&BalCards,Y,"Bal. Card Buffer",1},
	   {6,D_LONG,5,&W,&X,&MaxNoOfTrans,Y,"Trans Buffer:",1}, //MAX_TRANS
	   {7,D_LONG,5,&W,&X,&TotalNosOfTrans,Y,"Used Trans Buff:",1},
	   {8,D_LONG,5,&W,&X,&BalTransBuffer,Y,"Bal Trans Buff:",1},
	   {9,D_LONG,5,&W,&X,&MaxNoofTemplates,Y,"Templates Supp",1},
	   {10,D_LONG,5,&W,&X,&UsedTemplates,Y,"Used Templates:",1},
	   {11,D_LONG,5,&W,&X,&BalTemplates,Y,"Bal. Templates:",1},
	   {12,D_STR,8,&W,&X,&Z,&ModelInfo.SerialNo[0],"Serial No:",1},
	   {13,D_STR,8,&W,&X,&Z,&ModelInfo.MfgDate[0],"Mfg. Date:",1},
	   {14,D_STR,16,&W,&X,&Z,(BYTE *)&COMPILEDATE[0],"FW Compile Date",1},
	   {15,D_STR,8,&W,&X,&Z,&FirmWareVer[0],"FirmWare Version",1},
	   {16,D_STR,4,&W,&X,&Z,&ModelInfo.ModelNo[12],"HardWare Version",1},
	   {17,D_STR,16,&W,&X,&Z,&Controllertype[0],"Controller Type:",1},
	   {18,D_CHAR,3,&SysInfo.ContInOut, &X, &Z,Y,"Reader Type:",1},
	   {19,D_ARRAY_CHAR,6,&W,&X,&Z,&ModelInfo.MACAddress[0],"MAC Address",1},
	};
#else
const __packed struct PROTOCOL_CMD_HNDL Usefulpara[] =    //F0018 Add New service menu to display useful system parameters
	{
	   {0,D_STR,12,&W,&X,&Z,&ModelInfo.ModelNo[0],"Model Number:",1},
	   {1,D_CHAR,5,&SysInfo.MySlaveNo,&X, &Z, Y,"Unit ID:",1},
	   {2,D_INT,5,&W,&Doorinfo.ControllerNo, &Z,Y,"Controller No:",1},
	   {3,D_LONG,5,&W,&X,&MaxNoOfCards,Y,"Card Buffer:",1}, //MAX_NO_OF_CARD
	   {4,D_LONG,5,&W,&X,&TotalCards,Y,"Used Card Buffer",1},
	   {5,D_LONG,5,&W,&X,&BalCards,Y,"Bal. Card Buffer",1},
	   {6,D_LONG,5,&W,&X,&MaxNoOfTrans,Y,"Trans Buffer:",1}, //MAX_TRANS
	   {7,D_LONG,5,&W,&X,&TotalNosOfTrans,Y,"Used Trans Buff:",1},
	   {8,D_LONG,5,&W,&X,&BalTransBuffer,Y,"Bal Trans Buff: ",1},
	   {9,D_STR,8,&W,&X,&Z,&ModelInfo.SerialNo[0],"Serial No:",1},
	   {10,D_STR,8,&W,&X,&Z,&ModelInfo.MfgDate[0],"Mfg. Date:",1},
	   {11,D_STR,16,&W,&X,&Z,(BYTE *)&COMPILEDATE[0],"FW Compile Date",1},//PANKAJXXX
	   {12,D_STR,8,&W,&X,&Z,&FirmWareVer[0],"FirmWare Version",1},
	   {13,D_STR,4,&W,&X,&Z,&ModelInfo.ModelNo[12],"HardWare Version",1},
	   {14,D_STR,16,&W,&X,&Z,&Controllertype[0],"Controller Type:",1},	  //ARMD0463
	   {15,D_CHAR,3,&SysInfo.ContInOut, &X, &Z,Y,"Reader Type:",1},
	   {16,D_ARRAY_CHAR,6,&W,&X,&Z,&ModelInfo.MACAddress[0],"MAC Address",1},
	};
#endif
//=============================================================================================================================


__packed struct ALARM_MGMT {
	char AlarmNo;				// Alarm Number to be sent
	char ChNo;					// Channel No
	unsigned char *AlPtr;		// Alarm Pointer
	unsigned char *AlRstPtr;	// Set/Clear this value to mark alarm cleared
	char ALCond;				// To store what beat mean alarm
	char ALName[16];			// Alarm Name
};

const __packed struct ALARM_MGMT AlarmValues[MAX_ALARMS]=
{
	{1 ,0xFF,&FIRE_STATUS 				,&FIRE_ALARM_RESET		,1,"Fire Alarm      "},	   
	{2 ,0xFF,&TAMPER_STATUS				,&TAMPER_ALARM_RESET	,1,"Tamper Alarm    "},
	{3 ,0xFF,&INTRUSION_STATUS			,&INTRUSN_ALARM_RESET	,1,"Intrusion Alarm "},
	{32, 0	,&DRStruct[0].Dotl_Alarm 	,&DOTL1_ALARM_RESET		,1,"DOTL 1 Alarm    "},
	{33, 0	,&DRStruct[0].Force_Alarm	,&DOTL1_ALARM_RESET		,1,"DFO 1 Alarm     "},
//	{34, 0  ,&F_DeadManZone[0]			,&W						,0,"DMZ_Alarm1 		"},
};
//=============================================================================================================================

void HandleServerBasedAuth(unsigned char *buffer,unsigned char port);

unsigned char *GetDataByPositionSep(unsigned char *dst,unsigned char *src,unsigned int pos,char sep);

unsigned char *GetDataByPositionSep(unsigned char *dst,unsigned char *src,unsigned int pos,char sep)
{
#ifdef USE_strstok_FUNC
char tmpdata[1024],*ptr1,*ptr2;
WORD  i;
	strncpy(tmpdata,(char *)src,1023);
	for(i=0,ptr1=tmpdata;i<pos;i++,ptr1=NULL)
	{
		ptr2 = ptr1 = strtok(ptr1,",");
		if(ptr1 == NULL)
			return(NULL);
	}
	strncpy((char *)dst,ptr2,strlen(ptr2)+1);
	return(dst);
#else
unsigned int i;
	i=0;
	if(pos!=1)
	{
	    pos--;
		while(1)
		{
			if(src[i] == '\0')
				return(NULL);
			if((src[i] == sep)||(src[i] == '\n')||(src[i] == '\r'))			
			{
				pos--;	
				if(pos ==0)
					break;
			}
			i++;
			if(i > 100)
				return(NULL);
		}
	i++;			
	}
	for(pos=0;pos<100;pos++)
	{
		if((src[i]=='\0') ||(src[i]==sep)||(src[i]=='\n')||(src[i]=='\r'))
			break;
		dst[pos]= src[i];
		i++;
	}
	dst[pos]='\0';
	return(dst);
#endif

}
//=============================================================================================================================
/*** BeginHeader GetDataByPosition*/
unsigned char *GetDataByPosition(unsigned char *dst,unsigned char *src,unsigned int pos);
/*** EndHeader */
unsigned char *GetDataByPosition(unsigned char *dst,unsigned char *src,unsigned int pos)
{
#ifdef USE_strstok_FUNC
char tmpdata[1024],*ptr1,*ptr2;
WORD  i;
	strncpy(tmpdata,(char *)src,1023);
	for(i=0,ptr1=tmpdata;i<pos;i++,ptr1=NULL)
	{
		ptr2 = ptr1 = strtok(ptr1,",");
		if(ptr1 == NULL)
			return(NULL);
	}
	strncpy((char *)dst,ptr2,strlen(ptr2)+1);
	return(dst);
#else
unsigned int i;
	i=0;
	pos--;
	while(1)
	{
		if(src[i] == '\0')
			return(NULL);
		if((src[i] == ',')||(src[i] == '\n')||(src[i] == '\r'))			
		{
			pos--;
			if(pos ==0)
				break;
		}
		i++;
		if(i > 1023)
			return(NULL);
	}	
	i++;
	for(pos=0;pos<1023;pos++)
	{
		if((src[i]=='\0') ||(src[i]==',')||(src[i]=='\n')||(src[i]=='\r'))
			break;
		dst[pos]= src[i];
		i++;
	}
	dst[pos]='\0';
	return(dst);
#endif

}

// Get Pointer to data from index location
/*** BeginHeader GetDataByPosition*/
unsigned char *GetPtrByPosition(unsigned char *src,unsigned int pos);	  //ARMF2005
/*** EndHeader */
unsigned char *GetPtrByPosition(unsigned char *src,unsigned int pos)
{
unsigned int i;
	i=0;
	pos--;
	while(1)
	{
		if(src[i] == '\0')
			return(NULL);
		if((src[i] == ',')||(src[i] == '\n')||(src[i] == '\r'))			
		{
			pos--;
			if(pos ==0)
				break;
		}
		i++;
		if(i > 1023)
			return(NULL);
	}	
	i++;
	return(&src[i]);
}

/*-----------------------------------------------------------*/
/*** BeginHeader SendTransactionWithSaperator*/
unsigned int SendTransactionWithSaperator(unsigned char port);
/*** EndHeader */
unsigned int SendTransactionWithSaperator(unsigned char port)
{
   struct TRNX_DATA trans;
   unsigned int ptr;           	//shree 05Dec int
//	F_FlashSelect = 1;
   //	F_FlashSelect = 0;  
   if(ptr == 1)
   {
      // Transaction not found
      	TransmitCharToX(C_NEW_ERROR_RETURN,port);
		TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
      	TransmitCharToX(TERMINATOR,port);
   }
   else
   {
      	//SendSerialSendTransSaperator(&trans,port,TransReadPtr);
	   	SendNewSerialTrans(&trans,port,1,TransReadPtr);            // FA00031
		TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
      	TransmitCharToX(TERMINATOR,port);
   }
   return(ptr);
}
/*
void SendSerialSendTransSaperator(struct TRNX_DATA *trans,unsigned char port,unsigned int readptr)
{
      	TransmitCharToX('T',port);
		TransmitCharToX(',',port);
      	SendDecimalToPC3CharToX(trans->Chnl,port);
		TransmitCharToX(',',port);
      	SendDecimalToPC3CharToX(trans->Event,port);
		TransmitCharToX(',',port);
      	SendDecimalLongToX(trans->CardNo,port);
		TransmitCharToX(',',port);
     	SendDecimalToX(trans->Datetime.Time.Hour,port);
      	SendDecimalToX(trans->Datetime.Time.Min,port);
      	SendDecimalToX(trans->Datetime.Time.Secs,port);
		TransmitCharToX(',',port);
      	SendDecimalToX(trans->Datetime.Date.Day,port);
      	SendDecimalToX(trans->Datetime.Date.Month,port);
      	SendDecimalToX(trans->Datetime.Date.Year,port);
		TransmitCharToX(',',port);
      	SendDecimalIntToX(TotalNosOfTrans,port);
		TransmitCharToX(',',port);				//PANKAJ
      	SendDecimalIntToX(readptr,port);
#ifdef TRANS_EXTRA_DATA
		TransmitCharToX(',',port);
      	SendDecimalToPC3CharToX(trans->CType,port);
		TransmitCharToX(',',port);
      	SendDecimalToPC3CharToX(trans->InputType,port);
#else
      	TransmitCharToX(',',port);
      	TransmitCharToX('0',port);
      	TransmitCharToX(',',port);
      	TransmitCharToX('0',port);
#endif

}*/

/* disabled as not not used ..
void TestTFT(void)
{
unsigned int n1,n2,n3,n4;
		
		TS_XP_FUNC_GPIO();
		TS_YM_FUNC_GPIO();
		TS_XM_FUNC_GPIO();
		TS_YP_FUNC_GPIO();
		DIR_OUT_TS_XP_PIN();
		DIR_OUT_TS_YM_PIN();
		DIR_OUT_TS_XM_PIN();
		DIR_OUT_TS_YP_PIN(); 
		tsReadZ(&n1,&n2); //yp,xm when xp=1,ym=0
		n3=tsReadX();
		n4=tsReadY();
} 	
*/

void delay1()
{
	int i;
		for(i=0;i<500;i++)
			{}
}
//#define TEMPLATE_DATA_SIZE	384
//extern struct TMPLT_DATA_STRUCT TemplateDataX;
/*** BeginHeader HandleSerialTemplate*/
unsigned char HandleSerialTemplate(unsigned char *buffer,unsigned char port);
/*** EndHeader */
unsigned char HandleSerialTemplate(unsigned char *buffer,unsigned char port)
{
//_CTemplateInfo templateinfobuffer;
_CExtraInfo CardExtraData;
//struct TEMPLATE_DATA tempdata;
struct SD_TEMPLATE_DATA SDtemplateinfo;
CardData tempuser;
BYTE err=2,temp;					//enrollmode;	
unsigned int ptrdata1,cardfrom;
			  
#ifdef BIO_METRIC
CARDNO_DATA_STORAGE_TYPE userid;
WORD fingerid,tempsize,cmdver,i;
unsigned char tno;//,localorflash;
int ptrdata;//,tindex;

WORD toffsetno,tblocksz,itmp;

	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto NEW_CMD_HandleSerialTemplate;
	cmdver = atoi((char *)bufptr);
//	DisplaySensorBusyMessage();
//====================================================================================================================================

	switch(cmdver)
	{
		case 1:           // $1lx,1,userID,fingerID,chksum,enter
		case 5:
#ifdef SUPPORT_SUPREMA
			if(SensorTemplateSize == 0)
			{
				if(ReadBioSystemParameter(BIO_SYS_TEMPLATE_SIZE) == 0)
				{
					SensorTemplateSize = (unsigned short)BioCmdSize&0xFFFF;
				}
			}
#else
			SensorTemplateSize = MAX_BIO_TEMPLATE_SIZE;
#endif
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_HandleSerialTemplate;
            userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
 		 	if(GetDataByPosition(bufptr,buffer,4) == NULL)
	     	 	goto NEW_CMD_HandleSerialTemplate;
        	fingerid = atoi((char *)bufptr);
			if((fingerid > MAX_FINGERS)||(fingerid==0))
			{
           		err = 7;
				goto NEW_CMD_SerialTemplate_WithError;
			}

            if(cmdver == 5)
            	err = ReadDownloadTemplate(userid,fingerid,TemplateBuff);
         	else
				err = ReadSingleTemplate(userid,fingerid,TemplateBuff);
			if(err == 0)
            {
	            tempsize = (WORD)BioCmdSize;
            	TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
	      		TransmitCharToX(',',port);
				SendDecimalLongToX(userid,port);
   	         	TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(fingerid,port);
	      		TransmitCharToX(',',port);
				SendDecimalIntToX(tempsize,port);
	      		TransmitCharToX(',',port);
            	ptrdata = 0;
	           	while(ptrdata < tempsize)
				{
					SendAsciiToX(TemplateBuff[ptrdata],port);
					ptrdata++;
				}
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
		        return(0);
            }
            else
             	goto NEW_CMD_HandleSerialTemplate;
//====================================================================================================================================
	//  $1lx,300,
	//  Delete all templates 
		case 11:
//			F_FlashSelect = 1;
			err = DelAllTempletSD();
//			F_FlashSelect = 0;
			TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
	      	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(err,port);
	      	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return(0);
	//		break;
		case 310: // FOR TESTING sCAN tEMPLATE 
			ScanBioTemplate((BYTE*)&SDtemplateinfo.TData);
		break;
	//====================================================================================================================================	
		case 12:
		//  $1lx,301,
		//  Delete all template info , it will be set to 0xFF 
//			F_FlashSelect = 1;
			DelAllCardTemplateInfoFromFlash();
			TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
		   	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
		  	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
//			F_FlashSelect = 0;
			return(0);

//===================TFT Testing =================================================================================================================
//		case 25:	//$1lx,25,
//			TestTFT();
//		break;

		case 26:	//$1lx,26,
			TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
		   	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(26,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(adcRead(TS_YP_ADC_CHANNEL),port);
		  	TransmitCharToX(',',port);
			SendDecimalIntToX(adcRead(TS_XM_ADC_CHANNEL),port);
		  	TransmitCharToX(',',port);
			SendDecimalIntToX(adcRead(TS_YM_ADC_CHANNEL),port);
		  	TransmitCharToX(',',port);
			SendDecimalIntToX(adcRead(TS_XP_ADC_CHANNEL),port);
		  	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
		break;
//====================================================================================================================================
		case C_SUB_ENROLL_FINGER_SD: // 8, Add template to SD	& add card template info to flash //NGD00037
		//$1lx,8,cardno,tno,tempsize,templatexxxx,
#ifdef SUPPORT_SUPREMA
			if(SensorTemplateSize == 0)
			{
				if(ReadBioSystemParameter(BIO_SYS_TEMPLATE_SIZE) == 0)
				{
					SensorTemplateSize = (unsigned short)BioCmdSize&0xFFFF;
				}
			}
#else
			SensorTemplateSize = MAX_BIO_TEMPLATE_SIZE;
#endif		
			if(GetDataByPosition(bufptr,buffer,3) == NULL)	   	// CardNo
		      	goto NEW_CMD_HandleSerialTemplate;
            tempuser.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)		// TemplateNo
	      		goto NEW_CMD_HandleSerialTemplate;
        	tno = atoi((char *)bufptr);
			if(tno > MAX_TEMPLATE_SD_PERUSER)
			{
				err = ERROR_IMPROPER_PARAMETER;  // indicates no of template exceeds 
				goto NEW_CMD_SerialTemplate_WithError;						
			}
			if(GetDataByPosition(bufptr,buffer,5) == NULL)		// Template size
	      		goto NEW_CMD_HandleSerialTemplate;
        	tempsize = atoi((char *)bufptr);
			if(tempsize != SensorTemplateSize)
			{
				if(tempsize!=0)
				{
					err = ERROR_IMPROPER_TEMPLATESZ;
					goto NEW_CMD_HandleSerialTemplate;
				}
				else
					tempsize = SensorTemplateSize;		// Take template size which is there in sensor if template given is zero
			}				
			ptrdata  = SearchDisplayCard(tempuser.CardNo,&tempuser);	 
			if(cmdver == C_SUB_ENROLL_FINGER_SD)	   // 
			{
				if(ptrdata != CARD_NOT_FOUND)
				{
					if(GetHexStrByPosition((unsigned char*)&SDtemplateinfo.TData,buffer,6) != 0) 
						goto NEW_CMD_HandleSerialTemplate;
					err = ReadCardTemplateInfoFromFlash(ptrdata,&CardExtraData);		// check whether card template is in SD or sensor 					
					SDtemplateinfo.TSZ = MAX_TEMPLATE_SIZE;
					if((CardExtraData.Image_TemplateSD_Flag&0x0F) == 0x00)
					{
// 						GetBalanceTemplate();	// NGD0022
// 						if(BalTemplates >= TEMPLATE_OFFSET)
// 							CardExtraData.Image_TemplateSD_Flag = 0x01;   // add in Sensor 
// 						else
						if(tno > 1)	//NGD00051
						{
							err = ERROR_IMPROPER_PARAMETER;
							goto NEW_CMD_HandleSerialTemplate;	
						}
						CardExtraData.Image_TemplateSD_Flag = 0x02;   // add in SD 	
						CardExtraData.Image_TemplateSD_Flag = 0;
					}
					if((CardExtraData.Image_TemplateSD_Flag&0x0F) == 0x01)
					{
						err = ERROR_ALREADY_TEMPLATE_INSENSOR;  // indicates template for that ID is in Sensor  
						goto NEW_CMD_SerialTemplate_WithError;							
					}						 
					else if((CardExtraData.Image_TemplateSD_Flag&0x0F) == 0x02)
					{						 
						if(tno == 1)
							CardExtraData.TemplateData = CardExtraData.TemplateData | FIRST_TEMPLATE;						 								
						else if(tno == 2)    // 0x01 
							CardExtraData.TemplateData = CardExtraData.TemplateData | SECOND_TEMPLATE;						 
						else if(tno == 3)
							CardExtraData.TemplateData = CardExtraData.TemplateData | THIRD_TEMPLATE;						
						else if(tno == 4) // 3rd template
							CardExtraData.TemplateData = CardExtraData.TemplateData | FOURTH_TEMPLATE;						
						else if(tno== 5)// 4 template
							CardExtraData.TemplateData = CardExtraData.TemplateData | FIFTH_TEMPLATE;						
						else if(tno == 6)// 5 template
							CardExtraData.TemplateData = CardExtraData.TemplateData | SIXTH_TEMPLATE;						
						else if(tno== 7)// 6 template
							CardExtraData.TemplateData = CardExtraData.TemplateData | SEVENTH_TEMPLATE;						
						else if(tno == 8)// 7 template
							CardExtraData.TemplateData = CardExtraData.TemplateData | EIGHTH_TEMPLATE;	
						else{}							
					}	
					else
					{
						err = ERROR_ADD_TEMPLATE_STORAGE_TYPE;  // indicates template for that ID is in Sensor  
						goto NEW_CMD_SerialTemplate_WithError;							
					}	

					err = AddCardTemplateInfoToFlash(ptrdata,&CardExtraData); // add template info in flash 						
					if(err == 0)
					{	
						SDtemplateinfo.TSZ = tempsize;	 // can change when implimenting for ISO 						
						SDtemplateinfo.CardNo= tempuser.CardNo;					   //NGD00028
						err = AddTemplateToSD(SDtemplateinfo,ptrdata,tno);   // Add template data to SD card  
						if(err == 0)
						{
							err = ERROR_SD_WRITE_FAIL;
							goto NEW_CMD_SerialTemplate_WithError;								
						}
						else
							err = 0;
					}
					else
					{
						err = ERROR_MAX_CARD_REACH;
						goto NEW_CMD_SerialTemplate_WithError;
					}				
					TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
					TransmitCharToX(',',port);						
					SendDecimalToPC3CharToX(cmdver,port);
					TransmitCharToX(',',port);
					SendDecimalLongToX(tempuser.CardNo,port);
	   	         	TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(tno,port);
		      		TransmitCharToX(',',port);
					SendDecimalIntToX(tempsize,port);
					TransmitCheckSumX(port);
		      		TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
					return(0);
				}
				else
				{
					err = EVENT_CARD_NOT_FOUND;
             		goto NEW_CMD_SerialTemplate_WithError;
				}
			}		
		case C_NEW_SUB_READ_EXTRAINFO: // 59, read card template info from flash
//#1x,59,cardno,templocation,nooftempflash,noofsdtemplate,

			if(GetDataByPosition(bufptr,buffer,3) == NULL)	   	// CardNo
		      	goto NEW_CMD_HandleSerialTemplate;
            tempuser.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			ptrdata  = SearchDisplayCard(tempuser.CardNo,&tempuser);	 
			if(ptrdata != CARD_NOT_FOUND)
			{
				if(ReadCardTemplateInfoFromFlash(ptrdata,&CardExtraData)==0)
			  	{
					if((CardExtraData.Image_TemplateSD_Flag & 0x000F) == 2)
					{
						tno = 0;
 						 for(i=0;i<7;i++)
							tno += (CardExtraData.TemplateData>>i)&0x01;
					}
					else
					{
						tno=0;
					}
					fingerid=0;
				   	for(i=1;i<=MAX_TEMPLATE_SD_PERUSER;i++)
				   	{
					   	if(ReadTemplateFromSD(ptrdata,&SDtemplateinfo,i) == 0)	
					   	{		
					   		if(tempuser.CardNo==SDtemplateinfo.CardNo)
								fingerid ++;							
						}
					}
					TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(cmdver,port);
					TransmitCharToX(',',port);					
					SendDecimalLongToX(tempuser.CardNo,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(CardExtraData.Image_TemplateSD_Flag,port);
	 				TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(CardExtraData.TemplateData,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(tno,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(fingerid,port);
		      		TransmitCharToX(',',port);
					TransmitCheckSumX(port);
					TransmitCharToX(',',port);
			        TransmitCharToX(TERMINATOR,port);
					return(0);
			   	}
				else
				{
					err = 5;
	             	goto NEW_CMD_SerialTemplate_WithError;
				}
			}
			else
			{
				err = 4;
             	goto NEW_CMD_SerialTemplate_WithError;
			}	
			break;
		case C_NEW_SUB_READ_FINGER_SD: // $1lx,58,cardno,tempno,       

			if(GetDataByPosition(bufptr,buffer,3) == NULL)	   	// CardNo
		      	goto NEW_CMD_HandleSerialTemplate;
            tempuser.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)	   	// CardNo
		      	goto NEW_CMD_HandleSerialTemplate;
			tno = atoi((char *)bufptr);
			ptrdata  = SearchDisplayCard(tempuser.CardNo,&tempuser);	 
			if(ptrdata != CARD_NOT_FOUND)
			{
				if(ReadTemplateFromSD(ptrdata,&SDtemplateinfo,tno) == 0)	
				{		
					if(tempuser.CardNo==SDtemplateinfo.CardNo)
		            {	
						TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
						TransmitCharToX(',',port);
						SendDecimalToPC3CharToX(58,port);
					}
					else
		            {
						TransmitCharToX('e',port);
						TransmitCharToX(',',port);
						TransmitCharToX('7',port);
					}
		      		TransmitCharToX(',',port);
					SendDecimalLongToX(SDtemplateinfo.CardNo,port);
	   	         	TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(tno,port);
		      		TransmitCharToX(',',port);
					SendDecimalIntToX(SDtemplateinfo.TSZ,port);
					TransmitCharToX(',',port);
					i= 0;
					if(SDtemplateinfo.TSZ>=MAX_TEMPLATE_SIZE+10)		// because of some corrupton we may print huge data
						SDtemplateinfo.TSZ=MAX_TEMPLATE_SIZE;						
					while(i < SDtemplateinfo.TSZ)	 
					{
						SendAsciiToX(SDtemplateinfo.TData[i],port);
						i++;
					}
					TransmitCharToX(',',port);
					TransmitCheckSumX(port);
			        TransmitCharToX(',',port);
			        TransmitCharToX(TERMINATOR,port);	
					return(0);
				}
				else
				{
					err = ERROR_MAX_CARD_REACH;
             		goto NEW_CMD_SerialTemplate_WithError;
				}	
			}
			else
			{
				err = 4;
             	goto NEW_CMD_SerialTemplate_WithError;
         	}
//====================================================================================================================================
case 306:	//TESTING 2nd FLASH 
///		F_FlashSelect = 1;
		TestFlash();
//		F_FlashSelect = 0;
		TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
      	TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(0,port);
      	TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
		TransmitCharToX(TERMINATOR,port);
		return(0);
//====================================================================================================================================
/*		case 301:	//$1lx,301,cardno,LocalOrFlash,tno,TemplateXXXXXXXXXXXXXXXXXXx,
#ifdef SUPPORT_SUPREMA
			if(SensorTemplateSize == 0)
			{
				if(ReadBioSystemParameter(BIO_SYS_TEMPLATE_SIZE) == 0)
				{
					SensorTemplateSize = (unsigned short)BioCmdSize&0xFFFF;
				}
			}
#else
			SensorTemplateSize = MAX_BIO_TEMPLATE_SIZE;
#endif
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_HandleSerialTemplate;
            userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
	      		goto NEW_CMD_HandleSerialTemplate;
        	fingerid = atoi((char *)bufptr);
			
			if(fingerid > MAX_FINGERS)
			{
           		err = 7;
				goto NEW_CMD_SerialTemplate_WithError;
			}

			err = ReadSingleTemplate(userid,fingerid,TemplateBuff);
			if(err == 0)
            {
	            tempsize = (WORD)BioCmdSize;
            	TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
	      		TransmitCharToX(',',port);
				SendDecimalLongToX(userid,port);
   	         	TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(fingerid,port);
	      		TransmitCharToX(',',port);
				SendDecimalIntToX(tempsize,port);
	      		TransmitCharToX(',',port);
            	ptrdata = 0;
	           	while(ptrdata < tempsize)
				{
 					if(cmdver == 1)
						SendAsciiToX(TemplateBuff[ptrdata],port);
					else if(cmdver == 301)
						TemplateBufferX[ptrdata]= TemplateBuff[ptrdata];
					
					ptrdata++;
				}
				if(cmdver == 301)
				{
//					F_FlashSelect = 1;
					index=AddTemplateToFl(userid,fingerid,(unsigned char *)&TemplateBufferX);
//					F_FlashSelect = 0;
				}
	      		SendDecimalIntToX(index,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
		        return(0);
            }
            else
             	goto NEW_CMD_HandleSerialTemplate;

//====================================================================================================================================
		case 302:	 //$1lx,302,userID,fingerID,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_HandleSerialTemplate;
            userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
 			if(GetDataByPosition(bufptr,buffer,4) == NULL)
		      	goto NEW_CMD_HandleSerialTemplate;
            fingerid = atoi((char *)bufptr);
			if(fingerid > MAX_FINGERS)
			{
           		err = 7;
				goto NEW_CMD_SerialTemplate_WithError;
			}
//			F_FlashSelect = 1;
			index = SearchTemplateFromFl(userid,fingerid);
			TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
	      	TransmitCharToX(',',port);	
			SendDecimalIntToX(index,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
      		TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
//			F_FlashSelect = 1;
			return(0);
//		break; */
//====================================================================================================================================
//$1lx,51,userID,finderID,TemplateSize,TemplateOffsetNo,TemplateBlockSize,chksum,enter
//$1lx,51,12345,1,859,0,512,
		case 51:
#ifdef SUPPORT_SUPREMA
			if(SensorTemplateSize == 0)
			{
				if(ReadBioSystemParameter(BIO_SYS_TEMPLATE_SIZE) == 0)
				{
					SensorTemplateSize = (unsigned short)BioCmdSize&0xFFFF;
				}
			}
#else
			SensorTemplateSize = MAX_BIO_TEMPLATE_SIZE;
#endif
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)		//userID
		      	goto NEW_CMD_HandleSerialTemplate;
            userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
 			if(GetDataByPosition(bufptr,buffer,4) == NULL)		//finderID
		      	goto NEW_CMD_HandleSerialTemplate;
            fingerid = atoi((char *)bufptr);
			if(fingerid > MAX_FINGERS)
			{
           		err = 7;
				goto NEW_CMD_SerialTemplate_WithError;
			}
			if(GetDataByPosition(bufptr,buffer,5) == NULL)		//Template size
				goto NEW_CMD_HandleSerialTemplate;			
			tempsize = atoi((char *)bufptr);					//Not used currently
 			if(GetDataByPosition(bufptr,buffer,6) == NULL)		//offsetno
		      	goto NEW_CMD_HandleSerialTemplate;
            toffsetno = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,7) == NULL)		//Template Block Size
				goto NEW_CMD_HandleSerialTemplate;
			tblocksz = atoi((char *)bufptr);
			ptrdata = toffsetno * tblocksz;
			if(tblocksz > (tempsize-ptrdata))
				tblocksz = tempsize-ptrdata; 

			err = ReadSingleTemplate(userid,fingerid,TemplateBuff);
			if(err == 0)
            {
				if(tempsize != (WORD)BioCmdSize)
				{
	           		err = 8;
					goto NEW_CMD_SerialTemplate_WithError;
				}
	            tempsize = (WORD)BioCmdSize;
            	TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
	      		TransmitCharToX(',',port);
				SendDecimalLongToX(userid,port);
   	         	TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(fingerid,port);
	      		TransmitCharToX(',',port);
				SendDecimalIntToX(tempsize,port);
	      		TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(toffsetno,port);
	      		TransmitCharToX(',',port);
				SendDecimalIntToX(tblocksz,port);
	      		TransmitCharToX(',',port);
				for(itmp=0;itmp<tblocksz;itmp++)
				{
					SendAsciiToX(TemplateBuff[itmp+ptrdata],port);
				}
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
		        return(0);
            }
            else
             	goto NEW_CMD_HandleSerialTemplate;
//==============================ADD Database of Sensor in SD  =====================================================================================================
		case 10: // first delete all card data then  use this protocol command   $1lx,10,
			for(userid=1;userid<=1489;userid++)	 // 510 beacuse sensor with dummy template starting from user id 1 to 510 
			{
					if(CheckBioUserID(userid) == 0)
					{
						UserFingerNo = (BYTE)BioCmdSize & 0x0f;
		
							Carddata.CardNo = userid;
							if(userid > 65535)
							{
								if(Doorinfo.CardDigit == 8)
									Carddata.CardPin = (WORD)((DWORD)(userid & 0x0000FFFFL) % (DWORD)10000);   
								else
									Carddata.CardPin = (WORD)((DWORD)userid % 10000);
							}
							else
								Carddata.CardPin = (WORD)userid;
							Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
							Carddata.CardInfo.Door1 = 0x1;
							Carddata.CardInfo.Door2 = 0x1;
							Carddata.CardInfo.Holiday = 0x0;
							Carddata.Info.MesgInfo = 0;
							Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
#ifdef EN_DOORACCESS
							Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
#ifdef EN_CARD_EXP_DATE
							Carddata.ExpDT = 0;
#endif
#ifndef NEW_CARD_FORMAT
							Carddata.Info.BirthMonth = 0;
							Carddata.Info.BirthDate = 0;
#endif		
							for(i=0;i<15;i++)
							{	CardExtraData.Name[i] = ' ';}

							CardExtraData.JoiningDate = 0;
							CardExtraData.BirthDate = 0;
							CardExtraData.BirthMonth = 0;
							CardExtraData.AccessDate = 0;
							CardExtraData.TemplateData =0 ;
							CardExtraData.Image_TemplateSD_Flag = 2;
							memset((char*)SDtemplateinfo.TData,'\0',sizeof(SDtemplateinfo.TData));							
						delay1();
						ptrdata = AddCard(Carddata);								
						if(UserFingerNo>=8)
								UserFingerNo = 8;
						for(i=1;i<=UserFingerNo;i++)
						{
							if(i == 1)
								CardExtraData.TemplateData |= FIRST_TEMPLATE;						 								
							else if(i == 2)    // 0x01 
								CardExtraData.TemplateData |= SECOND_TEMPLATE;						 
							else if(i == 3)
								CardExtraData.TemplateData |= THIRD_TEMPLATE;						
							else if(i == 4) // 3rd template
								CardExtraData.TemplateData |= FOURTH_TEMPLATE;						
							else if(i== 5)// 4 template
								CardExtraData.TemplateData |= FIFTH_TEMPLATE;						
							else if(i == 6)// 5 template
								CardExtraData.TemplateData |= SIXTH_TEMPLATE;						
							else if(i== 7)// 6 template
								CardExtraData.TemplateData |= SEVENTH_TEMPLATE;						
							else if(i == 8)// 7 template
								CardExtraData.TemplateData |= EIGHTH_TEMPLATE;	
							else{}							

							err = ReadSingleTemplate(userid,i,(unsigned char*)&SDtemplateinfo.TData);							
							SDtemplateinfo.TSZ = MAX_TEMPLATE_SIZE;

						delay1();
							SDtemplateinfo.TSZ = MAX_TEMPLATE_SIZE;	 // can change when implimenting for ISO 						
							SDtemplateinfo.CardNo= userid;					   //NGD00028
							err = AddTemplateToSD(SDtemplateinfo,ptrdata,i);   // Add template data to SD card  								
						}
						delay1();
						err = AddCardTemplateInfoToFlash(ptrdata,&CardExtraData); // add template info in flash 											
					}		
			}	
		  
			break;
		  
		  case 13: //$1lx,13,
				cardfrom=1;
			  for(userid=1490;userid<=(2978);userid++)
				{						
					if(cardfrom%1490 == 0)
						cardfrom=1;					
						delay1();
						ptrdata1  = CardSearch(cardfrom);	 
						ReadCardTemplateInfoFromFlash(ptrdata1,&CardExtraData);
							
						Carddata.CardNo = userid;
						if(userid > 65535)
						{
							if(Doorinfo.CardDigit == 8)
								Carddata.CardPin = (WORD)((DWORD)(userid & 0x0000FFFFL) % (DWORD)10000);   
							else
								Carddata.CardPin = (WORD)((DWORD)userid % 10000);
						}
						else
							Carddata.CardPin = (WORD)userid;
						Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
						Carddata.CardInfo.Door1 = 0x1;
						Carddata.CardInfo.Door2 = 0x1;
						Carddata.CardInfo.Holiday = 0x0;
						Carddata.Info.MesgInfo = 0;
						Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
#ifdef EN_DOORACCESS
						Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
#ifdef EN_CARD_EXP_DATE
						Carddata.ExpDT = 0;
#endif
#ifndef NEW_CARD_FORMAT
						Carddata.Info.BirthMonth = 0;
						Carddata.Info.BirthDate = 0;
#endif		
						ptrdata = AddCard(Carddata);

						UserFingerNo = 0;
						for(temp=0;temp<7;temp++)
						{
							UserFingerNo += (CardExtraData.TemplateData>>temp) & 0x01;					
						}								
						if(UserFingerNo>=8)
								UserFingerNo = 8;
						for(temp=1;temp<=UserFingerNo;temp++)
						{
							delay1();
							if(ReadTemplateFromSD(ptrdata1,&SDtemplateinfo,temp) == 0)	
							SDtemplateinfo.TSZ = MAX_TEMPLATE_SIZE;	 // can change when implimenting for ISO 						
							SDtemplateinfo.CardNo= userid;					   //NGD00028
							err = AddTemplateToSD(SDtemplateinfo,ptrdata,temp);   // Add template data to SD card  									
						}
						cardfrom++;
						delay1();
						err = AddCardTemplateInfoToFlash(ptrdata,&CardExtraData); // add template info in flash 						
						
					}						
			break;
					
			case 14:// $1lx,14,dummy tempalte //  this command will add 75000 user with 8 template on each user 
#ifdef ENABLE_WATCHDOG
							WDTFeed();		//Clear watchdog timer
#endif						

				memset((char*)SDtemplateinfo.TData,'\0',sizeof(SDtemplateinfo.TData));							
				if(GetHexStrByPosition((unsigned char*)&SDtemplateinfo.TData,buffer,3) != 0) // Dummy  Template
					goto NEW_CMD_HandleSerialTemplate;
				
			  for(userid=1;userid<=75000;userid++)
				{													
#ifdef ENABLE_WATCHDOG
						if(userid%20 == 0)
						{	
							WDTFeed();		//Clear watchdog timer
						}
#endif						
						SDtemplateinfo.CardNo = Carddata.CardNo = userid;
						SDtemplateinfo.TSZ = 384;
						if(userid > 65535)
						{
							if(Doorinfo.CardDigit == 8)
								Carddata.CardPin = (WORD)((DWORD)(userid & 0x0000FFFFL) % (DWORD)10000);   
							else
								Carddata.CardPin = (WORD)((DWORD)userid % 10000);
						}
						else
							Carddata.CardPin = (WORD)userid;
						Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
						Carddata.CardInfo.Door1 = 0x1;
						Carddata.CardInfo.Door2 = 0x1;
						Carddata.CardInfo.Holiday = 0x0;
						Carddata.Info.MesgInfo = 0;
						Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
#ifdef EN_DOORACCESS
						Carddata.DoorAccess = 0xFF;		  //ARMD0402	  
#endif//#endif EN_DOORACCESS
#ifdef EN_CARD_EXP_DATE
						Carddata.ExpDT = 0;
#endif
#ifndef NEW_CARD_FORMAT
						Carddata.Info.BirthMonth = 0;
						Carddata.Info.BirthDate = 0;
#endif		
							for(i=0;i<15;i++)
							{	CardExtraData.Name[i] = ' ';}

							CardExtraData.JoiningDate = 0;
							CardExtraData.BirthDate = 0;
							CardExtraData.BirthMonth = 0;
							CardExtraData.AccessDate = 0;
							CardExtraData.TemplateData =0 ;
							CardExtraData.Image_TemplateSD_Flag = 2;
						ptrdata = AddCard(Carddata);

						UserFingerNo = 0;
						
						for(temp=1;temp<=8;temp++)
						{
							delay1();
							SDtemplateinfo.TSZ = MAX_TEMPLATE_SIZE;	 // can change when implimenting for ISO 						
							SDtemplateinfo.CardNo= userid;					   //NGD00028
							err = AddTemplateToSD(SDtemplateinfo,ptrdata,temp);   // Add template data to SD card  									
						}
						CardExtraData.TemplateData = 0xFF; //  all 8 template						 								
						delay1();
						err = AddCardTemplateInfoToFlash(ptrdata,&CardExtraData); // add template info in flash 						
						
				}					
			break;
						
//===================================================================================================================================			
//$1lx,3,Card No,Template No,Template Size,Template Info,Chksum,ENT			
//	$1lx,3,12345,1,320,Template Info,74,
		case C_SUB_ENROLL_FINGER:    			//2 Restore template to user ID
		case C_SUB_ENROLL_FINGER_CHECK:    		//3 Restore with check for old templates
		case C_SUB_ENROLL_DUP_FINGER:			//6  this will add two fingers at a time
		case C_SUB_ENROLL_DUP_FINGER_CHECK:  	//7 this will add two fingers at a time with check..
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);                				// Card number
			if(GetDataByPosition(bufptr,buffer,4) == NULL)   	// finger ID
				goto NEW_CMD_HandleSerialTemplate;
			fingerid = atoi((char *)bufptr);
			if(fingerid > MAX_FINGERS)
			{
           		err = 7;
				goto NEW_CMD_SerialTemplate_WithError;
			}
			if(GetDataByPosition(bufptr,buffer,5) == NULL) // Template size
				goto NEW_CMD_HandleSerialTemplate;
			tempsize = atoi((char *)bufptr);
#ifndef SUPPORT_SUPREMA
			tempsize = tempsize * fingerid;
#endif
			if(GetHexStrByPosition(TemplateBuff,buffer,6) != 0) // Template
				goto NEW_CMD_HandleSerialTemplate;

			ptrdata = CardSearch(userid);		
			if(ptrdata != CARD_NOT_FOUND)
			{						
				ReadCardTemplateInfoFromFlash(ptrdata,&CardExtraData);
			}
			else
			{
				err = EVENT_CARD_NOT_FOUND;
				goto NEW_CMD_SerialTemplate_WithError;					
			}	
			if(CardExtraData.Image_TemplateSD_Flag == 0)
			{
				GetBalanceTemplate();	// NG0004
				if(BalTemplates >= TEMPLATE_OFFSET)
				{	
					CardExtraData.Image_TemplateSD_Flag = 0x01;   // add in Sensor 
					AddCardTemplateInfoToFlash(ptrdata,&CardExtraData);
				}
				else
				{
					CardExtraData.Image_TemplateSD_Flag = 0x02;   // add in SD 									
					AddCardTemplateInfoToFlash(ptrdata,&CardExtraData);
					err = ERROR_MAX_TEMPLATE_SENSOR;
					goto NEW_CMD_SerialTemplate_WithError;					
				}
			}
			if(CardExtraData.Image_TemplateSD_Flag == 0x02)	
			{
				err = ERROR_ALREADY_TEMPLATE_INSD;
				goto NEW_CMD_SerialTemplate_WithError;					
			}	
			else if(CardExtraData.Image_TemplateSD_Flag == 0x01)
			{
				GetBalanceTemplate();	// NG0004
				if(BalTemplates <= TEMPLATE_OFFSET)
				{
					err = ERROR_MAX_TEMPLATE_SENSOR;
					goto NEW_CMD_SerialTemplate_WithError;					
					
				}
			}
			if((cmdver == C_SUB_ENROLL_FINGER_CHECK) || (C_SUB_ENROLL_DUP_FINGER_CHECK == cmdver))
			{ // check if requested finger id gets stored in required location
				if(C_SUB_ENROLL_DUP_FINGER_CHECK == cmdver)
				{
					if((fingerid % 2) == 0)
					{
						err = 3;
						goto NEW_CMD_SerialTemplate_WithError;
					}
				}
				if(CheckBioUserID(userid) == STATUS_BIO_NOT_FOUND)
				{
				//indicated user not present so we have to check if current fingerid to store  is template number 1
					if(fingerid != 1)
					{
						err = 5;
//						MsgPrint(1,fingerid,"finger ID error=");
				      	goto NEW_CMD_SerialTemplate_WithError;
					}
				}
				else
				{
					if(BioCmdSize != (fingerid-1))
					{
	               		err = 6;
//						MsgPrint(1,(unsigned int)BioCmdSize,"finger ID error BioCmdSize=");
//						MsgPrint(1,fingerid,"finger ID error fingerid=");
						goto NEW_CMD_SerialTemplate_WithError;
					}
				}
			}
         	err = EnrollByBioTemplate(userid,tempsize,TemplateBuff);
#ifdef SUPPORT_SUPREMA
            if((err == STATUS_BIO_SUCCESS) || (err == STATUS_BIO_FINGER_FOUND))
#else
            if((err == STATUS_BIO_SUCCESS))
#endif
            {
				if((cmdver == C_SUB_ENROLL_DUP_FINGER) || (cmdver == C_SUB_ENROLL_DUP_FINGER_CHECK))
				{
               	//we have to re-write same finger again
					err = EnrollByBioTemplate(userid,tempsize,TemplateBuff);
#ifdef SUPPORT_SUPREMA
            		if((err == STATUS_BIO_SUCCESS) || (err == STATUS_BIO_FINGER_FOUND))
#else
            		if((err == STATUS_BIO_SUCCESS))
#endif
	              		break;
					else
						err = 4;
				}
				break;
			}
			else
				goto NEW_CMD_HandleSerialTemplate;
//====================================================================================================================================
		case 20:			// Read User ID and fingers from module
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);                				// Card number
			if(CheckBioUserID(userid) == STATUS_BIO_NOT_FOUND)
				goto NEW_CMD_HandleSerialTemplate;
			else
			{
				fingerid = (unsigned char)BioCmdSize;
				TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(fingerid,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return(0);
            }
//====================================================================================================================================
		case 21:			// Delete User ID and its template
			if(GetDataByPosition(bufptr,buffer,3) == NULL)   		//shree 23Sep
				goto NEW_CMD_HandleSerialTemplate;
			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);                				// Card number
			if(DeleteBioUserID(userid) == STATUS_BIO_NOT_FOUND)
				goto NEW_CMD_HandleSerialTemplate;
			else
			{
				fingerid = (unsigned char)BioCmdSize;
				TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
				TransmitCharToX(',',port);
				SendDecimalLongToX(userid,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return(0);
			}
			
		case 22:     // Delete all template from user 
			if(DeleteAllBioTemplate() == STATUS_BIO_SUCCESS)
			{
				fingerid = (unsigned char)BioCmdSize;
				TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
				TransmitCharToX(',',port);
				SendDecimalLongToX(userid,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return(0);
			}
			else
			{
				goto NEW_CMD_HandleSerialTemplate;				
			}			
//====================================================================================================================================
// 		case 10:	    // This is just for testing purpose
// 			if(GetDataByPosition(bufptr,buffer,3) == NULL)
// 				goto NEW_CMD_HandleSerialTemplate;
// 			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
// 			err = EnrollByBioTemplate(userid,0x180,TemplateBuff);
// 			break;
//====================================================================================================================================
		case 100:      // Write system parameter  $1lx,100,sysparano,sysparavalue,chksum,enter
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			ptrdata = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			if(WriteSystemParameter(ptrdata,atoi((char *)bufptr)) != 0)
				goto NEW_CMD_HandleSerialTemplate;
			break;
//====================================================================================================================================
		case 101:		// Read system parameter  $1lx,101,syspara,chksum,enter
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			ptrdata = atoi((char *)bufptr);
			if(ReadBioSystemParameter(ptrdata&0xFF)==0)
			{
//				printf("PARA Value %d \n",BioCmdSize);
				TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
				TransmitCharToX(',',port);
				SendDecimalIntToX((unsigned short)BioCmdSize,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return(0);
			}
			else
				goto NEW_CMD_HandleSerialTemplate;
//====================================================================================================================================
		case C_NEW_SUB_SAVE_SYS_PARA_EEPROM:   // Store System parameter to eeprom  $1lx,105,chksum,enter
			if(SaveBioSystemParameter() != 0)
			{
				err = 3;
				goto NEW_CMD_SerialTemplate_WithError;
			}
			break;
//====================================================================================================================================
		case C_NEW_SYSTEM_BUSY:
			CancelBioCommand();
			F_BIO_COMM = CLR;
			DisplaySensorBusyMessage();
			MakeSound(SOUND_SYS_ERROR);
			IdleKeyCounter = 0;
			break;
//====================================================================================================================================
		case C_NEW_SYSTEM_NORMAL:
			MakeSound(SOUND_SYS_ERROR);
			DisplayMode = MODE_WAIT_FOR_CARD;
			HandleAllModeEvents(FUNCTION_KEY);
			F_KeyIdleTime = CLR;
			break;
//====================================================================================================================================
		case C_NEW_SUB_VERIFY_TEMP:
// following is used to test verify template by scan and we have to use read template before this command
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);                				// Card number
			if(GetDataByPosition(bufptr,buffer,4) == NULL)   	// finger ID
				goto NEW_CMD_HandleSerialTemplate;
			fingerid = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,5) == NULL) // Template size
				goto NEW_CMD_HandleSerialTemplate;
			tempsize = atoi((char *)bufptr);
//			VerifyBioTemplateFromHost(tempsize,1,TemplateBuff[0]);
			VerifyFingerCardID = userid;
//			HandleUserHostVerify(INITIALISE_EVENT);
			break;
//====================================================================================================================================
		case C_NEW_SUB_VERIFY_TEMP_SMART:
// following is used to test verify template by scan and we have to use read template before this command
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);                				// Card number
			if(GetDataByPosition(bufptr,buffer,4) == NULL)   	// finger ID
				goto NEW_CMD_HandleSerialTemplate;
			fingerid = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,5) == NULL) // Template size
				goto NEW_CMD_HandleSerialTemplate;
			tempsize = atoi((char *)bufptr);
//			VerifyBioTemplateFromHost(tempsize,1,(char (*)[MAX_BIO_TEMPLATE_SIZE])BufferTemp[0]);
			VerifyFingerCardID = userid;
//			HandleUserHostVerify(INITIALISE_EVENT);
			break;
//====================================================================================================================================
		case C_NEW_SUB_VERIFY_TEMP_PC:
// following is used to test verify template by scan and we have to use read template before this command
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerialTemplate;
			userid = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);                				// Card number
			if(GetDataByPosition(bufptr,buffer,4) == NULL)   	// finger ID
				goto NEW_CMD_HandleSerialTemplate;
			fingerid = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,5) == NULL) // Template size
				goto NEW_CMD_HandleSerialTemplate;
			tempsize = atoi((char *)bufptr);
//			memset(TemplateBuff,0,sizeof(TemplateBuff));
//			if(GetHexStrByPosition((unsigned char *)BufferTemp[0],buffer,6) != 0) // Template
//				goto NEW_CMD_HandleSerialTemplate;
//			memcpy(BufferTemp[1],TemplateBuff,sizeof(TemplateBuff));
//			VerifyBioTemplateFromHost(tempsize,2,BufferTemp);   //
//			VerifyFingerCardID = userid;
//			HandleUserHostVerify(INITIALISE_EVENT);
			break;
//====================================================================================================================================
		default:
			goto NEW_CMD_HandleSerialTemplate;

	}
	TransmitCharToX(C_NEW_FINGER_TEMPLATE,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	if((C_NEW_SUB_VERIFY_TEMP_PC == cmdver) || (C_NEW_SUB_VERIFY_TEMP == cmdver))
		return(C_NEW_SUB_VERIFY_TEMP);
	return(0);

NEW_CMD_HandleSerialTemplate:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	TransmitCharToX('2',port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return(0);

NEW_CMD_SerialTemplate_WithError:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(err,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return(0);
#else
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(err,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return(0);
#endif
}

//#ifdef BIO_METRIC
//---------------------------------------------------------------------------------
/*** BeginHeader GetHexStrByPosition*/
unsigned char GetHexStrByPosition(unsigned char *chrstr,unsigned char *src, unsigned char pos);
/*** EndHeader */
unsigned char GetHexStrByPosition(unsigned char *chrstr,unsigned char  *src, unsigned char pos)
{
	unsigned int i,ptr;
	i=0;
	pos--;
	while(1)
	{
		if(src[i] == '\0')
			return(1);
		if(src[i] == ',')
		{
      	pos--;
			if(pos ==0)
				break;
		}
		i++;
		if(i > MAX_SERIAL_BUFFER)
			return(1);
	}
	i++;
	for(ptr=0;ptr<512+3;ptr++)		 //MAX_BIO_TEMPLATE_SIZE
	{
		if((src[i]=='\0') ||(src[i]==',')||(src[i]=='\n')||(src[i]=='\r'))
			break;
		chrstr[ptr]= AsciiToHex(src[i]);
      i++;
		if((src[i]=='\0') ||(src[i]==',')||(src[i]=='\n')||(src[i]=='\r'))
			break;
		chrstr[ptr]= (chrstr[ptr]*0x10) + AsciiToHex(src[i]);
		i++;
	}
	chrstr[ptr]='\0';
	return(0);
}
//#endif

//---------------------------------------------------------------------------------
/*** BeginHeader HandleNewSearchCard*/
unsigned char HandleNewSearchCard( unsigned char *buffer,unsigned char port);
/*** EndHeader */
unsigned char HandleNewSearchCard( unsigned char *buffer,unsigned char port)
{
BYTE cmdver,err;
BYTE fingerid,name[17];
struct CARD_DATA empdata;
CARDNO_DATA_STORAGE_TYPE cardno;
#ifdef EN_CARD_EXP_DATE
	struct tm tdate; 
	time_t time;  
#endif
int index,maxcards,index2,index3;
unsigned int totalcardsread,noofcards;
   		err =2;
		//TransmitReplyStartToX(port);//ARMD0217
		if(GetDataByPosition(bufptr,buffer,2) == NULL)
	   	{
		    TransmitReplyStartToX(port);
            goto NEW_CMD_HandleNewSearchCardError;
        }
         cmdver = (unsigned char) atoi((char *)bufptr);

		 if(cmdver!=22)	//ARMD0217
		 TransmitReplyStartToX(port);

         switch(cmdver)
         {

      		case 1:			// Read card By index  $1S,index,chksum,enter
//            DisplaySensorBusyMessage();
	   			if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
            	if(GetCardByIndexNo(index,&empdata) == 0)
               	{
#ifdef BIO_METRIC
		 			if(CheckBioUserID(empdata.CardNo) == STATUS_BIO_NOT_FOUND)
						fingerid = (unsigned char) 0;
            		else
	                  	fingerid = (unsigned char) BioCmdSize;
#else
                    fingerid = 0;
#endif
	            	TransmitCharToX(C_NEW_SEARCH_CARD,port);
   	          		TransmitCharToX(',',port);
					SendDecimalLongToX(empdata.CardNo,port);
	               	TransmitCharToX(',',port);
	               	SendDecimalToPC3CharToX(fingerid,port);
	               	TransmitCharToX(',',port);
	               	TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
	               	TransmitCharToX(TERMINATOR,port);
		            return(0);
      		   	}
	            else
	            {
	               err =3;
	               goto NEW_CMD_HandleNewSearchCardError;
	            }
//	            break;
				case 2 :
	//Read card database $1lS,2,Card No,Chksum,ENT 					 ex.$1lS,2,12345,29,
	//response  #1S,No. of cards added,card no,PIN no,APB,TZD1,TZD2, 
	// ex.#1S,50161,0000012345,01111,001,001,255,001,000,001,,0000000000,000,5D,
 
	      		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	            index2 = SearchDisplayCard(cardno,&empdata);
               	if((int)index2 != CARD_NOT_FOUND)
				{
GOTOSendSearchCardData:
#ifdef BIO_METRIC
					if(CheckBioUserID(empdata.CardNo) == STATUS_BIO_NOT_FOUND)
						fingerid = (unsigned char) 0;
            		else
	                  	fingerid = (unsigned char) BioCmdSize;
#else
                     fingerid = 0;
#endif
#ifdef EN_CARD_EXP_DATE
						if(empdata.ExpDT !=0)
						{
							time = empdata.ExpDT;
							gmtime_r(&time,&tdate);		//PANKAJXX
						}
#endif
	               	index2 = index2+1;   //card index starts from 1 to max card ...
               		TransmitCharToX(C_NEW_SEARCH_CARD,port);
	               	TransmitCharToX(',',port);
               		SendCardDataToPC(index2,empdata,port);
	         		ReadCardNameFromFlash(index2-1,name);
					TransmitStrToX(name,port);
	               	TransmitCharToX(',',port);
#ifdef EN_CARD_EXP_DATE
				  	if(empdata.ExpDT !=0)
                  	{
	                  SendDecimalToPC(tdate.tm_hour);
	                  SendDecimalToPC(tdate.tm_min);
	                  SendDecimalToPC(tdate.tm_mday);
	                  SendDecimalToPC(tdate.tm_mon);
	                  SendDecimalToPC(tdate.tm_year-YEAR_BASE_VALUE);
 //PANKAJXX
					}
                  	else
#endif
                  	{
	                 	SendDecimalToPC(0);
	                  	SendDecimalToPC(0);
	                  	SendDecimalToPC(0);
	                  	SendDecimalToPC(0);
	                  	SendDecimalToPC(0);
                  	}
	               	TransmitCharToX(',',port);
	               	SendDecimalToPC3CharToX(fingerid,port);
	               	TransmitCharToX(',',port);
					TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
                  	return(0);
               	}
               	break;
           case 3:
	      		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		        	goto NEW_CMD_HandleNewSearchCardError;
          		cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	            index2 = CardSearch(cardno);
               	if((int)index2!=CARD_NOT_FOUND)
				{
	               	index2 = index2+1;   //card index starts from 1 to max card ...
               		TransmitCharToX(C_NEW_SEARCH_CARD,port);
   	            	TransmitCharToX(',',port);
		#ifdef EXTENDED_USER
					SendDecimalLongToX6digit(index2,port);
		#else			
					SendDecimalIntToX(index2,port);
		#endif
	               	TransmitCharToX(',',port);
					TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
                  	return(0);
               	}
            	break;
			case 4:
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
					goto NEW_CMD_HandleNewSearchCardError;
				cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
				if(cardno==0)
				{
					err = 7;
					goto NEW_CMD_HandleNewSearchCardError;
				}
				index2 = SpecialCardSearch(cardno);
				if((int)index2 != CARD_NOT_FOUND)
				{
	            	index2 = index2+1;   //card index starts from 1 to max card ...
					TransmitCharToX(C_NEW_SEARCH_CARD,port);
					TransmitCharToX(',',port);
		#ifdef EXTENDED_USER
					SendDecimalLongToX6digit(index2,port);
		#else			
					SendDecimalIntToX(index2,port);
		#endif
					TransmitCharToX(',',port);
					SendDecimalLongToX(cardno,port);   // card no
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(SpecialCardData.CardType,port);		//Special card type
					TransmitCharToX(',',port);
					SendDecimalIntToX(SpecialCardData.CardInfo,port);    // Special card info
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(SpecialCardData.ExtraInfo,port);		//Special card Extra info
					TransmitCharToX(',',port);
					TransmitCheckSumX(port);
					TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
					return(0);
				}
				if(index2 == CARD_NOT_FOUND)
					err = 7;
			break;
			case 5 :
	      		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	            index2 = SearchCardFromFlash(cardno,&empdata);
             	if((int)index2!=CARD_NOT_FOUND)
				{
	            	index2 = index2+1;   //card index starts from 1 to max card ...
               		TransmitCharToX(C_NEW_SEARCH_CARD,port);
	               	TransmitCharToX(',',port);
               		SendCardDataToPC(index2,empdata,port);
					TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
                  	return(0);
              	}
            	break;
            case 6: // Get card by location from RAM
            	if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index = atoi((char *)bufptr);
               	maxcards = GetCardByLocation(index,&empdata);
            	if( (maxcards != 0xFFFFFFFF)&&(maxcards != 0xFFFFFFFE) )
               	{
	               	TransmitCharToX(C_NEW_SEARCH_CARD,port);
   	            	TransmitCharToX(',',port);
					SendCardDataToPC(index,empdata,port);
	               	TransmitCharToX(',',port);
	               	TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
	               	TransmitCharToX(TERMINATOR,port);
		            return(0);
      		   	}
	            else
	            {
               		if(maxcards==0xFFFFFFFF)
		               	err =3;
                  	else
		               err =4;
	            }
            break;
			case 7: //it gives card at perticular location, if card is not present then it retuns error.
//$1lS,7,Location No,Chksum,ENT   		ex.$1lS,7,50161,2E,

//#1S,Card Index,card no,PIN,APB,TZD1,TZD2,Holiday,Card Type,Message ID,Name,Expiry Date,No of templates,Chksum,ENT
//ex. #1S,50161,0000012345,01111,001,001,255,001,000,001,,0000000000,000,5D,
            	if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index = atoi((char *)bufptr);
               	if(index ==0)
               	{
               		err = 5;
                  	break;
               	}
               	index--;
               	index2 = GetCardByLocation(index,&empdata);
				if(index2==0xFFFFFFFF)
               		err=3;
               	else if(index2==0xFFFFFFFE)
               		err=4;
				else
               		goto GOTOSendSearchCardData;
            break;
		    
			case 8:		//SPL card Search by Index no		//281210-2
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
					goto NEW_CMD_HandleNewSearchCardError;
				index2 = atoi((char*)bufptr);
				index2 = SplCardSearchByIndex(index2-1);
				if((int)index2!=CARD_NOT_FOUND)
				{
					index2 = index2+1;
					TransmitCharToX(C_NEW_SEARCH_CARD,port);
					TransmitCharToX(',',port);
		#ifdef EXTENDED_USER
					SendDecimalLongToX6digit(index2,port);
		#else			
					SendDecimalIntToX(index2,port);
		#endif
					TransmitCharToX(',',port);
					SendDecimalLongToX(SpecialCardData.CardNo,port);   // card no
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(SpecialCardData.CardType,port);		//Special card type
					TransmitCharToX(',',port);
					SendDecimalIntToX(SpecialCardData.CardInfo,port);    // Special card info
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(SpecialCardData.ExtraInfo,port);		//Special card Extra info
					TransmitCharToX(',',port);
					TransmitCheckSumX(port);
					TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
					return(0);
				}
			    if(index2 == CARD_NOT_FOUND)
		        	err = 7;
	            break;
			
			
			case 10:	// Read max Nos of cards 

	//Read no of cards added command : $1lS,10,Chksum,ENT   ex. $1lS,10,2B,
	//reply: #1S,No of Card Added,Chksum,ENT   ex. #1S,00006,77,
//	index = GetCardByIndexNo(0xFFFF,&empdata);
	       		TransmitCharToX(C_NEW_SEARCH_CARD,port);
   	            TransmitCharToX(',',port);
		#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(TotalCards,port);
		#else			
				SendDecimalIntToX(TotalCards,port);
		#endif
				TransmitCharToX(',',port);
	            TransmitCheckSumX(port);
	            TransmitCharToX(',',port);
	            TransmitCharToX(TERMINATOR,port);
		        return(0);
//            	break;
			case 11:
//					TotalCards = GetCardByIndexNo(0xFFFFFF,&empdata);
					TotalCards = GetTotalNumberOfCards();   //ARMD0191
	               	TransmitCharToX(C_NEW_SEARCH_CARD,port);
   	            	TransmitCharToX(',',port);
		#ifdef EXTENDED_USER
					SendDecimalLongToX6digit(TotalCards,port);
		#else			
					SendDecimalIntToX(TotalCards,port);
		#endif
	               	TransmitCharToX(',',port);
	               	TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
	               	TransmitCharToX(TERMINATOR,port);
		            return(0);
//            break;
			case 20:			// Read Cards from x index to Y index
				//maxcards = GetCardByIndexNo(0xFFFFFF,&empdata);				// Gex max no of cards
				maxcards = GetTotalNumberOfCards();			   //ARMD0191
				if(maxcards == 0)
               	{
               		err =4;
					goto NEW_CMD_HandleNewSearchCardError;
               	}
	      		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);

	      		if(GetDataByPosition(bufptr,buffer,4) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index2 = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
				if(index>index2)
               	{
               		err =2;
					goto NEW_CMD_HandleNewSearchCardError;
               	}
               	if(index2>maxcards)
               		index2 =maxcards;
               	if((index2 - index) >50 )
				{
            		err =2;
					goto NEW_CMD_HandleNewSearchCardError;
				}
	            TransmitCharToX(C_NEW_SEARCH_CARD,port);
               	while(index <= index2)
               	{
	               if(GetCardByIndexNo(index,&empdata) == 0)
	               {
/*	                   if( CheckBioUserID(empdata.CardNo) == STATUS_BIO_NOT_FOUND )
	                     fingerid = (unsigned char) 0;
	                  else
	                     fingerid = (unsigned char) BioCmdSize;
*/
	                	TransmitCharToX(',',port);
	                  	SendDecimalLongToX(empdata.CardNo,port);
                     	index++;
	               }
                  	else
		            	break;
               	}
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
               	return(0);
			case 21:			// Read Cards from x index to Y index
//					maxcards = GetCardByIndexNo(0xFFFF,&empdata);				// Gex max no of cards
	      		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	      		if(GetDataByPosition(bufptr,buffer,4) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index2 = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
				if(index>index2)
               	{
               		err =2;
					goto NEW_CMD_HandleNewSearchCardError;
               	}
               	if((index2 - index) > 50)
				{
            		err =2;
					goto NEW_CMD_HandleNewSearchCardError;
				}
	           	TransmitCharToX(C_NEW_SEARCH_CARD,port);
               	while(index <= index2)
               	{
	            	if(GetCardByIndexNo(index,&empdata) == 0)
	               	{
/*	                   if( CheckBioUserID(empdata.CardNo) == STATUS_BIO_NOT_FOUND )
	                     fingerid = (unsigned char) 0;
	                  else
	                     fingerid = (unsigned char) BioCmdSize;
*/
	                  TransmitCharToX(',',port);
	                  SendDecimalLongToX(empdata.CardNo,port);
                     index++;
	               	}
                  	else
		            	break;
               	}
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
               	return(0);

			case 22: 	// Dump card by location
						//$1lS,22,dumpindex,noofcards,
	      		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		index = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	      		if(GetDataByPosition(bufptr,buffer,4) ==NULL)
		         	goto NEW_CMD_HandleNewSearchCardError;
          		maxcards = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);				
				while(maxcards!=0)
				{
					index2 = GetCardByLocation(index++,&empdata);
					if(index2==0xFFFFFFFF)
						break;
					if(index2 != 0xFFFFFFFE)
					{
						TransmitReplyStartToX(port);
	      				TransmitCharToX(',',port);
						TransmitCharToX('S',port);
						TransmitCharToX(',',port);
						TransmitCharToX('2',port);
						TransmitCharToX('2',port);
	      				TransmitCharToX(',',port);
						SendCardDataToPC(index,empdata,port);
						TransmitCheckSumX(port);
						maxcards--;
					}					
					TransmitCharToX(TERMINATOR,port);
				}
				break;
			
			   	case 23:
			   	case 24:	// $1lS,24,CardNo,-> Respond extra card data Structure element for that card  
					if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         		goto NEW_CMD_HandleNewSearchCardError;
          			cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	            	index3 = index2 = SearchDisplayCard(cardno,&empdata);
               		if((int)index2 != CARD_NOT_FOUND)
					{
#ifdef EN_CARD_EXP_DATE
						if(empdata.ExpDT !=0)
						{
							time = empdata.ExpDT;
							gmtime_r(&time,&tdate);		//PANKAJXX
						}
#endif
	               		index2 = index2+1;   //card index starts from 1 to max card ...
               			TransmitCharToX(C_NEW_SEARCH_CARD,port);
	               		TransmitCharToX(',',port);
               			SendCardDataToPC(index2,empdata,port);

						ReadCardTemplateInfoFromFlash(index3,&tExtInfo);	
						TransmitNStrToX(tExtInfo.Name,CARD_NAME_BYTES,port);  // Name //NG0013
						TransmitCharToX(',',port);														
#ifdef EN_CARD_EXP_DATE
				  		if(empdata.ExpDT !=0)
                  		{
			            	SendDecimalToX(tdate.tm_hour,port);
			                SendDecimalToX(tdate.tm_min,port);
			                SendDecimalToX(tdate.tm_mday,port);
			                SendDecimalToX(tdate.tm_mon,port);
			                SendDecimalToX(tdate.tm_year-YEAR_BASE_VALUE,port);
						}
                  		else
#endif
                  		{
	                 		SendDecimalToX(0,port);
	                  		SendDecimalToX(0,port);
	                  		SendDecimalToX(0,port);
	                  		SendDecimalToX(0,port);
	                  		SendDecimalToX(0,port);
                  		}
	               		TransmitCharToX(',',port);
						
					
						if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 1)	// NG0018
						{
#ifdef BIO_METRIC
							if(CheckBioUserID(empdata.CardNo) == STATUS_BIO_NOT_FOUND)
							fingerid = (unsigned char) 0;
							else
	            	      	fingerid = (unsigned char) BioCmdSize;
#else					
							fingerid = 0;
#endif
						}	
						else if((tExtInfo.Image_TemplateSD_Flag & 0x0F) == 2) // NG0018
						{
							{
								char i;
								fingerid = 0;
								for(i=0;i<=7;i++)
								{
									fingerid += (tExtInfo.TemplateData>>i) & 0x01;					
								}
							}
						}
						else
						{
							fingerid = 0;
						}							
							
						SendNewCardDataToPC(empdata,fingerid,port);	 //add new command data here in this function							
						if(cmdver == 24)
						{
								if(tExtInfo.JoiningDate !=0)	// Joining Date
								{
									time = tExtInfo.JoiningDate;
									gmtime_r(&time,&tdate);	
									SendDecimalToX(tdate.tm_hour,port);
									SendDecimalToX(tdate.tm_min,port);
									SendDecimalToX(tdate.tm_mday,port);
									SendDecimalToX(tdate.tm_mon,port);
									SendDecimalToX(tdate.tm_year-YEAR_BASE_VALUE,port);
								}
								else
								{
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);	
								}
								TransmitCharToX(',',port);								
								if(tExtInfo.BirthDate !=0)	// Birth Date
								{
//									time = tExtInfo.BirthDate;
//									gmtime_r(&time,&tdate);	
// 									SendDecimalToPC(tdate.tm_hour);
// 									SendDecimalToPC(tdate.tm_min);
// 									SendDecimalToPC(tdate.tm_mday);
// 									SendDecimalToPC(tdate.tm_mon);
									SendDecimalToX(tExtInfo.BirthDate,port);
									TransmitCharToX(',',port);								
									SendDecimalToX(tExtInfo.BirthMonth,port);									
//									SendDecimalToPC(tdate.tm_year-YEAR_BASE_VALUE);
								}
								else
								{
									SendDecimalToX(0,port);
									TransmitCharToX(',',port);								//NG0006
									SendDecimalToX(0,port);
// 									SendDecimalToPC(0);
// 									SendDecimalToPC(0);
// 									SendDecimalToPC(0);	
								}
								TransmitCharToX(',',port);								
								if(tExtInfo.AccessDate !=0) 	//Access Date
								{
									time = tExtInfo.AccessDate;
									gmtime_r(&time,&tdate);	
									SendDecimalToX(tdate.tm_hour,port);
									SendDecimalToX(tdate.tm_min,port);
									SendDecimalToX(tdate.tm_mday,port);
									SendDecimalToX(tdate.tm_mon,port);
									SendDecimalToX(tdate.tm_year-YEAR_BASE_VALUE,port);
								}
								else
								{
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);
									SendDecimalToX(0,port);	
								}
								TransmitCharToX(',',port);	
								SendDecimalToPC3CharToX(tExtInfo.TemplateData,port);//  
								TransmitCharToX(',',port);	

								SendDecimalToPC3CharToX(tExtInfo.Image_TemplateSD_Flag,port);//  
								
								TransmitCharToX(',',port);	
							
						}
						TransmitCheckSumX(port);
	               		TransmitCharToX(',',port);
						TransmitCharToX(TERMINATOR,port);
                  		return(0);
               		}
               	break;
					
			case 97: //bulk card read		$1lS,97,99999,1,0,	//$1lS,97,no of cards,startcard number,location,
			   if(GetDataByPosition(bufptr,buffer,3) == NULL)
			      goto NEW_CMD_HandleNewSearchCardError;
			   	noofcards = atoi((char *)bufptr);	//total cards
			   	if(GetDataByPosition(bufptr,buffer,4) == NULL)
			      goto NEW_CMD_HandleNewSearchCardError;
		      	Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);//card number
			   	if(GetDataByPosition(bufptr,buffer,5) == NULL)
			      goto NEW_CMD_HandleNewSearchCardError;
		   		totalcardsread = TestCardMgmt(noofcards,Carddata.CardNo,atoi((char *)bufptr),1,port);	
		#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(totalcardsread,port);
		#else			
			   	SendDecimalIntToX(totalcardsread,port);
		#endif
			   	TransmitCharToX(',',port);
			   	TransmitCheckSumX(port);
			   	TransmitCharToX(',',port);
			   	TransmitCharToX(TERMINATOR,port);
				return(0);

            	default:
            		err =2;
               	goto NEW_CMD_HandleNewSearchCardError;
//               break;
         }
NEW_CMD_HandleNewSearchCardError:
	      		TransmitCharToX('e',port);
	      		TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(err,port);
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);

return(0);
}

/*** BeginHeader DisplaySensorBusyMessage*/
void DisplaySensorBusyMessage(void);
/*** EndHeader */
void DisplaySensorBusyMessage(void)
{
#ifdef	BIO_METRIC
   DisplayMode = MODE_BIOMETRIC_DOWNLOAD;
   F_KeyIdleTime = CLR;
   IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
//   WelMessageType = WEL_TEMPLATE_READ_WRITE;
//   DisplayWelcomeMessage();
#endif
}
//=====================New System parameter setting============
/*** BeginHeader NSeriesPhase2ParaSetting*/
void NSeriesPhase2ParaSetting(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void NSeriesPhase2ParaSetting(unsigned char *buffer,unsigned char port)
{
unsigned char errno,cmdver,temp1,len;

	errno = 2;
	TransmitReplyStartToX(port);
 	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
	   goto C_SET_GAME_PARA_ERROR;
	}
    temp1 = atoi((char *)bufptr);

   if(temp1 > MAX_OTHER_SYS_PARA)
   {
      if((temp1 >= 100) && (temp1 <= (100+MAX_OTHER_SYS_PARA)))
      {
         temp1 = temp1 - 100;
         TransmitCharToX(C_NEW_N_SRS_SYS_INFO_STRUCT,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(temp1,port);
         TransmitCharToX(',',port);
         switch(OtherSysPara[temp1].Type)
         {
				case D_BIN:
            case D_CHAR:
            	SendDecimalToPC3CharToX(*OtherSysPara[temp1].VChar,port);
               TransmitCharToX(',',port);
               break;
            case D_INT:
            	SendDecimalIntToX(*OtherSysPara[temp1].VInt,port);
               TransmitCharToX(',',port);
               break;
            case D_LONG:
               SendDecimalLongToX(*OtherSysPara[temp1].VLong,port);
               TransmitCharToX(',',port);
               break;
            case D_STR:
               TransmitNStrToX(OtherSysPara[temp1].VStr,OtherSysPara[temp1].Len,port);
               TransmitCharToX(',',port);
               break;
            case D_ARRAY_CHAR:
               for(cmdver=0;cmdver<OtherSysPara[temp1].Len;cmdver++)
               {
                  SendDecimalToPC3CharToX(OtherSysPara[temp1].VStr[cmdver],port);
                  TransmitCharToX(',',port);
               }
               break;
            case D_ARRAY_INT:
               for(cmdver=0;cmdver<OtherSysPara[temp1].Len;cmdver++)
               {
                  SendDecimalIntToX(*(((unsigned int *)OtherSysPara[temp1].VStr) + cmdver),port);
                  TransmitCharToX(',',port);
               }
               break;
         }
         TransmitCheckSumX(port);
         TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
         return;
      }
      else
         errno = 3;
      goto C_SET_GAME_PARA_ERROR;
   }
   else
   {
	   switch(OtherSysPara[temp1].Type)
	   {
			case D_BIN:
	   		case D_CHAR:
	      	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         {
	            goto C_SET_GAME_PARA_ERROR;
	         }
	         *OtherSysPara[temp1].VChar = atoi((char *)bufptr) & 0xff;
	         break;
	
	      	case D_INT:
	      	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         {
	            goto C_SET_GAME_PARA_ERROR;
	         }
	         *OtherSysPara[temp1].VInt = atoi((char *)bufptr);
	         break;
	
			case D_LONG:
	      	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         {
	            goto C_SET_GAME_PARA_ERROR;
	         }
	         *OtherSysPara[temp1].VLong = atoi((char *)bufptr);
	         break;
	      case D_STR:
	      	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         {
	            goto C_SET_GAME_PARA_ERROR;
	         }
	         len = strlen((char *)bufptr);
	         if(OtherSysPara[temp1].Len <= len)
	            len = OtherSysPara[temp1].Len;
	         strncpy((char *)OtherSysPara[temp1].VStr,(char *)bufptr,len);
	         OtherSysPara[temp1].VStr[len] = '\0';
	         break;
	      case D_ARRAY_CHAR:
		      if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      {
		         goto C_SET_GAME_PARA_ERROR;
		      }
		      cmdver =  atoi((char *)bufptr);
		      if((cmdver>OtherSysPara[temp1].Len) || (cmdver == 0))
		         goto C_SET_GAME_PARA_ERROR;
		      cmdver--;
		      if(GetDataByPosition(bufptr,buffer,4) == NULL)
		         goto C_SET_GAME_PARA_ERROR;
		      OtherSysPara[temp1].VStr[cmdver]= atoi((char *)bufptr);
		      break;
	      case D_ARRAY_INT:
	         if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         {
	            goto C_SET_GAME_PARA_ERROR;
	         }
	         cmdver =  atoi((char *)bufptr);
	         if((cmdver>OtherSysPara[temp1].Len) || (cmdver == 0))
	            goto C_SET_GAME_PARA_ERROR;
	         cmdver--;
	         if(GetDataByPosition(bufptr,buffer,4) == NULL)
	            goto C_SET_GAME_PARA_ERROR;
		      *(((unsigned int *)OtherSysPara[temp1].VStr) + cmdver) = atoi((char *)bufptr);
		      break;
	   	default:
	C_SET_GAME_PARA_ERROR:
	         TransmitCharToX('e',port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(errno,port);
	         TransmitCharToX(',',port);
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
	         return;
	   }
   }
   TransmitCharToX(C_NEW_N_SRS_SYS_INFO_STRUCT,port);
   TransmitCharToX(',',port);
   TransmitCheckSumX(port);
   TransmitCharToX(',',port);
   TransmitCharToX(TERMINATOR,port);
   WriteDoorInfoToFlash();
   WriteSysInfoToFlash();
}
//======================================================================================

/*** BeginHeader HandleSystemParaSetting*/
void HandleSystemParaSetting(unsigned char *buffer,unsigned char port) ;
/*** EndHeader */
void HandleSystemParaSetting(unsigned char *buffer,unsigned char port)
{
unsigned char errno,cmdver,temp1,len,paramstart,noofparam,i,setparano;
extern unsigned char DisplayTempBuffer[50];
unsigned char nptr[100]={0};
//unsigned int vdata;
	errno = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto C_SET_GAME_PARA_ERROR;
	temp1 = atoi((char *)bufptr);
	if(temp1 == READ_ALL_PARA)	   //$1lu,200,paramstart,noofparam,		  //Shivraj
	{
		TransmitCharToX(C_NEW_SYSTEM_INFO_STRUCT,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(temp1,port);
		TransmitCharToX(',',port);
	
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto C_SET_GAME_PARA_ERROR;
		paramstart = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,4) == NULL)
			goto C_SET_GAME_PARA_ERROR;
		noofparam = atoi((char *)bufptr);		
		if((noofparam <= MAX_SET_SYS_PARA)&&(noofparam>=1)&&(paramstart <= MAX_SET_SYS_PARA-1))	//(paramstart>=0)  not required and to avoid warning
		{
			SendDecimalToPC3CharToX((noofparam-paramstart)+1,port);
			TransmitCharToX(',',port);
			for(i=paramstart;i<=noofparam;i++)
			{
				switch(SetSysPara[i].Type)
				{
					case D_BIN:
					case D_CHAR:
						SendDecimalToPC3CharToX(*SetSysPara[i].VChar,port) ;
						TransmitCharToX(',',port);
						break;
					case D_INT:
						SendDecimalIntToX(*SetSysPara[i].VInt,port);
						TransmitCharToX(',',port);
						break;
					case D_LONG:
						SendDecimalLongToX(*SetSysPara[i].VLong,port);
						TransmitCharToX(',',port);
	//					printf(" Long %d %d \n",*SetSysPara[temp1].VLong/100000 , *SetSysPara[temp1].VLong%100000);
						break;
					case D_STR:
						TransmitNStrToX(SetSysPara[i].VStr,SetSysPara[i].Len,port);
						TransmitCharToX(',',port);
						break;
					case D_ARRAY_CHAR:
						TransmitCharToX('[',port);
						for(cmdver=0;cmdver<SetSysPara[i].Len;cmdver++)
						{
							SendDecimalToPC3CharToX(SetSysPara[i].VStr[cmdver],port) ;
							if(cmdver<((SetSysPara[i].Len)-1))
								TransmitCharToX(':',port);
						}
						TransmitCharToX(']',port);
						TransmitCharToX(',',port);
						break;
					case D_ARRAY_INT:
						TransmitCharToX('[',port);
						for(cmdver=0;cmdver<SetSysPara[i].Len;cmdver++)
						{
							SendDecimalIntToX(*(((unsigned int *)SetSysPara[i].VStr) + cmdver),port);
							if(cmdver<((SetSysPara[i].Len)-1))
								TransmitCharToX(':',port);
						}
						TransmitCharToX(']',port);
						TransmitCharToX(',',port);
						break;
				}
			}
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		}
		else
		{	
			SendDecimalToPC3CharToX(MAX_SET_SYS_PARA,port);
			TransmitCharToX(',',port);
			errno = 3;
			goto C_SET_GAME_PARA_ERROR;
		}
	}	
	if(temp1 == WRITE_ALL_PARA)	   //$1lu,201,setparano,paraData,		   //Shivraj
	{
		TransmitCharToX(C_NEW_SYSTEM_INFO_STRUCT,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(temp1,port);
		TransmitCharToX(',',port);

		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto C_SET_GAME_PARA_ERROR;
		setparano = atoi((char *)bufptr);

		switch(SetSysPara[setparano].Type)
		{//write parameter
			case D_BIN:
			case D_CHAR:
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto C_SET_GAME_PARA_ERROR;
				*SetSysPara[setparano].VChar = atoi((char*)bufptr) &0xff;
				break;
			case D_INT:
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto C_SET_GAME_PARA_ERROR;
				*SetSysPara[setparano].VInt = atoi((char*)bufptr);
				if( setparano == 5 )//port setting
				{
					InitParameters();
				}
				break;
			case D_LONG:
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto C_SET_GAME_PARA_ERROR;
				*SetSysPara[setparano].VLong = atoi((char*)bufptr);
		//			printf(" Long %d %d \n",*SetSysPara[setparano].VLong/100000 , *SetSysPara[setparano].VLong%100000);
				break;
			case D_STR:
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto C_SET_GAME_PARA_ERROR;
				len = strlen((char*)bufptr);
				if(SetSysPara[setparano].Len <= len)
				len = (unsigned char )SetSysPara[setparano].Len;
				strncpy((char *)SetSysPara[setparano].VStr,(char*)bufptr,len);
				SetSysPara[setparano].VStr[len]=(unsigned char)'\0';
				if(setparano == 1 || setparano == 2 || setparano == 3)//if it is parameter local ip
				{		 //////////////temporary change
					InitNetworkParameter();
				}
				break;
			case D_ARRAY_CHAR:
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto C_SET_GAME_PARA_ERROR;
				len = strlen((char*)bufptr);
				bufptr[len-1]='\0';

				for(i=0;i<SetSysPara[setparano].Len;i++)
				{
					 GetDataByPositionSep(nptr,&bufptr[1],i+1,':');				   	
					 SetSysPara[setparano].VStr[i]= atoi((char*)nptr)&0xFF;
				}
				break;
			case D_ARRAY_INT:
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto C_SET_GAME_PARA_ERROR;
				len = strlen((char*)bufptr);
				bufptr[len-1]='\0';

				for(i=0;i<SetSysPara[setparano].Len;i++)
				{
					 GetDataByPositionSep(nptr,&bufptr[1],i+1,':');				   	
					 *(((unsigned int *)SetSysPara[setparano].VStr) + i) =   atoi((char*)nptr);
				}
				break;
		
			default:
				errno = 3;
			   	goto C_SET_GAME_PARA_ERROR;
			}
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
		TransmitCharToX(TERMINATOR,port);
		WriteDoorInfoToFlash();
		WriteSysInfoToFlash();
		return;
	}
	
	if(temp1 > MAX_SET_SYS_PARA)
	{//read parameter
		if((temp1 >=100) &&(temp1<=100+MAX_SET_SYS_PARA))
		{
			temp1 = temp1-100;
			TransmitCharToX(C_NEW_SYSTEM_INFO_STRUCT,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(temp1,port);
			TransmitCharToX(',',port);
			switch(SetSysPara[temp1].Type)
			{
				case D_BIN:
				case D_CHAR:
					SendDecimalToPC3CharToX(*SetSysPara[temp1].VChar,port) ;
					TransmitCharToX(',',port);
					break;
				case D_INT:
					SendDecimalIntToX(*SetSysPara[temp1].VInt,port);
					TransmitCharToX(',',port);
					break;
				case D_LONG:
					SendDecimalLongToX(*SetSysPara[temp1].VLong,port);
					TransmitCharToX(',',port);
//					printf(" Long %d %d \n",*SetSysPara[temp1].VLong/100000 , *SetSysPara[temp1].VLong%100000);
					break;
				case D_STR:
					TransmitNStrToX(SetSysPara[temp1].VStr,SetSysPara[temp1].Len,port);
					TransmitCharToX(',',port);
					if(temp1 == 1 || temp1 == 2 || temp1 == 3)//if it is parameter local ip
					{
					 	
					}
					break;
				case D_ARRAY_CHAR:
					for(cmdver=0;cmdver<SetSysPara[temp1].Len;cmdver++)
					{
						SendDecimalToPC3CharToX(SetSysPara[temp1].VStr[cmdver],port) ;
						TransmitCharToX(',',port);
					}
					break;
				case D_ARRAY_INT:
					for(cmdver=0;cmdver<SetSysPara[temp1].Len;cmdver++)
					{
						SendDecimalIntToX(*(((unsigned int*)SetSysPara[temp1].VStr) + cmdver),port);
						TransmitCharToX(',',port);
					}	
					break;
			}
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		}
		else
			errno = 3;
		goto C_SET_GAME_PARA_ERROR;
	}
	switch(SetSysPara[temp1].Type)
	{//write parameter
		case D_BIN:
		case D_CHAR:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			*SetSysPara[temp1].VChar = atoi((char*)bufptr) &0xff;
			if(temp1 == 10)
			{
				for(i=0;i<MAX_LOCAL_DOORS;i++)	
					ReaderInfo[i].CntrolrType = atoi((char*)bufptr) &0xff;
				WriteReaderInfoToFlash();		
			}
			if(temp1 == 79)  // need changes for GUI
			{
				if(*SetSysPara[temp1].VChar != 0)		   //ARMD0505
				{
//					L_DisplayROMStr("IN Count:           ",16,ROW_USER_ENTRY);
//					L_DisplayDecimalInteger((WORD)InEmpCount,10,ROW_USER_ENTRY);
//					L_DisplayROMStr("INCnt:     /     ",16,ROW_USER_ENTRY);
				sprintf((char*)DisplayTempBuffer,"INCnt:%05d/%05d",InEmpCount,Doorinfo.OccupancyCount);
				DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);					
//					L_DisplayDecimal4Integer((WORD)InEmpCount,7,ROW_USER_ENTRY);
//					L_DisplayDecimal4Integer((WORD)Doorinfo.OccupancyCount,12,ROW_USER_ENTRY);
				}
			}

			break;
		case D_INT:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			*SetSysPara[temp1].VInt = atoi((char*)bufptr);
//			if( temp1 == 5 )//port setting//ip parameter is only init at reset
//			{
//				InitParameters();
//			}
			break;
		case D_LONG:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			*SetSysPara[temp1].VLong = atoi((char*)bufptr);
//			printf(" Long %d %d \n",*SetSysPara[temp1].VLong/100000 , *SetSysPara[temp1].VLong%100000);
			break;
		case D_STR:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			len = strlen((char*)bufptr);
			if(SetSysPara[temp1].Len <= len)
			len = (unsigned char )SetSysPara[temp1].Len;
			strncpy((char *)SetSysPara[temp1].VStr,(char*)bufptr,len);
			SetSysPara[temp1].VStr[len]=(unsigned char)'\0';
////			if(temp1 == 1 || temp1 == 2 || temp1 == 3)//if it is parameter local ip
////			{		 //////////////temporary change
////				InitNetworkParameter();//ip parameter is only init at reset
////			}
			break;
		case D_ARRAY_CHAR:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			cmdver = atoi((char *)bufptr);
			if((cmdver>SetSysPara[temp1].Len) || (cmdver == 0))
				goto C_SET_GAME_PARA_ERROR;
			cmdver--;
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			SetSysPara[temp1].VStr[cmdver]= atoi((char*)bufptr);
			break;
		case D_ARRAY_INT:
		{
	    	if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto C_SET_GAME_PARA_ERROR;
			cmdver =  atoi((char *)bufptr);
			if((cmdver > SetSysPara[temp1].Len) || (cmdver == 0))
				goto C_SET_GAME_PARA_ERROR;
			cmdver--;
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto C_SET_GAME_PARA_ERROR;		
			*(((unsigned int*)SetSysPara[temp1].VStr) + cmdver) = atoi((char *)bufptr);
//			temp = (unsigned int*)SetSysPara[temp1].VLong;
		}
			break;
	
		default:
C_SET_GAME_PARA_ERROR:
			TransmitCharToX('e',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(errno,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
	}
	TransmitCharToX(C_NEW_SYSTEM_INFO_STRUCT,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	WriteDoorInfoToFlash();
	WriteSysInfoToFlash();
}

///////////////////////////////////////////////////////////////////////////////
/*** BeginHeader HandleSerSmartCard*/
void HandleSerSmartCard(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleSerSmartCard(unsigned char *buffer,unsigned char port)
{
#ifdef SUPPORT_ICLASS_RDR			//FA00100
	unsigned int len; //fileno,
//   unsigned char record;
#endif
#ifdef SMART_CARD
BYTE cmdver,err,key;
#ifndef SUPPORT_ICLASS_RDR
	BYTE databuf[128];
	unsigned int index2;
#endif
//struct CARD_DATA empdata;
unsigned int readerno,sector;
	err = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto NEW_CMD_HandleSerSmartCardError;
	}
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
#ifndef SUPPORT_ICLASS_RDR			//FA00100
		case 1:    // $1ly,1,readerno,key,sector,keystring,chksum,enter
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			     goto NEW_CMD_HandleSerSmartCardError;
          	readerno = atoi((char *)bufptr);
	      	if(GetDataByPosition(bufptr,buffer,4) == NULL)
		         goto NEW_CMD_HandleSerSmartCardError;
            key = atoi((char *)bufptr);
	      	if(GetDataByPosition(bufptr,buffer,5) == NULL)
		         goto NEW_CMD_HandleSerSmartCardError;
            sector = atoi((char *)bufptr);
	      	if(GetDataByPosition(bufptr,buffer,6) == NULL)
		         goto NEW_CMD_HandleSerSmartCardError;
            if(strlen((char *)bufptr) < 12)
		         goto NEW_CMD_HandleSerSmartCardError;
            SCReaderNo = readerno;
			if(SendKeyToSCReader(key,sector,bufptr) == 0)
            {
				TransmitCharToX(C_NEW_SMARTCARD_COMM,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(0,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return;
			}
			else
			{
				err = 3;
				goto NEW_CMD_HandleSerSmartCardError;
			}
//			break;

		case 10:	  //$1ly,1,Dataaaaaa,
					 //$1ly,1,1Y00000101010101018002406000000000000000,
	      	if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandleSerSmartCardError;
          	readerno = atoi((char *)bufptr);
				SCReaderNo = readerno;
	      	if(GetDataByPosition(bufptr,buffer,4) == NULL)
		         goto NEW_CMD_HandleSerSmartCardError;
         	if(SendCommandToSCReader((char *)bufptr,strlen((char*)bufptr),(char *)databuf) == 0)
            {
				index2 = strlen((char *)databuf);
				TransmitCharToX(C_NEW_SMARTCARD_COMM,port);
				TransmitCharToX(',',port);
				for(sector=0;sector<index2;sector++)
				{
					TransmitCharToX(databuf[sector],port);
				}
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return;
			}
			else
			{
				err =3;
				goto NEW_CMD_HandleSerSmartCardError;
			}
//			break;
#endif 			
#ifdef SUPPORT_ICLASS_RDR			//FA00100
		case 36: //Write Key for I-Class reader
      //$1ly,36,readerno,key,ReaderSector,keysize,keystring,chksum,enter
      //$1ly,36,1,2,1,16,5CBCF1DA45D5FB5F,
         if(GetDataByPosition(bufptr,buffer,3) == NULL)
            goto NEW_CMD_HandleSerSmartCardError;
         readerno = atoi((char *)bufptr);
         if(GetDataByPosition(bufptr,buffer,4) == NULL)
            goto NEW_CMD_HandleSerSmartCardError;
         key = atoi((char *)bufptr);
         if(GetDataByPosition(bufptr,buffer,5) == NULL)
            goto NEW_CMD_HandleSerSmartCardError;
         sector = atoi((char *)bufptr);
         if((sector > 7) || (sector == 0))
            goto NEW_CMD_HandleSerSmartCardError;
			if(GetDataByPosition(bufptr,buffer,6) == NULL)
		   	goto NEW_CMD_HandleSerSmartCardError;
         len = atoi((char *)bufptr);
         if(len > 16)
            goto NEW_CMD_HandleSerSmartCardError;
         if(GetDataByPosition(bufptr,buffer,7) == NULL)
            goto NEW_CMD_HandleSerSmartCardError;
         if(strlen((char *)bufptr) > 16)
            goto NEW_CMD_HandleSerSmartCardError;
         if(SendKeyToIClassReader(key,sector,bufptr) == 0)
         {
	         TransmitCharToX(C_NEW_SMARTCARD_COMM,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(0,port);
	         TransmitCharToX(',',port);
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
	         return;
         }
         else
         {
            err = 3;
            goto NEW_CMD_HandleSerSmartCardError;
         }
//         break;
#endif

	}

NEW_CMD_HandleSerSmartCardError:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(err,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
#endif
}

/*** BeginHeader HandelLastCard*/
void HandelLastCard(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandelLastCard(unsigned char *buffer,unsigned char port)
{
//PANKAJXX 
BYTE cmdver,err;
	err = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
   		goto NEW_CMD_HandelLastCardError;
   	}
  	cmdver = atoi((char *)bufptr);
   	if(cmdver==0)
   	{
      // $1li,0,
      //#1i,readerno,cardno,fccode,chksum,enter
	   	TransmitCharToX(C_NEW_LAST_CARD,port);
		TransmitCharToX(',',port);
	    SendDecimalToPC3CharToX(CurrentUser.RdrNo,port);
		TransmitCharToX(',',port);
	    SendDecimalLongToX(DRStruct[CurrentUser.RdrNo-1].LastCardNo,port);
	    TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(DRStruct[CurrentUser.RdrNo-1].FCode,port);	//D0019
   	}
   	else if(cmdver>=1 &&(cmdver<=MAX_READERS_SUPPORT))
   	{
	   	TransmitCharToX(C_NEW_LAST_CARD,port);
		TransmitCharToX(',',port);
	    SendDecimalToPC3CharToX(cmdver,port); 		//D00025
	    TransmitCharToX(',',port);
	    SendDecimalLongToX(DRStruct[cmdver-1].LastCardNo,port);
	    TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(DRStruct[cmdver-1].FCode,port);	//D0019
   	}
   	else
     	goto NEW_CMD_HandelLastCardError;
   	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
   	return;
NEW_CMD_HandelLastCardError:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(err,port);
	TransmitCharToX(',',port);
   	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}


/*** BeginHeader HandleOtherParameterSetting*/
void HandleOtherParameterSetting(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleOtherParameterSetting(unsigned char *buffer,unsigned char port)
{
int tempdata;
unsigned char errno,temp1,len;
		errno =2;
		TransmitReplyStartToX(port);
		if(GetDataByPosition(bufptr,buffer,2) == NULL)
	   {
      	goto C_SET_OtherParameter_ERROR;
      }
      temp1 = atoi((char *)bufptr);
      if(temp1 > MAX_OTHER_PARA)
      {
      	if((temp1 >=100) &&(temp1<=100+MAX_OTHER_PARA))
         {
         	temp1=temp1-100;
	         TransmitCharToX(C_NEW_OTHER_PARA_SETTING,port);
	         TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(temp1,port);
	         TransmitCharToX(',',port);
	         switch(OtherPara[temp1].Type)
	         {
	            case D_BIN:
	            case D_CHAR:
	                  SendDecimalToPC3CharToX(*OtherPara[temp1].VChar,port) ;
	            break;
	            case D_INT:
	                 SendDecimalIntToX(*OtherPara[temp1].VInt,port);
	               break;
	            case D_LONG:
	               SendDecimalLongToX(*OtherPara[temp1].VLong,port);
				   MsgPrint(1,(unsigned long)&(*OtherPara[temp1].VLong),"OtherPara[temp1].VLong");
	            break;
	            case D_STR:
	               TransmitNStrToX(OtherPara[temp1].VStr,OtherPara[temp1].Len,port);
	            break;
	         }
	            TransmitCharToX(',',port);
	            TransmitCheckSumX(port);
	            TransmitCharToX(',',port);
	            TransmitCharToX(TERMINATOR,port);
               return;
         	}
         	else
         		errno =3;
		 	goto C_SET_OtherParameter_ERROR;
      }
      else
      {
      	if(OtherPara[temp1].Settable ==0)
         {
         	errno =4;
				goto C_SET_OtherParameter_ERROR;

         }
	      switch(OtherPara[temp1].Type)
	      {
	         case D_BIN:
	         case D_CHAR:
	            if(GetDataByPosition(bufptr,buffer,3) == NULL)
	            {
	               goto C_SET_OtherParameter_ERROR;
	            }
	            *OtherPara[temp1].VChar = atoi((char*)bufptr) & 0xff;
	         break;
	         case D_INT:
	            if(GetDataByPosition(bufptr,buffer,3) == NULL)
	            {
	               goto C_SET_OtherParameter_ERROR;
	            }
	            *OtherPara[temp1].VInt = atoi((char*)bufptr);
	         break;
	         case D_LONG:
	            if(GetDataByPosition(bufptr,buffer,3) == NULL)
	            {
	               goto C_SET_OtherParameter_ERROR;
	            }
	             tempdata = (unsigned int) (atol((char*)bufptr));
				 MsgPrint(1,tempdata,"tempdata =");
				 memcpy(OtherPara[temp1].VLong,&tempdata,sizeof(tempdata));
				 MsgPrint(1,(long)OtherPara[temp1].VLong,"OtherPara[temp1].VLong");
				 MsgPrint(1,atol((char*)bufptr),"atol((char*)bufptr)");
				 MsgPrint(1,*OtherPara[temp1].VLong,"*OtherPara[temp1].VLong");
	//            printf(" Long %d %d \n",*OtherPara[temp1].VLong/100000 , *OtherPara[temp1].VLong%100000);
	         break;
	         case D_STR:
	            if(GetDataByPosition(bufptr,buffer,3) == NULL)
	            {
	               goto C_SET_OtherParameter_ERROR;
	            }
	            len = strlen((char*)bufptr);
	            if(OtherPara[temp1].Len <= len)
	               len = OtherPara[temp1].Len;
	            strncpy((char *)OtherPara[temp1].VStr,(char *)bufptr,len);
	            OtherPara[temp1].VStr[len]= (char ) '\0';
	         break;
	         default:
C_SET_OtherParameter_ERROR:
	         TransmitCharToX('e',port);
	         TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(errno,port);
	         TransmitCharToX(',',port);
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
	         return;
	      }
		if((temp1>=6)&&(temp1<=10))
      		WriteModelInfoToFlash();
      	if(temp1 == 11)   			//shree 23July updated in EEprom
      	{
			Doorinfo.E_InEmpCount = InEmpCount_Back=InEmpCount;
         	WriteDoorInfoToFlash();
      	}
      	TransmitCharToX(C_NEW_OTHER_PARA_SETTING,port);
		TransmitCharToX(',',port);
	   	TransmitCheckSumX(port);
		TransmitCharToX(',',port);
   		TransmitCharToX(TERMINATOR,port);
      	return;
   }
//goto C_SET_OtherParameter_ERROR;
}

//------------------------------------------------------------------------------
/* Program time zone
// Max time zone now possible is 64 (1 to 64)
// Weekday
// 0 Sunday to 6 Saturday
//=======================

$1lT,1,timezoneno,weekday,Shh,Smm,Ehh,Emm,chksum,enter

//Read Full weektimezone
$1lT,100,timezoneno,
#1T,timezone,0,shh(0),smm(0),ehh(0),emm(0),:,1,shh(1),smm(1),ehh(1),emm(1),:,..........,6,shh(6),smm(6),ehh(6),emm(6),:,chksum,enter
#1T,001,000,000,000,023,000,:,001,000,000,174,000,:,002,000,000,132,000,:,003,000,000,000,000,:,004,000,000,000,174,:,005,000,000,000,132,:,006,000,000,000,000,:,7B,

//=======================

//Read Timezone for day
$1lT,101,timezoneno,weekday,chksum,enter,
#1T,timezone,wday,shh(wday),smm(wday),ehh(wday),emm(wday),chksum,enter

#1T,001,000,000,000,023,000,6A,

//=======================
Time zone setting slot wise. There will be 4 slots per day. Timezone checking will be done by slot 1, 2, 3, 4.
If current time is within slot 1 then it will ignore rest of slots and will give access.

Set time zones per slot
$1lT,2,TZNo,weekday,SlotNo,Shh,Smm,Ehh,Emm,Chksum,ENT
SlotNo = 1 to 4

Get time zones per slot
$1lT,102,TZNo,weekday,SlotNo,Chksum,ENT
$1lT,102,60,0,1,
SlotNo = 1 to 4
#1T,timezoneno,weekday,SlotNo,Shh,Smm,Ehh,Emm,Chksum,ENT

Set all slots using single command
$1lT,5,TZNo,Weekday,S1,Shh1,Smm1,Ehh1,Emm1,S2,Shh2,Smm2,Ehh2,Emm2,S3,Shh3,Smm3,Ehh3,Emm3,S4,Shh4,Smm4,Ehh4,Emm4,Chksum,ENT
$1lT,5,60,0,1,7,0,8,0,2,9,0,10,0,3,11,0,12,0,4,13,0,14,0,

Get all slots using single command
$1lT,105,TZNo,Weekday,Chksum,ENT
$1lT,105,60,0,
#1T,TZNo,Weekday,S1,Shh1,Smm1,Ehh1,Emm1,S2,Shh2,Smm2,Ehh2,Emm2,S3,Shh3,Smm3,Ehh3,Emm3,S4,Shh4,Smm4,Ehh4,Emm4,Chksum,ENT

*/

/*** BeginHeader HandelNewTimeZone*/
void HandelNewTimeZone(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandelNewTimeZone(unsigned char *buffer,unsigned char port)
{
//PANKAJXX 
BYTE cmdver, err, tzno, wday;
unsigned char j, tzslot;
	err = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
	   goto NEW_CMD_HandelNewTimeZone;
	}
	cmdver = atoi((char*)bufptr);
   switch(cmdver)
   {
      case 1:    // Set time zone
         if(GetDataByPosition(bufptr,buffer,3) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
         tzno = atoi((char *)bufptr);
         tzno--;
         if(tzno >= MAX_TIME_ZONE)
         {
            err = 3;
            goto NEW_CMD_HandelNewTimeZone;
         }
         if(GetDataByPosition(bufptr,buffer,4) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
         wday = atoi((char *)bufptr);
         if(wday >= 7)
         {
            err = 3;
            goto NEW_CMD_HandelNewTimeZone;
         }		//
//         xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
		  GetTimeZone(tzno,&Timezone);
         if(GetDataByPosition(bufptr,buffer,5) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
        Timezone.TimeZone[wday].TZSlotNo[0].StarHours = atoi((char *)bufptr);
         if(GetDataByPosition(bufptr,buffer,6) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
        Timezone.TimeZone[wday].TZSlotNo[0].StarMin = atoi((char *)bufptr);
         if(GetDataByPosition(bufptr,buffer,7) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
        Timezone.TimeZone[wday].TZSlotNo[0].EndHours = atoi((char *)bufptr);
         if(GetDataByPosition(bufptr,buffer,8) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
        Timezone.TimeZone[wday].TZSlotNo[0].EndMin = atoi((char *)bufptr);
		SaveTimeZone(tzno,&Timezone);
//        root2xmem((unsigned long)TIME_ZONE_BASE+(unsigned long)((unsigned long)sizeof(Timezone)*(unsigned long)tzno), &Timezone,sizeof(Timezone));
//        TimeZoneBackup();
        TransmitCharToX(C_NEW_TIMEZONE,port);
        TransmitCharToX(',',port);
        SendDecimalToPC3CharToX(0,port);
        TransmitCharToX(',',port);
        TransmitCheckSumX(port);
        TransmitCharToX(',',port);
        TransmitCharToX(TERMINATOR,port);
        return;
      case 100:    // Get Timzzone for week
         if(GetDataByPosition(bufptr,buffer,3) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
         tzno = atoi((char *)bufptr);
         tzno--;
         if(tzno >= MAX_TIME_ZONE)
         {
            err = 3;
            goto NEW_CMD_HandelNewTimeZone;
         }
         TransmitCharToX(C_NEW_TIMEZONE,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(tzno+1,port);
		GetTimeZone(tzno,&Timezone);
///         xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
         for(wday=0;wday<7;wday++)
         {
            TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(wday,port);
            TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].StarHours,port);
            TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].StarMin,port);
            TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].EndHours,port);
            TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].EndMin,port);
            TransmitCharToX(',',port);
            TransmitCharToX(':',port);
         }
         TransmitCharToX(',',port);
         TransmitCheckSumX(port);
         TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
         return;
      case 101:    // Get Timzzone for day
         if(GetDataByPosition(bufptr,buffer,3) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
         tzno = atoi((char *)bufptr);
         tzno--;
         if(tzno >= MAX_TIME_ZONE)
         {
            err =3;
            goto NEW_CMD_HandelNewTimeZone;
         }
         if(GetDataByPosition(bufptr,buffer,4) ==NULL)
            goto NEW_CMD_HandelNewTimeZone;
         wday = atoi((char *)bufptr);
         if(wday >= 7)
         {
            err = 4;
            goto NEW_CMD_HandelNewTimeZone;
         }
		GetTimeZone(tzno,&Timezone);
//         xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
         TransmitCharToX(C_NEW_TIMEZONE,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(tzno+1,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(wday,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].StarHours,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].StarMin,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].EndHours,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[0].EndMin,port);
         TransmitCharToX(',',port);
         TransmitCheckSumX(port);
         TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
         return;
      case 2:    // Set time zone Slotwise
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      tzno = atoi((char *)bufptr);
	      if((tzno > MAX_TIME_ZONE) || (tzno == 0))
	      {
	         err = 3;
	         goto NEW_CMD_HandelNewTimeZone;
	      }
	      tzno--;
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      wday = atoi((char *)bufptr);
	      if(wday >= 7)
	      {
	         err = 3;
	         goto NEW_CMD_HandelNewTimeZone;
	      }
	      if(GetDataByPosition(bufptr,buffer,5) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      tzslot = atoi((char *)bufptr);
	      if((tzslot > MAX_TZ_SLOTS) || (tzslot == 0))
	      {
	         err = 3;
	         goto NEW_CMD_HandelNewTimeZone;
	      }
         tzslot--;
		  GetTimeZone(tzno,&Timezone);
//	      xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
	      if(GetDataByPosition(bufptr,buffer,6) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      Timezone.TimeZone[wday].TZSlotNo[tzslot].StarHours = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,7) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      Timezone.TimeZone[wday].TZSlotNo[tzslot].StarMin = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,8) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      Timezone.TimeZone[wday].TZSlotNo[tzslot].EndHours = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,9) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      Timezone.TimeZone[wday].TZSlotNo[tzslot].EndMin = atoi((char *)bufptr);
		  SaveTimeZone(tzno,&Timezone);
//	      root2xmem((unsigned long)TIME_ZONE_BASE+(unsigned long)((unsigned long)sizeof(Timezone)*(unsigned long)tzno), &Timezone,sizeof(Timezone));
	      //TimeZoneBackup();
	      TransmitCharToX(C_NEW_TIMEZONE,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(0,port);
	      TransmitCharToX(',',port);
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
	      return;
      case 102:    // Get slotwise Timzzone for day
         if(GetDataByPosition(bufptr,buffer,3) == NULL)
            goto NEW_CMD_HandelNewTimeZone;
         tzno = atoi((char *)bufptr);
	      if((tzno > MAX_TIME_ZONE) || (tzno == 0))
         {
            err = 3;
            goto NEW_CMD_HandelNewTimeZone;
         }
         tzno--;
         if(GetDataByPosition(bufptr,buffer,4) == NULL)
            goto NEW_CMD_HandelNewTimeZone;
         wday = atoi((char *)bufptr);
         if(wday >= 7)
         {
            err = 4;
            goto NEW_CMD_HandelNewTimeZone;
         }
	      if(GetDataByPosition(bufptr,buffer,5) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      tzslot = atoi((char *)bufptr);
	      if((tzslot > MAX_TZ_SLOTS) || (tzslot == 0))
	      {
	         err = 3;
	         goto NEW_CMD_HandelNewTimeZone;
	      }
         tzslot--;
		  GetTimeZone(tzno,&Timezone);
//         xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
         TransmitCharToX(C_NEW_TIMEZONE,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(tzno+1,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(wday,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(tzslot+1,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].StarHours,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].StarMin,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].EndHours,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].EndMin,port);
         TransmitCharToX(',',port);
         TransmitCheckSumX(port);
         TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
         return;
      case 5:    // Set all 4 slotwise Timzzones for a weekday
			//$1lT,5,60,0,1,7,0,8,0,2,9,0,10,0,3,11,0,12,0,4,13,0,14,0,
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      tzno = atoi((char *)bufptr);
	      if((tzno > MAX_TIME_ZONE) || (tzno == 0))
	      {
	         err = 3;
	         goto NEW_CMD_HandelNewTimeZone;
	      }
	      tzno--;
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto NEW_CMD_HandelNewTimeZone;
	      wday = atoi((char *)bufptr);
	      if(wday >= 7)
	      {
	         err = 3;
	         goto NEW_CMD_HandelNewTimeZone;
	      }
         for(j=0;j<MAX_TZ_SLOTS;j++)
         {
	         if(GetDataByPosition(bufptr,buffer,(5*j)+5) == NULL)
	            goto NEW_CMD_HandelNewTimeZone;
	         tzslot = atoi((char *)bufptr);
	         if((tzslot > MAX_TZ_SLOTS) || (tzslot == 0))
	         {
	            err = 3;
	            goto NEW_CMD_HandelNewTimeZone;
	         }
            tzslot--;
		  	GetTimeZone(tzno,&Timezone);
//	         xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
	         if(GetDataByPosition(bufptr,buffer,(5*j)+6) == NULL)
	            goto NEW_CMD_HandelNewTimeZone;
	         Timezone.TimeZone[wday].TZSlotNo[tzslot].StarHours = atoi((char *)bufptr);
	         if(GetDataByPosition(bufptr,buffer,(5*j)+7) == NULL)
	            goto NEW_CMD_HandelNewTimeZone;
	         Timezone.TimeZone[wday].TZSlotNo[tzslot].StarMin = atoi((char *)bufptr);
	         if(GetDataByPosition(bufptr,buffer,(5*j)+8) == NULL)
	            goto NEW_CMD_HandelNewTimeZone;
	         Timezone.TimeZone[wday].TZSlotNo[tzslot].EndHours = atoi((char *)bufptr);
	         if(GetDataByPosition(bufptr,buffer,(5*j)+9) == NULL)
	            goto NEW_CMD_HandelNewTimeZone;
	         Timezone.TimeZone[wday].TZSlotNo[tzslot].EndMin = atoi((char *)bufptr);
		  	SaveTimeZone(tzno,&Timezone);
//         	root2xmem((unsigned long)TIME_ZONE_BASE+(unsigned long)((unsigned long)sizeof(Timezone)*(unsigned long)tzno), &Timezone,sizeof(Timezone));
			}
         //TimeZoneBackup();
	      TransmitCharToX(C_NEW_TIMEZONE,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(0,port);
	      TransmitCharToX(',',port);
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
	      return;
      case 105:    // Get all slotwise Timzzone for a weekday
         if(GetDataByPosition(bufptr,buffer,3) == NULL)
            goto NEW_CMD_HandelNewTimeZone;
         tzno = atoi((char *)bufptr);
	      if((tzno > MAX_TIME_ZONE) || (tzno == 0))
         {
            err = 3;
            goto NEW_CMD_HandelNewTimeZone;
         }
         tzno--;
         if(GetDataByPosition(bufptr,buffer,4) == NULL)
            goto NEW_CMD_HandelNewTimeZone;
         wday = atoi((char *)bufptr);
         if(wday >= 7)
         {
            err = 4;
            goto NEW_CMD_HandelNewTimeZone;
         }
//         xmem2root(&Timezone,(unsigned long)TIME_ZONE_BASE +((unsigned long)TIME_ZONE_BYTES * (unsigned long)tzno),TIME_ZONE_BYTES);
		  GetTimeZone(tzno,&Timezone);
         TransmitCharToX(C_NEW_TIMEZONE,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(tzno+1,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(wday,port);
         TransmitCharToX(',',port);
         for(tzslot=0;tzslot<MAX_TZ_SLOTS;tzslot++)
         {
	         SendDecimalToPC3CharToX(tzslot+1,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].StarHours,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].StarMin,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].EndHours,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(Timezone.TimeZone[wday].TZSlotNo[tzslot].EndMin,port);
         	TransmitCharToX(',',port);
			}
         TransmitCheckSumX(port);
         TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
         return;
   }
NEW_CMD_HandelNewTimeZone:
   TransmitCharToX('e',port);
   TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(err,port);
   TransmitCharToX(',',port);
   TransmitCheckSumX(port);
   TransmitCharToX(',',port);
   TransmitCharToX(TERMINATOR,port);
}
/*
// Following function will send UDP alert
// #slavenoU,channelno,event,cardno,time,date,writepointer,chksum,enter
unsigned char SendUDPAlert(unsigned char event,unsigned char channelno,unsigned long data1,unsigned int data2,unsigned char port)
{
	PortObj[port].BufPtr = 0;
	PortObj[port].F_ChkSum = SET;
	PortObj[port].ChkSum = 0;
	TransmitReplyStartToX(port);
	TransmitCharToX('U',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(1,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(channelno,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(event,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX(data1,port);
	TransmitCharToX(',',port);
	SendDecimalToX(Datetime.Time.Hour,port);
	SendDecimalToX(Datetime.Time.Min,port);
	SendDecimalToX(Datetime.Time.Secs,port);
	TransmitCharToX(',',port);
	SendDecimalToX(Datetime.Date.Day,port);
	SendDecimalToX(Datetime.Date.Month,port);
	SendDecimalToX(Datetime.Date.Year,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(data2,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
#ifdef ENABLE_UDP
    fnSendUDP(MyUDP_Socket, ucUDP_IP_Address, MY_UDP_PORT, (unsigned char*)&PortObj[port].Buffer, PortObj[port].BufPtr-DUMMY_UDP_HEADER_SIZE, 0);
#endif
	return(0);
}
*/
/***
UDP alert for trsnaction. we sued transaction type as 2
This even is called when we store transaction..
*/
unsigned char SendUDPTransaction(struct TRNX_DATA *trans,unsigned char port)
{
	PortObj[port].BufPtr = 0;
	PortObj[port].F_ChkSum = SET;
	PortObj[port].ChkSum = 0;
	TransmitReplyStartToX(port);
	TransmitCharToX('U',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(2,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(trans->Chnl,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(trans->Event,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX(trans->CardNo,port);
	TransmitCharToX(',',port);
	SendDecimalToX(trans->Datetime.Time.Hour,port);
	SendDecimalToX(trans->Datetime.Time.Min,port);
	SendDecimalToX(trans->Datetime.Time.Secs,port);
	TransmitCharToX(',',port);
	SendDecimalToX(trans->Datetime.Date.Day,port);
	SendDecimalToX(trans->Datetime.Date.Month,port);
	SendDecimalToX(trans->Datetime.Date.Year,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TotalNosOfTrans+1,port);		// As we send alert before saving transaction so we have to increment by one
	TransmitCharToX(',',port);          //PANKAJ
	SendDecimalLongToX6digit(TransWritePtr,port);
	TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
	SendDecimalToPC3CharToX(trans->CType,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(trans->InputType,port);
#else
	TransmitCharToX('0',port);
	TransmitCharToX(',',port);
	TransmitCharToX('0',port);
#endif
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
#ifdef ENABLE_UDP
//    fnSendUDP(MyUDP_Socket, ucUDP_IP_Address, MY_UDP_PORT, (unsigned char*)&PortObj[port].Buffer, PortObj[port].BufPtr-DUMMY_UDP_HEADER_SIZE, 0);
	{
		BYTE arrip[4];
		StrToArr((char*)&(SysInfo.UDP_IPAdd[0]),arrip);						
		fnSendUDP(MyUDP_Socket,arrip, SysInfo.UDP_PushPort, PortObj[port].Buffer, PortObj[port].BufPtr-sizeof(UDP_HEADER), 0);
	}
#endif
//	SendEmail(UDPPortObj.Buffer);
#ifdef ENABLE_EMAIL_SEND
//	EmailTransactionSend(trans,1,"");
//	EmailAddToBuffer(TransWritePtr,EMAIL_TYPE_NORMAL); 
#endif
	return(0);
}



//========================================================================================================================
/*
unsigned char SendUDPTemplate(struct TMPLT_DATA_STRUCT *TemplateDataX,unsigned char port)
{
unsigned char i;	
	PortObj[port].BufPtr = 0;
	PortObj[port].F_ChkSum = SET;
	PortObj[port].ChkSum = 0;
	TransmitReplyStartToX(port);
	TransmitCharToX('U',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(2,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(TemplateDataX->Chnl,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(TemplateDataX->Event,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX(TemplateDataX->CardNo,port);
	TransmitCharToX(',',port);
	SendDecimalToX(TemplateDataX->Datetime.Time.Hour,port);
	SendDecimalToX(TemplateDataX->Datetime.Time.Min,port);
	SendDecimalToX(TemplateDataX->Datetime.Time.Secs,port);
	TransmitCharToX(',',port);
	SendDecimalToX(TemplateDataX->Datetime.Date.Day,port);
	SendDecimalToX(TemplateDataX->Datetime.Date.Month,port);
	SendDecimalToX(TemplateDataX->Datetime.Date.Year,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(TotalNosOfTemplates+1,port);		// As we send alert before saving transaction so we have to increment by one
	TransmitCharToX(',',port);          //PANKAJ
	SendDecimalIntToX(TemplateWritePtr,port);
	TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
	SendDecimalToPC3CharToX(TemplateDataX->CType,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(TemplateDataX->InputType,port);
#else
	TransmitCharToX('0',port);
	TransmitCharToX(',',port);
	TransmitCharToX('0',port);
#endif
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	for(i=0;i<TEMPLATE_DATA_SIZE;i++)
		SendAsciiToX(TemplateDataX->TemplateBuffer[i],port);

	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
#ifdef ENABLE_UDP
//    fnSendUDP(MyUDP_Socket, ucUDP_IP_Address, MY_UDP_PORT, (unsigned char*)&PortObj[port].Buffer, PortObj[port].BufPtr-DUMMY_UDP_HEADER_SIZE, 0);
	{
		BYTE arrip[4];
		StrToArr((char*)&(SysInfo.UDP_IPAdd[0]),arrip);						
		fnSendUDP(MyUDP_Socket,arrip, SysInfo.UDP_PushPort, PortObj[port].Buffer, PortObj[port].BufPtr-sizeof(UDP_HEADER), 0);
	}
#endif
//	SendEmail(UDPPortObj.Buffer);
#ifdef ENABLE_EMAIL_SEND
//	EmailTransactionSend(trans,1,"");
//	EmailAddToBuffer(TransWritePtr,EMAIL_TYPE_NORMAL); 
#endif
	return(0);
}	*/
//===============================================================================================================================



#ifdef PROCESS_HEARTBEAT

unsigned char SendUDPToIPPort(struct TRNX_DATA *trans,unsigned char port,char *ip,short ipport )
{
	PortObj[port].BufPtr = 0;
	PortObj[port].F_ChkSum = SET;
	PortObj[port].ChkSum = 0;
	TransmitReplyStartToX(port);
	TransmitCharToX('H',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(1,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(trans->Chnl,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(trans->Event,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX(trans->CardNo,port);
	TransmitCharToX(',',port);
	SendDecimalToX(trans->Datetime.Time.Hour,port);
	SendDecimalToX(trans->Datetime.Time.Min,port);
	SendDecimalToX(trans->Datetime.Time.Secs,port);
	TransmitCharToX(',',port);
	SendDecimalToX(trans->Datetime.Date.Day,port);
	SendDecimalToX(trans->Datetime.Date.Month,port);
	SendDecimalToX(trans->Datetime.Date.Year,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TotalNosOfTrans+1,port);		// As we send alert before saving transaction so we have to increment by one
	TransmitCharToX(',',port);          //PANKAJ
	SendDecimalLongToX6digit(TransWritePtr,port);
	TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
	SendDecimalToPC3CharToX(trans->CType,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(trans->InputType,port);
#else
	TransmitCharToX('0',port);
	TransmitCharToX(',',port);
	TransmitCharToX('0',port);
#endif
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
#ifdef ENABLE_UDP
	{
		BYTE arrip[4];
		StrToArr((char *)ip,arrip);						
		fnSendUDP(MyUDP_Socket,arrip, ipport, PortObj[port].Buffer, PortObj[port].BufPtr-sizeof(UDP_HEADER), 0);
	}
#endif
	return(0);
}


unsigned char HandleSerialAuthCheck(unsigned char authtype,unsigned char port);
/*** EndHeader */
unsigned char HandleSerialAuthCheck(unsigned char authtype,unsigned char port)
{
	unsigned char errno;
	MsgPrint(MSG_WARNING,authtype,"HandleSerialAuthCheck:authtype");		
	switch(authtype)
	{
		case SECURE_AUTH_ADMIN:
		    MsgPrint(MSG_WARNING,PresentTCPStatus,"PresentTCPStatus");
			if((SysInfo.AuthIP == 1) && (PresentTCPStatus == SOCKET_AUTH_FAIL))                //D0034
			{
			   
				errno = 100;
				goto NEW_CMD_HandleSerialAuthCheckERROR;
			}
			goto NEW_CMD_HandleSerialAuthCheckSUCCESS;
	case SECURE_TRNX_DWNLD_IP_CHK:
		switch(Doorinfo.SecurityEnDis)
		{
			case 1: //check ip
			{
					if( aton((char*)&SysInfo.SERVER_IP_ADD[0]) == ArrToLong(CurrentIP) )  
						goto NEW_CMD_HandleSerialAuthCheckSUCCESS;
					else
					{
						errno = 106;
						goto NEW_CMD_HandleSerialAuthCheckERROR;
					}	
			}

			case 2:  //check mac
			{
				if(Check_Server_MACID(MY_ethernet_source_MAC) == 0x01)
				{
				  MsgPrint(MSG_WARNING,1,"MAC id sucess");
				  goto NEW_CMD_HandleSerialAuthCheckSUCCESS;				
				}
				else {
				     errno = 100;
				   	 MsgPrint(MSG_WARNING,0,"MAC id fail");
				    goto NEW_CMD_HandleSerialAuthCheckERROR;
				}
			}

			case 3:	 //check mac+ip
			{
	           if(Doorinfo.SecurityEnDis & BIT_TRNX_DWNLD_IP_CHK)
				{
					if( aton((char*)&SysInfo.SERVER_IP_ADD[0]) != ArrToLong(CurrentIP) ) 					
					{
						errno = 106;
						goto NEW_CMD_HandleSerialAuthCheckERROR;
					}
				}	
				
				if(Check_Server_MACID(MY_ethernet_source_MAC) == 0x01)
				  goto NEW_CMD_HandleSerialAuthCheckSUCCESS;
				else{
						errno = 100; goto NEW_CMD_HandleSerialAuthCheckERROR;
					}
			}

			case 0:
			goto NEW_CMD_HandleSerialAuthCheckSUCCESS;
		}//switch(Doorinfo.SecurityEnDis)
		default:
		break;
	}

NEW_CMD_HandleSerialAuthCheckSUCCESS:
	return(0);

NEW_CMD_HandleSerialAuthCheckERROR:
	TransmitReplyStartToX(port);
	TransmitCharToX(C_NEW_ERROR_RETURN,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitStrToX((BYTE*)ProdVerStr,port);
	TransmitCharToX(MAJOR_VER,port);
	TransmitCharToX('.',port);
	TransmitCharToX(MINOR_VER,port);
	TransmitCharToX(CONTROLLER_TYPE,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return(1);
}



unsigned char SendHBString(unsigned char port, char *ip,short ipport )
{
char tmpcnt;

	PortObj[port].BufPtr = 0;
	PortObj[port].F_ChkSum = SET;
	PortObj[port].ChkSum = 0;
	TransmitReplyStartToX(port);
	TransmitCharToX('H',port);
	TransmitCharToX(',',port);
	TransmitCharToX('1',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(SysInfo.MySlaveNo,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	TransmitStrToX((BYTE *)ProdVerStr,port); 							//shree 26Sep
	TransmitCharToX(MAJOR_VER,port);
	TransmitCharToX('.',port);
	TransmitCharToX(MINOR_VER,port);
	TransmitCharToX(CONTROLLER_TYPE,port);						//shree 26Sep
	TransmitCharToX(',',port);
	TransmitNStrToX(ModelInfo.ModelNo,sizeof(ModelInfo.ModelNo),port);
	TransmitCharToX(',',port);
	TransmitNStrToX(ModelInfo.SerialNo,sizeof(ModelInfo.SerialNo),port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(SysInfo.ETH_Port,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(SysInfo.UDP_PushPort,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(port,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TotalNosOfTrans,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(PercentageMem,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TransWritePtr,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TransReadPtr,port);
	TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
			SendDecimalIntToX(TotalCards,port);
#endif
	TransmitCharToX(',',port);
	SendDecimalToX(Datetime.Time.Hour,port);
	SendDecimalToX(Datetime.Time.Min,port);
	SendDecimalToX(Datetime.Time.Secs,port);
	TransmitCharToX(',',port);
	SendDecimalToX(Datetime.Date.Day,port);
	SendDecimalToX(Datetime.Date.Month,port);
	SendDecimalToX(Datetime.Date.Year,port);
	TransmitCharToX(',',port);
	SendDecimalToX(CWeekDay,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(SysInfo.ControllerMode,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(SysInfo.SlaveType,port);
	TransmitCharToX(',',port);
	SendAsciiToX(ModelInfo.MACAddress[0],port);
	for(tmpcnt=1;tmpcnt<6;tmpcnt++)
	{
		TransmitCharToX('-',port);
		SendAsciiToX(ModelInfo.MACAddress[tmpcnt],port);
	}
	TransmitCharToX(',',port);
	TransmitNStrToX(SetSysPara[1].VStr,SetSysPara[1].Len,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(0,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(0,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(0,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(0,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(0,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(0,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
#ifdef ENABLE_UDP
	{
		BYTE arrip[4];
		StrToArr((char *)ip,arrip);						
		fnSendUDP(MyUDP_Socket,arrip, ipport, PortObj[port].Buffer, PortObj[port].BufPtr-sizeof(UDP_HEADER), 0);
	}
#endif
	return(0);
}

#endif

//==============================================================================================
// Following is used to send and delete transaction in puch method
/*
#<deviceno char >P,<deviceno>,<no of transactions sent>,<Total pending>,<current Readpointer>,<write pointer>,!,
T,<ChannelNo>,<event type>,<cardno>,<time>,<data>,<readpointer >,<sequence no>,!,
T,<ChannelNo>,<event type>,<cardno>,<time>,<data>,<readpointer >,<sequence no>,!,
*/
/*** BeginHeader PushAndDeleteTransPacket*/
//void PushAndDeleteTransPacket(unsigned char nooftrans,unsigned char port);
/*** EndHeader */
//void PushAndDeleteTransPacket(unsigned char nooftrans,unsigned char port)
//{
//PANKAJXX
/*	struct TRNX_DATA trans;
	unsigned int totalavailable,tempread;
   unsigned char count;
   unsigned long ipaddress;

   ipaddress = aton(SysInfo.LOCAL_IP);
   totalavailable = GetPendingTrans(TransReadPtr,TransWritePtr);
   if(totalavailable <nooftrans)
   	nooftrans = totalavailable;
   tempread=TransReadPtr;
   TransmitReplyStartToX(port);
	TransmitCharToX('P',port);
	TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(SysInfo.MySlaveNo,port);
	TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(nooftrans,port);
	TransmitCharToX(',',port);
   SendDecimalIntToX(TotalNosOfTrans-nooftrans,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(TransReadPtr,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(TransWritePtr,port);
	TransmitCharToX(',',port);
   SendDecimalLongToX(ipaddress,port);
	TransmitCharToX(',',port);
	TransmitCharToX('!',port);
	TransmitCharToX(',',port);
   count =0;
	while(1)
	{
   	if(tempread ==TransWritePtr)
      {
      	nooftrans = count;
      	break;
      }
	   ReadData(tempread,(unsigned char*)&trans);
		TransmitCharToX('T',port);
		TransmitCharToX(',',port);
      SendDecimalToPC3CharToX(trans.Chnl,port);
		TransmitCharToX(',',port);
      SendDecimalToPC3CharToX(trans.Event,port);
		TransmitCharToX(',',port);
      SendDecimalLongToX(trans.CardNo,port);
		TransmitCharToX(',',port);
      SendDecimalToX(trans.Datetime.Time.Hour,port);
      SendDecimalToX(trans.Datetime.Time.Min,port);
      SendDecimalToX(trans.Datetime.Time.Secs,port);
		TransmitCharToX(',',port);
      SendDecimalToX(trans.Datetime.Date.Day,port);
      SendDecimalToX(trans.Datetime.Date.Month,port);
      SendDecimalToX(trans.Datetime.Date.Year,port);
		TransmitCharToX(',',port);
      SendDecimalIntToX(tempread,port);
		TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
      SendDecimalToPC3CharToX(trans.CType,port);
		TransmitCharToX(',',port);
      SendDecimalToPC3CharToX(trans.InputType,port);
		TransmitCharToX(',',port);
#else
      TransmitCharToX('0',port);
		TransmitCharToX(',',port);
      TransmitCharToX('0',port);
		TransmitCharToX(',',port);
#endif
		TransmitCharToX('!',port);
		TransmitCharToX(',',port);
      tempread++;
		if(tempread >=MAX_TRANS)
		{
			tempread = 0;
		}
      count++;
      if(count>=nooftrans)
      	break;
	}
   TransmitCharToX('G',port);
	TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(count,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
   TotalNosOfTrans = TotalNosOfTrans-nooftrans;
   TransReadPtr=tempread;
ERRORPushData:
*/
//	return;
//}
/*** BeginHeader InitialiseSocket*/
int InitialiseSocket(unsigned long ip, unsigned long mask,unsigned long gateway);
/*** EndHeader */
int InitialiseSocket(unsigned long ip, unsigned long mask,unsigned long gateway)
{
	unsigned char i;
//	TotalSocketConnect=0;
	//	   memset((unsigned char)SocketInfo, STATE_CLOSED, sizeof(SocketInfo));
	for(i=0;i<NUM_SOCKS;i++)
	{
		SocketInfo[i].SocketState = STATE_CLOSED;
		SocketInfo[i].SocketTimeOut = 0;
		SocketInfo[i].ClientIP=0;
		AuthIPList[i]=0;
	}
//	CurrentSocket = 0;
	//		xalloc_stats(0);
	//#ifdef ENABLE_UDP
	//	   InitialiseUDPSocket();
	//#endif
	//	   UDPDL_Init(my_id);
	return(0);
}

// Following function is used if given   IP is authenticated or not
/*** BeginHeader CheckAuthIPList*/
unsigned char CheckAuthIPList(unsigned long ipaddr);
/*** EndHeader */
unsigned char CheckAuthIPList(unsigned long ipaddr)
{
unsigned char i;

	if(SysInfo.AuthIP != 1)	//if device security is not enable return 0
		return(0);
	for(i=0;i<NUM_SOCKS;i++)
	{
		if(ipaddr == AuthIPList[i])
			return(i);
	}
	if(aton((char*)&SysInfo.SERVER_IP_ADD[0]) == ipaddr)
		return(NUM_SOCKS+1);
	return(0xFF);
}
/*** BeginHeader AddAuthIPList*/
unsigned char AddAuthIPList(unsigned long ipaddr);
/*** EndHeader */
unsigned char AddAuthIPList(unsigned long ipaddr)
{
unsigned char status,i;
	status = CheckAuthIPList(ipaddr);
	if(status == 0xFF)
	{
		status = CheckAuthIPList(0);  // 0 indicates empty  slot
		if(status != 0xFF)
		{
			AuthIPList[status] = ipaddr;
			return(status);
		}
		//Check unused socket and use that space
		for(i=0;i<NUM_SOCKS;i++)
		{
			if(SocketInfo[i].SocketState != STATE_ESTAB)
			{
				status = CheckAuthIPList(SocketInfo[i].ClientIP);
				if(status != 0xFF)
				{
					AuthIPList[status] = ipaddr;
					return(status);
				}
			}
		}
	}
	return(status);
}
/*** BeginHeader HandleSerialAuth*/
void HandleSerialAuth(unsigned char *buffer,unsigned char port);
// $1la,1,userID,password,chksum,enter  // authenticate
// $1la,2,userID,password,              // log out
// $1la,101,									// get all authenticated IP
/*** EndHeader */
void HandleSerialAuth(unsigned char *buffer,unsigned char port)
{
//	PANKAJXX 
	unsigned char cmdver,errno;
	unsigned int user,password;
	int cardptr;
	errno =2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto NEW_CMD_HandleSerialAuth;
	}
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
	case 1:	//login 
		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
			goto NEW_CMD_HandleSerialAuth;
		user = atoi((char *)bufptr);
		if(user ==0)
		{
			errno=3;
			goto NEW_CMD_HandleSerialAuth;
		}
		if(GetDataByPosition(bufptr,buffer,4) ==NULL)
			goto NEW_CMD_HandleSerialAuth;
		password  = atoi((char *)bufptr);
		cardptr = SearchNewDisplayAdminUser(user,&AdmCard); //search user data
		if(cardptr != CARD_NOT_FOUND) 
		{	//if user found
			if(AdmCard.AdmData.CardPin == password)
			{	//if password match
				errno = AddAuthIPList( ArrToLong(CurrentIP) );
				if( errno !=0xFF)
				{	//
////				printf(" authenticate success and ip added to %d \n",errno);
////				SocketInfo[CurrentSocket].Status = SOCKET_AUTH_SUCCESS;
					PresentTCPStatus = SOCKET_AUTH_SUCCESS;
					TransmitCharToX(C_NEW_SOCKET_AUTH,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(0,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(errno,port);
					TransmitCharToX(',',port);
					TransmitCheckSumX(port);
					TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
					errno=0;
					return;
				}
				else
				errno=4;
			}
			else
			errno=3;
		}
		else
		errno=3;
	break;
	
	case 2:    // log out
		if(GetDataByPosition(bufptr,buffer,3) ==NULL)
			goto NEW_CMD_HandleSerialAuth;
		user = atoi((char *)bufptr);
		if(user ==0)
		{
			errno=100;
			goto NEW_CMD_HandleSerialAuth;
		}
		if(GetDataByPosition(bufptr,buffer,4) ==NULL)
			goto NEW_CMD_HandleSerialAuth;
		password  = atoi((char *)bufptr);
		cardptr = SearchNewDisplayAdminUser(user,&AdmCard);
		if(cardptr != CARD_NOT_FOUND)
		{
			if(AdmCard.AdmData.CardPin == password)
			{
//				errno = CheckAuthIPList(SocketInfo[CurrentSocket].ClientIP);
				if( errno !=0xFF)
				{
					if(errno != (NUM_SOCKS+1))
						AuthIPList[errno] =0;
////					SocketInfo[CurrentSocket].Status = SOCKET_AUTH_FAIL;
					PresentTCPStatus = SOCKET_AUTH_FAIL;
					TransmitCharToX(C_NEW_SOCKET_AUTH,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(0,port);
					TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(errno,port);
					TransmitCharToX(',',port);
					TransmitCheckSumX(port);
					TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
					return;
				}
				else
				errno=4;
			}
			else
			errno=3;
		}
		else
		errno=3;
	break;
	
	case 101:
	break;
   }
NEW_CMD_HandleSerialAuth:
	TransmitCharToX(C_NEW_ERROR_RETURN,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);

}
  
//================================================================================

/*** BeginHeader HandleSerialAuthCheck*/
/*
unsigned char HandleSerialAuthCheck(unsigned char port);
//EndHeader
unsigned char HandleSerialAuthCheck(unsigned char port)
{
	if((SysInfo.AuthIP == 1) && (SocketInfo[DataSocketNo].Status == SOCKET_AUTH_FAIL))                //D0034
   {
		TransmitReplyStartToX(port);
	   	TransmitCharToX(C_NEW_ERROR_RETURN,port);
	   	TransmitCharToX(',',port);
	   	SendDecimalToPC3CharToX(100,port);
	   	TransmitCharToX(',',port);
		TransmitStrToX(ProdVerStr,port);
	   	TransmitCharToX(MAJOR_VER,port);
      	TransmitCharToX('.',port);
      	TransmitCharToX(MINOR_VER,port);
      	TransmitCharToX(CONTROLLER_TYPE,port);
	   	TransmitCharToX(',',port);
	   	TransmitCheckSumX(port);
	   	TransmitCharToX(',',port);
	   	TransmitCharToX(TERMINATOR,port);
		return(1);
   }
   else
   	return(0);
}  */

//================================================================================
// $1lG,0  ==> Add card with all data and delete biometric template
// $1lG,2,  ==> Add card with all data and do not delete templates
// $1lG,1,   ==> add card with all data except expiary date and Name
// $1lG,30, ==> Add special card

//$1lG,4,
//We will provide different locations to program special, holiday,duress and first in use so all are treated as different even all is stored in holiday char

/*** BeginHeader NewAddSerialCard*/
void NewAddSerialCard(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void NewAddSerialCard(unsigned char *buffer,unsigned char port)
{
unsigned int TempTotalNosTrans,var_cardno;
int err; // to avoid warning
BYTE cmdver,cmdver1,errno,cardmodify=0;
unsigned char admin,group,msginfo;
_CExtraInfo 	tExtInfo;
int ptrdata;
#ifdef EN_CARD_EXP_DATE
struct tm vDate;
#endif
#ifdef BIO_METRIC
	//unsigned int temp1;
#endif
     errno=2;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_NEW_ADD_SERIAL_CARD;
#endif
	TransmitReplyStartToX(port);
	//$1lG,1,Cardno,Pin,Doorinfo1,Doorinfo2,Holiday,CType,APB,message,Group,checksum,enter
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	   goto fun_NEW_CMD_ADD_CARD_ERROR;
	cmdver = atoi((char *)bufptr) ;
	if((cmdver == 1)||(cmdver == 0)||(cmdver == 2) || (cmdver == 3)||(cmdver == 4) ||(cmdver == 5))
	{
#ifdef EN_CARD_EXP_DATE
   	Carddata.ExpDT =0;		// Set to zero so that we can ignore the expiry date if same is zero
#endif
   // Add full card data.. in case of cmdver = 0 we will add card name also + we will delete fingers from sensor.
	   if(GetDataByPosition(bufptr,buffer,3) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE) StrDecToLong(bufptr,10);
	   if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardPin = atoi((char *)bufptr);
	   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardInfo.Door1 = atoi((char*)bufptr);
	   if(GetDataByPosition(bufptr,buffer,6) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardInfo.Door2 = atoi((char*)bufptr);
	   if(GetDataByPosition(bufptr,buffer,7) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardInfo.Holiday= atoi((char*)bufptr);
	   if(GetDataByPosition(bufptr,buffer,8) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.Info.CType = atoi((char *)bufptr);
	   if(GetDataByPosition(bufptr,buffer,9) ==NULL)
	         goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardInfo.APB = atoi((char *)bufptr);
	   if(GetDataByPosition(bufptr,buffer,10) ==NULL)
	         goto fun_NEW_CMD_ADD_CARD_ERROR;
	   	msginfo = atoi((char *)bufptr);
		if((cmdver==0)||(cmdver == 2)||(cmdver == 1))
	   		Carddata.Info.MesgInfo =msginfo;			 
	   if((cmdver==0)||(cmdver == 2)||(cmdver == 3)||(cmdver == 4) || (cmdver == 5))
	   {
      		if(GetDataByPosition(bufptr,buffer,11) == NULL)	  //name
	   			goto fun_NEW_CMD_ADD_CARD_ERROR;
#ifdef EN_CARD_EXP_DATE
      		if(GetDataByPosition(bufptr,buffer,12) == NULL)	  //exp date
	   		{			  
         		if(strlen((char *)bufptr)<10)
					Carddata.ExpDT =0;		// Set to zero so that we can ignore the expiary date if same is zero
         	}
         	if(strlen((char *)bufptr)<10)
				Carddata.ExpDT =0;		// Set to zero so that we can ignore the expiary date if same is zero
         	else
         	{
		        vDate.tm_hour  = SerialDecimalToHex(&bufptr[0]);
		        vDate.tm_min   = SerialDecimalToHex(&bufptr[2]);
		        vDate.tm_sec   = 59;
		        vDate.tm_mday  = SerialDecimalToHex(&bufptr[4]);
		        vDate.tm_mon   = SerialDecimalToHex(&bufptr[6]);
		        vDate.tm_year  = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
	         	vDate.tm_wday  = 0;
	            if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon)==0)
		            Carddata.ExpDT =0;		// Zero ExpDt means do not check exp dt
	            else
	  				Carddata.ExpDT = mktime(&vDate);
         	}
#endif
      }
      if((cmdver == 3)||(cmdver == 4)||(cmdver == 5))
      {
	  	Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday *0x01;		// Just keep holiday bit as we are setting other bit individually
//		if(GetDataByPosition(bufptr,buffer,13) == NULL)	   //CSN no.
//			goto fun_NEW_CMD_ADD_CARD_ERROR;
//================== 14 ===========	 Duress card
		if(GetDataByPosition(bufptr,buffer,14) == NULL)	   //dures en/ds
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		if(atoi((char *)bufptr)==1) 		//SPL  Duress assignment
			Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | (unsigned char) CARD_BIT_DURESS_CHK;      
		else
			Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday & (unsigned char)~(CARD_BIT_DURESS_CHK);      //SPL  Duress assignment
//================== 15 ===========	 Special Card 
		if(GetDataByPosition(bufptr,buffer,15) == NULL)	   
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		if(atoi((char *)bufptr)==1) 		
			Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | (unsigned char )CARD_BIT_SPECIAL_CARD;      //SPL  Card assignment
		else
			Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday & (unsigned char)~(CARD_BIT_SPECIAL_CARD);      //SPL  Card assignment
//================== 16 ===========	First in check
		if(GetDataByPosition(bufptr,buffer,16) == NULL)	   
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		if(atoi((char *)bufptr)==1) 		
			Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | (unsigned char )CHECK_FIRST_IN_USER_FOR_THIS_CRD ;      //SPL  Card assignment
		else
			Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday & (unsigned char)~(CHECK_FIRST_IN_USER_FOR_THIS_CRD);      //SPL  Card assignment
//================== 17 ===========	   Card Group
		if(GetDataByPosition(bufptr,buffer,17) == NULL)
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		else 
		{
			ptrdata = atoi((char *)bufptr);
			if((ptrdata >= 0) && (ptrdata < MAX_FIU_GROUPS)) 
				Carddata.Info.Group =  ptrdata;
			else
				Carddata.Info.Group =  0;
		}
 //================== 18 =========== Access Door					 //ARMF2002://Implement DoorAccess
 		if(GetDataByPosition(bufptr,buffer,18) ==NULL)					
			goto fun_NEW_CMD_ADD_CARD_ERROR;											
		Carddata.DoorAccess = atoi((char *)bufptr);
// ================== 19 ======== Set user as admin for Dual finger
		if(GetDataByPosition(bufptr,buffer,19) == NULL)
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		admin= atoi((char *)bufptr);
// ================== 20 ======== Set user as Group for Dual finger
		if(GetDataByPosition(bufptr,buffer,20) == NULL)
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		group = atoi((char *)bufptr);

		if(admin == 3)
			group = 1;
		if(group != 0)			
		{
			// indicates that we will use group functionality
	   		Carddata.Info.MesgInfo = (((admin<<5)&0x60)  + (group & 0x1F) ) | 0x80;			 
		}
		else	// indicates that Message info is used and we do not use any group functionality
			Carddata.Info.MesgInfo = msginfo;
	  }
	  else
	  		Carddata.DoorAccess = 0xFF;

// for precaution if card is added with template in sensor 
// if using protocol same card is added again then it give error cardalreadyExist
// user should del & add again 	  
	  if((cmdver == 3) || (cmdver == 4)|| (cmdver == 5)) 
	  {
		  ptrdata = CardSearch(Carddata.CardNo);
		   if((ptrdata != -1))
		   {
			   ReadCardTemplateInfoFromFlash(ptrdata,&tExtInfo);
			   cardmodify = 1;
// 			  errno = ERROR_CARD_ALREADY_EXIST;
// 			  goto fun_NEW_CMD_ADD_CARD_ERROR;
		   }
	  }
	   ptrdata = AddCard(Carddata);
	   if(ptrdata != -1)
	   {
	      if((cmdver == 0) || (cmdver == 2) || (cmdver == 3) || (cmdver == 4)|| (cmdver == 5))
	      {
		        if(GetDataByPosition(bufptr,buffer,11) == NULL)
		            goto fun_NEW_CMD_ADD_CARD_ERROR;
				memcpy((BYTE*)&tExtInfo.Name,(BYTE*)bufptr,CARD_NAME_BYTES);   // Employee Name 
								
// ================== 21 ======== Set Joining date 
			if(cmdver == 5)	
			{
				if(GetDataByPosition(bufptr,buffer,21) == NULL)	 
				{			
					if(strlen((char *)bufptr)<10)
						tExtInfo.JoiningDate =0;		// Set to zero so that we can ignore the expiary date if same is zero
				}
				if(strlen((char *)bufptr)<10)
					tExtInfo.JoiningDate =0;		// Set to zero so that we can ignore the expiary date if same is zero
				else
				{
					vDate.tm_hour  = SerialDecimalToHex(&bufptr[0]);
					vDate.tm_min   = SerialDecimalToHex(&bufptr[2]);
					vDate.tm_sec   = 59;	
					vDate.tm_mday  = SerialDecimalToHex(&bufptr[4]);
					vDate.tm_mon   = SerialDecimalToHex(&bufptr[6]);
					vDate.tm_year  = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
					vDate.tm_wday  = 0;
					if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon)==0)
						tExtInfo.JoiningDate =0;		// Zero ExpDt means do not check exp dt
					else
						tExtInfo.JoiningDate = mktime(&vDate);
				}
// ================== 22 ======== Set Birthday date 
				if(GetDataByPosition(bufptr,buffer,22) == NULL)	  //birth date
					goto fun_NEW_CMD_ADD_CARD_ERROR;
				tExtInfo.BirthDate = atoi((char *)bufptr);
				
				if(GetDataByPosition(bufptr,buffer,23) == NULL)	  //birth month
					goto fun_NEW_CMD_ADD_CARD_ERROR;
				tExtInfo.BirthMonth = atoi((char *)bufptr);
				// ================== End of 23 ====================	
				if(cardmodify == 0)  // new card add
				{	
					if(GetDataByPosition(bufptr,buffer,24) == NULL)	 
						goto fun_NEW_CMD_ADD_CARD_ERROR;				
					tExtInfo.Image_TemplateSD_Flag = atoi((char *)bufptr);
					tExtInfo.TemplateData = 0;		// NGD00024							
				}
				tExtInfo.AccessDate = 0;									
			}
			else  // in NG if we are not using LG,5 command then extra card data struct element -> 0
			{	
				if(cardmodify==0)
				{			
					tExtInfo.AccessDate = 0;		
					tExtInfo.JoiningDate =0;
					tExtInfo.BirthDate =0;
					tExtInfo.BirthMonth =0;
					tExtInfo.TemplateData = 0;	// NGD00024								
				}
				if(cardmodify == 0)
					tExtInfo.Image_TemplateSD_Flag = 0; // no template in sd & sensor 
			}			
			if(AddCardTemplateInfoToFlash(ptrdata,&tExtInfo)!=0)				
	       	{  
				errno = ERROR_MAX_CARD_REACH;
				goto fun_NEW_CMD_ADD_CARD_ERROR;
	       	}
#ifdef BIO_METRIC
			if(cmdver == 0)
			{
				if(F_BIO_COMM == SET)
				{
				   CancelBioCommand();
				   F_BIO_COMM = CLR;
				   PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT-3;
				}
				ENABLE_BIO_COMM();
				DeleteBioUserID(Carddata.CardNo);
				DISABLE_BIO_COMM();
			}
#endif
			}
      }
	   else
	   {
	      	TransmitCharToX(CARDBUFF_FULL,port);
	      	TransmitCharToX(',',port);
#ifdef EXTENDED_USER		
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	      	SendDecimalIntToX(TotalCards,port);
#endif
	      	TransmitCharToX(',',port);
	      	TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
	      	TransmitCharToX(TERMINATOR,port);
			goto fun_NEW_CMD_ADD_CARD_END;
	   }
	   TransmitCharToX(C_NEW_ADD_CARD,port);
	   TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	   SendDecimalIntToX(TotalCards,port);
#endif
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
		goto fun_NEW_CMD_ADD_CARD_END;
	}
	else if(cmdver == 10) //lG,10,x,card no,value,
	{
	   if(GetDataByPosition(bufptr,buffer,3) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	    cmdver1 = atoi((char*)bufptr);		
		if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	    var_cardno = (CARDNO_DATA_STORAGE_TYPE) StrDecToLong(bufptr,10);
		err = SearchDisplayCard(var_cardno,&Carddata);
		if(err != CARD_NOT_FOUND)
		{			
			// read extra card info 
			errno = ERROR_IMPROPER_PARAMETER ;
			ReadCardTemplateInfoFromFlash(err,&tExtInfo);
			switch(cmdver1)	
			{
				case 1:
				   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
					  goto fun_NEW_CMD_ADD_CARD_ERROR;
				   Carddata.CardPin = atoi((char *)bufptr);				
				break;
				
				case 2:
				   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
					  goto fun_NEW_CMD_ADD_CARD_ERROR;
				   Carddata.CardInfo.Door1 = atoi((char*)bufptr);					
				break;
				
				case 3:
				   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
					  goto fun_NEW_CMD_ADD_CARD_ERROR;
				   Carddata.CardInfo.Door2 = atoi((char*)bufptr);					
				break;
				
				case 4:
				   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
					  goto fun_NEW_CMD_ADD_CARD_ERROR;
				   Carddata.CardInfo.Holiday= atoi((char*)bufptr);					
				break;
				
				case 5:
				   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
					  goto fun_NEW_CMD_ADD_CARD_ERROR;
				   Carddata.Info.CType = atoi((char *)bufptr);					
				break;
				
				case 6:
				   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
						 goto fun_NEW_CMD_ADD_CARD_ERROR;
				   Carddata.CardInfo.APB = atoi((char *)bufptr);					
				break;
				
				case 7:
				   if(GetDataByPosition(bufptr,buffer,5) == NULL)
						 goto fun_NEW_CMD_ADD_CARD_ERROR;
					msginfo = atoi((char *)bufptr);
					
				break;
				
				case 8:
					if(GetDataByPosition(bufptr,buffer,5) == NULL)
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					memcpy((BYTE*)&tExtInfo.Name,(BYTE*)bufptr,CARD_NAME_BYTES);   // Employee Name 					
				break;
					
				case 9:	
#ifdef EN_CARD_EXP_DATE
					if(GetDataByPosition(bufptr,buffer,12) == NULL)	  //exp date
					{			  
						if(strlen((char *)bufptr)<10)
							Carddata.ExpDT =0;		// Set to zero so that we can ignore the expiary date if same is zero
					}
					if(strlen((char *)bufptr)<10)
						Carddata.ExpDT =0;		// Set to zero so that we can ignore the expiary date if same is zero
					else
					{
						vDate.tm_hour  = SerialDecimalToHex(&bufptr[0]);
						vDate.tm_min   = SerialDecimalToHex(&bufptr[2]);
						vDate.tm_sec   = 59;
						vDate.tm_mday  = SerialDecimalToHex(&bufptr[4]);
						vDate.tm_mon   = SerialDecimalToHex(&bufptr[6]);
						vDate.tm_year  = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
						vDate.tm_wday  = 0;
						if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon)==0)
							Carddata.ExpDT =0;		// Zero ExpDt means do not check exp dt
						else
							Carddata.ExpDT = mktime(&vDate);
					}
#endif
				break;	
					
				case 10:
				break;	
				
				case 11:
					if(GetDataByPosition(bufptr,buffer,5) == NULL)	   //dures en/ds
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					if(atoi((char *)bufptr)==1) 		//SPL  Duress assignment
						Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | (unsigned char) CARD_BIT_DURESS_CHK;      
					else
						Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday & (unsigned char)~(CARD_BIT_DURESS_CHK);      //SPL  Duress assignment
				break;	
				
				case 12:   //Special Card 
					if(GetDataByPosition(bufptr,buffer,15) == NULL)	   
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					if(atoi((char *)bufptr)==1) 		
						Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | (unsigned char )CARD_BIT_SPECIAL_CARD;      //SPL  Card assignment
					else
						Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday & (unsigned char)~(CARD_BIT_SPECIAL_CARD);      //SPL  Card assignment
				break;	
				
				case 13: // First in check
					if(GetDataByPosition(bufptr,buffer,16) == NULL)	   
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					if(atoi((char *)bufptr)==1) 		
						Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday | (unsigned char )CHECK_FIRST_IN_USER_FOR_THIS_CRD ;      //SPL  Card assignment
					else
						Carddata.CardInfo.Holiday = Carddata.CardInfo.Holiday & (unsigned char)~(CHECK_FIRST_IN_USER_FOR_THIS_CRD);      //SPL  Card assignment
				break;	

				case 14:  //  card group
					if(GetDataByPosition(bufptr,buffer,5) == NULL)
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					else 
					{
						ptrdata = atoi((char *)bufptr);
						if((ptrdata >= 0) && (ptrdata < MAX_FIU_GROUPS)) 
							Carddata.Info.Group =  ptrdata;
						else
							Carddata.Info.Group =  0;
					}
				break;	
				
				case 15: // acess door
					if(GetDataByPosition(bufptr,buffer,5) ==NULL)					
						goto fun_NEW_CMD_ADD_CARD_ERROR;											
					Carddata.DoorAccess = atoi((char *)bufptr);
				break;	
				
				case 16: //admin for dual finger
					if(GetDataByPosition(bufptr,buffer,19) == NULL)
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					admin= atoi((char *)bufptr);
				break;	
				
				case 17:// group dual user 
						if(GetDataByPosition(bufptr,buffer,20) == NULL)
							goto fun_NEW_CMD_ADD_CARD_ERROR;
						group = atoi((char *)bufptr);

						if(admin == 3)
							group = 1;
						if(group != 0)			
						{
							// indicates that we will use group functionality
							Carddata.Info.MesgInfo = (((admin<<5)&0x60)  + (group & 0x1F) ) | 0x80;			 
						}
						else	// indicates that Message info is used and we do not use any group functionality
							Carddata.Info.MesgInfo = msginfo;
	
				break;	
				
				case 18: // joining date 
					if(GetDataByPosition(bufptr,buffer,21) == NULL)	 
					{			
						if(strlen((char *)bufptr)<10)
							tExtInfo.JoiningDate =0;		// Set to zero so that we can ignore the expiary date if same is zero
					}
					if(strlen((char *)bufptr)<10)
						tExtInfo.JoiningDate =0;		// Set to zero so that we can ignore the expiary date if same is zero
					else
					{
						vDate.tm_hour  = SerialDecimalToHex(&bufptr[0]);
						vDate.tm_min   = SerialDecimalToHex(&bufptr[2]);
						vDate.tm_sec   = 59;	
						vDate.tm_mday  = SerialDecimalToHex(&bufptr[4]);
						vDate.tm_mon   = SerialDecimalToHex(&bufptr[6]);
						vDate.tm_year  = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
						vDate.tm_wday  = 0;
						if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon)==0)
							tExtInfo.JoiningDate =0;		// Zero ExpDt means do not check exp dt
						else
							tExtInfo.JoiningDate = mktime(&vDate);
					}
				break;	
			
				case 19:
					if(GetDataByPosition(bufptr,buffer,5) == NULL)	  //birth date
						goto fun_NEW_CMD_ADD_CARD_ERROR;	
					tExtInfo.BirthDate = atoi((char *)bufptr);
				break;	
				
				case 20:
					if(GetDataByPosition(bufptr,buffer,5) == NULL)	  //birth month
						goto fun_NEW_CMD_ADD_CARD_ERROR;					
					tExtInfo.BirthMonth = atoi((char *)bufptr);
				break;					
		   }
	   ptrdata = AddCard(Carddata);	    
	   ptrdata = AddCardTemplateInfoToFlash(ptrdata,&tExtInfo);				

	   TransmitCharToX(C_NEW_ADD_CARD,port);
	   TransmitCharToX(',',port);
	   SendDecimalToX(EVENT_CARD_NOT_FOUND,port);     
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
		goto fun_NEW_CMD_ADD_CARD_END;
		   
	  }
	  else
	  {
		   TransmitCharToX(C_NEW_ERROR_RETURN,port); //
		   TransmitCharToX(',',port);
#ifdef EXTENDED_USER
		   SendDecimalLongToX6digit(TotalCards,port);
#else			
		   SendDecimalIntToX(TotalCards,port);
#endif
		   TransmitCharToX(',',port);
		   TransmitCheckSumX(port);
		   TransmitCharToX(',',port);
		   TransmitCharToX(TERMINATOR,port);
			goto fun_NEW_CMD_ADD_CARD_END;
	  }	  
	  
	}
	else if(cmdver == 99)
	{
	     // Dummy fast card add with location
	      //AddCard_Loc   $1lG,99,1,Location,noofcards,chksum,enter
	   if(GetDataByPosition(bufptr,buffer,4) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   ptrdata = atoi((char *)bufptr);          // Location
	   if(GetDataByPosition(bufptr,buffer,5) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   TempTotalNosTrans = atoi((char *)bufptr);           // No of cards
	   memset((unsigned char*)&Carddata,0,sizeof(Carddata));
	   	Carddata.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;
		Carddata.CardInfo.Door1 = 1;
		Carddata.CardInfo.Door2 = 1;
		Carddata.CardInfo.Holiday = 0;
		Carddata.Info.MesgInfo = 5;
#ifdef EN_CARD_EXP_DATE
		Carddata.ExpDT = 0;
#endif
		Carddata.Info.CType = 7;
      while(1)
	   {
	      TempTotalNosTrans --;
	      if(ptrdata >= MAX_NO_OF_CARD)
	         break;
	      Carddata.CardNo = ptrdata;
	      Carddata.CardPin = ptrdata%10000;
	      AddCard_Loc(ptrdata,Carddata);
	      ptrdata++;
	      if(TempTotalNosTrans==0)
	         break;
#ifdef ENABLE_WATCHDOG
			if(ptrdata % 200 == 0)
				WDTFeed();		//Clear watchdog timer
#endif
	   }
	   TransmitCharToX(C_NEW_ADD_CARD,port);
	   TransmitCharToX(',',port);
#ifdef EXTENDED_USER
		SendDecimalLongToX6digit(TempTotalNosTrans,port);
#else			
	   SendDecimalIntToX(TempTotalNosTrans,port);
#endif
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
	   goto fun_NEW_CMD_ADD_CARD_END;
	}
   else if(cmdver ==98)
   {
	   if(GetDataByPosition(bufptr,buffer,3) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   	ptrdata = atoi((char *)bufptr);
   		TempTotalNosTrans = TestCardMgmt(ptrdata,0,0,0,port);
	   	TransmitCharToX(C_NEW_ADD_CARD,port);
	   	TransmitCharToX(',',port);
	   	SendDecimalToPC3CharToX(98,port);
	   	TransmitCharToX(',',port);
	   	TransmitCheckSumX(port);
	   	TransmitCharToX(',',port);
	   	TransmitCharToX(TERMINATOR,port);
	   	goto fun_NEW_CMD_ADD_CARD_END;

   }
   else if(cmdver ==97)//bulk card add		$1lG,97,99999,1,0,08,
   {
	   if(GetDataByPosition(bufptr,buffer,3) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   	ptrdata = atoi((char *)bufptr);	//total cards
	   	if(GetDataByPosition(bufptr,buffer,4) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
      	Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);//card number
	   	if(GetDataByPosition(bufptr,buffer,5) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;

   		TempTotalNosTrans = TestCardMgmt(ptrdata,Carddata.CardNo,atoi((char *)bufptr),0,port);
										//(total card,start card no.,0)
	  	TransmitCharToX(C_NEW_ADD_CARD,port);
	   	TransmitCharToX(',',port);
	   	SendDecimalToPC3CharToX(97,port);
	   	TransmitCharToX(',',port);
#ifdef EXTENDED_USER
		SendDecimalLongToX6digit(TempTotalNosTrans,port);
#else			
	   	SendDecimalIntToX(TempTotalNosTrans,port);
#endif
	   	TransmitCharToX(',',port);
	   	TransmitCheckSumX(port);
	   	TransmitCharToX(',',port);
	   	TransmitCharToX(TERMINATOR,port);
	   	goto fun_NEW_CMD_ADD_CARD_END;

   }
  else if(cmdver ==96)//bulk card add		$1lG,96,99999,1,0,08,
   {
	   if(GetDataByPosition(bufptr,buffer,3) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   	ptrdata = atoi((char *)bufptr);	//total cards
	   	if(GetDataByPosition(bufptr,buffer,4) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
      	Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);//card number
	   	if(GetDataByPosition(bufptr,buffer,5) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
   		TempTotalNosTrans = TestCardMgmt(ptrdata,Carddata.CardNo,atoi((char *)bufptr),0,port);
	  	TransmitCharToX(C_NEW_ADD_CARD,port);
	   	TransmitCharToX(',',port);
	   	SendDecimalToPC3CharToX(97,port);
	   	TransmitCharToX(',',port);
#ifdef EXTENDED_USER
		SendDecimalLongToX6digit(TempTotalNosTrans,port);
#else			
	   	SendDecimalIntToX(TempTotalNosTrans,port);
#endif
	   	TransmitCharToX(',',port);
	   	TransmitCheckSumX(port);
	   	TransmitCharToX(',',port);
	   	TransmitCharToX(TERMINATOR,port);
	   	goto fun_NEW_CMD_ADD_CARD_END;

   }
//==================SPL ADD====================		//281210-2
//$1lG,30,Card No, Spl Card Type, Spl Card Info, Extra Info1, Extra Info2, Extra Info3, Chksum, ENT
	else if(cmdver == 30)
	{
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		SpecialCardData.CardNo = (CARDNO_DATA_STORAGE_TYPE) StrDecToLong(bufptr,10);
		if(GetDataByPosition(bufptr,buffer,4) == NULL)
			goto fun_NEW_CMD_ADD_CARD_ERROR;
		SpecialCardData.CardType = atoi((char *)bufptr);
      	if(GetDataByPosition(bufptr,buffer,5) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
      	SpecialCardData.CardInfo = atoi((char *)bufptr);
      	if(GetDataByPosition(bufptr,buffer,6) == NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
      	SpecialCardData.ExtraInfo = atoi((char *)bufptr);
		ptrdata = AddSpecialCard(SpecialCardData); 			// Add Special card data to the flash memory
		if(ptrdata == -1)
		{
			errno =4;
			goto fun_NEW_CMD_ADD_CARD_ERROR;                // Error messg if the card not get Add properly
		}
		TransmitCharToX(C_NEW_ADD_CARD,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(TotalSplCards,port);        // total spl cards added
		TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
		TransmitCharToX(TERMINATOR,port);
		goto fun_NEW_CMD_ADD_CARD_END;
	}
	else if(cmdver < 112)
	{
	   if(GetDataByPosition(bufptr,buffer,3) ==NULL)
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE) StrDecToLong(bufptr,10);
	   ptrdata = SearchDisplayCard(Carddata.CardNo,&Carddata);
	   if(ptrdata != CARD_NOT_FOUND)
	   {
	      switch(cmdver)
	      {
	      case 8:
	         if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	            goto fun_NEW_CMD_ADD_CARD_ERROR;
//	         MsgPrint(1,Carddata.Info.CType,"OLD::AddSerialMessage:arddata.Info.CType=");
	         Carddata.Info.CType = atoi((char *)bufptr);
//	         MsgPrint(1,Carddata.Info.CType,"AddSerialMessage:arddata.Info.CType=");
	         break;
	      case 10:
	         if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	            goto fun_NEW_CMD_ADD_CARD_ERROR;
//	         MsgPrint(1,Carddata.Info.MesgInfo,"OLD::AddSerialMessage:Carddata.Info.MesgInfo=");
	         Carddata.Info.MesgInfo = atoi((char *)bufptr);
//	         MsgPrint(1,Carddata.Info.MesgInfo,"AddSerialMessage:Carddata.Info.MesgInfo=");
	         break;
				case 15:	  //$1lG,15,cardno,DUAadmin,DUAgroup,
					if(GetDataByPosition(bufptr,buffer,4) == NULL)
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					admin= atoi((char *)bufptr);
					if(GetDataByPosition(bufptr,buffer,5) == NULL)
						goto fun_NEW_CMD_ADD_CARD_ERROR;
					group = atoi((char *)bufptr);
					if(admin == 3)
						group = 1;
							
					if(group != 0)			
					{
						// indicates that we will use group functionality
				   		Carddata.Info.MesgInfo = (((admin<<5)&0x60)  + (group & 0x1F) ) | 0x80;			 
					}
					else	// indicates that Message info is used and we do not use any group functionality
						Carddata.Info.MesgInfo = msginfo;
		         break;	  
#ifdef SUPPORT_NAME_FROM_FLASH
	      case 11:
	         if(GetDataByPosition(bufptr,buffer,4) == NULL)
	            goto fun_NEW_CMD_ADD_CARD_ERROR;
	         if(AddCardNameToFlash(ptrdata,bufptr)==0)
	         {
	            TransmitCharToX(C_NEW_ADD_CARD,port);
	            TransmitCharToX(',',port);
#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(TotalCards,port);
#else			
	            SendDecimalIntToX(TotalCards,port);
#endif
	            TransmitCharToX(',',port);
	            TransmitCheckSumX(port);
	            TransmitCharToX(',',port);
	            TransmitCharToX(TERMINATOR,port);
	         }
	         else
	         {  errno =3;
	            goto fun_NEW_CMD_ADD_CARD_ERROR;
	         }
	         goto fun_NEW_CMD_ADD_CARD_END;       // As we are adding card no to flash so come out of add card
//	         break;
	      case 111:
	         if(GetDataByPosition(bufptr,buffer,4) == NULL)
	            goto fun_NEW_CMD_ADD_CARD_ERROR;
	         if(ReadCardNameFromFlash(ptrdata,bufptr)==0)
	         {
	            TransmitCharToX(C_NEW_ADD_CARD,port);
	            TransmitCharToX(',',port);
	            SendDecimalLongToX(Carddata.CardNo,port);
	            TransmitCharToX(',',port);
	            TransmitStrToX(bufptr,port);
	            TransmitCharToX(',',port);
	            TransmitCheckSumX(port);
	            TransmitCharToX(',',port);
	            TransmitCharToX(TERMINATOR,port);
	         }
	         else
	         {
            	errno =3;
	         	goto fun_NEW_CMD_ADD_CARD_ERROR;
	         }
			 goto fun_NEW_CMD_ADD_CARD_END;
//	         break;
#endif
#ifdef EN_CARD_EXP_DATE
			case 12:		// Add expiary date and Time
	   			if(GetDataByPosition(bufptr,buffer,4) == NULL)
		            goto fun_NEW_CMD_ADD_CARD_ERROR;
		        vDate.tm_hour  = SerialDecimalToHex(&bufptr[0]);
		        vDate.tm_min   = SerialDecimalToHex(&bufptr[2]);
		        vDate.tm_sec   = 59;
		        vDate.tm_mday  = SerialDecimalToHex(&bufptr[4]);
		        vDate.tm_mon   = SerialDecimalToHex(&bufptr[6]);
		        vDate.tm_year  = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
		        vDate.tm_wday  = 0;
	            if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon)==0)
		            Carddata.ExpDT =0;		// Zero ExpDt means do not check exp dt
	            else
		  			Carddata.ExpDT = mktime(&vDate);
         	break;
#endif
	      	default:
	            errno =2;
	         	goto fun_NEW_CMD_ADD_CARD_ERROR;
	      }
			if( AddCard_Loc(ptrdata,Carddata) !=-1)
         {
	         TransmitCharToX(C_NEW_ADD_CARD,port);
	         TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	         SendDecimalIntToX(TotalCards,port);
#endif
	         TransmitCharToX(',',port);
         }
	      else
	      {
	         TransmitCharToX(CARDBUFF_FULL,port);
	         TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	         SendDecimalIntToX(TotalCards,port);
#endif
	         TransmitCharToX(',',port);
	      }
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
			goto fun_NEW_CMD_ADD_CARD_END;
	   }
	   else
	   {  errno =3;
	      goto fun_NEW_CMD_ADD_CARD_ERROR;
	   }
	}
	else
		goto fun_NEW_CMD_ADD_CARD_ERROR;
fun_NEW_CMD_ADD_CARD_ERROR:
	TransmitCharToX(C_NEW_ERROR_RETURN,port);
	TransmitCharToX(',',port);
//	TransmitCharToX(errno+'0',port);
	SendDecimalToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
fun_NEW_CMD_ADD_CARD_END:
	return;
}

//------------------------------------------------------------------------------
/*** BeginHeader HandleNewSendSerialTrans*/
void HandleNewSendSerialTrans(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewSendSerialTrans(unsigned char *buffer,unsigned char port)
{
struct TRNX_DATA trans;
unsigned int TempTransReadPtr,TempTotalNosTrans,NewReadPointer;
unsigned char temp1,cmdver,errno,transDataError ;
unsigned int ptrdata;                  //shree 05Dec

	transDataError = 0;
	errno = 5;
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_C_BULK_TRNX_DWNLD;
#endif
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
        goto NEW_CMD_DUMP_TRNX_ERROR;
 	cmdver =atoi((char *)bufptr);
	switch(cmdver)
	{
	case 0:
	case 1:
	case 2:
	case 3:	//to check transaction read pointer
	{
		if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
		{
			if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
				return;
		}
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
      		goto NEW_CMD_DUMP_TRNX_ERROR;
      	ptrdata = temp1 = (unsigned char)atoi((char *)bufptr)& 0x0000FF;
		if(temp1 > 15)
			ptrdata = temp1 = 15;

		if(cmdver == 3)
		{
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
	      		goto NEW_CMD_DUMP_TRNX_ERROR;
			TempTransReadPtr = atoi((char *)bufptr);
			if(TempTransReadPtr != TransReadPtr)
			{
				errno = 3;//data incorrect
			   	goto NEW_CMD_DUMP_TRNX_ERROR;
			}
		}

		MsgPrint(1,temp1,"no of Transaction temp1");
      	TempTransReadPtr = TransReadPtr;
		TempTotalNosTrans = TotalNosOfTrans;
		PortObj[port].BufPtr=0;
		if(temp1 == 0)
		{
			TransmitReplyStartToX(port);
     		TransmitCharToX('e',port);
     		TransmitCharToX(',',port);
	   		SendDecimalToPC3CharToX(3,port);
	   		TransmitCharToX(',',port);
			TransmitCheckSumX(port);
     		TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			break;
		}
		while(1)
		{
			if(ReadCurrentTransaction(&trans) == -1)
				break;
			else
			{
	      		if((SysInfo.TransAdjMode == 1) || (SysInfo.TransAdjMode == 2))	//FA00029
	         	{
		         	if(CheckValidTrans(&trans) != 0)
		         	{
	            		if(SysInfo.TransAdjMode == 2)               //FA00029
	               		{
			               	NewReadPointer = GetNextValidTransPtr();
			               	ReadCurrentTransaction(&trans);
			               	if(NewReadPointer == 0xFFFF)
			               	{
			                  // indicates we have not received valid transaction and now total transactions is zero
			                  	transDataError = 1;
			                  	break;
			               	}
			               	transDataError = 1;
		               	}
		               	else                                        //FA00029
		               	{
		               		trans.CType = trans.Event;
		               		trans.Event = EVENT_BAD_TRNX_DATA;      //FA00050
		               	}
		         	}
	         	}
	//PANKAJXX
	         	PortObj[port].ChkSum = 0;
	         	PortObj[port].F_ChkSum = SET;
//			 	PortObj[port].BufPtr=0;
	         	TransmitReplyStartToX(port);
//	         	if( (cmdver == 1)	|| (cmdver == 3) )
//					SendSerialSendTransSaperator(&trans,port,TransReadPtr);         // FA00031
//	         	else
	         	SendNewSerialTrans(&trans,port,cmdver,TransReadPtr);            // FA00031
	     		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);	//commented for testing
#ifdef ETHERNET_OLD
		    	SendtoEthernet();
#endif
//				if(F_EthernetReceived)
//				{
//#ifdef ETHERNET
//					SendSerialDataToEthernetPort(1);		//PANKAJXX DataSocketNo
//#else
//	#ifndef TELNET_TEST
//					F_CheckSum = CLR;
//					PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
//					fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE);
//	#endif
//#endif
//					F_EthernetReceived = CLR;
//				}
				DeleteTransaction();
			}
         	temp1--;
        	if(temp1 == 0)
				break;

#ifdef ENABLE_WATCHDOG
        	if((temp1 % 50) == 0)
				WDTFeed();		//Clear watchdog timer
#endif
	}
/*	PortObj[port].ChkSum =0;
    PortObj[port].F_ChkSum =SET;
	PortObj[port].BufPtr=0;		*///  Cheksum for last response    		//PANKAJXX
  	TransmitReplyStartToX(port);
  	TransmitCharToX('G',port);
	TransmitCharToX(',',port);
  	SendDecimalIntToX((ptrdata-temp1),port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
   if(SysInfo.TransAdjMode ==1)
   {
	   if(transDataError==1)
	   {
	      if(TransReadPtr < (ptrdata- temp1))
	         TransReadPtr = (MAX_TRANS + TransReadPtr)- (ptrdata- temp1);
	      else
	         TransReadPtr = TransReadPtr - (ptrdata- temp1);
	      if( TransReadPtr > TransWritePtr)
	         TotalNosOfTrans = ( MAX_TRANS - TransReadPtr) + TransWritePtr;
	      else
	         TotalNosOfTrans = TransWritePtr-TransReadPtr;
	   }
	   else
	   {
	      TransReadPtr = TempTransReadPtr;
	      TotalNosOfTrans = TempTotalNosTrans;
	   }
   }
   else
   {
		TransReadPtr = TempTransReadPtr;
	   TotalNosOfTrans = TempTotalNosTrans;
   }
  }
  break;
  case 10:                                            //FA00031
//  $1lj,10,location,downloadtype,
//  Read transaction for given location
   if(GetDataByPosition(bufptr,buffer,3) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;
   ptrdata = atoi((char *)bufptr)& 0xFF;
	if(ptrdata >=MAX_TRANS)
   {
   	errno = 3;
	   goto NEW_CMD_DUMP_TRNX_ERROR;
   }
   if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;
   cmdver = atoi((char *)bufptr)& 0xFF;
	ReadData(ptrdata ,(unsigned char *)&trans);		 //ReadTemplateData
/*   PortObj[port].ChkSum =0;
   PortObj[port].F_ChkSum =SET;
	PortObj[port].BufPtr=0;*/ // PANKAJXX
   TransmitReplyStartToX(port);
//   if(cmdver ==1)
//		SendSerialSendTransSaperator(&trans,port,ptrdata);
//   else
   	SendNewSerialTrans(&trans,port,cmdver,ptrdata);
    TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
  break;

  case 110:
// Write Transaction to required location This is test command and should be used only for testing..
// $1ly,110,dummy,chnlno,event,cardno,HHMMSS,DDMMYY,dummy,location,dummy,dummy,chksum,
//       2  3       4      5    6      7       8      9    10

	   if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;
	   trans.Chnl = atoi((char *)bufptr);
	   if(GetDataByPosition(bufptr,buffer,5) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;
	   trans.Event = atoi((char *)bufptr);

   	if(GetDataByPosition(bufptr,buffer,6) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;
	   trans.CardNo = (CARDNO_DATA_STORAGE_TYPE) StrDecToLong(bufptr,10);

   	if(GetDataByPosition(bufptr,buffer,7) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;

      trans.Datetime.Time.Hour = SerialDecimalToHex(&bufptr[0]);
	   trans.Datetime.Time.Min  = SerialDecimalToHex(&bufptr[2]);
	   trans.Datetime.Time.Secs = SerialDecimalToHex(&bufptr[4]);

      if(GetDataByPosition(bufptr,buffer,8) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;

      trans.Datetime.Date.Day   = SerialDecimalToHex(&bufptr[0]);
	   trans.Datetime.Date.Month = SerialDecimalToHex(&bufptr[2]);
	   trans.Datetime.Date.Year  = SerialDecimalToHex(&bufptr[4]);
	   trans.CType = 0xFF;			// Just to indicate that this is test command
	   trans.InputType= 0xFF;     // Just to indicate that this is test command

      if(GetDataByPosition(bufptr,buffer,10) ==NULL)
	      goto NEW_CMD_DUMP_TRNX_ERROR;
      ptrdata =  atoi((char *)bufptr);
		if(ptrdata >=MAX_TRANS)
      {
      	errno = 3;
	      goto NEW_CMD_DUMP_TRNX_ERROR;
      }
		else
      	WriteData(ptrdata,(unsigned char *) &trans);	//WriteTemplateData
	   TransmitReplyStartToX(port);
	   TransmitCharToX(C_NEW_DUMP_TRNX,port);
	   TransmitCharToX(',',port);
	   SendDecimalToPC3CharToX(0,port);
		TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
  break;

  default:
  		goto NEW_CMD_DUMP_TRNX_ERROR;
   }
   return;
NEW_CMD_DUMP_TRNX_ERROR:
	   TransmitReplyStartToX(port);
	   TransmitCharToX('e',port);
	   TransmitCharToX(',',port);
	   SendDecimalToPC3CharToX(errno,port);
		TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
}

//------------------------------------------------------------------------------
/*** BeginHeader GetNextValidTransPtr*/
unsigned int GetNextValidTransPtr(void);
/*** EndHeader */
unsigned int GetNextValidTransPtr(void)
{
struct TRNX_DATA trans;
 	while(1)
   {
	   if(ReadCurrentTransaction(&trans) == -1)
	   {
	      return(0xFFFF);
	   }
	   else
	   {
	      if(CheckValidTrans(&trans) != 0)
	         DeleteTransaction();
	      else
	         return(TransReadPtr);
	   }
	}
}

/*** BeginHeader CheckValidTrans*/
unsigned char CheckValidTrans(struct TRNX_DATA *trans);
/*** EndHeader */
unsigned char CheckValidTrans(struct TRNX_DATA *trans)
{
	if((trans->Chnl >MAX_READERS)&&(trans->Event == 0xFF))
		return(1);
	if((trans->Datetime.Time.Hour>24)&&(trans->Datetime.Time.Min >60)&&(trans->Datetime.Time.Secs>60))
		return(2);
	if((trans->Datetime.Date.Day>31) && (trans->Datetime.Date.Month>12))
		return(3);
	return(0);
}

//------------------------------------------------------------------------------
/*** BeginHeader SendNewSerialTrans*/
void SendNewSerialTrans(struct TRNX_DATA *trans,unsigned char port,unsigned char protocolno,unsigned int readptr);
/*** EndHeader */
void SendNewSerialTrans(struct TRNX_DATA *trans,unsigned char port,unsigned char protocolno,unsigned int readptr)
{

		switch(protocolno)
      {
      case 0:
      case 1:
      case 3://ARMF0384 
      	TransmitCharToX('T',port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(trans->Chnl,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(trans->Event,port);
	      TransmitCharToX(',',port);
	      SendDecimalLongToX(trans->CardNo,port);
	      TransmitCharToX(',',port);
	      SendDecimalToX(trans->Datetime.Time.Hour,port);
	      SendDecimalToX(trans->Datetime.Time.Min,port);
	      SendDecimalToX(trans->Datetime.Time.Secs,port);
	      TransmitCharToX(',',port);
	      SendDecimalToX(trans->Datetime.Date.Day,port);
	      SendDecimalToX(trans->Datetime.Date.Month,port);
	      SendDecimalToX(trans->Datetime.Date.Year,port);
	      TransmitCharToX(',',port);
	      SendDecimalLongToX6digit(TotalNosOfTrans,port);
	      TransmitCharToX(',',port);          //PANKAJ
	      SendDecimalLongToX6digit(readptr,port);
	      TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
	      SendDecimalToPC3CharToX(trans->CType,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(trans->InputType,port);
#else
	      TransmitCharToX('0',port);
	      TransmitCharToX(',',port);
	      TransmitCharToX('0',port);
#endif
	      if(protocolno != 1)
		  {
	      		TransmitCharToX(',',port);
	      		SendDecimalIntToX(Doorinfo.ControllerNo,port);
		  }
			return;
      case 2:
	      TransmitCharToX('j',port);
	      TransmitCharToX(',',port);
	      SendDecimalIntToX(Doorinfo.ControllerNo,port);
	      TransmitCharToX(',',port);
	      break;
      default:
	      TransmitCharToX('e',port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(3,port);
      return;
		}
	SendDecimalToPC3CharToX(trans->Chnl,port);	
	TransmitCharToX(',',port);
    SendDecimalToPC3CharToX(trans->Event,port);
	TransmitCharToX(',',port);
      SendDecimalLongToX(trans->CardNo,port);
		TransmitCharToX(',',port);
      SendDecimalToX(trans->Datetime.Time.Hour,port);
      SendDecimalToX(trans->Datetime.Time.Min,port);
      SendDecimalToX(trans->Datetime.Time.Secs,port);
		TransmitCharToX(',',port);
      SendDecimalToX(trans->Datetime.Date.Day,port);
      SendDecimalToX(trans->Datetime.Date.Month,port);
      SendDecimalToX(trans->Datetime.Date.Year,port);
		TransmitCharToX(',',port);
      SendDecimalLongToX6digit(TotalNosOfTrans,port);
		TransmitCharToX(',',port);				//PANKAJ
      SendDecimalLongToX6digit(readptr,port);
		TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
      SendDecimalToPC3CharToX(trans->CType,port);
		TransmitCharToX(',',port);
      SendDecimalToPC3CharToX(trans->InputType,port);
#else
	      TransmitCharToX('0',port);
	      TransmitCharToX(',',port);
	      TransmitCharToX('0',port);
#endif
}


/*** BeginHeader HandleNewBulkCardAdd*/
void HandleNewBulkCardAdd(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewBulkCardAdd(unsigned char *buffer,unsigned char port)
{
/*
// $1lg,0,   Same as old only difference is it will not check for existing card..
// $1lg,50,NoOfCards,Cardno1,Cardno2,Cardno2,  Add multiple cards with default template
// Default template is
	if(DisplayCardNo>65535)
		Carddata.CardPin = (unsigned int)((unsigned long)DisplayCardNo%10000);
	else
		Carddata.CardPin = (unsigned int)DisplayCardNo;
	Carddata.CardInfo.APB = 0x0 ;
	Carddata.CardInfo.Door1 = 0x1 ;
	Carddata.CardInfo.Door2 = 0x1 ;
	Carddata.CardInfo.Holiday = 0x0 ;
	Carddata.Info.MesgInfo = 0;
	Carddata.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
	Carddata.ExpDT =0;
	Carddata.Name ="                 ";
*/
unsigned char ccount,cmdver,errno,noofcards,name[17],dataoffset;
int ptrdata;
#ifdef EN_CARD_EXP_DATE
	struct tm vDate;
#endif
#ifdef BIO_METRIC
//	unsigned int temp1;
#endif
CardData UserData;
CARDNO_DATA_STORAGE_TYPE cardno;

   	ccount = 0;
	errno = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto fun_NEW_BULK_ADD_CARD_ERROR;
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
		case 0:
		case 1:
#ifdef EN_CARD_EXP_DATE
			UserData.ExpDT = 0;		// Set to zero so that we can ignore the expiary date if same is zero
#endif
// Add full card data.. in case of cmdver = 0 we will add card name also + we will delete fingers from sensor.
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardPin = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,5) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.Door1 = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,6) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.Door2 = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,7) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.Holiday = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,8) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.Info.CType = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,9) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.APB = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,10) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.Info.MesgInfo = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,11) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
#ifdef EN_CARD_EXP_DATE
			if(GetDataByPosition(bufptr,buffer,12) == NULL)
			{
				if(strlen((char *)bufptr) < 10)
					UserData.ExpDT = 0;		// Set to zero so that we can ignore the expiary date if same is zero
			}
			if(strlen((char *)bufptr) < 10)
				UserData.ExpDT = 0;		// Set to zero so that we can ignore the expiary date if same is zero
         	else
			{
				vDate.tm_hour  = SerialDecimalToHex(&bufptr[0]);
				vDate.tm_min   = SerialDecimalToHex(&bufptr[2]);
				vDate.tm_sec   = 59;
				vDate.tm_mday  = SerialDecimalToHex(&bufptr[4]);
				vDate.tm_mon   = SerialDecimalToHex(&bufptr[6]);
				vDate.tm_year  = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
				vDate.tm_wday  = 0;
				if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon) == 0)
					UserData.ExpDT = 0;		// Zero ExpDt means do not check exp dt
				else
					UserData.ExpDT = mktime(&vDate);
			}
#endif
			ptrdata = AddCardAtLastAddedLoc(UserData);
			if(ptrdata != -1)
			{
				if(GetDataByPosition(bufptr,buffer,11) == NULL)
					goto fun_NEW_BULK_ADD_CARD_ERROR;
				if(AddCardNameToFlash(ptrdata,bufptr) != 0)
				{
					errno = 4;
					goto fun_NEW_BULK_ADD_CARD_ERROR;
				}
#ifdef BIO_METRIC
				if(cmdver == 0)
				{
					if(F_BIO_COMM == SET)
					{
						//temp1 = 
						CancelBioCommand();
						F_BIO_COMM = CLR;
						PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 3;
					}
					ENABLE_BIO_COMM();
					DeleteBioUserID(UserData.CardNo);
					DISABLE_BIO_COMM();
				}
#endif
			}
			else                            //shree
			{
				errno=6;
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			}
			noofcards = 1;
			TransmitCharToX(C_NEW_BULK_ADD_CARD,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX6digit(noofcards,port);
			TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
			SendDecimalIntToX(TotalCards,port);
#endif
			TransmitCharToX(',',port);
			SendDecimalLongToX6digit(LastCardAddedPtr,port);                 
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;

	case 10:
	case 11:
//           3       4     5  6   7  8   9     10   11    12   13   14
//$1lg,10,noofcards,B,cardno,pin,d1,d2,hol,ctype,apb,infomsg,name,expdate,B,cardno2,..,..,....
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		noofcards = atoi((char *)bufptr);
		if(noofcards > 15)
		{
			errno = 3;
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		}
		dataoffset = 0;
		ccount = 0;
		while(1)
		{
			if(GetDataByPosition(bufptr,buffer,4+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			if(bufptr[0] != 'B')
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			if(GetDataByPosition(bufptr,buffer,5+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			UserData.CardNo = cardno;
			if(GetDataByPosition(bufptr,buffer,6+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardPin = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,7+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.Door1 = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,8+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.Door2 = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,9+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.Holiday = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,10+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.Info.CType = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,11+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.CardInfo.APB = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,12+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			UserData.Info.MesgInfo = atoi((char *)bufptr);
			if(GetDataByPosition(name,buffer,13+dataoffset) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
#ifdef EN_CARD_EXP_DATE
			if(GetDataByPosition(bufptr,buffer,14+dataoffset) == NULL)
			{
				if(strlen((char *)bufptr) < 10)
					UserData.ExpDT = 0;      // Set to zero so that we can ignore the expiary date if same is zero
			}
			if(strlen((char *)bufptr) < 10)
				UserData.ExpDT = 0;      // Set to zero so that we can ignore the expiary date if same is zero
			else
			{
				vDate.tm_hour = SerialDecimalToHex(&bufptr[0]);
				vDate.tm_min = SerialDecimalToHex(&bufptr[2]);
				vDate.tm_sec = 59;
				vDate.tm_mday = SerialDecimalToHex(&bufptr[4]);
				vDate.tm_mon = SerialDecimalToHex(&bufptr[6]);
				vDate.tm_year = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
				vDate.tm_wday = 0;
				if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon) == 0)
					UserData.ExpDT = 0;      // Zero ExpDt means do not check exp dt
				else
					UserData.ExpDT = mktime(&vDate);
			}
#endif
			ptrdata = AddCardAtLastAddedLoc(UserData);
			if(ptrdata == 0xFFFF)
			{
				TransmitCharToX('e',port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(6,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(ccount,port);
				TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	         SendDecimalIntToX(TotalCards,port);
#endif
				TransmitCharToX(',',port);
				SendDecimalLongToX6digit(LastCardAddedPtr,port);                 //shree
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return;
			}
			ccount++;
			dataoffset = ccount * 11;
			AddCardNameToFlash(ptrdata,name);
#ifdef BIO_METRIC
			if(cmdver == 10)
			{
				if(F_BIO_COMM == SET)
				{
					//temp1 = 
					CancelBioCommand();
					F_BIO_COMM = CLR;
					PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 3;
				}
				ENABLE_BIO_COMM();
				DeleteBioUserID(UserData.CardNo);
				DISABLE_BIO_COMM();
			}
#endif
			if(ccount == noofcards)
				break;
		}
		TransmitCharToX(C_NEW_BULK_ADD_CARD,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(noofcards,port);
		TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	         SendDecimalIntToX(TotalCards,port);
#endif
		TransmitCharToX(',',port);
		SendDecimalLongToX6digit(LastCardAddedPtr,port);                 //shree
		TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
		TransmitCharToX(TERMINATOR,port);
		return;

	case 51:
#ifdef EN_CARD_EXP_DATE
   		UserData.ExpDT = 0;		// Set to zero so that we can ignore the expiary date if same is zero
#endif
// Add full card data.. in case of cmdver = 0 we will add card name also + we will delete fingers from sensor.
		errno = 2;
		ccount = 0;
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		noofcards = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,4) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		UserData.CardInfo.Door1 = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,5) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		UserData.CardInfo.Door2 = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,6) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		UserData.CardInfo.Holiday = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,7) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		UserData.Info.CType = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,8) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		UserData.CardInfo.APB = atoi((char *)bufptr);
		if(GetDataByPosition(bufptr,buffer,9) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		UserData.Info.MesgInfo = atoi((char *)bufptr);
		if(GetDataByPosition(name,buffer,10) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
#ifdef EN_CARD_EXP_DATE
      	if(GetDataByPosition(bufptr,buffer,11) == NULL)
	   	{
         	if(strlen((char *)bufptr) < 10)
				UserData.ExpDT = 0;		// Set to zero so that we can ignore the expiary date if same is zero
		}
		if(strlen((char *)bufptr) < 10)
			UserData.ExpDT = 0;		// Set to zero so that we can ignore the expiary date if same is zero
		else
		{
			vDate.tm_hour = SerialDecimalToHex(&bufptr[0]);
			vDate.tm_min = SerialDecimalToHex(&bufptr[2]);
			vDate.tm_sec = 59;
			vDate.tm_mday = SerialDecimalToHex(&bufptr[4]);
			vDate.tm_mon = SerialDecimalToHex(&bufptr[6]);
			vDate.tm_year = YEAR_BASE_VALUE + SerialDecimalToHex(&bufptr[8]);
			vDate.tm_wday = 0;
			if((vDate.tm_hour+vDate.tm_min+vDate.tm_mday+vDate.tm_mon) == 0)
				UserData.ExpDT = 0;		// Zero ExpDt means do not check exp dt
			else
				UserData.ExpDT = mktime(&vDate);
		}
#endif
		if(GetDataByPosition(bufptr,buffer,12) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		if(bufptr[0] != 'B')
		{
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		}
		if(noofcards > 50)          		//shree
		{
			errno = 3;
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		}
		dataoffset = 13;
		goto GOTO_Add_bulkCards;

	case 50:
		ccount = 0;
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		noofcards = atoi((char *)bufptr);
		if(noofcards > 50)
		{
			errno = 3;
			goto fun_NEW_BULK_ADD_CARD_ERROR;
		}
		UserData.CardInfo.APB = APB_NOWHERE_USERWISE_CHK;				//shree 18Nov 0x0 ;
		UserData.CardInfo.Door1 = 0x1;
		UserData.CardInfo.Door2 = 0x1;
		UserData.CardInfo.Holiday = 0x0;
		UserData.Info.MesgInfo = 0;
#ifdef BIO_METRIC
		UserData.Info.CType = UTYPE_CARD_OP_FIN_MUST_VERIFY;
#else
		UserData.Info.CType = UTYPE_CARD_ONLY_VERIFY;          //shree 13Oct
#endif
		UserData.ExpDT = 0;
		strncpy((char*)name,"               ",16);
		dataoffset = 4;
GOTO_Add_bulkCards:
		while(1)
		{
			if(GetDataByPosition(bufptr,buffer,dataoffset+ccount) == NULL)
				goto fun_NEW_BULK_ADD_CARD_ERROR;
			cardno = (CARDNO_DATA_STORAGE_TYPE) StrDecToLong(bufptr,10);
			UserData.CardNo = cardno;
			if(cardno > 65535)
				UserData.CardPin = (unsigned int)((long)cardno%10000);
			else
				UserData.CardPin = (unsigned int)cardno;
			ptrdata = AddCardAtLastAddedLoc(UserData);
			if(ptrdata == 0xFFFF)
			{
				TransmitCharToX('e',port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(6,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(ccount,port);
				TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	         SendDecimalIntToX(TotalCards,port);
#endif
				TransmitCharToX(',',port);
				SendDecimalLongToX6digit(LastCardAddedPtr,port);                 //shree
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				return;
			}
			ccount++;
			AddCardNameToFlash(ptrdata,name);
			if(ccount == noofcards)
				break;
		}
		TransmitCharToX(C_NEW_BULK_ADD_CARD,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(noofcards,port);
		TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(TotalCards,port);
#else			
	         SendDecimalIntToX(TotalCards,port);
#endif
		TransmitCharToX(',',port);
		SendDecimalLongToX6digit(LastCardAddedPtr,port);                 //shree
		TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
		TransmitCharToX(TERMINATOR,port);
		return;
	}
fun_NEW_BULK_ADD_CARD_ERROR:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(ccount,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(TotalCards,port);                 //shree
	TransmitCharToX(',',port);
	SendDecimalIntToX(LastCardAddedPtr,port);                  //shree
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}

//==============================================================================
#ifdef ENABLE_GSM_GPRS
/*** BeginHeader HandleModemCommands*/
void HandleModemCommands(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleModemCommands(unsigned char *buffer,unsigned char port);

void HandleModemCommands(unsigned char *buffer,unsigned char port)
{
unsigned char cmdver,errno,time,recdata[255];
//int ptrdata,errorcode;
	errno = 2;
	memset(recdata,0,sizeof(recdata));
 	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto fun_NEW_MODEM_COMMAND_ERROR;
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
   {
   	case 2:         //$1lm,2, Connect GPRS
   		InitialiseGPRS(1);
	   TransmitCharToX(C_NEW_SEND_MODEM_COMMAND,port);
	   TransmitCharToX(',',port);
	   SendDecimalIntToX(GPRSStatus,port);
	   TransmitCharToX(',',port);
	   TransmitStrToX(GPRSIPAddress,port);
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
	   return;
      case 3:			//$1lm,3, 	Disconnect GPRS
      if(port==MODEM_PORT)
      {
	      TransmitCharToX(C_NEW_SEND_MODEM_COMMAND,port);
	      TransmitCharToX(',',port);
	      SendDecimalIntToX(0,port);
	      TransmitCharToX(',',port);
	      SendDecimalIntToX(0,port);
	      TransmitCharToX(',',port);
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
      }
		F_100mSecCounterStart = SET;
		Temp_100mSec_Time_Counter = 0;
		while(Temp_100mSec_Time_Counter < 4)
		{
			#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
			#endif	
		}
		F_100mSecCounterStart = CLR;      
		time= ShutdownGPRS();
      if(port!=MODEM_PORT)
      {
	      TransmitCharToX(C_NEW_SEND_MODEM_COMMAND,port);
	      TransmitCharToX(',',port);
	      SendDecimalIntToX(GPRSStatus,port);
	      TransmitCharToX(',',port);
	      SendDecimalIntToX(time,port);
	      TransmitCharToX(',',port);
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
      }
		return;
      case 1:
	   if(GetDataByPosition(bufptr,buffer,3) ==NULL)
	      goto fun_NEW_MODEM_COMMAND_ERROR;
		time = atoi((char *)bufptr);
	   if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	      goto fun_NEW_MODEM_COMMAND_ERROR;
	   time = SendCommandToModem(bufptr,sizeof(bufptr),recdata,time);
	   TransmitCharToX(C_NEW_SEND_MODEM_COMMAND,port);
	   TransmitCharToX(',',port);
	   SendDecimalIntToX(GPRSStatus,port);
	   TransmitCharToX(',',port);
	   TransmitStrToX(recdata,port);
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
      return;
      default:
      	errno=3;
      break;
	}
fun_NEW_MODEM_COMMAND_ERROR:
	TransmitCharToX('e',port);
   TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}
#endif

//==============================================================================
/*** BeginHeader HandleNewVersionCommands*/
void HandleNewVersionCommands(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewVersionCommands(unsigned char *buffer,unsigned char port)
{
BYTE cmdver,errno,tmpcnt;
DWORD *regptr;
	errno = 2;
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto fun_NEW_NewVersion_ERROR;
	}
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
		case 5:
		// $1lv,5,key,  ;key=> numeric key=1 to 10; 11=*  ; 10=enter
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto fun_NEW_NewVersion_ERROR;
			}
			tmpcnt = atoi((char *)bufptr);
            //put key in keybuffer
			KeyBuff[KeyWritePtr++] = tmpcnt;
			if(KeyWritePtr >= 4)
				KeyWritePtr = 0;

			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			TransmitCharToX('5',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(tmpcnt,port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
		return;
		case 0:
			SendAllInfoString(port);
			return;
		case 1:
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			TransmitCharToX('1',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.MySlaveNo,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(Doorinfo.ControllerNo,port);
			TransmitCharToX(',',port);
			TransmitStrToX((BYTE *)ProdVerStr,port);   // DEFECT							//shree 26Sep
			TransmitCharToX(MAJOR_VER,port);
			TransmitCharToX('.',port);
			TransmitCharToX(MINOR_VER,port);
			TransmitChar(CONTROLLER_TYPE);						//shree 26Sep
			TransmitCharToX(',',port);
			TransmitNStrToX(ModelInfo.ModelNo,sizeof(ModelInfo.ModelNo),port);
			TransmitCharToX(',',port);
			TransmitNStrToX(ModelInfo.SerialNo,sizeof(ModelInfo.SerialNo),port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(port,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX6digit(TotalNosOfTrans,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(PercentageMem,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX6digit(TotalCards,port);
			TransmitCharToX(',',port);
			SendDecimalToX(Datetime.Time.Hour,port);
			SendDecimalToX(Datetime.Time.Min,port);
			SendDecimalToX(Datetime.Time.Secs,port);
			TransmitCharToX(',',port);
			SendDecimalToX(Datetime.Date.Day,port);
			SendDecimalToX(Datetime.Date.Month,port);
			SendDecimalToX(Datetime.Date.Year,port);
			TransmitCharToX(',',port);
			SendDecimalToX(CWeekDay,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.ControllerMode,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.SlaveType,port);
			TransmitCharToX(',',port);
			SendAsciiToX(ModelInfo.MACAddress[0],port);
			for(tmpcnt=1;tmpcnt<6;tmpcnt++)
			{
				TransmitCharToX('-',port);
   				SendAsciiToX(ModelInfo.MACAddress[tmpcnt],port);
			}
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;

		case 2:		//$1lv,2,
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendHBString(port,(char *)&SysInfo.UDP_IPAdd[0],SysInfo.UDP_PushPort);
			return;	

		case 3:                                             //shree 26Sep
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			TransmitCharToX('3',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_READERS,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_SLAVE_NO,port);
			TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(MAX_NO_OF_CARD,port);
#else			
			SendDecimalIntToX(MAX_NO_OF_CARD,port);
#endif
			TransmitCharToX(',',port);
#ifdef EXTENDED_USER
			SendDecimalLongToX6digit(MAX_TRANS,port);
#else			
			SendDecimalIntToX(MAX_TRANS,port);
#endif
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_ADMIN_USER_NEW,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_TIME_ZONE,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_HOLIDAY,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_MESSAGE_NO,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(FACILITYCODE_MAX,port);
			TransmitCharToX(',',port);
#ifdef BIO_METRIC
			SendDecimalToPC3CharToX(MAX_SEC_LEVEL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_NO_OF_SC_TEMPLATES,port);
			TransmitCharToX(',',port);
#else
			TransmitCharToX('0',port);
			TransmitCharToX(',',port);
			TransmitCharToX('0',port);
			TransmitCharToX(',',port);
#endif
			SendDecimalToPC3CharToX(MAX_ACCESS_LEVEL,port);		//Access levels
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 11:
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(11,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.ContInOut,port);            //8
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.IdentifyMode,port);         //9
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.ControllerType,port);       //10
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.InputED,port);              //14
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.InOutToggle,port);          //17
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.ChkPin,port);               //19
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(Doorinfo.CardDigit,port);           //69
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(Doorinfo.CardMask,port);            //70
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(Doorinfo.FireType,port);            //74
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 53:                                                 //A00004
		case 52:
		case 51:
		case 50:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto fun_NEW_NewVersion_ERROR;
			if(cmdver == 50)
			 	strncpy((char*)&ModelInfo.ModelNo[0],(char *)bufptr,sizeof(ModelInfo.ModelNo));
			else if(cmdver == 51)
			 	strncpy((char*)&ModelInfo.SerialNo[0],(char*)bufptr,sizeof(ModelInfo.SerialNo));
			else if(cmdver == 52)
			 	strncpy((char*)&ModelInfo.MfgDate[0],(char *)bufptr,sizeof(ModelInfo.MfgDate));
			else if(cmdver == 53)
			 	strncpy((char*)&ModelInfo.StartDate[0],(char *)bufptr,sizeof(ModelInfo.StartDate));
			else
				goto fun_NEW_NewVersion_ERROR;
			WriteModelInfoToFlash();
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 150:
			ReadModelInfoFromFlash();
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(50,port);
			TransmitCharToX(',',port);
			TransmitNStrToX(ModelInfo.ModelNo,sizeof(ModelInfo.ModelNo),port);
			TransmitCharToX(',',port);
			TransmitNStrToX(ModelInfo.SerialNo,sizeof(ModelInfo.SerialNo),port);
			TransmitCharToX(',',port);
			TransmitNStrToX(ModelInfo.MfgDate,sizeof(ModelInfo.MfgDate),port);
			TransmitCharToX(',',port);
			TransmitNStrToX(ModelInfo.StartDate,sizeof(ModelInfo.StartDate),port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;

		case 40:	  
		//$1lv,40,b1,b2,b3,b4,b5,b6,Chksum,ENT 
		//$1lv,40,0,48,108,0,0,3,
			for(tmpcnt=0;tmpcnt<6;tmpcnt++)
			{
				if(GetDataByPosition(bufptr,buffer,3+tmpcnt) == NULL)
					goto fun_NEW_NewVersion_ERROR;
				ModelInfo.MACAddress[tmpcnt] = atoi((char *)bufptr);
			}
			WriteModelInfoToFlash();
//			InitNetworkParameter();
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 140:		 
		//$1lv,140,Chksum,ENT
		//#1v,40,000,048,108,000,000,003,H,00,30,6C,00,00,03,77,
			ReadModelInfoFromFlash();
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(40,port);
			TransmitCharToX(',',port);
			for(tmpcnt=0;tmpcnt<6;tmpcnt++)
			{
				SendDecimalToPC3CharToX(ModelInfo.MACAddress[tmpcnt],port);
				TransmitCharToX(',',port);
			}
			TransmitCharToX('H',port);
			TransmitCharToX(',',port);
			for(tmpcnt=0;tmpcnt<6;tmpcnt++)
			{
   				SendAsciiToX(ModelInfo.MACAddress[tmpcnt],port);
				TransmitCharToX(',',port);
			}
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;

		case 120:		 
		//$1lv,120,address,Chksum,ENT
		//#1v,20,address,Value,77,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto fun_NEW_NewVersion_ERROR;
			regptr = (DWORD *)StrDecToLong(bufptr,10);
			if(((DWORD)regptr%4) != 0)
				goto fun_NEW_NewVersion_ERROR;
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(20,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX((DWORD)regptr,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX((DWORD)*regptr,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 121:
			// Read Utasker Stack, Heap and other values
			// Free Stack available 
			// Heap available
			// Free Heap
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(21,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(fnStackFree(),port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(fnHeapAvailable(),port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(fnHeapFree(),port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(fnPresentHeap(),port);
			TransmitCharToX(',',port);
			SendDecimalLongToX((long)&tmpcnt,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX(GetPresentHeapLocation(),port);//heap pointer
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 122://read current socket status	//ARMF0284
			//$1lv,122,Chksum,ENT
			//#1v,22,socket status,IP,port number,address,Value,77,
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(22,port);
			TransmitCharToX(',',port);

			SendDecimalToPC3CharToX(SocketStatus,port);//TCP_STATE_ESTABLISHED=176=connected;160=disconnected=TCP_STATE_LAST_ACK
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(RemoteIP[0],port);
			TransmitCharToX('.',port);
			SendDecimalToPC3CharToX(RemoteIP[1],port);
			TransmitCharToX('.',port);
			SendDecimalToPC3CharToX(RemoteIP[2],port);
			TransmitCharToX('.',port);
			SendDecimalToPC3CharToX(RemoteIP[3],port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(RemotePort,port);
			
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
		return;
		case 70:	  
				//$1lv,70,b1,b2,b3,b4,b5,b6,Chksum,ENT 
				//$1lv,70,000,039,014,049,084,166,   //dec //enter dec value only.
				//user enters hex value and s/w converts hex to dec and sends dec value from pc to unit.
				//$1lv,70,00,27,0E,31,54,A6,  //hex
			for(tmpcnt=0;tmpcnt<6;tmpcnt++)
			{
				if(GetDataByPosition(bufptr,buffer,3+tmpcnt) == NULL)
					goto fun_NEW_NewVersion_ERROR;
				ModelInfo.Server_MACAddr[tmpcnt] = (atoi((char *)bufptr));	
			}
			WriteModelInfoToFlash();
		//	InitNetworkParameter();
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		 case 170:		 
			//$1lv,170,Chksum,ENT
			//#1v,70,000,048,108,000,000,003,H,00,30,6C,00,00,03,77,
		   //#1v,70,000,039,014,049,084,166,H,00,27,0E,31,54,A6,0C,
 
			ReadModelInfoFromFlash();
			TransmitReplyStartToX(port);
			TransmitCharToX(C_NEW_VERSION_COMMAND,port);
			TransmitCharToX(',',port);
			SendDecimalToX(70,port);
			TransmitCharToX(',',port);
			for(tmpcnt=0;tmpcnt<6;tmpcnt++)
			{
				SendDecimalToPC3CharToX(ModelInfo.Server_MACAddr[tmpcnt],port);
				TransmitCharToX(',',port);
			}
			TransmitCharToX('H',port);
			TransmitCharToX(',',port);
			for(tmpcnt=0;tmpcnt<6;tmpcnt++)
			{
   				SendAsciiToX(ModelInfo.Server_MACAddr[tmpcnt],port);
				TransmitCharToX(',',port);
			}
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
		return;
   }
fun_NEW_NewVersion_ERROR:
	TransmitReplyStartToX(port);
	TransmitCharToX('e',port);
   	TransmitCharToX(',',port);
	SendDecimalIntToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}

//==============================================================================
/*** BeginHeader SendAllInfoString*/
void SendAllInfoString(unsigned char port);
/*** EndHeader */
void SendAllInfoString(unsigned char port)
{

 	TransmitReplyStartToX(port);
	TransmitCharToX(C_NEW_VERSION_COMMAND,port);
	TransmitCharToX(',',port);
	TransmitCharToX('0',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(SysInfo.MySlaveNo,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
   TransmitStrToPC((BYTE *)ProdVerStr); 							//shree 26Sep
   TransmitCharToX(MAJOR_VER,port);
   TransmitCharToX('.',port);
   TransmitCharToX(MINOR_VER,port);
   TransmitChar(CONTROLLER_TYPE);						//shree 26Sep
	TransmitCharToX(',',port);
   TransmitNStrToX(ModelInfo.ModelNo,sizeof(ModelInfo.ModelNo),port);
	TransmitCharToX(',',port);
   TransmitNStrToX(ModelInfo.SerialNo,sizeof(ModelInfo.SerialNo),port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(port,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TotalNosOfTrans,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(PercentageMem,port);
	TransmitCharToX(',',port);
#ifdef ENABLE_GSM_GPRS
   TransmitStrToX(GPRSIPAddress,port);
#else
   TransmitStrToX("0.0.0.0",port);
#endif
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);

}

//----------------------------------------------------------------------------
// following function is used to display InoutEmployee count on Serial Display module

/*** BeginHeader SendINOUTCountToDisplay*/
void SendINOUTCountToDisplay(unsigned int count,unsigned port);
/*** EndHeader */
void SendINOUTCountToDisplay(unsigned int count,unsigned port)
{
#ifdef SUPPORT_7SEG_DISPLAY
#ifdef SMART_SENSOR_DISPLAY
	TransmitCharToX('$',port);
	TransmitCharToX('1',port);
	TransmitCharToX('1',port);
	TransmitCharToX('P',port);
	TransmitCharToX((count/1000) + '0',port);
	TransmitCharToX(((count%1000)/100) + '0',port);
	TransmitCharToX((((count%1000)%100)/10) + '0',port);
	TransmitCharToX((((count%1000)%100)%10) + '0',port);
	TransmitCharToX((Doorinfo.OccupancyCount/1000) + '0',port);
	TransmitCharToX(((Doorinfo.OccupancyCount%1000)/100) + '0',port);
	TransmitCharToX((((Doorinfo.OccupancyCount%1000)%100)/10) + '0',port);
	TransmitCharToX((((Doorinfo.OccupancyCount%1000)%100)%10) + '0',port);
	TransmitCharToX('\n',port);
#else
	TransmitCharToX(STXBIGDISP,port);
	TransmitCharToX(BIGDISPADDR,port);
   TransmitCharToX(((count/1000) + '0'),port);
   TransmitCharToX(((count%1000)/100 + '0'),port);
   TransmitCharToX((((count%1000)%100)/10 + '0'),port);
   TransmitCharToX(((count%10) + '0'),port);
   SendDecimalIntToX(0,port);
	TransmitCharToX('0',port);
	TransmitCharToX('0',port);
	TransmitCharToX('0',port);
	TransmitCharToX(ETXBIGDISP,port);
#endif
#endif
}

//----------------------------------------------------------------------------
// Set new date time and get date time.
/*** BeginHeader HandleNewSetTimeDate*/
void HandleNewSetTimeDate(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewSetTimeDate(unsigned char *buffer,unsigned char port)
{
	// $1lK,1,hh,mm,ss,dd,mm,yy,ww,chksum,enter
   // $1lK,101,  To read time date
struct DATE_TIME tmpdatetime;
unsigned char cmdver,errno,temptime;

   errno=2;
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto fun_NEW_NewTimeDate_ERROR;
	cmdver = atoi((char *)bufptr);
 	TransmitReplyStartToX(port);
	switch(cmdver)
   {
   	case 1:				//ARMD0214
		if(GetDataByPosition(bufptr,buffer,3) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
		if( temptime > 23 )
			goto fun_NEW_NewTimeDate_ERROR;
      tmpdatetime.Time.Hour = temptime;

      if(GetDataByPosition(bufptr,buffer,4) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
		if( temptime > 59 )
			goto fun_NEW_NewTimeDate_ERROR;
		tmpdatetime.Time.Min  =  temptime;

		if(GetDataByPosition(bufptr,buffer,5) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
      tmpdatetime.Time.Secs = temptime;

      if(GetDataByPosition(bufptr,buffer,6) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
		if( temptime > 31 )
			goto fun_NEW_NewTimeDate_ERROR;
      tmpdatetime.Date.Day  = temptime;

      if(GetDataByPosition(bufptr,buffer,7) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
		if( temptime > 12 )
			goto fun_NEW_NewTimeDate_ERROR;
      tmpdatetime.Date.Month= temptime;

      if(GetDataByPosition(bufptr,buffer,8) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
      tmpdatetime.Date.Year = temptime;

      if(GetDataByPosition(bufptr,buffer,9) == NULL)
			goto fun_NEW_NewTimeDate_ERROR;
		temptime = atoi((char *)bufptr);
		if( temptime > 6 )
			goto fun_NEW_NewTimeDate_ERROR;
      SetRTCTimeDate(tmpdatetime,temptime);
	   TransmitCharToX(C_NEW_SET_TIME_DATE,port);
	   TransmitCharToX(',',port);
	   SendDecimalToPC3CharToX(1,port);
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
      return;
      case 101:
	   TransmitCharToX(C_NEW_SET_TIME_DATE,port);
	   TransmitCharToX(',',port);
	   SendDecimalToPC3CharToX(1,port);
	   TransmitCharToX(',',port);
      SendDecimalToPC(Datetime.Time.Hour);
		TransmitCharToX(',',port);
      SendDecimalToPC(Datetime.Time.Min);
		TransmitCharToX(',',port);
      SendDecimalToPC(Datetime.Time.Secs);
		TransmitCharToX(',',port);
      SendDecimalToPC(Datetime.Date.Day);
	   TransmitCharToX(',',port);
      SendDecimalToPC(Datetime.Date.Month);
	   TransmitCharToX(',',port);
      SendDecimalToPC(Datetime.Date.Year);
	   TransmitCharToX(',',port);
      SendDecimalToX(CWeekDay,port);
	   TransmitCharToX(',',port);
	   TransmitCheckSumX(port);
	   TransmitCharToX(',',port);
	   TransmitCharToX(TERMINATOR,port);
      return;
   }
fun_NEW_NewTimeDate_ERROR:
	TransmitCharToX('e',port);
   TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}


/*** BeginHeader HandelNewAccessLevel*/
void HandelNewAccessLevel(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandelNewAccessLevel(unsigned char *buffer,unsigned char port)
{
// $1lL,commandtype,
// $1lL,0,Accesslevelno,No of readers,tzrd1,tzrd2,tzrd3,......,tzrd16,chksum,enter
// $1lL,1,Accesslevelno,reader,timezone,chksum,enter

// $1lL,100,Accesslevelno,tzrd1,tzrd2,tzrd3,......,tzrd16,chksum,enter
// $1lL,101,Accesslevelno,tzrd1,tzrd2,tzrd3,......,tzrd16,chksum,enter
BYTE cmdver,err,alno,rdno,tzno,nodata;

	err = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto NEW_CMD_HandelNewAccessLevel;
	}
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
		case 0:	// Write time zones for all readers at a time
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			alno = atoi((char *)bufptr);
			alno--;
			if(alno >= MAX_ACCESS_LEVEL)
			{
				err = 3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			nodata = atoi((char *)bufptr);		// No of readers
			if(nodata > MAX_READERS_SUPPORT)
			{
				err = 3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			GetAccessLevel(alno,&AccessLevel);
			for(rdno=0;rdno<nodata;rdno++)
			{
				if(GetDataByPosition(bufptr,buffer,5+rdno) == NULL)
					goto NEW_CMD_HandelNewAccessLevel;
				tzno = atoi((char *)bufptr);
				AccessLevel.TimeZone[rdno] = tzno;
			}
			StoreAccessLevel(alno,&AccessLevel);
			//AccessLevelBackup();
			TransmitCharToX(C_NEW_ACCESS_LEVEL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 1:    // Set Access Level
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			alno = atoi((char *)bufptr);
			alno--;
			if(alno >= MAX_ACCESS_LEVEL)
			{
				err = 3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			rdno = atoi((char *)bufptr);
			rdno--;
			if(rdno>=MAX_READERS_SUPPORT)
			{
				err = 3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			GetAccessLevel(alno,&AccessLevel);
			if(GetDataByPosition(bufptr,buffer,5) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			tzno = atoi((char *)bufptr);
			AccessLevel.TimeZone[rdno] = tzno;
			StoreAccessLevel(alno,&AccessLevel);
			//AccessLevelBackup();
			TransmitCharToX(C_NEW_ACCESS_LEVEL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 100:    // Get All Reader AccessLevel
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			alno = atoi((char *)bufptr);
			alno--;
			if(alno >= MAX_ACCESS_LEVEL)
			{
				err = 3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			TransmitCharToX(C_NEW_ACCESS_LEVEL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(alno+1,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_READERS_SUPPORT,port);
			TransmitCharToX(',',port);
			GetAccessLevel(alno,&AccessLevel);
			for(rdno=0;rdno<MAX_READERS_SUPPORT;rdno++)
			{
				SendDecimalToPC3CharToX(AccessLevel.TimeZone[rdno],port);
				TransmitCharToX(',',port);
			}
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		case 101:    // Get One reader time zone
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			alno = atoi((char *)bufptr);
			alno--;
			if(alno >= MAX_ACCESS_LEVEL)
			{
				err =3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			if(GetDataByPosition(bufptr,buffer,4) ==NULL)
				goto NEW_CMD_HandelNewAccessLevel;
			rdno = atoi((char *)bufptr);
			rdno--;
			if(rdno >= MAX_READERS_SUPPORT)
			{
				err = 3;
				goto NEW_CMD_HandelNewAccessLevel;
			}
			TransmitCharToX(C_NEW_ACCESS_LEVEL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(alno+1,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(rdno+1,port);
			TransmitCharToX(',',port);
			GetAccessLevel(alno,&AccessLevel);
			SendDecimalToPC3CharToX(AccessLevel.TimeZone[rdno],port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
	}
NEW_CMD_HandelNewAccessLevel:
	TransmitCharToX(C_NEW_ERROR_RETURN,port);
	TransmitCharToX(',',port);
	TransmitCharToX(err+'0',port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	
	
}
#ifdef SUPPORT_NSERIES2
 /*
//Write Access Level for m No. of days. In the Access Month
//$1lN,0,AccessMonthNo,AccessDayStart(n),Count(m),ALNo(Dn),ALNo(Dn+1),............,ALNo(Dn+m),Chksum,Enter

//Set Access Level in Access Month table
//$1lN,1,AccessMonthNo,AccessDay,ALNo,Chksum,Enter

//Read All Access Level of that Month no
//$1lN,100,AccessMonthNo,Chksum,Enter
//Response from the controller
//#1N,AccessMonthNo,ALNo1(D1),ALNo2(D2),..............,ALNo(Dn),Chksum,Enter

//Get Single Access Level of Access Month
//$1lN,101,AccessMonthNo,AccessDay,Chksum,Enter
//Response from the controller
//#1N,AccessMonthNo,AccessDay,ALNo,Chksum,Enter
*/
/*** BeginHeader HandelNewAccessMonth*/
void HandelNewAccessMonth(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandelNewAccessMonth(unsigned char *buffer,unsigned char port)
{
   BYTE cmdver,errno,amno,strtdate,count,date,alno,i;

   errno = 2;
	TransmitReplyStartToX(port);
   if(GetDataByPosition(bufptr,buffer,2) == NULL)
   {
      goto NEW_CMD_HandelNewAccessMonth;
   }
   cmdver = atoi((const char*)bufptr);
   switch(cmdver)
   {
	   case 0:  //write Access Levels for multiple Dates
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto NEW_CMD_HandelNewAccessMonth;
	      amno = atoi((const char*)bufptr);    // get access month no
	      if((amno == 0) || (amno > MAX_ACCESS_MONTH_LEVEL))
	      {
	         errno = 3;
	         goto NEW_CMD_HandelNewAccessMonth;
	      }
         amno--;
         if(GetDataByPosition(bufptr,buffer,4) == NULL)
            goto NEW_CMD_HandelNewAccessMonth;
         strtdate = atoi((const char*)bufptr);   // get starting date
         if((strtdate == 0) || (strtdate > MAX_ACCESS_MONTH_DAYS))
         {
            errno = 3;
            goto NEW_CMD_HandelNewAccessMonth;
         }
         strtdate--;
         if(GetDataByPosition(bufptr,buffer,5) == NULL)
            goto NEW_CMD_HandelNewAccessMonth;
         count = atoi((const char*)bufptr);   // no of date counts
         if(count > (MAX_ACCESS_MONTH_DAYS - strtdate))
         {
            errno = 3;
            goto NEW_CMD_HandelNewAccessMonth;
         }
         GetAccessMonth(amno,&AccessMonth);
         for(date=strtdate,i=0;date<=strtdate+count;date++,i++)
         {
            if(GetDataByPosition(bufptr,buffer,6+i) == NULL)
               goto NEW_CMD_HandelNewAccessMonth;
            alno = atoi((const char*)bufptr);
	         if((alno == 0) || (alno > MAX_ACCESS_LEVEL))
	         {
	            errno = 3;
	            goto NEW_CMD_HandelNewAccessMonth;
	         }
	         alno--;
            AccessMonth.AccessMonthLevel[date] = alno;
         }
         StoreAccessMonth(amno,&AccessMonth);
        // AccessMonthBackup();
	      errno = 0;
	      TransmitCharToX(C_NEW_ACCESS_MONTH,port);
	      goto NEW_CMD_HandelNewAccessMonth_Success;

   	case 1:	//Set Single Access Level
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	      	goto NEW_CMD_HandelNewAccessMonth;
	      amno = atoi((const char*)bufptr);    // get access month no
	      if((amno == 0) || (amno > MAX_ACCESS_MONTH_LEVEL))
	      {
	         errno = 3;
	         goto NEW_CMD_HandelNewAccessMonth;
	      }
         amno--;
         if(GetDataByPosition(bufptr,buffer,4) == NULL)
            goto NEW_CMD_HandelNewAccessMonth;
         date = atoi((const char*)bufptr); // get date to store the access level
         if((date == 0) || (date > MAX_ACCESS_MONTH_DAYS))
         {
            errno = 3;
            goto NEW_CMD_HandelNewAccessMonth;
         }
         date--;
         if(GetDataByPosition(bufptr,buffer,5) == NULL)
            goto NEW_CMD_HandelNewAccessMonth;
         alno = atoi((const char*)bufptr); // get access level to set
	      if((alno == 0) || (alno > MAX_ACCESS_LEVEL))
	      {
	         errno = 3;
	         goto NEW_CMD_HandelNewAccessMonth;
	      }
	      alno--;
	      GetAccessMonth(amno,&AccessMonth);
	      AccessMonth.AccessMonthLevel[date] = alno;   // set the perticular Access level
	      StoreAccessMonth(amno,&AccessMonth);
	    //  AccessMonthBackup();
	      errno = 0;
	      TransmitCharToX(C_NEW_ACCESS_MONTH,port);
	      goto NEW_CMD_HandelNewAccessMonth_Success;

   	case 100:	// Read all Access Level of particular Month level no
         if(GetDataByPosition(bufptr,buffer,3) == NULL)
            goto NEW_CMD_HandelNewAccessMonth;
         amno = atoi((const char*)bufptr);    // get access month no
	      if((amno == 0) || (amno > MAX_ACCESS_MONTH_LEVEL))
	      {
	         errno = 3;
	         goto NEW_CMD_HandelNewAccessMonth;
	      }
	      amno--;
	      GetAccessMonth(amno,&AccessMonth);
	      TransmitCharToX(C_NEW_ACCESS_MONTH,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(amno+1,port);
	      TransmitCharToX(',',port);
	      for(date=0;date<=30;date++)
	      {
	         SendDecimalToPC3CharToX(AccessMonth.AccessMonthLevel[date]+1,port);   //ARMF0278
	         TransmitCharToX(',',port);
	      }
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
	      return;

   	case 101:	//Read Single Day Access Level
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto NEW_CMD_HandelNewAccessMonth;
	      amno = atoi((const char*)bufptr);    // get access month no
	      if((amno == 0) || (amno > MAX_ACCESS_MONTH_LEVEL))
	      {
	         errno = 3;
	         goto NEW_CMD_HandelNewAccessMonth;
	      }
	      amno--;
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	      	goto NEW_CMD_HandelNewAccessMonth;
	      date = atoi((const char*)bufptr); // get date to store the access level
	      if((date == 0) || (date > MAX_ACCESS_MONTH_DAYS))
	      {
	         errno = 3;
	         goto NEW_CMD_HandelNewAccessMonth;
	      }
	      date--;
	      GetAccessMonth(amno,&AccessMonth);
	      TransmitCharToX(C_NEW_ACCESS_MONTH,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(amno+1,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(date+1,port);
	      TransmitCharToX(',',port);
	      alno = AccessMonth.AccessMonthLevel[date];
	      SendDecimalToPC3CharToX(alno+1,port);  // send access level
	      TransmitCharToX(',',port);
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
	      return;
   }

NEW_CMD_HandelNewAccessMonth:
	TransmitCharToX(C_NEW_ERROR_RETURN,port);
NEW_CMD_HandelNewAccessMonth_Success:
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;
}
#endif
//----------------------------------------------------------------------------
/*
//$1lk,0,eventindexstart,noofevents,e1,e2,e3,e4,e5,.... e16,
  $1lk,0,16,v1,v2,v3,v4,
//$1lk,100,eventstart,noofevents,chksum,ent

//$1lk,1,eventID,data,    //set patern
//$1lk,101,eventID,chksum,ent

//$1lk,2,eventID,outtype,data[0/1],   //Set bit
//$1lk,102,eventID,outtype,chksum,ent     //not implement now

//$1lk,3,1,[0,1, 2 , 3 ,to 8],   //pattern settings for all events
//$1lk,103,1,chksum,ent           //not implement now

*/
/*** BeginHeader HandleNewIOEventCommands*/
void HandleNewIOEventCommands(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewIOEventCommands(unsigned char *buffer,unsigned char port)
{

unsigned char cmdver, errno;
unsigned char iotype, noofevents;
unsigned int eventno, i, evdata;

	errno=2;
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto fun_NEW_IOEvent_ERROR;
	cmdver = atoi((char *)bufptr);
 	TransmitReplyStartToX(port);
	switch(cmdver)
   {
	   case 0:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      eventno = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      noofevents = atoi((char *)bufptr);
	      if((noofevents > 16) || (noofevents == 0))
	      {
	         errno=3;
	         goto fun_NEW_IOEvent_ERROR;
	      }
         for(i=0;i<noofevents;i++)
         {
	         if(GetDataByPosition(bufptr,buffer,5+i) == NULL)
	            goto fun_NEW_IOEvent_ERROR;
		      evdata = atoi((char *)bufptr);
            if((eventno+i) >= MAX_EVENT_IO)
            {
		         errno=3;
            	goto fun_NEW_IOEvent_ERROR;
            }
	         IOEventInfo[(unsigned char)(eventno+i)] = evdata;
         }
         goto fun_NEW_IOEvent_SUCCESS;

	   case 1:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      eventno = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      evdata = atoi((char *)bufptr);
         if(eventno >= MAX_EVENT_IO)
         {
		   	errno=3;
            goto fun_NEW_IOEvent_ERROR;
         }
	      IOEventInfo[(unsigned char)eventno] = evdata;
         goto fun_NEW_IOEvent_SUCCESS;

	   case 2:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      eventno = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      iotype = atoi((char *)bufptr);
	      if((iotype >= 16) || (eventno >= MAX_EVENT_IO))
	      {
	         errno=3;
	         goto fun_NEW_IOEvent_ERROR;
	      }
	      if(GetDataByPosition(bufptr,buffer,5) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      i = atoi((char *)bufptr);
	      if(i == 0)
	         IOEventInfo[(unsigned char)eventno] &= ~(0x1<<iotype);    //Clear
         else if(i == 1)
	         IOEventInfo[(unsigned char)eventno] |= 0x1<<iotype;     //Set
         else
         {
	         errno=3;
	         goto fun_NEW_IOEvent_ERROR;
	     }
         goto fun_NEW_IOEvent_SUCCESS;

	   case 3:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      noofevents = atoi((char *)bufptr);
 	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      iotype = atoi((char *)bufptr);
	      if(noofevents  != 1)
         {
            errno = 3;
            goto fun_NEW_IOEvent_ERROR;
         }
         else
         {
	         switch(iotype)
	         {
	            case 0:
	               for(i=0;i<=MAX_EVENT_IO;i++)
	                  IOEventInfo[(unsigned char)i] = 0x0000;
                  goto fun_NEW_IOEvent_SUCCESS;

	            case 1:
	               for(i=0;i<=MAX_EVENT_IO;i++)
	                  IOEventInfo[(unsigned char)i] = 0x0001;
                  goto fun_NEW_IOEvent_SUCCESS;

	            default:
	               break;
	         }
         }
	      break;

      case 100:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      eventno = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      noofevents = atoi((char *)bufptr);
	      if((noofevents == 0) || (noofevents > 16) || ((eventno + noofevents) >= MAX_EVENT_IO))
	      {
	         errno=3;
	         goto fun_NEW_IOEvent_ERROR;
	      }
	      TransmitCharToX(C_NEW_IOEVENT_TYPE,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(0,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX((unsigned char)eventno,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX(noofevents,port);
	      TransmitCharToX(',',port);
         for(i=0;i<noofevents;i++)
         {
				SendDecimalIntToX(IOEventInfo[(unsigned char)eventno+i],port);
	         TransmitCharToX(',',port);
			}
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
      	return;

      case 101:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_IOEvent_ERROR;
	      eventno = atoi((char *)bufptr);
	      TransmitCharToX(C_NEW_IOEVENT_TYPE,port);
	      TransmitCharToX(',',port);
 	      SendDecimalToPC3CharToX(1,port);
	      TransmitCharToX(',',port);
	      SendDecimalToPC3CharToX((unsigned char)eventno,port);
	      TransmitCharToX(',',port);
         SendDecimalIntToX(IOEventInfo[(unsigned char)eventno],port);
         TransmitCharToX(',',port);
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
       	return;

      default:
         break;

   }

fun_NEW_IOEvent_SUCCESS:
	WriteIOEventInfoToFlash();
	TransmitCharToX(C_NEW_IOEVENT_TYPE,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;

fun_NEW_IOEvent_ERROR:
	TransmitCharToX('e',port);
   TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;

}

// $1lJ,0,ControllerEnDisValue,
// $1lJ,1,controller no , EnDis,
// $1lJ,2,              initialise device structure

// $1lJ,100,
// $1lJ,101,

// Controller En Disable
// Controller ID
// Reader 10
//$1lJ,10,readerno,DoorTime,DoTL time,DOTL Enable/Disable,SharedDOTL,FacilityCodeCheck,FreeTimeZoneENDis,FreeTimeZone,PinEnableDisable,APB EnableDisable,ReaderInOut,AreaNoFrom,AreaNoTo,
//Dead Man Zone En/Dis,DMZ_Time,DulUsrAth_Rdr,FirstInUserRule,DontDisturb,chksum,enter.
// $1lJ,110,readerno,  to read readerdata

/*** BeginHeader HandelRDControllerConfig*/
void HandelRDControllerConfig(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandelRDControllerConfig(unsigned char *buffer,unsigned char port)
{
BYTE cmdver,err,rdno;
WORD contno,tempint;
	err = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto NEW_CMD_HandelNewRdContConf;
	}
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
		case 0:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandelNewRdContConf;
			}
			tempint = atoi((char *)bufptr);
			SysInfo.ControllerEnDis = tempint;
			WriteSysInfoToFlash();
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			#ifdef RDPOLL_INCLUDE
			InitialiseDeviceStruct();
			#endif
			return;
		case 1:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandelNewRdContConf;
			}
			contno = atoi((char *)bufptr);
			if(MAX_POLL_DEVICES < contno)
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
			{
				goto NEW_CMD_HandelNewRdContConf;
			}
			rdno = atoi((char *)bufptr);
			tempint = 1;
			contno--;
			tempint = tempint << contno;
			if(rdno == 0)
			{
				SysInfo.ControllerEnDis = SysInfo.ControllerEnDis & (~tempint);
			}
			else if(rdno == 1)
			{
				SysInfo.ControllerEnDis = SysInfo.ControllerEnDis | tempint;
			}
			else
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			WriteSysInfoToFlash();
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			#ifdef RDPOLL_INCLUDE
			InitialiseDeviceStruct();  // To initialise device structure..
			#endif
			return;
		case 4:
		     
			// Command send to readr/ slave controller
			// $1lJ,4,slaveno,Command,chksum,enter { In this command we have to send , for # }
			#ifdef RDPOLL_INCLUDE
			ClearSlaveSerBuffer();
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			rdno = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto NEW_CMD_HandelNewRdContConf;						
			while(1)
			{
				if(F_PollSent == SET)
				{
					ManagePollResponse();
				}
				else
					break;
			}
			tempint = strlen((char *)bufptr);
			TransmitCharToX('$',SER_SLAVE_PORT);			
			TransmitCharToX(rdno+CNTRBASEADD,SER_SLAVE_PORT);
			for(contno=0;contno<tempint;contno++)
			{
				if(bufptr[contno] == '#')
					TransmitCharToX(',',SER_SLAVE_PORT);					
				else
					TransmitCharToX(bufptr[contno],SER_SLAVE_PORT);			
			}
			TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
			if(WaitForSlaveResponse(3) == 0)
			{
				TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
				TransmitCharToX(',',port);
				TransmitCharToX('4',port);
				TransmitCharToX(',',port);
				TransmitCharToX('{',port);
				TransmitCharToX(',',port);
				for(contno=1;contno<PortObj[SER_SLAVE_PORT].RxPtr;contno++)
				{
					if((SlaveSerBuffer[contno] == '\n') || (SlaveSerBuffer[contno] == '\r'))
						break;
					TransmitCharToX(SlaveSerBuffer[contno],port);
				}
				TransmitCharToX('}',port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
			}	
			else
			{
				goto NEW_CMD_HandelNewRdContConf;
			// Error we have not received any response from slave
			} 
			#endif
			break;
		case 5:			// To program controller door mode
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			rdno = atoi((char *)bufptr);
			if(rdno == 4)
				SysInfo.ControllerMode = rdno;
			else
			{
#ifdef BIO_METRIC
				SysInfo.ControllerMode = 2;
#else
				SysInfo.ControllerMode = 8;
#endif
				for(contno=0;contno<SysInfo.ControllerMode;contno++)	//ARMD0108
					ReaderInfo[contno].SharedDOTL = SET;
			}
			WriteSysInfoToFlash();
			WriteReaderInfoToFlash();
			#ifdef RDPOLL_INCLUDE
			F_UpdateSlaveInfo = SET;
			InitialiseDeviceStruct();  // To initialise device structure..
			#endif
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			break;
	
		case 105:
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.ControllerMode,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			break;
	
		case 6:			// To program controller door mode
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			rdno = atoi((char *)bufptr);
			if(rdno == 1)
				SysInfo.SlaveType = rdno;
			else
				SysInfo.SlaveType = 2;
			WriteSysInfoToFlash();
			#ifdef RDPOLL_INCLUDE
			InitialiseDeviceStruct();  // To initialise device structure..
			#endif
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			break;
	
		case 106:
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(SysInfo.SlaveType,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			break;
	
		case 100:
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX(SysInfo.ControllerEnDis,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(MAX_POLL_DEVICES,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
	
		case 101:	   
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandelNewRdContConf;
			}
			contno =  atoi((char *)bufptr);
			contno--;
			if(MAX_POLL_DEVICES <= contno)
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			tempint = 0x0001;
			tempint = tempint << contno;
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(contno+1,port);
			TransmitCharToX(',',port);
			if(tempint & SysInfo.ControllerEnDis)
			{
				TransmitCharToX('1',port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].ActualStatus,port);
			}
			else
			{
				TransmitCharToX('0',port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(0,port);
			}
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
	
		case 102:	//$1lJ,102,ControllerNo,Chksum,Ent	   
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandelNewRdContConf;
			}
			contno =  atoi((char *)bufptr);
			contno--;
			if(MAX_POLL_DEVICES <= contno)
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			tempint = 0x0001;
			tempint = tempint << contno;
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(contno+1,port);
			TransmitCharToX(',',port);
			if(tempint & SysInfo.ControllerEnDis)
			{
				TransmitCharToX('1',port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].ActualStatus,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].ID,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].Type,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].TimeOut,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].EnDis,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].NoRd,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].RdOffset,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].Status,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(PollDevices[contno].RCount,port);
			}
			else
			{
				TransmitCharToX('0',port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(0,port);
			}
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
	
		case 10:
			// $1lJ,10,readerno,DoorTime,DoTL time,DOTL Enable/Disable,SharedDOTL,FacilityCodeCheck,FreeTimeZoneENDis,FreeTimeZone,PinEnableDisable,APB EnableDisable,ReaderInOut,AreaNoFrom,AreaNoTo,
		    //	Dead Man Zone En/Dis,DMZ_Time,DulUsrAth_Rdr,FirstInUserRule,DontDisturb,DISGrp,chksum,enetr
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			 goto NEW_CMD_HandelNewRdContConf;
			rdno =  atoi((char *)bufptr);
			if((rdno > MAX_READERS_SUPPORT) || (rdno == 0))   
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			rdno--;
			ReadReaderInfoFromFlash();
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].DOpTime = atoi((char *)bufptr);
			if(ReaderInfo[rdno].DOpTime == 0)
				ReaderInfo[rdno].DOpTime = 1;
			if(GetDataByPosition(bufptr,buffer,5) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].DOTLTime = atoi((char *)bufptr);
			if(ReaderInfo[rdno].DOTLTime == 0)
				ReaderInfo[rdno].DOTLTime = 1;
			if(GetDataByPosition(bufptr,buffer,6) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].DOTLEn_Dis = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,7) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].SharedDOTL = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,8) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].FacCheck = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,9) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].FreeTZEnDis = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,10) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].FreeTZ = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,11) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].PinEnDis = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,12) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].APBEnDis = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,13) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].RDInOut = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,14) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].AreaNoFrom = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,15) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].AreaNoTo = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,16) == NULL)
         		ReaderInfo[rdno].DeadManZoneEnDis = 0x00;
            else
				ReaderInfo[rdno].DeadManZoneEnDis = atoi((char *)bufptr);
			DeadMenZoneMinCounter = 0;			//need to RESET COUNTER	WHEN SET DMZ READERWISE
			DMZMinCounter = 0;
		    if(GetDataByPosition(bufptr,buffer,17) == NULL)
				ReaderInfo[rdno].DMZ_Time = 0x00;
			else 
				ReaderInfo[rdno].DMZ_Time = atoi((char *)bufptr);
			if(ReaderInfo[rdno].DMZ_Time < 10)
				ReaderInfo[rdno].DMZ_Time = 10;
			if(GetDataByPosition(bufptr,buffer,18) == NULL)
				ReaderInfo[rdno].DulUsrAth_Rdr = 0x00;
            else ReaderInfo[rdno].DulUsrAth_Rdr = atoi((char *)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,19) == NULL)
		    	ReaderInfo[rdno].FirstInUserRule = 0x00;
            else ReaderInfo[rdno].FirstInUserRule = atoi((char *)bufptr);
			
            if(GetDataByPosition(bufptr,buffer,20) == NULL)
		    	ReaderInfo[rdno].DontDisturb = 0x00;
            else ReaderInfo[rdno].DontDisturb = atoi((char *)bufptr);

		   	if(GetDataByPosition(bufptr,buffer,21) == NULL)
		    	ReaderInfo[rdno].DNDTZ = 0x00;
            else ReaderInfo[rdno].DNDTZ = atoi((char *)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,22) == NULL)			//ARMF2001: //Implement DIS
				ReaderInfo[rdno].DISGrp = 0x00;
			if(ReaderInfo[rdno].DISGrp > MAXDISGRP)
			   	ReaderInfo[rdno].DISGrp = 0;



			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			WriteReaderInfoToFlash();
			#ifdef RDPOLL_INCLUDE
			F_UpdateSlaveInfo = SET;
			InitialiseDeviceStruct();
			#endif
			break;
		case 110:
		// $1lJ,110,readerno,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			rdno =  atoi((char *)bufptr);
			if((rdno > MAX_READERS_SUPPORT) || (rdno == 0)) 			
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			rdno--;
			ReadReaderInfoFromFlash();
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(rdno+1,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].DOpTime,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].DOTLTime,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].DOTLEn_Dis,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].SharedDOTL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].FacCheck,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].FreeTZEnDis,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].FreeTZ,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].PinEnDis,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].APBEnDis,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].RDInOut,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].AreaNoFrom,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].AreaNoTo,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].DeadManZoneEnDis,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].DMZ_Time,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);//not reader wise
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
            SendDecimalToPC3CharToX(ReaderInfo[rdno].DNDTZ,port);//not reader wise,but reader 1 data is used for processing
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);				//ARMF2001: //Implement DIS		  
			TransmitCharToX(',',port);								 
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			break;

		case 11:   // To set reader wise controller mode 
		// $1lJ,11,readerno,CntrolrType,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			 goto NEW_CMD_HandelNewRdContConf;
			rdno =  atoi((char *)bufptr);
			if((rdno > MAX_READERS_SUPPORT) || (rdno == 0))   
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			rdno--;
			ReadReaderInfoFromFlash();
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			ReaderInfo[rdno].CntrolrType = atoi((char *)bufptr);

			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);

			SysInfo.ControllerType = ReaderInfo[0].CntrolrType;
			WriteSysInfoToFlash();
			WriteReaderInfoToFlash();
#ifdef RDPOLL_INCLUDE
			F_UpdateSlaveInfo = SET;
			InitialiseDeviceStruct();
#endif
			break;
			 
		case 111:
		// $1lJ,111,readerno,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_HandelNewRdContConf;
			rdno =  atoi((char *)bufptr);
			if((rdno > MAX_READERS_SUPPORT) || (rdno == 0)) 			
			{
				err = 3;
				goto NEW_CMD_HandelNewRdContConf;
			}
			rdno--;
			ReadReaderInfoFromFlash();
			TransmitCharToX(C_NEW_RD_CONT_CONFIG,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(rdno+1,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(ReaderInfo[rdno].CntrolrType,port);
			TransmitCharToX(',',port);

			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
		break;

	}
	return;
NEW_CMD_HandelNewRdContConf:
	TransmitCharToX(C_NEW_ERROR_RETURN,port);
	TransmitCharToX(',',port);
	TransmitCharToX(err+'0',port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}
//=================================================================================
/*
$1lO,opentype,doorno,opentime,dotltime,chksum,enter
// $1lO,0,chnlno,optime,dotltime,chksum,enter
// $1lO,1,chnlno,  // Door full open
// $1lO,2,chnlno,  // Door close
// $1lO,3,chnlno,  // Door Normal


$1lO,110,
#1O,10,Fire,Tamper,Intrusion,I1,I2,I3,I4,

$1lO,111,noofdoors,
#1O,11,noofdoors,Doorno,MCStatus,Door Status,Current Relay Status,Other1,Other2,Doorno,Door Status,Current Relay Status,,Other1,Other2....


Read Controller Input conditions like
Fire, Intrusion, Tamper,Input1, Input2, 
Door Specific
MC contact, Door Status, Current Door Relay Status, 


*/
/*** BeginHeader SerialHandleDoorOpen*/
void SerialHandleDoorOpen(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void SerialHandleDoorOpen(unsigned char *buffer,unsigned char port)
{
BYTE chno,cmdver,err,doorno,dotltime,opentime,i,success,setclr,alarmno,rstalarmno;
	success = 0;
	err =2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto NEW_CMD_HandleDoorOpen;
	}
    cmdver = atoi((char *)bufptr);
#ifndef SUPPORT_ONLY_2_DOOR
#ifdef SLAVE_CONTROLLERS
       	if((doorno>=2)&&((cmdver==1)||(cmdver==2)||(cmdver==3)))
      	{
	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	{
		goto NEW_CMD_HandleDoorOpen;
	}
	doorno = atoi((char *)bufptr);
    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
    {
    	err=3;
        goto NEW_CMD_HandleDoorOpen;
	}
   	doorno = doorno-1;
			if(SendDoorCommand(ReaderInfo[doorno].SlaveContNo,cmdver,ReaderInfo[doorno].DoorNo,0,0,0) == 0)
	        	err=0;
			else
			{
            	err =4;
				goto NEW_CMD_HandleDoorOpen;
			}
            goto OK_HandleDoorOpen;
        }
#endif
#endif
         switch(cmdver)
         {
	      case 0:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandleDoorOpen;
			}
			doorno = atoi((char *)bufptr);
		    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
		    {
		    	err=3;
		        goto NEW_CMD_HandleDoorOpen;
			}
		   	doorno = doorno-1;
	         if(GetDataByPosition(bufptr,buffer,4) == NULL)
	            goto NEW_CMD_HandleDoorOpen;
	         opentime = atoi((char *)bufptr);
	         if(GetDataByPosition(bufptr,buffer,5) == NULL)
	            goto NEW_CMD_HandleDoorOpen;
	         dotltime = atoi((char *)bufptr);
	         if(GetDataByPosition(bufptr,buffer,6) == NULL)
	            chno = 0;
	         else
	            chno = atoi((char *)bufptr)-1;
#ifndef SUPPORT_ONLY_2_DOOR
	         if(doorno==0 || doorno==1)
#endif
	            {
//#ifdef SUPPORT_NSERIES2
    //     			if(DoorInterlockCheck(doorno) == 0)	//ARMF0247 
//#endif
						DoorConditionControl(doorno,DR_ACCESS_OPEN,opentime,dotltime);
				}
#ifndef SUPPORT_ONLY_2_DOOR
#ifdef SLAVE_CONTROLLERS
	         else
	         if(SendDoorCommand(ReaderInfo[doorno].SlaveContNo,cmdver,ReaderInfo[doorno].DoorNo,opentime,dotltime,chno-2) ==0)
	            err=0;
	         else
	         {
	            err =4;
	            goto NEW_CMD_HandleDoorOpen;
	         }
#endif
#endif
	      break;
	      case 1:
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				doorno = atoi((char *)bufptr);
			    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
			    {
			    	err=3;
			        goto NEW_CMD_HandleDoorOpen;
				}
			   	doorno = doorno-1;
//#ifdef SUPPORT_NSERIES2
       //  		if(DoorInterlockCheck(doorno) == 0)	//ARMF0247 
//#endif
	            //	DoorConditionControl(doorno,DR_USER_OPEN,opentime,dotltime);
					DoorConditionControl(doorno,DR_PC_USER_OPEN,opentime,dotltime);	  
	         break;
	      case 2:
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				doorno = atoi((char *)bufptr);
			    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
			    {
			    	err=3;
			        goto NEW_CMD_HandleDoorOpen;
				}
			   	doorno = doorno-1;
	           // DoorConditionControl(doorno,DR_USER_CLOSE,opentime,dotltime);
			   DoorConditionControl(doorno,DR_PC_USER_CLOSE,opentime,dotltime);
	         break;
	      case 3:
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				doorno = atoi((char *)bufptr);
			    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
			    {
			    	err=3;
			        goto NEW_CMD_HandleDoorOpen;
				}
			   	doorno = doorno-1;
	            //DoorConditionControl(doorno,DR_NORMAL,opentime,dotltime);	 
	            DoorConditionControl(doorno,DR_PC_NORMAL,opentime,dotltime);	 //ARMF2011

	         break;

			case 4:	// Extra relay Open 
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				doorno = atoi((char *)bufptr);
			    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
			    {
			    	err=3;
			        goto NEW_CMD_HandleDoorOpen;
				}
			   	doorno = doorno-1;
	           // DoorConditionControl(doorno,DR_USER_CLOSE,opentime,dotltime);
//			   DoorConditionControl(doorno,DR_PC_USER_CLOSE,opentime,dotltime);
				DoorOpen(doorno);
	         break;

			case 5:	// Extra relay Close
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				doorno = atoi((char *)bufptr);
			    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
			    {
			    	err=3;
			        goto NEW_CMD_HandleDoorOpen;
				}
			   	doorno = doorno-1;
	           // DoorConditionControl(doorno,DR_USER_CLOSE,opentime,dotltime);
//			   DoorConditionControl(doorno,DR_PC_USER_CLOSE,opentime,dotltime);
				DoorClose(doorno);
	         break;

	   	case 20:
//$1lO,20,alarmno,setclr, ==> $1lO,20,1,1, ==>	where Last number 0=CLR/1=SET
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandleDoorOpen;
			}
			alarmno = atoi((char *)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
	            goto NEW_CMD_HandleDoorOpen;
	         setclr = atoi((char *)bufptr);

			for(i=0;i<MAX_ALARMS;i++)
			{
				if(AlarmValues[i].AlarmNo == alarmno)
				{
					AlarmGenerateFlg[i] = setclr;
			   	}
			}
			if(AlarmGenerateFlg[5] == CLR)
			{
				F_DeadManZone= CLR;
			}
		break;

		case 21:
//$1lO,21,rstalarmno, ==> $1lO,21,1, ==>	where Last number is alrm no to be Cleared/ACK.
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandleDoorOpen;
			}
			rstalarmno = atoi((char *)bufptr);
			
			for(i=0;i<MAX_ALARMS;i++)
			{
				if(AlarmValues[i].AlarmNo == rstalarmno)
				{
					AlarmACKFlg[i] = SET;
			   	}
			}
			if((rstalarmno == 32)||(rstalarmno== 33))
				DRStruct[0].ResetAlarm = SET;

			else if(rstalarmno == 34)
				F_DeadManZone = CLR;
				DeadMenZoneMinCounter = 0;
				DMZMinCounter = 0;
		break;

		case 120:
//$1lO,120,		
			TransmitCharToX(C_NEW_UNLOCK_DOOR,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(20,port);
			TransmitCharToX(',',port);
		
			for(i=0;i<MAX_ALARMS;i++)
			{
				if(*AlarmValues[i].AlPtr == AlarmValues[i].ALCond)
				   	success++;  
			}
			SendDecimalToPC3CharToX(success,port);
			TransmitCharToX(',',port);	
		
			for(i=0;i<MAX_ALARMS;i++)
			{
				if(*AlarmValues[i].AlPtr == AlarmValues[i].ALCond)
				{
					SendDecimalToX(AlarmValues[i].AlarmNo,port);	
					TransmitCharToX(',',port);
				}
			}
//				TransmitCharToX('0',port);
//   			TransmitCharToX(',',port);
//				TransmitCharToX('0',port);
//   			TransmitCharToX(',',port);	
		   	TransmitCheckSumX(port);
		   	TransmitCharToX(',',port);
		   	TransmitCharToX(TERMINATOR,port);
	  		return;

		  case 110:
//#1O,10,Fire status,Intruson Status,Tamper Status,Transaction Full,Other1,Other2,Other3,chksum,enter
	  	 	TransmitCharToX(C_NEW_UNLOCK_DOOR,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(10,port);
			TransmitCharToX(',',port);
			TransmitCharToX(FIRE_STATUS+'0',port);	
			TransmitCharToX(',',port);
			TransmitCharToX(INTRUSION_STATUS+'0',port);
			TransmitCharToX(',',port);
			TransmitCharToX(TAMPER_STATUS+'0',port);
			TransmitCharToX(',',port);
			TransmitCharToX(F_TrnxMemFull+'0',port);
			TransmitCharToX(',',port);	
			TransmitCharToX('0',port);
			TransmitCharToX(',',port);	
			TransmitCharToX('0',port);
			TransmitCharToX(',',port);	
			TransmitCharToX('0',port);
			TransmitCharToX(',',port);	
		   	TransmitCheckSumX(port);
		   	TransmitCharToX(',',port);
		   	TransmitCharToX(TERMINATOR,port);
	  		return;
		  case 111:
//#1O,11,noofdoors,D,Doorno,MCStatus,Door Egress,Door Status,Current Relay Status,Door Alarm,Card No,FC Code,Other1,Other2,Other3,D,Doorno,MCStatus,Door Egress,Door Status,Current Relay Status,Door Alarm,Card No,FC Code,Other1,Other2,Other3,.....
/*
Door statuis ==> 
#define DR_NORMAL				0
#define DR_EGRESS_OPEN			1
#define DR_ACCESS_OPEN			2
#define DR_TZ_OPEN				3
#define DR_FIRE_OPEN			4
#define DR_USER_OPEN			5
#define DR_USER_CLOSE			6
#define DR_INTRUSION_CLOSE 		7   //F0011 Checking of Intrusion Alarm
#define DR_EXT_RLY_ON			8

*/
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
			{
				goto NEW_CMD_HandleDoorOpen;
			}
			doorno = atoi((char *)bufptr);
		    if((doorno ==0)||(doorno>SysInfo.ControllerMode))
		    {
		    	err=3;
		        goto NEW_CMD_HandleDoorOpen;
			}
		   	doorno = doorno-1;
			if(doorno>=MAX_LOCAL_DOORS)
				goto NEW_CMD_HandleDoorOpen;
	  	 	TransmitCharToX(C_NEW_UNLOCK_DOOR,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(11,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(doorno+1,port);	
			TransmitCharToX(',',port);
			for(dotltime=0;dotltime<doorno;dotltime++)
			{					
				TransmitCharToX('D',port);
				SendDecimalToPC3CharToX(dotltime+1,port);	
				TransmitCharToX(',',port);
   				TransmitCharToX(DRStruct[dotltime].DRMCStatus+'0',port);		// Door MC Status
				TransmitCharToX(',',port);
				TransmitCharToX(DRStruct[dotltime].DREgressStatus+'0',port);		// Door Egress
				TransmitCharToX(',',port);
				TransmitCharToX(DRStruct[dotltime].DRStatus+'0',port);		// 
				TransmitCharToX(',',port);												
   				TransmitCharToX(DRStruct[dotltime].DRCurrentStatus+'0',port);		// Door Relay Open =1 Door Close =0
				TransmitCharToX(',',port);
				if(DRStruct[dotltime].Dotl_Alarm)							
   					TransmitCharToX(1+'0',port);									
				else if(DRStruct[dotltime].Force_Alarm)
   					TransmitCharToX(2+'0',port);
				else 
					TransmitCharToX('0',port);			// 1= DORL Alarm, 2 = Door Force Alarm, 0 = no alarm
				TransmitCharToX(',',port);
				SendDecimalLongToX(DRStruct[dotltime].LastCardNo,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(DRStruct[dotltime].FCode,port);
				TransmitCharToX(',',port);
				TransmitCharToX('0',port);
   				TransmitCharToX(',',port);	
				TransmitCharToX('0',port);
   				TransmitCharToX(',',port);	
				TransmitCharToX('0',port);
   				TransmitCharToX(',',port);	

			}
		   	TransmitCheckSumX(port);
		   	TransmitCharToX(',',port);
		   	TransmitCharToX(TERMINATOR,port);
	  		return;
			
			case 30:   	//$1lO,30,soundtype,time,	//ARMF2007
			//// Make Sound For Controller detection
/*
#define SOUND_CARD_FOUND		30
#define SOUND_USER_MESSAGE		25
#define SOUND_SYS_ERROR			50
#define SOUND_KEY_PRESS			5
#define SOUND_USER_ERROR		20
#define TIME_SOUND_DOUBL_BEEP	15
*/
				if(GetDataByPosition(bufptr,buffer,3) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				doorno = atoi((char *)bufptr);	//soundtype

				if(GetDataByPosition(bufptr,buffer,4) == NULL)
				{
					goto NEW_CMD_HandleDoorOpen;
				}
				if(doorno == 0)
					dotltime = 0;					  //time
				else
					dotltime = atoi((char *)bufptr);

				if(doorno == 1)
					doorno = TIME_SOUND_DOUBL_BEEP;

				MakeSoundForTime(dotltime,doorno);
			break; 

      default:
         goto NEW_CMD_HandleDoorOpen;
		}

   TransmitCharToX(C_NEW_UNLOCK_DOOR,port);
   TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(0,port);
   TransmitCharToX(',',port);
   TransmitCheckSumX(port);
   TransmitCharToX(',',port);
   TransmitCharToX(TERMINATOR,port);
   return;

NEW_CMD_HandleDoorOpen:
   TransmitCharToX(C_NEW_ERROR_RETURN,port);
   TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(err,port);
   TransmitCharToX(',',port);
   TransmitCheckSumX(port);
   TransmitCharToX(',',port);
   TransmitCharToX(TERMINATOR,port);
   return;
}


//----------------------------------------------------------------------------
/*
Set holiday
$1lP,1,ReaderNo,location,DD,MM,YY,Chksum,ENT
#1P,001,73,
ReaderNo = 1 to 2
location = 1 to 42

Get holiday
$1lP,101,ReaderNo,location,Chksum,ENT
location = 1 to 42
#1P,ReaderNo,Location,DD,MM,YY,Chksum,

//Bulk Holiday set
$1lP,2,ReaderNo,1,DDMMYY,2,DDMMYY, ........
#1P,001,73,

//Bulk holiday get
$1lP,102,Reader No,
#1P,ReaderNo,Location1,DD1MM1YY1,Location2,DD1MM1YY1,Location42,DD42MM42YY42,Chksum,
*/
/*** BeginHeader HandleNewHolidaySettings*/
void HandleNewHolidaySettings(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewHolidaySettings(unsigned char *buffer,unsigned char port)
{

unsigned char cmdver, errno;
unsigned char rdrno, tempdate;
unsigned int loc; // hdaystart, hdayend;

	errno = 2;
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto fun_NEW_Holiday_ERROR;
	cmdver = atoi((char *)bufptr);
 	TransmitReplyStartToX(port);
	switch(cmdver)
   	{
	   	case 1:
	    	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	rdrno = atoi((char *)bufptr);
     		if((rdrno > MAX_READERS) || (rdrno == 0))
	      	{
	         	errno = 3;
	         	goto fun_NEW_Holiday_ERROR;
	      	}
         	rdrno--;
	      	if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	loc = atoi((char *)bufptr);
	      	if((loc > MAX_RDR_HOLIDAY) || (loc == 0))
	      	{
	         	errno = 3;
	         	goto fun_NEW_Holiday_ERROR;
	      	}
         	loc--;
//         	loc = (MAX_RDR_HOLIDAY * rdrno) + loc;
	      	if(GetDataByPosition(bufptr,buffer,5) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	tempdate = atoi((char *)bufptr);
	      	StrHoliday.Day  = tempdate;
	      	if(GetDataByPosition(bufptr,buffer,6) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	tempdate = atoi((char *)bufptr);
	      	StrHoliday.Month = tempdate;
	      	if(GetDataByPosition(bufptr,buffer,7) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	tempdate = atoi((char *)bufptr);
	      	StrHoliday.Year = tempdate;
		  	StoreHoliday(loc,rdrno,&StrHoliday);
//         	root2xmem((unsigned long)HOLIDAY_BASE+(unsigned long)((unsigned long)loc *(unsigned long)sizeof(StrHoliday)),(unsigned char *)&Holiday, sizeof(Holiday));
//         	HolidayBackup();
	      	TransmitCharToX(C_NEW_HOLIDAY,port);
	      	TransmitCharToX(',',port);
	      	SendDecimalToPC3CharToX(1,port);
	      	TransmitCharToX(',',port);
	      	TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
	      	TransmitCharToX(TERMINATOR,port);
	      	return; 
     case 101:
	      	if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	rdrno = atoi((char *)bufptr);
         	if((rdrno > MAX_READERS) || (rdrno == 0))
	      	{
	         	errno = 3;
	         	goto fun_NEW_Holiday_ERROR;
	      	}
         	rdrno--;
	      	if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         	goto fun_NEW_Holiday_ERROR;
	      	loc = atoi((char *)bufptr);
			if((loc > 0) && (loc <= MAX_RDR_HOLIDAY))
         	{
         		loc--;
		  		GetHoliday(loc,rdrno,&StrHoliday);
		        TransmitCharToX(C_NEW_HOLIDAY,port);
		      	TransmitCharToX(',',port);
		      	SendDecimalToPC3CharToX((unsigned char)rdrno+1,port);
		      	TransmitCharToX(',',port);
		      	SendDecimalToPC3CharToX(loc+1,port);
		      	TransmitCharToX(',',port);
	   	      	SendDecimalToPC(StrHoliday.Day);
		      	TransmitCharToX(',',port);
	      	   	SendDecimalToPC(StrHoliday.Month);
		      	TransmitCharToX(',',port);
	         	SendDecimalToPC(StrHoliday.Year);
		        TransmitCharToX(',',port);
         	}
	      	else
	      	{
	         	errno = 3;
	         	goto fun_NEW_Holiday_ERROR;
	      	}
	      	TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
	      	TransmitCharToX(TERMINATOR,port);
       		return;
     	case 102:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_Holiday_ERROR;
	      rdrno = atoi((char *)bufptr);
         if((rdrno > MAX_READERS) || (rdrno == 0))
	      {
	         errno = 3;
	         goto fun_NEW_Holiday_ERROR;
	      }
         rdrno--;
         TransmitCharToX(C_NEW_HOLIDAY,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX((unsigned char)rdrno+1,port);
         TransmitCharToX(',',port);
         for(loc=0;loc<MAX_RDR_HOLIDAY;loc++)
         {
//            xmem2root(&Holiday,HOLIDAY_BASE+(loc*sizeof(Holiday)), sizeof(Holiday));
		  	GetHoliday(loc,rdrno,&StrHoliday);
            SendDecimalToPC3CharToX((unsigned char)(loc+1),port);
            TransmitCharToX(',',port);
            SendDecimalToPC(StrHoliday.Day);
            SendDecimalToPC(StrHoliday.Month);
            SendDecimalToPC(StrHoliday.Year);
            TransmitCharToX(',',port);
         }
	      TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
	      TransmitCharToX(TERMINATOR,port);
       	return;

      default:
         break;

   }

fun_NEW_Holiday_ERROR:
	TransmitCharToX('e',port);
   TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;


}

//----------------------------------------------------------------------------
/*** BeginHeader HandleNewDelDumpTRnx*/
void HandleNewDelDumpTRnx(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewDelDumpTRnx(unsigned char *buffer,unsigned char port)
{
unsigned int TempTotalNosTrans;
unsigned char cmdver,errno;
int ptrdata,temp1;
//struct TRNX_DATA trans;

	errno = 5;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto NEW_CMD_DEL_DUMP_TRNX_ERROR;
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
		case 1:      //$1lB,1,DeleteTrnxCount,Chksum,ENT
		case 2:      //$1lB,2,DeleteTrnxCount,read pointer,Chksum,ENT	 //ARMF0384 
					 //$1lB,2,2,268,
	      if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
	      {
	         if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
	            return;
	      }
//NEW_CMD_DEL_DUMP_TRNX_SUCCESS:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_DEL_DUMP_TRNX_ERROR;
			ptrdata = temp1 = atoi((char *)bufptr) & 0xFF;
			if(ptrdata == 0)
			{
			   	errno = 3;
				goto NEW_CMD_DEL_DUMP_TRNX_ERROR;
			}
			
			if(cmdver==2)//ARMF0384
			{
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
					goto NEW_CMD_DEL_DUMP_TRNX_ERROR;
				temp1 = atoi((char *)bufptr) ; //transaction pointer
				if(temp1 != TransReadPtr) //if same read pointer then only delete data
				{
				   	errno = 3;
					goto NEW_CMD_DEL_DUMP_TRNX_ERROR;
				}
			}

				TempTotalNosTrans = TotalNosOfTrans;
				while(ptrdata--)
				{
					if(DeleteTransaction() != 0)
						break;
				}
				TransmitChar(C_NEW_DELETE_DUMP_TRNX);
				TransmitCharToX(',',port);
				SendDecimalLongToX6digit((TempTotalNosTrans - TotalNosOfTrans),port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitChar(TERMINATOR);
			break;
		default:
			goto NEW_CMD_DEL_DUMP_TRNX_ERROR;
	}
	return;

NEW_CMD_DEL_DUMP_TRNX_ERROR:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;
}


//unsigned char codebuf[512];

/*
//Firmware upgrade protocol
====================================
Flash Memory structure:
====================================
Page 1 data = New code size, No of pages, Firmware info, Hardware Info, Compile Date, Error Info
Page 2 to Page N data = Total required pages by the code
We will use end pages from external flash i.e. last 500 pages to store new firmware.
Base address for New firmware Memory structure will be 7400. So we will get max 543 pages for new f/w. Last page no will be 7943 as we are using flash in 528 byte mode.

Flash memory write command:
$1lc,10,NewCodeSize,NoOfPages,FWInfo,HWInfo,CompileDate,ErrorInfo,Chksum,ENT
$1lc,11,FlashBaseAddress(Offset),NoOfBytes(256),Data(max. 256Bytes),DataChksumOfPage,Chksum,ENT

Flash Memory Read Command:
$1lc,110,Chksum,ENT
$1lc,111,FlashBaseAddress(Offset),NoOfBytes(256),Chksum,ENT

Flash memory Chksum verify with page command:
$1lc,20,FlashBaseAddress(Offset),DataChksumOfPage,Chksum,ENT

All code Flash Chksum verify command:
$1lc,21,DataChksumOfCode,Chksum,ENT
*/
void SerialHandleTestComand(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void SerialHandleTestComand(unsigned char *buffer,unsigned char port)
{
BYTE cmdver,err;
int memptr,count,offset,pgno;
unsigned int len,i,startblock;	
char *mptr;
unsigned char imageno,groupno;	
WORD codechksum;
unsigned char codebuf[PAGE_SIZE];
	
#ifdef INSERT_SDCARD
	clearSDbuffer();
#endif	

	err = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
	{
		goto ERR_NEW_CMD_TestComand;
	}
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
		case 0:	   //read programmed flash directly
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			memptr = atoi((char *)bufptr);
			mptr = (char *)memptr;
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);						
			TransmitCharToX(',',port);
			while(count--)
			{
				SendAsciiToX(*mptr,port);	
				mptr++;
			}
			break;
/*		case 1:		//write progeam flash directly //not working so commented
			mptr = (char *)0x07A000;
			TransmitCharToX(',',port);
			SendDecimalLongToX((int)mptr,port);			 
			TransmitCharToX(':',port);
			for(count=0;count<=32;count++)
			{
				SendAsciiToX(*mptr,port);	
				mptr++;
			}
			mptr = (char *)0x07A000;
//			memcpy(mptr,"12345678901234567890",20);
			mptr1 = test2;
			for(count=0;count<=32;count++)
				*mptr++ = *mptr1++;
			TransmitCharToX(',',port);
			SendDecimalLongToX((int)mptr,port);			 
			TransmitCharToX('=',port);
			mptr = (char *)0x07B000;
			for(count=0;count<=20;count++)
			{
				SendAsciiToX(*mptr,port);	
				mptr++;
			}
			goto NEW_CMD_TestComand_Success;
*/
		case 10:	   //Load new f/w info in ext. flash
			//$1lc,10,NewCodeSize,NoOfPages,FWInfo,HWInfo,CompileDate,ErrorInfo,Chksum,ENT
		#ifdef HARDWARE_SI065
			F_FlashSelect=1;
		#endif
			if(GetDataByPosition(bufptr,buffer,3) == NULL)		//CodeSz
				goto ERR_NEW_CMD_TestComand;
			NewFWInfo.CodeSz = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)		//NoOfPages
				goto ERR_NEW_CMD_TestComand;
			NewFWInfo.NoOfPages = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,5) == NULL)		//FWInfo 		
				goto ERR_NEW_CMD_TestComand;
			strncpy((char*)&NewFWInfo.FWInfo[0],(char *)bufptr,sizeof(NewFWInfo.FWInfo));
			if(GetDataByPosition(bufptr,buffer,6) == NULL)		//HWInfo		
				goto ERR_NEW_CMD_TestComand;
			strncpy((char*)&NewFWInfo.HWInfo[0],(char *)bufptr,sizeof(NewFWInfo.HWInfo));
			if(GetDataByPosition(bufptr,buffer,7) == NULL)		//CompileDate		
				goto ERR_NEW_CMD_TestComand;
			strncpy((char*)&NewFWInfo.CompileDate[0],(char *)bufptr,sizeof(NewFWInfo.CompileDate));
			if(GetDataByPosition(bufptr,buffer,8) == NULL)		//ErrorInfo		
				goto ERR_NEW_CMD_TestComand;
			NewFWInfo.ErrInfo = atoi((char *)bufptr);
		    MainMem_BuffWrt(0,1,(BYTE *)&NewFWInfo,sizeof(NewFWInfo));
			BuffWrt_MainMem(FL_NEW_FW_CODE_INFO,1);
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);	
			SendDecimalToPC3CharToX(10,port);						
			TransmitCharToX(',',port);	
			F_FlashSelect=0;
			break;
		case 110:	   //Read new f/w info from ext. flash
			//$1lc,110,Chksum,ENT
		#ifdef HARDWARE_SI065
			F_FlashSelect=1;
		#endif
 			MainMem_ReadPage(FL_NEW_FW_CODE_INFO,0,(BYTE *)&NewFWInfo,sizeof(NewFWInfo));
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalLongToX((DWORD)NewFWInfo.CodeSz,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)NewFWInfo.NoOfPages,port);
			TransmitCharToX(',',port);
			TransmitNStrToX(NewFWInfo.FWInfo,sizeof(NewFWInfo.FWInfo),port);
			TransmitCharToX(',',port);
			TransmitNStrToX(NewFWInfo.HWInfo,sizeof(NewFWInfo.HWInfo),port);
			TransmitCharToX(',',port);
			TransmitNStrToX(NewFWInfo.CompileDate,sizeof(NewFWInfo.CompileDate),port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)NewFWInfo.ErrInfo,port);
			TransmitCharToX(',',port);				
			F_FlashSelect=0;
  			break;
		case 11:	   //Load new f/w in ext. flash
			//$1lc,11,FlashBaseAddress(Offset),NoOfBytes(512),Data(max. 512Bytes),DataChkcum,Chksum,ENT
		#ifdef HARDWARE_SI065
			F_FlashSelect=1;
		#endif
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			offset = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);
			if(GetHexStrByPosition(codebuf,buffer,5) != 0) 		//New file Hex data
				goto ERR_NEW_CMD_TestComand;
			if(GetDataByPosition(bufptr,buffer,6) == NULL)		//Data chksum
				goto ERR_NEW_CMD_TestComand;
			codechksum = atoi((char *)bufptr);
			pgno = FL_NEW_FW_BASE_ADDRESS + (offset * count)/CODE_PAGE_SIZE;
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)offset,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)count,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)pgno,port);
			TransmitCharToX(',',port);				
			CopyFromNVRAMToBuffer(pgno,buff);//ARMD0300	  //CopyTemplateFromNVRAMToBuffer
			memptr = buff[CODE_PAGE_SIZE] * 0x100 + buff[CODE_PAGE_SIZE+1];	//get chksum
			memcpy(&buff[(offset * count)%CODE_PAGE_SIZE],codebuf,count); //codebuf has perfect data all time  
			if(offset%2)		//X-OR and update chksum
				codechksum ^= memptr;
			buff[CODE_PAGE_SIZE] = codechksum / 0x100;
			buff[CODE_PAGE_SIZE+1] = codechksum & 0xFF;
		   	MainMem_BuffWrt(0,1,buff,PAGE_SIZE);
		   	BuffWrt_MainMem(pgno,1);
			F_FlashSelect=0;
			break;
			
		case 16: 	//// $1lc,16,Startpageno,EndPageNo,flashselect, //$1lc,16,1,100,1,checksum
			if(GetDataByPosition(bufptr,buffer,3) == NULL) //
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)  //  512 
				goto ERR_NEW_CMD_TestComand;
			offset = atoi((char *)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,5) == NULL)   // Image No 
				goto ERR_NEW_CMD_TestComand;
			imageno = atoi((char *)bufptr);
			
			if(imageno == 1)
				F_FlashSelect = 0;
			else
				F_FlashSelect = 1;
			
			TransmitCharToX('\r',port);
			TransmitCharToX('\n',port);
			for(i=count;i<=offset;i++)
			{  // read pages and send to serial 
				TransmitCharToX(',',port);
				SendDecimalIntToX(i,port);
				TransmitCharToX(',',port);
				MainMem_ReadPage(i,0,(BYTE* )&codebuf,FLSH_APP_PAGE_SZ);
				for(len = 0;len<FLSH_APP_PAGE_SZ;len++)
					SendAsciiToX(codebuf[len],port);
				TransmitCharToX(',',port);
				TransmitCharToX('\r',port);
				TransmitCharToX('\n',port);
			}
			F_FlashSelect = 0;
		break;
// 		case 17:
// 			if(GetDataByPosition(bufptr,buffer,3) == NULL)
// 				goto ERR_NEW_CMD_TestComand;
// 			Doorinfo.F_AutoCardStart = atoi((char *)bufptr);
//             temptimer1 = 0;
// 			TransmitCharToX('c',port);
// 			TransmitCharToX(',',port);
// 		break;
#ifdef INSERT_SDCARD				
		case 15:    // To write BMP hex data in SD card $1lc,12,SDFlashBaseAddress(Offset),RXBufferSize,HEXRecive,offset,data,checksum,
// $1lc,15,RXBufferSize, offset, ImageNo, GroupNO, data,checksum, //$1lc,15,256,0,2,2,data,checksum
			F_ImageUploadInProcess = 5;	//NGD00026
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)  //  512 
				goto ERR_NEW_CMD_TestComand;
			offset = atoi((char *)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,5) == NULL)   // Image No 
				goto ERR_NEW_CMD_TestComand;
			imageno = atoi((char *)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,6) == NULL)   // group No 
				goto ERR_NEW_CMD_TestComand;			
			groupno = atoi((char *)bufptr); 
			if(groupno == IMAGES_GROUP)
			{	
				len = BLOCKSPERIMAGE;
				startblock = SD_START_BLOCKNO_SD_BMP;
				if(imageno>MAX_IMAGES)
				{
					goto	ERR_NEW_CMD_TestComand;
				}
		  }
			else if(groupno == ICON_GROUP)   
			{	
				len = BLOCKSPERICON;				
				startblock = SD_START_BLOCKNO_ICON;
				if(imageno>MAX_ICONNO)
				{
					goto	ERR_NEW_CMD_TestComand;
				}
		  }
			else if(groupno == EVENT_ICON_GROUP)  // for future use 
			{	
				len = BLOCKSPER_EVENTICON;
				startblock = SD_START_BLOCKNO_EVENT_ICON;
				if(imageno>MAX_EVENTICONNO)
				{
					goto	ERR_NEW_CMD_TestComand;
				}
		  }
// 			else if(groupno == 4)
// 			{	
// //			len = 300;
// 				startblock = START_BLOCKNO_ICON3;
// 				if(imageno>MAX_ICON3)
// 				{
// 				goto	ERR_NEW_CMD_TestComand;
// 				}
// 		  }
			else{}
				
			if(GetHexStrByPosition(codebuf,buffer,7) != 0) 		//New file Hex data
				goto ERR_NEW_CMD_TestComand;
			imageno = imageno - 1;
			
			guintBlockNum = (startblock + (imageno*len)) + (offset * count)/CODE_PAGE_SIZE;	 
			err = SD_readSingleBlock (guintBlockNum);  // Read from sector 
			memcpy(&buff,SDbuffer,count);	               // copy page into buff from SD		
			memcpy(&buff[(offset * count)%CODE_PAGE_SIZE],codebuf,count);  // 
			for(i=0;i<512;i++)
			{
					if(i <= 259) 
					{
						SDbuf1[i] = buff[i];
					}
					else
					{
						SDbuf2[i - 260] = buff[i];		
					}
			}
			 err = SD_writeSingleBlock(guintBlockNum); 	
			if(err)
					goto ERR_NEW_CMD_TestComand;

			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)count,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)offset,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)imageno,port);
			TransmitCharToX(',',port);				
			SendDecimalIntToX((WORD)groupno,port);
			TransmitCharToX(',',port);				
			//			CopyFromNVRAMToBuffer(pgno,buff);//ARMD0300	  //CopyTemplateFromNVRAMToBuffer
			
			break;
	
		case 17:	// $1lc,17, to indicate Image upload done  // NGD00026
				F_ImageUploadInProcess = 0;
		break;
		case 115:
			//$1lc,115,(Offset), ImageNo, Group No , NoOfBytes(512),Chksum,ENT
		// $1lc,115,00,1,2,512,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			offset = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL) // Image No 
				goto ERR_NEW_CMD_TestComand;
			imageno = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,5) == NULL) // Group No 
				goto ERR_NEW_CMD_TestComand;
			groupno = atoi((char *)bufptr);
			
			if(groupno == IMAGES_GROUP)
			{	
				len = BLOCKSPERIMAGE;  // 300 nos of 512  Block
				startblock = SD_START_BLOCKNO_SD_BMP;
				if(imageno>MAX_IMAGES)
				{
					goto ERR_NEW_CMD_TestComand;
				}
		  }
			else if(groupno == ICON_GROUP)
			{	
				len = BLOCKSPERICON;				
				startblock = SD_START_BLOCKNO_ICON;
				if(imageno>MAX_ICONNO)
				{
					goto ERR_NEW_CMD_TestComand;
				}
		  }
			else if(groupno == EVENT_ICON_GROUP)  
			{	
				len = BLOCKSPER_EVENTICON;
				startblock = SD_START_BLOCKNO_EVENT_ICON;
				if(imageno>MAX_EVENTICONNO)
				{
					goto	ERR_NEW_CMD_TestComand;
				}
		  }
			// 			else if(groupno == 4)
// 			{	
// //				len = 300;
// 				startblock = START_BLOCKNO_ICON3;
// 				if(imageno>MAX_ICON3)
// 				{
// 					goto ERR_NEW_CMD_TestComand;
// 				}
// 		  }
// 			else{}
				
			imageno = imageno - 1;
			if(GetDataByPosition(bufptr,buffer,6) == NULL)
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);
//			guintBlockNum = SD_START_BLOCKNO_SD_BMP + ((offset * count)/CODE_PAGE_SIZE);
			guintBlockNum = (startblock + (imageno*len)) + (offset * count)/CODE_PAGE_SIZE;	   // 300 beacouse  for single Image we need 300 Block
			err = SD_readSingleBlock (guintBlockNum);
			if(err)
				goto ERR_NEW_CMD_TestComand;
			else
			{			
					memptr = (offset * count)%CODE_PAGE_SIZE;
					while(count--)
					{
						SendAsciiToX(SDbuffer[memptr],port);
						memptr++;
					}
// 				for(i=0;i<512;i++)
// 				{
// //						if(SDbuffer[i] == '~') break;
// 						TransmitCharToX(SDbuffer[i],port);
// 				}
		  }
//			CopyFromNVRAMToBuffer(pgno,codebuf);		  //CopyTemplateFromNVRAMToBuffer
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)offset,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)count,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)pgno,port);
			TransmitCharToX(',',port);
			
// 			memptr = (offset * count)%CODE_PAGE_SIZE;
// 			while(count--)
// 			{
// 				SendAsciiToX(codebuf[memptr],port);
// 				memptr++;
// 			}
// 			TransmitCharToX(',',port);
// 			codechksum = codebuf[CODE_PAGE_SIZE] * 0x100 + codebuf[CODE_PAGE_SIZE+1];
// 			SendDecimalIntToX((WORD)codechksum,port);	
// 			TransmitCharToX(',',port);				
			break;
#endif
		
		case 111:	   //Read new f/w in ext. flash
			//$1lc,111,FlashBaseAddress(Offset),NoOfBytes(512),Chksum,ENT
			F_FlashSelect=1;
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			offset = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);
			pgno = FL_NEW_FW_BASE_ADDRESS + ((offset * count)/CODE_PAGE_SIZE);
			CopyFromNVRAMToBuffer(pgno,codebuf);		  //CopyTemplateFromNVRAMToBuffer
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)offset,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)count,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((WORD)pgno,port);
			TransmitCharToX(',',port);
			memptr = (offset * count)%CODE_PAGE_SIZE;
			while(count--)
			{
				SendAsciiToX(codebuf[memptr],port);
				memptr++;
			}
			TransmitCharToX(',',port);
			codechksum = codebuf[CODE_PAGE_SIZE] * 0x100 + codebuf[CODE_PAGE_SIZE+1];
			SendDecimalIntToX((WORD)codechksum,port);	
			TransmitCharToX(',',port);				
			F_FlashSelect=0;
			break;
		case 12://set bootloader check string	$1lc,12,SMARTUPG,
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			len = strlen((char*)bufptr);
			if(len > BOOT_STRING_LENGTH)
				len=BOOT_STRING_LENGTH;
			memcpy((char *)MEM_ADD_BOOT_STRING,(char*)bufptr,len);
		   
			ModelInfo.PrevVersionNo = AsciiToHex(MAJOR_VER);	//ARMF2006
			ModelInfo.PrevVersionNo <<= 4;
			ModelInfo.PrevVersionNo |= AsciiToHex(MINOR_VER); 
			WriteModelInfoToFlash();

			F_FirmwareUpgrade = SET;//to see firmware upgrade message on display
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(12,port);
			TransmitCharToX(',',port);
		break;
		case 112://read	bootloader check string	   $1lc,112,
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(12,port);
			TransmitCharToX(',',port);
			TransmitNStrToX((BYTE*)MEM_ADD_BOOT_STRING,(BYTE)BOOT_STRING_LENGTH,port);
			TransmitCharToX(',',port);
		break;
		case 113://read check sum
			//$1lc,113,FlashBaseAddressStart(Offset),TotalPages,Chksum,ENT	
			//#1lc,113,codeChecksum,Chksum,ENT		
			F_FlashSelect=1;
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			offset = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto ERR_NEW_CMD_TestComand;
			len = atoi((char *)bufptr);
			pgno = FL_NEW_FW_BASE_ADDRESS + offset ;
			len += pgno ;
			CheckSum32 = 0;

			TransmitCharToX('c',port);
			TransmitCharToX(',',port);

#ifdef ENABLE_WATCHDOG
			WDTFeed();		//Clear watchdog timer
#endif

			for(;pgno<len;pgno++)
			{
				CopyFromNVRAMToBuffer(pgno,codebuf);   //CopyTemplateFromNVRAMToBuffer
				offset = CODE_PAGE_SIZE;
				while(offset--)
				{
					CheckSum32 += codebuf[offset];
				}
#ifdef ENABLE_WATCHDOG	//if we add new local variable it will not accept it
				if(pgno%100 == 0)
					WDTFeed();		//Clear watchdog timer
#endif
			}

			SendDecimalLongToX((DWORD)CheckSum32,port);
			TransmitCharToX(',',port);
			F_FlashSelect=0;
		break;
		case 20://$1lc,20,512, 	//this is debug command to test how good network is.	//ARMF0502
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto ERR_NEW_CMD_TestComand;
			count = atoi((char *)bufptr);

			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(20,port);
			TransmitCharToX(',',port);

			cmdver = '1';
			while(count--)
			{
				TransmitCharToX(cmdver,port);
				++cmdver;
				if(cmdver > '9')
					cmdver ='0';
			}
			TransmitCharToX(',',port);
		break;

#ifdef TEST_SDCARD			
#ifdef INSERT_SDCARD			
		case 50: // Create new text file in SD Card     //$1lc,50,file Name,
				 // read file name and call fn to create 	new txt file 
					if(GetDataByPosition(bufptr,buffer,3) == NULL)
				    goto ERR_NEW_CMD_TestComand;
					sprintf((char*)SDFileName,"%s",bufptr);
					SDDataLength = strlen((const char *)SDFileName);
					err = ucFnSetFile(SDFileName,(unsigned char*)&SBuffer[0],20); // Will Create a file and 20 bytes will be written
					if(err == 0)
					{
						  TransmitCharToX('c',port);
							TransmitCharToX(',',port);
						  TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
						  TransmitCharToX(',',port);
					}
		break;
					
		case 51: // Read a text file in SD Card     //$1lc,51,file Name, Offset from where the data is to be read,DataSize, 
		 // read file name 													// $1lc,51,file Name,0001,4096, 
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) // file name
				goto ERR_NEW_CMD_TestComand;
				sprintf((char*)SDFileName,"%s",bufptr);
				SDDataLength = strlen((const char *)SDFileName);
			 
			 if(GetDataByPosition(bufptr,buffer,4) == NULL)
				goto ERR_NEW_CMD_TestComand;
			 guintBlockNum = atoi((char *)bufptr);
			 
			 if(GetDataByPosition(bufptr,buffer,5) == NULL)
				goto ERR_NEW_CMD_TestComand;
			  gusDataSize = atoi((char *)bufptr);
				err = ucFnReadFileOffset(SDFileName,(unsigned char *)&SBuffer[0], guintBlockNum, gusDataSize); // Variable guintBlockNum is used to hold the offset address
			 if(err == 0)
				{
						TransmitCharToX('c',port);
					  TransmitCharToX(',',port);
  					TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
						TransmitNStrToX("Read Successful",sizeof("Read Successful"),port);
					  TransmitCharToX(',',port);
//					TX_NEWLINE;transmitString(" File Reading Successful."); TX_NEWLINE;
				}
				else
				{
					goto ERR_NEW_CMD_TestComand;	
					//					TX_NEWLINE;transmitString(" Error in File Reading."); TX_NEWLINE;
				}
		break;	
	
		case 52: // Appened a text file in SD Card     //$1lc,52,file Name,string to be append, 
		 // read file name 			
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) // file name
				  goto ERR_NEW_CMD_TestComand;

				sprintf((char*)SDFileName,"%s",bufptr);
				SDDataLength = strlen((const char *)SDFileName);
			 
			 if(GetDataByPosition(bufptr,buffer,4) == NULL)
				  goto ERR_NEW_CMD_TestComand;
			  sprintf((char*)SBuffer,"%s",bufptr);
			  SDDataLength = strlen((const char *)SBuffer);
				err = ucFnAppendFile(SDFileName,(unsigned char *)&SBuffer[0],SDDataLength);	
				if(err == 0)
				{
						TransmitCharToX('c',port);
					  	TransmitCharToX(',',port);
  						TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
						TransmitNStrToX("Appened Successful",sizeof("Appened Successful"),port);
					  	TransmitCharToX(',',port);
				}
				else
				{
					  goto ERR_NEW_CMD_TestComand;
				}
		break;

		case 53: // Search a text file in SD Card     // 		
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) // file name
				  goto ERR_NEW_CMD_TestComand;

				sprintf((char*)SDFileName,"%s",bufptr);
				SDDataLength = strlen((const char *)SDFileName);
			 
			 err = ucFnSearchFile(SDFileName);
			 if(err == 1)  // file exist if 1 elseif 0 then not exsist 
			 {
				TransmitCharToX('c',port);
				TransmitCharToX(',',port);
				TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
				TransmitNStrToX("File Exsist",sizeof("File Exsist"),port);
				TransmitCharToX(',',port);				 
			 }
			 else
			 {
				  goto ERR_NEW_CMD_TestComand;
			 }
		break;
			 
		case 54: // Size of text file in SD Card     // $1lc,54,file Name, 
		 // read file name 
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) // file name
				  goto ERR_NEW_CMD_TestComand;

				sprintf((char*)SDFileName,"%s",bufptr);
				SDDataLength = strlen((const char *)SDFileName);
			  len = ulFnGetFileSize(SDFileName);  // if 0 then invalid file name 
			  if (len != 0) 
				{
					TransmitCharToX('c',port);
    				TransmitCharToX(',',port);
  					TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
					TransmitNStrToX("File Size=",sizeof("File Size="),port);
					SendDecimalIntToX(len,port);
			    	TransmitCharToX(',',port);				 					
				}
				else
				{
					 err = len;
					 goto ERR_NEW_CMD_TestComand;
				}		
		break;		

		case 55: // read a block    // $1lc,54,Block name, 
	
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) // Block name
				  goto ERR_NEW_CMD_TestComand;
				guintBlockNum = atoi((char *)bufptr);
//				sprintf(guintBlockNum,"%d",bufptr);
			 
				err = SD_readSingleBlock (guintBlockNum);
//				TX_NEWLINE;
				if(err)
					goto ERR_NEW_CMD_TestComand;
				else
				{
					for(i=0;i<512;i++)
					{
							if(SDbuffer[i] == '~') break;
							TransmitCharToX(SDbuffer[i],port);
					}
// 					TX_NEWLINE;
// 					TX_NEWLINE;
//					transmitString("Read successful!");
				}			 
		break;
				
		case 56: // write  a block    // $1lc,54,block Name,256 char,256 char, 
 
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) // file name
				  goto ERR_NEW_CMD_TestComand;
				guintBlockNum = atoi((char *)bufptr);	
//				sprintf(guintBlockNum,"%s",bufptr);
			 if(GetDataByPosition(SDbuf1,buffer,4) == NULL) // file name
				  goto ERR_NEW_CMD_TestComand;

			 if(GetDataByPosition(SDbuf2,buffer,5) == NULL) // file name
				  goto ERR_NEW_CMD_TestComand;

			 err = SD_writeSingleBlock (guintBlockNum);
			  
//				TX_NEWLINE;
				if(err)
					goto ERR_NEW_CMD_TestComand;
				else
				{
					for(i=0;i<512;i++)
					{
							if(SDbuffer[i] == '~') break;
//							TransmitCharToX(SDbuffer[i],port);
					}
// 					TX_NEWLINE;
// 					TX_NEWLINE;
//					transmitString("Read successful!");
				}			 
		break;
				
		case 58:  // Delete a file 
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) //$1lc,58,file Name,  
				  goto ERR_NEW_CMD_TestComand;

				sprintf((char*)SDFileName,"%s",bufptr);
				SDDataLength = strlen((const char *)SDFileName);
				err = ucFnDeleteFile(SDFileName); 
			  if(err == 0)
					{
						TransmitCharToX('c',port);
						TransmitCharToX(',',port);
						TransmitNStrToX((BYTE*)SDFileName,(BYTE)SDDataLength,port);
						TransmitNStrToX("File Deleted",sizeof("File Deleted"),port);			
						TransmitCharToX(',',port);
					}
				else
					{
						 goto ERR_NEW_CMD_TestComand;
					}
		break;
					
		case 59:  // Write a page in  flash lc,59,page no,flash select;
			 if(GetDataByPosition(bufptr,buffer,3) == NULL) 
				  goto ERR_NEW_CMD_TestComand;
				guintBlockNum = atoi((char *)bufptr);	
			 if(GetDataByPosition(bufptr,buffer,4) == NULL) 
				  goto ERR_NEW_CMD_TestComand;
				F_FlashSelect = atoi((char *)bufptr);	
				F_FlashSelect--;
				if(F_FlashSelect > 1)
					F_FlashSelect = 0;
				err= TestingFlash(guintBlockNum);
				if(err==0)
					TransmitNStrToX("flash OK",sizeof("flash OK"),port);	
				else				
					TransmitNStrToX("flash not OK",sizeof("flash not OK"),port);	
					TransmitCharToX(',',port);
				F_FlashSelect = 0;				
				
				break;
		case 60:		
			memoryStatistics();
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(60,port);
			TransmitCharToX(',',port);
			SendDecimalLongToX(FreeSDMemory,port);
			TransmitCharToX(',',port);
		break;
// 		case 159:  // read a page in  flash lc,159,page no,flash select;
// 			 if(GetDataByPosition(bufptr,buffer,3) == NULL) 
// 				  goto ERR_NEW_CMD_TestComand;
// 				guintBlockNum = atoi((char *)bufptr);	
// 				MainMem_ReadPage(guintBlockNum,0,&codebuf,FLSH_APP_PAGE_SZ);
// 				for(i=0;i<FLSH_APP_PAGE_SZ;i++)
// 				
// 			break;

// 		case 60:  // Write 100 page in  flash -> 1st page 111, 2nd-222...
// 			
// 			break;

		case 160:  // Read 100  page flash  
			
			break;
		
// 		case 58:  // Read 100  page flash  
// 			
// 			break;
// 		case 58:  // Read 100  page flash  
// 			
// 			break;
// 		
						
#endif			
#endif					
		
		case 99://$1lc,99,
//			L_DisplayROMStr("Watch Dog Hang....",16,ROW_USER_FUNCTION);
			DisplayBottomStatusIcon(0,"Watch Dog Hang...",0,0);
			while(1);			// To test Watchdog woks
//		break;
////////////////////////////////////////////////////////////////
/*		case 31: // normal tcp connection close socket
			TransmitCharToX('c',port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(31,port);
			TransmitCharToX(',',port);
			fnTCP_close(Socket_TCP);
			//fnCloseTCPSession(PresentTcpPtr);  //server is closing connection
		break;

		case 21: // tcp time server	 open socket
		//$1lc,21,
		TransmitCharToX('c',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(21,port);
		TransmitCharToX(',',port);
	    {
			//if((USER_TCP_socket = fnGetTCP_Socket(TOS_MINIMISE_DELAY, TCP_DEFAULT_TIMEOUT, fnUserListener)) >= 0) 
			if((USER_TCP_socket = fnGetTCP_Socket(TOS_MINIMISE_DELAY, TCP_DEFAULT_TIMEOUT, TPushTestListener)) >= 0) 
			{
				//fnTCP_Connect(TIME_TCP_socket, iparr , TIME_PORT, 0, 0);
			}
			else
			{
				MsgPrint(MSG_WARNING,USER_TCP_socket,"socket not found");
			}
		}	
		break;
		case 22: //connect tcp server
		//$1lc,22,
		TransmitCharToX('c',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(22,port);
		TransmitCharToX(',',port);
	    {
			unsigned char iparr[4]={192,168,0,15};
	   		fnTCP_Connect(USER_TCP_socket, iparr , 3001, 0, 0);
			//fnTCP_close(TIME_TCP_socket);
		}	
		break;
		case 23: //send data from time server connection
		//$1lc,23,
		TransmitCharToX('c',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(23,port);
		TransmitCharToX(',',port);
	    {
	   		//fnSendBufTCP(USER_TCP_socket, (unsigned char *)"***welocme***", 13, TCP_BUF_SEND);
			typedef struct stTCP_MESSAGE
			{
				TCP_HEADER     tTCP_Header;                                          // reserve header space
				unsigned char  ucTCP_Message[1400];
			} TCP_MESSAGE;
			static TCP_MESSAGE TestData;
			TestData.ucTCP_Message[0] = 0x01;
			TestData.ucTCP_Message[1] = 0x02;
			TestData.ucTCP_Message[2] = 0x03;
			TestData.ucTCP_Message[3] = 0x04;
			fnSendTCP(USER_TCP_socket, (unsigned char *)&TestData, 4, TCP_FLAG_PUSH);
		}	
		break;
		case 40://$1lc,40,	//ping test
		{
			unsigned char iparr[4]={192,168,0,15};
			if(NO_ARP_ENTRY == fnSendPing(iparr, MAX_TTL, TASK_DEBUG, MyUDP_Socket)){
				//fnDebugMsg("ARP resolution started\n\r");
			}
		}
		break;
		case 41://$1lc,41,	//ping test for unreachable IP.
		{
			unsigned char iparr[4]={192,168,0,151};
			if(NO_ARP_ENTRY == fnSendPing(iparr, MAX_TTL, TASK_DEBUG, MyUDP_Socket)){
				//fnDebugMsg("ARP resolution started\n\r");
			}
		}
		break;*/
		case 24: //close socket
		//$1lc,24,
		TransmitCharToX('c',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(24,port);
		TransmitCharToX(',',port);
	    {
	   		fnTCP_close(USER_TCP_socket);
			//fnCloseTCPSession(PresentTcpPtr);
			//fnSendBufTCP(TIME_TCP_socket, (unsigned char *)"***welocme***", 13, TCP_BUF_SEND);
		}	
		break; 
// 		case 35:
// 		{
// 			extern unsigned char my_push_state;
// 			TransmitCharToX('c',port);
// 			TransmitCharToX(',',port);
// 			SendDecimalToPC3CharToX(35,port);
// 			TransmitCharToX(',',port);
// 			my_push_state = 5 ;
// 		}
// 		break;
////////////////////////////////////////////////////////
#ifdef ENABLE_EMAIL_SEND
		case 25:
//		strcpy(PortObj[SER_EMAIL_PORT].Buffer,"Pankaj Zanwar aaaaaaaaaaaaaaaaaaa");
		PortObj[SER_EMAIL_PORT].BufPtr=33;
		EmailAddToBuffer(1,0);
		EmailSendFromBuffer();
		fnSendEmail(0);
		TransmitCharToX('c',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(25,port);
		TransmitCharToX(',',port);
		 break;
#endif
	}
#ifdef HARDWARE_SI065
	F_FlashSelect=0;
#endif

//NEW_CMD_TestComand_Success:
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;

ERR_NEW_CMD_TestComand:
#ifdef HARDWARE_SI065
	F_FlashSelect=0;
#endif
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(err,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;
}




/*** BeginHeader HandleNewCommandGroup*/
void HandleNewCommandGroup(unsigned char *buffer,unsigned char port) ;
/*** EndHeader */
void HandleNewCommandGroup(unsigned char *buffer,unsigned char port)
{
unsigned char temp1,cmdver,errno;
unsigned char chno;
long cnumber;
int ptrdata;
#ifdef BIO_METRIC
DWORD cardno;
#endif
	errno =2;

	if(port == SER_TCPIP_PORT)//ARMF0249
	 	memcpy(CurrentIP,PresentTcpPtr->ucRemoteIP,sizeof(CurrentIP));
	if(port == SER_UDP_PORT)//ARMF0249
		memcpy(CurrentIP,CurrentUDPIP,sizeof(CurrentIP));
   	if(C_NEW_SOCKET_AUTH == buffer[COMMAND_POSITION+1])
   	{
      	HandleSerialAuth(buffer,port);
      	goto end_HandleNewCommandGroup;  // Here we return as ethernet handle is done in above function
   	}
   	else
   	{
	  	if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
      	{
//			MsgPrint(MSG_WARNING,buffer[COMMAND_POSITION+1],"HandleNewCommandGroup::command");
      		// as ethernet so check authentication is done or now else do not allow access
      		if(HandleSerialAuthCheck(SECURE_AUTH_ADMIN,port) == 1)
     			goto end_HandleNewCommandGroup;
      	}
		switch(buffer[COMMAND_POSITION+1])
      	{
		case C_NEW_SERVER_COMMAND:
#ifdef ENABLE_SERVER_AUTH
			  HandleServerBasedAuth(buffer,port);
#endif
		break;
		case C_NEW_TIME_BASED_ACTION:	//ARMF0252 
			HandleTimeBasedActions(buffer,port);
		break;
#ifdef	ENABLE_EMAIL_SEND
         case C_NEW_EMAIL:
         	SerialHandleEmailSend(buffer,port);
			break;
#endif
		case C_NEW_TEST_COMMAND:
         	SerialHandleTestComand(buffer,port);
		break;
      	case C_NEW_UNLOCK_DOOR:
         	SerialHandleDoorOpen(buffer,port);
        	break;
#ifdef ENABLE_GSM_GPRS
      	case C_NEW_SEND_MODEM_COMMAND:
         	HandleModemCommands(buffer,port);
         	break;
#endif
		case C_NEW_SET_TIME_DATE:
         	HandleNewSetTimeDate(buffer,port);
         	break;
		case C_NEW_VERSION_COMMAND:
			HandleNewVersionCommands(buffer,port);
       		break;
        case C_NEW_IOEVENT_TYPE:
         	HandleNewIOEventCommands(buffer,port);
         	break;
		case C_NEW_ADD_ADMIN:
         	HandleNewAddAdminCommands(buffer,port);
         	break;
        case C_NEW_HOLIDAY:
         	HandleNewHolidaySettings(buffer,port);
        	break;
		case C_NEW_BULK_ADD_CARD:
         	HandleNewBulkCardAdd(buffer,port);
			break;
        case C_NEW_SEARCH_CARD:
#ifdef BIO_METRIC
			if(F_BIO_COMM == SET)
	       	{
				CancelBioCommand();
	            F_BIO_COMM =CLR;
				PollBioSensorTimeOut= MAX_FINGER_POLL_TIME_OUT-3;
	       	}
#endif
			HandleNewSearchCard(buffer,port);
         break;
         case C_NEW_SYSTEM_INFO_STRUCT:
         	HandleSystemParaSetting(buffer,port);
         break;
         case C_NEW_OTHER_PARA_SETTING:
				HandleOtherParameterSetting(buffer,port);
         break;
         case C_NEW_ADD_CARD:
				NewAddSerialCard(buffer,port);
		 break;
		 case C_NEW_N_SRS_SYS_INFO_STRUCT:
		      NSeriesPhase2ParaSetting(buffer,port);
			break;
//-------------------------------------------------------------
		case C_NEW_DEL_CARD:
         //$1lI,1,Cardno
#ifdef BIO_METRIC
		   	if(F_BIO_COMM == SET)
         	{
				temp1 = CancelBioCommand();
				F_BIO_COMM =CLR;
				PollBioSensorTimeOut= MAX_FINGER_POLL_TIME_OUT-3;
         	}
#endif
			TransmitReplyStartToX(port);
			if(GetDataByPosition(bufptr,buffer,2) == NULL)
	         goto NEW_CMD_DEL_CARD_ERROR;
			cmdver = atoi((char *)bufptr);
         switch(cmdver)
         {
	         case 1:
	         if(cmdver == 1)
	         {
	            if(GetDataByPosition(bufptr,buffer,3) == NULL)
	               goto NEW_CMD_DEL_CARD_ERROR;
	            Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	         }
	         else
	            goto NEW_CMD_DEL_CARD_ERROR;
			 
	         ptrdata= DelCard(Carddata);
	         if(ptrdata == CARD_NOT_FOUND)
	         {					 
	            TransmitCharToX(C_NEW_ERROR_RETURN,port);
	            TransmitCharToX(',',port);
#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(TotalCards,port);
#else			
	            SendDecimalIntToX(TotalCards,port);
#endif
	            TransmitCharToX(',',port);
	         }
	         else
	         {
				 // Del Extra card info 			 
				temp1 = DelCardTemplateInfoFromFlash(ptrdata);
	            TransmitCharToX(C_NEW_DEL_CARD,port);
	            TransmitCharToX(',',port);
#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(TotalCards,port);
#else			
	            SendDecimalIntToX(TotalCards,port);
#endif
	            TransmitCharToX(',',port);
	         }
#ifdef BIO_METRIC
	         if(ptrdata != CARD_NOT_FOUND)
	         {
	            ENABLE_BIO_COMM();
	            DeleteBioUserID(Carddata.CardNo);
	            DISABLE_BIO_COMM();
	         }
#endif
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
            goto end_HandleNewCommandGroup;
#ifdef BIO_METRIC
// This command is to delete perticular finger ID for selected user. $1l ,2,cardno,fingerid,chksum,enter   finger template from 0 to 9
            case 2:
            	if(GetDataByPosition(bufptr,buffer,3) ==NULL)	// Read card number
	            	goto NEW_CMD_DEL_CARD_ERROR;
	            Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);

            	if(GetDataByPosition(bufptr,buffer,4) ==NULL)	// Read finger ID
	            	goto NEW_CMD_DEL_CARD_ERROR;
					temp1 = atoi((char *)bufptr);
                if(temp1>=10)
	            	goto NEW_CMD_DEL_CARD_ERROR;
	            if( (errno =DeleteBioFingerID(Carddata.CardNo,temp1,DELETE_ONLY_ONE))==0)
	            {
	               	TransmitCharToX(C_NEW_DEL_CARD,port);
	               	TransmitCharToX(',',port);
	               	SendDecimalToPC3CharToX(0,port);
	               	TransmitCharToX(',',port);
	               	TransmitCheckSumX(port);
	               	TransmitCharToX(',',port);
	               	TransmitCharToX(TERMINATOR,port);
            		goto end_HandleNewCommandGroup;
	            }
               break;
				
			case 5:   // del card only ................
	            if(GetDataByPosition(bufptr,buffer,3) == NULL)
	               goto NEW_CMD_DEL_CARD_ERROR;
	            Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
			 
	         ptrdata= DelCard(Carddata);
	         if(ptrdata == CARD_NOT_FOUND)
	         {					 
	            TransmitCharToX(C_NEW_ERROR_RETURN,port);
	            TransmitCharToX(',',port);
#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(TotalCards,port);
#else			
	            SendDecimalIntToX(TotalCards,port);
#endif
	            TransmitCharToX(',',port);
	         }
	         else
	         {
				 // Del Extra card info 			 
				temp1 = DelCardTemplateInfoFromFlash(ptrdata);
	            TransmitCharToX(C_NEW_DEL_CARD,port);
	            TransmitCharToX(',',port);
#ifdef EXTENDED_USER
				SendDecimalLongToX6digit(TotalCards,port);
#else			
	            SendDecimalIntToX(TotalCards,port);
#endif
	            TransmitCharToX(',',port);
	         }
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
				goto end_HandleNewCommandGroup;
			 
//==============================================================================
            case 3:   // Delete multiple templates
            	if(GetDataByPosition(bufptr,buffer,3) ==NULL)	// Read card number
	            	goto NEW_CMD_DEL_CARD_ERROR;
	            Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
            	if(GetDataByPosition(bufptr,buffer,4) ==NULL)	// Read finger ID
	            	goto NEW_CMD_DEL_CARD_ERROR;
					cardno = StrDecToLong(bufptr,10);
	            if( (errno =DeleteBioFingerID(Carddata.CardNo,cardno,DELETE_MULTIPLE_ID))==0)
	            {
	               TransmitCharToX(C_NEW_DEL_CARD,port);
	               TransmitCharToX(',',port);
						SendDecimalIntToX((unsigned int)BioCmdSize,port);  // not of templates deleted
	               TransmitCharToX(',',port);
	               TransmitCheckSumX(port);
	               TransmitCharToX(',',port);
	               TransmitCharToX(TERMINATOR,port);
            		goto end_HandleNewCommandGroup;
	            }
               break;
//            goto end_HandleNewCommandGroup;
#endif
			case 4://delete special card
			{
//Special Card Delete:	$1lI, 4, Special Card No, Chksum, ENT
//Response from Controller: 	#1I, No of Special cards Stored, Chksum, ENT
//Whereas,
//No of Special cards Stored = Total no of special cards stored in it (0 to 32)
				if(GetDataByPosition(bufptr,buffer,3) == NULL)	// Read card number
					goto NEW_CMD_DEL_CARD_ERROR;
				Carddata.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
				ptrdata = DelOnlySplCard(Carddata.CardNo);
				if(ptrdata != 0)
				{
					errno = 7;
					goto NEW_CMD_DEL_CARD_ERROR;
				}
				TransmitCharToX(C_NEW_DEL_CARD,port);
				TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(TotalSplCards+1,port);
				TransmitCharToX(',',port);
				TransmitCheckSumX(port);
				TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				goto end_HandleNewCommandGroup;
			}
		//	break;
				default:
            goto NEW_CMD_DEL_CARD_ERROR;
   		}
NEW_CMD_DEL_CARD_ERROR:
			TransmitCharToX(C_NEW_ERROR_RETURN,port);
	      TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(errno,port);
	      TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	      TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
			break;
//-------------------------------------------------------------
		case C_NEW_SEND_TRANS:
			if((port == SER_TCPIP_PORT) ||(port == SER_UDP_PORT))//ARMF0249
			{
				if(HandleSerialAuthCheck(SECURE_TRNX_DWNLD_IP_CHK,port) == 1)
					break;
			}
			TransmitReplyStartToX(port);
            SendTransactionWithSaperator(port);
      break;
      case C_NEW_DUMP_TRNX:
			HandleNewSendSerialTrans(buffer,port);
		break;
//------------------------------------------------------------------------------
	case C_NEW_ADDMESGTODISP:
		   TransmitReplyStartToX(port);
			if(GetDataByPosition(bufptr,buffer,2) == NULL)
	         goto NEW_CMD_ADDMESGTODISP_ERROR;
         if(atoi((char *)bufptr) == 1)
         {
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_ADDMESGTODISP_ERROR;
            temp1 = atoi((char *)bufptr);
				if(GetDataByPosition(bufptr,buffer,4) == NULL)
		      	goto NEW_CMD_ADDMESGTODISP_ERROR;
            if(AddMessageToFlash(temp1,bufptr) == 0)
            {
            	// Success
	            TransmitCharToX(C_NEW_ADDMESGTODISP,port);
	            TransmitCharToX(',',port);
					TransmitCheckSumX(port);
	            TransmitCharToX(',',port);
	            TransmitCharToX(TERMINATOR,port);
            }
            else
            {
	      		TransmitCharToX('e',port);
	      		TransmitCharToX(',',port);
				TransmitCharToX('2',port);
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
            }
         }
         else
         {
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_ADDMESGTODISP_ERROR;
            temp1 = atoi((char *)bufptr);
            memset(bufptr,' ',16);
            if( GetMessageFromFlash(temp1,bufptr) ==0)
            {
            	// Success
//					L_DisplayROMStr(bufptr,16,1);
	            TransmitCharToX(C_NEW_ADDMESGTODISP,port);
	            TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(temp1,port);
	            TransmitCharToX(',',port);
				TransmitStrToX(bufptr,port);
	            TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	            TransmitCharToX(',',port);
	            TransmitCharToX(TERMINATOR,port);
            }
            else
            {
            	TransmitCharToX('e',port);
	      		TransmitCharToX(',',port);
					TransmitCharToX('2',port);
	      		TransmitCharToX(',',port);
					TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
            }
         }
   break;
NEW_CMD_ADDMESGTODISP_ERROR:
	      		TransmitCharToX('e',port);
	      		TransmitCharToX(',',port);
					TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
	break;
#ifdef SUPPORT_OLD_PROTOCOL
   case C_NEW_SYSTEM_INFO:
			TransmitReplyStartToX(port);
			if(GetDataByPosition(bufptr,buffer,2) == NULL)
	         goto NEW_SYSTEM_INFO_ERROR;
         cmdver = atoi((char *)bufptr);
	      if(GetDataByPosition(bufptr,buffer,3) ==NULL)
		         goto NEW_SYSTEM_INFO_ERROR;
			temp1 = atoi((char *)bufptr);
         switch(cmdver)
         {
         	case 6:
	          	SysInfo.GlobleMsg = temp1;
				break;
            case 7:
            	SysInfo.BannerMsg = temp1;
					GetMessageFromFlash(0,BannerMessage);
            break;
            case 8:
					SysInfo.ContInOut = temp1;
            break;
            case 9:
					SysInfo.IdentifyMode = temp1;
				break;
         default:
         	goto NEW_SYSTEM_INFO_ERROR;
         }
	         WriteSysInfoToFlash();
	         TransmitCharToX(C_NEW_SYSTEM_INFO,port);
	         TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
   break;
NEW_SYSTEM_INFO_ERROR:
	      		TransmitCharToX('e',port);
	      		TransmitCharToX(',',port);
					SendDecimalToPC3CharToX(errno,port);
	      		TransmitCharToX(',',port);
					TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
					TransmitCharToX(TERMINATOR,port);
	break;
#endif
#ifdef BIO_METRIC
   case C_NEW_FINGER_TEMPLATE:
		if(F_BIO_COMM == SET)
		{
//			printf("Biometric Busy \n");
			temp1 = CancelBioCommand();
//			printf("Biometric Busy CancelBioCommand %x\n",temp1);
			F_BIO_COMM = CLR;
		}
		ENABLE_BIO_COMM();
		if(HandleSerialTemplate(buffer,port) != C_NEW_SUB_VERIFY_TEMP)
         	DISABLE_BIO_COMM();
   		break;
#endif

#ifdef SMART_CARD
	case C_NEW_SMARTCARD_COMM:
		HandleSerSmartCard(buffer,port);
		break;
#endif

   case C_NEW_INITIALISE_SYS:	//$1lM,0,
			if(GetDataByPosition(bufptr,buffer,2) == NULL)
	        	goto NEW_CMD_INI_SYS_ERROR;
         	cmdver = atoi((char *)bufptr);
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         	goto NEW_CMD_INI_SYS_ERROR;
         	if( atoi((char *)bufptr) !=123)
	        	goto NEW_CMD_INI_SYS_ERROR;
           	if(InitialiseDefaultSelect(cmdver) != 0)
			{
NEW_CMD_INI_SYS_ERROR:
         		TransmitReplyStartToX(port);
            	TransmitCharToX('e',port);
	      		TransmitCharToX(',',port);
				SendDecimalToPC3CharToX(errno,port);
	      		TransmitCharToX(',',port);
				TransmitCheckSumX(port);
	      		TransmitCharToX(',',port);
				TransmitCharToX(TERMINATOR,port);
				goto end_HandleNewCommandGroup;
			}
     		TransmitReplyStartToX(port);
	        TransmitCharToX(C_NEW_INITIALISE_SYS,port);
	        TransmitCharToX(',',port);
	        TransmitCharToX('0',port);
	        TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	        TransmitCharToX(',',port);
	        TransmitCharToX(TERMINATOR,port);
   			break;

	case C_NEW_DUMMY_CARD: 
   	// For testing to send dummy card from PC
			if(GetDataByPosition(bufptr,buffer,2) == NULL)    // Cardno
	         goto NEW_CMD_DUMMY_CARD_ERROR;
         	ReceivedCardNo = StrDecToLong(bufptr,10);
			if(GetDataByPosition(bufptr,buffer,3) == NULL)   // Reader No
				goto NEW_CMD_DUMMY_CARD_ERROR;
         	cmdver = atoi((char *)bufptr);
//         	cmdver = strtoul((char *)bufptr,NULL,10);
			CurrentUser.InputType=INPUT_USER_FROM_WEIGAND;

         	{
				F_EthernetReceived = CLR;
	         	CurrentUser.RdrNo = cmdver ;
	         	CurrentUser.SearchCard.CardNo =ReceivedCardNo;
	         	CurrentUser.InputType=INPUT_USER_FROM_WEIGAND;     //need to take care #define INPUT_FROM_SLAVE_POLL
	         	ProcessCard(CurrentUser.RdrNo);
//				goto end_HandleNewCommandGroup;
			}
			PortObj[port].BufPtr = 0;
			PortObj[port].ChkSum = 0;
			PortObj[port].F_ChkSum = SET;
            TransmitReplyStartToX(port);
	  		TransmitCharToX(C_NEW_DUMMY_CARD,port);
	      	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
	      	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			goto end_HandleNewCommandGroup;
NEW_CMD_DUMMY_CARD_ERROR:
	  		TransmitCharToX('e',port);
	      	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(errno,port);
	      	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
   break;
//#ifdef SUPPORT_OLD_PROTOCOL
   case C_NEW_DUMMY_WEIGAND://ARMF0249
   		errno=2;

			TransmitReplyStartToX(port);
			if(GetDataByPosition(bufptr,buffer,2) == NULL)
	         goto NEW_DUMMY_WEIGAND_ERROR;
         cmdver = atoi((char *)bufptr);
         switch(cmdver)
         {
         	case 2:   // $1lZ,2,Rdrno,WCount,FCode,CardNo,
	         if(GetDataByPosition(bufptr,buffer,3) ==NULL)
	               goto NEW_DUMMY_WEIGAND_ERROR;
				chno = atoi((char *)bufptr);
				if(chno>MAX_LOCAL_READER)
					chno =1;
				chno--;

	            if(GetDataByPosition(bufptr,buffer,4) ==NULL)
	                  goto NEW_DUMMY_WEIGAND_ERROR;
	            ReaderData[chno].WCount = atoi((char *)bufptr);
	            if(GetDataByPosition(bufptr,buffer,5) ==NULL)
	                  goto NEW_DUMMY_WEIGAND_ERROR;
               temp1 = atoi((char *)bufptr);
	            if(GetDataByPosition(bufptr,buffer,6) ==NULL)
	                  goto NEW_DUMMY_WEIGAND_ERROR;
//					ReaderData[chno].CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10); //ARMD0251
				cnumber =(CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
               if(ReaderData[chno].WCount==26)
               {
	               ReaderData[chno].WeigandData = (cnumber & 0x00FFFF) + (unsigned long) (temp1&0x0FF) *0x10000 ;
                  ReaderData[chno].WeigandData = ReaderData[chno].WeigandData << 1;
               }
               else
               {
	               ReaderData[chno].WeigandData = (cnumber & 0xFFFFFF) + (unsigned long) (temp1&0x0FF) *0x1000000 ;
               }
            	ReaderData[chno].F_WeigandInterrupt = SET;                        
	  		TransmitCharToX(C_NEW_DUMMY_WEIGAND,port);
	      	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(0,port);
	      	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
         break;
NEW_DUMMY_WEIGAND_ERROR:
	  		TransmitCharToX('e',port);
	      	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(errno,port);
	      	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
         break;
			}
   break;
//#endif
   case C_NEW_LAST_CARD:
   		HandelLastCard(buffer,port);
   break;
   case C_NEW_TIMEZONE:
   		HandelNewTimeZone(buffer,port);
   break;
   case C_NEW_ACCESS_LEVEL:
   		HandelNewAccessLevel(buffer,port);
   break;
   #ifdef SUPPORT_NSERIES2
   case C_NEW_ACCESS_MONTH:
   		HandelNewAccessMonth(buffer,port);
   break;
   #endif
   case C_NEW_RD_CONT_CONFIG:
   		HandelRDControllerConfig(buffer,port);
   break;
	case C_NEW_DELETE_DUMP_TRNX:
		HandleNewDelDumpTRnx(buffer,port);
		break;
   default:
   			TransmitReplyStartToX(port);
	  		TransmitCharToX('e',port);
	      	TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(15,port);
	      	TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	      	TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
   break;
      }
    }
end_HandleNewCommandGroup:
	if(F_EthernetReceived)
	{
#ifdef ETHERNET
		SendSerialDataToEthernetPort(1);		//PANKAJXX DataSocketNo
#else
	#ifndef TELNET_TEST
		F_CheckSum = CLR;
		PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
		fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE,PortObj[SER_TCPIP_PORT].BufPtr);
//		{//testing
//			int j ;//= PortObj[SER_TCPIP_PORT].BufPtr ;
//			for(j=0;j<PortObj[SER_TCPIP_PORT].BufPtr ;j++)
//			{
//				TransmitCharToX((BYTE )PortObj[SER_TCPIP_PORT].Buffer[j],SER_PORT_C);
//			}		
//		}
	#endif
#endif
		F_EthernetReceived = CLR;
	}
	return;
}

void SendCardDataToPC(int pos, CardData empcard,unsigned char port)
{
#ifdef EXTENDED_USER
	SendDecimalLongToX6digit(pos,port);
#else			
	SendDecimalIntToX(pos,port);
#endif
   	TransmitCharToX(',',port);
	SendDecimalLongToX(empcard.CardNo,port);
   	TransmitCharToX(',',port);
	SendDecimalIntToX(empcard.CardPin,port);
   	TransmitCharToX(',',port);
   	SendDecimalToPC3CharToX(empcard.CardInfo.APB,port);
   	TransmitCharToX(',',port);
   	SendDecimalToPC3CharToX(empcard.CardInfo.Door1,port);
   	TransmitCharToX(',',port);
   	SendDecimalToPC3CharToX(empcard.CardInfo.Door2,port);
   	TransmitCharToX(',',port);
   	SendDecimalToPC3CharToX(empcard.CardInfo.Holiday,port);
   	TransmitCharToX(',',port);
   	SendDecimalToPC3CharToX(empcard.Info.CType,port);
   	TransmitCharToX(',',port);
   	SendDecimalToPC3CharToX(empcard.Info.MesgInfo,port);
   	TransmitCharToX(',',port);
}

void SendNewCardDataToPC(CardData empcard,char fingerid,unsigned char port)
{
	if(empcard.CardInfo.Holiday  & CARD_BIT_DURESS_CHK)
		TransmitCharToX('1',port);
	else
		TransmitCharToX('0',port);
   	TransmitCharToX(',',port);
	if(empcard.CardInfo.Holiday  & CARD_BIT_SPECIAL_CARD)
		TransmitCharToX('1',port);
	else
		TransmitCharToX('0',port);
   	TransmitCharToX(',',port);
	if(empcard.CardInfo.Holiday  & CHECK_FIRST_IN_USER_FOR_THIS_CRD)
		TransmitCharToX('1',port);
	else
		TransmitCharToX('0',port);
   	TransmitCharToX(',',port);
	
	SendDecimalToPC3CharToX(empcard.Info.Group,port);
   	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(empcard.DoorAccess,port);
   	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(((empcard.Info.MesgInfo & 0x60) >> 5),port); //DUA ADMIN	//ARMF2008
   	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX((empcard.Info.MesgInfo & 0x1F),port);		 //DUA GROUP
   	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(fingerid,port);								 //FingerID
   	TransmitCharToX(',',port);
				
}
/*
Add Admin command
$1lA,0,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,APB,TZD1,TZD2,Holiday,MsgNo,ExpiryDate,Chksum,ENT
$1lA,1,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,Chksum,ENT
$1lA,1,12345,12345,0,0,0,
#1A,1,AddedLocation,Chksum,ENT

Get Admin by admin ID
$1lA,101,AdminID,Chksum,ENT
#1A,1,AdminLoc,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,Chksum,ENT

Get Admin data using location
$1lA,102,location,Chksum,ENT
#1A,2,AdminLoc,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,APB,TZD1,TZD2,Holiday,MsgNo,ExpiryDate,Chksum,ENT

Del Admin command
$1lA,50,AdminID,Chksum,ENT
$1lA,50,12345,
#1A,50,DelLocation,Chksum,ENT

$1lA,51,Location,Chksum,ENT
$1lA,51,0-15,
#1A,DelLocation,Chksum,ENT

*/
#ifdef	ENABLE_EMAIL_SEND
/*** BeginHeader SerialHandleEmailSend*/
void SerialHandleEmailSend(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void SerialHandleEmailSend(unsigned char *buffer,unsigned char port)
{
unsigned char temp1,cmdver,errno;
	errno = 2;
	TransmitReplyStartToX(port);
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto NEW_CMD_EMAIL_ERROR;
	cmdver = atoi((char *)bufptr);
	switch(cmdver)
	{
	   case 1:     //$1C,1,ParaNo,32 char string,chksum,enter
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_EMAIL_ERROR;
            temp1=atoi((char *)bufptr);
            if(temp1>=MAX_EMAIL_ADDRESS)
            {
              errno=3;
		      	goto NEW_CMD_EMAIL_ERROR;
            }
         	if(GetDataByPosition(bufptr,buffer,4) == NULL)
		      	goto NEW_CMD_EMAIL_ERROR;							
            memcpy(EmailAd[temp1].Adress,(char *)bufptr,32);
			WriteEmailAddToFlash();
	       	TransmitCharToX(C_NEW_EMAIL,port);
	        TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(temp1,port);
	        TransmitCharToX(',',port);
			TransmitStrToX(bufptr,port);
	        TransmitCharToX(',',port);
			TransmitCheckSumX(port);
	        TransmitCharToX(',',port);
	        TransmitCharToX(TERMINATOR,port);
			break;
         case 101:
         	if(GetDataByPosition(bufptr,buffer,3) == NULL)
		      	goto NEW_CMD_EMAIL_ERROR;
            temp1=atoi((char *)bufptr);
            if(temp1>=MAX_EMAIL_ADDRESS)
            {
              	errno=3;
		      	goto NEW_CMD_EMAIL_ERROR;
            }
            TransmitCharToX(C_NEW_EMAIL,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(temp1,port);
            TransmitCharToX(',',port);
			TransmitStrToX((BYTE *)&EmailAd[temp1].Adress[0],port);
            TransmitCharToX(',',port);
			TransmitCheckSumX(port);
            TransmitCharToX(',',port);
            TransmitCharToX(TERMINATOR,port);
         break;
	}
   return;
NEW_CMD_EMAIL_ERROR:
   TransmitCharToX('e',port);
   TransmitCharToX(',',port);
   SendDecimalToPC3CharToX(errno,port);
   TransmitCharToX(',',port);
   TransmitCheckSumX(port);
   TransmitCharToX(',',port);
   TransmitCharToX(TERMINATOR,port);
}
#endif


/*
Add Admin command
$1lA,0,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,APB,TZD1,TZD2,Holiday,MsgNo,ExpiryDate,Chksum,ENT
$1lA,1,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,Chksum,ENT
$1lA,1,12345,12345,0,0,0,
#1A,1,AddedLocation,Chksum,ENT

Get Admin by admin ID
$1lA,101,AdminID,Chksum,ENT
#1A,1,AdminLoc,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,Chksum,ENT

Get Admin data using location
$1lA,102,location,Chksum,ENT
#1A,2,AdminLoc,AdminID,AdminPin,CardType,AuthenticationType,DownloadType,APB,TZD1,TZD2,Holiday,MsgNo,ExpiryDate,Chksum,ENT

Del Admin command
$1lA,50,AdminID,Chksum,ENT
$1lA,50,12345,
#1A,50,DelLocation,Chksum,ENT

$1lA,51,Location,Chksum,ENT
$1lA,51,0-15,
#1A,DelLocation,Chksum,ENT

*/

/*** BeginHeader HandleNewAddAdminCommands*/
void HandleNewAddAdminCommands(unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleNewAddAdminCommands(unsigned char *buffer,unsigned char port)
{
unsigned char cmdver, errno;
struct ADMIN_INFO admcard;
int cardptr;

	errno = 2;
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto fun_NEW_ADD_ADMIN_ERROR;
	cmdver = atoi((const char*)bufptr);
 	TransmitReplyStartToX(port);
	switch(cmdver)
   {
	   case 1:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.AdmData.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
	      if(GetDataByPosition(bufptr,buffer,4) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.AdmData.CardPin = atoi((const char*)bufptr);
	      if(GetDataByPosition(bufptr,buffer,5) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.AdmData.Info.CType = atoi((const char*)bufptr);
	      if(GetDataByPosition(bufptr,buffer,6) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.AdminType = atoi((const char*)bufptr);
	      if(GetDataByPosition(bufptr,buffer,7) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.DownloadID = atoi((const char*)bufptr);

         admcard.AdmData.CardInfo.APB = 0x0;
         admcard.AdmData.CardInfo.Door1 = 0x0;
         admcard.AdmData.CardInfo.Door2 = 0x0;
         admcard.AdmData.CardInfo.Holiday = 0x0;
         admcard.AdmData.Info.MesgInfo = 0x0;
#ifdef EN_CARD_EXP_DATE
         admcard.AdmData.ExpDT = 0x0;
#endif
			cardptr = AddNewAdminUser(admcard);
			if(cardptr != -1)
			{
	         TransmitCharToX(C_NEW_ADD_ADMIN,port);
	         TransmitCharToX(',',port);
	         TransmitCharToX('1',port);
	         TransmitCharToX(',',port);
         	 SendDecimalIntToX(cardptr,port);
	         TransmitCharToX(',',port);
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
	         return;
			}
			else
			{
	         errno = 3;
			}
         break;
     case 101:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.AdmData.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
         cardptr = SearchNewDisplayAdminUser(admcard.AdmData.CardNo,&AdmCard);
	      if(cardptr == CARD_NOT_FOUND)
	      {
	         errno = 3;
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      }
         else
         {
	         TransmitCharToX(C_NEW_ADD_ADMIN,port);
	         TransmitCharToX(',',port);
	         TransmitCharToX('1',port);
	         TransmitCharToX(',',port);
         	SendDecimalIntToX(cardptr,port);
	         TransmitCharToX(',',port);
            SendDecimalLongToX(AdmCard.AdmData.CardNo,port);
            TransmitCharToX(',',port);
         	SendDecimalIntToX(AdmCard.AdmData.CardPin,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(AdmCard.AdmData.Info.CType,port);
	         TransmitCharToX(',',port);
	         SendDecimalIntToX(AdmCard.AdminType,port);
	         TransmitCharToX(',',port);
         	SendDecimalIntToX(AdmCard.DownloadID,port);
	         TransmitCharToX(',',port);
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
		}
       	return;

     case 102:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      cardptr = atoi((const char*)bufptr);
         if(cardptr >= MAX_ADMIN_USER_NEW)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	   	//xmem2root((unsigned char *)&admcard,((unsigned long)ADMIN_DATA_BASE+(unsigned long)((unsigned long)cardptr*(unsigned long)ADMIN_DATA_BYTES)),ADMIN_DATA_BYTES);
		if(GetAdminUserByLoc(cardptr,&admcard)==-1)    //ARMD0262
	    {
				errno = 3;
		     goto fun_NEW_ADD_ADMIN_ERROR;
		}
//		MainMem_ReadPage(FL_ADMIN_DATA_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
//		memcpy(&tempwrbuf[cardptr*ADMIN_DATA_BYTES],&admcard,ADMIN_DATA_BYTES);
		TransmitCharToX(C_NEW_ADD_ADMIN,port);
         TransmitCharToX(',',port);
         TransmitCharToX('2',port);
         TransmitCharToX(',',port);
         SendDecimalIntToX(cardptr,port);
         TransmitCharToX(',',port);
         SendDecimalLongToX(admcard.AdmData.CardNo,port);
         TransmitCharToX(',',port);
         SendDecimalIntToX(admcard.AdmData.CardPin,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(admcard.AdmData.Info.CType,port);
         TransmitCharToX(',',port);
         SendDecimalIntToX(admcard.AdminType,port);
         TransmitCharToX(',',port);
         SendDecimalIntToX(admcard.DownloadID,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(admcard.AdmData.CardInfo.APB,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(admcard.AdmData.CardInfo.Door1,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(admcard.AdmData.CardInfo.Door2,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(admcard.AdmData.CardInfo.Holiday,port);
         TransmitCharToX(',',port);
         SendDecimalToPC3CharToX(admcard.AdmData.Info.MesgInfo,port);
         TransmitCharToX(',',port);
#ifdef EN_CARD_EXP_DATE
         SendDecimalLongToX(admcard.AdmData.ExpDT,port);
#endif
         TransmitCharToX(',',port);
         TransmitCheckSumX(port);
         TransmitCharToX(',',port);
         TransmitCharToX(TERMINATOR,port);
         return;

	   case 50:
	      if(GetDataByPosition(bufptr,buffer,3) == NULL)
	         goto fun_NEW_ADD_ADMIN_ERROR;
	      admcard.AdmData.CardNo = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
         cardptr = DelNewAdminUser(admcard);
			if(cardptr != -1)
			{
	         TransmitCharToX(C_NEW_ADD_ADMIN,port);
	         TransmitCharToX(',',port);
	         SendDecimalToPC3CharToX(cmdver,port);
	         TransmitCharToX(',',port);
         	SendDecimalIntToX(cardptr,port);
	         TransmitCharToX(',',port);
	         TransmitCheckSumX(port);
	         TransmitCharToX(',',port);
	         TransmitCharToX(TERMINATOR,port);
	         return;
			}
			else
			{
	         errno = 3;
	        // goto fun_NEW_ADD_ADMIN_ERROR;
		}
		break;
      default:
         break;

   }

fun_NEW_ADD_ADMIN_ERROR:
	TransmitCharToX('e',port);
   TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;
}

/*** BeginHeader HandleTimeBasedActions*/
void HandleTimeBasedActions(unsigned char *buffer,unsigned char port);
//Write Time Based Action
//$1ln,1,ActionNo,ActionType,ActionData,StHr,StMin,EndHr,EndMin,Date,Month,Year,Dummy1,Dummy2,Dummy3,Dummy4,chksum,enter
//$1ln,1,1,1,1,10,00,12,00,0,0,0,1,1,1,1,chksum,enter
//Read Time Based Action
//$1ln,101,ActionNo,chksum,enter
//#1n,Actionno,ActionType,ActionData,Date,Month,Year,StartHR,StrartMin,EndHr,EndMin,Dummy1,Dummy2,Dummy3,Dummy4,chksum
//#1n,001,001,00001,06,05,10,012,053,012,000,001,001,00001,00001,65,
/*** EndHeader */
void HandleTimeBasedActions(unsigned char *buffer,unsigned char port)	//ARMF0252 
{
	unsigned char temp1,cmdver,errno,actionno;
	errno = 2;	//insufficient data
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto NEW_CMD_TIME_BASED_ACTION_ERROR;
	cmdver = atoi((const char*)bufptr);

	TransmitReplyStartToX(port);

	switch(cmdver)
	{
		case 1:
		{
			ReadTimeBasedAction(pTimeBasedAction);  		// Better to read action before writing. ARMF0317

			if(GetDataByPosition(bufptr,buffer,3) == NULL)  //Get ActionNo, 1 to MAX_TIME_BASED_ACTIONS
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			actionno = atoi((const char*)bufptr);
			if((actionno > MAX_TIME_BASED_ACTIONS) || (actionno == 0))
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			actionno--;
			
			if(GetDataByPosition(bufptr,buffer,4) == NULL)	//Get Action type,ex.APB reset ,DOTL reset
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].ActionType = atoi((const char*)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,5) == NULL)	//Get Action Data
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].ActionData = atoi((const char*)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,6) == NULL)	//Get start Hour
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			temp1 = atoi((const char*)bufptr);
			if(temp1 > 23)
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			(*pTimeBasedAction)[actionno].TimeAction.StarHours = temp1;
			
			if(GetDataByPosition(bufptr,buffer,7) == NULL)	//Get Start Minute
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			temp1 = atoi((const char*)bufptr);
			if(temp1 > 59)
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			(*pTimeBasedAction)[actionno].TimeAction.StarMin = temp1;
			
			if(GetDataByPosition(bufptr,buffer,8) == NULL)	//Get End Hour
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			temp1 = atoi((const char*)bufptr);
			if(temp1 > 23)
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			(*pTimeBasedAction)[actionno].TimeAction.EndHours = temp1;
			
			if(GetDataByPosition(bufptr,buffer,9) == NULL)	//Get End Minute
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			temp1 = atoi((const char*)bufptr);
			if(temp1 > 59)
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].TimeAction.EndMin = temp1;
			
			if(GetDataByPosition(bufptr,buffer,10) == NULL)	//Get day
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			temp1 = atoi((const char*)bufptr);
			if(temp1 > 31)
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			(*pTimeBasedAction)[actionno].ActionCompleteDate.Day = temp1;

			if(GetDataByPosition(bufptr,buffer,11) == NULL)	//Get Complete Month
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			temp1 = atoi((const char*)bufptr);
			if(temp1 > 12)
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			(*pTimeBasedAction)[actionno].ActionCompleteDate.Month = temp1;

			if(GetDataByPosition(bufptr,buffer,12) == NULL)	//Get Complete Year
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].ActionCompleteDate.Year = atoi((const char*)bufptr);
			
			if(GetDataByPosition(bufptr,buffer,13) == NULL)	//Get Dummy1
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].Dummy1 = atoi((const char*)bufptr);

			if(GetDataByPosition(bufptr,buffer,14) == NULL)	//Get Dummy2
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].Dummy2 = atoi((const char*)bufptr);

			if(GetDataByPosition(bufptr,buffer,15) == NULL)	//Get Dummy2
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].Dummy3 = atoi((const char*)bufptr);
					
			if(GetDataByPosition(bufptr,buffer,16) == NULL)	//Get Dummy2
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			(*pTimeBasedAction)[actionno].Dummy4 = atoi((const char*)bufptr);
			
			WriteTimeBasedAction(pTimeBasedAction);
			TransmitCharToX(C_NEW_TIME_BASED_ACTION,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);

		}	
return;
		case 101:
		{
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_TIME_BASED_ACTION_ERROR;
			actionno = atoi((const char*)bufptr);
			if((actionno > MAX_TIME_BASED_ACTIONS) || (actionno == 0))
				goto NEW_CMD_TIME_BASED_ACTION_DATAERROR;
			actionno--;
			
			ReadTimeBasedAction(pTimeBasedAction);
			TransmitCharToX(C_NEW_TIME_BASED_ACTION,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX(actionno+1,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].ActionType,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((*pTimeBasedAction)[actionno].ActionData,port);
			TransmitCharToX(',',port);
			SendDecimalToPC((*pTimeBasedAction)[actionno].ActionCompleteDate.Day);
			TransmitCharToX(',',port);
			SendDecimalToPC((*pTimeBasedAction)[actionno].ActionCompleteDate.Month);
			TransmitCharToX(',',port);
			SendDecimalToPC((*pTimeBasedAction)[actionno].ActionCompleteDate.Year);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].TimeAction.StarHours,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].TimeAction.StarMin,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].TimeAction.EndHours,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].TimeAction.EndMin,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].Dummy1,port);
			TransmitCharToX(',',port);
			SendDecimalToPC3CharToX((*pTimeBasedAction)[actionno].Dummy2,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((*pTimeBasedAction)[actionno].Dummy3,port);
			TransmitCharToX(',',port);
			SendDecimalIntToX((*pTimeBasedAction)[actionno].Dummy4,port);
			TransmitCharToX(',',port);
			TransmitCheckSumX(port);
			TransmitCharToX(',',port);
			TransmitCharToX(TERMINATOR,port);
			return;
		}
		default:
		break;
	}	
NEW_CMD_TIME_BASED_ACTION_DATAERROR: //data is improper
	errno = 3;	
NEW_CMD_TIME_BASED_ACTION_ERROR:
	TransmitCharToX('e',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
}
//======================================================================================================================

unsigned char Check_Server_MACID(unsigned char  * MY_ethernet_source_MAC);
unsigned char Check_Server_MACID(unsigned char  * MY_ethernet_source_MAC)
{
//   char temp,temp1,temp2;
   
    if(MY_ethernet_source_MAC==0)
        return 0;
	   return( Compare_Server_MACID(MY_ethernet_source_MAC,&Doorinfo.ServerMACAdress) );
}
//======================================================================================================================

/*   Server MAC adrss is array of 6 char and device mac adress is str of 12 char 

 so in  device mac adress 2 digit is combined to get 1 digit of server MAC adress 
   */
unsigned char Compare_Server_MACID(const void *ServerMACAdress, const void *DeviceMACAdress);
unsigned char Compare_Server_MACID(const void *ServerMACAdress, const void *DeviceMACAdress)
{
    unsigned char msbofdigit=0,lsbofdigit=0,digit;
    unsigned char *_ServerMACAdress = (unsigned char *)ServerMACAdress;
    unsigned char *_DeviceMACAdress = (unsigned char *)DeviceMACAdress;
	int Size = MAC_LENGTH;

    while(Size--)
	{
             msbofdigit =  (*_DeviceMACAdress >='A')?(*_DeviceMACAdress-'A'+10):(*_DeviceMACAdress-'0');
			 msbofdigit = (msbofdigit<<4)&0xF0;
			 _DeviceMACAdress++;
			 lsbofdigit = (*_DeviceMACAdress >='A')?(*_DeviceMACAdress-'A'+10):(*_DeviceMACAdress-'0');
			 lsbofdigit= lsbofdigit&0x0F;
			 digit = msbofdigit | lsbofdigit;  

        if (*_ServerMACAdress != digit) {
			return 0;  //fail                                                  // match failed
        }
		 _ServerMACAdress++;
		 _DeviceMACAdress++;
    } 
    return 1; //success                                                           // compared memory is identical
}

//======================================================================================================================

void HandleServerBasedAuth(unsigned char *buffer,unsigned char port)			//ARMF2004
{
// $1ls,1,SeqNo,CardNo,ReaderNo,DoorNo,Status,Name,
	unsigned char cmdver,errno,rdno,status,message[18];
	int cardno;
	WORD seqNo;
	_CURRENT_USER servUser;
	errno = 2;	//insufficient data
	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto NEW_CMD_SERVER_AUTH_ERROR;
	cmdver = atoi((const char*)bufptr);
	switch(cmdver)
	{
		case 1:
				if(GetDataByPosition(bufptr,buffer,3) == NULL)  	// Sequence No
					goto NEW_CMD_SERVER_AUTH_ERROR;
         		seqNo = atoi((char *)bufptr);
				if(GetDataByPosition(bufptr,buffer,4) == NULL)  	// Card NO
					goto NEW_CMD_SERVER_AUTH_ERROR;
	         	cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong(bufptr,10);
				if(GetDataByPosition(bufptr,buffer,5) == NULL)  	// Reader NO
					goto NEW_CMD_SERVER_AUTH_ERROR;
         		rdno = (char ) atoi((char *)bufptr);
				if(GetDataByPosition(bufptr,buffer,6) == NULL)  	// chno No 	= Reader NO - 1	  dummy rt nw
					goto NEW_CMD_SERVER_AUTH_ERROR;
				if(GetDataByPosition(bufptr,buffer,7) == NULL)		// Status 
					goto NEW_CMD_SERVER_AUTH_ERROR;	
				status = atoi((char *)bufptr);
				if(GetDataByPosition(bufptr,buffer,8) == NULL)  	// Name 
					goto NEW_CMD_SERVER_AUTH_ERROR;		
				memcpy(message,bufptr,16);		
				servUser.SearchCard.CardNo=cardno;
				servUser.RdrNo = rdno;
				errno = ServerChkResponseVerify(&servUser,seqNo,rdno-1);   //ARMF2004
				if(errno==0) 
				{
					if(status == EVENT_VALID_CARD)
	         			FinalAccessGranted(&servUser,rdno-1);
					else//if(Status != EVENT_VALID_CARD)
					{
					#ifdef BIO_METRIC			 
						if((DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == USER_IDENTIFY_MODE)||(DisplayMode == USER_VERIFY_MODE))
					#else
						if(DisplayMode == MODE_WAIT_FOR_CARD)
					#endif
						{
							F_KeyIdleTime = CLR;
							IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
							L_DisplayROMStr("                     ",16,ROW_CARD_ERROR_DISP);
							L_DisplayRAMStr(message,16,ROW_CARD_ERROR_DISP);
						}
						StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,status,0,0); 
						errno = 1;
					}						
				}
				else
				{
					goto NEW_CMD_SERVER_AUTH_ERROR;
				}
				break;
		default:
			goto NEW_CMD_SERVER_AUTH_ERROR;
	}
//#1s,cmdver,seqNo,cardno,ControllerNo,rdno,errno,
	PortObj[port].BufPtr = 0;
	PortObj[port].ChkSum = 0;
	PortObj[port].F_ChkSum = SET;
	TransmitReplyStartToX(port);
	TransmitCharToX(C_NEW_SERVER_COMMAND,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(cmdver,port);
    TransmitCharToX(',',port);
	SendDecimalIntToX(seqNo,port);
    TransmitCharToX(',',port);
	SendDecimalLongToX(cardno,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
    TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(rdno,port);
    TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;
NEW_CMD_SERVER_AUTH_ERROR:
   	TransmitReplyStartToX(port);
	TransmitCharToX('e',port);
    TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(errno,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	return;
}
//======================================================================================================================
/*** BeginHeader LogData*/
void LogData(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event,unsigned char LogCmd);
/*** EndHeader */
void LogData(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event,unsigned char LogCmd) //DA00139
{
	MsgPrint(MSG_WARNING,CurrentInputType,"LogData:CurrentInputType");
	switch(CurrentInputType)
   {
//    case LOG_TYPE_PROTOCOL:
// 	   if(LogEnDs & BIT_LOG_PROTOCOL)//IF protocol LOGGING IS ENABLE
// 	   {//generate transaction for add card command
// 	   	StoreCardInTrDBFull(cardno ,channelno ,event ,CurrentIPLastByte ,LOG_TYPE_PROTOCOL|LogCmd);
//       }
//    break;
//    case LOG_TYPE_KEYPAD:
// 	   if(LogEnDs & BIT_LOG_KEYPAD)//IF protocol LOGGING IS ENABLE
// 	   {//generate transaction for add card command
// 	   	StoreCardInTrDBFull(cardno ,channelno ,event ,0 ,LOG_TYPE_KEYPAD|LogCmd);
//       }
//    break;
   case LOG_TYPE_INTERNAL:
//      if(LogEnDs & BIT_LOG_INTERNAL)//IF INTERNAL ERROR LOGGING IS ENABLE
      {//generate transaction
	   	StoreCardInTrDBFull(cardno ,channelno ,event ,0 ,LOG_TYPE_INTERNAL|LogCmd);
      }
   break;
   }
}
//======================================================================================================================
	
unsigned char *HandleEnhancedProtocol(unsigned char *buffer,char port)			  //ARMF2005
{
 // $1lD,1,MACID,Command,
 // $1lD,2,SERNO,Command,
	unsigned char i,cmdver,*buptr;

	if(GetDataByPosition(bufptr,buffer,2) == NULL)
		goto NEW_CMD_ENH_PROTO;
	cmdver = atoi((const char*)bufptr);
	switch(cmdver)
	{
		case 1:
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_ENH_PROTO;
			for(i=0;i<6;i++)
			{
				if( ModelInfo.MACAddress[i] != AsciiToHex(bufptr[i*3]))
				{
					goto NEW_CMD_ENH_PROTO;
				}	
			}
			buptr = GetPtrByPosition(buffer,4);
			return(buptr);
		
		case 2: // Execute command if Serial number matches
			if(GetDataByPosition(bufptr,buffer,3) == NULL)
				goto NEW_CMD_ENH_PROTO;
			
			if(strncmp((char *)ModelInfo.SerialNo,(char *)bufptr,sizeof(ModelInfo.SerialNo)))
				goto NEW_CMD_ENH_PROTO;
			buptr = GetPtrByPosition(buffer,4);
			return(buptr);
	}
NEW_CMD_ENH_PROTO:
	return(NULL);
}



//======================================================================================================================



