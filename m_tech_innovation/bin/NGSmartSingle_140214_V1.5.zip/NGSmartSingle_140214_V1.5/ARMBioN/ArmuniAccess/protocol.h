#ifdef SUPPORT_OLD_PROTOCOL
	#define C_NEW_SYSTEM_INFO       't'
#endif
#define C_NEW_ADD_ADMIN				'A'
#define C_NEW_DELETE_DUMP_TRNX		'B'
#define C_NEW_ADD_CARD				'G'
#define C_NEW_DEL_CARD				'I'
#define C_NEW_RD_CONT_CONFIG		'J'
#define C_NEW_SET_TIME_DATE			'K'
#define C_NEW_ACCESS_LEVEL			'L'
#define C_NEW_INITIALISE_SYS		'M'
#define C_NEW_ACCESS_MONTH			'N'
#define C_NEW_UNLOCK_DOOR			'O'
#define C_NEW_HOLIDAY				'P'
#define C_NEW_SEARCH_CARD  			'S'
#define C_NEW_TIMEZONE				'T'
#define C_NEW_SEND_TRANS			'Y'
#define C_NEW_DUMMY_WEIGAND      	'Z'
#define C_NEW_ENHANCED_PROTO		'D'		//ARMF2005

#define C_NEW_SOCKET_AUTH			'a'
#define C_NEW_ERROR_RETURN			'e'
#define C_NEW_BULK_ADD_CARD			'g'
#define C_NEW_LAST_CARD				'i'
#define C_NEW_DUMP_TRNX				'j'
#define C_NEW_IOEVENT_TYPE			'k'      //FA00070
#define C_NEW_SEND_MODEM_COMMAND	'm'
#define C_NEW_ADDMESGTODISP   		'o'
#define C_NEW_OTHER_PARA_SETTING 	'r'
#define C_NEW_SYSTEM_INFO_STRUCT	'u'
#define C_NEW_N_SRS_SYS_INFO_STRUCT		'p'
#define C_NEW_VERSION_COMMAND			'v'
#define C_NEW_FINGER_TEMPLATE			'x'
#define C_NEW_SMARTCARD_COMM  			'y'
#define C_NEW_DUMMY_CARD        	 	'z'
#define C_NEW_TEST_COMMAND				'c'
#ifdef	ENABLE_EMAIL_SEND
	#define C_NEW_EMAIL						'C'
#endif
#define C_NEW_TIME_BASED_ACTION        	'n'	//ARMF0252 
#define C_NEW_SERVER_COMMAND			's'

#define C_NEW_SUB_READ_FINGER			1
#define C_SUB_ENROLL_FINGER				2
#define C_SUB_ENROLL_FINGER_CHECK		3
#define C_SUB_ENROLL_DUP_FINGER			6
#define C_SUB_ENROLL_DUP_FINGER_CHECK	7
#define C_SUB_ENROLL_FINGER_SD			8
#define C_NEW_SUB_READ_FINGER_SD		58
#define C_NEW_SUB_READ_EXTRAINFO		59

#define C_NEW_SUB_GET_USER_INFO			20
#define C_NEW_SUB_DEL_USER_INFO			21


#define C_NEW_SUB_READ_SYS_PARA			101
#define C_NEW_SUB_WRITE_SYS_PARA		100
#define C_NEW_SUB_SAVE_SYS_PARA_EEPROM	105
#define C_NEW_SYSTEM_BUSY		 		200
#define C_NEW_SYSTEM_NORMAL				201

#define C_NEW_SUB_VERIFY_TEMP			30
#define C_NEW_SUB_VERIFY_TEMP_PC		31
#define C_NEW_SUB_VERIFY_TEMP_SMART		32


#define NEW_CMD_TEMPLATE_ERROR	3

//InoutEmployee Display Protocol
#ifdef SUPPORT_7SEG_DISPLAY               //A00014
	#define STXBIGDISP   0xB2  //0xB2   //'%'             //shree 17July
	#define ETXBIGDISP   0xA3  //0xA3   //'&'             //shree 17July
	#define BIGDISPADDR  0x00                          //shree 17July
#endif

extern SYSInfo SysInfo;
extern struct DOOR_INFO Doorinfo;
extern BYTE PercentageMem;
extern unsigned int TransFreeLocation;
//extern unsigned char bufptr[PAGE_SIZE];		// locally used variable
extern struct SYS_MODEL_INFO ModelInfo;

__packed struct  PROTOCOL_CMD_HNDL
{
	BYTE command;
	BYTE Type;
	BYTE Len;
	BYTE *VChar;
	__packed WORD *VInt;
	unsigned int *VLong;
	BYTE *VStr;
	__packed BYTE ParaName[17];
	BYTE Settable;
};

#define D_CHAR   		'C'
#define D_INT   		'I'
#define D_LONG	 		'L'
#define D_STR	 		'S'
#define D_BIN	 		'B'
#define D_ARRAY_CHAR 	'A'
#define D_ARRAY_INT		'a'

#define MAX_SET_SYS_PARA  97      //85 A00017
#define READ_ALL_PARA  		200      
#define WRITE_ALL_PARA  	201      
//extern unsigned char InOutTime1;			// If ContInOut =4 then following will store time zone number to toggle
//extern unsigned char InOutTime2;
//extern unsigned char InOut1;            // If ContInOut =4 then following will store what to do for that time zone InoutTimeX
//extern unsigned char InOut2;

//
#ifdef BIO_METRIC
	#define MAX_USEFUL_PARA  19
#else
	#define MAX_USEFUL_PARA  16
#endif

// Following structure is used to read current conditions of some imp variables in system
// we can read these using $1lr command and we can also set same.
// if last variable Settable =1 then we can set and if same is 0 the we can not write same.

#define MAX_OTHER_PARA  17	//it is limit of OtherPara[] ,lr command
extern BYTE F_FirmwareUpgrade;
extern BYTE F_ImageUploadInProcess; //NGD00026

#define SECURE_AUTH_ADMIN				0
#define SECURE_TRNX_DWNLD_IP_CHK		1
#define SECURE_MAC_CHK					2

#define BIT_TRNX_DWNLD_IP_CHK		0x01  //F0039  Security Implementation for network communication
#define BIT_MAC_CHK					0x02

#define NUM_SOCKS 3 			//(NUM_LISTEN_SOCKS+1)

#define STATE_CLOSED				0		// Initial state, must be zero.
#define STATE_LISTEN				1
#define STATE_ESTAB					2
#define STATE_CLOSING				3
#define STATE_DATA_RECEIVED			4
#define STATE_DONT_USE	     		0xFF		// must be less than 0

#define SOCKET_AUTH_SUCCESS  1
#define SOCKET_AUTH_FAIL  0
extern USOCKET Socket_TCP;
  
struct MYSOCKET_INFO
{
	unsigned char SocketState;
	unsigned char SocketTimeOut;
	unsigned char Status;
	unsigned long ClientIP;
	unsigned long Server_MAC_ID;
};
extern struct MYSOCKET_INFO  SocketInfo[NUM_SOCKS];

extern TCP_CONTROL *PresentTcpPtr ;
extern unsigned char PresentTCPStatus;
extern USOCKET USER_TCP_socket;

extern void HandleNewCommandGroup(unsigned char *buffer,unsigned char port) ;
extern unsigned char *GetDataByPosition(unsigned char *dst,unsigned char *src,unsigned int pos);
extern unsigned int SendTransactionWithSaperator(unsigned char port);
//extern void SendSerialSendTransSaperator(struct TRNX_DATA *trans,unsigned char port,unsigned int readptr);
//extern void HandleSerialTemplate(BYTE *buffer,BYTE port);
extern unsigned char GetHexStrByPosition(unsigned char *chrstr,unsigned char *src, unsigned char pos);
//extern unsigned char HandleNewSearchCard(unsigned char *buffer,unsigned char port);
extern void DisplaySensorBusyMessage(void);
extern void HandleSystemParaSetting(unsigned char *buffer,unsigned char port);
extern void HandleSerSmartCard(unsigned char *buffer,unsigned char port);
extern void HandelLastCard(unsigned char *buffer,unsigned char port);
extern void HandleOtherParameterSetting(unsigned char *buffer,unsigned char port);
extern void HandelNewTimeZone(unsigned char *buffer,unsigned char port);
extern unsigned char HandleSerialTemplate(unsigned char *buffer,unsigned char port);
extern void SendCardDataToPC(int pos, CardData empcard,unsigned char port);
extern void SendNewCardDataToPC(CardData empcard,char fingerid,unsigned char port);
extern unsigned char SendUDPAlert(unsigned char event,unsigned char channelno,unsigned long data1,unsigned int data2,unsigned char port);
extern unsigned char SendUDPTransaction(struct TRNX_DATA *trans,unsigned char port);

extern unsigned char HandleSerialAuthCheck(unsigned char authtype,unsigned char port);
extern void NSeriesPhase2ParaSetting(unsigned char *buffer,unsigned char port);
extern void HandleNewAddAdminCommands(unsigned char *buffer,unsigned char port);
extern void HandleTimeBasedActions(unsigned char *buffer,unsigned char port);
extern unsigned char Check_Server_MACID(unsigned char  * MY_ethernet_source_MAC);
extern unsigned char Compare_Server_MACID(const void *ptrTo, const void *ptrFrom);
extern unsigned char SendUDPToIPPort(struct TRNX_DATA *trans,unsigned char port, char *ip,short ipport );
extern unsigned char SendHBString(unsigned char port, char *ip,short ipport );
#ifdef SUPPORT_7SEG_DISPLAY 
extern void SendINOUTCountToDisplay(unsigned int count,unsigned port);
#endif

extern unsigned char *HandleEnhancedProtocol(unsigned char *buffer,char port);
//==============================================================================
#define MAX_ALARMS		15

#define FIRE_ALARM_RESET		AlarmACKFlg[0]		 		//$1lO,20,1,1/0,
#define TAMPER_ALARM_RESET		AlarmACKFlg[1]				//$1lO,20,2,1/0,
#define INTRUSN_ALARM_RESET		AlarmACKFlg[2]				//$1lO,20,3,1/0,


#define DOTL1_ALARM_RESET		DRStruct[0].ResetAlarm		//$1lO,20,32/33,1/0,

//==============================================================================
#define MAXDISGRP	  200
//==============================================================================
extern void TestTFT(void);
