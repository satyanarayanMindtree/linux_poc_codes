/******************************************************************
 *****                                                        *****
 *****  Name: Armaccess.c                                       *****
 *****  Ver.: 1.0                                             *****
 *****  Date: 13/02/2008                                      *****
 *****  Auth: Mukund Dongare                              *****
 *****  Func: implements a dynamic HTTP-server by using       *****
 *****        the easyWEB-API                                 *****
 *****                                                        *****
 ******************************************************************/
/*

ERROR CODE MEANINGS: 
===================
http://www.keil.com/support/man/docs/armerr/armerr_BABDJCCI.htm

=============
Version 2.0
=============
22-Jun-2010:
ARMD0112	Watchdog Implementation
ARMD0113	Slave buffer initialisation issue at startup
ARMD0114	Display MAC Address in service menu and version string
ARMD0115	Add protocol to read ARM registers

26-Jun-2010:
1) Add code for testing to generate auth cards after every 5 sec  (#define TEST_SYSTEM)

=============
Version 2.1
=============
1) Implemented Virdi Support in ARMBiolite.

=============
Version 2.2
=============
08/11/10
1) Added error count while polling for slave 485 readers.
{13,D_INT,5,&W,&BadDataCounter,&Z,Y,"Bad Data Counter",1},        
{14,D_INT,5,&W,&SlaveNoResponseCounter,&Z,Y,"SLNoResp Counter",1},        
{15,D_INT,5,&W,&BadDataDayCounter,&Z,Y,"BadDataDayCount ",1},        
{16,D_INT,5,&W,&NoRespDayCounter,&Z,Y,"NoResp DayCount ",1},
if Bad data packet count is displayed on LCD if counter >= 5
2) Added Chksum verification for slave response
 
10/11/10
1) Added Parity error event for slave and controller        
Slave event --> #define SL_EV_WEI_PARITY_ERROR			254
Controller Event --> #define EVENT_WEI_PARITY_ERROR		203      

=============
Version 2.3
=============
12/11/10	//Changes for ARM bIolite
ARMD0138	User Capacity should be 250.
ARMD0139	Total templates should be 750.
ARMD0140	Transaction Capacity should be 6000.
ARMD0141	Slave ID setting up to 16 by keypad & PC command.
ARMD0142	Admin users should be 3.
ARMD0144	Global & local messages not working.

13/11/10
ARMD0135	Some parameter should set to some default value.
ARMD0136	System set templete size after every reset by PC or reset switch in auto identification mode.
ARMD0137	If I enable free time zone only for reader 2 then relay start to flicker in share DOTL.
ARMD0143	It does not shows card no. by continuous swiping of cards.

------------
13/01/11
------------
A4D	ARMD0156	Converter & reader configuration setting menu by keypad. Added *994 menu.

------------
17/3/11
------------
ARMD0167 	protocol for new door control  

17 May 2011
===========
1) Special card functionality added with Intrusion, Emergency card..
1.Initial import
2.Modified for LCD,Kp working on V1.6 Board.
3.Modified for output as per v1.6 board
4.Developed code for ip1,ip2,fire,tamper inputs.
5.485,TCP-IP Communication OK.
6.Modified for contnious o/p on error.
7.Modified for implementing 30000 users,one lakh transactions.
8.If defined ONE_LK_TXN_30K_CARDS works foe one lakh txn and 30k cards.
9.Added f/w upgrade thru serial.
10.Firmware update implemented.
11.Implemented chicp select enable,disable logic.
12.Reviewed by Pankaj Sir. included seperate h/w files for armbiolite and armbiosmart.
13.Added few special cards(pankaj sir),intrusion thru kp.
14.Modified for controller types.
15.Modified for f/w upgrade protocol.
16.Modified for controller types(6,7 will be set to 0).in biosmart.
17.Added f/w upgrade msg.
18Modified for:
Set Yes No option to add finger for first time card addition.
19.modified for bug :
Remove smart template & finger sense type from *93 keypad menu.
20.modifying for standalone unit.
21.modifications done for standalone unit.
modified shared dotl in default condition.
22.Flash msgs,pinprox,Phase 2 features.
23.Modified for empincount.
24.implementing code for dual finger auth,month wise tz setting,dead manzone done.
25.blk admin login,beep enable/disable.
26.PARTIALLY IMPLEMENTED CODE FOR ADMIN AUTHORITY LEVELS.

31-July-2011
1) UDP Server implemented now all Commands can be sent using UDP protocol 
We use UDP Push port number for same which is default to 2001.
2) Implemented UDP authentication for secure download.
3) Implemented DNS server set from Keypad and missing setting like UDP IP/ TCP Push IP etc.. 
4) Taken care buffer issue with UDP Push 
5) Changes SerPort structure so we allocate memory where it is required.

3-Aug-2011
1) Added Delay in startup for display initialise...

ARMD0250 : display cursor is not proper some time
4/08/11
ARMD0251 : pinprox for 4dr4rd is not working properly

-------------
05/aug/2011
ARMF0252 : timed APB reset feature
6 Aug 2011
A4R	ARMD0254	Card add issue in 8 digit mode for 111-11111 card

8 Aug 2011
1) Time based action is not read at start-up
10 Aug 2011
===========
1) Added DIS Code for 4 and two door

ARMD0261	After deleting all admin user default admin id also get deleted it required to off on the system to enter in admin mode.
ARMD0262	New admin command not worked properly. Remove old admin command. Admin not get added by *92 keypad menu properly. It shows memory full message.
ARMD0265	It shows  no in  reset transaction in place of card no. 
ARMD0256	Shows acces type & card type in transaction for 

16 Aug 2011
===========
ARMD0260 : Door not get open by egress switch when tamper is on.
		   when buzzer is ON it takes more time to read egress,fire...all in puts.
but because of this modification buzzer sound is not proper.

17 Aug 2011
===========
ARMD0264 : Unit get hang by sending reset command by PC & keypad when fire & intrusion is ON.

17 Aug 2011
===========
ARMD0259 : display msg for escort card is given as "Special card 0000" change this as sp.card 0000 is alert card
		   escort card is card type 1

1)ARMD0266 : Added new read Door status command and Read current fire and tamper status

$1lO,110,
#1O,10,Fire status,Intruson Status,Tamper Status,Transaction Full,Other1,Other2,Other3,chksum,enter

$1lO,111,
//#1O,11,noofdoors,D,Doorno,MCStatus,Door Egress,Door Status,Current Relay Status,Door Alarm,Card No,FC Code,Other1,Other2,Other3,D,Doorno,MCStatus,Door Egress,Door Status,Current Relay Status,Door Alarm,Card No,FC Code,Other1,Other2,Other3,.....

Door statuis ==> 
#define DR_NORMAL				0
#define DR_EGRESS_OPEN			1
#define DR_ACCESS_OPEN			2
#define DR_TZ_OPEN				3
#define DR_FIRE_OPEN			4
#define DR_USER_OPEN			5
#define DR_USER_CLOSE			6
#define DR_INTRUSION_CLOSE 		7   //F0011 Checking of Intrusion Alarm
#define DR_EXT_RLY_ON			8

2) Added stack read command to improve deabuging.. Modified utasker code.

17 Aug 2011
===========
ARMD0274 : Special card functionality not works preoperly.
1) It works as escort card for all special card types if I add card by setting APB field to 1 & generates same event code.
2) Set different event code for all specical card.

19 Aug 2011
===========
ARMD0275 : give special card name to corresponding card,avoid displaying spl card number.
ARMD0273 : Admin do not add by showing card to reader 1 & admin log is not worked for card only.
20 Aug 2011
=-=========
1) Admin user menu accessiable by Card Also...

22 Aug 2011
===========
ARMF0279 : admin id change from 8 to 16

23 Aug 2011
===========
ARMF0283 : add normal card to reset effect of fire card.

24 Aug 2011
===========
ARMF0284 : add socket read command, it reads which socket is connected to which IP and PORT,and it status.

24 Aug 2011
===========
ARMF0285 : delete special card command and delete specialcard info command
===========
ARMD0286 : override access card must not toggle between old and new controller type
ARMD0291 : Admin do not log out after 1 min
ARMD0292 : Admin get log out after 1 min automatically even keypad in use.
ARMD0290 : It shows 5 digit card no after adding 10 digit admin user when cotroller in 10 digit mode.

31 Aug 2011
===========
ARMD0295 : while deleting special card no need to want convert into normal card
ARMD0264 : Unit get hang by sending reset command by PC & keypad when fire & intrusion is ON.
ARMD0296 : first in user not working.

06 sEP 2011
===========
ARMD0301 :Messages Problems: Tamper, Fire, Instrusion


07 SEP 2011
===========

ARMD0305: welcome message display problems
ARMD0306:Occupancy control decrement count error(decrementing InEmpCount on zero value also)

07 SEP 2011
===========
ARMD0307: Share DOTL of reader1 and reader 2 getting enabled after reset the unit and in delete door info.(initially = 0).

A2R	ARMD0308	on pressing egress switch msg displayed DOOR CLOSE contniously

12 SEP 2011
===========
ARMD0315:	unit doesn�t come in normal mode *0 for unauthorised card in set mgd id to access type.
ARMD0309:   on setting f/w upgrade flag unit displays user restricted msg.
ARMD0316:	unit  to come in normal mode *0   after 20 sec in set msg id to access type (*3,*4,*5,*6,*7,*8)..

ARMD0320:   while in verify mode if finger is not placed(first user) 
                    and other card is shown(second user and second user finger placed) suprema gives finger mismatch.
ARMD0321:   in dual finger auth mode if first card is shown(finger not placed) 
                   and then second card shown and finger placed access granted for valid finger. 	
                   Also modifications done for firmware upgrade msg display.	ARMD0309
15 SEP 2011
===========
ARMD0322	Fingerprint transfer from BIOsmart to BIOsingle with weigand out. Not working

16 SEP 2011
===========
ARMD0326 intrusion not working

17 SEP 2011
===========
ARMD0324:UID by keypad is always enable same as rabbit.
ARMD0325:Card buffer should be same as 4dr 4rd i.e. 12210. Now it adds 12000 cards only.
         //restricted to MAX_NO_OF_CARD.
ARMD0257:Set card only card type to user if finger not required when  added by *3 menu in biometric unit.	
ARMD0217:By searching cards $1lS,22, conmmand in reaponse it will send following data at start 
          #1#1,S,22,00001,0000000010,00010,127,001,001,000,000,005,53	 
		  
19 SEP 2011
===========
ARMD0312:admin login by finger.	

20 SEP 2011
===========
ARMD0325:Dual user auth not working properly.

21 SEP 2011
===========
ARMD0325:User ID not taken from keypad in A2R f/w.	

03 OCT 2011
===========
ARMD0193: Support card type from Keypad
ARMD0318: bulk card addition by keypad  

08 OCT 2011
===========
ARMD0332:Does not give access to enter pin after showing card or entering user id from keypad.

10 OCT 2011
===========
ARMD0333 : global,local msgs not working in A2R.
ARMD0334: Transperent slave mode not working when master starts first and then slave startsup.
          soln given: get data from slave only if command sent from master.
		              avoid data thrown by slave on startup.
12 OCT 2011
===========
Modifications done as follows.
//#define MAX_SPL_CARD					128			// instead of 32
DEAD_MAN_ZONE modifications done as follows in biosmart , smart single:
1.#define SP_CARD_DMZ_RESET_TYPE          8 //Dead Man Zone Reset card
2.Event type stored in txn.
#define EVENT_DMZ_RESET_CARD		      71         if spl crd info == 0x00
#define EVENT_DMZ_RESET_DOOR_OPEN_CARD  72        if spl crd info == 0x01
3.Relay 2 operated if ioevent enabled for dead man zone.
Event 71 = dead man zone reset card
Event 72 = dead man zone reset card with door open
4.Don't check expiry validity ,APB for dead man zone reset card
5.Dead man zone time in minutes
6.Txn. Stored if door opened (event = 72)

*993 included in smart single

12 OCT 2011
===========
1.event type #define EVENT_DMZ_RESET_DOOR_OPEN_CARD  72  removed.

13 OCT 2011
===========
modifications assigned by Pankaj Sir.
1)	We should keep this in slave file and not in main file. ARMD0341
2)	We should stop use of #ifdef SUPPORT_NSERIES2 and go ahead and add code directly. ;from now onwards it will be done.
3)	Remove code to avoid confusion Timer.c :done
9) I do not think dead man zone is working fine as we do not call function UserAccessGranted in case of special card.: calling 
		if(Doorinfo.EnDisDeadManZone == 0x01)
		{
		if(tdata == EVENT_DMZ_RESET_CARD && F_DeadManZone_DoorOpen == 0X01)//write txn. as DMZ door open and then open the door.
			DoorOpenForTime(1);//Dead Man Zone reset + door oped Special card.
		F_DeadManZone_DoorOpen == CLR;
		}//	if(Doorinfo.EnDisDeadManZone == 0x01)
For normal user we are reseting dead man timers.. //we are not resetting for normal users ,we are resetting only for dead man spl card
5) (UserIntf.c) Do we still need  following structure as we can use only new structure which has admin details ?  will be done in next release.
11) We should use some sort of #define for special card deadman with door open. Done #define DOOR_OPEN_BY_DMZ_CARD 1  
3) Why we need F_DeadManZone_DoorOpen = CLR;  instead of this we can use common variable like SpecialCardDoor open : done ARMD0343
8) We need to change display message Ded Man Card as this gives bad information that we are asking dead man to show card :-) Get some good name from mkt.
"DMZ RESET CARD� given temporarily if not accepted will be changed by consulting marketing.
10) We should call UserAccessGranted for door open type of deadmanzone by returing 0 from GetUserInfoAndProcess 
 and manage specail card bit in USER_CARD_INFO *empcard structure to manage diferently in this functions.. 
like apb will not be checked for special card.  Done ARMD0342
ON SHOWING DMZ RESET CARD 2 TXNs generated:
dmz card
#1T,001,071,0000035492,135305,131011,00002,00000,000,002,4A, 
Valid card
 #1T,001,001,0000035492,135305,131011,00001,00001,000,002,4F,
 ARMD0335	By setting read name from unit then by showing card to reader 2 it shows name properly
                   but same time it shows card no too.
ARMD0336	When I shows normal valid card before showing first in user card it gives access 
                    to valid card and after showing first in user card it shows message Show Access Card for valid card 
		i.e when I enable this fuctionality first time.
ARMD0340	It shows 5digit pin no  if I add card by *9993 keypad menu & by adding card by *3 menu it
                   shows 4 digit pin no. This is happened only in 5 digit card no setting.
14 OCT 2011
===========
Assigned by pankaj Sir.
ARMD0344:
Bio sensor baudrate hardcoded to 57600.
1)	uart.c 
      Remove following comment for biometric port :Done

void SerialInt(void)
{
  SysInfo.BaudRate[SER_BAUD_BIO] = 57600;              //uart2
}

ARMD0338: If I prgram name to card and by showing this card it shows name properly but after  
         "Occupancy Full" message If I show card then it shows card no in place of name.
ARMD0343: In out toggle mode not worked.
ARMD0345: Since if i show card on reader 2 and after some time if i am pressing keys 
*2 am getting msg ** MemoryFull ** instead of Admin menu for the first time only.
and the cycle continues.
ARMD0346:Access granted but txn. not stored in case when memory is full and *2 pressed.

15 OCT 2011
===========
ARMD0349:DOTL En/Ds bit not bocomes 0 in reader info command after OFF ON by changing 
controller type to atten & atten. No check by parameter 10.	   

19 OCT 2011
===========
ANS:ARMD0356 : Weigand out not worked properly, functionality and display issue
ARMD0352: It shows 4= Sechudled InOut. Recorrect name as scheduled InOut
ARMD0355:There should be *9992 keypad menu weigand out bit seconds
ARMD0354:It shows Reader config menu when we go by *8 keypad menu.

ARMD0357:weigand count display in *9992 menu

ANS	ARMD0357	weigand count display in *9992 menu	Verify
ANB	ARMD0358	Display system information (*991) gets display without admin login.	Open
ARMD0359	It shows finger not found message, when we have selected card 
                    only card option and also generates user access and user not found transaction.

02 Nov 2011
=============
1) Added code for UDP Heart Beat
2) Added three new programming parameter in Network programming
   a) Heart Beat Server IP
   b) HeartBeat Port Number
   c) HeartBeat Time interval in min. If this is zero we will not send hearbeat.

23 jan 12
=========
ARMD0335	By setting read name from unit then by showing card to reader 2 it shows name properly but same time it shows card no too.
            name display from unit is not working in sio49 basic release
17 Nov 2011
=============
ARMD0373	unit in 8-digit mode shows garbage value if card number is > 65535,which must show 000-0000

17 jan 2012
============
ARMF0384 :$1lj,3,no.of transaction,trans read pointer,
			$1lB,2,DeleteTrnxCount,read pointer,Chksum,ENT
			this commands are added so that same commands come twice it will not not give improper result
			which might happen in udp commands.
ARMF0385 : new parameter is added for udp server port

24 jan 2012
============
ARMD0374  :	LED of reader 2 remains red for valid user If I set IN OUT toggle mode in Bio access 2 RD 
           cotroller type (For IN entry) . 8=3,10=1
ARMF0388  : in reader mode In finger sense mode, after verification it takes 15  secs to enable sensor.   9=4,8=5,it should be door time
ARMD0375  : In weigand reader mode LED of reader 2 not becomes green for access granted


07 Feb 2012
===========
1) void HandleWeiCardDataDisplay(unsigned char keytype)		//star+9995	
	Function Added to Display Received Weigand Card's CardBits,RawData,ExtraData,Actual CardDAta in HEX & Decimal   

2) void HandleSetSharedDOTL(unsigned char keytype)		  	//star+9996
	Function Added to SET or CLR Shared DOTL Of respective ReaderNO which is to be passed from keyboard.Saved to EEPROM.

12 Feb 2012 
===========

1)  Generate Alarm from Command: 
    Do not consider what is there at hardware but generate that alarm
    It is assumed as if alarm is come from hardware.
    This alarm will go away by command again by putting 0 instead of 1.
    If any one send reset alarm command then also this alarm will go away.

Fire,Tamper, Intrusion ==> yes
NOTE: SET/RESET These following parameters first  
---- 	
Parameter No.14(Needed) & 74(Optional):	0=Resest All,
										1=Fire,
										2=Tamper,
										4=Intrusion 

NOTE:Parameter No 14 must be set to ENABLE that Particular Test. 
----
AlarmGenerateFlg[0]:$1lO,20, GenerateFireAlarm, ==>    $1lO,20,1,1/0, 	==> DONE
AlarmGenerateFlg[1]:$1lO,20, GenerateTamperAlarm, ==>  $1lO,20,2,1/0, 	==> DONE
AlarmGenerateFlg[2]:$1lO,20, GenerateIntrusionAlarm,==>$1lO,20,3,1/0,	==> DONE


//$1lO,120,	 	==> to read the alarms present at this time with total alarms

13 Feb 2012 
===========

2) Reset Alarm from Command (ACKNOWLEDGEMENT):
   If any alarm is present please reset same and do not make any work for that 

alarm etc.. 
   This reset is only for current condition and if that condition goes away and again alarm 
   comes then we should again generate alarm even alarm was reseted 
Fire,Tamper,Intrusion ==> yes
DOTL,ForeAlarm	==> Yes

AlarmACKFlg[0] :$1lO,21, Fire_AckAlarm,		//$1lO,21,1,		===> DONE
AlarmACKFlg[1] :$1lO,21, Tamper_AckAlarm,	//$1lO,21,2,		===> DONE
AlarmACKFlg[2] :$1lO,21, Intrusion_AckAlarm,//$1lO,21,3,		===> DONE

14 Feb 2012 
===========
1) DOTL Alarm or Force alarms comes 
	Storetransaction
	Displayondisplay
  	Buzzer ON 
2) Use send reset command to indicate I have seen this alarm 
	Display should stop
	Bizzer should go to normal
3) Again DOTL alarm comes 
	Go to step 1 

DRStruct[0].Dotl_Alarm :$1lO,21, >DR1Dotl_AckAlarm,		//$1lO,21,32,	===> DONE
DRStruct[0].Force_Alarm:$1lO,21, >DR1Force_AckAlarm, 	//$1lO,21,33,	===> DONE
DRStruct[1].Dotl_Alarm :$1lO,21, >DR2Dotl_AckAlarm,		//$1lO,21,48,	===> DONE
DRStruct[1].Force_Alarm:$1lO,21, >DR2Force_AckAlarm, 	//$1lO,21,49,	===> DONE
DRStruct[2].Dotl_Alarm :$1lO,21, >DR3Dotl_AckAlarm,		//$1lO,21,64,	===> DONE
DRStruct[2].Force_Alarm:$1lO,21, >DR3Force_AckAlarm, 	//$1lO,21,65,	===> DONE
DRStruct[3].Dotl_Alarm :$1lO,21, >DR4Dotl_AckAlarm,		//$1lO,21,80,	===> DONE
DRStruct[3].Force_Alarm:$1lO,21, >DR4Force_AckAlarm, 	//$1lO,21,81,	===> DONE

16 Feb 2012
===========
To read All Parameters in one command

//$1lu,200,paramstart,noofparam,

29 feb 2012
============
ARMD0392	:	PINprox for ANS2.9 is not working properly

18 Feb 2012
===========	
To set Particular Parameter
	
//$1lu,201,setparano,paraData,		   

24 Feb 2012
===========
//ARMF2002://Implement DoorAccess
	 Implement DoorAccess Command
	 Add in existing command
	 Individual or groupwise DoorAccess
>>>> Uncomment #define EN_DOORACCESS to Enable this functionality in config.h


26 apr 2012
===========
ARMD0447  :	It gives "login disable" message when we admin login using Admin 
			user 11111 and password 12345 after firmware upgradation from ANB2.8 to ANB3.1.

03 may 2012
===========
ARMD0452 : Sometimes unit dosent reponse to TCP communication & if I enter in *990 keypad menu then system start to ping.


05 May 2012
===========
SysInfo.ControllerType is changed to ReaderInfo[].CntrolrType as we need to add controllertype readerwise.

26 apr 2012
===========
ARMD0447  :	It gives "login disable" message when we admin login using Admin 
			user 11111 and password 12345 after firmware upgradation from ANB2.8 to ANB3.1.


14 May 2012
===========
//ARMF2003N: DMZ
Two different modes
1) Any one can reset DMZ
   Doorinfo.EnDisDeadManZone  == 2
2) Only specific person can reset DMZ
   Doorinfo.EnDisDeadManZone == 1

1) 	when Doorinfo.EnDisDeadManZone  == 2 DMZ card is also a normal card
	so if that card is shown on any controller even DMZ enabled/ available or not he 
	will get access and door will get opened
	Now if for that card DMZ is enabled then DMZ transaction will be generated if DMZ is active  and we will reset the active DMZ.

2) 	when Doorinfo.EnDisDeadManZone  == 1 DMZ will work as previously and resetted only by using DMZS SPECIAL CARD and other than DMZ time elapse it will act as normal card.

12 july 2012
=============
ARMF0502   :menu for pinging gateway and public dns server is added. This menu is added for debugging of network
			Variable width dummy data send cmd is added. new utasker stack is added.

07 jan 2013
NGARM01  : In NG Biosmart we will not Display Verification Procedure in any mode if Card is shown From Exit Reader  

02Sep2013

NG0001	On back key pressed we get unit hand for some time as we go in loop for one sec.
NG0003	During finger delete we should not hang for 1 sec and use second row to display information.
NG0005	Card memory getting overwritten while adding card in same buffer

04Sep2013

NG0006	In $1lS,24 command for zero Birth date we do not sent "," between birth date and month
NG0007	If Card added without template in SD Card and if we show that card unit display hands while asking for template.
NG0012	We can not store date after CARD_NAME_BYTES in name array as it may overwrite other data
NG0013	In Search card $1lS,24,  we send card name as biger size data then 16 bytes,
NG0014	If template in SD has bad size data then we should give error and do not send template to sensor.
NG0015	do not hardcode MAX_TEMPLATE_SIZE in code as 384 use #define value
NG0016	we should pass template block no to verifySD template function
NG0019	In Finger from keypad for SD card finger template size is not written properly
NGD00066	Reader Info Setting Related(PIN En/Ds) : 	When we Enable PIN in Reader Info Setting through Test Software PinProx TimeOutR message display on center of unit Display and another one value shows on Time & Date Bar.(i.e. 1)

02/10/13
NGD00080	Some Sd card FAT 32 not Found msg coming

*/

#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include <stdlib.h>		
#include <stdio.h>
#include <string.h>

extern USOCKET MyUDP_Socket;//ARMF0249

extern unsigned char Stack_Mem;
#define HEAP_START_ADDRESS  &Stack_Mem                           // Keil - start of stack
													      
#define extern            // Keil: Line added for modular project management
#define VERSION_HEAD

#include "config.h"
#include "portdef.h"
#include "type.h"
#include "timer.h"
#include "target.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"
//#include "EMAC.h"         // Keil: *.c -> *.h    // ethernet packet driver
//#include "tcpip.h"        // Keil: *.c -> *.h    // easyWEB TCP/IP stack
#include "webpage.h"                             // webside for our HTTP server (HTML)
#include "target.h"
#include "irq.h"
//#include "extint.h"
#include "fio.h"
#include "portlcd.h"
#include "spi.h"
#include "Access.h"
#include "serial.h"
#include "Smartcard.h"
#include "userIntf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "memory.h"
#include "Keypad.h"
#include "INOUT.h"
#include "Cardmgmt.h"
#include "memmap.h"
#include "rdcont.h"
#include "rdpoll.h"
#include "version.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif
#include "ProcessWeiCard.h"
#include "weigand.h"
#include"App.h"

#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/application_lcd.h"                                             // {46} LCD tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/ADC_Timers.h"                                                  // {46} ADC and timer tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/iic_tests.h"                                                   // {46} iic tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/Port_Interrupts.h"                                             // {46} port interrupt tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/can_tests.h"                                                   // {46} CAN tests
#include "../../uTaskerV1.4_LPC/stack/tcpip.h" 
#include "protocol.h"
#include "emailsend.h"
#ifdef ENABLE_SLAVE_SUPPORT            //FA00090
#include "TransparentSlave.h"
#endif

#ifdef 	extern
	#undef	extern
	#endif
	#include "../../GLCD/drivers/lcd/tft/lcd.h"
	#include "../../GLCD/drivers/lcd/tft/drawing.h"
	#include "../../GLCD/drivers/lcd/tft/fonts/dejavusans9.h"
	#include "../../GLCD/drivers/lcd/tft/fonts/dejavusansbold9.h"
	#include "../../GLCD/drivers/lcd/tft/fonts/dejavusansmono8.h"
	#include "userIntfGLCD.h"
	//#include "touchscreen.h"
	#include "../../GLCD/drivers/lcd/tft/touchscreen.h"
	#include "../../GLCD/drivers/lcd/tft/bmp.h"
	 #include "../../GLCD/BMPImage/sea3_565.h"
	#include "../../GLCD/drivers/lcd/tft/fonts/veramonobold11.h"

#define	extern
//#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
//#include "../../uTaskerV1.4_LPC/uTasker/driver.h"
//#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
//#include "../../uTaskerV1.4_LPC/uTasker/utasker.h"
//#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/taskconfig.h"
#include "SplCardMgnt.h"
#include "ServerCheck.h"
//#include "smartcard.h"
#include "TcpPush.h"
#include "GSMModem.h"
#ifdef SUPPORT_SPEECHIC
	#include "DriverSpeech_IC.h"
#endif
	#include "IClassRdr.h"
	#include "IClassRdrProcess.h"

#ifdef INSERT_SDCARD
	#include "../../SDCard/fat32.h"
	#include "../../SDCard/SD_routines.h"
	#include "../../SDCard/NewSdMain.h"

	u32 gulSysTick = 0;
	u8 gucWriteReadBlockEnable = 1;	// 1 = Write and read a single block
	u8 gaucDebDuf[100];				  
#endif

#ifdef SUPPORT_TOUCHKEYPAD
#ifdef NEW_TOUCH_KEYPAD
	#include "../../Touch Keypad/i2cNew.h"
	#include "../../Touch Keypad/TouchKey.h"
#else
	#include "../../Touch Keypad/i2c.h"
	volatile DWORD I2CCount = 0;
    volatile BYTE I2CMasterBuffer[I2C_BUFSIZE];
    volatile DWORD  I2CMasterState=I2C_IDLE;
    volatile DWORD I2CReadLength, I2CWriteLength;	
#endif	
	volatile BYTE I2CKeyData;
#endif

#ifdef ENABLE_TCP_PUSH
	void ManagePushLogic(void);
#endif
extern BYTE F_FirmwareUpgrade;
#ifdef SUPPORT_NSERIES2
unsigned char F_DuelUserAuth;				
unsigned char F_DeadManZone,F_Spl_Crd_Dr_open ;//ARMD0343
unsigned int Temp1MinCounter;
//extern unsigned char F_FirstInUser;	
unsigned char F_DISIndicator;				//281210-1		// DIS Indicator flag
#endif
unsigned int F_BuzzerOn;
extern BYTE F_FirmwareUpgrade;
unsigned char DuelUserCounter;
unsigned char F_DISIndicator,F_DMZBuz,F_DMZOccur;				//281210-1		// DIS Indicator flag
unsigned char F_authScreenTimer,F_authScreenTimerEnable;				


const unsigned char GetResponse[] =              // 1st thing our server sends to a client
{
  "HTTP/1.0 200 OK\r\n"                          // protocol ver 1.0, code 200, reason OK
  "Content-Type: text/html\r\n"                  // type of data we want to send
  "\r\n"                                         // indicate end of HTTP-header
};

#ifdef DISP_EVENT_MSGS_FROM_FLASH
	#define  WEL_WELCOME             0
	#define  WEL_DOOR_CLOSE          1
	#define  WEL_DOOR_OPEN           2
	#define  WEL_FREE_TIME_ZONE      3
	#define  WEL_TEMPLATE_READ_WRITE 4

#define MAX_WEL_MESSAGE		5
	const char WEL_MESSAGE[MAX_WEL_MESSAGE][17] = {
//	   "    Welcome     ",
	   "                ",
	   "    DOOR CLOSE  ",
	   "    DOOR OPEN   ",
	   " FREE TIME ZONE ",
	   " BUSY READ/WRITE",
	};
#else 
#define MAX_WEL_MESSAGE		14
const unsigned char WEL_MESSAGE[MAX_WEL_MESSAGE][17] = {
//	"    Welcome     ",
	"                ",
	" DOOR OPEN LONG ",
	"DOOR FORCE OPEN ",
	"   DOOR CLOSE   ",
	"   DOOR OPEN    ",
	" FREE TIME ZONE ",
	" FIRE DOOR OPEN ",
	" DEVICE TAMPER  ",
	"INTRUSION ALARM ",                  //shree 19Jan09
    " BUSY READ/WRITE",
	" TEMPLATE WRITE ",
	"FIRMWARE UPGRADE",//11
	" DEAD MAN ZONE  ",//12
    "Show 2nd Finger",//13
};
#endif

extern void Reset_Handler(void);
/*-------------TCPIP Variable-----------------------------------------------*/
//BYTE *PWebSide;                         // pointer to webside
//WORD HTTPBytesToSend;                    // bytes left to send
//BYTE HTTPStatus;                        // status byte 
/*------------------------------------------------------------*/\
//Structures
struct SYS_MODEL_INFO ModelInfo;
SYSInfo SysInfo;
struct DOOR_INFO Doorinfo;
_TRANSData UExTrnxData; 
Date Holiday;
//RTCTime Datetime;								    
//Date CDate;
CardData Carddata;		

SmartCardData CurrentCard;
/*------------------------------------------------------------*/\
//Flags
void SendUDPHeartBeat(void);
BYTE F_CheckSum;
BYTE F_BIO_COMM,F_WeigandStarted1,F_WeigandStarted2;
BYTE F_WeigandInterrupt1,F_WeigandInterrupt2,F_ChangeInInput;
BYTE F_FingerFound,F_KeyIdleTime,F_Password,F_UserTimeOut;
BYTE F_BulkDownload,F_SmartRDRResp;

CARDNO_DATA_STORAGE_TYPE ReceivedCardNo,LastCardNo1,LastCardNo2,cardno;
BYTE LastCardTime,LastFCode1,LastFCode2,ReaderNo,CWeekDay;
volatile BYTE Temp1SecCounter;
unsigned int ReceivedPin;
BYTE DOTLTimeOut1,DOTLTimeOut2,Door2OpenTimeOut,Door1OpenTimeOut;
BYTE COMtime,PINtime,FaclityCode,WelMessageType,DoorMode;
WORD OutLatch;
DWORD WeigandData2,WeigandData1;
BYTE magdata[10];
DWORD MAGFacility1,MAGFacility2;
BYTE WCount1,WeigandTimeOut1,WCount2,WeigandTimeOut2,DeabugLevel,ReaderNo;
BYTE FaclityCode1,FaclityCode2;
BYTE F_KeyPressed;	
BYTE MySlaveNo,CWeekDay;
WORD tdata,Serrevcont,BAUDPORT_C,BAUDPORT_D,BAUDPORT_E,Baudrate;
short i,Counter;
BYTE BannerMessage[16];
WORD InEmpCount,InEmpCount_Back;

unsigned char  CurrentIP[IPV4_LENGTH],CurrentUDPIP[IPV4_LENGTH]; //ARMF0249 // This will store ip address which called protocol communication..	
/*-------------Trnx Variable-----------------------------------------------*/
                                                                                

DWORD CARD_DATA_BASE,TIME_ZONE_BASE,HOLIDAY_BASE,ADMIN_DATA_BASE;
DWORD ExMemCARD_BASE,ExMemTIME_ZONE_BASE,ExMemHOLIDAY_BASE,ExMemADMIN_DATA_BASE;
																						
/*--------------------------------------------------------------------------*/
//global Variables uart file
volatile BYTE F_Receiver_Data ,F_Check_Slave_No,F_Receive_Serial_Data,F_Global_Command,F_Get_Slave_Data;
volatile BYTE F_SerialCommandProxy,F_secsend,F_EthernetReceived;
volatile WORD ReceiveCount,ToReceiveCount;
//volatile BYTE SBuffer[BUFSIZE];
//volatile BYTE UART2Buffer[BUFSIZE],UART3Buffer[BUFSIZE],UART1Buffer[BUFSIZE];
volatile WORD UART2Count,UART3Count,UART1Count;
//volatile BYTE BioCmdStatus;
//Global variable serial file
WORD enetptr;
BYTE CheckSumE,CheckSumC,CheckSumD,CheckSumB;
BYTE CheckSum,TempTotalDnTrnxNo;
//BYTE trnsbuffer[800];
BYTE F_CheckSumC,F_CheckSumD,F_CheckSumE,F_CheckSumB;
WORD NoOfNWTxData  ;
WORD EXCARD_COUNT,PrevBulkDownload;

//global variable access file
int LastCardAddedPtr;
BYTE FCode;
BYTE F_Dotl1_Alarm_Made_Off,F_Dotl2_Alarm_Made_Off;
BYTE UserName[20];
BYTE InOutReader ,InOutReaderTime,F_DisplayINOutToggle;
extern BYTE EmpMinCount,InEmpDispCount;
//global variable tranxmgmt file
BYTE PercentageMem;
unsigned int TransFreeLocation;
BYTE F_TransCrossOver;

#define LOC_READ_PTR	0
#define LOC_WRITE_PTR	4

#ifdef ENABLE_GSM_GPRS
//	unsigned char SignalStrength,GPRSNoDataTime;
//	volatile BYTE F_GPRSData;
#endif

//int  fnTimeListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen);

//global variable Access file
//BYTE string_buffer[BIO_BUFFER_LENGTH];
WORD ReceiveCountSERPC;
BYTE NextDisplayMode,AccessType;      //AccessType = we can mark access for Lunch, office work, dinner, For Snacks break.. etc...
BYTE AccessTypeMessage[MESSAGE_BYTES+1];
static BYTE ToggleCount;
BYTE FacCode;
// global variable smartCard reader
//BYTE UserName[MESSAGE_BYTES+1];

BYTE F_Door1_Open_TimeOut,F_Door2_Open_TimeOut,F_OneSec,F_Dotl1_TimeOut,F_100mSec=0;
BYTE F_Dotl2_TimeOut,F_Is_Dotl1_Alarm,F_Is_Dotl2_Alarm,F_Channel1_DoorClose;
BYTE F_Dotl1_Alarm,F_Dotl2_Alarm,F_Facility,F_Door1IsOpen,F_Door2IsOpen,F_LastCardCheck;
BYTE F_Channel2_DoorClose,F_Egrase1_SW_Pressed,F_Egrase2_SW_Pressed,F_Dotl1_set;
BYTE F_CardFound1,F_CardFound2;
unsigned char F_DoNotCheckAPBForCard,DoNotCheckAPBTime,SpecialCardRdNo;
extern int F_SCAN_KEY = 0;

unsigned int MaxNoOfCards;       //F0018 Add New service menu to display useful system parameters
unsigned int MaxNoOfTrans;
unsigned char FirmWareVer[8];
unsigned int BalCards;
unsigned int BalTransBuffer;
unsigned char Controllertype[16];
__packed const BYTE COMPILEDATE[]=__DATE__;   

#ifdef BIO_METRIC
	unsigned int MaxNoofTemplates;
	unsigned int UsedTemplates;
	unsigned int BalTemplates;
#endif

extern volatile DWORD ReceiveLength;
extern volatile DWORD PacketReceived;
volatile DWORD eint0_counter; 
BYTE DspRdrNo;

void InitialiseSystem(void);
int TestingFlash(unsigned int guintBlockNum);
void TestFlash(void);
void DisplayModelInfo(unsigned char count);
unsigned char ModelSerDispCount;
#ifdef BIO_METRIC
	void ValidateTemplateSize(WORD tempsz);
#endif
#ifdef SUPPORT_SUPREMA
	void ValidateBioEnrollType(WORD enrolltype);
#endif
unsigned int UDPHeartBeatCount;
#ifndef	ENABLE_ETHERNET_OLD
extern unsigned char SocketTimeOut;	  //ARMF0240
extern unsigned char SocketStatus = 0;
extern unsigned	char RemoteIP[IPV4_LENGTH]={0};
extern unsigned	short RemotePort =0;
USOCKET Socket_TCP;
extern volatile int StateUTasker;
unsigned char UTaskerMaxTasks=0;
#endif
unsigned char DisplayTempBuffer[50];
/*--------------------------------------------------------------------------*/
#ifndef BIO_METRIC
void DisplaySlaveStatus(unsigned char row);
#endif
#ifdef BIO_METRIC
	unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE]; 
//	unsigned char BufferTemp[MAX_BIO_TEMPLATE_SIZE]; 
#endif

unsigned char AdminLogOutTimer,IdleKeyCounter,F_Password;
extern char SerERcvdCn;
unsigned int AdminMenuRight;
//void IncSocketTimeOut(void);//ARMD0452
void HandleDisplayTimeOuts(void);
void DMZMainLoopManager(void);
void DualUserMainLoopManager(void);
void CheckForFirmwareUpgrade(void);

unsigned char CurrentInputType; 
extern unsigned char DisplayTempBuffer[50];

unsigned char F_SDCardStatus,F_FAT_MemStatus;

#ifdef TEST_HW
	void TestSpeechIC();
	void TestTFT();
	void Test_TouchTFT();
	void Test_LEDBAR();	
	void Test_GPRS();
#endif	
void ResetVariable(void)
{
	F_WeigandStarted1 = F_WeigandStarted2 = F_EthernetReceived = 0;
	
	TouchKeyPad.Keyfunction[0]= TOUCH_KEY1;
	TouchKeyPad.Keyfunction[1]= TOUCH_KEY2;
	TouchKeyPad.Keyfunction[2]= TOUCH_KEY3;
	TouchKeyPad.Keyfunction[3]= TOUCH_KEY4;
	TouchKeyPad.Keyfunction[4]= TOUCH_KEY5;
	TouchKeyPad.CurrentSelection =0;
	TouchKeyPad.PreviousSelection =0;

	DisplayData.GridCurrentSelection = 0;
	DisplayData.GridPreviousSelection = 0;
	
	DisplayMode = 0;
	DeviceOpMode = ADM_USR;

	ScreenFormatData.F_ImageNo = 1;
}
/*****************************************************************************
**   Main Function  main()
*****************************************************************************/
#ifdef RANDOM_NUMBER_GENERATOR
    unsigned short *ptrSeed;
#endif

extern unsigned long SecCount;
//		unsigned int tz1,tz2,txRaw,tyRaw;   //////testing

void ProcessSlaveSupport(void);		// To make code readable

int main(void)
{
int j; 
//unsigned int n;
unsigned char i,weekday,sendudp=0; 
unsigned char DoorOpen_Wigand;	
//BYTE counter = 0;
BYTE temp,priority;
#ifdef SUPPORT_ICLASS_RDR
	BYTE temp1;
#endif
	
CARDNO_DATA_STORAGE_TYPE 	tempcard;
	
#ifdef MULTISTART
    MULTISTART_TABLE *prtInfo;
//    unsigned char *pucHeapStart = HEAP_START_ADDRESS;
#endif
#ifdef RANDOM_NUMBER_GENERATOR
    unsigned short usRandomSeed;                                         // we put an uninitialised variable on to the stack for use as a random seed
    ptrSeed = &usRandomSeed;
#endif

//	DeabugLevel = 0xff;
	MyUDP_Socket=0;	
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_SYSTEM_START;
#endif

	InitialiseSystem();		
#ifdef SUPPORT_SPEECHIC
	InitSoundIC();
// 	CLR_SPEKER_BUSY();
// 	CLR_SPEKER_FULL();
// 	SET_SPEKER_BUSY();
// 	SET_SPEKER_FULL();
//	waitX10ms(100);
	
//	SendSerialCmd1(0x8d);//power UP IC
//	SendSerialCmd1(0xC5);//power UP IC
	waitX10ms(100);
//	SendSerialCmd2(0xe3,0x11);//set out2 status to 8Khz
//	waitX10ms(100);	
	#ifdef TEST_HW
		TestSpeechIC();
	#endif
#endif

#ifdef SUPPORT_TOUCHKEYPAD
#ifdef NEW_TOUCH_KEYPAD
	I2CInit();
	DIR_SDA0();
	DIR_SCL0();
	for(i=0;i<50;i++)
	{
		SCL0_HIGH();
		waitX10ms(2);		
		SCL0_HIGH();
		waitX10ms(2);		
	}
	Capsence_Init();
// 	TransmitStrToPC("KEYPAD detected.."); 
#else	
   if ( I2CInit( (DWORD)I2CSLAVE ) == FALSE )	/* initialize I2c */
//		 TransmitStrToPC("Touch Keypad Initialization failed...");
//	 else
//		 TransmitStrToPC("Touch Keypad Initialization Success...");
	//------------  message that Touch keypad initialisation fail -----------------	 
#endif	 // end of NEW_TOUCH_KEYPAD
#endif

	GLOBAL_PORT = PC_PORT;
	PortObj[GLOBAL_PORT].ChkSum = 0;
	PortObj[GLOBAL_PORT].F_ChkSum = SET;			
	TransmitReplyStart();
	TransmitStrToX((BYTE *)ProdVerStr,GLOBAL_PORT);
	TransmitCharToX(MAJOR_VER,GLOBAL_PORT);
	TransmitCharToX('.',GLOBAL_PORT);
	TransmitCharToX(MINOR_VER,GLOBAL_PORT);
	TransmitCharToX(CONTROLLER_TYPE,GLOBAL_PORT);
	TransmitCheckSumX(GLOBAL_PORT);
	TransmitCharToX(TERMINATOR,GLOBAL_PORT);

 //Carddata.CardNo = 11111;
	
 //  temporary commented
	AdmCard.AdmData.CardNo = 11111;
    if(SearchNewDisplayAdminUser(AdmCard.AdmData.CardNo,&AdmCard) == CARD_NOT_FOUND)
	{
		AdmCard.AdmData.CardNo = 11111;
		AdmCard.AdmData.CardPin = 12345;
		AdmCard.AdmData.Info.CType = 0x0A;    //UID + PIN
		AdmCard.AdminType = BIT_SUPER_ADMIN;      //Added default admin as super Admin
		AddNewAdminUser(AdmCard);
	}
	PercentageMem = GetPercentageFull(TransReadPtr,TransWritePtr);
	if(SysInfo.MemMgmt >= 100)
	{ 
	//MemMgmt >=100 indicates do not overwrite the data
		if(TransFreeLocation < 10)
			F_TrnxMemFull = SET; 				
	}
	CurrentUser.RdrNo =1; //default value
	CurrentUser.SearchCard.Info.CType = 0;
	CurrentUser.InputType = 0;
	
#ifdef ENABLE_WATCHDOG
//	CurrentUser.SearchCard.CardNo = 2;
	CurrentUser.SearchCard.Info.CType = (unsigned char)WDTResetType;
	if(CurrentUser.SearchCard.Info.CType != NORMAL_RESET)
		CurrentUser.InputType = 1;
	WDTResetType = NORMAL_RESET;
#endif

//	StoreCardInTrDBFull(0,1,EVENT_SYSTEM_RESET,0,0);	   //ARMD0265   
	
	DisplayMode = MODE_WAIT_FOR_CARD;
/************************************************************************/

#ifdef ENABLE_WATCHDOG
	WDTInit(5);			//watchdog initialization for secs
#endif

#ifdef ADMIN_NO_LOG_OUT
	F_Password = PASS_ADMIN_LOGIN;
	AdminMenuRight = 0xFF;	   
#else
	F_Password = 0;
	AdminMenuRight = 0;
#endif
	ScreenFormatData.F_ImageNo = 2;//this is default screen for wall paper.
	DisplayFormat(FORMAT_WELCOME_SCREEN);

ReceiveCount = 0;
  	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
	ModelSerDispCount = 0;
	DisplayModelInfo(ModelSerDispCount);
#ifdef ETHERNET_ENABLE		
#ifndef ENABLE_ETHERNET_OLD 
   prtInfo = ptMultiStartTable;                                         // if the user has already set to alternative start configuration
   if (prtInfo == 0) {                                                  // no special start required
//_abort_multi:
       fnInitialiseHeap(ctOurHeap, HEAP_START_ADDRESS);                 // initialise heap
       uTaskerStart((UTASKTABLEINIT *)ctTaskTable, ctNodes, PHYSICAL_QUEUES); // start the operating system
					//(pointer to task table,array of task's #define,)
   }
	for(j=0;j<100;j++)
    {
		prtInfo = (MULTISTART_TABLE*)uTaskerSchedule();	//schedule uTasker for initialisation
#ifdef ENABLE_WATCHDOG
		WDTHandleType = WDT_MAIN_LOOP;
		WDTFeed();		//Clear watchdog timer
#endif
	}
#endif
#endif	
	for(j=0;j<2;j++)
   		DoorConditionControl(j,DR_NORMAL,5,5);
//	#ifdef SUPPORT_NSERIES2
//		ValidateInEmpCount();
//	#endif
#ifdef SUPPORT_7SEG_DISPLAY               //A00014
	if(Doorinfo.EnDisEmpInDispCount & 0x01)
		SendINOUTCountToDisplay(InEmpCount,EMP_DISPLAY_PORT);
#endif
    AccessType_Timer = 0x00;
    #ifdef ENABLE_SLAVE_SUPPORT
	InitliaseSlaveFlags();//this fun. must once called before while loop.ARMD0341
	#endif//#ifdef ENABLE_SLAVE_SUPPORT	ARMD0334
    memset((BYTE *)SBuffer, PAGE_SIZE, 0);
	DspRdrNo = 0;//default reader number
	StoreCardInTrDBFull(0,1,EVENT_SYSTEM_RESET,0,0);	   //ARMD0265   
	ScrollImageTime = 0;
	
	MaxValues(); 	// to get max no of Template support 	

#ifdef TEST_HW
	TestTFT();
#endif	
	if(	F_Password == PASS_ADMIN_LOGIN )
	{
		DisplayStatusIcon(STATUS_LOCKED,1);
	}
	else
	{
		DisplayStatusIcon(STATUS_LOCKED,0);
	}

#ifdef TEST_HW
	Test_TouchTFT();
	Test_LEDBAR();	
	Test_GPRS();
#endif	
	DispWall_IdealTime = 0;
	SysInfo.ThemeSelectNo = 1;   // temparary commented 
	F_ImageUploadInProcess = 0;
	WeigandOutLEdStatus = 0;	// Indicates LED RED
	DoorOpen_Wigand = 0;
///////////// end of test code here

	while (1) /////////////////////////////////////////////////////////////////////////////////////////////// repeat forever
	{
		EnableDisplay();//this is called here to remove any error like some function has disable display and returned without enabling it.
		
	//==================================================
	// Following code added to take care of issue of UDP send.. 
	//so it send two dummy heartbeat at start to take care of same
	if(MyUDP_Socket!=0)
	{
		if(sendudp<=3)
		{
			sendudp++;
			SendUDPHeartBeat();
		}
	}
	//==================================================
#ifndef ENABLE_ETHERNET_OLD 
	{
// 		static int icount=0;
// 		SendDecimalIntToPC(icount++) ;
// 		if(icount == 835)
// 		{
// 			icount = icount;
// 		}
#ifdef ETHERNET_ENABLE		
	prtInfo = (MULTISTART_TABLE*)uTaskerSchedule();  // schedule uTasker
#endif		
//		TransmitStrToPC("E\\n");
	}
#endif
#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_MAIN_LOOP;
	WDTFeed();		//Clear watchdog timer
#endif
	priority++;

#ifdef WEIGAND_OUT_READER
	if(SysInfo.ContInOut == 5)
	{		// If 2nd controller DOTL time is greater than ourNG as a Reader then Problem of GUI will come to take care  check WeigandOutLEdStatus Status
		if(CHK_WIGAND_IN_GRANT_OVER())	//NGD00077
		{
			WeigandOutLEdStatus = 0;	// Indicates LED RED  						
		}	
		if(CHK_WIGAND_IN_GRANT())
		{			
			if(WeigandOutLEdStatus == 0)				
				if(DRStruct[0].DRStatus == DR_NORMAL)
				{
					DoorOpen_Wigand  = 1; 
					WeigandOutLEdStatus = 1;	//  	Indicates LED green
					HandleDisplayErrorMessages(EVENT_VALID_CARD);
					//DoorConditionControl(0,DR_ACCESS_OPEN,ReaderInfo[0].DOpTime,ReaderInfo[0].DOTLTime);
					DoorConditionControl(ReaderNo-1,DR_ACCESS_OPEN,ReaderInfo[ReaderNo-1].DOpTime,ReaderInfo[ReaderNo-1].DOTLTime);	//ARMD0375
				}
		}
		else if((DRStruct[0].DRStatus != DR_NORMAL) && ( DoorOpen_Wigand  == 1)) //NGD00161
		{
			DoorOpen_Wigand  = 0;
			//DoorConditionControl(0,DR_NORMAL,ReaderInfo[0].DOpTime,ReaderInfo[0].DOTLTime);
			DoorConditionControl(ReaderNo-1,DR_NORMAL,ReaderInfo[ReaderNo-1].DOpTime,ReaderInfo[ReaderNo-1].DOTLTime);	//ARMD0375
		}
	}
#endif
    if((priority%8)==0)	   // Good Buzzer sound
	for(i=0;i<SysInfo.ControllerMode;i++)
	{
  		HandelDoorControlInputs(i);
//		WeigandBuzControl(i);
	}

/*#ifndef BIO_METRIC
	if((priority % 8) == 0)
  		if(F_PollSent == CLR)
			PollNextReader();
	if(F_PollSent == SET)
  	{
		ManagePollResponse();
	}
//Need to be used when we hve to send command to reader even in poll mode 
	else
	{	
		SendFromSendQueue();
		if((F_RdrOtherSendCommand == SET) && (INTRUSION_STATUS == CLR))
		{
			F_RdrOtherSendCommand = CLR;
			CheckFreeTimeZone(CWeekDay);
		}
	}
#else  */
	if((F_RdrOtherSendCommand == SET) && (INTRUSION_STATUS == CLR))		  //ARMD0137
	{
		F_RdrOtherSendCommand = CLR;
		CheckFreeTimeZone(CWeekDay);
	}
//#endif
if(F_ImageUploadInProcess == 0)
if(F_FirmwareUpgrade == 0x00)
#ifdef BIO_METRIC
	if(DisplayMode != MODE_BIOMETRIC_DOWNLOAD )
#endif												 
	{
//		if(F_KeyPressed == SET)
		//if((priority % 6) == 0)
		
//---------  For touch keypad check 		
//		if(F_SCAN_KEY)
		{
		    F_SCAN_KEY=0;
			F_KeyPressed = CLR;
			HandleKeyBoard();
			//sense touch screen and check if key is pressed.
#ifdef	SUPPORT_TOUCH_KEY
			if(F_GenerateBackKey)
			{
				F_GenerateBackKey=CLR;
				GenerateBackKey();
			}
			if(ScreenFormatData.CurrentFormat != FORMAT_WELCOME_SCREEN )
				HandleTouchScreenKey();  //if key is pressed put key in buffer
#endif
		}
		if(CHECK_KEY_IN_BUFFER())
		{
			temp = ReadKeyFromBuffer();
			DispWall_IdealTime = 0;
#ifdef INSERT_SDCARD					
			if(ScreenFormatData.F_Scrollimage == 1 )
			{
					ScreenFormatData.F_Scrollimage = 0;  // dissable scroll menu 
					ScreenFormatData.F_ImageNo = 1;   // select current walpaper -> later modify from variable stored in flash ie controlled by a protocol
					//ScreenFormatData.CurrentFormat = FORMAT_BOOT_SCREEN ;// To show time and date imidiately on TFT 
					DisplayFormat(FORMAT_WELCOME_SCREEN);
//					SDDisplayBackGround(0,0,320,190,ScreenFormatData.F_ImageNo) ;  // display set wallpaper 
			}
#endif			
			HandleKeyEvent(temp);
			//NewHandleKeyEvent(temp);
//			L_DisplayChar1(14,temp);	
			MsgPrint(MSG_WARNING,temp,"Key Press");		
		}
	}
	if(F_OneSec)
	{
		if(F_OneMinute)
		{
			F_OneMinute=CLR;
#ifdef PROCESS_HEARTBEAT
			if(Doorinfo.UDPHeartBeat!=0)
			{
				UDPHeartBeatCount++;
				if(Doorinfo.UDPHeartBeat <= UDPHeartBeatCount)
				{
					// We have to send heartbeat to UDP Server PC.
					UDPHeartBeatCount=0;
					SendUDPHeartBeat();					
				}
			}
#endif
		}
//		MakeSoundForTimeMainLoop();		
#ifdef INSERT_SDCARD		
	#ifndef SENDING_IMAGE_DATA
// 		if(ScreenFormatData.F_Scrollimage == 1)
// 		{
// 			if(ScrollImageTime > 5)
// 			{
// 				ScrollImageTime = 0;
// 				ScrollBmpImage(0);     
// 			}
// 		}
// 		else if(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN)
// 		{
// 			if(DispWall_IdealTime >= SysInfo.DispIdealTime)
// 			{
// 				ScrollImageTime = 0;				
// 				ScrollBmpImage(FUNCTION_KEY);	
// 			}
// 		}
	#endif
#endif
		if( (SysInfo.SelAccessType == 0x01) && (AccessType != 0) ) //ARMD0316 
		{
			AccessType_Timer++;
			if(AccessType_Timer == 20)
			{
				AccessType_Timer = 0x00;
				AccessType = 0x00;
			}
		}
//#ifdef ENABLE_SERVER_AUTH
		ServCheckMainLoop();  //ARMF2004
//#endif
    TimeBasedActions();  //ARMF0252 // This should be checked on sec and now always
#ifdef	ENABLE_EMAIL_SEND
		EmailOneSecLoop();
#endif
#ifdef ENABLE_PIN_PROX
		PinProxOneSecTimer();
		CheckPinProxTimeout();
#endif
        DualUserMainLoopManager();

//		SpecialCardLEDBlinkMainLoop();

		DMZMainLoopManager();
#ifdef SUPPORT_NSERIES2
#ifdef BIO_METRIC
//=================DUA Timer==============================  
			if((Doorinfo.DuelUserAuth == 1) && (F_DuelUserAuth == SET))
			{
				DuelUserCounter++;
				if(DuelUserCounter >= TIMEOUT_DUAL_FINGER)
		         {
		            F_DuelUserAuth = CLR;
		            DuelUserCounter = 0;
		         }
			}
//=========================================================
#endif

#ifdef MODE_ANY_DUAL_MODE_FINGER
	if((DuelUserCounter == TIMEOUT_DUAL_FINGER-1) &&(Doorinfo.DuelUserAuth == 1) && (F_DuelUserAuth == SET))
    {
		L_DisplayROMStr("2ndFingerTimeOut ",16,ROW_USER_FUNCTION);
        F_KeyIdleTime = CLR;
        IdleKeyCounter = MAX_KEY_IDLE_TIME - 5;
		MakeSound(SOUND_USER_ERROR);
    }
#endif
#endif
		F_OneSec = CLR;
//#ifdef ENABLE_ETHERNET_OLD 
//      	IncSocketTimeOut();	  				//ARMF0240	//ARMD0452
//#endif
		F_RdrOtherSendCommand = SET;
//		current_time = RTCGetTime(); 
		Datetime = RTCGetTime();
#ifndef SENDING_IMAGE_DATA
		DisplayDateTime(); //commented to input bmp file wia serial
		//Displaystatus(); //show top and critical status here
#endif

		if(ModelSerDispCount <= 6)
		{
			F_TempCounterStart = SET; 	// NGD00028 // NGD00013	// Status Bar MSG not comming properly
			if(Temp_Time_Counter > 2)
			{
				F_TempCounterStart = SET;
				Temp_Time_Counter = 0;
				ModelSerDispCount ++;
				DisplayModelInfo(ModelSerDispCount);
			}
		}
		else
		{
			HandleDisplayTimeOuts();
		}

#ifdef ENABLE_LCD_BACKLITE
//		MsgPrint(MSG_ERROR,BacklitOnTime,"BKLIT On Time");			   //Defect X0048
//		MsgPrint(MSG_ERROR,Doorinfo.MaxBacklitOnTime,"BKLIT Max Time");
		if(Doorinfo.MaxBacklitOnTime >= 2)
		{
			if(BacklitOnTime >= (Doorinfo.MaxBacklitOnTime))						//Defect X0048         AutoOFF feature
			{
				MsgPrint(MSG_ERROR,BacklitOnTime,"OFF BKLIT");
				OFF_LCD_BACKLIGHT();
			}
		}
#endif

#ifdef ENABLE_TCP_PUSH
		if(StateUTasker == STATE_UTASKER_ACTIVE)
		{
		//	MsgPrint(MSG_DISP_ALWAYS,1,"ManagePushLogic");
			if(SysInfo.PushEnable)
			{       
				ManagePushLogic();
			}
		}
#endif
#ifdef SUPPORT_NSERIES2  // need changes in User Interface 
		if(Doorinfo.EnDisEmpInDispCount != 0)
		{
			if(EmpMinCount >= MAX_MINUTES_TOSAVE_EMPINCOUNT)
			{
				EmpMinCount = 0;
				SaveInEmpCount();
			}
			if(InEmpDispCount >= MAX_SECS_TOSHOW_EMPINCOUNT)				 //ARMD0505
			{
				InEmpDispCount = 0;
				sprintf((char*)DisplayTempBuffer,"INCnt:%05d/%05d",InEmpCount,Doorinfo.OccupancyCount);
				DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);
//				L_DisplayROMStr("INCnt:     /     ",16,ROW_USER_ENTRY);
//				L_DisplayDecimal4Integer((WORD)InEmpCount,7,ROW_USER_ENTRY);
//				L_DisplayDecimal4Integer((WORD)Doorinfo.OccupancyCount,12,ROW_USER_ENTRY);
			}
		}
#endif	
		if(F_authScreenTimerEnable && F_authScreenTimer==0)
		{
			F_authScreenTimerEnable = 0;
			DisplayFormat(FORMAT_WELCOME_SCREEN);			
 			ScreenFormatData.CurrentFormat = FORMAT_WELCOME_SCREEN;
// 			if(SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE)
// 			{
// 				DisplayMode = USER_IDENTIFY_MODE;
// 				UserBioMode = BIO_GET_USER_ID_BY_SCAN;
// 			}
		}
	}//if(F_OneSec)

//	LCDDisplayTimeData(current_time,2,CWeekDay);
#ifdef BIO_METRIC
  if(F_ImageUploadInProcess == 0)	
  {
	if(F_BIO_COMM)
	{
		if(FingerWaitTimeOut >= 400)
		{
			FingerWaitTimeOut = 0;
			BioCmdStatus = STATUS_BIO_COMM_TIME_OUT;
			HandleBioUserEvents();
			DISABLE_BIO_COMM();
			DisplayMode = MODE_WAIT_FOR_CARD;
		}
	}
	if(F_SerialCommandBio)
	{  
		F_SerialCommandBio = CLR;
		ProcessBioSerialResponse();
		PortObj[SER_BIO_PORT].RxPtr = 0;
		HandleBioUserEvents();
	}
	#ifdef ENABLE_POLL_BIO
		if(F_FirmwareUpgrade == 0x00)
			if(((USER_IDENTIFY_MODE == DisplayMode) || (MODE_WAIT_FOR_CARD == DisplayMode)) && (SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) && 
				(ScreenFormatData.CurrentFormat == FORMAT_WELCOME_SCREEN))
			{
				if(F_Poll_Bio_Sensor == SET)
				{
					F_Poll_Bio_Sensor = CLR;
					ReaderNo = 1;
					ENABLE_BIO_COMM();
					MsgPrint(MSG_WARNING,0,"PollIdentifyFinger=");
					PollBioSensorTimeOut = 0;
					F_FingerUnderPoll = SET;
					IdentifyFinger();
					FingerWaitTimeOut = 0;
					UserBioMode = BIO_GET_USER_ID_BY_SCAN;
					DisplayMode = USER_IDENTIFY_MODE;
				}
			}
	#endif
//	#ifdef BIOLITE_HARDWARE	// commented for NG hardware for finger sense mode 
			else if((MODE_WAIT_FOR_CARD == DisplayMode) && (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
			{
				if((F_FingerSense == SET) && (F_Poll_Bio_Sensor == SET))
				{
				#ifdef ENABLE_LCD_BACKLITE
					BacklitOnTime = 0;	   
					ON_LCD_BACKLIGHT();
				#endif//#ifdef ENABLE_LCD_BACKLITE
					F_Poll_Bio_Sensor = CLR;
					F_FingerSense = CLR;
					ReaderNo = 1; 
					BioReaderNo = 1;
					ENABLE_BIO_COMM();
					MsgPrint(MSG_WARNING,ReaderNo,"PollIdentifyFinger Reader=");
					PollBioSensorTimeOut = 0;
					F_FingerUnderPoll = SET;
					IdentifyFinger();
					FingerWaitTimeOut = 0;
					UserBioMode = BIO_GET_USER_ID_BY_SCAN;
					DisplayMode = USER_IDENTIFY_MODE;
				}
				}
			}		
//	#endif//#ifdef BIOLITE_HARDWARE	
#endif//#ifdef BIO_METRIC

	if(F_SerialCommandProxy == 1)
	{
 	 	//UARTSend( 0, (BYTE *)SBuffer, ToReceiveCount);
		if(F_EthernetReceived == SET)
		{
			HandleSerialCmd(SER_TCPIP_PORT);
			F_EthernetReceived = CLR;
		}
		else
		{
			HandleSerialCmd(PC_PORT);
		}
	  	F_SerialCommandProxy = CLR;
	}
	else if (F_SerialCommandProxy == 3)
	{
		HandleSerialCmd(MODEM_PORT);	
		F_SerialCommandProxy = CLR;
	}
	else
	{}
     
#ifdef SMART_CARD
	#ifdef SUPPORT_ICLASS_RDR
		MainLoopPollForIClassRDR();	
		temp1 = MainLoopIClassRDR();
		if(temp1 != 0)
		{
			if(MODE_WAIT_FOR_CARD == DisplayMode)
			{
					if((ERR_SC_LAYOUT_ERROR == temp1) || (ICR_CARDNO_ERROR_CODE == temp1))
							L_DisplayROMStr("ERR:InvalidCard.",16,ROW_USER_ENTRY);
					else if(temp1 == ICR_ERROR_CARDINFO_BL)
							L_DisplayROMStr("ERR:CardInfo BL",16,ROW_USER_ENTRY);
					ICRERRORCode = 0;
					MakeSound(SOUND_USER_ERROR);
					IdleKeyCounter = MAX_KEY_IDLE_TIME - 3;
					F_KeyIdleTime = CLR;
			}
		}
	#else
	MainLoopPollForSCardRDR();
	SmartCardSerialMainLoop();
	#endif
#endif

// 	Chk_Egress();
//	if(F_ChangeInInput)
//	{  
//		F_ChangeInInput = 0;
//		HandleDoorInput();
//	}

#ifdef ENABLE_SLAVE_SUPPORT
         ProcessSlaveSupport();
#endif
if(F_FirmwareUpgrade == 0x00)
#ifdef BIO_METRIC
		if(!((DisplayMode == MODE_BIOMETRIC_DOWNLOAD) || /*(DisplayMode == MODE_MEMORY_FULL) ||*/ ((F_TrnxMemFull == SET) && (DisplayMode != MODE_ADMIN_PASSWORD)) /*|| (INTRUSION_STATUS == SET)*/))         //F0011 Checking of Intrusion Alarm
#else
		if(!(/*(DisplayMode == MODE_MEMORY_FULL) ||*/ ((F_TrnxMemFull == SET) && (DisplayMode != MODE_ADMIN_PASSWORD)) /*|| (INTRUSION_STATUS == SET)*/))         //F0011 Checking of Intrusion Alarm
#endif
		{
//#ifdef ENABLE_PIN_PROX
//			CheckPinProxTimeout();
//#endif
		if(F_ImageUploadInProcess == 0)
		{
			if(ReaderData[0].F_WeigandInterrupt)
			{
				if(CheckServerQueueFree(0)==0)		//ARMF2004				
				{
					ReaderData[0].F_WeigandInterrupt = CLR;
					DspRdrNo = 0;	 						//ReaderNo
					tempcard = HandleWeigandRawCard(0);
					CurrentUser.InputType = INPUT_USER_FROM_WEIGAND;
					if(MODE_WEI_CARD_DISPLAY==DisplayMode)
					{	
						ReceivedCardNo=tempcard; 
						HandleWeigandEvent();
					}				
					else
						ProcessRecCarddata(DspRdrNo,tempcard);
				}
			}

			if(ReaderData[1].F_WeigandInterrupt)
			{
				if(CheckServerQueueFree(1)==0)		//ARMF2004				
				{
					ReaderData[1].F_WeigandInterrupt = CLR;
					DspRdrNo = 1;	 						//ReaderNo
					tempcard = HandleWeigandRawCard(1);
					CurrentUser.InputType = INPUT_USER_FROM_WEIGAND;
					if(MODE_WEI_CARD_DISPLAY==DisplayMode)
					{	
						ReceivedCardNo=tempcard; 
						HandleWeigandEvent();
					}
					else
						ProcessRecCarddata(DspRdrNo,tempcard);
				}
			}
			if(ReaderData[0].F_CardFound == SET)
			{
				if(CheckServerQueueFree(0)==0)		//ARMF2004				
			    {
					ProcessRecCarddata(0,ReceivedCardNo);
					ReaderData[0].F_CardFound = CLR;
				}
	        }
	        if(ReaderData[1].F_CardFound == SET)
	        {
				if(CheckServerQueueFree(0)==0)		//ARMF2004				
	            {
					ProcessRecCarddata(1,ReceivedCardNo);
					ReaderData[1].F_CardFound = CLR;
				}
	        }
		}
		}
//		else
//		{
//			ReaderData[0].F_Weigand3Interrupt = ReaderData[1].F_WeigandInterrupt = CLR;
//			ReaderData[0].F_CardFound = ReaderData[1].F_CardFound = CLR;
//		}

#ifdef BIO_METRIC
		if(F_UserTimeOut == SET)
		{
			if(UserTimeOut == 0)
			{
				F_UserTimeOut = CLR;
				HandleUserTimeOutEvents();
			}
		}
#endif
		if(F_OneHour == SET)
		{
			F_OneHour = CLR;
			Datetime = RTCGetTime();	
			weekday = GetWeekDay(CurrentTimeInt);//ARMD0214
			if(weekday != CWeekDay)		    
			{
				CWeekDay=weekday;
				RTC_DOW=CWeekDay;
			}		
		}
//#ifdef ENABLE_GSM_GPRS
//		AutoConnectGPRS();
//#endif
#ifdef ENABLE_GSM_GPRS
	    SendWithoutDelay = 1;
		AutoConnectGPRS();
		if(Doorinfo.GPRSEnable == 1)
		{
		
               MainLoopGPRSHandle();
		}
	    SendWithoutDelay = 0;
#endif
	}
}


void ProcessSlaveSupport(void)
{
char n ;
		 if(F_SerialPollSlaveProxy)
         {
         	F_SerialPollSlaveProxy = CLR;
				if(F_EthernetReceived == SET)
            {
            	if(Doorinfo.SlaveRespMode == 1)
	             //  WaitDataSocketNo = DataSocketNo;
				       WaitDataSocketNo = 1;
	             HandleSerialSlaveCmd(SBuffer,SER_TCPIP_PORT);
            }
            else
	            HandleSerialSlaveCmd(SBuffer,PC_PORT);
         }

		if(Doorinfo.SlaveRespMode == 1)
        {
			if(F_WaitForSlaveResponse)
				WaitForMainloopSlaveResponse();
	         if(F_SerialSlaveDataProxy == SET)
	         {
	            L_DisplayCharAt1(14,'<');
	            L_DisplayCharAt1(15,'<');
	            F_SerialSlaveDataProxy = CLR;
				//for(n=0;n<=SlaveSerPtr;n++)//ARMD0322
			//	TransmitCharToX(SlaveSerBuffer[n],GLOBAL_PORT);
				n=strlen((char*)SlaveSerBuffer);
			   	while(n>0) 
				{
	            	TransmitCharToX(SlaveSerBuffer[n],GLOBAL_PORT);//ARMD0322
			   		n--;
				}
				TransmitCharToX(SlaveSerBuffer[n],GLOBAL_PORT);
			   	n=0;
#ifdef ETHERNET
				SendSerialDataToEthernetPort(1);		//PANKAJXX DataSocketNo
#else
#ifndef TELNET_TEST
				F_CheckSum = CLR;
				PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
				fnPrint((BYTE *)SlaveSerBuffer,NETWORK_HANDLE,strlen((const char *)SlaveSerBuffer));
		//		fnPrint((BYTE *)SlaveSerBuffer,NETWORK_HANDLE,SlaveSerPtr);
#endif
#endif
				F_EthernetReceived = CLR;
	        }
		}
}

void InitNetworkParameter(void)
{
#undef extern
extern const NETWORK_PARAMETERS network_default;
//	BYTE arrip[4];
	int i;
	network.usNetworkOptions = network_default.usNetworkOptions;//taken from "network_default" variable
	
	for(i=0;i<6;i++) //till mac length
	{
		network.ucOurMAC[i] = ModelInfo.MACAddress[i];
	}
	StrToArr((char*)&(SysInfo.LOCAL_IP[0]),network.ucOurIP);  //parameter no. 1
	StrToArr((char*)&(SysInfo.LOCAL_NETMASK[0]),network.ucNetMask);//2
	StrToArr((char*)&(SysInfo.LOCAL_GATEWAY[0]),network.ucDefGW);//3
	StrToArr((char*)&(SysInfo.LOCAL_DOMAINNAME[0]),network.ucDNS_server);//28
//	StrToArr((char*)&(SysInfo.SERVER_IP_ADD[0]),arrip);//4
//	StrToArr((char*)&(SysInfo.LOCAL_DOMAINNAME[0]),arrip);//28
//	StrToArr((char*)&(SysInfo.UDP_IPAdd[0]),arrip);//40
//	StrToArr((char*)&(SysInfo.PUSH_TCP_ServAdd1[0]),arrip);//42
//	StrToArr((char*)&(SysInfo.PUSH_TCP_ServAdd2[0]),arrip);//43
}
void InitParameters(void)
{
#ifdef extern
	#undef extern
#endif
extern PARS *parameters;//initialised in fnApplication()
extern const PARS cParameters;//default values for parameter setting
	uMemcpy(parameters, (unsigned char *)&cParameters, sizeof(PARS));
//	parameters->usTelnetPort = cParameters.usTelnetPort ;
	parameters->usTelnetPort = SysInfo.ETH_Port ;
//	SysInfo.ETH_Port;
}
/*----------------------------------------------------------------------------------
InitialiseSystem :
Initialise all system parameters
----------------------------------------------------------------------------------*/
void InitialiseSystem(void)
{
unsigned long ip;
#ifdef INSERT_SDCARD	  // SD CARD
	unsigned char error1;
#endif
	F_GenerateBackKey = CLR;
	TargetResetInit();	  // Initialise all basic controller this is like a start-up
	ResetVariable();	  
	InitialiseIO();
   	SysInfo.MySlaveNo = 1;
#ifdef ENABLE_ETHERNET_OLD 
	TCPLowLevelInit();
#endif
	InitialiseFlags = 0;//ARMF0377
/************************UART Ineatilise *******************************/	
//testing 	uart not working for bio sensor 
// 	FIO0DIR = 0x00000C00;
// 	FIO0SET = 0x00000C00;
// 	FIO0CLR = 0x00000C00;
// 	FIO0SET = 0x00000C00;
	
	InitialiseSerialObj();
#ifndef SUPPORT_ICLASS_RDR 	   //if not defined SUPPORT_ICLASS_RDR 
    UARTInit(0,9600,0);		//PC port
//	SysInfo.BaudRate[0]= 9600;
#else
  	UARTInit(0,9600,0);	//PC port
//	SysInfo.BaudRate[0]= 9600;
#endif
	UARTInit(1,9600,0);	  	//serial Reader port
//	SysInfo.BaudRate[1]= 9600;
//	SER_SMARD1_BAUDRATE();
#ifdef BIO_METRIC    // Not required as we also do serial initialise for ports but better to set some default valus at start
//    UARTInit(2,57600,0);		//Sensor port
//	SysInfo.BaudRate[2]= 57600;
#else
    UARTInit(2,9600,0);		
//	SysInfo.BaudRate[2]= 9600;
#endif	
	UARTInit(3,9600,0);	
	SysInfo.BaudRate[3]= 9600;	
#ifdef 	SMART_CARD
    UARTInit(SER_SMART_RD1_PORT,38400,0);	  //this might be PC port
	SysInfo.BaudRate[SER_SMART_RD1_PORT]= 9600;
#endif
#ifdef	ENABLE_GSM_GPRS
    UARTInit(MODEM_PORT,9600,0);	  //this might be PC port
	SysInfo.BaudRate[MODEM_PORT]= 9600;
#endif

/************************ Display all internal parameters using deabug*******************************/
	PrintAccessMemMap();
/************************Timer Ineatilise *******************************/	
	Temp10mSecCounter = Temp100mSecCounter = 0;
	init_timer(1,TIME_INTERVAL);
	enable_timer(1);
/************************RTC Ineatilise *******************************/	 
 	RTCInit();
	RTCStart();
	Datetime = RTCGetTime();
/*#ifndef BIO_METRIC
	SlaveNoResponseCounter = BadDataCounter = 0;
	BadDataDayCounter = NoRespDayCounter = 0;
	F_OneDay = F_OneHour = F_OneMinute = CLR;	// This is required as after startup as cTime old value isjunk so do it will gegerate F_OneMinute Flag
#endif*/

/************************GPIO Ineatilise *******************************/	
/* Initialize port in Normal/Fast Mode */
	GPIOInit(2,FAST_PORT,DIR_OUT);
/* LCD Module.2x16 init */
/************************Interrupt Ineatilise *******************************/	   
  	EINTInit();  	// Initialise here beacouse In Smart SIngle same FW not working 

	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
	while(Temp_Time_Counter < 2);
			F_TempCounterStart = CLR;
			
#ifdef WEIGAND_OUT_READER
		WEIGAND_0_HIGH();
		WEIGAND_1_HIGH();
#endif			
//==========================================================================
/************************LCD or TFT Ineatilise *******************************/	
#ifdef	GLCD_SUPPPORT
	lcdInit();	
#else
	InitialiseDisplay();
#endif

/************************SPI Ineatilise *******************************/
	F_FlashSelect = 0;	
// Following will initialise Flash 1, Flash 2 and SD Card SPI ports
	SPIInit();	//Initialise SPI port as fast port for commnication before SPI initialisation
//F_FlashSelect = 0;
//	SPIInit();	//Initialise SPI port as fast port for commnication before SPI initialisation		
		
#ifdef ENABLE_WATCHDOG
	WDTInit(10);		//ARMD0161		//watchdog initialization for secs
#endif

	SPI_DeviceID((BYTE* )SBuffer);  
	for(i=0;i<5;i++)
	 	MsgPrint(MSG_MEM,SBuffer[i],"Flash Data ");
	if(SBuffer[1]==0x27)
	 	MsgPrint(MSG_MEM,SBuffer[1],"FLASH SIZE is 32Mbit");
	else
		MsgPrint(MSG_MEM,SBuffer[1],"******ERROR CHECK FLASH MEMORY SIZE ****");		
///////////////////  check for flash memory structure	//////////////////ARMD0398 
#ifdef FL_CARD_NAME_PAGE_NO	
// 	if( (MAX_PAGES_REQUIRED_FOR_CARDS+FL_CARDDATA_PAGE_NO) >= FL_CARD_NAME_PAGE_NO )
// 	{//name page and card data page are overlapped
// 		MakeSound(SOUND_SYS_ERROR);
// 		MsgPrint(MSG_MEM,1,"NamePageError");	
//     	L_DisplayMessage("NamePageError   ",16,1);

// 		F_TempCounterStart = SET;
// 		Temp_Time_Counter = 0;
// 		while(Temp_Time_Counter < 3);
// 			F_TempCounterStart = CLR;
// 	}
#endif

///////////////////  End of check for flash memory structure	//////////
////////////////////////////////////////////// start of SD card init ///////////////////////////////
#ifdef INSERT_SDCARD	  // SD CARD
	guintBlockNum = 0;
	gusDataSize = 0;
	SDcardType = 0;
	for (i=0; i<10; i++)
	{
	  error1 = SD_init();	// Will return 0 if Initialized 
	  if(!error1) break;
	}
		F_SDCardStatus = 0;
		F_FAT_MemStatus = 0;
//		TX_NEWLINE;
		if(error1 == 1) 
		{
				L_DisplayROMStr("SD card not detected",0,BOOT_MSG1);
				F_SDCardStatus = 1;
//				TransmitStrToPC("SD card not detected..");
		}
		if(error1 == 2) 
		{
//				TransmitStrToPC("Card Initialization failed..");
				F_SDCardStatus = 2;
				L_DisplayROMStr("Card Initialization failed",0,BOOT_MSG1);
		}
		F_TempCounterStart = SET;
		Temp_Time_Counter = 0;
		while(Temp_Time_Counter < 1);
			F_TempCounterStart = CLR;
		
//	TX_NEWLINE;
		switch (SDcardType)
		{
			case 1:
//				TransmitStrToPC(("Standard Capacity Card (Ver 1.x) Detected!"));
			break;
	  	
			case 2:
//				TransmitStrToPC(("High Capacity Card Detected!")); //4Gb Fat32
	  	break;
	  	
			case 3:
//				TransmitStrToPC(("Std Cap Card (Ver 2.x) Det'd!")); // 2GB Fat32
			break;
	  	
		default:
//			TransmitStrToPC(("Unknown SD Card Detected!"));
	    break; 
	}

		SET_SPI_SD_INTERFACE_FULL_SPEED();	// NGD00080
	
		error1 = getBootSectorData(); //read boot sector and keep necessary data in global variables
//#ifdef DEBUG_EN	
	if(error1) 	// Error
	{
//		TransmitStrToPC (("FAT32 Not found!"));	
			L_DisplayROMStr("FAT32 not found!",0,BOOT_MSG2);
	}
	else
	{
//		TX_NEWLINE;
//	  TransmitStrToPC (("FAT32 found!"));	
			L_DisplayROMStr("FAT32 found!",0,BOOT_MSG2);
	} 
//#endif
	memoryStatistics(); ////NGD00026
		F_TempCounterStart = SET;
		Temp_Time_Counter = 0;
		while(Temp_Time_Counter < 1);
			F_TempCounterStart = CLR;

#endif	 // end INSERT_SDCARD
////////////////////////////////////////////// end of SD card init ///////////////////////////////
#ifdef	GLCD_SUPPPORT
	//DisplayBootScreen();
	DisplayFormat(FORMAT_BOOT_SCREEN);
#endif
	ReadSysInfoFromFlash();
	ReadModelInfoFromFlash();
	ReadDoorInfoFromFlash();
	ReadIOEventInfoFromFlash();
	ReadReaderInfoFromFlash();
	ReadSplCardFlagInfoFromFlash();
	InitNetworkParameter();
	Doorinfo.TScalibrated = 1;	// to disable touch screen on sud HW
#ifdef SUPPORT_TOUCH_KEY    //init after door info is read.
  // Initialise the touch screen (and calibrate if necessary)
	tsInit();
#endif


//	InitParameters();
	SerialInt();		  //serial port initialisation after reading from memory
#ifdef ENABLE_LCD_BACKLITE
	ON_LCD_BACKLIGHT();
#endif
	SysInfo.ThemeSelectNo = 1;   // temparary commented 

  IniTransaction();
	MsgPrint(MSG_MEM,TransReadPtr,"TransReadPtr ");	
	MsgPrint(MSG_MEM,TransWritePtr,"TransWritePtr");
//	IniTemplates();
// For this hardware we have just two reader and one door
	if(SysInfo.ControllerMode != 2)		  //ARMD0314
		SysInfo.ControllerMode = 2;		// To avoid bug if some one set ControllerMode greater then 8
	InitialiseDrData();
	ip = aton((char *)&SysInfo.LOCAL_IP[0]);
	MsgPrint(MSG_MEM,ip,"IP Address ");		
#ifdef	GLCD_SUPPPORT
//	L_DisplayROMStr("0123456789012345678901234567890123456789012345678901234567890123456789",16,BOOT_MSG1);
	L_DisplayROMStr("Sys:Initialise  ",16,BOOT_MSG1);
#else
	L_DisplayROMStr("Sys:Initialise  ",16,ROW_USER_FUNCTION);
	L_DisplayROMStr("Please  Wait    ",16,ROW_USER_ENTRY);
#endif
	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
#ifdef ENABLE_GSM_GPRS	
	GSMPOWER_CONTROL_LOW();
#endif	
	while(Temp_Time_Counter < 1);
		F_TempCounterStart = CLR;
	
//	for(ip=0;ip<2;ip++)
//   		DoorConditionControl(ip,DR_NORMAL,5,5);   //removed because of TCP hang
	DoorClose(0);   //door initialisation condition
	DoorClose(1);
	WeigandLedOff(0);
	WeigandLedOff(1);
	
	CheckForFirmwareUpgrade();//ARMD0447

#ifdef ENABLE_ETHERNET_OLD 
	CheckValidIPAddress();
#endif
#ifndef	GLCD_SUPPPORT
	L_DisplayMessage("                ",16,ROW_USER_FUNCTION);
	L_DisplayROMStr(SysInfo.LOCAL_IP,16,ROW_USER_FUNCTION);
	L_DisplayROMStr("Eth.Port        ",16,ROW_USER_ENTRY);
	L_DisplayDecimalInteger(SysInfo.ETH_Port,10,ROW_USER_ENTRY);
	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
	while(Temp_Time_Counter < 2);
		F_TempCounterStart = CLR;
#else
    memset((char*)DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));

	sprintf((char*)DisplayTempBuffer,"IP = %s Port = %d",(char *)SysInfo.LOCAL_IP,(char *)SysInfo.ETH_Port);
//	L_DisplayROMStr(SysInfo.LOCAL_IP,16,BOOT_MSG2);
//	sprintf(TempString,"%s %d","Eth.Port ",SysInfo.ETH_Port);
	L_DisplayROMStr(DisplayTempBuffer,0,BOOT_MSG2);
#endif

#ifdef ENABLE_ETHERNET_OLD 
	SocketTimeOut = 0xFF;
 	TCPLowLevelInit();
#endif
	IniCardInfo();
   #ifdef SUPPORT_NSERIES2
	   SplCardInit();		//281210-2	//Init Total SPL card
	   MsgPrint(MSG_MEM,TotalSplCards,"TOTAL SPECIAL CARDS");
   #endif
	F_KeyPressed = CLR;
	F_TrnxMemFull = CLR;        		 //D0011
//  	HTTPStatus = 0;                                 // clear HTTP-server's flag register
	if(Doorinfo.CardDigit == 8)
   		Doorinfo.CardMask = 24;
   	else if(Doorinfo.CardDigit == 5)
   		Doorinfo.CardMask = 16;
   	else
   		Doorinfo.CardMask = 32;
	F_DoNotCheckAPBForCard = DoNotCheckAPBTime = 0;			//FA00130
		
// {
// 			ModelInfo.MACAddress[1] =1;
// 			ModelInfo.MACAddress[2] = 2;
// 			ModelInfo.MACAddress[3] = 5;
// 			ModelInfo.MACAddress[4] = 4;
// 			ModelInfo.MACAddress[5] = 9;
// 			WriteModelInfoToFlash();
// 			DelAllCards();
// 			DelAllDoorInfo();
// 			DelAllTimeZone();
// 			DelAllFacilityCode();
// 			DelAllAdminUser();
// 			DelAllHoliday();
// 			IniDefaultSysInfo();
// 			DelAllNamesFromFlash();
// //			DelAllTempletSD();
// //			DelAllCardTemplateInfoFromFlash();
// 			DelAllMessageToFlash();			//ARMD0068
// 			WriteDefaultReaderInfo();     
// #ifdef BIO_METRIC
// 			DelAllFingers();
// #endif	
// }		
#ifndef	GLCD_SUPPPORT
	L_DisplayROMStr("MAC ",16,ROW_USER_FUNCTION);
	L_DisplayHexByte(ModelInfo.MACAddress[0],4,ROW_USER_FUNCTION);
	L_DisplayHexByte(ModelInfo.MACAddress[1],6,ROW_USER_FUNCTION);
	L_DisplayHexByte(ModelInfo.MACAddress[2],8,ROW_USER_FUNCTION);
	L_DisplayHexByte(ModelInfo.MACAddress[3],10,ROW_USER_FUNCTION);
	L_DisplayHexByte(ModelInfo.MACAddress[4],12,ROW_USER_FUNCTION);
	L_DisplayHexByte(ModelInfo.MACAddress[5],14,ROW_USER_FUNCTION);
	L_DisplayROMStr("TCards:     ",16,ROW_USER_ENTRY);
#else
	sprintf((char*)DisplayTempBuffer,"MAC = %d,%d,%d,%d,%d,%d",ModelInfo.MACAddress[0],
									ModelInfo.MACAddress[1],
									ModelInfo.MACAddress[2],
									ModelInfo.MACAddress[3],
									ModelInfo.MACAddress[4],
									ModelInfo.MACAddress[5]);
	L_DisplayROMStr(DisplayTempBuffer,0,BOOT_MSG3);
#endif

	TotalCards = GetTotalNumberOfCards();

#ifdef	SUPPORT_4DR4RD 
	{
		BYTE str11[16];
		sprintf((char *)str11,"%.6lu",TotalCards);
		L_DisplayROMStrLoc((BYTE *)str11,6,ROW_USER_ENTRY,9);
	}
#else
	#ifndef	GLCD_SUPPPORT
		L_DisplayDecimalInteger(TotalCards,10,ROW_USER_ENTRY);
	#else
		memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
//		L_DisplayROMStr(TempString,0,BOOT_MSG1);  //clear line 1 //not working
		ClearBootScreen();
		sprintf((char*)DisplayTempBuffer,"Total Cards = %d",TotalCards);
		L_DisplayROMStr(DisplayTempBuffer,0,BOOT_MSG1);
	#endif
#endif	
	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
	while(Temp_Time_Counter < 1);
	{
		F_TempCounterStart = CLR;
#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
#endif
	}
#ifdef ENABLE_GSM_GPRS		
	GSMPOWER_CONTROL_HIGH(); 
#endif	
//Reset basic sys and door info parameters after power off/on 
//need to create a function and initialise all parameters if above expected max value
	for(i=0;i<MAX_LOCAL_DOORS;i++)
		if(ReaderInfo[i].CntrolrType > MAX_CONTROLLER_TYPE)
			ReaderInfo[i].CntrolrType = 0;

	if((SysInfo.MySlaveNo <= 1) || (SysInfo.MySlaveNo > MAX_SLAVE_NO))
		SysInfo.MySlaveNo = 1;

	SysInfo.ControllerType = ReaderInfo[0].CntrolrType;	   //ARMD0463
#ifdef BIO_METRIC
for(i=0;i<MAX_LOCAL_DOORS;i++)			   //ARMD0454
{									 
	if(CHECK_ATT_SC_NOCARD(i) || CHECK_ATT_NOCARD(i) || CHECK_ATT_CARD_ONLY(i) || CHECK_DENY_LIST(i))
		Doorinfo.APBEANABLE = 0;

	if(CHECK_BIO_NOCHK(i))             
		SysInfo.IdentifyMode = BIO_POLL_TYPE_NORMAL;
}
#else
for(i=0;i<MAX_LOCAL_DOORS;i++)			   //ARMD0454
{									 
	if(CHECK_ATT_NOCARD(i) || CHECK_ATT_CARD_ONLY(i) || CHECK_ATT_SC_NOCARD(i) || CHECK_DENY_LIST(i))  
	{
		ReaderInfo[i].DOTLEn_Dis = 0;
		ReaderInfo[i].APBEnDis = 0;
		Doorinfo.APBEANABLE = 0;
	}
	else
	{
		ReaderInfo[i].DOTLEn_Dis = 1;
	}
}
#endif
	if(Doorinfo.ChkHoliday > 2)
		Doorinfo.ChkHoliday = 1;
#ifdef ENABLE_WEIGAND_FUNCTIONS
	WeiProcessInit();
#endif

#ifdef ENABLE_LCD_BACKLITE
	BacklitOnTime = 0;				 					//Defect X0048     
	ON_LCD_BACKLIGHT();
#endif

#ifdef BIO_METRIC
	BioSensorFail = 0;
	SensorTemplateSize = 0;
#ifndef	GLCD_SUPPPORT
	L_DisplayROMStr("Sys:Check Sensor  ",16,ROW_USER_FUNCTION);
	L_DisplayROMStr("Please  Wait      ",16,ROW_USER_ENTRY);
#else
	memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
	L_DisplayROMStr(DisplayTempBuffer,0,BOOT_MSG1);  //clear line 1
	strncpy((char*)DisplayTempBuffer,"Sys:Check Sensor.",18);
	L_DisplayROMStr(DisplayTempBuffer,0,BOOT_MSG2);
#endif
	ENABLE_BIO_COMM();
	if(F_BIO_COMM == SET)	   //ARMD0136
   	{
		CancelBioCommand();	   //11secs
        F_BIO_COMM = CLR;
		PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 3;
   	}
#ifdef SUPPORT_SUPREMA
	if(ReadBioSystemParameter(BIO_SYS_TEMPLATE_SIZE) == 0)	   //10secs
	{
		F_KeyIdleTime = CLR;
		IdleKeyCounter = MAX_KEY_IDLE_TIME - 7;
		SensorTemplateSize = (WORD)(BioCmdSize & (unsigned long)0x0000FFFF);
#ifndef	GLCD_SUPPPORT
		L_DisplayROMStr("TemplateSz:     ",16,ROW_USER_ENTRY);
		L_DisplayDecimalInteger(SensorTemplateSize,11,ROW_USER_ENTRY);
#else
		memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
		sprintf((char*)DisplayTempBuffer,"%s%3d","TemplateSz:",SensorTemplateSize);
		L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG3);
#endif
		ValidateTemplateSize(SensorTemplateSize);
	}
	else
	{
		ENABLE_BIO_COMM();
		if(ReadBioSystemParameter(BIO_SYS_TEMPLATE_SIZE) == 0)	  //6secs
		{
			F_KeyIdleTime = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 7;
			SensorTemplateSize = (WORD)( BioCmdSize & (unsigned long)0x0000FFFF);
#ifndef	GLCD_SUPPPORT
			L_DisplayROMStr("TemplateSz:     ",16,ROW_USER_ENTRY);
			L_DisplayDecimalInteger(SensorTemplateSize,11,ROW_USER_ENTRY);
#else
			memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
			sprintf((char*)DisplayTempBuffer,"%s%3d","TemplateSz:",SensorTemplateSize);
			L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG3);
#endif
			ValidateTemplateSize(SensorTemplateSize);
		}
		else
		{
#ifndef	GLCD_SUPPPORT
			L_DisplayROMStr("Sensor Fail ....",16,ROW_HW_ERROR_DISP);
#else
			L_DisplayROMStr("Sensor Fail ....",2,BOOT_MSG3);
#endif
			MakeSound(SOUND_SYS_ERROR);
			F_KeyIdleTime = CLR;
			F_SerialCommandProxy = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
		}
	}

	if(ReadBioSystemParameter(BIO_SYS_ENROLL_TYPE) == 0)	   //10secs
	{
		F_KeyIdleTime = CLR;
		IdleKeyCounter = MAX_KEY_IDLE_TIME - 7;
		SensorBioEnrollType = (unsigned char)BioCmdSize;
//		L_DisplayROMStr("BEnrolType:     ",16,ROW_USER_ENTRY);
//		L_DisplayDecimalInteger(SensorBioEnrollType,11,ROW_USER_ENTRY);

		ClearBootScreen();		
		memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
		sprintf((char*)DisplayTempBuffer,"%s%3d","BEnrolType: ",SensorBioEnrollType);
		L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG1);

		ValidateBioEnrollType(SensorBioEnrollType);
	}
	else
	{
		ENABLE_BIO_COMM();
		ClearBootScreen();
		if(ReadBioSystemParameter(BIO_SYS_ENROLL_TYPE) == 0)	  //6secs
		{
			F_KeyIdleTime = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 7;
			SensorBioEnrollType = (unsigned char)BioCmdSize;
//			SensorTemplateSize = (WORD)( BioCmdSize & (unsigned long)0x0000FFFF);
//			L_DisplayROMStr("BEnrolType:     ",16,ROW_USER_ENTRY);
//			L_DisplayDecimalInteger(SensorBioEnrollType,11,ROW_USER_ENTRY);
			memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
			L_DisplayROMStr(DisplayTempBuffer,0,BOOT_MSG1);  //clear line 1
			memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
			sprintf((char*)DisplayTempBuffer,"%s%3d","BEnrolType: ",SensorBioEnrollType);
			L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG1);
			ValidateBioEnrollType(SensorBioEnrollType);
		}
		else
		{
//			L_DisplayROMStr("Sensor Fail ....",16,ROW_HW_ERROR_DISP);
			L_DisplayROMStr("Sensor Fail ....",2,BOOT_MSG1);
			MakeSound(SOUND_SYS_ERROR);
			F_KeyIdleTime = CLR;
			F_SerialCommandProxy = CLR;
			IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
		}
	} 		

#else
	L_DisplayROMStr("Virdi BioSensor ",16,ROW_USER_FUNCTION);
	if(ReadBioSystemVersion() == 0)
	{
		L_DisplayROMStr("Ver:  .         ",16,ROW_USER_ENTRY);
		L_DisplayChar2(4,BioCmdData);
		L_DisplayChar2(7,BioCmdSize);
	}
	else
	{
		L_DisplayROMStr("Sensor Fail ....",16,ROW_USER_ENTRY);
		MakeSound(SOUND_SYS_ERROR);
		F_KeyIdleTime = CLR;
		F_SerialCommandProxy = CLR;
		IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
	}
#endif

	F_TempCounterStart = SET;
	Temp_Time_Counter = 0;
	while(Temp_Time_Counter < 1);
		F_TempCounterStart = CLR;
	DISABLE_BIO_COMM();
	FingerRechkCount = 0;  //A00006
//	F_ChkAdminFinger = CLR;
//ARMD0313 For Biometric based panel device we have to set door in shared DOTL as we have just one door
	ReaderInfo[0].SharedDOTL = SET;
	ReaderInfo[1].SharedDOTL = SET;

	#ifdef BIOLITE_HARDWARE	 									
		#ifdef ENABLE_POLL_BIO
	PollBioSensorTimeOut = 0;
	if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
		F_Poll_Bio_Sensor = SET;
		#endif
  	F_FingerSense = CLR;
	#endif

#ifdef EXTENDED_KEYPAD
	if(Doorinfo.F2keymode > 4)
		Doorinfo.F2keymode = 0;
	if(Doorinfo.F2keymode == 3)
	   LunchODInOut = 3;
	else
	   LunchODInOut = 0;	
#endif

#ifdef ENABLE_GSM_GPRS
	InitialiseModemData();
#endif

#else
#ifdef RDPOLL_INCLUDE
	InitialiseSlaveController();
#endif //#ifdef RDPOLL_INCLUDE

#endif

#ifdef DISP_EVENT_MSGS_FROM_FLASH
	InitialiseDisplayErrorMsg();
#endif
if(Doorinfo.SocketCloseTime <= 0x0A)
Doorinfo.SocketCloseTime = 0x14;
	#ifdef SUPPORT_NSERIES2
		ValidateInEmpCount();
	#endif
//	WriteIOEventInfoToFlash();
	NextDisplayMode = 0;
	InOutReader = 1;		// in reader
	InOutReaderTime = 0;
#ifdef ENABLE_ETHERNET_OLD
	F_ReceieveAllDataPackets = CLR;
#else
	StateUTasker = STATE_INI;
#endif

	if(SysInfo.PushNoOfTrans >= MAX_TRNX_DOWNLOAD_SUPPORT)
	   	SysInfo.PushNoOfTrans = MAX_TRNX_DOWNLOAD_SUPPORT;
	
#ifdef SUPPORT_ICLASS_RDR			//FA00100
		RDRChkCount = 0;
		if(Doorinfo.IClassCardType > SUPPORT_16K_16CARD)
			Doorinfo.IClassCardType = SUPPORT_16K_2CARD;
		AllocateRequiredBlocks();       //Need to reset unit after setting required start block para 51
#endif

//SysInfo.SCReaderEnDis[0] = 0; //just to reset SC card
//SysInfo.SCReaderEnDis[1] = 0;
	WriteSysInfoToFlash();
	WriteDoorInfoToFlash();
	WriteReaderInfoToFlash();
	
#ifdef SUPPORT_NSERIES2
//	F_FirstInUser = CLR;                      //First In user flag reset       
#endif                    //First In user flag reset       
	F_FirmwareUpgrade = CLR;
	TempSecCount = EmpMinCount = DMZMinCounter = InEmpDispCount = 0;
    F_DMZBuz = F_DMZOccur = 0;
	memset(DuelUserData,0x00,sizeof(DuelUserData));
#ifdef SUPPORT_NSERIES2
	F_DeadManZone = CLR;
	F_DuelUserAuth = CLR;                     //DUA Flag reset
	DuelUserCounter = 0;                      // DUA Counter reset
	F_Spl_Crd_Dr_open = CLR;///ARMD0343
#endif
//	ReadTimeBasedAction();	 				

#ifdef	ENABLE_EMAIL_SEND

//	EmailInitialise();   it creats problem of near by memory overrite,to solve: initialise emailID array.
#endif
#ifdef PROCESS_HEARTBEAT
	UDPHeartBeatCount = Doorinfo.UDPHeartBeat-1;
#endif
	InitServerPara();	  //ARMF2004
#ifdef ENABLE_TCP_PUSH
	TPushState =  TPUSH_STATE_INI;
	TPushServerNum =1;
	TCP_PUSH_socket = -1 ;
	FContSend = 0;
#endif
}

#ifdef ENABLE_ETHERNET_OLD 
// This function implements a very simple dynamic HTTP-server.
// It waits until connected, then sends a HTTP-header and the
// HTML-code stored in memory. Before sending, it replaces
// some special strings with dynamic values.
// NOTE: For strings crossing page boundaries, replacing will
// not work. In this case, simply add some extra lines
// (e.g. CR and LFs) to the HTML-code.
void HTTPServer(void)
{
  if (SocketStatus & SOCK_CONNECTED)             // check if somebody has connected to our TCP
  {
    if (SocketStatus & SOCK_DATA_AVAILABLE)      // check if remote TCP sent data
      TCPReleaseRxBuffer();                      // and throw it away

    if (SocketStatus & SOCK_TX_BUF_RELEASED)     // check if buffer is free for TX
    {
      if (!(HTTPStatus & HTTP_SEND_PAGE))        // init byte-counter and pointer to webside
      {                                          // if called the 1st time
        HTTPBytesToSend = sizeof(WebSide) - 1;   // get HTML length, ignore trailing zero
        PWebSide = (unsigned char *)WebSide;     // pointer to HTML-code
      }

      if (HTTPBytesToSend > MAX_TCP_TX_DATA_SIZE)     // transmit a segment of MAX_SIZE
      {
        if (!(HTTPStatus & HTTP_SEND_PAGE))           // 1st time, include HTTP-header
        {
          memcpy(TCP_TX_BUF, GetResponse, sizeof(GetResponse) - 1);
          memcpy(TCP_TX_BUF + sizeof(GetResponse) - 1, PWebSide, MAX_TCP_TX_DATA_SIZE - sizeof(GetResponse) + 1);
          HTTPBytesToSend -= MAX_TCP_TX_DATA_SIZE - sizeof(GetResponse) + 1;
          PWebSide += MAX_TCP_TX_DATA_SIZE - sizeof(GetResponse) + 1;
        }
        else
        {
          memcpy(TCP_TX_BUF, PWebSide, MAX_TCP_TX_DATA_SIZE);
          HTTPBytesToSend -= MAX_TCP_TX_DATA_SIZE;
          PWebSide += MAX_TCP_TX_DATA_SIZE;
        }
          
        TCPTxDataCount = MAX_TCP_TX_DATA_SIZE;   // bytes to xfer
        InsertDynamicValues();                   // exchange some strings...
        TCPTransmitTxBuffer();                   // xfer buffer
      }
      else if (HTTPBytesToSend)                  // transmit leftover bytes
      {
        memcpy(TCP_TX_BUF, PWebSide, HTTPBytesToSend);
        TCPTxDataCount = HTTPBytesToSend;        // bytes to xfer
        
		InsertDynamicValues();                   // exchange some strings...
        TCPTransmitTxBuffer();                   // send last segment
        TCPClose();                              // and close connection
        HTTPBytesToSend = 0;                     // all data sent
      }

      HTTPStatus |= HTTP_SEND_PAGE;              // ok, 1st loop executed
    }
  }
  else
    HTTPStatus &= ~HTTP_SEND_PAGE;               // reset help-flag if not connected
}

// samples and returns the AD-converter value of channel 0
/* to reduce size
unsigned int GetAD7Val(void)
{
// Keil: function replaced to handle LPC2378 A/D converter.
  unsigned int val;

  AD0CR = 0x01000001 | 0x002E0400;       // Setup A/D: 10-bit AIN0 @ 3MHz
  do {
    val = AD0GDR;                        // Read A/D Data Register
  } while ((val & 0x80000000) == 0);     // Wait for end of A/D Conversion
  AD0CR &= ~0x01000001;                  // Stop A/D Conversion
  val = (val >> 6) & 0x03FF;             // Extract AIN0 Value
  return(val / 10);                      // result of A/D process 
}

// samples and returns AD-converter value of channel 1

unsigned int GetTempVal(void)
{
// Keil: function replaced to handle LPC2378 A/D converter.
  unsigned int val;

  AD0CR  = 0x01000002 | 0x002E0400;      // Setup A/D: 10-bit AIN1 @ 3MHz
  do {
    val = AD0GDR;                        // Read A/D Data Register
  } while ((val & 0x80000000) == 0);     // Wait for end of A/D Conversion
  AD0CR &= ~0x01000002;                  // Stop A/D Conversion
  val = (val >> 6) & 0x03FF;             // Extract AIN1 Value
  return(val / 10);                      // result of A/D process 
}

// searches the TX-buffer for special strings and replaces them
// with dynamic values (AD-converter results)

void InsertDynamicValues(void)
{
unsigned char *Key;
//  char NewKey[5];
//  unsigned int i;
  
	Key  = "MUKUND WEB TEST DATA";
	memcpy(TCP_TX_BUF, Key, sizeof(Key) - 1);
	UARTSend( 1, Key, sizeof(Key)); 
//  *NewKey = rand();
 // if (TCPTxDataCount < 4) return;                     // there can't be any special string
//  memcpy(Key, NewKey, 3);
  Key = TCP_TX_BUF;
  
  for (i = 0; i < (TCPTxDataCount - 3); i++)
  {
    if (*Key == 'A')
     if (*(Key + 1) == 'D')
       if (*(Key + 3) == '%')
         switch (*(Key + 2))
         {
           case '7' :                                 // "AD7%"?
           {
             sprintf(NewKey, "%3u", GetAD7Val());     // insert AD converter value
             memcpy(Key, NewKey, 3);                  // channel 7 (P6.7)
             break;
           }
           case 'A' :                                 // "ADA%"?
           {
             sprintf(NewKey, "%3u", GetTempVal());    // insert AD converter value
             memcpy(Key, NewKey, 3);                  // channel 10 (temp.-diode)
             break;
           }
         }
    Key++;
  }
}*/
#endif

/*--------------------------------------------------------------------------*/
void MakeSound(unsigned char type)
{
	SoundType = type;
	if(type == SOUND_DOUBLE_BEEP)
	{
//		SoundTimer = TIME_SOUND_DOUBL_BEEP * 14;
		SoundTimer = TIME_SOUND_DOUBL_BEEP / 5;		//ARMD0057 as timer interrupt occurs after every 100msecs
	}
	else
	{
//		SoundTimer = type * 14;
		SoundTimer = type / 5;		
	}
	BUZZER_ON();
}
unsigned char F_MakeSound=CLR;				 //ARMF2007
unsigned char MakeSoundCounter=0;
unsigned char MakeSoundType;
/*--------------------------------------------------------------------------*/
void MakeSoundForTimeMainLoop(void)		//ARMF2007
{
	if(F_MakeSound == SET)
	{
		if(MakeSoundCounter == 0)
		{
	   		F_MakeSound = CLR;
		}
		else
		{
			MakeSoundCounter --;			  
			MakeSound(MakeSoundType);
		}
	}
}
/*--------------------------------------------------------------------------*/
void MakeSoundForTime(unsigned char ttime,unsigned char stype)	   //ARMF2007
{
	F_MakeSound = SET;
	MakeSoundCounter = ttime;	
	MakeSoundType=stype;
}

/*--------------------------------------------------------------------------*/
void HandleSoundControl(void)
{
	if(SoundTimer == 0)
		BUZZER_OFF();
}

/*--------------------------------------------------------------------------*/
void ProcessCard(unsigned char channel)
{
char AccessGranted;
	if(INTRUSION_STATUS == CLR)
	{
		if(channel <= MAX_READERS_SUPPORT)
		{			  	
			ReaderNo = channel;			 
#ifdef BIO_METRIC
			FingerRechkCount = 0;        //A00006
			if((ReaderNo == 1) || ((CHECK_TWO_DOOR(channel)) && (ReaderNo == 2)))
#else
			if(ReaderNo == 1)  // for In reader 
#endif
			{
					ReaderNo = GetCurrentReaderNo();	//NGD00079
					#ifdef BIO_METRIC
					if(ReaderNo == 2) 
						CurrentUser.RdrNo = ReaderNo;
					#endif
					HandleWeigandEvent();
			}
			else // For out Reader 
			{
// 				if(!CHK_NAME_DISPLAY())//ARMD0335
// 				{
// 					L_DisplayROMStr("UID:            ",16,1);
// 					L_DisplayCardNumber((CARDNO_DATA_STORAGE_TYPE)ReceivedCardNo,6,1);
// 				}
/*#ifndef BIO_METRIC
				if(!((DisplayMode == MODE_MEMORY_FULL) || ((F_TrnxMemFull == SET) && (DisplayMode != MODE_ADMIN_PASSWORD))))
#endif */
				{	 // NGARM01
					AccessGranted = GetUserInfoAndProcess(ReceivedCardNo,&CurrentUser,CurrentUser.InputType);//ARMD0392
					if(AccessGranted == 0)//success
						UserAccessGranted(&CurrentUser); 
					else if( AccessGranted == -2)//memory full.
					ReaderData[ReaderNo].F_WeigandInterrupt = CLR;//ARMD0346
				}
			}
		}
		else
			DisplayBottomStatusIcon(0,"Bad Reader No",0,0);
//			L_DisplayROMStr("Bad Reader No   ",16,ROW_CARD_ERROR_DISP);
	}
}

/*--------------------------------------------------------------------------*/
void HandleDisplayTimeOuts(void)
{
unsigned char message[17],tmp;
	tmp = 1;
	ToggleCount ++;
	if(ToggleCount >= 6)
		ToggleCount = 0;
		ManageAutoInOut();//ARMD0343	
#ifdef BIO_METRIC			  
	if((F_UserMessageDisplay == SET) && (IdleKeyCounter == (MAX_KEY_IDLE_TIME - 3)) && ((DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == USER_IDENTIFY_MODE)))
#else
	if((F_UserMessageDisplay == SET) && (IdleKeyCounter == (MAX_KEY_IDLE_TIME - 3)) && (DisplayMode == MODE_WAIT_FOR_CARD))
#endif
	{               // in this loop it handles Screen in Place of Wellcome MSG Get data from Flash for Global mSG 
// 		if(ScreenFormatData.F_Scrollimage != 1)  
// 			DisplayFormat(FORMAT_WELCOME_SCREEN);//glcd
		if(UserMessage != 0)
		{
//#ifdef BIO_METRIC
			if(GetMessageFromFlash(UserMessage,message) == 0)
//#endif
			{
				//L_BlankDisplay(ROW_USER_ENTRY);
				//L_DisplayROMStr(message,16,ROW_USER_ENTRY);
				DisplayBottomStatusIcon(0,message,0,0);
				tmp = 0;
			}
		}
#ifdef ENABLE_BANNER_GLOBAL_MSG
		if(SysInfo.GlobleMsg != 0)
		{
//#ifdef BIO_METRIC
			if(GetMessageFromFlash(SysInfo.GlobleMsg,message) == 0)
//#endif
			{
				//L_BlankDisplay(ROW_USER_FUNCTION);
				//L_DisplayROMStr(message,16,ROW_USER_FUNCTION);
				DisplayBottomStatusIcon(0,message,0,0);
				tmp = 0;
			}
		}
#endif		
		if(tmp == 1)
		{
			IdleKeyCounter = IdleKeyCounter + 3;
		}
		else
			MakeSound(SOUND_USER_MESSAGE);
		F_UserMessageDisplay = CLR;
	}
		DisplayWelcomeMessage();	
#ifdef BIO_METRIC    // ideal keycounter decides wht
	if(/*((DisplayMode == USER_IDENTIFY_MODE) || (DisplayMode == MODE_WAIT_FOR_CARD)) && */(IdleKeyCounter >= MAX_KEY_IDLE_TIME)/*&&(F_BIO_COMM == CLR)*/&& (F_Password == CLR))
#else
	if(/*(DisplayMode == MODE_WAIT_FOR_CARD) &&*/ (IdleKeyCounter >= MAX_KEY_IDLE_TIME) && (F_Password == CLR))
#endif
	{
// 		if(ScreenFormatData.F_Scrollimage != 1)  
// 			DisplayFormat(FORMAT_WELCOME_SCREEN);//glcd
		
		F_UserMessageDisplay = CLR;
		//L_DisplayROMStr((char *)&DISPLAY_MODE[DisplayMode],16,ROW_USER_FUNCTION);
		WelMessageType = 0xFF;
//		DisplayWelcomeMessage();
		if(ToggleCount >= 2)
		{
			if(ToggleCount >= 4)
			{
			  #ifndef SUPPORT_7SEG_DISPLAY 
			  if(Doorinfo.EnDisEmpInDispCount == SET)         
               {
                  //L_DisplayROMStr("COUNT:          ",16,ROW_USER_FUNCTION);
                  //L_DisplayDecimalInteger(InEmpCount,11,ROW_USER_FUNCTION);
					sprintf((char*)DisplayTempBuffer,"COUNT: %05d",InEmpCount);
				  DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);
               }
			   #endif
				if(PercentageMem >= 99)
				{
					//L_DisplayROMStr("TR Mem Used    %",16,ROW_USER_ENTRY);
					//L_DisplayChar2(12,PercentageMem);
					sprintf((char*)DisplayTempBuffer,"TR Mem Used   %2d%%",PercentageMem);
					DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);
				}
				else if(SysInfo.MemMgmt != 0)
				{  
				// we have to display memory status only when memory is more then % of MemMgme
				//as we use same data field to store memory disp value and overwrite mode
					if((SysInfo.MemMgmt%100) <= PercentageMem)
					{
						//L_DisplayROMStr("TR Mem Used    %",16,ROW_USER_ENTRY);
						//L_DisplayChar2(12,PercentageMem);
						sprintf((char*)DisplayTempBuffer,"TR Mem Used   %2d%%",PercentageMem);
						DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);
					}
					else
						ToggleCount = 0;
				}
				else
					ToggleCount = 0;
			}
/*			else if((INTRUSION_STATUS == CLR) && (F_DMZOccur == CLR))    // no need to display place finger 
			{
#ifdef BIO_METRIC
				if(SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY)  //not supposed to work if Sensor Fails
				{
//					L_DisplayROMStr("Place Finger ...",16,ROW_USER_ENTRY);
					//sprintf((char*)DisplayTempBuffer,"TR Mem Used   %2d/%",PercentageMem);
					DisplayBottomStatusIcon(0,"Place Finger ...",0,0);					
				}
#else
//	#ifdef SMART_CARD
///  commented in NG code 
//					L_DisplayROMStr("Show Card ...... ",16,ROW_USER_ENTRY);     //removed for TFT display
//					DisplayBottomStatusIcon(0,"Show Card ...... "0,0);
					sprintf(DisplayTempBuffer,"Show Card ... ");	
					DisplayBottomStatusIcon(0,DisplayTempBuffer,0,0);	
	//#endif
#endif
				if(ScreenFormatData.F_Scrollimage != 1)
					DisplayFormat(FORMAT_WELCOME_SCREEN);
			}  */
		}
		else
		{
			//LCDDisplayTimeData(Datetime,ROW_USER_ENTRY,CWeekDay);
		}
	}	
			
#ifdef BIO_METRIC
	if((F_KeyIdleTime == SET) && (F_Password == CLR) && (F_BIO_COMM == CLR))
#else
	if((F_KeyIdleTime == SET) && (F_Password == CLR))
#endif
	{
		DisplayMode = MODE_WAIT_FOR_CARD;
		DisplayFormat(FORMAT_WELCOME_SCREEN);
		HandleAllModeEvents(FUNCTION_KEY);
		F_KeyIdleTime = CLR;
	}
#ifndef ADMIN_NO_LOG_OUT
//	if(F_Password == SET || F_Password == PASS_ADMIN_LOGIN || F_Password == PASS_IPSET_LOGIN)
	if(F_Password != CLR)
	{
		if(AdminLogOutTimer >= MAX_ADMIN_TIME_OUT)
		{
// 			if(ScreenFormatData.F_Scrollimage != 1)
// 				DisplayFormat(FORMAT_WELCOME_SCREEN);//glcd
			F_Password = CLR;
			//L_DisplayROMStr("Admin Logged Out  ",16,ROW_USER_FUNCTION);

			DisplayStatusIcon(STATUS_LOCKED,0);//log out
			DisplayBottomStatusIcon(0,"Admin Logged Out",0,0);
			DisplayFormat(FORMAT_WELCOME_SCREEN);
			IdleKeyCounter = MAX_KEY_IDLE_TIME;
			F_KeyIdleTime = CLR;
			DisplayMode = MODE_WAIT_FOR_CARD;
			WelMessageType = 0xFF;
		}
	}
#endif
	PercentageMem = GetPercentageFull(TransReadPtr,TransWritePtr);
	if(SysInfo.MemMgmt >= 100)
	{ // MemMgmt >=100 indicates do not overwrite the data
		if(PercentageMem >= 99)
		{
			if(TransFreeLocation < 10)
				F_TrnxMemFull = SET;
			else
				F_TrnxMemFull = CLR;
			if(MODE_WAIT_FOR_CARD == DisplayMode)
			{
				DisplayFormat(FORMAT_WELCOME_SCREEN);//glcd
				DisplayMode = MODE_MEMORY_FULL;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 6;
				//L_DisplayROMStr("** MemoryFull **",16,ROW_USER_FUNCTION);
				DisplayBottomStatusIcon(0,"** MemoryFull **",0,0);
				
				F_KeyIdleTime = CLR;
				//LCDDisplayTimeData(Datetime,ROW_USER_ENTRY,CWeekDay);
			}
		}
		else
			F_TrnxMemFull = CLR;
	}
	else
		F_TrnxMemFull = CLR; 
}


/*--------------------------------------------------------------------------*/
#ifdef BIO_METRIC2

void HandleSerialBioData(unsigned char n)
{//  if(DeabugLevel)
  //		printf("%x",n);
	if(ReceiveCountSERPC == 0)
	{
		if(n == BIO_START_CMD)
      {
      	string_buffer[ReceiveCountSERPC] = n;
	      ReceiveCountSERPC =1;
	   }
	}
	else
	{
		string_buffer[ReceiveCountSERPC] = n;
	   ReceiveCountSERPC ++;
	   if(ReceiveCountSERPC>=15)
	   {
	   	ReceiveCountSERPC = 15;
	      F_SerialCommandBio = SET;
//         if(DeabugLevel)
//           printf("\n\n");
	   }
	}
}

#endif

/*--------------------------------------------------------------------------*/
void DisplayWelcomeMessage(void)
{
unsigned char dispstr[20];
unsigned char  rdrno,Icon=0; //event,
#ifndef DISP_EVENT_MSGS_FROM_FLASH
unsigned char toggle;		// just to avoid warning
#endif

	if(ToggleCount > 4)
	ToggleCount = 0;
	if((SysInfo.ControllerMode != 4) && (SysInfo.ControllerMode != 2))
	{
		rdrno = (ToggleCount * 2) - 2;
#ifndef DISP_EVENT_MSGS_FROM_FLASH
		toggle = rdrno / 2;
#endif
	}
	else
	{
#ifndef DISP_EVENT_MSGS_FROM_FLASH
		toggle = rdrno = ToggleCount - 1;
#endif
	}

// 	if(ScreenFormatData.CurrentFormat != FORMAT_WELCOME_SCREEN)
// 		return ;

#ifdef BIO_METRIC
 	if((MODE_WAIT_FOR_CARD == DisplayMode) || (DisplayMode == USER_IDENTIFY_MODE))
#else
 	if(MODE_WAIT_FOR_CARD == DisplayMode)
#endif
	{
		if(F_FirmwareUpgrade)//highest priority
		{
//		   	L_DisplayROMStr("FIRMWARE UPGRADE",16,ROW_USER_FUNCTION);  //ARMD0309
			DisplayBottomStatusIcon(0,"FIRMWARE UPGRADE",0,0);
		}
		else if((FIRE_STATUS == SET)&&(FIRE_ALARM_RESET == CLR))	   //Fire
		{
			#ifdef DISP_EVENT_MSGS_FROM_FLASH
				WelMessageType = EVENT_FIRE_ALARM_HIGH;
			#else
			WelMessageType = WEL_FIRE_ALARM;
			#endif
			Icon = 0; // if having images - 1
		}
		else if((TAMPER_STATUS == SET)&&(TAMPER_ALARM_RESET == CLR))         //Tamper
		{
			#ifdef DISP_EVENT_MSGS_FROM_FLASH
				WelMessageType = EVENT_TAMPER_ALARM_HIGH;
			#else
				WelMessageType = WEL_TAMPER_ALARM;
			#endif
			Icon = 0; // if having images - 2
		}
		else if((INTRUSION_STATUS == SET)&&(INTRUSN_ALARM_RESET == CLR))
		{
			#ifdef DISP_EVENT_MSGS_FROM_FLASH
				WelMessageType = EVENT_INTRUSION_ALARM_HIGH;
			#else
			WelMessageType = WEL_INTRUSION_ALARM;
			#endif
			Icon = 0; // if having images - 3			
		}
		else if(DRStruct[0].DRStatus == DR_PC_USER_CLOSE)  // NGD00175
		{
					WelMessageType = WEL_DOOR_CLOSE; //| ((toggle+1) * 0x10);		   //not needed as we have only one door.			
		}			
		else if(DRStruct[0].DRStatus == DR_PC_USER_OPEN) // NGD00175
		{
					WelMessageType = WEL_DOOR_OPEN; //| ((toggle+1) * 0x10);		   //not needed as we have only one door.			
		}			
		else if((DRStruct[0].Dotl_Alarm == SET) && (DRStruct[0].ResetAlarm == CLR))  // NGD00078
		{
			#ifdef DISP_EVENT_MSGS_FROM_FLASH
				WelMessageType = EVENT_DOTL1_ALARM;
			#else
				WelMessageType = WEL_DOOR_OPEN_LONG | ((toggle+1) * 0x10);	
			#endif			
			Icon = 0; // if having images - 4
		}
		else if((DRStruct[0].Force_Alarm == SET) && (DRStruct[0].ResetAlarm == CLR))	//NGD00078
		{
			#ifdef DISP_EVENT_MSGS_FROM_FLASH
				WelMessageType = EVENT_FORCE1_ALARM;
			#else
				WelMessageType = WEL_DOOR_FORCE_OPEN | ((toggle+1) * 0x10);
			#endif				
			Icon = 0; // if having images - 5
		}
		else if(F_SDCardStatus == 1)
		{
			DisplayBottomStatusIcon(0,"SD card not detected",0,0);		
		}
		else if(F_SDCardStatus == 2)
		{
			DisplayBottomStatusIcon(0,"SD Card failed",0,0);			
		}	
#ifdef INSERT_SDCARD	  // SD CARD
		else if(F_FAT_MemStatus == 1)	// NGD00023
		{
			DisplayBottomStatusIcon(0,"SD FAT Mem Full",0,0);						
		}		
#endif
		else if (F_ImageUploadInProcess != 0)
		{
			DisplayBottomStatusIcon(0,"Uploading Image...",0,0);									
		}			
#ifdef BIO_METRIC
		else if (DisplayMode == MODE_BIOMETRIC_DOWNLOAD)
		{
			WelMessageType = WEL_TEMPLATE_READ_WRITE;
		}
#endif
#ifdef SUPPORT_NSERIES2
	   else if((F_DeadManZone == SET) && (Doorinfo.EnDisDeadManZone != 0)) 		//201210-1
      	{
	#ifdef DISP_EVENT_MSGS_FROM_FLASH
	      WelMessageType = EVENT_DEAD_MAN_ZONE;
	#else
	      WelMessageType = WEL_DEAD_MAN_ZONE;
	#endif
      	}
		else if ((F_DuelUserAuth == SET) && (Doorinfo.DuelUserAuth == 1))     // DUA wait for 2nd User	//ARMF2008
      	{
	#ifdef DISP_EVENT_MSGS_FROM_FLASH
         WelMessageType = EVENT_DUEL_USER_2;
	#else
	     WelMessageType = WEL_DUEL_USER_2;
	#endif
		}
#endif
		else
		{
			//switch(DRStruct[rdrno].DRStatus)//since only one door //ARMD0308
			switch(DRStruct[0].DRStatus)
			{
				case DR_USER_CLOSE://ARMD0305
					WelMessageType = WEL_DOOR_CLOSE; //| ((toggle+1) * 0x10);		   //not needed as we have only one door.
					break;
				case DR_USER_OPEN://NGD00078
					WelMessageType = WEL_DOOR_OPEN ;
					break;
				case DR_TZ_OPEN:
					WelMessageType = WEL_FREE_TIME_ZONE ;
					break;
				default:
					WelMessageType = WEL_WELCOME;
					break;
			}
		}
	}
	//if(WelMessageType != oldmsg)
	if(WelMessageType == 0)
	{
		if( (SysInfo.SelAccessType == 0x01) && (AccessType != 0) )//chk only for ONE , to avoid garbage values.
		{
			L_DisplayROMStr(AccessTypeMessage,16,1);
		}
		else
		{ 
#ifdef ENABLE_BANNER_GLOBAL_MSG			
			if((SysInfo.BannerMsg != 0) && (WelMessageType == WEL_WELCOME) && ((ToggleCount < 2) || (SysInfo.ContInOut == 0) || (SysInfo.ContInOut == 4) || (SysInfo.ContInOut == 5)))  // If banner message toggle between inout and banner
			{
				if(GetMessageFromFlash(0,BannerMessage) == 0)
				{}//					L_DisplayROMStr(BannerMessage,16,ROW_USER_FUNCTION);
			}
			else
#endif				
			{
				if(WelMessageType == WEL_WELCOME)
				{
						if((SysInfo.ContInOut != 0) && (SysInfo.ContInOut != 5) )/*&& (SysInfo.ContInOut != 4) && (SysInfo.ContInOut != 5))*/	//ARMD0356
						{
							if(SysInfo.ContInOut == 2)
							{
								//L_DisplayROMStr("   Out Entry    ",16,ROW_USER_FUNCTION);
								DisplayBottomStatusIcon(0,"   Out Entry    ",0,0);
							}
							else if(SysInfo.ContInOut == 1)
							{
								//L_DisplayROMStr("   In Entry     ",16,ROW_USER_FUNCTION);
								DisplayBottomStatusIcon(0,"   In Entry    ",0,0);
							}
							else
							{
								if(InOutReader == 1)
								{
									//L_DisplayROMStr("   In Entry     ",16,ROW_USER_FUNCTION);
									DisplayBottomStatusIcon(0,"   In Entry    ",0,0);
								}
								else
								{
									//L_DisplayROMStr("   Out Entry    ",16,ROW_USER_FUNCTION);
									DisplayBottomStatusIcon(0,"   Out Entry    ",0,0);
								}
							}
							#ifdef EXTENDED_KEYPAD	 
							if(LunchODInOut > 0)
								L_DisplayROMStrLoc((BYTE*)&F2_KEY_MODE[LunchODInOut],16,ROW_USER_FUNCTION,0);
							#endif
						}
						else
						{
						//L_DisplayROMStr((BYTE*)&WEL_MESSAGE[WelMessageType&0x0f],16,ROW_USER_FUNCTION);   //do not display welcome for tft
							if(ToggleCount >= 4)
							{
								if(WelMessageType < MAX_WEL_MESSAGE)
									DisplayBottomStatusIcon(0,(BYTE*)&WEL_MESSAGE[WelMessageType&0x0f],0,0);   //do not display welcome for tft
							}
							if(WelMessageType & 0xF0)
							 {
	// 							if(SysInfo.ContInOut != 5)
	// 								L_DisplayCharAt1(15,toggle+'1');
	 						 }
						}
					}
				else
				{
					//L_DisplayROMStr((BYTE*)&WEL_MESSAGE[WelMessageType&0x0f],16,ROW_USER_FUNCTION);
					if(WelMessageType & 0xF0)
					{
//						if(SysInfo.ContInOut != 5)
//						{
							//L_DisplayCharAt1(15,toggle+'1');
//							sprintf((char*)DisplayTempBuffer,"%s %1d",WEL_MESSAGE[WelMessageType&0x0f],toggle+1);
//						}
					}
//					DisplayBottomStatusIcon(0,(BYTE*)&WEL_MESSAGE[WelMessageType&0x0f],0,Icon);
				}
			}
		}//else if((SysInfo.SelAccessType) && (AccessType != 0))
		#ifdef ENABLE_GSM_GPRS
		if((WelMessageType == WEL_WELCOME) && (Doorinfo.GPRSEnable == 1))
		{
//			DisplaySignalStrength(SignalStrength,ROW_USER_FUNCTION);
		}
		#endif
	}//if(WelMessageType == 0)
	else if(F_FirmwareUpgrade == CLR)
	{
		#ifdef DISP_EVENT_MSGS_FROM_FLASH		
		if((WelMessageType > WEL_TEMPLATE_READ_WRITE) && (WelMessageType < MAX_ERROR_MSGS))
		{
			//GetMessageFromFlash(ERROR_MESSAGE_BASE+(WelMessageType&0x0f),dispstr);
			 GetMessageFromFlash(ERROR_MESSAGE_BASE+(WelMessageType),dispstr);
			if(Icon ==0)	
				DisplayBottomStatusIcon(0,dispstr,0,Icon);
			else
				DisplayBottomStatusIcon(0,dispstr,1,Icon);
					//L_DisplayROMStr(dispstr,16,ROW_USER_FUNCTION);
		}
		else//bug resolved for : "3oor force open msg".
		#endif
		{
			//L_DisplayROMStr((BYTE*)&WEL_MESSAGE[WelMessageType&0x0f],16,ROW_USER_FUNCTION);//since getting different msgs by masking.
			//L_DisplayROMStr((BYTE*)&WEL_MESSAGE[WelMessageType],16,ROW_USER_FUNCTION);  //ARMD0301 
			if(WelMessageType < MAX_WEL_MESSAGE)				
				DisplayBottomStatusIcon(0,(BYTE*)&WEL_MESSAGE[WelMessageType],0,0);
		}
		/*if(WelMessageType & 0xF0)
		{
		if(SysInfo.ContInOut != 5)
		L_DisplayCharAt1(15,toggle+'1');
		}//if(WelMessageType & 0xF0)
		*/
	}//else if(WelMessageType == 0)
}
/*--------------------------------------------------------------------------*/
void TestFlash(void)
{   
	WORD i = 0;

	DisplayFlashpage(233);	
	DisplayFlashpage(234);	    
	DisplayFlashpage(235);		   	
	for(i=0;i<SPIBUFSIZE;i++)
		SBuffer[i] = (unsigned char)i & 0x00FF; 	

	MainMem_BuffWrt(0,1,(BYTE*)SBuffer,SPIBUFSIZE);
	BuffWrt_MainMem(233,1);
//	DisplayFlashpage(3233);	    
	MainMem_ReadPage(233,0,(BYTE*)SBuffer,SPIBUFSIZE); 	
	DisplayFlashpage(233);	    

	for(i=0;i<SPIBUFSIZE;i++)
		SBuffer[i] = 0x55; 		
	MainMem_BuffWrt(0,1,(BYTE*)SBuffer,SPIBUFSIZE);
	BuffWrt_MainMem(235,1);
	DisplayFlashpage(235);	    

	for(i=0;i<SPIBUFSIZE;i++)
		SBuffer[i] = (unsigned char)i & 0x00FF; 		
	MainMem_BuffWrt(0,1,(BYTE*)SBuffer,SPIBUFSIZE);
	BuffWrt_MainMem(234,1);
	DisplayFlashpage(234);	    
}  

int TestingFlash(unsigned int guintBlockNum)
{
	WORD i = 0;
	unsigned char pno,error;
	unsigned char temp=1;
	unsigned char tempbuffer[SPIBUFSIZE];
	for(pno=guintBlockNum;pno<(guintBlockNum+11);pno++)
	{
		for(i=0;i<SPIBUFSIZE;i++)
			SBuffer[i] = (unsigned char)temp & 0x00FF; 	
		MainMem_BuffWrt(0,1,(BYTE*)SBuffer,SPIBUFSIZE);
		BuffWrt_MainMem(pno,1);
		temp++;
		Delay(100);
		MainMem_ReadPage(pno,0,(BYTE*)tempbuffer,SPIBUFSIZE); 	
		error = strncmp((const char*)SBuffer,(const char *)tempbuffer,SPIBUFSIZE); 	
		if(error != 0)
			return(error);
		if(pno>7940)
			return(1);
	}
	return(0);
}

/******************************************************************************
** Function name:		delay
**
** Descriptions:		Delay in while loop cycles.		
**
** parameters:			delay counter
** Returned value:		None
** 
******************************************************************************/
void Delay(DWORD cnt) 
{
	while(cnt--);
		return;
}

/*-----------------------------------------------------------------------------*/
void DisplayModelInfo(unsigned char count)          //DA00027
{
	if(count >= 7)
		return;
	
	memset(DisplayTempBuffer,0,50);
	switch(count)
	{
		case 1:
			//L_DisplayROMStr("Ver:  ",16,ROW_USER_FUNCTION);
			//L_DisplayROMStrLoc((BYTE *)&COMPILEDATE,16,ROW_USER_FUNCTION,5);
			sprintf((char*)&DisplayTempBuffer,"Ver:  %s",(BYTE *)&COMPILEDATE);
		break;

		case 2:
			memcpy(Controllertype,CONTR_TYPE[ReaderInfo[0].CntrolrType],17);
//			sprintf((char*)DisplayTempBuffer,"%s",&Controllertype[0]);
			strcpy((char*)&DisplayTempBuffer,(char*)&Controllertype[0]);	
		break;
		
		case 3:
			if((ModelInfo.ModelNo[0] >= 19) && (ModelInfo.ModelNo[0] <= 0x7F) && \
				((ModelInfo.ModelNo[1] >= 19) && (ModelInfo.ModelNo[1] <= 0x7F)))  // If case model number data is junk we will not display this will not work always but will help in upgrade case at site
			{
// 				L_DisplayROMStr("                ",16,ROW_USER_FUNCTION);
// 				L_DisplayROMStr(ModelInfo.ModelNo,16,ROW_USER_FUNCTION);
// 				L_DisplayROMStr("                ",16,ROW_USER_ENTRY);
// 				L_DisplayROMStrLoc(ModelInfo.SerialNo,8,ROW_USER_ENTRY,0);
// 				L_DisplayROMStrLoc(ModelInfo.MfgDate,8,ROW_USER_ENTRY,10);
//				sprintf((char*)DisplayTempBuffer,"%s",ModelInfo.ModelNo);
				strncpy((char*)&DisplayTempBuffer,(char*)&ModelInfo.ModelNo,sizeof(ModelInfo.ModelNo));	
				DisplayTempBuffer[sizeof(ModelInfo.ModelNo)+1] = '\0';
			}
		break;

		case 4:
			if((ModelInfo.ModelNo[0] >= 19) && (ModelInfo.ModelNo[0] <= 0x7F) && \
				((ModelInfo.ModelNo[1] >= 19) && (ModelInfo.ModelNo[1] <= 0x7F)))  // If case model number data is junk we will not display this will not work always but will help in upgrade case at site
			{
				sprintf((char*)DisplayTempBuffer,"%s %s",ModelInfo.SerialNo,\
														 ModelInfo.MfgDate);
			}
		break;

		case 5:
			MsgPrint(MSG_WARNING,0,"System Started ...");
			MsgPrint(MSG_WARNING,0,"bio System Started ...");
//			sprintf((char*)DisplayTempBuffer,"%s",(BYTE *)ProductStr);
			strcpy((char*)DisplayTempBuffer,(char *)ProductStr);	
			break;
		case 6:
			sprintf((char*)DisplayTempBuffer,"%s V%c.%c%c %03d",(BYTE *)ProdVerStr,MAJOR_VER,MINOR_VER,CONTROLLER_TYPE,SysInfo.MySlaveNo);
			break;
// 		case 6:
// #ifdef BIO_METRIC
// 			sprintf((char*)DisplayTempBuffer,"%03d %5d",SysInfo.MySlaveNo,Doorinfo.ControllerNo);
// #else
// 			sprintf((char*)DisplayTempBuffer,"%03d %5d",SysInfo.MySlaveNo,Doorinfo.ControllerNo);
// #endif
// 			break;

		default:
			break;
	}

	//clear bottom msg area.
// 	rectinfo.FillType = RCTFILL_PLAIN;
// 	rectinfo.Color = ThemeColour[SysInfo.ThemeSelectNo].TitleMSGBackgroundColour;
// 	rectinfo.Hight = BOTTOM_STATUS_ICON_SECTION_HEIGHT ;
// 	rectinfo.Width = BOTTOM_STATUS_ICON_SECTION_WIDTH ;
// 	rectinfo.BorderColor = 0;
// 	DrawRect(&rectinfo, BOTTOM_STATUS_ICON_SECTION_X0, BOTTOM_STATUS_ICON_SECTION_Y0);

// 	//draw center string.
// 	DrawCenterText(	BOTTOM_STATUS_ICON_SECTION_Y0,
// 				ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,   // 
// 				BOTTOM_STATUS_MSG_FONTINFO_PTR,
// 				(char*)DisplayTempBuffer);
// 	
// 					DrawCenterTextWithBackGround(BOTTOM_STATUS_ICON_SECTION_Y0,
// 																	ThemeColour[SysInfo.ThemeSelectNo].TitleMSGStrColour,
// 																	BOTTOM_STATUS_MSG_FONTINFO_PTR,
// 																	320,	
// 																	DisplayTempBuffer,
// 																	ThemeColour[SysInfo.ThemeSelectNo].StatusbarColour);
	DisplayBottomStatusIcon(0,(unsigned char*)DisplayTempBuffer,0,0);	
}

#ifdef NOT_IN_USE
/******************************************************************************/
WORD HandleWeigandRawCard1(DWORD WeigandData1,BYTE WCount1,BYTE *fcode)
{  // printf("%d",Ones);
  //	printf("%d",Zero);
	MsgPrint(MSG_WARNING,(WORD)WCount1,"Weigand1 Count");
	MsgPrint(MSG_WARNING,(WORD)WeigandData1&0xFFFF,"Raw WData LSB=");
	MsgPrint(MSG_WARNING,(WORD)(WeigandData1/0x10000),"Raw WData MSB=");
//   if(DeabugLevel)
//	   printf("Card No ""%d",(WORD)WeigandData1);
	switch(WCount1)
	{
	case 26:
		WeigandData1 = WeigandData1 >>2;
      *fcode = (BYTE) (WeigandData1 >> 16);
		break;
	case 34:
		WeigandData1 = WeigandData1 >> 2;
      *fcode = (BYTE) (WeigandData1 >> 16);
		break;
	case 35:
		WeigandData1 = WeigandData1 >> 5;
      *fcode = (BYTE) (WeigandData1 >> 16);
		break;
	case 25:
 		WeigandData1 = WeigandData1 >> 2;
      *fcode = (BYTE) (WeigandData1 >> 16);
		break;
   case 8:
		WeigandData1 = (WeigandData1>>1) &0x0F;
#ifdef MAGReader
	case 95:
			WeigandData1 = (WeigandData1>>3);
      MAGFacility1 = (MAGFacility1>>7);

      magdata[0] = (BYTE)(MAGFacility1 & 0x0000000F)+'0';

      magdata[1] = (BYTE)((MAGFacility1 & 0x000000F0) >> 4) +'0';

      magdata[2] = (BYTE)((MAGFacility1 & 0x00000F00) >> 8) +'0';

      magdata[3] = (BYTE)((MAGFacility1 & 0x0000F000) >> 12) +'0';

      magdata[4] = (BYTE)((MAGFacility1 & 0x000F0000) >> 16) +'0';

      *fcode = (BYTE) FiveAsciiToHex(&magdata[0]);

      magdata[0] = (BYTE)(WeigandData1 & 0x0000000F)+'0';

      magdata[1] = (BYTE)((WeigandData1 & 0x000000F0) >> 4) +'0';

      magdata[2] = (BYTE)((WeigandData1 & 0x00000F00) >> 8) +'0';

      magdata[3] = (BYTE)((WeigandData1 & 0x0000F000) >> 12) +'0';

      magdata[4] = (BYTE)((WeigandData1 & 0x000F0000) >> 16) +'0';

      WeigandData1 = FiveAsciiToHex(&magdata[0]);
      break;
#endif
	default:
		WeigandData1 =0;
		break;
	}
   if(DeabugLevel)
	{//   printf("Reader1 ""%d",WCount1);
   	 //printf("Card No ""%d",(WeigandData1 & 0xFFFF));
   }

 	MsgPrint(MSG_WARNING,(WORD)WeigandData1&0xFFFF,"Card LSB=");
 	MsgPrint(MSG_WARNING,(WORD)(WeigandData1/0x10000),"Card MSB=");
 // Ones = Zero = 0;
	return((WORD )WeigandData1 & 0xFFFF);
}
/*****************************************************************************/
WORD HandleWeigandRawCard2(DWORD WeigandData2,BYTE WCount2,BYTE *fcode)
{ // printf("%d",Ones);
 //	printf("%d",Zero);
	MsgPrint(MSG_WARNING,(WORD)WCount2,"Weigand2 Count");
	MsgPrint(MSG_WARNING,(WORD)WeigandData2&0xFFFF,"Raw WData LSB=");
	MsgPrint(MSG_WARNING,(WORD)(WeigandData2/0x10000),"Raw WData MSB=");
	switch(WCount2)
	{
	case 26:
		WeigandData2 = WeigandData2 >>2;
      *fcode = (BYTE) (WeigandData2 >> 16);
		break;
	case 34:
		WeigandData2 = WeigandData2 >> 2;
      *fcode = (BYTE) (WeigandData2 >> 16);
		break;
	case 35:
		WeigandData2 = WeigandData2 >> 5;
      *fcode = (BYTE) (WeigandData2 >> 16);
		break;
	case 25:
 		WeigandData2 = WeigandData2 >> 2;
      *fcode = (BYTE) (WeigandData2 >> 16);
		break;
   case 8:
		WeigandData2 = (WeigandData2>>1) &0x0F;
      break;
#ifdef MAGReader
   case 95:
		WeigandData2 = (WeigandData2>>3);
      MAGFacility2 = (MAGFacility2>>7);

      magdata[0] = (BYTE)(MAGFacility2 & 0x0000000F)+'0';

      magdata[1] = (BYTE)((MAGFacility2 & 0x000000F0) >> 4) +'0';

      magdata[2] = (BYTE)((MAGFacility2 & 0x00000F00) >> 8) +'0';

      magdata[3] = (BYTE)((MAGFacility2 & 0x0000F000) >> 12) +'0';

      magdata[4] = (BYTE)((MAGFacility2 & 0x000F0000) >> 16) +'0';

      *fcode = (BYTE) FiveAsciiToHex(&magdata[0]);

      magdata[0] = (BYTE)(WeigandData2 & 0x0000000F)+'0';

      magdata[1] = (BYTE)((WeigandData2 & 0x000000F0) >> 4) +'0';

      magdata[2] = (BYTE)((WeigandData2 & 0x00000F00) >> 8) +'0';

      magdata[3] = (BYTE)((WeigandData2 & 0x0000F000) >> 12) +'0';

      magdata[4] = (BYTE)((WeigandData2 & 0x000F0000) >> 16) +'0';

      WeigandData2 = FiveAsciiToHex(&magdata[0]);
      break;
#endif
	default:
		WeigandData2 =0;
		break;
	}
	if(DeabugLevel)
	{  
//		printf("Reader2 ""%d",WCount2);
//		printf("Card No ""%d",(WeigandData2 & 0xFFFF));
	}   
 	MsgPrint(MSG_WARNING,(WORD)WeigandData2&0xFFFF,"Card LSB=");
 	MsgPrint(MSG_WARNING,(WORD)(WeigandData2/0x10000),"Card MSB=");
 //Ones = Zero = 0;
	return((WORD )WeigandData2 & 0xFFFF);
}  
#endif

/*-----------------------------------------------------------------------------*/
#ifdef BIO_METRIC
void ValidateTemplateSize(WORD tempsz)
{
	if(tempsz != Doorinfo.TemplateSize)               //Templete size 256 and 1016(SFOD) are not supported by our unit
	{
		ClearBootScreen();				
		BUZZER_ON();
		if((Doorinfo.TemplateSize == SUPPORTED_TEMPLATE_SZ_2) || (Doorinfo.TemplateSize == SUPPORTED_TEMPLATE_SZ_3) || \
			(Doorinfo.TemplateSize == SUPPORTED_TEMPLATE_SZ_4) || (Doorinfo.TemplateSize == SUPPORTED_TEMPLATE_SZ_5))
		{
			ENABLE_BIO_COMM();
			if(WriteSystemParameter(BIO_SYS_TEMPLATE_SIZE,Doorinfo.TemplateSize) == 0)
			{
				if(SaveBioSystemParameter() == 0)
				{
					SensorTemplateSize = Doorinfo.TemplateSize;
//					L_DisplayROMStr("TemplateSz:     ",16,ROW_USER_ENTRY);
//					L_DisplayDecimalInteger(Doorinfo.TemplateSize,11,ROW_USER_ENTRY);
					memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
					sprintf((char*)DisplayTempBuffer,"%s%3d","TemplateSz:",Doorinfo.TemplateSize);
					L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG2);
					
//            		MakeSound(SOUND_SYS_ERROR);
//               	if(ResetSensorModule() == 0)
//               		L_DisplayROMStr("Module Reset OK ",16,ROW_USER_FUNCTION);
					F_TempCounterStart = SET;
					Temp_Time_Counter = 0;
					while(Temp_Time_Counter < 1);
						F_TempCounterStart = CLR;
//					L_DisplayROMStr("Set Successfully",16,ROW_USER_ENTRY);
					memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
					L_DisplayROMStr("Set Successfully",2,BOOT_MSG3);					
					
					F_TempCounterStart = SET;
					Temp_Time_Counter = 0;
					while(Temp_Time_Counter < 1);
						F_TempCounterStart = CLR;
				}
				else
				{
//					L_DisplayROMStr("Save Fail ..    ",16,ROW_USER_ENTRY);
					memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
					L_DisplayROMStr("Save Fail ..    ",2,BOOT_MSG3);					
//					MakeSound(SOUND_SYS_ERROR);
				}
			}
			else
			{
//				L_DisplayROMStr("Write Fail ..   ",16,ROW_USER_ENTRY);
				memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
				L_DisplayROMStr("Write Fail ..   ",2,BOOT_MSG3);					
//	         MakeSound(SOUND_USER_ERROR);
			}
			DISABLE_BIO_COMM();
		}
		else
		{
			Doorinfo.TemplateSize = tempsz;
//			L_DisplayROMStr("TemplateSz:     ",16,ROW_USER_ENTRY);
//			L_DisplayDecimalInteger(Doorinfo.TemplateSize,11,ROW_USER_ENTRY);
			memset(DisplayTempBuffer,' ',sizeof(DisplayTempBuffer));
			sprintf((char*)DisplayTempBuffer,"%s%3d","TemplateSz:",Doorinfo.TemplateSize);
			L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG2);
			
//			MakeSound(SOUND_USER_ERROR);
			WriteDoorInfoToFlash();
			F_TempCounterStart = SET;
			Temp_Time_Counter = 0;
			while(Temp_Time_Counter < 1);
            	F_TempCounterStart = CLR;
		}
		BUZZER_OFF();
	}
}
#endif

#ifdef SUPPORT_SUPREMA
void ValidateBioEnrollType(WORD enrolltype)
{
	if(enrolltype != SysInfo.BioEnrollType)               //BioEnrollType = 48 and 65 are supported by our unit
	{
		BUZZER_ON();
		ClearBootScreen();		
		if((SysInfo.BioEnrollType == BIO_SINGLE_ENROLL) || (SysInfo.BioEnrollType == BIO_TWO_TEMPLATE_ENROLL))
		{
			ENABLE_BIO_COMM();
			if(WriteSystemParameter(BIO_SYS_ENROLL_TYPE,SysInfo.BioEnrollType) == 0)
			{
				if(SaveBioSystemParameter() == 0)
				{
					SensorBioEnrollType = SysInfo.BioEnrollType;
					sprintf((char*)DisplayTempBuffer,"%s%3d","BEnrolType: ",SysInfo.BioEnrollType);
					L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG1);
//					L_DisplayROMStr("BEnrolType:     ",16,BOOT_MSG2);	// 
//					L_DisplayDecimalInteger(SysInfo.BioEnrollType,11,BOOT_MSG2);
					F_TempCounterStart = SET;
					Temp_Time_Counter = 0;
					while(Temp_Time_Counter < 4);
						F_TempCounterStart = CLR;
					L_DisplayROMStr("Set Successfully",16,BOOT_MSG3);
					F_TempCounterStart = SET;
					Temp_Time_Counter = 0;
					while(Temp_Time_Counter < 1);
						F_TempCounterStart = CLR;
				}
				else
				{
					L_DisplayROMStr("Save Fail ..    ",16,BOOT_MSG3);
				}
			}
			else
			{
				L_DisplayROMStr("Write Fail ..   ",16,BOOT_MSG3);
			}
			DISABLE_BIO_COMM();
		}
		else
		{
			SysInfo.BioEnrollType = enrolltype;
//			L_DisplayROMStr("BEnrolType:     ",16,BOOT_MSG2);
//			L_DisplayDecimalInteger(SysInfo.BioEnrollType,11,BOOT_MSG2);
			sprintf((char*)DisplayTempBuffer,"%s%3d","BEnrolType: ",SysInfo.BioEnrollType);
			L_DisplayROMStr(DisplayTempBuffer,2,BOOT_MSG2);
			WriteSysInfoToFlash();
			F_TempCounterStart = SET;
			Temp_Time_Counter = 0;
			while(Temp_Time_Counter < 4);
            	F_TempCounterStart = CLR;
		}
		BUZZER_OFF();
	}
}
#endif

#ifndef	ENABLE_ETHERNET_OLD
/*** BeginHeader IncSocketTimeOut*/
//void IncSocketTimeOut(void);
/*** EndHeader */
//void IncSocketTimeOut(void)		//ARMF0240
// {
// //	if(SocketStatus == SOCK_ACTIVE)	 //check socket state
// 	//SocketStatus is updated in fnHandleTCP()
// 	if( (Doorinfo.SocketCloseTime != 0) && (SocketStatus == TCP_STATE_SYN_RCVD || SocketStatus == TCP_STATE_ESTABLISHED) )
// 	{
// 		if(SocketTimeOut <= 254)
// 		{
// 			SocketTimeOut++;
// 			if(SocketTimeOut > Doorinfo.SocketCloseTime)
// 			{
// 				SocketTimeOut = 0xFF;
// 				fnTCP_close(Socket_TCP);
// 			}
// 		}
// 	}                              
// }

#endif


//extern int fnUDPListner(USOCKET SocketNr, unsigned char ucEvent, unsigned char *ucIP, unsigned short usPortNr, unsigned char *data, unsigned short usLength)
void ProcessUDPCommand(unsigned short usPortNr,unsigned char *ucIP,unsigned char *data,unsigned short usLength)//ARMF0249
{	
	unsigned short i,F_UDPCommandReceive;
	F_UDPCommandReceive= CLR;
	if(data[0]==STX)
	if((SysInfo.MySlaveNo == (data[1]- CNTRBASEADD) )|| (data[1]== GLOBAL_COMMAND))
	{
		for (i=2;i<usLength;i++)
		if((data[i]=='\n')||(data[i]=='\r'))
		{
			if(sizeof(SBuffer)<=i)
				i = sizeof(SBuffer);
			memcpy((unsigned char *) SBuffer,&data[1],i-1);
			F_UDPCommandReceive= SET;
		}
	}					
	if(F_UDPCommandReceive)
	{
		memcpy(CurrentUDPIP,ucIP,sizeof(CurrentUDPIP));
		HandleSerialCmd(SER_UDP_PORT);
        fnSendUDP(MyUDP_Socket, ucIP, usPortNr, PortObj[SER_UDP_PORT].Buffer, PortObj[SER_UDP_PORT].BufPtr-sizeof(UDP_HEADER), TASK_APPLICATION); // echo back from transmitting IP and port
//		fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE,PortObj[SER_TCPIP_PORT].BufPtr);
	}
}

#ifdef PROCESS_HEARTBEAT
void SendUDPHeartBeat(void)
{
// 	struct TRNX_DATA ptrans;
// 	ptrans.Chnl = 1;
// 	ptrans.Event = EVENT_UDP_HEARTBEAT;
// 	ptrans.CardNo = TotalNosOfTrans;
// 	ptrans.Datetime = Datetime;
//     ptrans.CType = SysInfo.ETH_Port;
// 	ptrans.InputType = Doorinfo.UDPServerPort ;
//	SendUDPToIPPort(&ptrans,SER_UDP_PORT,(char *)&Doorinfo.HeartBeatIP[0],Doorinfo.HBPort);
	SendHBString(SER_UDP_PORT,(char *)&Doorinfo.HeartBeatIP[0],Doorinfo.HBPort);
}
#endif
/**
this function is called after all parameters are readed on respective structures.
this function checks that firmware is upgraded or not
if firmware is upgraded, it will initialise few selected parameters
*/
//void CheckForFirmwareUpgrade(void)//ARMD0447
//{
//	if(check_string(MEM_ADD_BOOT_STRING,BOOT_STRING_COMPLETE,BOOT_STRING_LENGTH))
//	{	//come here if firmware is upgraded
//		SysInfo.BlockKeyboard = 0;
//
//		memcpy(Doorinfo.InternetTestIP,INTERNET_TEST_IP,16); //ARMF0502
//
//		WriteSysInfoToFlash();
//		WriteDoorInfoToFlash();
//		WriteReaderInfoToFlash();
//		memcpy((char *)MEM_ADD_BOOT_STRING,BOOT_STRING_INITDONE,BOOT_STRING_LENGTH);
//	}
//}

void CheckForFirmwareUpgrade(void)//ARMD0447    //ARMD0498		 //ARMF2006
{
unsigned char prev_ver;
	if(check_string(MEM_ADD_BOOT_STRING,BOOT_STRING_COMPLETE,BOOT_STRING_LENGTH))
	{	//come here if firmware is upgraded
		memcpy((char *)MEM_ADD_BOOT_STRING,BOOT_STRING_INITDONE,BOOT_STRING_LENGTH);  //ARMF0517
		SysInfo.BlockKeyboard = 0;
		Doorinfo.SecurityEnDis = 0;
		SysInfo.AuthIP = 0;
		ReadModelInfoFromFlash();							   //ARMF0497
		prev_ver = (unsigned char)ModelInfo.PrevVersionNo;
		
		if((prev_ver < 0x37)||(prev_ver == 0x00)||(prev_ver == 0xFF))
		{
			ModelInfo.PrevVersionNo = 0 ; 					//ARMF2006
			WriteModelInfoToFlash();	
			prev_ver = 0x00;
		}
		
		switch(prev_ver)						 //ARMF2006
		{
			//new parameters will be get added here in case of new firmware version
			//suppose next version 4.0 will be added now,
			//then new parameters that are changed from 3.9 to 4.0 will be get added here to set them default.
			//also add a new case here i.e. 3.9 will be moved here 
			case 0x37:	//version 3.7
				Doorinfo.ServerMACAdress[0] = 0;
				memcpy(Doorinfo.InternetTestIP,INTERNET_TEST_IP,16); 
//				memcpy(Doorinfo.InternetTestIP,"192.168.2.40",16); 	 //for testing only
			break;

			case 0x42:	//version 4.2	
			//no change
//				memcpy(Doorinfo.InternetTestIP,"192.168.2.39",16); 	 //for testing only
			break;

			default:
				Doorinfo.ServerMACAdress[0] = 0;
				memcpy(Doorinfo.InternetTestIP,INTERNET_TEST_IP,16); 
			   	memcpy(SysInfo.LOCAL_IP,PRIMARY_STATIC_IP,16);
				Doorinfo.UDPServerPort = UDP_DEFAULT_PORT;
				SysInfo.ETH_Port = TCP_DEFAULT_PORT;
				memcpy(SysInfo.LOCAL_GATEWAY,PRIMARY_MY_GATEWAY,16);
				memcpy(SysInfo.LOCAL_NETMASK,PRIMARY_NETMASK,16);
				memcpy(SysInfo.LOCAL_DOMAINNAME,PRIMARY_LOCAL_DOMAINNAME,16);
//				memcpy(Doorinfo.InternetTestIP,"192.168.2.30",16); 	 //for testing only
			break;
		}
		

		WriteSysInfoToFlash();
		WriteDoorInfoToFlash();
		WriteReaderInfoToFlash();
	}
}

#ifdef TEST_HW
#ifdef SUPPORT_SPEECHIC
 //   Test Code for Speech IC 
void TestSpeechIC()
while(1)
{
for(i=0;i<=15;i++)
	{
		PlaySoundMsg(i);
		waitX10ms(400);
	
	}	
} 
#endif



void Test_LEDBAR()
{	
	DIR_OUT_LED_BLUE();
	while(1)
	{
		LED_INT_ON();
		//B_LED_BLUE(0);
		waitX10ms(100);	
		waitX10ms(100);	
		LED_INT_OFF();
		//B_LED_BLUE(1);
		waitX10ms(100);	
		waitX10ms(100);	
	}
}	
void Test_GPRS
{	
while(1)
{
unsigned char recbuffer[256];	
	unsigned char sendstr[255];
//	if(temp ==1 )
//temp = SendCommandToModemAndCheck_3("ATE0",5,recbuffer,15,"OK");
	while(1)
	{
		TransmitStrToPC("AT");
		DisableECHO();
		waitX10ms(200);	
			temp = ChkSignalStrength();
		waitX10ms(200);	
		temp = SendCommandToModemAndCheck_3("AT+QIDEACT",10,recbuffer,20,"OK");
waitX10ms(500);
//		L_DisplayROMStr("DEFINE PDP CONTE",16,ROW_USER_ENTRY);
		sprintf((char*)sendstr,"AT+CGDCONT=1,\"IP\",\"%s\"",(char*)Doorinfo.PDPContext);	//define PDP Context LIVE.VODAFONE.IN
		temp = SendCommandToModemAndCheck_3(sendstr,strlen((char*)sendstr),recbuffer,2,(char*)"OK");
waitX10ms(500);
//		L_DisplayROMStr("START TCP TASK  ",16,ROW_USER_ENTRY);
		sprintf((char*)sendstr,"AT+QIREGAPP=\"%s\",\"%s\",\"%s\"",(char*)Doorinfo.APNType,(char*)Doorinfo.APNUserName,(char*)Doorinfo.APNPassword);	//start task and set apn, username, password	"WWW","",""
		temp = SendCommandToModemAndCheck_3(sendstr,strlen((char*)sendstr),recbuffer,5,(char*)"OK");

waitX10ms(500);
//		L_DisplayROMStr("WIRELESS CONNECT",16,ROW_USER_ENTRY);
		temp = SendCommandToModemAndCheck_3("AT+QIACT",8,recbuffer,5,(char*)"OK");
		waitX10ms(500);
		temp = SendCommandToModemAndCheck("AT+QILOCIP",8,recbuffer,5,NULL);
	}	
 if (F_SerialCommandProxy == 3)
	{
		HandleSerialCmd(MODEM_PORT);	
		F_SerialCommandProxy = CLR;
	}
}	
}
void Test_TouchTFT()
{
	unsigned int tz1,tz2,txRaw,tyRaw;
	{
	// 	DispTouchKeyPad(FORMAT_WELCOME_SCREEN);
		while(1)
	 	{
	// 		HandleTouchScreenKey();  //if key is pressed put key in buffer
			tsReadZ(&tz1, &tz2);
			txRaw = tsReadY();
			tyRaw = tsReadX();    
		}
	}
}


/*==== Already defined in protocol.c
void TestTFT(void)
{
//  	{//touch screen testing.
// 		//  touch screen testing.
		TS_XP_FUNC_GPIO();
		TS_YM_FUNC_GPIO();
		TS_XM_FUNC_GPIO();
		TS_YP_FUNC_GPIO();
		DIR_OUT_TS_XP_PIN();
		DIR_OUT_TS_YM_PIN();
		DIR_OUT_TS_XM_PIN();
		DIR_OUT_TS_YP_PIN();
 		while(1)
 		{

			tsReadZ(&n1,&n2); //yp,xm when xp=1,ym=0
			n3=tsReadX();
			n4=tsReadY();
// 			B_TS_XP(0);
// 			B_TS_YM(0);
// 			B_TS_XM(0);
// 			B_TS_YP(0);
// 			
// 			sendudp += 2;
// 			sendudp |= 2;
// 			
// 			B_TS_XP(1);
// 			B_TS_YM(1);
// 			B_TS_XM(1);
// 			B_TS_YP(1);
 		}
 	}	

*/				

#endif


