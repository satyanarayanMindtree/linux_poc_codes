
#include "DriverSpeech_IC.h"
#include  "HW_armNGBiosmart1_0.h"

extern char F_TempCounterStart,Temp_Time_Counter;

void InitSoundIC(void) //hw pin driver
{	
	DIR_IO_SPEECH();
	
	SOUND_SET_CS();	
	SOUND_SET_SCK();
	SOUND_SET_DOUT();

	SOUND_CLR_CS();
	SOUND_CLR_SCK();
	SOUND_CLR_DOUT();
	
	DIR_SPEAKER_PIN();
	
	SET_SPEKER_BUSY();
	SET_SPEKER_FULL();

}

void SoundDelay(unsigned int count)
{
	for(;count>0;--count)
	{
		__nop();
	}
}
void PlaySoundMsg(unsigned char SoundNum)
{
	InitSoundIC();
	SendSerialCmd2(0x55,SoundNum);
}

void waitX10ms(unsigned int i)
{
#ifdef SUPPORT_SPEECHIC			
	SoundDelay_10 = 0;
	while(SoundDelay_10<i)
	{}	
#endif		
}

void SendSerialByte(unsigned char byte)   //hw pin driver
{
unsigned char i=0;
	for(i=0;i<8;++i)
	{
		if(byte & (unsigned char)0x01<<i)   //send LSB first
		{
			SOUND_SET_DOUT();
			SoundDelay(8);//100ns
		}
		else
		{
			SOUND_CLR_DOUT();
			SoundDelay(8);//100ns
		}
		SOUND_SET_SCK();
//		SoundDelay(80);//1usec
		SoundDelay(74);//1usec
		SOUND_CLR_SCK();
		SoundDelay(66);//1usec// 74-8 =66
	}
}
void SendSerialCmd1(unsigned char cmd)   //hw pin driver
{
	SOUND_SET_CS();

	SoundDelay(8);//100ns
	SendSerialByte(cmd); 
	SoundDelay(8);//100ns
	SOUND_CLR_CS();
	SoundDelay(8);//100ns
	SET_SPEKER_FULL();
	SoundDelay(100);
	SET_SPEKER_BUSY();
//	SoundDelay(18000);//300usec  
	SoundDelay(27816);//300usec  
}
void SendSerialCmd2(unsigned char cmd,unsigned char dat)   //hw pin driver
{
	SOUND_SET_CS();	
	SoundDelay(8);//100ns
// 	SendSerialByte(cmd); 
// 	SendSerialByte(dat);
	SoundDelay(8);//100ns
//	SOUND_CLR_CS();
//	SoundDelay(8);//100ns
//	SOUND_CLR_CS();
// 	SET_SPEKER_FULL();
// 	SoundDelay(26600);
// 	SET_SPEKER_BUSY(); 
//	SoundDelay(180);//300usec  
//	SoundDelay(27816);//300usec  
//	SOUND_SET_CS();
	SendSerialByte(0x71);
	SendSerialByte(0x11);
	SOUND_SET_CS();
	SoundDelay(180);//300usec
	
	SOUND_SET_CS();	
	SoundDelay(18);//100ns
	SendSerialByte(0x71);
	SendSerialByte(dat);	
	SOUND_CLR_CS();
	SoundDelay(180);//300usec
	while(FIO2PIN&PIN_SPEAKER_FULL != PIN_SPEAKER_FULL) //  wait for full become High 
	{
		F_TempCounterStart = 1;
	 	Temp_Time_Counter = 0;
	 	if(Temp_Time_Counter < 2);
	 		{
				F_TempCounterStart = 0;		
				break;		
			}
	}
	
	SOUND_SET_CS();	// Snd_Cmd_PUP2
	SoundDelay(20);//100ns	
	SendSerialByte(0x8D);
	SOUND_CLR_CS();
	SoundDelay(180);//300usec  
	FIO2MASK = 0xFFFFFE7F; 
	while((FIO2PIN & PIN_SPEAKER_FULL) != 0x00000000)//  wait for full become low 
	{
		F_TempCounterStart = 1;
	 	Temp_Time_Counter = 0;
	 	if(Temp_Time_Counter < 2);
	 		{
				F_TempCounterStart = 0;		
				break;		
			}
	}		
	while((FIO2PIN & PIN_SPEAKER_BUSY) == 0x00000000)//  wait for Busy become low 
	{
		F_TempCounterStart = 1;
	 	Temp_Time_Counter = 0;
	 	if(Temp_Time_Counter < 2);
	 		{
				F_TempCounterStart = 0;		
				break;		
			}
	}		
	FIO2MASK = 0; 
	
// 	F_TempCounterStart = 1;
// 	Temp_Time_Counter = 0;
// 	while(Temp_Time_Counter < 2);
// 			F_TempCounterStart = 0;	
// 	SOUND_SET_CS();	// Snd_Cmd_PUP2 //DisableSound
// 	SoundDelay(20);//100ns	
// 	SendSerialByte(0xA9);
	SOUND_CLR_CS();
	SoundDelay(26600);//300usec
}

