/*****************************************************************************
 *   extint.h:  Header file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.13  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __EXTINT_H 
#define __EXTINT_H

#define EINT0		0x00000001
#define EINT1		0x00000002
#define EINT2		0x00000004
#define EINT3		0x00000008

#define EINT0_EDGE	0x00000001
#define EINT1_EDGE	0x00000002
#define EINT2_EDGE	0x00000004
#define EINT3_EDGE	0x00000008

#define EINT0_RISING	0x00000001
#define EINT1_RISING	0x00000002
#define EINT2_RISING	0x00000004
#define EINT3_RISING	0x00000008

extern void EINT0_Handler(void) __irq;
extern void EINT1_Handler(void) __irq;
extern void EINT2_Handler(void) __irq;
extern void EINT3_Handler(void) __irq;
extern DWORD EINTInit(void);

#endif 

#define WEIGAND_TIMER_HNDLx(X)		{  				\
	if(ReaderData[X].F_WeigandStarted)				\
	{ 												\
		ReaderData[X].WeigandTimeOut ++;      		\
		if(ReaderData[X].WeigandTimeOut >= 10) 		\
		{                              				\
			ReaderData[X].F_WeigandStarted = CLR;   \
			ReaderData[X].F_WeigandInterrupt = SET; \
		}                             				\
	}                                				\
}

// We have created macro for all interrupt and it uses ## to pass number in variable.
// this will help same code for all readers but still different variables
#define WEIGAND_INTERRUPT_HNDLx(X,WEIDATA)		{  									\
	if(!ReaderData[X].F_WeigandStarted)												\
	{  																				\
		ReaderData[X].WeigandData = 0;              								\
		ReaderData[X].WeigandExData = 0;            								\
		ReaderData[X].F_WeigandStarted = SET;       								\
		ReaderData[X].WCount = 0;                   								\
		ReaderData[X].WeigandTimeOut = 0;           								\
	}                                   											\
	ReaderData[X].WCount ++;                       									\
	if(WEIDATA)                        												\
	{                                   											\
		if(ReaderData[X].WCount >= 33)               								\
		{                                											\
			ReaderData[X].WeigandExData  = ReaderData[X].WeigandExData * 2;			\
			ReaderData[X].WeigandExData = ReaderData[X].WeigandExData | 0x0000001;	\
		}                                                  							\
		else                                               							\
		{                                                  							\
			ReaderData[X].WeigandData  = ReaderData[X].WeigandData * 2;            	\
			ReaderData[X].WeigandData = ReaderData[X].WeigandData | 0x0000001;     	\
		}                                                  							\
	}                                                     							\
	else                                                  							\
	{                                                     							\
		if(ReaderData[X].WCount >= 33)                                				\
			ReaderData[X].WeigandExData  = ReaderData[X].WeigandExData * 2;         \
		else                                               							\
			ReaderData[X].WeigandData = ReaderData[X].WeigandData * 2;            	\
	}                                                     							\
}


#define B_WINT1		((FIO2PIN >> 10) & 0x1)			//P2.10 = EINT0
#define B_WINT2		((FIO2PIN >> 11) & 0x1)			//P2.11	= EINT1

#ifndef HARDWARE_SI065
	 #define B_W1D1		((FIO2PIN >> 12) & 0x1)			//P2.12	= EINT2
 	#define B_W2D1		((FIO2PIN >> 13) & 0x1)			//P2.13	= EINT3
#else
	#define B_W1D1		((FIO0PIN >> 19) & 0x1)			//P0.19	= wiegand data pin in SI065
	#define B_W2D1		((FIO0PIN >> 20) & 0x1)			//P0.20	= 

	#define P0_19_WOUTD0	0x00080000					
	#define P0_20_WOUTD1	0x00100000					
	#define DIR_WEIGAND_READER_PORT()	{FIO0DIR |= P0_19_WOUTD0; FIO0DIR |= P0_20_WOUTD1;}

#endif
extern unsigned char WCount;
extern unsigned int ParityErrCount;

#ifdef MAGNETIC_READER_SUPPORT
extern unsigned long MAGFacility1,MAGFacility2;
#endif

extern void WeiProcessInit(void);
extern void CheckPinProxTimeout(void);
extern void PinProxOneSecTimer(void);
extern CARDNO_DATA_STORAGE_TYPE HandleWeigandRawCard(unsigned char rdrno);
extern void ProcessRecCarddata(unsigned char rdrno, unsigned long tmpcard);
extern unsigned char CheckNoOfOneInInt(unsigned int padata);
extern char Check35BitEvenParity(unsigned long padata);
extern char Check35BitOddParity1(unsigned long padata, unsigned char padata1);
extern char Check35BitOddParity2(unsigned long padata, unsigned char padata1);



/* end __EXTINT_H */
/****************************************************************************
**                            End Of File
*****************************************************************************/
