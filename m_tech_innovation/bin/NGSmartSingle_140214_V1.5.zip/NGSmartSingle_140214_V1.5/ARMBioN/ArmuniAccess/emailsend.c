#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "config.h"
#include "version.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"	
#include "serial.h"
#include "Access.h"
#include "userintf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "smartcard.h"
#include "CardMgmt.h"
#include "memory.h"
#include "rdcont.h"
#include "memmap.h"
#include "portdef.h"	
#include "rdpoll.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif
#include "spi.h"
#include "portlcd.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"

#include"App.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/application_lcd.h"                                             // {46} LCD tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/ADC_Timers.h"                                                  // {46} ADC and timer tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/iic_tests.h"                                                   // {46} iic tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/Port_Interrupts.h"                                             // {46} port interrupt tests
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/can_tests.h" 
#include "emailsend.h"
#include "IOEventMgmt.h"
/*

SMTP HELP from Pankaj
1) To Enable SMTP which is used for email send we have to enable all #define USE_SMTP
2) We also have to enable USE_SMTP_AUTHENTICATION so that we can use authentication in email send
I have observed for certain email servier it can work without authentication but we need to enable
same as for few server it may not accept authentication
3) I have tested this with mail.cian.co email server
4) In this we have used DNS server to get ip address of mail.cian.co
5) When we start email send it 1st gets IP address from DNS and then fires email send functionality 
	I feel this needs to be modified which we will do over the time.
6) To test if there are any issues we should keep break point at following 
	fnEmailTest --> switch statement.
	Also to know what response we have received form email server keep break point at 
	smtp.c  ==> fnSMTPListener
	What data we have sent to email server check at 
	smtp.c  ==> fnRegenerate ==> fnSendTCP

I have observed authentication error in certain case... 
Or issue with DNS name resolution.. to check DNS name resolution please check following .
	dns.c ==> fnDNSListner
	********** NOIE **********
7) I have also observed that if email domain name ( smartisystems.com ) is used then we 
send email as controller00001@smartisystems.com and in this case if we send email to  
any  smartisystems.com email address as receive email address then smart I domain do not 
accept email from controller00001@smartisystems.com as this is not created on smart i 
email account.

So better to use domain name other than to email address domain name else we should 
create email account for all controller on email server.


8) Rt now we do not send date on which email is send so on some of mail client we will not be able to see
date


SMTP Raw send details
1) use putty and connect to port 25 and mail.smartisystems.com\
	We get response as ==>  220 smtp.example.com ESMTP Postfix

2) Type following 
	HELO mail.smartisystems.com
We get response as ==> Hello relay.example.org, I am glad to meet you

3) Authentication 

	AUTH LOGIN
We get following ===> 334 VXNlcm5hbWU6

Type user name in encripted format 

	cGFua2FqLnphbndhckBzbWFydGlzeXN0ZW1zLmNvbQ==

We get following ===> 334 UGFzc3dvcmQ6
Type password name in encripted format 	
	UGFua2FqMDA3

We get following ===> 235 Authenticated

4)  Send following 

	MAIL FROM:<pankaj.zanwar@smartisystems.com>

We get response as   ==> S: 250 Ok

4) Type following 

	RCPT TO:<pankaj.zanwar@smartisystems.com>
	RCPT TO:<pankaj.zanwar@cian.co>
	RCPT TO:<pankaj.zanwar@gmail.com>

Type enter two times 

5) Send the data in following format 

	DATA
We get following    ==> S: 354 End data with <CR><LF>.<CR><LF>

Type following 

From: "Pankaj Zanwar" <pankaj.zanwar@cian.co>
To: "Pankaj" <pankaj.zanwar@smartisystems.com>
Cc: pankaj.zanwar@gmail.com
Date: Tue, 15 July 2011 16:02:43 -0500
Subject: Test message From Pankaj

Hello Alice.
This is a test message with 5 header fields and 4 lines in the message body.
Your friend,
Bob
.


We get response as follows   ===> S: 250 Ok: queued as 12345

6) Type 
	QUIT
	We get following ==> 221 Bye

===============

For base 64 encoding use following link 
http://www.opinionatedgeek.com/dotnet/tools/base64encode/

Email Server:: mail.cian.co
Email auth address :: test@cian.co
Email auth Password :: test1234

*/
#ifdef	ENABLE_EMAIL_SEND

#ifdef USE_SMTP
    CHAR cEmailAdd[41] = DEFAULT_DESTINATION_EMAIL_ADDRESS;
#endif

char FromEmail[100],ToEmail[50],SubjectEmail[100];


#ifdef USE_SMTP
    static const CHAR *fnEmailTest(unsigned char ucEvent, unsigned short *usData); // e-mail call back handler
    #ifdef USE_DNS
        static void fnDNSListner(unsigned char ucEvent, unsigned char *ptrIP);
    #endif
#endif



#if defined USE_SMTP
    static const CHAR cUserDomain[]   = OUR_USER_DOMAIN;
//    static const CHAR cSubject[]      = EMAIL_SUBJECT;
//    static const CHAR cEmailText[]    = EMAIL_CONTENT;
    #ifndef SMTP_PARAMETERS
    	static const CHAR cSender[]       = SENDERS_EMAIL_ADDRESS;
        static const CHAR cUserName[]     = SMTP_ACCOUNT_NAME;
        static const CHAR cUserPassword[] = SMTP_PASSWORD;
        #ifdef USE_DNS
            const CHAR cSMTP_provider[]   = SMTP_PROVIDER_ADDRESS;       // our smtp provider's server
        #endif
    #endif
#endif


#ifdef USE_SMTP
    #ifdef USE_DNS
        unsigned char ucSMTP_server[] = {0,0,0,0};                       // IP address or smtp server after it has been resolved
        static unsigned char ucSMTP_Retry;                               // DNS retry counter
    #else
        unsigned char ucSMTP_server[] = SMTP_PROVIDER_IP_ADDRESS;
    #endif
#endif



#define MAX_EMAIL_BUFFER		5
#define EMAIL_AUTH_ADDRESS		0
#define EMAIL_AUTH_PASSWORD		1
#define EMAIL_AUTH_SERVER		2
#define EMAIL_SEND_DOMAIN		3
#define EMAIL_SEND_ADDRESS		4
//4,5 reserved for future use
#define EMAIL_TO_ADDRESS		6

// Please specify the email address and password of smart i systems

#define DEFAULT_AUTH_EMAIL_ADDRESS	"test@cian.co"
//encripted data --->   dGVzdEBjaWFuLmNv
#define DEFAULT_AUTH_EMAIL_PASSWORD	"test1234"
//encripted data --->   dGVzdDEyMzQ=
#define DEFAULT_SEND_EMAIL_ADDRESS	"pankaj.zanwar@gmail.com"
#define DEFAULT_DOMAINNAME			"smartisystems.com"

#define AUTH_EMAIL_ADDRESS   		EmailAd[EMAIL_AUTH_ADDRESS].Adress
#define AUTH_EMAIL_PASSWORD      	EmailAd[EMAIL_AUTH_PASSWORD].Adress
#define AUTH_EMAIL_SERVER      		EmailAd[EMAIL_AUTH_SERVER].Adress
#define AUTH_EMAIL_DOMAIN      		EmailAd[EMAIL_SEND_DOMAIN].Adress
#define TO_EMAIL_ADDRESS			EmailAd[EMAIL_TO_ADDRESS].Adress
#define SEND_EMAIL_ADDRESS			EmailAd[EMAIL_SEND_ADDRESS].Adress

struct EMAIL_BUFFER{
	unsigned int TransNo;
   unsigned char Type;
   unsigned char Status;
};
struct EMAIL_BUFFER EmailBuffer[MAX_EMAIL_BUFFER];
unsigned char EmailRdPtr,EmailWrPtr;




#define EMAIL_SEND_START		0			// indicatd we have to send this email
#define EMAIL_SEND_REQUESTED	1			// indicated we have started email send
#define EMAIL_RETRY_FAIL      	4			// indicated we tries 3 times and not not able to send email so discard
#define EMAIL_SEND_SUCCESS		5			//Successfullt send email


#define EMAIL_G_STATUS_IDLE		0
#define EMAIL_G_STATUS_START	1
#define EMAIL_G_STATUS_START1	2
#define EMAIL_G_STATUS_START2	3
#define EMAIL_G_STATUS_START3	4
#define EMAIL_G_STATUS_SUCCESS	5
#define EMAIL_G_STATUS_FAIL		6
#define EMAIL_G_STATUS_RETRY	7


#define EMAIL_SEND_DELAY_TIME	10			// This is delay between two emails

unsigned char EmailSendTimer,F_EmailSendProgress;

unsigned char EmailGStatus;		// Global Email status

unsigned char EmailSendFromBuffer(void);
unsigned int EmailTransactionSend(struct TRNX_DATA *trans,unsigned int nooftrans,unsigned char *emailstr);
extern void smtp_sendmail( char *ToEmail,  char *FromEmail,  char *SubjectEmail, __packed unsigned char *buffer);
extern __packed unsigned short IOEventInfo[MAX_EVENT_IO+1];
extern __packed unsigned short IOEventInfo2[MAX_EVENT_IO+1];

//#define GET_EMAIL_ID(X,Y)		X=6
struct TRNX_DATA emailtrans;

/*** endheader */

/*** BeginHeader SendEmail*/
int SendEmail(unsigned char *sendemaildata);
/*** EndHeader */
int SendEmail(unsigned char *sendemaildata)
{

	return(1);
}

/*** BeginHeader EmailInitialise*/
extern void EmailInitialise(void);
/*** EndHeader */
extern void EmailInitialise(void)
{
	EmailGStatus = EMAIL_G_STATUS_IDLE;
	F_EmailSendProgress = CLR;
	ReadEmailAddFromFlash();	
   	sprintf(FromEmail,"controller%05d@%s",Doorinfo.ControllerNo,AUTH_EMAIL_DOMAIN);//this creats problem if AUTH_EMAIL_DOMAIN is not initialised
   	strcpy(ToEmail,DEFAULT_SEND_EMAIL_ADDRESS );
	strncpy(ToEmail,EmailAd[6].Adress,sizeof(EmailAd[6].Adress));
   	sprintf(SubjectEmail,"Alert from controller %05d ",Doorinfo.ControllerNo); //,Doorinfo.ControllerNo);
   EmailRdPtr=EmailWrPtr=0;
}


/*** BeginHeader EmailSendMainLoop*/
void EmailSendMainLoop(void);
/*** EndHeader */
void EmailSendMainLoop(void)
{
//	int status;
  	if(Doorinfo.EnableEmail!=1)
   		return;		
	if(F_EmailSendProgress==SET)
   	{
   		if(EMAIL_G_STATUS_SUCCESS==EmailGStatus)
		{
			EmailBuffer[EmailRdPtr].Status = EMAIL_SEND_SUCCESS;
	        F_EmailSendProgress = CLR;
			EmailSendFromBuffer();
			EmailSendTimer = EMAIL_SEND_DELAY_TIME; // On success send next email immediately do not wait

		}
		else if(EMAIL_G_STATUS_FAIL==EmailGStatus)
		{
			EmailBuffer[EmailRdPtr].Status = EMAIL_RETRY_FAIL;
        	F_EmailSendProgress = CLR;
			EmailSendFromBuffer();
		}
		if(EMAIL_G_STATUS_START==EmailGStatus)
   		{
			if(EmailSendTimer>=EMAIL_SEND_DELAY_TIME)
   			{
				// Indicates that we are not able to get DNS name and email is not moving so restart email send functionality
        		F_EmailSendProgress = CLR;					
				EmailBuffer[EmailRdPtr].Status = EMAIL_RETRY_FAIL;
			}
		}
	}
   else
	   EmailSendFromBuffer();						
}




extern unsigned char EmailSendFromBuffer(void)
{

	if(Doorinfo.EnableEmail!=1)
   		return(0);
	if(EmailRdPtr==EmailWrPtr)
   		return(0);
   	if(EmailSendTimer<EMAIL_SEND_DELAY_TIME)
   		return(0);
   	if(EmailBuffer[EmailRdPtr].Status!=EMAIL_SEND_START)
	{
   		if(EmailBuffer[EmailRdPtr].Status != EMAIL_SEND_SUCCESS)
      	{
	   		EmailBuffer[EmailRdPtr].Status ++;
     	}
   		if((EmailBuffer[EmailRdPtr].Status == EMAIL_RETRY_FAIL)||(EmailBuffer[EmailRdPtr].Status == EMAIL_SEND_SUCCESS))
   		{
      		EmailRdPtr++;
         	if(EmailRdPtr>=MAX_EMAIL_BUFFER)
         		EmailRdPtr=0;
			if(EmailRdPtr==EmailWrPtr)
	   			return(0);
      	}
	}
	if(EmailBuffer[EmailRdPtr].Status==EMAIL_SEND_START)
		EmailBuffer[EmailRdPtr].Status = EMAIL_SEND_REQUESTED;
	F_EmailSendProgress=SET;
	EmailSendTimer =0;
	EmailGStatus = EMAIL_G_STATUS_START;
    ReadTrans(&emailtrans,EmailBuffer[EmailRdPtr].TransNo);	   //ReadTemplate
	EmailTransactionSend(&emailtrans,0,"");
	fnSendEmail(0);
	return(1);
}



/*** BeginHeader EmailAddToBuffer*/
unsigned char EmailAddToBuffer(unsigned inttrans,unsigned char type);
/*** EndHeader */
unsigned char EmailAddToBuffer(unsigned inttrans,unsigned char type)
{
	if(Doorinfo.EnableEmail!=1)
   	return(0);
	EmailBuffer[EmailWrPtr].TransNo=inttrans;
	EmailBuffer[EmailWrPtr].Type=type;
    EmailBuffer[EmailWrPtr].Status=EMAIL_SEND_START;
	EmailWrPtr++;
    if(EmailWrPtr>= MAX_EMAIL_BUFFER)
   		EmailWrPtr=0;
   	if(EmailWrPtr==EmailRdPtr)
   	{
   		EmailRdPtr++ ;
	   	if(EmailRdPtr>= MAX_EMAIL_BUFFER)
	      	EmailRdPtr=0;
	}
	return(1);
}


extern unsigned int EmailTransactionSend(struct TRNX_DATA *trans,unsigned int nooftrans,unsigned char *emailstr)
{
unsigned char port,emailid,evno;
unsigned char sendstr[20];
   port = SER_EMAIL_PORT;

	if(Doorinfo.EnableEmail!=1)
   		return(0);
//	if(F_EmailSendProgress==SET)
//   	return(-1);
#ifdef USE_SMTP_AUTH
	smtp_setauth (AUTH_EMAIL_ADDRESS,AUTH_EMAIL_PASSWORD);
#endif

#if _USER
   	smtp_setserver(SMTP_SERVER);
#endif
 		sprintf(FromEmail,"controller%05d@%s",Doorinfo.ControllerNo,AUTH_EMAIL_DOMAIN);
         GET_EMAIL_ID(emailid,trans->Event);
		if(EMAIL_TO_ADDRESS>=emailid)
         	emailid=EMAIL_TO_ADDRESS;
   		memcpy(ToEmail,EmailAd[emailid].Adress,sizeof(EmailAd[emailid].Adress));
		PortObj[SER_EMAIL_PORT].BufPtr=0;
		TransmitStrToX(emailstr,port);
		TransmitStrToX("\n ===============================================",port);
/*		if(GetMessageFromFlash(ERROR_MESSAGE_BASE+trans->Event,sendstr)==0)
		{
				TransmitStrToX("\n Event: ",port);
				TransmitStrToX(sendstr,port);
         } 
		 */
         TransmitStrToX("\n Event: ",port);
         evno = trans->Event;
         if((evno >= 0) && (evno < MAX_ERROR_MSGS))
         	evno = ERROR_MESSAGE_BASE + evno;
         else if((evno >= 50) && (evno <= 55))
         	evno = 45 + evno;                //to read event msg from 95 to 100 msg id

       	if(GetMessageFromFlash(evno,sendstr) == 0)
        	TransmitStrToX(sendstr,port);
		TransmitStrToX("\n ===============================================",port);
		TransmitStrToX("\n Card No : ",port);
	    SendDecimalLongToX(trans->CardNo,port);
		TransmitStrToX("\n Door No : ",port);
	    SendDecimalToPC3CharToX(trans->Chnl,port);
		TransmitStrToX("\n Date Time : ",port);
	    SendDecimalToX(trans->Datetime.Time.Hour,port);
	    TransmitCharToX(':',port);
	    SendDecimalToX(trans->Datetime.Time.Min,port);
 	    TransmitCharToX(':',port);
		SendDecimalToX(trans->Datetime.Time.Secs,port);
  		TransmitCharToX(' ',port);
  		SendDecimalToX(trans->Datetime.Date.Day,port);
  		TransmitCharToX('/',port);
	  	SendDecimalToX(trans->Datetime.Date.Month,port);
	  	TransmitCharToX('/',port);
	  	SendDecimalToX(trans->Datetime.Date.Year,port);
		TransmitStrToX("\n Event Type : ",port);
		SendDecimalToPC3CharToX(trans->Event,port);
		TransmitStrToX("\n Controller No : ",port);
 		SendDecimalIntToX(Doorinfo.ControllerNo,port);
  		TransmitCharToX('\n',port);
		TransmitStrToX("\n ===============================================\n",port);
	   	TransmitReplyStartToX(port);
	 	TransmitCharToX('E',port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(2,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(trans->Chnl,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(trans->Event,port);
		TransmitCharToX(',',port);
		SendDecimalLongToX(trans->CardNo,port);
		TransmitCharToX(',',port);
		SendDecimalToX(trans->Datetime.Time.Hour,port);
		SendDecimalToX(trans->Datetime.Time.Min,port);
		SendDecimalToX(trans->Datetime.Time.Secs,port);
		TransmitCharToX(',',port);
		SendDecimalToX(trans->Datetime.Date.Day,port);
		SendDecimalToX(trans->Datetime.Date.Month,port);
		SendDecimalToX(trans->Datetime.Date.Year,port);
		TransmitCharToX(',',port);
		SendDecimalLongToX6digit(TotalNosOfTrans+1,port);		// As we send alert before saving transaction so we have to increment by one
		TransmitCharToX(',',port);          //PANKAJ
		SendDecimalLongToX6digit(TransWritePtr,port);
		TransmitCharToX(',',port);
#ifdef TRANS_EXTRA_DATA
		SendDecimalToPC3CharToX(trans->CType,port);
		TransmitCharToX(',',port);
		SendDecimalToPC3CharToX(trans->InputType,port);
		TransmitCharToX(',',port);
#else
		TransmitCharToX('0',port);
		TransmitCharToX(',',port);
		TransmitCharToX('0',port);
		TransmitCharToX(',',port);
#endif
		SendDecimalIntToX(Doorinfo.ControllerNo,port);
		TransmitCharToX(',',port);
		TransmitCheckSumX(port);
		TransmitCharToX(',',port);
		TransmitCharToX(TERMINATOR,port);
		TransmitCharToX('\0',port);
		TransmitCharToX('\0',port);
		//smtp_sendmail(ToEmail, FromEmail, SubjectEmail,PortObj[SER_EMAIL_PORT].Buffer);
		F_EmailSendProgress = SET;
	   	return(0);
}


/*
Following is called in 1 sec loop
*/

extern void EmailOneSecLoop(void)
{
	if(EmailSendTimer < EMAIL_SEND_DELAY_TIME)
	    EmailSendTimer++;
	EmailSendMainLoop();
}

#ifdef USE_SMTP
extern void fnSendEmail(int iRepeat)
{
    #ifdef USE_DNS
    if (!uMemcmp(ucSMTP_server, cucNullMACIP, IPV4_LENGTH)) {
    #ifdef SMTP_PARAMETERS
        fnResolveHostName((CHAR *)temp_pars->temp_parameters.ucSMTP_server, fnDNSListner); // resolve SMTP server address so that we can send
    #else
        fnResolveHostName(cSMTP_provider, fnDNSListner);                 // resolve SMTP server address so that we can send
    #endif
    }
    else {
        fnConnectSMTP(ucSMTP_server, (unsigned char)(temp_pars->temp_parameters.usServers & SMTP_LOGIN), fnEmailTest); // initiate Email transmission
    }
    if (!iRepeat) {
        ucSMTP_Retry = 2;
    }
    #else
    fnConnectSMTP(ucSMTP_server, (unsigned char)(temp_pars->temp_parameters.ucServers & SMTP_LOGIN), fnEmailTest); // initiate Email transmission
    #endif
}

// Email call back handler
//
static const CHAR *fnEmailTest(unsigned char ucEvent, unsigned short *usData)
{				
    switch (ucEvent) {
    case SMTP_GET_DOMAIN:
		EmailGStatus = EMAIL_G_STATUS_START1;
        return cUserDomain;

#ifdef USE_SMTP_AUTHENTICATION
    case SMTP_USER_NAME:
//        return cUserName;
        return EmailAd[EMAIL_AUTH_ADDRESS].Adress;

    case SMTP_USER_PASS:
//        return cUserPassword;
        return EmailAd[EMAIL_AUTH_PASSWORD].Adress;
//        #endif
#endif

    case SMTP_GET_SENDER:
	EmailGStatus = EMAIL_G_STATUS_START1;
    /*#ifndef SMTP_PARAMETERS
        return cSender;
    #else
        return (CHAR *)temp_pars->temp_parameters.ucSMTP_user_email;
    #endif*/
	  return FromEmail;

    case SMTP_GET_DESTINATION:
//        return cEmailAdd;
	  return ToEmail;

    case SMTP_GET_SUBJECT:
//        return cSubject;
		return SubjectEmail;

    case SMTP_SEND_MESSAGE:
/*        {
        unsigned short usEmailPosition = *usData;
        if (usEmailPosition >= (sizeof(cEmailText) - 1)) {               // here we can send our Email message
            *usData = 0;
            return 0;                                                    // Email has been completely sent, inform that there is no more
        }
        else {
            *usData = (sizeof(cEmailText) - 1) - usEmailPosition;        // remaining length
        }
        return (const CHAR *)&cEmailText[usEmailPosition];               // give a pointer to the next part of message
        }
*/
		EmailGStatus = EMAIL_G_STATUS_START2;
      {
	  	unsigned short usEmailPosition = *usData;
        if (usEmailPosition >= PortObj[SER_EMAIL_PORT].BufPtr -1) {               // here we can send our Email message
            *usData = 0;
            return 0;                                                    // Email has been completely sent, inform that there is no more
        }
        else {
            *usData = PortObj[SER_EMAIL_PORT].BufPtr -1 - usEmailPosition;        // remaining length
        }
        return (const CHAR *)&PortObj[SER_EMAIL_PORT].Buffer[usEmailPosition];
	  }
    case SMTP_MAIL_SUCCESSFULLY_SENT:        
		if(( EmailGStatus == EMAIL_G_STATUS_START2)||( EmailGStatus == EMAIL_G_STATUS_SUCCESS))                         // Our email has been successfully sent!!
			EmailGStatus = EMAIL_G_STATUS_SUCCESS;
		else
			EmailGStatus = EMAIL_G_STATUS_FAIL;
        break;

  //case ERROR_SMTP_LOGIN_FAILED:                                        // user name and password incorrect
  //case ERROR_SMTP_LOGIN_NOT_SUPPORTED:                                 // we are trying to use login but the server doesn't support it
  //case ERROR_SMTP_POLICY_REJECT:                                       // we are not using login but the server insists on it
  //case ERROR_SMTP_TIMEOUT:                                             // connection timed out
    default:                                                             // An error has occurred
    #ifdef USE_DNS
		EmailGStatus = EMAIL_G_STATUS_RETRY;
        uMemcpy(ucSMTP_server, cucNullMACIP, IPV4_LENGTH);               // we reset the IP address since it may be that the server has changed it address
        if (ucSMTP_Retry) {
            ucSMTP_Retry--;
            fnSendEmail(1);                                              // retry
        }
		else
			EmailGStatus = EMAIL_G_STATUS_FAIL;
			
    #endif
        break;
    }
    return 0;
}
#endif 

#if defined (USE_SMTP) && defined (USE_DNS)
static void fnDNSListner(unsigned char ucEvent, unsigned char *ptrIP)
{
    switch (ucEvent) {
    case DNS_EVENT_SUCCESS:
    #ifdef USE_SMTP
        uMemcpy(ucSMTP_server, ptrIP, IPV4_LENGTH);                      // save the IP address which has just been resolved
        fnConnectSMTP(ucSMTP_server, (unsigned char)(temp_pars->temp_parameters.usServers & SMTP_LOGIN), fnEmailTest); // initiate Email transmission
    #endif
        break;

    default:                                                             // DNS error message
        break;
    }
}
#endif

/*
extern void smtp_sendmail( char *ToEmail,  char *FromEmail,  char *SubjectEmail, __packed unsigned char *buffer)
{

}
*/

extern unsigned char WriteEmailAddToFlash(void)
{
    MainMem_BuffWrt(0,1,(BYTE *)&EmailAd[0],sizeof(EmailAd) );
	BuffWrt_MainMem(FL_EMAIL_ADD_INFO,1);
    MsgPrint(MSG_MEM,0," CWriteEmailAddToFlash \n");
		return(0);

}
/*--------------------------------------------------------------------------*/


extern unsigned char ReadEmailAddFromFlash(void)
{
//	unsigned char i,*infoptr;   	
 	MainMem_ReadPage(FL_EMAIL_ADD_INFO,0,(BYTE *)&EmailAd[0],sizeof(EmailAd));
	MsgPrint(MSG_MEM,0,"ReadEmailAddFromFlash ");
	return(0);
}

#endif	//#ifdef	ENABLE_EMAIL_SEND





