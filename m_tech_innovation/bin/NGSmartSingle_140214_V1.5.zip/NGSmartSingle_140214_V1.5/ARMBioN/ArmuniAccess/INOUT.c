/*****************************************************************************
 *   inout.c:  I/O module file for armaccess for input out defination and read
 *
 *   History
 *   2008.12.3  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/

#include "LPC23xx.h"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "INOUT.h"



// void InitialiseIOOLD( void)
// {

// //PORT 0 PINS USED 31 TO 16 :0001 0000 0010 0000 0000 0000 0011 1100 
//  	FIO0DIR |= 0x08000000; 

// //port 4 = 0011 0000 0000 0000 0000 0000 0000 0000	
// //28,29 ARE USED as output
// 	FIO4DIR |= 0x30000000;    
// //port 2 = 0000 0000 0000 0000 0011 1001 1111 1100	
// //Input  output 2,3,4,5,6,7.
// 	FIO2DIR |= 0x000000FC; 
// //port 3 = 0000 0110 0000 0000 0000 0000 0000 0000	
// //25,26	ARE USED as  input output
// 	
// 	FIO3DIR |= 0x06000000;    	   

//     FIO1DIR |= 0x80000000; 

// //select default Wigend as input when SDC memory is used no interrupt is received on wiegand
// 	FIO0CLR |=	WG_LATCh_SEL;	
// 	DIR_IO_DEC_PINS();
// 	BYTE_IO_OUT_PORT(0xFF);
// }
/*
void LOCK_1(BYTE data)
{   FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO2SET |= OUT_DB0)  : (FIO2CLR |= OUT_DB0) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
						
}

void LOCK_2(BYTE data)
{    FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO2SET |= OUT_DB1)  : (FIO2CLR |= OUT_DB1) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}

void DOTL_BUZ_1(BYTE data)
{    FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO2SET |= OUT_DB2)  : (FIO2CLR |= OUT_DB2) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}
void DOTL_BUZ_2(BYTE data)
{   FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO2SET |= OUT_DB3)  : (FIO2CLR |= OUT_DB3) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}
void READER_LED_1(BYTE data)
{    FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO2SET |= OUT_DB4)  : (FIO2CLR |= OUT_DB4) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}
void READER_LED_2(BYTE data) 
{    FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO2SET |= OUT_DB5)  : (FIO2CLR |= OUT_DB5) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}
void READER_BUZ_1(BYTE data) 
{    FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO3SET |= OUT_DB6)  : (FIO3CLR |= OUT_DB6) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}
void READER_BUZ_2(BYTE data)
{    FIO4SET |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	FIO2DIR |= 0x000000FC;
	FIO3DIR |= 0x06000000; 	
	((data) ?(FIO3SET |= OUT_DB7)  : (FIO3CLR |= OUT_DB7) ); 
	FIO4CLR |= OUT_LATCh_SEL1 ;
	FIO2DIR &= ~0x000000FC;
	FIO3DIR &= ~0x06000000; 
}


BYTE EGRS_1(void)
{	BYTE temp;
	FIO2DIR &= ~0x000000FC; 
	FIO3DIR &= ~0x06000000; 
	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO2PIN >>IN_DB0) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}

BYTE DOTLIN_1(void)	 
{	BYTE temp;  
	FIO2DIR &= ~0x000000FC;  
	FIO3DIR &= ~0x06000000; 
  	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO2PIN >>IN_DB1) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}
BYTE EGRS_2(void)
{	BYTE temp;
   	FIO2DIR &= ~0x000000FC; 	
	FIO3DIR &= ~0x06000000; 
	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO2PIN >>IN_DB2) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}

BYTE DOTLIN_2(void)	
{	BYTE temp;
   	FIO2DIR &= ~0x000000FC; 	
	FIO3DIR &= ~0x06000000; 
	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO2PIN >>IN_DB3) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}

BYTE FIREIN(void)
{	BYTE temp;
	FIO2DIR &= ~0x000000FC; 	  
	FIO3DIR &= ~0x06000000; 
    FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO2PIN >>IN_DB4) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}

BYTE TAMPERIN(void)
{	BYTE temp;
	FIO2DIR &= ~0x000000FC; 	  
	FIO3DIR &= ~0x06000000; 
   	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO2PIN >>IN_DB5) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}


BYTE DIGITAL_1(void)
{	BYTE temp;
	FIO2DIR &= ~0x000000FC; 	  
	FIO3DIR &= ~0x06000000; 
	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO3PIN >>IN_DB6) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}
BYTE DIGITAL_2(void)
{	BYTE temp;
	FIO2DIR &= ~0x000000FC; 	  
	FIO3DIR &= ~0x06000000; 
	FIO4CLR |= OUT_LATCh_SEL0; 
	FIO4SET |= OUT_LATCh_SEL1; 
	IODIR1	|= 0x80000000; 
	IOCLR1  |= OUT_LATCh_SEL2; 
	temp = ((FIO3PIN >>IN_DB7) & 0x01);
	FIO4CLR |= OUT_LATCh_SEL1 ;
	return temp;
}

*/
BYTE WigIN_1(void)
{
 	BYTE temp;		
    temp = 	((FIO2PIN >> WG_DB6) & 0x1); 
	return temp;
}



BYTE WigIN_2(void)
{
	BYTE temp;
    temp = 	((FIO2PIN >> WG_DB7) & 0x1); 
	return temp;

}

BYTE WigIN_3(void)
{
	BYTE temp;
    temp = 	((FIO0PIN >> WG_DB2) & 0x1); 
	return temp;


}

BYTE WigIN_4(void)
{
	BYTE temp;
    temp = 	((FIO0PIN >> WG_DB3) & 0x1); 
	return temp;
 
}


