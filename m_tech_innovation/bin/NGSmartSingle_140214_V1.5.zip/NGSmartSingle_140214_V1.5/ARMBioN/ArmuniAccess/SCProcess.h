/*** BeginHeader SCProcess*/

// Following is used to select which card layout is to be used using system parameter no 65
#define SC_LAYOUT_HCL		0
#define SC_LAYOUT_ZICOM		1
#define SC_LAYOUT_BARC		2
#define SC_LAYOUT_BEST		3
#define SC_LAYOUT_LPU		4

#define SC_CARD_TYPE_HCL	1
#define SC_CARD_TYPE_LPU	2

#define SUPPORT_BARC_VIGIL_CARD		0x01
#define SUPPORT_BARC_CHSS_CARD		0x02
#define SUPPORT_BARC_ANTC_CARD		0x04

#define ZICOM_SC_CARD_NO_INFO_BLOCK			5
#define ZICOM_SC_VALIDITY_INFO_BLOCK		6

#define ERR_SC_LAYOUT_ERROR            ((char)-71)
#define ERR_SC_NO_TEMPLATE             ((char)-72)

#define MAX_NO_OF_SC_TEMPLATES			4

#define MAX_SC_BLOCKS_FOR_CARDINFO			6         


#define SEC_EMPINFO_READ_KEY           0
#define SEC_CANTEEN_READ_KEY           0
#define SEC_EMPINFO_READ_KEY_TYPE      0
#define SEC_CANTEEN_READ_KEY_TYPE      0

#define SEC_EMPINFO_WRITE_KEY          0
#define SEC_CANTEEN_WRITE_KEY          0
#define SEC_EMPINFO_WRITE_KEY_TYPE     1
#define SEC_CANTEEN_WRITE_KEY_TYPE     1

#define SCB_EMPVALIDITY    				44
#define SCB_EMPNAME        				45
#define SCB_EMPNO          				46

#define SCB_CARDNO            			48
#define SCB_CANTEEN_VDT       			49
#define SCB_BACKUP_EMPVALIDITY      	49
#define SCB_DENT_DT        				50

// card data source  ( this can be from Local or from SmartCard	  10001
#define CDATA_SOURCE_NAME			0x0001
#define CDATA_SOURCE_PIN			0x0002
#define CDATA_SOURCE_VALIDITY		0x0004
#define CDATA_SOURCE_TEMPLATE		0x0008
#define CDATA_SOURCE_USER_TYPE 		0x0010     // Card is visitor or normal employee
#define CDATA_SOURCE_ACCESSLEVEL 	0x0020	   // not in use

extern unsigned char ReadSmartCardAllData(unsigned char rdno);
extern unsigned char ReadSmartCardLayout(void);		  


/*** EndHeader */


