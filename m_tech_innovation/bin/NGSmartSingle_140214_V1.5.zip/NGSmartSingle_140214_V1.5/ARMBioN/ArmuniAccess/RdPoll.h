
#define SLAVE_TERMINATOR1  '\n'
#define SLAVE_TERMINATOR2	'\r'
#define  MAX_POLL_DEVICES				8
#define F_SerialSlaveDataProxy	PortObj[SER_SLAVE_PORT].F_SerProxy

#define DEVICE_NOT_RESPONDING	0
#define DEVICE_RESPONDING		1

#define SER_SLAVE_PORT	SER_PORT_D

#define QUEUE_CMD_WEI_LED_ON	1

							  
#define SLAVE_100mSEC_INTERRUPT()	{	\
									if(F_PollSent==SET)		 	\
					            		PollResponseTimeOut++;	 \
									SlaveWaitTimeOut++;			 \
								}
//#define MAX_SLAVE_SER_BUFF	200

#define MAX_SEND_QUEUE		10

//__packed struct _SEND_QUEUE
//{
//   unsigned char Device;
//   unsigned char Cmd;
//   unsigned char Data1;
//   unsigned char Data2;
//   unsigned char Data3;
//   unsigned char Data4;
//   unsigned char Data5;
//};

//extern __packed struct _SEND_QUEUE SendQueue[MAX_SEND_QUEUE];

__packed struct POLL_DEVICE
{
   	unsigned char ID;	//slave id
   	unsigned char Type;
   	unsigned char TimeOut;
   	unsigned char EnDis;
   	unsigned char NoRd;		//no of readers connected
	unsigned char RdOffset;		// Reader offset number to be added on received channel to get exact reader number.
   	unsigned char Status;
   	unsigned char ActualStatus;
   	unsigned char RCount;
};

extern char SendQueueRd,SendQueueWr;


//extern unsigned char SlaveSerBuffer[MAX_SLAVE_SER_BUFF+2];
#ifdef RDPOLL_INCLUDE
  extern  char SlaveSerBuffer[1024+2];
#endif
extern unsigned char F_UpdateSlaveInfo;
extern unsigned char PollRdrNo,SlaveWaitTimeOut,AllSlaveRestartTime,PollResponseTimeOut, F_PollSent, RestartPollCount, F_RestartPollSelective;
extern unsigned char F_RestartPollForAll,F_Slave_DataStart;
extern unsigned char F_ReceiveSlaveCardPortData;


extern __packed struct POLL_DEVICE PollDevices[MAX_POLL_DEVICES+1];

unsigned char InitialiseDeviceStruct(void);
void PollNextReader(void);
void ClearSlaveSerBuffer(void) ;
unsigned char SendPollRdr(unsigned char contid);
unsigned char WaitForSlaveResponse(unsigned int  time);
unsigned char InitialiseSlave(void);
void ManagePollResponse(void);
void RestartPollForSelectDev(void);
void RestartPollForAllDevices(void);
unsigned char SendDoorOpenRdr(unsigned char contid,unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno);
extern unsigned char SendResetBufferRdr(unsigned char contid);
extern void InitialiseSlaveController(void);
extern unsigned char AddToSendQueue(unsigned char deviceno,unsigned char cmd,unsigned char data1,unsigned char data2, unsigned char data3,unsigned char data4,unsigned char data5);
extern unsigned char SendFromSendQueue(void);
extern unsigned char SendDoorOpenChannel(unsigned char channelno);
extern unsigned char VerifyRecChecksum(unsigned short datacnt,unsigned char *buffer);
extern unsigned char SendSlaveDoorControl(unsigned char channelno,unsigned char eventcode,unsigned char buzzercode);

