
==============================================
How to create PHASE-II ABW firmware file: ARM Biosmart-Suprema
==============================================
1) Select "ArmBiolite.Uv2" project.
2) #define selection

//This is for hardware selection
#define BIO_METRIC
#defineARM_BIOSMART_HW
#define SUPPORT_SUPREMA



