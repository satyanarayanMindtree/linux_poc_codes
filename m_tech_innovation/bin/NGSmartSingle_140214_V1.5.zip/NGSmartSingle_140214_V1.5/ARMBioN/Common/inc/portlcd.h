/*****************************************************************************
 *   portlcd.h:  Header file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.13  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __PORTLCD_H 
#define __PORTLCD_H

#define USE_FIO		1

//#if USE_FIO
//#define IO1DIR    FIO1DIR
//#define IO1SET    FIO1SET			   
//#define IO1CLR    FIO1CLR
//#define IO1PIN    FIO1PIN
//#else
//#define IO1DIR    IODIR1
//#define IO1SET    IOSET1
//#define IO1CLR    IOCLR1
//#define IO1PIN    IOPIN1
//#endif

//#define USE_4_16_DISPLAY

#ifdef USE_4_16_DISPLAY

// used to display user inputs for data entry
#define ROW_USER_ENTRY          	3
// used to display different function selected
#define ROW_USER_FUNCTION       	2
// used to display Just Current Date and time
#define ROW_DATE_TIME_DISP      	4
// used to display Organization name always
#define ROW_ORG_NAME_DISP    		1
// used to display Error and access grant messages like access granted/ time zone error
#define ROW_CARD_ERROR_DISP 				3
//to display hardware error maeeages SC Fail/ Sensor fail
#define ROW_HW_ERROR_DISP 			3

#else

//#define ROW_USER_FUNCTION   		1    //taken from unserinfglcd.h
//#define ROW_USER_ENTRY		 		2
#define ROW_DATE_TIME_DISP  		2
#define ROW_ORG_NAME_DISP 			1
#define ROW_CARD_ERROR_DISP 		2
#define ROW_HW_ERROR_DISP 			2

#endif


/* Please note, on old MCB2300 board, the LCD_E bit is p1.30, on the new board
it's p1.31, please check the schematic carefully, and change LCD_CTRL and LCD_E 
accordingly if you have a different board. */
 


#define MESSAGE_POSITION 0x0            /* Start of display message */
#define MESSAGEOFFSET 0x0

extern void InitialiseDisplay(void);
extern void LCD_load(BYTE *fp, DWORD cnt);
extern void LCD_gotoxy(BYTE x, BYTE y);
extern void PositionCursorOnRow1(BYTE position );
extern void PositionCursorOnRow2(BYTE position );
extern void PositionCursorOnRowNo(BYTE position,BYTE row);
extern void L_BlankDisplay(BYTE line);
extern void L_DisplayMessage(BYTE *stringtype,BYTE length,BYTE row );
extern void L_DisplayString(BYTE stringtype,BYTE row );
extern void LCD_cls(void);
extern void LCD_cur_off(void);
extern void LCD_on(void);
extern void WriteDataToDisplay( BYTE data1 );
extern void LCD_puts(BYTE *sp);
extern void LCD_bargraph(DWORD val, DWORD size);
extern void L_DisplayROMStrLoc(unsigned char *strdata,BYTE len,BYTE row, BYTE loc);
extern void L_DisplayDecimalInteger(WORD intdata,BYTE position,BYTE row);
extern void L_DisplayRAMStr(BYTE *strdata,BYTE len,BYTE row);
extern void L_DisplayROMStr(unsigned char *strdata,BYTE len,BYTE row);
extern void L_DisplayCharAt1(BYTE position,BYTE data1 );
extern void L_DisplayCharAt2(BYTE position,BYTE data1 );
extern void L_DisplayChar1(BYTE position, BYTE data1);
extern void L_DisplayChar2(BYTE position, BYTE data1);
extern void L_DisplayStdMessg(BYTE stringtype,BYTE row );
extern void L_BlankDisplay(BYTE line);
extern void L_DisplayCardNumber(CARDNO_DATA_STORAGE_TYPE intdata,BYTE position,BYTE row);
extern void L_DisplayLong(DWORD  intdata,BYTE position,BYTE row);
extern void L_DisplayCharAtRow(BYTE position,BYTE data1,BYTE row );
extern void L_CenterDisplayROMStrLoc(unsigned char *strdata,BYTE row);

/* Local Function Prototypes */
extern void Delay( DWORD cnt );
extern void lcd_write( DWORD c );
extern void lcd_write_4bit( DWORD c );
extern DWORD lcd_read_stat( void );
extern void lcd_write_cmd( DWORD c );
extern void lcd_write_data( DWORD d );
extern void lcd_wait_busy( void );
extern void L_DisplayCharRow(unsigned char position,unsigned char data1,unsigned char row);
extern void LCDDisplayTimeData(RTCTime timedate,BYTE blinkpos,BYTE weekday);
extern void LCDDisplayTimeDataAtRow(struct DATE_TIME timedate,unsigned char blinkpos,unsigned char weekday,unsigned char row);;
extern void L_DisplayDecimalByte(unsigned char intdata,unsigned char position,unsigned char row);
extern void L_DisplayHexByte(unsigned char intdata,unsigned char position,unsigned char row);
extern void DisplayRadioButton(unsigned char *strdata,BYTE row,char Highlight);
extern void L_DisplayHexDouble(unsigned long intdata,unsigned char position,unsigned char row);
extern void L_DisplayWelcomeMessage(unsigned char *strdata,BYTE len,BYTE row, BYTE pos);



#endif /* end __PORTLCD_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/
