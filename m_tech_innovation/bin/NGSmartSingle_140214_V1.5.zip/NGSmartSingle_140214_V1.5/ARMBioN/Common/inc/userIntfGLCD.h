
#ifndef USERINTGLCD_H
#define	USERINTGLCD_H

#include "../../GLCD/drivers/lcd/tft/lcd.h"
#include "../../GLCD/drivers/lcd/tft/drawing.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusans9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusansbold9.h"
#include "../../GLCD/drivers/lcd/tft/fonts/dejavusansmono8.h"
//#include "../../GLCD/drivers/lcd/tft/hw/ILI9328.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerifBold16.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif14pts.h"
#include "../../GLCD/drivers/lcd/tft/fonts/Verdana12ptsBold_custom.h"
#include "../../GLCD/drivers/lcd/tft/fonts/Arial12ptsBold.h"
#include "../../GLCD/drivers/lcd/tft/fonts/MicrosoftSansSerif12ptsBold.h"
#include "../../GLCD/drivers/lcd/tft/fonts/Vrinda20ptsBold.h"
//void WelcomeMode(unsigned char keytype);
void UpdateTouchScreen(unsigned char tcKey,unsigned char select);
void DisplayIcon(unsigned char iconPos,unsigned char iconNo,unsigned char select);
void DisplayIconWithName(unsigned char iconPos,unsigned char iconNo,unsigned char select,char* text);
void DisplayRadioScroll(void) ;

//====================================================================
__packed struct USER_MGMT
{
	unsigned char CMode;			// Current Display Mode
	char SMode;			// Display Sub Mode
	char GroupNo;		// Group number for which this displayMode is selected	e.g G_CARD	or G_BILLING etc..
	long CNumber;		// Card Number
	char ModeIndex;		// Mode no as Indexno 
	char CharValue1;	// internal Value 1 which is char
	int  IntValue1;		// internal value 1 which is int
	char PrevMode;		// Previous mode before this mode
};

extern struct USER_MGMT UserMgmt;		// User management values for mode management.

#define DisplayMode		UserMgmt.CMode
#define DisplaySubMode	UserMgmt.SMode
//#define ModeIndex		UserMgmt.ModeIndex
#define GroupNo			UserMgmt.GroupNo
#define PrevMode		UserMgmt.PrevMode

#define ICON_VIEW_GRID	0X80
#define ICON_VIEW_LIST	0X00

//=====================================================================

// __packed struct MULTI_FUN
// {
// 	long Cno;
// 	long Amt;
// 	char Qty;
// 	char Total;
// };

// extern struct MULTI_FUN multifun;
//=====================================================================
// Group Nos
#define G_MAIN_SCREEN	0
#define G_SETTING 		1
#define G_BILLING 		2
#define G_MENU	  		3
#define G_CARD		  	4
// The Admin Types are
#define ADM_USR		0x00
#define ADM_OPR		0x01
#define ADM_ADM		0x02

//KEY DEFINITIONS				//FUNCTIONS ALLOTED	     // Decided KEYPAD
#define KEY_ESC 		ESC		//WELCOME			  ---> 	Esc
#define KEY_FN  		F1		//DWN				  ---> 	In(Yes)
#define KEY_DSA  		F2	    //UP				  --->	Out(No)
#define KEY_TICKET 		F3		//ITEM RELATED MENU	  --->	Login
#define KEY_STAGE  		F4		//TURN OFF DEVICE	  --->	F1
#define KEY_INSP 		F5		//PRINT PREVIOUS BILL --->	Report 
#define KEY_REPEAT 		F6		//DIRECT ITEM MENU	  --->  Print 	
#define KEY_DATACOMM 	PC

#define KEY_LUG 		F7		//BILLING MENU		  --->	Bill
#define KEY_PASS 		F8		//DATE TIME SETTINGS  --->	F2
#define KEY_REPORT 		F9		//CARD MGMT 		  --->	Card

#define KEY_CONS  		F10		//RESET BILL NO		  --->	F3
#define KEY_FREETABLE 	F11 	//SETTING MENU		  --->	Setting
#define KEY_CREDIT		F12		//SET MAX ITEM NO	  --->	F4
#define KEY_PAPFD	 	F13

#define UP_KEY	 	0
#define DN_KEY	 	1
//#define UP_KEY	 	0
//#define UP_KEY	 	0


//Different CardTypes

#define NO_BAL_CHECK	0
#define	BAL_ON_UNIT		1
#define BAL_ON_CARD		2

// Different Device Operation Mode Are
#define U_WELCOME		1	//0001
#define U_ATTENDANCE	2	//0010
#define U_WEIGAND_OUT  	4	//0100
#define U_SMART_CARD    8	//1000
#define U_ACCESS		10	//0001

//==========================================================================================================================

#ifdef ENABLE_GSM_GPRS
	#ifdef ENABLE_SERVER_AUTH
		#define MAX_DISPLAY_NEWMODE_MEMBER	(85+1+1)		// If any extra menu is added in structure then 'ADD 1(+1)'  
	#else //#ifdef ENABLE_SERVER_AUTH
		#define MAX_DISPLAY_NEWMODE_MEMBER	(79+1+1)		// If any extra menu is added in structure then 'ADD 1(+1)'  
	#endif //#else //#ifdef ENABLE_SERVER_AUTH
#else
	#ifdef ENABLE_SERVER_AUTH
		#define MAX_DISPLAY_NEWMODE_MEMBER	(78+1+1)		// If any extra menu is added in structure then 'ADD 1(+1)'  
	#else //#ifdef ENABLE_SERVER_AUTH
		#define MAX_DISPLAY_NEWMODE_MEMBER	(73+1+1)		// If any extra menu is added in structure then 'ADD 1(+1)'  
	#endif //#else //#ifdef ENABLE_SERVER_AUTH
#endif	
//#define MAX_DISPLAY_MODE_NEW		45		//this is number of menus ex. if last menu is *9995 then it is 35  
// We need to fill following structure with Function which needs to be called and value of No should match with index number.	
struct MENU_GROUP_S
{
	unsigned char ModeNo;
	unsigned char DevOpMode;
	unsigned char Group;		// Sub Group Name	 
	unsigned char DSPMode;			// used to set displaymode variable to support calling from weigand and bio handlers
	unsigned char SpKey;		
	unsigned char MenuName[32];
	void (*EvFunction)(unsigned char);
	unsigned char IconInfo;	//view type of following icon and icon index
	unsigned char Admin;									
};
extern const struct MENU_GROUP_S UserInt1[MAX_DISPLAY_NEWMODE_MEMBER]; 

#define MODE_MAIN_MENU					0
////////////////////////////////////////// Start of Grid View ////////////////////////
#define DISPLAY_HEIGHT						240
#define DISPLAY_WIDTH						320

#define GRID_TITLE_FONT_INFO_PTR			(&bitstreamVeraSansMonoBold11ptFontInfo)			  
#define GRID_TITLE_FONT_COLOR				COLOR_WHITE	  
#define GRID_TITLE_FONT_HEIGHT				9				
#define GRID_TITLE_SECTION_WIDTH			320
#define GRID_TITLE_SECTION_HEIGHT			20
#define GRID_TITLE_SECTION_X0				0
#define GRID_TITLE_SECTION_Y0				18

#define GRID_ICON_WIDTH						64
#define GRID_ICON_HEIGHT					60
#define GRID_ICON_GAP_WIDTH					12
#define GRID_ICON_GAP_HEIGHT				17  //17*3 = 51 +60+60 
#define GRID_SECTION_WIDTH				    320
#define GRID_SECTION_HEIGHT					135
#define MAX_GRID_ICON						8
#define GRID_SECTION_X0						(0)
#define GRID_SECTION_Y0						(24+1)//  STATUSBAR_HEIGHT + 1 //exclude Top status bar-18pix and Title bar-20pix  // 30+18
#define GRID_ICON_SECTION_WIDTH				(GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH)
#define GRID_ICON_SECTION_HEIGHT			(GRID_ICON_HEIGHT + GRID_ICON_GAP_HEIGHT)

#define GRID_ICON1_SECTION_X0				0
#define GRID_ICON2_SECTION_X0				(GRID_ICON1_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH/2)
#define GRID_ICON3_SECTION_X0				(GRID_ICON2_SECTION_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH/2)
#define GRID_ICON4_SECTION_X0				(GRID_ICON3_SECTION_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH/2)

#define GRID_ICON1_SECTION_Y0				GRID_SECTION_Y0
#define GRID_ICON2_SECTION_Y0				GRID_ICON1_SECTION_Y0
#define GRID_ICON3_SECTION_Y0				GRID_ICON1_SECTION_Y0
#define GRID_ICON4_SECTION_Y0				GRID_ICON1_SECTION_Y0

#define GRID_ICON5_SECTION_X0				GRID_ICON1_SECTION_X0
#define GRID_ICON6_SECTION_X0				GRID_ICON2_SECTION_X0
#define GRID_ICON7_SECTION_X0				GRID_ICON3_SECTION_X0
#define GRID_ICON8_SECTION_X0				GRID_ICON4_SECTION_X0

#define GRID_ICON5_SECTION_Y0				(GRID_ICON1_SECTION_Y0+GRID_ICON_HEIGHT+GRID_ICON_GAP_HEIGHT/2)
#define GRID_ICON6_SECTION_Y0				GRID_ICON5_SECTION_Y0
#define GRID_ICON7_SECTION_Y0				GRID_ICON5_SECTION_Y0
#define GRID_ICON8_SECTION_Y0				GRID_ICON5_SECTION_Y0

#define GRID_ICON1_X0						14
#define GRID_ICON1_Y0						(GRID_SECTION_Y0 + 5)//(GRID_SECTION_Y0 + GRID_ICON_GAP_HEIGHT)  //

#define GRID_ICON2_X0						(GRID_ICON1_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH)
#define GRID_ICON2_Y0						GRID_ICON1_Y0

#define GRID_ICON3_X0						(GRID_ICON2_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH)
#define GRID_ICON3_Y0						GRID_ICON1_Y0

#define GRID_ICON4_X0						(GRID_ICON3_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH)
#define GRID_ICON4_Y0						GRID_ICON1_Y0
///////
#define GRID_ICON5_X0						GRID_ICON1_X0
#define GRID_ICON5_Y0						(GRID_ICON1_Y0 + GRID_ICON_HEIGHT + GRID_ICON_GAP_HEIGHT+6)

#define GRID_ICON6_X0						GRID_ICON2_X0
#define GRID_ICON6_Y0						GRID_ICON5_Y0

#define GRID_ICON7_X0						GRID_ICON3_X0
#define GRID_ICON7_Y0						GRID_ICON5_Y0

#define GRID_ICON8_X0						GRID_ICON4_X0
#define GRID_ICON8_Y0						GRID_ICON5_Y0

                // -----  Grid Icon Name  ---------
#define SPACE_GRIDICON_NAME_HEIGHT    		1
#define GRIDICON_NAME_STRWIDTH    		    76

#define GRID_ICON1_NAME_X0		    8
#define GRID_ICON1_NAME_Y0		  	(GRID_ICON1_Y0 + GRID_ICON_HEIGHT + SPACE_GRIDICON_NAME_HEIGHT)

#define GRID_ICON2_NAME_X0		    (GRID_ICON1_NAME_X0 + GRIDICON_NAME_STRWIDTH)
#define GRID_ICON2_NAME_Y0		  	GRID_ICON1_NAME_Y0

#define GRID_ICON3_NAME_X0		    (GRID_ICON2_NAME_X0 + GRIDICON_NAME_STRWIDTH)
#define GRID_ICON3_NAME_Y0		  	GRID_ICON1_NAME_Y0

#define GRID_ICON4_NAME_X0		    (GRID_ICON3_NAME_X0 + GRIDICON_NAME_STRWIDTH)
#define GRID_ICON4_NAME_Y0		  	GRID_ICON1_NAME_Y0

#define GRID_ICON5_NAME_X0		    GRID_ICON1_NAME_X0
#define GRID_ICON5_NAME_Y0		  	(GRID_ICON5_Y0 +GRID_ICON_HEIGHT + SPACE_GRIDICON_NAME_HEIGHT)

#define GRID_ICON6_NAME_X0		    GRID_ICON2_NAME_X0
#define GRID_ICON6_NAME_Y0		  	GRID_ICON5_NAME_Y0

#define GRID_ICON7_NAME_X0		    GRID_ICON3_NAME_X0
#define GRID_ICON7_NAME_Y0		  	GRID_ICON5_NAME_Y0

#define GRID_ICON8_NAME_X0		    GRID_ICON4_NAME_X0
#define GRID_ICON8_NAME_Y0		  	GRID_ICON5_NAME_Y0


#define FONT_ICON_NAME   (&dejaVuSansCondensed9ptFontInfo)


////////////////////////////////////////// End of Grid View ////////////////////////
// ////////////////////////////////////////// Start of Grid View ////////////////////////  old data with 3X3 matrix
// #define DISPLAY_HEIGHT						240
// #define DISPLAY_WIDTH						320

// #define GRID_ICON_HEIGHT					60
// #define GRID_ICON_WIDTH						60
// #define GRID_ICON_GAP_HEIGHT				2
// #define GRID_ICON_GAP_WIDTH					15
// #define GRID_SECTION_HEIGHT					(GRID_ICON_HEIGHT*3 + GRID_ICON_GAP_HEIGHT*2)
// #define GRID_SECTION_WIDTH				    (GRID_ICON_WIDTH*3 + GRID_ICON_GAP_WIDTH*2)
// #define MAX_GRID_ICON						9
// #define GRID_SECTION_X0						( (DISPLAY_WIDTH-GRID_SECTION_WIDTH)/2 )
// #define GRID_SECTION_Y0						( (DISPLAY_HEIGHT - TOUCH_KEY_SECTION_HEIGHT - GRID_SECTION_HEIGHT)/2 )

// #define GRID_ICON1_X0						GRID_SECTION_X0
// #define GRID_ICON1_Y0						GRID_SECTION_Y0
// #define GRID_ICON2_X0						(GRID_ICON1_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH)
// #define GRID_ICON2_Y0						GRID_ICON1_Y0
// #define GRID_ICON3_X0						(GRID_ICON2_X0 + GRID_ICON_WIDTH + GRID_ICON_GAP_WIDTH)
// #define GRID_ICON3_Y0						GRID_ICON1_Y0

// #define GRID_ICON4_X0						GRID_ICON1_X0
// #define GRID_ICON4_Y0						(GRID_ICON1_Y0 + GRID_ICON_HEIGHT + GRID_ICON_GAP_HEIGHT)
// #define GRID_ICON5_X0						GRID_ICON2_X0
// #define GRID_ICON5_Y0						GRID_ICON4_Y0
// #define GRID_ICON6_X0						GRID_ICON3_X0
// #define GRID_ICON6_Y0						GRID_ICON4_Y0

// #define GRID_ICON7_X0						GRID_ICON1_X0
// #define GRID_ICON7_Y0						(GRID_ICON4_Y0 + GRID_ICON_HEIGHT + GRID_ICON_GAP_HEIGHT)
// #define GRID_ICON8_X0						GRID_ICON2_X0
// #define GRID_ICON8_Y0						GRID_ICON7_Y0
// #define GRID_ICON9_X0						GRID_ICON3_X0
// #define GRID_ICON9_Y0						GRID_ICON7_Y0
// ////////////////////////////////////////// End of Grid View ////////////////////////

////////////////////////////////////////// Start of touch key ////////////////////////
#define TOUCH_KEY_SECTION_HEIGHT			50
#define TOUCH_KEY_SECTION_WIDTH				DISPLAY_WIDTH
#define MAX_TOUCH_KEY						5
#define TOUCH_KEY_HEIGHT					(TOUCH_KEY_SECTION_HEIGHT - 2)           		//48
#define TOUCH_KEY_WIDTH						(TOUCH_KEY_SECTION_WIDTH/MAX_TOUCH_KEY-2)    	//62
#define TOUCH_KEY_SECTION_X0				0
#define TOUCH_KEY_SECTION_Y0				(DISPLAY_HEIGHT - TOUCH_KEY_SECTION_HEIGHT)
#define TOUCH_KEY1_X0						(TOUCH_KEY_SECTION_X0+1)
#define TOUCH_KEY1_Y0                       (TOUCH_KEY_SECTION_Y0+1)
#define TOUCH_KEY2_X0						(TOUCH_KEY1_X0+TOUCH_KEY_WIDTH+2)
#define TOUCH_KEY2_Y0                       TOUCH_KEY1_Y0
#define TOUCH_KEY3_X0						(TOUCH_KEY2_X0+TOUCH_KEY_WIDTH+2)
#define TOUCH_KEY3_Y0                       TOUCH_KEY1_Y0
#define TOUCH_KEY4_X0						(TOUCH_KEY3_X0+TOUCH_KEY_WIDTH+2)
#define TOUCH_KEY4_Y0                       TOUCH_KEY1_Y0
#define TOUCH_KEY5_X0						(TOUCH_KEY4_X0+TOUCH_KEY_WIDTH+2)
#define TOUCH_KEY5_Y0                       TOUCH_KEY1_Y0

#define TOUCH_KEY_FONT_INFO_PTR				&bitstreamVeraSansMonoBold11ptFontInfo
#define TOUCH_KEY_FONT_HEIGHT				9				

struct structTouchKeyPad
{
	unsigned char Keyfunction[MAX_TOUCH_KEY];
	unsigned char CurrentSelection;  //0=no selection, range is from 1 to 5
	unsigned char PreviousSelection; //0=no selection, range is from 1 to 5
	unsigned char IsVisible; //0=no selection, range is from 1 to 5
	
};
extern struct structTouchKeyPad TouchKeyPad;
////////////////////////////////////////// End of touch key ////////////////////////

#define BOOT_MSG_SECTION_HEIGHT					TOUCH_KEY_SECTION_HEIGHT
#define BOOT_MSG_SECTION_WIDTH					TOUCH_KEY_SECTION_WIDTH
#define BOOT_MSG_SECTION_X0					0
#define BOOT_MSG_SECTION_Y0					(DISPLAY_HEIGHT - BOOT_MSG_SECTION_HEIGHT)

#define RCTFILL_PLAIN						1
#define RCTFILL_VERTICAL_UP_SHADOW			2
#define RCTFILL_VERTICAL_DOWN_SHADOW		3
#define RCTFILL_HORIZONTAL_LEFT_SHADOW		4
#define RCTFILL_HORIZONTAL_RIGHT_SHADOW		5
#define RCTFILL_VERTICAL_DOUBLE_SHADOW		6
#define RCTFILL_HORIZONTAL_DOUBLE_SHADOW	7
#define RCTFILL_BORDER						8
#define RCTFILL_CURVEDBORDER				9
#define RCTFILL_CURVED						10




//------------------ Walpaper  --------------------------------
#define DUMMY_ZONE_COLOR                    COLOR_BLACK //COLOR_GREEN //COLOR_BLACK
#define DUMMY_ZONE_HEIGHT					12    
#define DUMMY_ZONE_WIDTH					320
#define DUMMY_ZONE_X0						0
#define DUMMY_ZONE_Y0						0

#define STATUSBAR_COLOR						COLOR_LIGHTGRAY			      // BATERY NETWORK ALL ICONS 
#define STATUSBAR_HEIGHT					18    
#define STATUSBAR_WIDTH						320
#define STATUSBAR_X0						0
#define STATUSBAR_Y0						DUMMY_ZONE_HEIGHT

#define DISP_DATETIME_HEIGHT				(80)
#define DISP_DATETIME_WIDTH					320
#define DISP_DATETIME_X0					0
#define DISP_DATETIME_Y0					(STATUSBAR_HEIGHT +  DUMMY_ZONE_HEIGHT )

#define DISP_STATUSMSGHEIGHT_HEIGHT			0//	18 + TOUCH_KEY_SECTION_HEIGHT
#define DISP_STATUSMSGHEIGHT_WIDTH			0//	320
#define DISP_STATUSMSGHEIGHT_X0				0
#define DISP_STATUSMSGHEIGHT_Y0				DUMMY_ZONE_HEIGHT//	(TOUCH_KEY_SECTION_Y0 - 18)
/************************************************************************************/
////////////////////////////// START OF bottom STATUS ICON //////////////////
#define MAX_BOTTOM_EVENT 		8

#define BOTTOM_STATUS_ICON_WIDTH				16
#define BOTTOM_STATUS_ICON_HEIGHT				16
#define BOTTOM_STATUS_ICON_SECTION_X0			DISP_STATUSMSGHEIGHT_X0
#define BOTTOM_STATUS_ICON_SECTION_Y0         	DISP_STATUSMSGHEIGHT_Y0
#define BOTTOM_STATUS_ICON_SECTION_WIDTH      	(320-BOTTOM_STATUS_ICON_WIDTH-2)
#define BOTTOM_STATUS_ICON_SECTION_HEIGHT     	18
#define BOTTOM_STATUS_ICON_WIDTH				16
#define BOTTOM_STATUS_ICON_HEIGHT				16

#define BOTTOM_STATUS_ICON_X0			(BOTTOM_STATUS_ICON_SECTION_X0 +1)
#define BOTTOM_STATUS_ICON_Y0			(BOTTOM_STATUS_ICON_SECTION_Y0 +1)

#define BOTTOM_STATUS_MSG_X0			(BOTTOM_STATUS_ICON_X0 +1)
#define BOTTOM_STATUS_MSG_Y0			(BOTTOM_STATUS_ICON_SECTION_Y0)

#define BOTTOM_STATUS_MSG_FONTINFO_PTR	(&bitstreamVeraSansMonoBold11ptFontInfo)
//#define BOTTOM_STATUS_MSG_FONT_COLOR	
////////////////////////////// END OF bottom STATUS ICON //////////////////

#define WALLPAPER_HEIGHT					(240 - (STATUSBAR_HEIGHT + DISP_DATETIME_HEIGHT))
#define WALLPAPER_WIDTH						320
#define WALLPAPER_X0						0
#define WALLPAPER_Y0						(STATUSBAR_HEIGHT + DISP_DATETIME_HEIGHT)

#define TITLEMSG_HEIGHT      		    30 
#define TITLEMSG_WEIGHT					320
#define DISP_TITLEMSG_X0  				0
#define DISP_TITLEMSG_Y0  			(STATUSBAR_HEIGHT + DUMMY_ZONE_HEIGHT)

#define MAX_THEME		4

 struct Theme_Colour{
		unsigned short StatusbarColour; // status msg background colour // default white
		unsigned short TimeDateColour;    //TimeDateColour background colour //  red
		unsigned short BackGroundColour;  //  BackGroundColour in submenue and scroll menue  //white
		unsigned short SatusMSGColour;      // 
		unsigned short TitleMSGBackgroundColour;	 // TitleMSGBackgroundColour  is titlke ackground colour in submenue and scroll menue //red
		unsigned short TitleMSGStrColour;    //      TitleMSGStrColour is string colour ie submeue headline colour         // white
		unsigned short SubmenuBackgroundColour;   //		SubmenuBackgroundColour         same as BackGroundColour
		unsigned short SubmenuStrBackgroundColour;   //
		unsigned short SubmenuHighlightStrColour;					//
		unsigned short SubmenuUnHighlightStrColour;					//
		//unsigned int StatusMSGStringColor;		// string color of top status msg//black
	};
	
	
// for SD card --------------
#define GRID_ICONS		2	
	
#define MAX_IMAGES  		10
#define BLOCKSPERIMAGE      300
#define IMAGES_GROUP        1

#define MAX_ICONNO          17    // 8 ICON FOR UNHIGHLIGHT AND 8 FOR HIGHLIGHT total - 16
#define BLOCKSPERICON       15
#define ICON_GROUP          GRID_ICONS

#define MAX_EVENTICONNO     17    	
#define BLOCKSPER_EVENTICON       1
#define EVENT_ICON_GROUP          3
	
//----------------------------	
extern const struct Theme_Colour ThemeColour[MAX_THEME];	
	
__packed struct Theme_Select{
	
	 unsigned short StatusbarHeight;   
	 unsigned short StatusbarWidth;	
	 unsigned short StatusbarStartXO;	
	 unsigned char StatusbarStartYO;  // max 240

//	 unsigned int TimeDateColour;
	 unsigned short TimeDateHeight;
	 unsigned short TimeDateWidth;	
	 unsigned short TimeDateStartXO;	
	 unsigned char TimeDateStartYO;  // max 240

//	 unsigned int BackGroundColour;
	 unsigned short BackGroundHeight;
	 unsigned short BackGroundWidth;	
	 unsigned short BackGroundStartXO;	
	 unsigned char BackGroundStartYO;  // max 240

//	 unsigned int SatusMSGColour;
	 unsigned short SatusMSGHeight;
	 unsigned short SatusMSGWidth;	
	 unsigned short SatusMSGStartXO;	
	 unsigned char SatusMSGStartYO;  // max 240
	 
	 unsigned short SubmenueTitleMSGHeight;
	 unsigned short SubmenueTitleMSGWidth;	
	 unsigned short SubmenueTitleMSGStartXO;	
	 unsigned char 	submenueSatusMSGStartYO;  // max 240

// STRING COLOUR, TOUCHKEPADCOLOUR, 	STRING_TOUCHKEPADCOLOUR,TS RELATED 
};

	
extern const struct Theme_Select ThemeSelect;
//---------------------  End of  Walpaper   -------------------------------------------

__packed struct RectInfo
{
	unsigned char FillType;
	uint16_t	Color;
   	uint16_t	Hight;
	uint16_t	Width;
	uint16_t	BorderColor;
	// following info is for shadow
	unsigned char XIncrementPixel;
	unsigned char YIncrementPixel;
	unsigned char XSpacePixel;
	unsigned char YSpacePixel;
};
extern struct RectInfo		DefaultBackground,MenuBachground,MenuHighlight;

#define MAX_ICON	5 
#define ICON_COLOR	COLOR_WHITE
#define ICON_NUM_MASK	0x3f

#define BACKGROUND_COLOR	COLOR_BLACK
#define GLOBAL_FONT_COLOR	COLOR_WHITE
#define MENU_FONT_COLOR		COLOR_WHITE
extern const FONT_INFO *GlobalFontInfo ;
extern const FONT_INFO *IconFontInfo ;
//extern __packed uint16_t IconArray[MAX_ICON][16];//array of 16X16bit icons
extern unsigned char CurrentMenu;

void DisplayDefaultBackGround(void);
void DisplayDefaultScreen(void);
void DrawGrid(unsigned char curmenu);
void DisplayFuncScroll(unsigned char curmenu);
void HandleSubMenuScroll(unsigned char key);
char GetMaxSubMenu(unsigned char group);
void GL_DisplayROMStrLoc(char  *strdata, unsigned char row, unsigned char loc);
void DisplayClr(void);
void HighlightIcon(unsigned char CurrentIconIndex,unsigned char PreviousIconIndex,
					unsigned char CurrentIconNum,unsigned char PreviousIconNum,
					unsigned char currentArr,unsigned char prevArr);
void DrawIconByByte(unsigned char Index, uint16_t color, uint16_t x0, uint16_t y0);
void DrawRect(struct RectInfo * rectinfo, uint16_t x0, uint16_t y0 );
void ShiftDisplayUp(void);
void ClearBootScreen(void);
//void DispTouchKeyPad(void);
void DispTouchKeyPad(unsigned char Format);
void DisplayBmp(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned short image[]);
void DisplayBmpTransparent(uint16_t x, uint16_t y,uint16_t width, uint16_t height,const unsigned short image[],const unsigned short TransparentColor);
void ClearGridDisplay(void);
void LCDWriteScrollMenuString(char *String,unsigned char Len,unsigned char lineNum);
void DisplayDateTime(void);
void DisplayFormat(unsigned char Format);
void DisplayWallpaper(void);
void ClrScreenWithoutStatusBar(void);
void DefaultGrid_SubmenueScreen(void);
void DisplayWallpaperWithoutGrid(void);
void UpdateGridView(void);
unsigned char GetIndexFromGridSelection(void);
void DisplayGridMenu(void);
void UpdateScrollMenu(unsigned char MenuIndex);
unsigned char GetModeIndexFromSelection(unsigned char Index,unsigned char CurrentSelection);
void DisplayBackGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height, unsigned short image);
unsigned char GetMaxScrollMenu(unsigned char Index);
void DisplayScrollMenu(unsigned char MenuIndex);
void TFTWriteCommand(unsigned char ucData);
void TFTWriteData(unsigned short usData);
void drawCharBitmap(const uint16_t xPixel, const uint16_t yPixel, uint16_t color, const uint8_t *glyph, uint8_t glyphHeightPages, uint8_t glyphWidthBits);
void HandleDisplayErrorMessages(short event);
void DisplayEventIcon(short event);
extern void DrawCenterText(unsigned short y ,unsigned short color, const FONT_INFO *fontInfo,unsigned char* text);
char HandleTouchScreenKey(void);
void DisplayMenuFromModeNum(short ModeNumber);
void SDDisplayBackGround(uint16_t x, uint16_t y,uint16_t width, uint16_t height,unsigned char ImageNo,unsigned char groupno);
extern void DrawCenterTextWithBackGround(unsigned short y ,unsigned short color,const FONT_INFO *fontInfo,unsigned short TotalWidth,unsigned char* text,unsigned int BackGroundColour);
void ClrScreenScrollToGrid(void);
extern const unsigned short TouchKeyPosition[][2];
extern const unsigned short GridIconPosition[][2];
extern void L_NewDisplayROMStrLoc(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo,unsigned char *str,uint16_t bkColor);
extern void DISPLAY_CARD_FROM_KEYPAD(unsigned short x, unsigned short y, unsigned short color, const FONT_INFO *fontInfo,unsigned short bkColor);
extern void L_CenterDisplayROMStrFont(unsigned char *strdata,unsigned char row,const FONT_INFO *fontInfo);
extern void L_CenterDisplaySubStr(unsigned char *strdata,unsigned char row,const FONT_INFO *fontInfo);
extern void PositionCursorOnRow(unsigned short Xpos,unsigned char Xdigts,unsigned char row,unsigned char select,const FONT_INFO *fontInfo);
void DisplayStatusIcon(unsigned char Event,unsigned char Status);
void DisplayBottomStatusIcon(unsigned char Event,unsigned char *Str,unsigned char IconFlag,unsigned char IconNo); 
extern void EnableDisplay(void);

//extern unsigned char GridIconSelection;
#define XPOS	0
#define YPOS    1

//#define ROW_ORG_NAME_DISP		1		// used to display Organization name always
//#define ROW_HHT_TYPE			2		 
//#define ROW_USER_FUNCTION   	3		// used to display different function selected
//#define ROW_USER_SUB_FUNCTION 	4		// used to display different function selected
//#define ROW_USER_ENTRY      	5		// used to display user inputs for data entry
//#define ROW_USER_SUB_ENTRY     	6		// used to display user inputs for data entry
//#define ROW_INFO_DISP			7		
//#define ROW_DATE_TIME_DISP		8		// used to display Just Current Date and time

#define MAX_COL		16


//////////// FOR GRID LOCATION PIXEL WISE ///////////
#define GRID_START_X0	40	  //W.R.T. MAIN (0,0)
#define GRID_START_Y0	15	
#define GRID_SECTOR_SIZE_X	80	//SIZE IN PIXEL
#define GRID_SECTOR_SIZE_Y	75
#define GRID_PALLET_SIZE_X	(GRID_SECTOR_SIZE_X - 4	)
#define GRID_PALLET_SIZE_Y	(GRID_SECTOR_SIZE_Y - 10)	//50//
#define GRID_ICON_POS_X		8	//W.R.T. START POS OF SECTOR(GRID_SECTOR_SIZE_X,Y)	
#define GRID_ICON_POS_Y		1
#define GRID_TEXT_POS_X		2	//W.R.T. START POS OF SECTOR(GRID_SECTOR_SIZE_X,Y)	
#define GRID_TEXT_POS_Y		50
#define GRID_PALLET_POS_X		1	//W.R.T. START POS OF SECTOR(GRID_SECTOR_SIZE_X,Y)	
#define GRID_PALLET_POS_Y		1
////////////////////////////

#define GRID_PALLET1_X0		(GRID_START_X0 + 1)	
#define GRID_PALLET1_Y0		(GRID_START_Y0 + 1)
#define GRID_PALLET1_X1		(GRID_PALLET1_X0 + GRID_SECTOR_SIZE_X -2 )
#define GRID_PALLET1_Y1		(GRID_PALLET1_Y0	+ GRID_SECTOR_SIZE_Y -2)
#define GRID_PALLET2_X0		(GRID_START_X0 + 1 +	GRID_SECTOR_SIZE_X )
#define GRID_PALLET2_Y0		(GRID_START_Y0 + 1)
#define GRID_PALLET3_X0		(GRID_START_X0 + 1 + GRID_SECTOR_SIZE_X + GRID_SECTOR_SIZE_X	)
#define GRID_PALLET3_Y0		(GRID_START_Y0 + 1)

#define GRID_PALLET4_X0		(GRID_START_X0 + 1	)
#define GRID_PALLET4_Y0		(GRID_START_Y0 + 1 + GRID_SECTOR_SIZE_Y)
#define GRID_PALLET5_X0		(GRID_START_X0 + 1 +	GRID_SECTOR_SIZE_X	)
#define GRID_PALLET5_Y0		(GRID_START_Y0 + 1 + GRID_SECTOR_SIZE_Y		 )
#define GRID_PALLET6_X0		(GRID_START_X0 + 1 + GRID_SECTOR_SIZE_X + GRID_SECTOR_SIZE_X	)
#define GRID_PALLET6_Y0		(GRID_START_Y0 + 1 + GRID_SECTOR_SIZE_Y)
							
#define GRID_PALLET7_X0		(GRID_START_X0 + 1	)
#define GRID_PALLET7_Y0		(GRID_START_Y0 + 1 + GRID_SECTOR_SIZE_Y + GRID_SECTOR_SIZE_Y)
#define GRID_PALLET8_X0		(GRID_START_X0 + 1 +	GRID_SECTOR_SIZE_X	)
#define GRID_PALLET8_Y0		(GRID_START_Y0 + 1 + GRID_SECTOR_SIZE_Y + GRID_SECTOR_SIZE_Y)
#define GRID_PALLET9_X0		(GRID_START_X0 + 1 + GRID_SECTOR_SIZE_X + GRID_SECTOR_SIZE_X)	
#define GRID_PALLET9_Y0		(GRID_START_Y0 + 1 + GRID_SECTOR_SIZE_Y + GRID_SECTOR_SIZE_Y)

#define SECTOR1_COLOR	COLOR_YELLOW
#define SECTOR2_COLOR	COLOR_YELLOW
#define SECTOR3_COLOR	COLOR_YELLOW
#define SECTOR4_COLOR	COLOR_YELLOW
#define SECTOR5_COLOR	COLOR_YELLOW
#define SECTOR6_COLOR	COLOR_YELLOW
#define SECTOR7_COLOR	COLOR_YELLOW
#define SECTOR8_COLOR	COLOR_YELLOW
#define SECTOR9_COLOR	COLOR_YELLOW

#define BOOT_MSG1			1
#define BOOT_MSG2	        2
#define BOOT_MSG3	        3
#define ROW_USER_TITLE	    4
#define ROW_USER_FUNCTION   5
#define ROW_USER_ENTRY      6
#define ROW_USER_ENTRY2	    7
#define ROW_USER_ENTRY3	    8
#define ROW_USER_ENTRY4	    9
#define ROW_USER_ENTRY5	    10

#define BOOT_MSG_HEIGHT			16
#define BOOT_MSG1_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG1_Y0			(BOOT_MSG_SECTION_Y0)
#define BOOT_MSG2_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG2_Y0			(BOOT_MSG1_Y0+BOOT_MSG_HEIGHT+1)
#define BOOT_MSG3_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG3_Y0			(BOOT_MSG2_Y0+BOOT_MSG_HEIGHT+1)
#define BOOT_MSG_COLOR			COLOR_WHITE
#define BOOT_MSG_FONT			dejaVuSansBold9ptFontInfo

#define FORMAT_BOOT_SCREEN					1
#define FORMAT_WELCOME_SCREEN       2
#define FORMAT_GRID_SCREEN          3
#define FORMAT_SCROLL_SCREEN        4
#define FORMAT_SUBMENU_SCREEN       5
#define FORMAT_EVENT_ICON       		6
#define FORMAT_SCROLL_MENU					7
#define FORMAT_CONNECT_GPRS					8

__packed struct DISPLAY_DATA
{
	unsigned char GridCurrentSelection;
	unsigned char GridPreviousSelection;
};
extern struct DISPLAY_DATA DisplayData;

__packed struct SCROLL_MENU_DATA
{
	unsigned char ScrollMenuCurrentSelection;
	unsigned char ScrollMenuPreviousSelection;
	unsigned char firstMenuNum;   //this displays first visible menu on screen i.e. if we are displaying menu from 2 to 5 then this =5
	unsigned char MaxMenuNum;     //maximum sub menus available in this menu
};
extern struct SCROLL_MENU_DATA ScrollMenuData;

__packed struct SCREEN_FORMAT_DATA
{
	unsigned char CurrentFormat;
	unsigned char F_SmallTimeVisible;
	unsigned char F_BigTimeVisible;
	unsigned char F_TouchScreenVisible;
	unsigned char F_GridVisible;
	unsigned char F_ScrollMenuVisible;
	unsigned char F_SubMenuVisible;
	unsigned char F_SatusBar1Visible;
	unsigned char F_SatusBar2Visible;
	unsigned char F_Scrollimage;	
	unsigned char F_ImageNo;	
};
extern struct SCREEN_FORMAT_DATA ScreenFormatData;

//below is line for scrolling menu
#define MAX_SCROLL_LINE	5
#define LINE_TITLE	1
#define LINE1       2
#define LINE2       3
#define LINE3       4
//extern unsigned char CurrentFormat;


//////////////////////////// TIME DATE DISPLAY ////////////////////////////////
#define SMALL_TIME_START_X0			260	  //W.R.T. MAIN (0,0)
#define SMALL_TIME_START_Y0			(STATUSBAR_HEIGHT + 8) 	
#define SMALL_TIME_SECTOR_SIZE_X	100	//SIZE IN PIXEL
#define SMALL_TIME_SECTOR_SIZE_Y	20
#define SMALL_TIME_FONT_INFO		(&bitstreamVeraSansMonoBold11ptFontInfo)			  
#define SMALL_TIME_FONT_COLOR		COLOR_BLACK	  

#define SMALL_DATE_START_X0			15	  //W.R.T. MAIN (0,0)
#define SMALL_DATE_START_Y0			(STATUSBAR_HEIGHT + 8)	
#define SMALL_DATE_SECTOR_SIZE_X	100	//SIZE IN PIXEL
#define SMALL_DATE_SECTOR_SIZE_Y	20
#define SMALL_DATE_FONT_INFO		(&bitstreamVeraSansMonoBold11ptFontInfo)			  
#define SMALL_DATE_FONT_COLOR		COLOR_BLACK	  

#define BIG_TIME_FONT_INFO			(&microsoftSansSerif_36ptFontInfo)
//#define BIG_TIME_FONT_INFO			(&microsoftSansSerif_26ptFontInfo)			  
//#define BIG_TIME_FONT_INFO			(&microsoftSansSerif_16ptFontInfo)			  
//#define BIG_TIME_FONT_INFO			(&microsoftSansSerif_22ptFontInfo)			  
//#define BIG_TIME_FONT_INFO			(&bitstreamVeraSansMonoBold11ptFontInfo)			  
//#define BIG_TIME_FONT_INFO			(&oCRAExtended_16ptFontInfo)			  
#define BIG_TIME_FONT_COLOR				COLOR_WHITE	  
#define BIG_TIME_START_X0					20 	  //W.R.T. MAIN (0,0)
#define BIG_TIME_START_Y0			(DISP_DATETIME_Y0 + 5)
#define BIG_TIME_SECTOR_SIZE_X		320	//SIZE IN PIXEL
//#define BIG_TIME_SECTOR_SIZE_Y		20
#define BIG_TIME_SECTOR_SIZE_Y		((BIG_TIME_FONT_INFO->heightPages)*8+5)      //+5 IS ADDED BY TRIAL AND ERROR
//#define BIG_TIME_FONT_INFO			(&bitstreamVeraSansMonoBold11ptFontInfo)

#define BIG_DATE_START_X0						120	  //W.R.T. MAIN (0,0)
#define BIG_DATE_START_Y0						(DISP_DATETIME_HEIGHT - 2 +DUMMY_ZONE_HEIGHT)   // 
#define BIG_DATE_SECTOR_SIZE_X			320	//SIZE IN PIXEL
#define BIG_DATE_SECTOR_SIZE_Y		20
#define BIG_DATE_FONT_INFO			(&bitstreamVeraSansMonoBold11ptFontInfo)  // font size 11
//#define BIG_DATE_FONT_INFO			  (&oCRAExtended_16ptFontInfo)

#define BIG_DATE_FONT_COLOR			COLOR_WHITE	  

//#define BIG_YEAR_START_X0			20	  //W.R.T. MAIN (0,0)
//#define BIG_YEAR_START_Y0			DISP_DATETIME_Y0 + 14

//////////////////////////// END OF TIME DATE DISPLAY ////////////////////////////////

//////////////////////////// FOR SCROLL MENU ////////////////////////////////
#define SCROLL_LINE1_START_X0			0	  
#define SCROLL_LINE1_START_Y0			30	
#define SCROLL_LINE1_SECTION_SIZE_X		320	//SIZE IN PIXEL
#define SCROLL_LINE1_SECTION_SIZE_Y		30

#define SCROLL_LINE2_START_X0			0	  //W.R.T. MAIN (0,0)
#define SCROLL_LINE2_START_Y0			(SCROLL_LINE1_START_Y0 + SCROLL_LINE1_SECTION_SIZE_Y) //60
#define SCROLL_LINE2_SECTION_SIZE_X		SCROLL_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SCROLL_LINE2_SECTION_SIZE_Y		20

#define SCROLL_LINE3_START_X0			SCROLL_LINE2_START_X0	  //SAME AS LINE 2
#define SCROLL_LINE3_START_Y0			(SCROLL_LINE2_START_Y0 + SCROLL_LINE2_SECTION_SIZE_Y)//80
#define SCROLL_LINE3_SECTION_SIZE_X		SCROLL_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SCROLL_LINE3_SECTION_SIZE_Y		SCROLL_LINE2_SECTION_SIZE_Y

#define SCROLL_LINE4_START_X0			SCROLL_LINE2_START_X0	  //W.R.T. MAIN (0,0)
#define SCROLL_LINE4_START_Y0			(SCROLL_LINE3_START_Y0 + SCROLL_LINE3_SECTION_SIZE_Y)//100
#define SCROLL_LINE4_SECTION_SIZE_X		SCROLL_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SCROLL_LINE4_SECTION_SIZE_Y		SCROLL_LINE2_SECTION_SIZE_Y

#define SCROLL_LINE5_START_X0			SCROLL_LINE2_START_X0	  //W.R.T. MAIN (0,0)
#define SCROLL_LINE5_START_Y0			(SCROLL_LINE4_START_Y0 + SCROLL_LINE4_SECTION_SIZE_Y)//120
#define SCROLL_LINE5_SECTION_SIZE_X		SCROLL_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SCROLL_LINE5_SECTION_SIZE_Y		SCROLL_LINE2_SECTION_SIZE_Y

#define SCROLL_LINE6_START_X0				SCROLL_LINE2_START_X0	  //W.R.T. MAIN (0,0)
#define SCROLL_LINE6_START_Y0			    (SCROLL_LINE5_START_Y0 + SCROLL_LINE5_SECTION_SIZE_Y) //140 
#define SCROLL_LINE6_SECTION_SIZE_X			SCROLL_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SCROLL_LINE6_SECTION_SIZE_Y			SCROLL_LINE2_SECTION_SIZE_Y

#define SCROLL_SECTION_START_X0			SCROLL_LINE1_START_X0	  //W.R.T. MAIN (0,0)
#define SCROLL_SECTION_START_Y0			SCROLL_LINE1_START_Y0
#define SCROLL_SECTION_SIZE_X			SCROLL_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SCROLL_SECTION_SIZE_Y			(SCROLL_LINE6_START_Y0 - SCROLL_LINE1_START_Y0 + SCROLL_LINE6_SECTION_SIZE_Y)//160-30-20=110

struct stSCROLL_DATA
{
	unsigned short TitleTextColor;
	unsigned short NormalTextColor;
	unsigned short HighlightTextColor;
	const FONT_INFO *TitleFontInfo;
	const FONT_INFO *NormalFontInfo;
	struct RectInfo *HighlightRectinfo;
	unsigned short Coordinate[MAX_SCROLL_LINE][2];//[x - Coordinate,y - Coordinate]
};
//////////////////////////// END OF FOR SCROLL MENU ////////////////////////////////
//////////////////////////// FOR SUB MENU ////////////////////////////////
#define MAX_USER_LINE					5	//including title line
#define USER_TITLE_LINE_COLOR			COLOR_BLUE
#define USER_NORMAL_LINE_COLOR          COLOR_BLACK
//#define USER_TITLE_FONTINFO_PTR         &bitstreamVeraSansMonoBold11ptFontInfo
#define USER_TITLE_FONTINFO_PTR         (&microsoftSansSerif_16ptFontInfo)
#define USER_NORMAL_FONTINFO_PTR        (&bitstreamVeraSansMonoBold11ptFontInfo)
#define USER_TITLE_FONT_WIDTH			8
#define USER_NORMAL_FONT_WIDTH          (((USER_NORMAL_FONTINFO_PTR)->charInfo)->widthBits+1)  //8

#define USER_NORMAL_BIGFONTINFO_PTR        (&verdana_12ptFontInfo)

#define USER_LINE1_START_X0				0	  //W.R.T. MAIN (0,0)    //for icon bar and title 
//#define USER_LINE1_START_Y0			(18+((DUMMY_ZONE_HEIGHT/DUMMY_ZONE_HEIGHT)*2))	
#define USER_LINE1_START_Y0				(18 + DUMMY_ZONE_HEIGHT)	
#define USER_LINE1_SECTION_SIZE_X		320	//SIZE IN PIXEL
#define USER_LINE1_SECTION_SIZE_Y		30

#define USER_LINE2_START_X0				0	  // 1 line 
#define USER_LINE2_START_Y0				(USER_LINE1_START_Y0 + USER_LINE1_SECTION_SIZE_Y) //48
#define USER_LINE2_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_LINE2_SECTION_SIZE_Y		20

#define USER_LINE3_START_X0				USER_LINE2_START_X0	  //SAME AS LINE 2
#define USER_LINE3_START_Y0				(USER_LINE2_START_Y0 + USER_LINE2_SECTION_SIZE_Y) // 68
#define USER_LINE3_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_LINE3_SECTION_SIZE_Y		USER_LINE2_SECTION_SIZE_Y

#define USER_LINE4_START_X0				USER_LINE2_START_X0	  //3rd line 
#define USER_LINE4_START_Y0				(USER_LINE3_START_Y0 + USER_LINE3_SECTION_SIZE_Y) //88
#define USER_LINE4_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_LINE4_SECTION_SIZE_Y		USER_LINE2_SECTION_SIZE_Y

#define USER_LINE5_START_X0				USER_LINE2_START_X0	  //4 line
#define USER_LINE5_START_Y0				(USER_LINE4_START_Y0 + USER_LINE4_SECTION_SIZE_Y) //108
#define USER_LINE5_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_LINE5_SECTION_SIZE_Y		USER_LINE2_SECTION_SIZE_Y

#define USER_LINE6_START_X0				USER_LINE2_START_X0	  //5 line
#define USER_LINE6_START_Y0				(USER_LINE5_START_Y0 + USER_LINE5_SECTION_SIZE_Y)  // 128
#define USER_LINE6_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_LINE6_SECTION_SIZE_Y		USER_LINE2_SECTION_SIZE_Y

#define USER_LINE7_START_X0				USER_LINE2_START_X0	  //6 line
#define USER_LINE7_START_Y0				(USER_LINE6_START_Y0 + USER_LINE6_SECTION_SIZE_Y)  // 148
#define USER_LINE7_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_LINE7_SECTION_SIZE_Y		USER_LINE2_SECTION_SIZE_Y

#define USER_SECTION_START_X0			USER_LINE1_START_X0	  
#define USER_SECTION_START_Y0			USER_LINE1_START_Y0
#define USER_SECTION_SIZE_X				USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define USER_SECTION_SIZE_Y				(USER_LINE7_START_Y0 - USER_LINE1_START_Y0 + USER_LINE7_SECTION_SIZE_Y)

// -------    Sub Menue Dispaly     like add card , Set Time Date ------------

#define GAP															5
#define SUBMENUE_LINE1_START_X0					0	  //W.R.T. MAIN (0,0)    //title line
#define SUBMENUE_LINE1_START_Y0					(STATUSBAR_HEIGHT + TITLEMSG_HEIGHT +GAP + DUMMY_ZONE_HEIGHT) // 53
#define SUBMENUE_LINE1_SECTION_SIZE_X		320	//SIZE IN PIXEL
#define SUBMENUE_LINE1_SECTION_SIZE_Y		33

#define SUBMENUE_LINE2_START_X0					0	  //W.R.T. MAIN (0,0)
#define SUBMENUE_LINE2_START_Y0					(SUBMENUE_LINE1_START_Y0 + SUBMENUE_LINE1_SECTION_SIZE_Y)  // 86
#define SUBMENUE_LINE2_SECTION_SIZE_X		USER_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SUBMENUE_LINE2_SECTION_SIZE_Y		33

#define SUBMENUE_LINE3_START_X0					SUBMENUE_LINE2_START_X0	  //SAME AS LINE 2
#define SUBMENUE_LINE3_START_Y0					(SUBMENUE_LINE2_START_Y0 + SUBMENUE_LINE2_SECTION_SIZE_Y)  // 109
#define SUBMENUE_LINE3_SECTION_SIZE_X		SUBMENUE_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SUBMENUE_LINE3_SECTION_SIZE_Y		SUBMENUE_LINE2_SECTION_SIZE_Y

#define SUBMENUE_LINE4_START_X0					SUBMENUE_LINE2_START_X0	  //W.R.T. MAIN (0,0)
#define SUBMENUE_LINE4_START_Y0					(SUBMENUE_LINE3_START_Y0 + SUBMENUE_LINE3_SECTION_SIZE_Y)  // 142
#define SUBMENUE_LINE4_SECTION_SIZE_X		SUBMENUE_LINE1_SECTION_SIZE_X	//SIZE IN PIXEL
#define SUBMENUE_LINE4_SECTION_SIZE_Y		SUBMENUE_LINE2_SECTION_SIZE_Y

#define SUBMENUE_CHAR_FONTINFO_PTR        (&vrinda_20ptFontInfo)//arial_12ptFontInfo)
#define SUBMENUE_NUMBER_FONTINFO_PTR        (&vrinda_20ptFontInfo)//)
#define SUBMENUE_NUMBER_FONT_WIDTH       (((SUBMENUE_NUMBER_FONTINFO_PTR)->charInfo)->widthBits)  
#define SUBMENUE_CHAR_FONT_WIDTH         (((SUBMENUE_CHAR_FONTINFO_PTR)->charInfo)->widthBits)  

#define STR_HIGHLIGHT_COLOUR       COLOR_GREEN    //
#define STR_UNHIGHLIGHT_COLOUR     COLOR_WHITE    
//------------------------------------------------------------------------------

#define CENTRE_OFFSET		10
#define STRING_OFFSET		CENTRE_OFFSET*2 

////////////// radio button
#define RADIOBUTTON_RADIUS1	(USER_LINE2_SECTION_SIZE_Y/2-2)
#define RADIOBUTTON_RADIUS2	(RADIOBUTTON_RADIUS1-1)
#define RADIOBUTTON_RADIUS3	(RADIOBUTTON_RADIUS2-1)
#define RADIOBUTTON_RADIUS4	(RADIOBUTTON_RADIUS3-1)
#define RADIOBUTTON_BORDER1_COLOR		COLOR_WHITE
#define RADIOBUTTON_BORDER2_COLOR		COLOR_BLACK
#define RADIOBUTTON_HIGHLIGHT_COLOR		COLOR_GREEN
#define RADIOBUTTON_NON_HIGHLIGHT_COLOR	COLOR_WHITE
////////////// End of radio button
////////////// check box button

////////////// End of check box button





//welcome msges are shown when we are on welcome screen i.e. format3
//it is just user mesage line 2 and 3
#define WELCOME_MSG_SECTION_START_X0			USER_LINE2_START_X0	  //W.R.T. MAIN (0,0)
#define WELCOME_MSG_SECTION_START_Y0			USER_LINE2_START_Y0
#define WELCOME_MSG_SECTION_SIZE_X				USER_LINE2_SECTION_SIZE_X	//SIZE IN PIXEL
#define WELCOME_MSG_SECTION_SIZE_Y				(USER_LINE3_START_Y0 - USER_LINE2_START_Y0 + USER_LINE3_SECTION_SIZE_Y)

//////////////////////////// END OF FOR SUB MENU ////////////////////////////////
////////////////////////////// START OF ICON SCREEN FOR WELCOME MODE //////////////////
#define SCREEN_ICON1_SECTION_X0			0
#define SCREEN_ICON1_SECTION_Y0         18
#define SCREEN_ICON1_SECTION_WIDTH      320
#define SCREEN_ICON1_SECTION_HEIGHT     80

//for authorised,unauthorised,enter uid,select function used for "HandleWaitForCardKeyBio()"
#define SCREEN_ICON1_X0				210
#define SCREEN_ICON1_Y0				65
#define SCREEN_ICON1_WIDTH		80 //88
#define SCREEN_ICON1_HEIGHT		80 //79

#define SCREEN_UNAUTH_WIDTH			80
#define SCREEN_UNAUTH_HEIGHT		80 //77

#define ACCESS_STRING_X0				150
#define ACCESS_STRING_Y0				(SCREEN_ICON1_Y0 + SCREEN_ICON1_HEIGHT + 5)
#define ACCESS_STRING_FONT    (&microsoftSansSerif_16ptFontInfo)
#define ACCESS_STRING_COLOR      COLOR_BLACK

////////////////////////////// END OF ICONS SCREEN FOR WELCOME MODE ////////////////////
////////////////////////////// START OF NOTIGICATION ICON AREA /////////////////////////
#define TOP_NOTIFICATION_ICON_SECTION_START_X0			0	  //W.R.T. MAIN (0,0)
#define TOP_NOTIFICATION_ICON_SECTION_START_Y0			0
#define TOP_NOTIFICATION_ICON_SECTION_SIZE_WIDTH		DISPLAY_WIDTH
#define TOP_NOTIFICATION_ICON_SECTION_SIZE_HEIGHT		SCREEN_ICON1_SECTION_Y0	

#define BOTTOM_NOTIFICATION_ICON_SECTION_START_X0		0	  //W.R.T. MAIN (0,0)
#define BOTTOM_NOTIFICATION_ICON_SECTION_START_Y0		(TOP_NOTIFICATION_ICON_SECTION_SIZE_HEIGHT+SCREEN_ICON1_SECTION_HEIGHT)
#define BOTTOM_NOTIFICATION_ICON_SECTION_SIZE_WIDTH		DISPLAY_WIDTH
#define BOTTOM_NOTIFICATION_ICON_SECTION_SIZE_HEIGHT	SCREEN_ICON1_SECTION_Y0	
//////////////////////////////// END OF NOTIGICATION ICON AREA /////////////////////////
////////////////////////////// START OF messages like *993 //////////////////
#define WELCOME_FONTINFO_PTR	(&bitstreamVeraSansMonoBold11ptFontInfo)
#define WELCOME_FONT_WIDTH		(((USER_NORMAL_FONTINFO_PTR)->charInfo)->widthBits+1)
#define WELCOME_LINE_COLOR      COLOR_BLACK

#define	WELCOME_LINE1_START_X0 			0
#define WELCOME_LINE1_START_Y0          170
#define WELCOME_LINE1_SECTION_SIZE_X    320
#define WELCOME_LINE1_SECTION_SIZE_Y    15

#define	WELCOME_LINE2_START_X0			0
#define WELCOME_LINE2_START_Y0          170
#define WELCOME_LINE2_SECTION_SIZE_X    320
#define WELCOME_LINE2_SECTION_SIZE_Y    15

////////////////////////////// END OF messages like *993 //////////////////
/************************************************************************************/
////////////////////////////// START OF TOP STATUS ICON //////////////////
#define TOP_STATUS_ICON_SECTION_X0			0
#define TOP_STATUS_ICON_SECTION_Y0         	0
#define TOP_STATUS_ICON_SECTION_WIDTH      	320
#define TOP_STATUS_ICON_SECTION_HEIGHT     	18
#define TOP_STATUS_ICON_WIDTH				16
#define TOP_STATUS_ICON_HEIGHT				16

#define TOP_STATUS_ICON1_X0			300
//#define TOP_STATUS_ICON1_Y0			1
#define TOP_STATUS_ICON1_Y0			DUMMY_ZONE_HEIGHT

#define STATUS_LOCKED        1
#define STATUS_LAN_ONLINE    2
#define STATUS_WIFI_ONLINE   3

#define MAX_STATUS_ICON		3

struct stTopStatusData
{
	unsigned short x0;
	unsigned short y0;
	unsigned char ActiveIconNum;
	unsigned char InActiveIconNum;
};

////////////////////////////// END OF TOP STATUS ICON //////////////////

struct RADIO_SCROLL_DATA
{
	char PrevSeletion;	//this value must be set by calling function   -1 indicates no selection
	char CurrSeletion; //this value must be set by calling function
	unsigned char MaxElement;	//this value must be set by calling function
	const char **Array;	//this value must be set by calling function
	unsigned char MaxScrollElement;	//this value must be set by calling function
	unsigned char PageNumber;	//this value must be set by calling function
};
#define MAX_RADIO_BUTTON_LINES	5
void DisplayDummy(void);

#endif	//#ifndef USERINTGLCD_H

