
#ifndef TCPPUSH_H_
#define TCPPUSH_H_


#define TCP_BUF_SEND               	0x01

#define USER_PORT   37

//extern volatile int EVENT_TCPPUSH;
//extern unsigned char PushConnected;
//extern volatile unsigned char PushWaitTimer,PushDelayTimer;
//extern volatile unsigned char PushConnTimeOut,PushCloseTimeOut;
extern unsigned int GetPendingTrans(unsigned int readptr,unsigned int writeptr);

#define TPUSH_STATE_INI				0	//Initial state, must be zero.
#define TPUSH_STATE_PROGRESS1		1
#define TPUSH_STATE_PROGRESS2		2
#define TPUSH_STATE_PROGRESS3		3
#define TPUSH_STATE_ERROR			4
#define TPUSH_STATE_ESTAB			5
#define TPUSH_STATE_RECEIVED		6
#define TPUSH_STATE_CLOSING			7
#define TPUSH_STATE_CONNECTED		8
#define TPUSH_STATE_CONNECT			9	//
#define TPUSH_STATE_CONNECTING		10	//
#define TPUSH_STATE_DATA_SENT_OK	11	// when data is received to server and ack is SENT FROM SERVER AND received to client
#define TPUSH_STATE_DATA_SENT_FAIL	12	// when data is SENT to server and ack is NOT RECEIVED
#define TPUSH_STATE_DATA_SENDING	13	// 
#define TPUSH_STATE_CLOSED			14	// 
#define TPUSH_STATE_CONNECT_FAIL	15	 

typedef struct stTCP_MESSAGE
{
	TCP_HEADER     tTCP_Header;                                          // reserve header space
	unsigned char  TcpPushSendBuffer[1400];
} TCP_MESSAGE;
extern TCP_MESSAGE TPushData;

extern USOCKET TCP_PUSH_socket;

extern unsigned char TPushState;
extern unsigned char TPushServerNum;
extern unsigned char TPushTempWaitDelay,TPushTempTransDelay,TPushTempCloseDelay;
extern unsigned char FContSend ;
//extern void MainLoopTcpPush(void);
void MyManagePushLogic(void);
int TPushTestListener(USOCKET Socket, unsigned char ucEvent, unsigned char *ucIp_Data, unsigned short usPortLen); 

#endif	//TCPPUSH_H_

