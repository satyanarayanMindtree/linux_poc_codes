/*
Cardmgmt.h : This file is used to sore defn of all card memory
*/

#ifdef SRC_CARDMGMT

#define EXTERN_CM	
#else
#define EXTERN_CM	extern 
#endif 

#define FLSH_APP_PAGE_SZ	528	// NGD00066
//#define FLSH_APP_PAGE_SZ	512	
/*
#define BIT_ALL_NO_CHK		0x00
#define BIT_HOLIDAY_CHK		0x01
#define BIT_DURESS_CHK		0x02
*/

#define APB_NOWHERE_USERWISE_NOCHK		0xFF 	//F0029  F0030 F0031
#define APB_NOWHERE_USERWISE_CHK		0x7F
#define APB_NO_CHK						0x80

#define BIT_APB_CHK				0x01
#define BIT_SOFT_APB_CHK		0x02
#define BIT_AREAWISE_APB_CHK	0x04


#define CARD_BIT_ALL_NO_CHK					0x00
#define CARD_BIT_HOLIDAY_CHK				0x01	// Holiday is enabled for this card
#define CARD_BIT_DURESS_CHK					0x02	// This card is Duress card
#define CHECK_FIRST_IN_USER_FOR_THIS_CRD 	0x04

// Following type indicates different type of card where we will support other options like
// Escort card. If this bit is 1 then we will use
// For Special Card meessage field will be used to indicate what type of admin card is this.
// rt now we will support just apb ignore for admin card.
#define CARD_BIT_SPECIAL_CARD				0x80


//==================== log related ==================
#define BIT_LOG_PROTOCOL	1
#define BIT_LOG_KEYPAD		2
#define BIT_LOG_INTERNAL	4
#define BIT_LOG_ALL			7

#define LOG_TYPE_PROTOCOL	1
#define LOG_TYPE_KEYPAD		2
#define LOG_TYPE_INTERNAL	3

#define LOG_CMD_ADD_CARD				0x10
#define LOG_CMD_DELETE_CARD				0x20
#define LOG_APB_ERROR					0x30
#define LOG_CMD_ADD_FINGER				0x40
#define LOG_CMD_DELETE_FINGER			0x50
#define LOG_DATAMISMATCH				0x60
//================ end of log related ===============

__packed struct CARD_FLASH_DB		//18 bytes
{
	CARDNO_DATA_STORAGE_TYPE CardNo;		//4
	unsigned char APB;		// APB			//1
	unsigned char TZ1; 		// Time zone or acces level		//1
	unsigned char TZ2; 		// Time zone or acces level		//1
  	unsigned char Holiday;	// Holiday number				//1
 	unsigned char CType; 	// Card Access bit				//1
 	unsigned char MesgInfo; // Card Message number			//1
  	WORD CardPin;   // Card Pin								//2
    unsigned long ExpDT;		// Expiary date in long format	//4
	unsigned char DrAccess;									//1
	unsigned char Group;									//1
};

//extern unsigned char tempwrbuf11[264];

__packed struct CARD_MEMORY		//5
{
	CARDNO_DATA_STORAGE_TYPE CardNo;	//4
   unsigned char APB;					//1
//	unsigned long AccessTime;				Disabled this to increase not cards in memory
};

#define CARD_RAM_DB_BYTES	sizeof(struct CARD_MEMORY)

struct CARD_MEM_HASH_DATA
{
   DWORD LastCardPtr;		// Pointer to end of card in that group
   DWORD BlankCardPtr;		// Pointer to blank card location
   DWORD BlockChkSum;		// Checkum of this block
   DWORD StartPageNo;		// Page where Flash data starts
   DWORD TotalCards;		// Total Cards in this location
   DWORD MaxCards;			// Max noof cards in this block
   unsigned long RamStartMem;		// Memory from where Ram data will start
   DWORD RamMemChksum;		// Memory from where Ram data will start
};

extern struct CARD_MEM_HASH_DATA	CardMemHashTable[MAX_CARD_BLOCKS+1];		// Cards are divided in 11 different group

#define CARD_FLASH_DB_BYTES		(sizeof(struct CARD_FLASH_DB))	  //18

#define MAX_CARD_PER_PAGE	  ((unsigned int)(FLSH_APP_PAGE_SZ / CARD_FLASH_DB_BYTES))	// 512/18=28

//ARMD0398 
//take example to solve following,  APPROX_MAX_CARD = 12000,MAX_CARD_BLOCKS=10
#define XX		((unsigned int)(APPROX_MAX_CARD/MAX_CARD_BLOCKS))	//XX= 12000/10 = 1200; this two must be integer after division
//  XX Defines No of Cards in Block for 50000cards it is 5000
#define	YY		( (unsigned int)(XX/MAX_CARD_PER_PAGE) + 1 )		//YY = 1200/29 + 1 = 42
// YY defines MAX No of pages per block  = 173  5000/29  =172.4 
#define MAX_PAGES ((unsigned int)(YY*MAX_CARD_BLOCKS))

#define MAX_CARD_PER_BLOCK	((unsigned int)(YY * MAX_CARD_PER_PAGE))	//=42*29 = 1218; this is actual card per block
// 
#define MAX_NO_OF_CARD   	((unsigned int)(MAX_CARD_PER_BLOCK * MAX_CARD_BLOCKS))
//=1218*10 = 12180; this is actual max cards,
							//which may be more then approx_max card(but must not be less)
#define MAX_PAGES_REQUIRED_FOR_CARDS	(YY*MAX_CARD_BLOCKS)	//=42*10 = 420 ;just for information display

//#define FL_PAGES_PER_CARD_BLOCK		((MAX_CARD_PER_BLOCK / (FLSH_APP_PAGE_SZ/sizeof(struct CARD_FLASH_DB)))+1 )
#define FL_PAGES_PER_CARD_BLOCK		(YY)

//========================Special Card Structure==========================	//281210-2
/*
Maximum 64 Spl card we can support
CardType ==> Will contain which type of Spl card it is
Card Info & ExtrInfo ==> will contain which action has to be taken
*/
//========================SPL=================

#define DMZ_PREWARNING_TIME	   5
#define DONOT_DISTURB_MODE_ON  1
#define DONOT_DISTURB_ZONE_ON  2

__packed struct SPL_CARD_DATA		//ARMD0459
{
	CARDNO_DATA_STORAGE_TYPE CardNo;
	unsigned int CardInfo;
	unsigned char CardType;
	unsigned char ExtraInfo;
};
extern struct SPL_CARD_DATA	SpecialCardData;
extern unsigned int TotalSplCards;

//=======================DUA Struct=====================	//281210-4

#define NORMAL_USER		0x00 
#define GROUP_ADMIN		0x01
#define SUPER_ADMIN		0x03

struct DUEL_USER_DATA
{
	CARDNO_DATA_STORAGE_TYPE CardNo;
	unsigned char DuelCType;
	unsigned char GrpInfo;
//	unsigned char MesgInfo;
};

struct FIRST_IN_USER_DATA
{
	CARDNO_DATA_STORAGE_TYPE CardNo;
	unsigned char FIU_CType;
	unsigned char MsgInfo;
};					
										
EXTERN_CM unsigned int IniCardInfo(void);
EXTERN_CM unsigned char IniCardDataStrt(void);
EXTERN_CM unsigned int TestCardMgmt(unsigned int maxcards,unsigned long cardstart,unsigned int ptr,unsigned char wrt_rd,unsigned char port);
EXTERN_CM unsigned char ReadCardDataFromFlashBlock(unsigned char block,unsigned int cardpos,struct CARD_DATA *empcard1);
EXTERN_CM unsigned char WriteCardDataToFlashBlock(unsigned char block,unsigned int cardpos,struct CARD_DATA empcard);

EXTERN_CM int DelCard(struct CARD_DATA empcard);
EXTERN_CM int AddCard(struct CARD_DATA empcard);
EXTERN_CM int CardSearch(CARDNO_DATA_STORAGE_TYPE Cardno);
EXTERN_CM int SearchDisplayCard(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard);
EXTERN_CM void PrintCardData(CardData *empcard);
EXTERN_CM int BlockCardSearch(unsigned char block,CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_FLASH_DB *cardflash);
EXTERN_CM int GetCardByIndexNo(int index,struct CARD_DATA *empcard);
EXTERN_CM void DelAllCards(void);
EXTERN_CM int GetCardByLocation(unsigned int loc,struct CARD_DATA *empcard);
//EXTERN_CM void IncDecInEmpCount(unsigned char readerno);
EXTERN_CM int AddCardAtLastAddedLoc(struct CARD_DATA empcard);
EXTERN_CM void DelAllNamesFromFlash(void);
EXTERN_CM unsigned char HandleAPBSetting(unsigned char rdno,unsigned int cardptr,struct CARD_DATA carddata);
EXTERN_CM int AddCard_Loc(int loc,struct CARD_DATA empcard);
EXTERN_CM int GetTotalNumberOfCards(void);
EXTERN_CM int SpecialCardSearch(CARDNO_DATA_STORAGE_TYPE cardno);
EXTERN_CM int SplCardSearchByIndex(unsigned int index);
EXTERN_CM int AddSpecialCard(struct SPL_CARD_DATA empcard);
EXTERN_CM void DelAllSplCard(void);
EXTERN_CM void SplCardInit(void);
EXTERN_CM unsigned char WriteSplCardDataToFlashBlock(unsigned int cardpos,struct SPL_CARD_DATA empcard);
EXTERN_CM int DelSplCard(int temp);
EXTERN_CM int DelOnlySplCard(CARDNO_DATA_STORAGE_TYPE CardNo);

