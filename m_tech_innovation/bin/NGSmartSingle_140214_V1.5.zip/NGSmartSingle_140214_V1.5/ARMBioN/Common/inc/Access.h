
#ifndef __ACCESS_H
#define __ACCESS_H


/*** BeginHeader*/
// #define I_OPortWite()


#define CARD_NOT_FOUND			-1
#define TIME_ZONE_ERROR			-2
#define HOLIDAY_NO_ACCESS		-3
#define INITIALIZATION_ERROR	-4
#define PIN_MISMATCH_ERROR		-5

#define MAX_EMP_IN_COUNT  						MAX_NO_OF_CARD
#define MAX_MINUTES_TOSAVE_EMPINCOUNT		15  
#define MAX_SECS_TOSHOW_EMPINCOUNT		15  

#define MAX_INI_NAME_LOC	2

#define NO_NAME				0
#define NAME_FROM_FLASH	    1
#define NAME_FROM_SMART     2


/*
Already defined in SmartBio.h
 #define INPUT_USER_FROM_SMART				0x01
#define INPUT_USER_FROM_WEIGAND				0x02
#define INPUT_USER_FROM_KEYBOARD			0x04
#define INPUT_USER_FROM_FINGER				0x08
#define INPUT_USER_FROM_SMART_FINGER 		0x10
#define INPUT_FROM_SLAVE_POLL				0x40

*/

#define NO_NAME						0
#define NAME_FROM_FLASH				1
#define NAME_FROM_SMART    		2
#define NAME_AS_ZICOM_EMP_NO		3
#define NAME_FROM_FL_CARDNO		5
#define NAME_FROM_SMART_CARDNO	6
#define DISPLAY_7BYTE_CSN			7	//311210-1


#define CHK_NAME_DISPLAY() 			((NAME_AS_ZICOM_EMP_NO == SysInfo.NameType) ||	\
													(SysInfo.NameType == NAME_FROM_FLASH) || 		\
                                       (SysInfo.NameType == NAME_FROM_SMART) || 		\
                                       (SysInfo.NameType == NAME_FROM_FL_CARDNO) ||	\
                                       (SysInfo.NameType == NAME_FROM_SMART_CARDNO))

#define CHK_READ_NAME_FROM_FLASH()  ((SysInfo.NameType == NAME_FROM_FLASH) || (SysInfo.NameType == NAME_FROM_FL_CARDNO))
#define CHK_READ_NAME_FROM_SMART()  ((NAME_AS_ZICOM_EMP_NO == SysInfo.NameType) || (SysInfo.NameType == NAME_FROM_SMART) || (SysInfo.NameType == NAME_FROM_SMART_CARDNO))
#define CHK_DISPLAY_NAME_CARDNO()	((SysInfo.NameType == NAME_FROM_FL_CARDNO) || (SysInfo.NameType == NAME_FROM_SMART_CARDNO))


#define INVALID_CARD_BEEP_ON      0x01  //A00017
#define VALID_CARD_BEEP_ON        0x02  //A00017


/* Current user structure hols information about Current  card and its all run time information*/
__packed typedef struct USER_CARD_INFO
{
	CardData SearchCard;
   	unsigned char InputType;
   	unsigned char UserName[MESSAGE_BYTES+1];
   	unsigned char Status;
   	int CPin;				// Current Pin
	unsigned int SearchCardPtr;
   	unsigned char RdrNo;
   	unsigned char FCode;
}_CURRENT_USER;

extern _CURRENT_USER CurrentUser;

/*------------------------------------------------------------------------*/
//New Admin Structure
//#define MAX_ADMIN_USER_NEW		8
#define MAX_ADMIN_USER_NEW		16	//ARMF0279 
#define ADMIN_DATA_BYTES_NEW	sizeof(struct ADMIN_INFO)

__packed struct ADMIN_INFO
{
	struct ADMIN_CARD_DATA AdmData;//defect:after FW upgrade user will not able to login
	unsigned int AdminType;
    unsigned int DownloadID;
};

extern struct ADMIN_INFO AdmCard;

__packed struct ACCESS_LEVEL_STR
{
	unsigned char TimeZone[MAX_READERS_SUPPORT];
};

extern struct ACCESS_LEVEL_STR AccessLevel;

#define ACCESS_LEVEL_BYTES	sizeof(struct ACCESS_LEVEL_STR)

#define SPL_CARDDATA_BYTES	sizeof(struct SPL_CARD_DATA)
#ifdef SUPPORT_NSERIES2
/*------------------------------------------------------------------------*/
// Access Date-wise/Access Month will support maximum upto 32 lavels/days
// To Enable Access Lavel Month/Date-wise TZ2 should be 254
#define MAX_ACCESS_MONTH_LEVEL	32
#define MAX_ACCESS_MONTH_DAYS		31
#define CHK_ACCESS_MONTH			254

struct ACCESS_MONTH_STR
{
	unsigned char AccessMonthLevel[MAX_ACCESS_MONTH_DAYS];
};
extern struct ACCESS_MONTH_STR AccessMonth;

#define ACCESS_MONTH_BYTES sizeof(struct ACCESS_MONTH_STR)
#endif

/*-------------------------------------------------------------------------*/
//struct  TIME_ZONE_STR
//{	unsigned char    StarHours;
//	unsigned char    StarMin;
//	unsigned char	 EndHours;
//	unsigned char	 EndMin;
//};



struct TIME_ZONE_INFO
{
	struct TIME_ZONE_STR TZSlotNo[MAX_TZ_SLOTS];  		//4 slots per day
};

typedef struct TIME_ZONE
{
	struct TIME_ZONE_INFO TimeZone[7];  		 			//week time zone
}_TIMEZONE;

extern struct DUEL_USER_DATA DuelUserData[2];
extern struct SPL_CARD_DATA	SpecialCardData;
extern _TIMEZONE Timezone;

extern unsigned short BadDataCounter, SlaveNoResponseCounter;
extern unsigned short BadDataDayCounter, NoRespDayCounter;
extern unsigned char DuelUserCounter;
#define MAX_BAD_PACKET_COUNT		5

extern BYTE UserMessage,F_UserMessageDisplay;	   //ARMD0144


#define TIME_ZONE_BYTES		sizeof(struct TIME_ZONE)
#define MAX_TZ_PER_PAGE 	(PAGE_SIZE/TIME_ZONE_BYTES)

typedef Date _STRHoliday;
extern _STRHoliday StrHoliday;
#define HOLIDAY_BYTES		sizeof(struct DATE_FORMAT)

// Following macro is used for Do not check APB Special card handling this needs to be called in
// interrupt
#define DONOT_CHECK_APB_INT(){				\
	if(F_DoNotCheckAPBForCard == SET)       \
	{ 										\
		if(DoNotCheckAPBTime != 0)        	\
			DoNotCheckAPBTime--;          	\
		else                              	\
			F_DoNotCheckAPBForCard = CLR; 	\
	}                                   	\
}
// Following type indicates different type of card where we will support other options like
// Escort card. If this bit is 1 then we will use
// For Special Card meessage field will be used to indicate what type of admin card is this.
// rt now we will support just apb ignore for admin card.
#define CARD_BIT_SPECIAL_CARD			0x80		//SPL
#define MAX_SPL_CARD					50			//SPL 	   //ARMD0459
//
//FA00130
//#define CARD_SPECIAL_APB_TYPE			1
//Special card types        
#define SP_CARD_ALERT_TYPE				0
#define SP_CARD_APB_ESCORT_TYPE			1
#define SP_CARD_INTRUSION_TYPE			2
//#define SP_CARD_OCCUPANCY_RESET_TYPE	3
#define SP_CARD_OCCUPANCY_TYPE			3
#define SP_CARD_OVERRIDE_ACCESS_TYPE	4
#define SP_CARD_FIRST_IN_USER_TYPE		5
#define SP_CARD_EMERGENCY_TYPE			6
#define SP_CARD_NORMAL_TYPE				7 	//ARMF0283 
#define SP_CARD_DMZ_RESET_TYPE          8 //Dead Man Zone Reset card
#define SP_CARD_DONOT_DSTRB_TYPE        9
#define SP_CARD_DONOT_DSTRB_ZONE_TYPE   10
/*** EndHeader */

extern void SendDoorOpen(BYTE channelno);
extern void SendDoorClose(BYTE channelno);
extern int Check_Holiday(unsigned rno);
extern short Check_Accesslevel_Timezone(BYTE channelno,BYTE TWeekDay,WORD Cardindex);
extern void Check_Free_TimeZone(BYTE TWeekDay);
extern unsigned char DoorOpenForTime(BYTE channelno);
extern int SearchDisplayCard(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard);
extern int SearchCardLastCard(void);
extern void MaxValues(void);
extern void DelAllHoliday(void);
extern void DelAllCards(void);
extern short VerifyCardInDB(DWORD cardno,BYTE channelno,BYTE TWeekDay);
extern int Check_TimeZone(BYTE TZ_No,BYTE WeekDay);
extern char CheckAPB(struct CARD_DATA empcard,BYTE ReaderNo );
extern unsigned char CheckLastCardError(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char readerno);
extern int VerifyCardData(struct CARD_DATA verifycard,BYTE readerno,BYTE CWeekDay);
extern void HandleDisplayErrorMessages(short errorvalue);
extern void Chk_Egress(void);
//extern short AddAdminUser(struct CARD_DATA empcard);
//extern short SearchAdminUser(CARDNO_DATA_STORAGE_TYPE cardno);
//extern short SearchDisplayAdminUser(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard);
//extern short DelAdminUser(struct CARD_DATA empcard);
//extern short DelAdminUserByLocation(int location);
extern int CheckFacilityCode(unsigned char readerno, unsigned char fcode);
extern void DelAllAdminUser(void);
extern void DelAllFacilityCode(void);
extern void IniDefaultSysInfo(void);
extern void DelAllDoorInfo(void);
extern void DelAllTimeZone(void);
extern void DelAllMessageToFlash(void);
extern char AddMessageToFlash(BYTE msgno,BYTE *message);
extern char GetMessageFromFlash(BYTE msgno,BYTE *message);
extern int GetCardByIndexNo(int index,struct CARD_DATA *empcard);
extern unsigned char ReadCardNoFromFlash(unsigned int cardpos,struct CARD_DATA *empcard);
extern int SearchCardFromFlash(CARDNO_DATA_STORAGE_TYPE cardno,struct CARD_DATA *empcard);
extern unsigned char AddCardNameToFlash(unsigned int cardindex,BYTE *name);
extern unsigned char ReadCardNameFromFlash(unsigned int cardindex,BYTE *name);
extern int GetAdminUserByLoc(short loc,struct ADMIN_INFO *admcard);
extern char InitialiseDefaultSelect(BYTE ini);
extern char DelAllFingers(void);
extern BYTE GetCurrentReaderNo(void);
extern void ManageAutoInOut(void);
extern int UserAccessGranted(struct USER_CARD_INFO *empcard);
extern int GetUserInfoAndProcess(CARDNO_DATA_STORAGE_TYPE cardno,struct USER_CARD_INFO *empcard,unsigned char inputtype);
extern void HandleDoorInput(void); 
extern void CARDwritetoFlash(WORD CardIndex,struct CARD_DATA empcard);

extern int SaveTimeZone(unsigned char tzno,_TIMEZONE *timez);
extern int GetTimeZone(unsigned char tzno,_TIMEZONE *timez);
extern int GetHoliday(unsigned char holidayno,unsigned char rdno,_STRHoliday *holiday);
extern int StoreHoliday(unsigned char holidayno,unsigned char rdno,_STRHoliday *holiday);
extern void CheckFreeTimeZone(unsigned char TWeekDay);
//extern void ProcessSpcialCard(struct CARD_DATA empcard,unsigned char rdno);
extern int ProcessSpcialCard(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char rdno);
extern int ProcessEscortCard(unsigned char rdno);
#ifdef SUPPORT_NSERIES2
	extern void IncDecInEmpCount(unsigned char readerno);
	extern void ValidateInEmpCount(void);
	extern void SaveInEmpCount(void);
	extern volatile BYTE DeadMenZoneSecCounter;
	extern WORD DeadMenZoneMinCounter;
	extern unsigned char F_DeadManZone,F_Spl_Crd_Dr_open;	
	extern unsigned char DoNotDisturbZone[MAX_LOCAL_READER];	
#endif//#ifdef SUPPORT_NSERIES2
#ifdef DISP_EVENT_MSGS_FROM_FLASH
extern void InitialiseDisplayErrorMsg(void);
#endif
/***********Local variable****************************************/
extern int AddNewAdminUser(struct ADMIN_INFO admcard);
extern int SearchNewAdminUser(CARDNO_DATA_STORAGE_TYPE cardno);
extern int SearchNewDisplayAdminUser(CARDNO_DATA_STORAGE_TYPE cardno,struct ADMIN_INFO *admcard);
extern int DelNewAdminUser(struct ADMIN_INFO admcard);
extern int DelNewAdminUserByLocation(int location);
void TimeBasedActions(void);
void GetSpecialCardMSG(BYTE EventNum,BYTE* message);
void DelAllTimeBasedActions(void);
extern int FinalAccessGranted(struct USER_CARD_INFO *empcard,char chno);
extern void DelAllPhas2Setting(void);


extern unsigned int InitialiseFlags;
#define DELETE_ALL_CARDS				0X1
#define DELETE_ALL_DOORINFO				0X2
#define DELETE_ALL_TIMEZONE				0X4
#define DELETE_ALL_FACILITY_CODE		0X8
#define DELETE_ALL_ADMIN_USER			0X10
#define DELETE_ALL_HOLIDAY				0X20
#define DELETE_ALL_INI_DEF_SYSTEM		0X40
#define DELETE_ALL_NAME_FROM_FLASH		0X80
#define DELETE_ALL_MSG_TO_FLASH			0X100
#define DELETE_ALL_DEF_READER_INFO		0X200
#define DELETE_ALL_FINGER				0X400
#define DELETE_ALL_SPL_CARD				0X800
#define DELETE_ALL_TIME_ACTION			0X1000
#endif//#ifndef __ACCESS_H

