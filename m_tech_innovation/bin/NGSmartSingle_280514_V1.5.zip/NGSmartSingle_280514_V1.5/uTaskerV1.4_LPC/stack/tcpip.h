/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        tcpip.h
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    16.02.2007 Add SMTP LOGIN defines
    17.02.2007 Add TFTP support defines
    15.03.2007 Add RARP and VLAN defines
    24.03.2007 Define structures to ensure packing with GNU compiler     {1}
    08.04.2007 Add fnSubnetBroadcast(), added UNETWORK_STATS
    28.04.2007 Add SNMP defines
    01.06.2007 Modify fnVerifyUser() control define                      {2}
    03.06.2007 Add fnGetFreeTCP_Port() and extend fnStartFtp() with timeout and mode
    12.07.2007 ucNegotiate no longer conditional on Telnet               {3}
    21.08.2007 Add HTTP windowing tx support (HTTP_WINDOWING_BUFFERS)    {4}
    29.08.2007 Add content size history (HTTP_WINDOWING_BUFFERS)         {5}
    03.09.2007 Add optional external retrigger of socket idle timer      {6}
    06.11.2007 Add NetBIOS support                                       {7}
    02.01.2008 Remove some packed struct defines which could cause problems with GNU compiler {8}
    06.01.2008 Add tx buffer end to fnInsertHTMLString()                 {9}
    11.01.2008 Extend HTTP struct to include user data pointer and dynamic count array {10}
    12.01.2008 Optionally pass HTTP session information to fnInsertValue(){11}
    13.01.2008 fnStartHTTP's fnInsertRoutine() parameter now uses typedef LENGTH_CHUNK_COUNT as does DynamicCnt {12}
    23.04.2008 Add INFINITE_TIMEOUT define                               {13}
    25.04.2008 Add TCP_STATE_BAD_SOCKET and fnGetTCP_state()             {14}
    18.05.2008 Modify fnEncode64() parameters for general use            {15}
    25.05.2008 Add HTTP states HTTP_STATE_POSTING_PLAIN
    02.07.2008 Add fnResetuNetwork_stats()                               {16}
    09.07.2008 Correct IPV6 length to 16                                 {17}
    07.09.2008 Add POSTING_PARAMETER_DATA_TO_APP                         {18}
    22.09.2008 Add iFetchingInternalMemory to HTTP session struct        {19}
    23.09.2008 Add HTTP state HTTP_STATE_DOING_PARAMETER_POST            {20}
    04.10.2008 Add APP_REQUEST_AUTHENTICATION                            {21}
    04.11.2008 Add conditional on FTP_DATA_WINDOWS                       {22}
    13.11.2008 Correct typo in variable name                             {23}
    13.11.2008 Add flags LAST_DYNAMIC_CONTENT_DATA and GENERATING_DYNAMIC_BINARY {24}
    01.02.2009 Add POSTING_PARTIAL_PARAMETER_DATA_TO_APP                 {25}
    13.06.2009 Add flag DELAY_DYNAMIC_SERVING                            {26}
    07.08.2009 Add SNTP_PORT UDP port number and SNTP defines            {27}
    18.11.2009 Add permanent ARP entry                                   {28}
    23.11.2009 Struct packing control removed to driver.h
    10.01.2010 Add IPV6 network settings and IPV6 structs                {29}
    12.01.2010 Add error codes SOCKET_NOT_FOUND, SOCKET_STATE_INVALID and NO_FREE_PORTS_AVAILABLE {30}
    25.01.2010 Rename fnReportWindow() to fnReportTCPWindow()            {31}
    25.01.2010 Add WINDOW_UPDATE flag                                    {32}
    25.01.2010 Add return value to fnModifyTCPWindow()                   {33}
    02.02.2010 Add IPV6 functions                                        {34}
    15.02.2010 Modify HTTP struct to allow HTTP_DYNAMIC_CONTENT to be disabled {35}
    08.11.2010 Add MAXIMUM_DYNAMIC_INSERTS                               {36}
    17.11.2010 Add optional fall-back DNS server                         {37}
    08.12.2010 Add optional HTTP session pointer passed to the HTTP generator callback {38}
    08.12.2010 Add WEB_BLACKLIST_IP flag                                 {39}
    27.03.2011 Support INDIVIDUAL_BUFFERED_TCP_BUFFER_SIZE (allowing each buffered TCP socket to have its own buffer size) {40}
    16.04.2011 Add variable HTTP port number                             {41}
    06.07.2011 Add IP_IGMP and fnHandleIGMP()                            {42}
    07.07.2011 Add fnStartZeroConfig() and fnCheckZeroConfigCollision()  {43}
    11.07.2011 Add fnActiveTCP_connections() and make fnSendARP_request() extern if USE_ZERO_CONFIG is active {44}
    03.08.2011 Add zero-configuration states                             {45}
    24.10.2011 Change fnServeDelayed() to optionally pass file string rather than just character {46}
    30.10.2011 Add extended buffered TCP options                         {47}
    11.11.2011 Add ftp client functions and callback events              {48}
    11.12.2001 Add fnTCP_IdleTimeout()                                   {49}

*/

#ifndef _TCP_IP_
#define _TCP_IP_


#define MAC_LENGTH              6                                        // Ethernet MAC hardware address length
#define IPV4_LENGTH             4                                        // IPv4
#define IPV6_LENGTH             16                                       // IPv6 {17}
#define VLAN_TAG_LENGTH         4

#define _IP6_ADD_DIGIT(x)       (unsigned char)(x >> 8), (unsigned char)(x)
#define MAX_IPV6_STRING         40                                       // maximum size of IPV6 address as terminated string

/************************** Ethernet Defines *****************************************************************/
#define    ETH_HEADER_LEN          14                                    // fixed ethernet header length
#define    ETH_MTU                 1500                                  // max ethernet frame contents length

#define    PROTOCOL_IPv4           0x0800                                // IPv4 over Ethernet    
#define    PROTOCOL_IPv6           0x86dd                                // IPv6 over Ethernet
#define    PROTOCOL_ARP            0x0806                                // ARP over Ethernet
#define    PROTOCOL_RARP           0x8035                                // RARP over Ethernet
#define    TAG_PROTOCOL_IDENTIFIER 0x8100                                // VLAN Protocol Identifier IEEE 802.1Q 

typedef struct _PACK stETHERNET_II                                       // {1}
{
    unsigned char  destination_mac_address[MAC_LENGTH];    
    unsigned char  source_mac_address[MAC_LENGTH];
    unsigned char  ethernet_type[2];
} ETHERNET_II;

typedef struct _PACK stETHERNET_CONTENT                                  // {1}
{
    unsigned char  ethernet_destination_MAC[MAC_LENGTH];                 // MAC address of destination    
    unsigned char  ethernet_source_MAC[MAC_LENGTH];                      // MAC address of source
    unsigned char  ethernet_frame_type[2];                               // Ethernet frame tye
    unsigned char  ucData[ETH_MTU];                                      // maximum ethernet data packet
} ETHERNET_FRAME_CONTENT;


#define IP_PROTOCOL_OFFSET 9                                             // fixed offset in Ethernet frame data


typedef struct _PACK stETHERNET_FRAME                                    // {1}
{
    unsigned short          frame_size;                                  // physical size of ethernet frame
    ETHERNET_FRAME_CONTENT *ptEth;                                       // pointer to the frame
} ETHERNET_FRAME;



typedef struct _PACK stETHERNET_STATS                                    // don't change order due to dynamic html references...
{
  unsigned long ulRxTot;                                                 // total frames received by the Ethernet controller
  unsigned long ulLostRx;                                                // lost frames (overrun)

  unsigned long ulRxARP;                                                 // ARP frames received for our IP address
  unsigned long ulRxICMP;                                                // ICMP frames received for our IP address
  unsigned long ulRxUDP;                                                 // UDP frames received for our IP address
  unsigned long ulRxTCP;                                                 // TCP frames received for our IP address

  unsigned long ulCheckSumError;                                         // TCP/IP frames discarded due to check sum error
  unsigned long ulOtherProtocol;                                         // Other received TCP/IP frames using non-supported protocol

  unsigned long ulForeignRxARP;                                          // foreign ARP frames seen on the network
  unsigned long ulForeignRxICMP;                                         // foreign ICMP frames seen on the network
  unsigned long ulForeignRxUDP;                                          // foreign UDP frames seen on the network
  unsigned long ulForeignRxTCP;                                          // foreign TCP frames seen on the network

  unsigned long ulTxTot;                                                 // total frames sent from the Ethernet controller
  unsigned long ulTxARP;                                                 // ARP frames sent from the Ethernet controller
  unsigned long ulTxICMP;                                                // ICMP frames sent from the Ethernet controller
  unsigned long ulTxUDP;                                                 // UDP frames sent from the Ethernet controller
  unsigned long ulTxTCP;                                                 // TCP frames sent from the Ethernet controller

  unsigned long ulOthers;                                                // non-specified Ethernet events

#ifdef USE_IPV6
  unsigned long ulRxICMPV6;                                              // total amount of ICMPV6 receptions
  unsigned long ulTxICMPV6;                                              // total amount of ICMPV6 transmissions
#endif
} ETHERNET_STATS;



// Warning: the following must match the array structure of Ethernet stats
#define TOTAL_RX_FRAMES                     0                            // HTTP a
#define TOTAL_LOST_RX_FRAMES                1                            // HTTP b
#define RECEIVED_ARP_FRAMES                 2                            // HTTP c
#define RECEIVED_ICMP_FRAMES                3                            // warning: keep order of ICMP/UDP and TCP here
#define RECEIVED_UDP_FRAMES                 4                            // HTTP e
#define RECEIVED_TCP_FRAMES                 5                            // HTTP f
#define DISCARDED_CHECKSUM_FRAMES           6                            // HTTP g
#define UNSUPPORTED_PROTOCOL_FRAMES         7                            // HTTP h

#define SEEN_FOREIGN_ARP_FRAMES             8                            // HTTP i
#define SEEN_FOREIGN_ICMP_FRAMES            9                            // ..and here
#define SEEN_FOREIGN_UDP_FRAMES             10                           // HTTP k
#define SEEN_FOREIGN_TCP_FRAMES             11                           // HTTP l
#define LAST_RX_COUNTER                     SEEN_FOREIGN_TCP_FRAMES

#define TOTAL_TX_FRAMES                     12                           // HTTP m
#define SENT_ARP_FRAMES                     13                           // HTTP n
#define SENT_ICMP_FRAMES                    14                           // HTTP o
#define SENT_UDP_FRAMES                     15                           // HTTP p
#define SENT_TCP_FRAMES                     16                           // HTTP q
#define LAST_TX_COUNTER                     SENT_TCP_FRAMES

#define TOTAL_OTHER_EVENTS                  17                           // HTTP r

// IPV6 counters
//
#define RECEIVED_ICMPV6_FRAMES              18                           // HTTP s
#define TRANSMITTED_ICMPV6_FRAMES           19                           // HTTP t



typedef struct _PACK stUNETWORK_STATS                                    // don't change order due to dynamic html references...
{
  unsigned long ulBroadcast_tx;
  unsigned long ulTx_frames;
  unsigned long ulRx_frames;      
#ifdef UPROTOCOL_WITH_RETRANS
  unsigned long ulRx_ack;
  unsigned long ulRxSynch_error;
  unsigned long ulTx_rep;
  unsigned long ulTx_lost;
  unsigned long ulTx_ack;
  unsigned long ulRx_bad_ack;
#endif
} UNETWORK_STATS;

#define UNETWORK_BROADCAST_TX               0                            // HTTP A
#define UNETWORK_TX_FRAMES                  1                            // HTTP B
#define UNETWORK_RX_FRAMES                  2                            // HTTP C
#define UNETWORK_RX_ACKS                    3                            // HTTP D
#define UNETWORK_RX_SYNCH_ERRORS            4                            // HTTP E
#define UNETWORK_TX_REPS                    5                            // HTTP F
#define UNETWORK_TX_LOST                    6                            // HTTP G
#define UNETWORK_TX_ACKS                    7                            // HTTP H
#define UNETWORK_RX_BADACK                  8                            // HTTP I

// Warning: the following must match the array structure of Ethernet stats

/************************** ARP Defines *****************************************************************/
#define ETHERNET_HARDWARE       0x0001                                   // hardware is ethernet

typedef struct _PACK stARP_FRAME                                         // {1}
{
    unsigned char ucHardwareType[2];
    unsigned char ucProtocolType[2];
    unsigned char ucHardware_size;
    unsigned char ucProtocolSize;
    unsigned char ucOpCode[2];
    unsigned char ucSenderMAC_address[MAC_LENGTH];
    unsigned char ucSender_IP_address[IPV4_LENGTH];
    unsigned char ucTargetMAC_address[MAC_LENGTH];
    unsigned char ucTarget_IP_address[IPV4_LENGTH];
} ARP_FRAME;

typedef struct _PACK stETHERNET_ARP_FRAME                                // {1}
{
    ETHERNET_II   ethernet_header;
    ARP_FRAME     arp_content;
} ETHERNET_ARP_FRAME;

typedef struct stARP_TAB                                                 // {8} don't force packed
{
    unsigned char ucState;                                               // present state of this ARP entry
    UTASK_TASK    OwnerTask;                                             // a task can be woken on low level errors
    USOCKET       OwnerSocket;                                           // a task can be informed in more detail about a specific socket
    unsigned char ucRetries;                                             // number of retries to resolve IP address
    unsigned char ucTimeToLive;                                          // remaining time to live for this entry
    unsigned char ucMac[MAC_LENGTH];                                     // MAC address of entry
    unsigned char ucIP[IPV4_LENGTH];                                     // IP address of entry
} ARP_TAB;

#ifndef MAX_HW_ADDRESS_LENGTH
    #define MAX_HW_ADDRESS_LENGTH     MAC_LENGTH
#endif

typedef struct stNEIGHBOR_TAB                                            // {34}
{
    unsigned char ucState;                                               // present state of this ARP entry
    UTASK_TASK    OwnerTask;                                             // a task can be woken on low level errors
    USOCKET       OwnerSocket;                                           // a task can be informed in more detail about a specific socket
    unsigned char ucRetries;                                             // number of retries to resolve IP address
    unsigned char ucTimeToLive;                                          // remaining time to live for this entry
    unsigned char ucHWAddress[MAX_HW_ADDRESS_LENGTH];                    // MAC address of entry
    unsigned char ucHWAddressLength;                                     // hardware address entry length
    unsigned char ucIPV6[IPV6_LENGTH];                                   // IPV6 address of entry
} NEIGHBOR_TAB;

// Arp Entry Types
//
#define ARP_FIXED_IP      0x01                                           // for Fixed addresses like GW - entry is automatically refreshed after timeout
#define ARP_TEMP_IP       0x02                                           // for Temporary addresses - entry is removed after timeout
#define ARP_PERMANENT_IP  0x04                                           // {28} for permanent addresses - these never timeout and so never need refreshing


#define NO_ARP_ENTRY          -1                                         // ARP error codes



/************************** IP Defines *****************************************************************/
#define IP_VERSION_MASK         0xf0                                     // field masks
#define IP_HEADER_LENGTH_MASK   0x0f
#define IP_MIN_HLEN             20                                       // IP Header Length in bytes (without options)
#define IP_DEFAULT_VERSION_HEADER_LENGTH  (unsigned char)(IPV4_LENGTH<<4 | (IP_MIN_HLEN/4))
#define MAX_IP_OPTLEN           40                                       // max. IP Header option field length
//#define MAX_IPV6_OPTLEN       0
#define IP_MAX_HLEN             (IP_MIN_HLEN + MAX_IP_OPTLEN)
#ifdef IP_USE_TX_OPTIONS
  #define IP_MAX_TX_HLEN        (IP_MAX_HLEN)
#else
  #define IP_MAX_TX_HLEN        (IP_MIN_HLEN)
#endif

#define IP_ICMP                 1                                        // ICMP over IP
#define IP_UDP                  17                                       // UDP over IP
#define IP_TCP                  6                                        // TCP over IP
#define IP_IGMPV2               2                                        // IGMPV2 over IP {42}
#define IP_6TO4                 41                                       // IPV6 in IPV4 tunneling
#define FOREIGN_FRAME           0x80                                     // flag used to signal that the protocol is not addressing us


// IP frament flags and fragment offset field
//
#define IP_FRAGMENT_RESERVED        0x8000                               // reserved - must be zero
#define IP_DONT_FRAGMENT            0x4000                               // don't fragment flag            
#define IP_MORE_FRAGMENTS           0x2000                               // more fragments bit            
#define IP_FRAGMENT_OFFSET_BITS     0x1FFF                               // fragment offset mask

#define TOS_NORMAL_SERVICE          0x00                                 // normal type-of-service
#define TOS_MINIMISE_DELAY          0x10
#define TOS_MAXIMISE_THROUGHPUT     0x08
#define TOS_MAXIMISE_RELIABILITY    0x04
#define TOS_MINIMISE_MONETARY_COST  0x02

#define MAX_TTL                     0x80

typedef struct _PACK stIP_PACKET                                         // {1}
{
    // IPV4 structure
    unsigned char  version_header_length;                                // version and header length
    unsigned char  differentiatedServicesField;                          // differentiated services field
    unsigned char  total_length[2];                                      // total length
    unsigned char  identification[2];                                    // identification
    unsigned char  fragment_offset[2];                                   // fragments and offset
    unsigned char  time_to_live;                                         // time to live
    unsigned char  ip_protocol;                                          // protocol eg. ICMP, UDP or TCP
    unsigned char  ip_checksum[2];                                       // header checksum
    unsigned char  source_IP_address[IPV4_LENGTH];                       // source IP address
    unsigned char  destination_IP_address[IPV4_LENGTH];                  // destination IP address
    unsigned char  ip_options[MAX_IP_OPTLEN];                            // options - if available
} IP_PACKET;

typedef struct _PACK stIP_PACKET_V6                                      // {29}
{
    // IPV6 structure
    unsigned char  version_traffic_class;                                // version and traffic class (high nibble)
    unsigned char  traffic_class_flow;                                   // traffic class (low nibble) and flow label (high nibble)
    unsigned char  flow_lable[2];                                        // flow label (lower 4 nibbles)
    unsigned char  payload_length[2];                                    // pay load length (0..64k)
    unsigned char  next_header;                                          // next header
    unsigned char  hop_limit;                                            // hop limit
    unsigned char  source_IP_address[IPV6_LENGTH];                       // source IPV6 address
    unsigned char  destination_IP_address[IPV6_LENGTH];                  // destination IPV6 address
    #ifdef MAX_IPV6_OPTLEN
    unsigned char  ip_v6_options[MAX_IPV6_OPTLEN];                       // options - if available
    #endif
} IP_PACKET_V6;
            
#define IP_VERSION_6             (6 << 4)
#define HEADER_TYPE_ICMPV6       58


#define SOURCE_LINK_LAYER_ADDRESS 1
#define TARGET_LINK_LAYER_ADDRESS 2
#define ICMPV6_OPTION_LENGTH_8    1

/************************** IGMP defines *****************************************************************/

typedef struct _PACK stIGMP_FRAME
{
    unsigned char  ucIGMPType;                                           // IGMP type
    unsigned char  ucIGMPResponseTime;                                   // maximum response time
    unsigned char  ucIGMPCheckSum[2];                                    // checksum of IGMP message
    unsigned char  ucIGMPMulticastAddress[IPV4_LENGTH];                  // multicast address
} IGMP_FRAME;

/************************** ICMP defines *****************************************************************/

#define ECHO_PING_REPLY           0x00
#define DESTINATION_UNREACHABLE   0x03
#define ECHO_PING                 0x08

#define ICMP_HEADER_LENGTH           8

#define PORT_UNREACHABLE          0x03

#define REPORTING_LENGTH_UDP_UNREACHABLE 8                               // it is typical to report first 8 bytes at least
#define ICMP_ERROR_HEADER_LENGTH         8                               // the fields from ICMP type to and including ucICMP_variable[4]

#define PING_DATA_LENGTH 26
typedef struct _PACK stPING_FRAME                                        // {1}
{
    unsigned char  ucICMPType;                                           // ICMP type
    unsigned char  ucICMPCode;                                           // ICMP code
    unsigned char  ucICMPCheckSum[2];                                    // checksum of ICMP message
    unsigned char  ucICMPIdent[2];                                       // Ping identifier
    unsigned char  ucICMPSequence[2];                                    // Ping sequence number
    unsigned char  ucICMPData[PING_DATA_LENGTH];
} PING_FRAME;

typedef struct _PACK stICMP_ERROR                                        // {1}
{
    unsigned char  ucICMPType;                                           // ICMP type
    unsigned char  ucICMPCode;                                           // ICMP code
    unsigned char  ucICMPCheckSum[2];                                    // checksum of ICMP message
    unsigned char  ucICMP_variable[4];                                   // these fields vary depending on ICMP type
    IP_PACKET      tCopy_IP_header;                                      // space for a copy of the original IP header including possible options
    unsigned char  ucIP_dataGram_contents[REPORTING_LENGTH_UDP_UNREACHABLE];
} ICMP_ERROR;

#define PING_RESULT                       1                              // ICMP internal messages
#define PING_IPV6_RESULT                  2

typedef struct _PACK stICMPV6                                            // {29}
{
    unsigned char  ucICMPV6Type;                                         // ICMPV6 type
    unsigned char  ucICMPV6Code;                                         // ICMPV6 code
    unsigned char  ucICMPV6CheckSum[2];                                  // checksum of ICMPV6 message
    unsigned char  ucICMPV6Flags[4];                                     // flags
    unsigned short target_IP_address[IPV6_LENGTH/sizeof(unsigned short)];// target IPV6 address
    unsigned char  ucICMPV6_option_type;
    unsigned char  ucICMPV6_option_length;
    unsigned char  ucICMPV6_option_data[6];                              // length defined in the option
} ICMPV6;

#define IPV6_PING_DATA_LENGTH 26                                         // data length same as 'a' .. 'z'

typedef struct _PACK stICMPV6_ECHO_REQUEST                               // {29}
{
    unsigned char  ucICMPV6Type;                                         // ICMPV6 type
    unsigned char  ucICMPV6Code;                                         // ICMPV6 code
    unsigned char  ucICMPV6CheckSum[2];                                  // checksum of ICMPV6 message
    unsigned char  ucICMPV6ID[2];                                        // ID
    unsigned char  ucICMPV6sequence[2];                                  // sequence
    unsigned char  ucICMPV6_data[IPV6_PING_DATA_LENGTH];                 // data field
} ICMPV6_ECHO_REQUEST;

// ucICMPV6Flags[0]
//
#define OVERRIDE             0x20
#define SOLICITED_RESPONSE   0x40
#define AM_ROUTER            0x80

// ICMPV6 errors according to RFC 2463
//
#define ICMPV6_ERROR_DESTINATION_UNREACHABLE                         1   // Destination Unreachable
#define ICMPV6_ERROR_PACKET_TOO_BIG                                  2   // Packet Too Big
#define ICMPV6_ERROR_TIME_EXCEEDED                                   3   // Time Exceeded
#define ICMPV6_ERROR_PARAMETER_PROBLEM                               4   // Parameter Problem


// ICMPV6 information messages
//
#define ICMPV6_TYPE_ECHO_REQUEST                                     128 // Echo Request - RFC 2463
#define ICMPV6_TYPE_ECHO_REPLY                                       129 // Echo Reply - RFC 2463
#define ICMPV6_TYPE_MULTICAST_LISTENER_QUERY                         130 // Multicast Listener Query - RFC 2710 and RFC 3810
#define ICMPV6_TYPE_V1_MULTICAST_LISTENER_REPORT                     131 // Version 1 Multicast Listener Report - RFC 2710
#define ICMPV6_TYPE_MULTICAST_LISTENER_DONE                          132 // Multicast Listener Done - RFC 2710
#define ICMPV6_TYPE_ROUTER_SOLICITATION                              133 // Router Solicitation - RFC 2461
#define ICMPV6_TYPE_ROUTER_ADVERTISEMENT                             134 // Router Advertisement - RFC 2461
#define ICMPV6_TYPE_NEIGHBOR_SOLICITATION                            135 // Neighbor Solicitation - RFC 2461
#define ICMPV6_TYPE_NEIGHBOR_ADVERTISEMENT                           136 // Neighbor Advertisement - RFC 2461
#define ICMPV6_TYPE_REDIRECT                                         137 // Redirect - RFC 2461
#define ICMPV6_TYPE_ROUTER_RENUMBERING                               138 // Router Renumbering
#define ICMPV6_TYPE_ICMP_NODE_INFO_QUERY                             139 // ICMP Node Information Query
#define ICMPV6_TYPE_ICPM_NODE_INFO_RESPONSE                          140 // ICMP Node Information Response
#define ICMPV6_TYPE_INVERSE_NEIGHBOR_DISCOVERY_SOLICITATION_MESSAGE  141 // Inverse Neighbor Discovery Solicitation Message - RFC 3122
#define ICMPV6_TYPE_INVERSE_NEIGHBOR_DISCOVERY_ADVERTISEMENT_MESSAGE 142 // Inverse Neighbor Discovery Advertisement Message - RFC 3122
#define ICMPV6_TYPE_V2_MULTICAST_LISTENER_REPORT                     143 // Version 2 Multicast Listener Report - RFC 3810
#define ICMPV6_TYPE_HOME_AGENT_ADDRESS_DISCOVERY_REQUEST_MESSAGE     144 // Home Agent Address Discovery Request Message - RFC 3775
#define ICMPV6_TYPE_HOME_AGENT_ADDRESS_DISCOVERY_REPLY_MESSAGE       145 // Home Agent Address Discovery Reply Message - RFC 3775
#define ICMPV6_TYPE_MOBILE_PREFIX_SOLICITATION                       146 // Mobile Prefix Solicitation - RFC 3775
#define ICMPV6_TYPE_MOBILE_PREFIX_ADVERTISEMENT                      147 // Mobile Prefix Advertisement - RFC 3775
#define ICMPV6_TYPE_CERTIFICATION_PATH_SOLICITATION_MESSAGE          148 // Certification Path Solicitation Message - RFC 3971
#define ICMPV6_TYPE_CERTIFICATION_PATH_ADVERTISEMENT_MESSAGE         149 // Certification Path Advertisement Message - RFC 3971
#define ICMPV6_TYPE_MULTICAST_ROUTER_ADVERTISEMENT                   151 // Multicast Router Advertisement 	
#define ICMPV6_TYPE_MULTICAST_ROUTER_SOLICITATION                    152 // Multicast Router Solicitation 	
#define ICMPV6_TYPE_MULTICAST_ROUTER_TERMINATION                     153 // Multicast Router Termination 


typedef struct _PACK stIPV6_DISCOVERY_FRAME                              // {29}
{
    ETHERNET_II    ethernetII;
    IP_PACKET_V6   ipv6;
    ICMPV6         icmpv6;
} IPV6_DISCOVERY_FRAME;


typedef struct _PACK stIPV6_DISCOVERY_FRAME_RX
{
    IP_PACKET_V6   ipv6;
    ICMPV6         icmpv6;
} IPV6_DISCOVERY_FRAME_RX;


/************************** UDP Defines *****************************************************************/

typedef struct stUDP_TAB                                                 // {8} don't force packed
{                                                                        // call back function for this socket
    int     (*fnListener)(USOCKET, unsigned char, unsigned char *, unsigned short, unsigned char *, unsigned short );
    unsigned char  ucState;                                              // present state of this UDP entry
    unsigned char  ucServiceType;                                        // type of UDP service
    unsigned short usLocalPort;                                          // local UDP port of socket
    unsigned char  ucOptions;                                            // options (checkum)
} UDP_TAB;


typedef struct _PACK stUDP_HEADER                                        // {1}
{
    unsigned short  usSourcePort;
    unsigned short  usDestinationPort;
    unsigned short  usLength;
    unsigned short  ucCheckSum;
} UDP_HEADER;

#define UDP_HLEN            8                                            // UDP Header length
#define UDP_SEND_MTU        (ETH_MTU - UDP_HLEN - IP_MAX_TX_HLEN)

#define UDP_HEADER_SPACE    0,0,0,0,0,0,0,0                              // can be used to pre-define UDP header to zero

#define UDP_OPT_SEND_CS     0x01                                         // open a socket with this option to send data with extra check sum security
#define UDP_OPT_CHECK_CS    0x02                                         // check receive check sum


#define UDP_EVENT_RXDATA                 1                               // ARP/UDP events
#define UDP_EVENT_PORT_UNREACHABLE       2
#define ARP_RESOLUTION_FAILED            3
#define ARP_RESOLUTION_SUCCESS           4
#define UDP_NO_ACK                       5
#define NN_RESOLUTION_FAILED             6
#define NN_RESOLUTION_SUCCESS            7

#define NO_LISTENER_DEFINED              -11                             // UDP error codes
#define NO_FREE_UDP_SOCKETS              -12
#define INVALID_SOCKET_HANDLE            -13
#define INVALID_LOCAL_PORT               -14
#define INVALID_DEST_IP                  -15
#define INVALID_REMOTE_PORT              -16
#define SOCKET_CLOSED                    -17
#define ZERO_PORT                        -18
#define NO_UDP_LISTENER_FOUND            -19
#define UDP_NOT_INITIALISED              -20


// Error codes
//
#define DHCP_REBOOT_REJECTED             -1
#define NO_UDP_SOCKET_FOR_DHCP           -2
#define NO_SUPPORT_FOR_DHCP_OVERLOAD     -3
#define NO_VALID_DHCP_MSG                -4
#define DHCP_ADDRESS_ALREADY_EXISTS      -5
#define INVALID_DHCP_PACKET              -6
#define NO_OPTIONS_ALLOWED_IN_DHCP_STATE -7
#define NOT_DHCP_SOCKET                  -8
#define FOREIGN_DHCP_PACKET              -9
#define BAD_MAGIC_COOKIE                 -10

// DHCP states
//
#define DHCP_INIT                        0x00                            // state not yet active
#define DHCP_STATE_INIT_REBOOT           0x01                            // initialising, trying to re-obtain parameters
#define DHCP_STATE_INIT                  0x02                            // initialising with not parameters
#define DHCP_STATE_REBOOTING             0x04                            // rebooting (with preferred parameters)
#define DHCP_STATE_SELECTING             0x08                            // selecting DHCP server
#define DHCP_STATE_REQUESTING            0x10                            // offer received from DHCP server and we are requesting
#define DHCP_STATE_BOUND                 0x20                            // we have received all parameters and are using them (possibly until lease times out)
#define DHCP_STATE_RENEWING              0x40                            // renewing after lease timeout
#define DHCP_STATE_REBINDING             0x80                            // last attempt to reobtain lease

// Zero configuration states                                             // {45}
//
#define ZERO_CONFIG_OFF                  0
#define ZERO_CONFIG_PROBING              1
#define ZERO_CONFIG_ACTIVE_DEFENDED      2                               // within a ten second period since defending the address after a previous collision
#define ZERO_CONFIG_ACTIVE               3


// SNTP defines                                                          // {27}
//
#define NTP_FLAG_LI_MASK                   0xc0                          // leap indicator mask field
#define NTP_FLAG_LI_NO_WARNING             0x00
#define NTP_FLAG_LI_61_SEC                 0x40
#define NTP_FLAG_LI_59_SEC                 0x80
#define NTP_FLAG_LI_CLOCK_NOT_SYNCHRONISED 0xc0
#define NTP_FLAG_VN_MASK                   0x38
#define NTP_FLAG_VN_3                      0x18
#define NTP_FLAG_VN_4                      0x20
#define NTP_FLAG_MODE_MASK                 0x07
#define NTP_FLAG_MODE_SYMMETRIC_ACTIVE     0x01
#define NTP_FLAG_MODE_SYMMETRIC_PASSIVE    0x02
#define NTP_FLAG_MODE_CLIENT               0x03
#define NTP_FLAG_MODE_SERVER               0x04
#define NTP_FLAG_MODE_BROADCAST            0x05
#define NTP_FLAG_MODE_RES_NTP_CONTROL      0x06
#define NTP_FLAG_MODE_RES_PRIVATE_USE      0x07

#define STRATUM_KISS_O_DEATH               0x00
#define STRATUM_PRIMARY_REFERENCE          0x01
#define STRATUM_SECONDARY_REFERENCE_MAX    0x0f

typedef struct stNTP_FRAME
{
    unsigned char  ucFlags;
    unsigned char  ucPeerClockStratum;
    unsigned char  ucPeerPollingInterval;
    unsigned char  ucPeerClockPrecision;
    unsigned char  ucRootDelay[4];
    unsigned char  ucRootDispersion[4];
    unsigned char  ucReferenceClockID[4];
    unsigned char  ucReferenceClockUpdateTime[8];
    unsigned char  ucOriginateTimeStamp[8];
    unsigned char  ucReceiveTimeStamp[8];
    unsigned char  ucTransmitTimeStamp[8];
  //unsigned char  ucKeyIndicator[4];                                    // optional for NTP authentication
  //unsigned char  ucMessageDigest[16];                                  // optional for NTP authentication
} NTP_FRAME;

typedef struct stSNTP_TIME
{
    unsigned long  ulSeconds;
    unsigned long  ulFraction;
} SNTP_TIME;


#define SNTP_SYNCHRONISED             0
#define USE_OTHER_SNTP_SERVER         -1
#define SNTP_SERVER_NOT_SYNCHRONISED  -2
#define SNTP_SERVER_FORMAT_ERROR      -3
#define SNTP_SERVER_MODE_INVALID      -4


/************************** TCP Defines *****************************************************************/

                                                                         // TCP states. The values have been carefully chosen to allow optimum program code for checking
                                                                         //             single and multiple states. DON'T CHANGE
#define TCP_STATE_FREE                 0x00                              // potential TCP socket space is free
#define TCP_STATE_RESERVED             0x01                              // TCP socket has been obtained
#define TCP_STATE_CLOSED               0x02                              // TCP socket has been bound and is in closed state
#define TCP_STATE_LISTEN               0x03                              // server has been set to the listening state and is waiting for a SYN reception (incoming connections)
#define TCP_STATE_SYN_RCVD             0x08                              // SYN has been received (either to the SYN we sent or from an incomming connection)
#define TCP_STATE_SYN_SENT             0x10                              // SYN packet sent as an attempt to establish a connection
#define TCP_STATE_FIN_WAIT_1           0x20                              // application wants to close, we have sent FIN
#define TCP_STATE_FIN_WAIT_2           0x40                              // ACK received to our FIN, wait for FIN from partner
#define TCP_STATE_CLOSING              0x80                              // doing simultaneous close; FIN received and ACK sent, waiting for final ACK to our FIN
#define TCP_STATE_CLOSE_WAIT           0x90                              // passive close. We have received a FIN and sent an ACK to it. We are waiting for our application to close.
#define TCP_STATE_LAST_ACK             0xa0                              // passive close. Our application has terminated and we have sent FIN. Waiting for final ACK to our FIN.
#define TCP_STATE_TIME_WAIT            0x04                              // active close terminated. Wait 2MSL time before allowing new connection.
#define TCP_STATE_ESTABLISHED          0xb0                              // connection established - in data transfer state
#define TCP_STATE_BAD_SOCKET           0xff                              // this state doesn't exist but this is returned by fnGetTCP_state if the socket is invalid {14}

#define TCP_FLAG_FIN                   0x01                              // protocol flag bits
#define TCP_FLAG_SYN                   0x02
#define TCP_FLAG_RESET                 0x04
#define TCP_FLAG_PUSH                  0x08
#define TCP_FLAG_ACK                   0x10

#define MIN_TCP_HLEN                   20                                // TCP header length without options
#define MAX_TCP_OPTLEN                 40                                // maximum TCP options length

#define TCP_CLOSEPENDING               0x01                              // internal flag
#define SILLY_WINDOW_AVOIDANCE         0x02                              // we are stalling the transmitter to avoid silly (small) window
#define WINDOW_UPDATE                  0x04                              // {32} windows update in progress, avaiting ARP resolution


#ifdef USE_BUFFERED_TCP                                                  // optional TCP connection buffer

typedef struct stTCP_WINDOWS_LIST                                        // {8} don't force packed
{
    unsigned short usFrameSize;                                          // the size of the frame in the buffer
//  #ifdef USE_TELNET
  #if defined USE_TELNET || defined USE_TCP_SERVER
    unsigned short usEscapeLength;                                       // the number of escaped characters in the output buffer
  #endif
    unsigned char  ucNegotiate;                                          // details about negotiation content {3}
    unsigned char  ucWindowTimeout;                                      // monitor ack timeouts for each window
} TCP_WINDOWS_LIST;

 typedef struct stTCP_TX_BUFFER                                          // {8} don't force packed
 {   
    unsigned char  *ucDataStart;
    unsigned char  *ucDataEnd;     
    unsigned short usPacketSize;
    unsigned short usWaitingSize;
#ifdef SUPPORT_PEER_WINDOW
    unsigned short usOpenBytes;                                          // total bytes not yet acked
    unsigned char  ucCwnd;                                               // congestion window count
    unsigned char  ucOpenAcks;                                           // total frames not yet acked
    unsigned char  ucPutFrame;                                           // tx_window for next use
    unsigned char  ucGetFrame;                                           // first outstanding tx_window
    TCP_WINDOWS_LIST tx_window[WINDOWING_BUFFERS];                       // window management
#endif
#ifdef WAKE_BLOCKED_TCP_BUF
    UTASK_TASK     WakeTask;
#endif
#ifdef INDIVIDUAL_BUFFERED_TCP_BUFFER_SIZE                               // {40}
    unsigned char  *ucTCP_tx;                                            // pointer to the location of the buffered TCP buffer
#else
    unsigned char  ucTCP_tx[TCP_BUFFER];                                 // buffered TCP buffer as part of the TCP_TX_BUFFER struct
#endif
 } TCP_TX_BUFFER;
#endif


typedef struct _PACK stTCP_HEADER                                        // header define for transmitter use {1}
{
    unsigned char  ucLocalPort[2];                                       // elements are defines in bytes to ensure correct length
    unsigned char  ucRemotePort[2];
    unsigned char  ucUnacked[4];
    unsigned char  ucRxNext[4];
    unsigned char  ucLen;
    unsigned char  ucFlags;
    unsigned char  ucDefMTU[2];
    unsigned char  ucCheckSum[2];
    unsigned char  ucUrgent[2];
} TCP_HEADER;

typedef struct stTCP_CONTROL                                             // {8} don't force packed
{
    unsigned long  ulNextTransmissionNumber;                             // sequence number to be sent next
    unsigned long  ulNextReceptionNumber;                                // sequence number which we expect to receive
    unsigned long  ulSendUnackedNumber;                                  // ack number to be sent
    int (*event_listener)(USOCKET, unsigned char, unsigned char *, unsigned short);
#ifdef USE_BUFFERED_TCP
    TCP_TX_BUFFER  *ptrTCP_Tx_Buffer;                                    // optional transmit buffer pointer
#endif
    unsigned short usRemport;                                            // remote TCP port
    unsigned short usLocport;                                            // local TCP port
    unsigned short usIdleTimeout;                                        // timeout in seconds until the TCP connection timeout without activity
    unsigned short usLinkTimer;                                          // Counter for the idle timer
    unsigned short usTransmitTimer;                                      // counter for the retransmit
#ifdef CONTROL_WINDOW_SIZE
    unsigned short usRxWindowSize;                                       // space in our receiver
    #if defined HTTP_WINDOWING_BUFFERS || defined  FTP_DATA_WINDOWS      // {4}{22}
        unsigned char  ucPersistentTimer;                                // persistent timer count down
        unsigned char  ucProbeCount;                                     // persistent probe exponential backof index
    #endif
#endif
#ifdef SUPPORT_PEER_WINDOW
    unsigned short usTxWindowSize;                                       // space in peer's receiver
#endif
#ifdef SUPPORT_PEER_MSS
    unsigned short usPeerMSS;                                            // the maximum segment size that our peer can accept
#endif
#if defined HTTP_WINDOWING_BUFFERS || defined  FTP_DATA_WINDOWS          // {22}
    unsigned short usOpenCnt;                                            // {4}
#endif
#if defined USE_BUFFERED_TCP && defined INDIVIDUAL_BUFFERED_TCP_BUFFER_SIZE // {40}
    unsigned short usTCP_buffer_length;                                  // length of the buffered TCP buffer associated with this socket
#endif
    unsigned char  ucTCP_state;                                          // TCP socket state
    unsigned char  ucSendFlags;                                          // flags to be sent in the control message
    unsigned char  ucRemoteIP[IPV4_LENGTH];                              // our peers IP address
    unsigned char  ucTos;                                                // type of service
    unsigned char  ucRetransmissions;                                    // number of retransmissions left before aborting
    unsigned char  ucTCPInternalFlags;                                   // Internal flags for software control
    USOCKET        MySocketNumber;                                       // save socket number also in structure for convenience */
} TCP_CONTROL;


typedef struct _PACK stTCP_PACKET                                        // {1}
{
  unsigned short usSourcePort;                                           // the source port which sent the TCP packet
  unsigned short usDestPort;                                             // the port it is sending the TCP packet to
  unsigned long  ulSeqNr;                                                // sequence number of data
  unsigned long  ulAckNo;                                                // acknowledge number of data
  unsigned short usHeaderLengthAndFlags;                                 // length of data and optional flags
  unsigned short usWindowSize;                                           // advertised window size
  unsigned short usChecksum;                                             // TCP frame check sum
  unsigned short usUrgentPointer;                                        // urgent data pointer (when URG flag is set)
//unsigned char  ucOptData[MAX_TCP_OPTLEN];                              // possible TCP options (since we do not use them we do not save them)
} TCP_PACKET;



#define TCP_DEF_RETRIES         7                                        // packets will be retransmitted this amount of times
#define TCP_CON_ATTEMPTS        7                                        // connection attempts will stop after this amount of tries

#define TCP_PORTS_START         49152                                    // start in dynamic port range
#define TCP_PORTS_END           65535                                    // end in dynamic port range


// Timeouts (in seconds)
//
#define TCP_INIT_RETRY_TOUT     1                                        // initial SYN retry timeout
#define TCP_SYN_RETRY_TOUT      2                                        // normal SYN retry timeout
#define TCP_STANDARD_RETRY_TOUT 3                                        // normal TCP packet retry timeout
#define TCP_SILLY_WINDOW_DELAY  5                                        // wait for this time when avoiding silly windows
#define TCP_FIN_WAIT_2_TIMEOUT  60                                       // we don't allow blocking in this state so set  a reasonable timeout
#define TCP_DEFAULT_TIMEOUT     120                                      // connection timeout with no activity
#define TCP_MSL_TIMEOUT         2                                        // 2MSL is twice this timeout - normally this should be about 1min
                                                                         // but it is a problem if we have a limited amount of sockets and will cause
                                                                         // the web server (for example) to not be able to respond until the timeout passes.
                                                                         // since the chance of problems with shorter times is very small (in LANs especially)
                                                                         // we prefer fast reactivation and a low count of sockets

#define TCP_EVENT_ABORT                     1                            // TCP EVENTS
#define TCP_EVENT_CONNECTED                 2
#define TCP_EVENT_ACK                       3
#define TCP_EVENT_DATA                      4
#define TCP_EVENT_CLOSE                     5
#define TCP_EVENT_CLOSED                    6
#define TCP_EVENT_REGENERATE                7
#define TCP_EVENT_CONREQ                    8
#define TCP_EVENT_ARP_RESOLUTION_FAILED     9
#define TCP_EVENT_PARTIAL_ACK               10
#define TCP_WINDOW_UPDATE                   11                           // {4}
#define TCP_WINDOW_PROBE                    12                           // {4}

#define APP_ACCEPT                          0x00                         // TCP listener return values
#define APP_SENT_DATA                       0x01
#define APP_REJECT                          0x02
#define APP_WAIT                            0x04
#define APP_REQUEST_CLOSE                   0x08
#define APP_REJECT_DATA                     0x10
#define HANDLING_PARTICAL_ACK               0x20
#define APP_REQUEST_AUTHENTICATION          0x40                         // {21}


#define NO_TCP_LISTENER_INSTALLED          -1                            // TCP error codes
#define NO_TCP_SOCKET_FREE                 -2
#define SOCKET_NOT_FOUND                   -3                            // {30}
#define SOCKET_STATE_INVALID               -4                            // {30}
#define NO_FREE_PORTS_AVAILABLE            -5                            // {30}

/************************** TELNET Defines ***************************************************************/

#define TELNET_IAC            255
#define TELNET_DONT           254
#define TELNET_DO             253
#define TELNET_WONT           252
#define TELNET_WILL           251
#define TELNET_SB             250                                        // start sub negotiation
#define TELNET_GO_AHEAD       249
#define TELNET_ERASE_LINE     248
#define TELNET_ERASE_CHAR     247
#define TELNET_AYT            246                                        // Are You There?
#define TELNET_ABORT_OUTPUT   245
#define TELNET_INTERRUPT_PROC 244
#define TELNET_BREAK          243
#define TELNET_DATA_MARK      242                                        // data stream portion of sync - always TCP urgent notification
#define TELNET_NOP            241
#define TELNET_SE             240                                        // end sub negotiation
#define TELNET_EOR            239                                        // end of record
#define TELNET_ABORT          238
#define TELNET_SUSP           237                                        // suspend current process
#define TELNET_EOF            236                                        // end of file


#define TELNET_BINARY                   0
#define TELNET_ECHO                     1
#define TELNET_RECONNECTION             2
#define TELNET_SUPPRESS_GO_AHEAD        3
#define TELNET_APPROX_MSG_SIZE          4
#define TELNET_STATUS                   5
#define TELNET_TIMING_MARK              6
#define TELNET_REM_TRANS_ECHO           7
#define TELNET_OUTPUT_LINE_WIDTH        8
#define TELNET_OUTPUT_PAGE_SIZE         9
#define TELNET_OUTPUT_CR_DISP          10
#define TELNET_OUTPUT_TAB_STOPS        11
#define TELNET_OUTPUT_HOR_TAB_DISP     12
#define TELNET_OUTPUT_FORMFEED_DISP    13
#define TELNET_OUTPUT_VER_TAB_STOPS    14
#define TELNET_OUTPUT_VER_TAB_DISP     15
#define TELNET_OUTPUT_LF_DISP          16
#define TELNET_EXTENDED_ASCII          17
#define TELNET_LOGOUT                  18
#define TELNET_BYTE_MACRO              19
#define TELNET_DATA_ENTRY_TERMINAL     20
#define TELNET_SUPDUP                  21
#define TELNET_SUPDUP_OUTPUT           22
#define TELNET_SEND_LOCATION           23
#define TELNET_TERMINAL_TYPE           24
#define TELNET_END_OF_RECORD           25
#define TELNET_TACACS_USER_ID          26
#define TELNET_OUTPUT_MARKING          27
#define TELNET_TERMINAL_LOC_NUMBER     28
#define TELNET_3270_REGIME             29
#define TELNET_X_3_PAD                 30
#define TELNET_NEG_WINDOW_SIZE         31
#define TELNET_TERMINAL_SPEED          32
#define TELNET_REMOTE_FLOW_CONTROL     33
#define TELNET_LINEMODE                34
#define TELNET_X_DISPLAY_LOCATION      35
#define TELNET_ENVIRONMENT_OPTION      36
#define TELNET_AUTHENTICATION_OPTION   37
#define TELNET_ENCRYPTION_OPTION       38
#define TELNET_NEW_ENVIRONMENT_OPTION  39
#define TELNET_TN3270E                 40


// Telnet commands
//
#define GOTO_ECHO_MODE                 0
#define LEAVE_ECHO_MODE                1
#define PASSWORD_ENTRY                 2
#define CLEAR_TEXT_ENTRY               3
#define TELNET_ASCII_MODE              4
#define TELNET_RAW_MODE                5
#define TELNET_RAW_RX_IAC_ON           6
#define TELNET_RAW_RX_IAC_OFF          7
#define TELNET_RAW_TX_IAC_ON           8
#define TELNET_RAW_TX_IAC_OFF          9
#define TELNET_RESET_MODE              10

// Telnet modes
//
#define TELNET_DO_ECHO                 0x0001
//#define TELNET_TELNET_SOCKET         0x0002
#define TELNET_RAW_SOCKET              0x0004
#define TELNET_COMMAND_MODE            0x0008
#define TELNET_WILL_ECHO               0x0010
#define PASSWORD_ENTRY_MODE            0x0020
#define TELNET_WONT_ECHO               0x0040
#define TELNET_BINARY_MODE             0x0080
#define TELNET_BIN_RX_IAC              0x0100
#define TELNET_BIN_TX_IAC              0x0200
#define TELNET_STUFF_TX_IAC            0x0400
#define TELNET_SEARCH_RX_IAC           0x0800

typedef struct stTELNET                                                  // {8} don't force packed
{
  int (*fnApp)(USOCKET, unsigned char, unsigned char *, unsigned short);
  unsigned short usTelnetMode;
  unsigned short usTelnetPortNumber;
  unsigned short usMaxWindow;
  USOCKET        Telnet_socket;
  unsigned char  ucState;
  UTASK_TASK     wakeOnAck;
} TELNET;

/************************** HTTP Defines *****************************************************************/

typedef struct stHTTP                                                    // {8} don't force packed
{
#ifdef SUPPORT_HTTP_POST
    MEMORY_RANGE_POINTER ptrFile;
#endif
    MEMORY_RANGE_POINTER ptrFileStart;
#if defined HTTP_DYNAMIC_CONTENT && defined HTTP_USER_DETAILS            // {10}
    void *ptrUserData;                                                   // pointer to memory containing connection details needed by application
#endif
#if defined HTTP_DYNAMIC_CONTENT || defined HTTP_WINDOWING_BUFFERS       // {35}
    #ifdef HTTP_WINDOWING_BUFFERS
    LENGTH_CHUNK_COUNT DynamicCnt[1 + HTTP_WINDOWING_BUFFERS];           // reference during dynamic content generation {10} array {12}
    #else
    LENGTH_CHUNK_COUNT DynamicCnt[2];                                    // {12}
    #endif
#endif
    MAX_FILE_LENGTH FileLength;
    MAX_FILE_LENGTH FilePoint;
    unsigned short usUnacked;
    USOCKET        OwnerTCPSocket;
    unsigned char  ucState;
#ifdef SUPPORT_MIME_IDENTIFIER
    unsigned char  ucMimeType;                                           // file type
#endif
#ifdef HTTP_AUTHENTICATION
    #define USER_PASS_LENGTH                 24                          // base 64 coded user and pass of each 8 bytes need this amount of coded space. ((name length + 1 + password length) * 8)/6) rounded up to nearest 2
    CHAR           cUserPass[USER_PASS_LENGTH];                          // we must save parts of authentication frames
    unsigned char  ucAuth;                                               // authorisation counter
#endif
#ifdef HTTP_WINDOWING_BUFFERS                                            // {4} Raw data size
    unsigned short usUnackedPrevious;                                    // previous unacked window (we only support 2 at present)
    unsigned short usUnackedPreviousContent;                             // {5} Content data size (can be different when dynmically filled)
    unsigned char  ucOpenWindows;                                        // the number of open acks when sending using windowing
#endif
#ifdef HTTP_DYNAMIC_CONTENT
    #ifdef HTTP_WINDOWING_BUFFERS
    unsigned char  ucPresentFrame;                                       // counter of frame in a windowing sequence
    #endif
    unsigned char  ucDynamicFlags;                                       // special flags helpful when generating dynamic data {23 - corrected from ucDymamic}
#endif
#ifdef SUPPORT_HTTP_POST
    unsigned char  ucBoundaryLength;                                     // length of boundary identifier used in post
    CHAR           cDisplayFile;                                         // file to be returned after posting
    #ifdef SUB_FILE_SIZE
    unsigned char  ucSubFileWrite;                                       // write to sub-file is in progress
    #endif
#endif
#ifdef HTTP_UTFAT
    UTFILE         utFile;
#endif
#ifdef _WINDOWS                                                          // {19}
    int iFetchingInternalMemory;
#endif
} HTTP;

#ifdef HTTP_DYNAMIC_CONTENT
  #define QUIT_FRAME_DURING_GENERATION  0x01                             // flag used to quit frame filling during dynamic content generation
  #define NO_DYNAMIC_CONTENT_TO_ADD     0x02                             // flag used to ignore generation - can be used by application
  #define LAST_DYNAMIC_CONTENT_DATA     0x04                             // {24} flag that this is the last chunk of data to send - it avoids padding being added, which may corrupt binary content
  #define GENERATING_DYNAMIC_BINARY     0x08                             // {24} flag that the user is generating binary data rather than HTML content. This is used to avoid probing with HTML character
  #define DELAY_DYNAMIC_SERVING         0x10                             // {26} flag that the user requires the HTTP connection to pause before sending more content
  #define MAXIMUM_DYNAMIC_INSERTS       0x20                             // {36} flag that no further dynamic inserts should be started in the present TCP frame
#endif

#define HTTP_STATE_FREE                 0                                // HTTP states
#define HTTP_STATE_RESERVED             1
#define HTTP_STATE_ACTIVE               2
#define HTTP_STATE_REQUEST_CREDS        3
#define HTTP_STATE_PROCESSING           4
#define HTTP_STATE_START_POST           5
#define HTTP_STATE_POSTING              6
#define HTTP_STATE_BEGIN_POSTING        7
#define HTTP_STATE_READY_POSTING        8
#define HTTP_STATE_POSTING_DATA         9
#define HTTP_STATE_DUMPING_DATA         10
#define HTTP_STATE_POSTING_TO_APP       11
#define HTTP_STATE_DELAYED_SERVING      12
#define HTTP_STATE_POSTING_PLAIN        13
#define HTTP_STATE_DOING_PARAMETER_POST 14                               // {20}

#define CREDENTIALS_REQUIRED           -1                                // user return codes
#define DISPLAY_INTERNAL               -2
#define PROCESSING_INPUT               -3
#define DELAY_SERVING                  -4

#define CAN_POST_BEGIN                (unsigned char)-1
#define INFORM_POST_SUCCESS           (unsigned char)-2
#define INFORM_POST_FAILED            (unsigned char)-3
#define POSTING_DATA_TO_APP           (unsigned char)-4
#define POSTING_PARAMETER_DATA_TO_APP (unsigned char)-5                  // {18}
#define POSTING_PARTIAL_PARAMETER_DATA_TO_APP (unsigned char)-6          // {25}

/************************** SMTP ************************************************************************************/

#define ERROR_SMTP_NOT_READY      -1
#define ERROR_SMTP_IN_USE         -2

// SMTP modes
//
#define SMTP_LOGIN                  0x01                                 // use LOGIN authentication

// Call back events
//
#define SMTP_GET_DOMAIN             1
#define SMTP_GET_SENDER             2
#define SMTP_GET_DESTINATION        3
#define SMTP_GET_SUBJECT            4
#define SMTP_SEND_MESSAGE           5
#define SMTP_USER_NAME              6
#define SMTP_USER_PASS              7

#define SMTP_MAIL_SUCCESSFULLY_SENT 8

#define ERROR_SMTP_ARP_FAIL         10
#define ERROR_SMTP_TIMEOUT          11
#define ERROR_SMTP_HOST_CLOSED      12
#define ERROR_SMTP_LOGIN_FAILED     13
#define ERROR_SMTP_LOGIN_NOT_SUPPORTED 14
#define ERROR_SMTP_POLICY_REJECT    15

/************************** POP3 ************************************************************************************/

#define ERROR_POP3_NOT_READY       -1
#define ERROR_POP3_IN_USE          -2

// Call back events
//
#define POP3_USER_NAME              1
#define POP3_USER_PASS              2
#define POP3_WAITING_MESSAGES       3
#define POP3_RX_MESSAGE             4
#define POP3_RX_MESSAGE_END         5
#define POP3_SEARCH_SUBJECT         6
#define POP3_RX_SUBJECT             7
#define POP3_GOOD_SUBJECT           8
#define POP3_RX_TINY_MESSAGE        9
#define POP3_RX_MESSAGE_START       10
#define POP3_DELETE_MESSAGE         11
#define POP3_CONNECTION_CLOSED      12

#define ERROR_POP3_ARP_FAIL         30
#define ERROR_POP3_TIMEOUT          31
#define ERROR_POP3_DIDNT_UNDERSTAND 32
#define ERROR_POP3_HOST_CLOSED      33

/************************** DNS *************************************************************************************/

// Call back events
//
#define DNS_EVENT_SUCCESS           1

#define DNS_ERROR_NO_ARP_RES        10
#define DNS_ERROR_TIMEOUT           11
#define DNS_ERROR_GENERAL           12
#define DNS_OPCODE_ERROR            13

/************************** TFTP ************************************************************************************/

// Codes
//
#define TFTP_OPCODE_RRQ       1
#define TFTP_OPCODE_WRQ       2
#define TFTP_OPCODE_DATA      3
#define TFTP_OPCODE_ACK       4
#define TFTP_OPCODE_ERROR     5

// TFTP error codes
//
#define TFTP_NON_DEFINED_SEE_ERROR_MSG     0 
#define TFTP_FILE_NOT_FOUND                1
#define TFTP_ACCESS_VIOLATION              2
#define TFTP_DISK_FULL                     3
#define TFTP_ILLEGAL_OPERATION             4
#define TFTP_UNKNOWN_TRANSFER_ID           5
#define TFTP_FILE_ALREADY_EXISTS           6
#define TFTP_NO_SUCH_USER                  7
#define TFTP_FILE_NOT_EQUAL                8

// Callback codes
//
#define TFTP_CLIENT_ERROR             0x8000                             // flag to inform client side error
#define TFTP_TRANSFER_DID_NOT_START   (TFTP_CLIENT_ERROR | 0x100)        // call back messages
#define TFTP_TRANSFER_READ_COMPLETE   0x101                              // non-error
#define TFTP_TRANSFER_WRITE_COMPLETE  0x102                              // non-error
#define TFTP_FILE_EQUALITY            0x103                              // non-error
#define TFTP_ARP_RESOLUTION_FAILED    0x104                              // TFTP server could not be resolved at ARP level. Probably doesn't exist.
#define TFTP_ARP_RESOLVED             0x105                              // when acting as a client this can occur on transfer initialisation. The user should restart the request, which will then complete
#define TFTP_DESTINATION_UNREACHABLE  0x106                              // no port listening


/************************** FTP client *****************************************************************************/

// Callback codes                                                        {48}
//
#define FTP_CLIENT_EVENT_REQUEST_FTP_USER_NAME     0x0001                // application should return user name as string (null pointer or zero length for anonymous login)
#define FTP_CLIENT_EVENT_REQUEST_FTP_USER_PASSWORD 0x0002                // application should return user password as string
#define FTP_CLIENT_EVENT_LOGGED_IN                 0x0004                // successfully logged into FTP server
#define FTP_CLIENT_EVENT_LOGGED_FAILED             0x0080                // FTP server login failed
#define FTP_CLIENT_EVENT_CONNECTION_CLOSED         0x0005                // FTP server control connection closed
#define FTP_CLIENT_EVENT_ACTIVE_PASSIVE_LIST       0x0040                // application should return 0 for listing in passive mode or non-zero for listing in active mode
#define FTP_CLIENT_USER_NAME_ERROR                 0x0081                // login error - user name invalid
#define FTP_CLIENT_USER_PASS_ERROR                 0x0082                // login error - password invalid
#define FTP_CLIENT_EVENT_LISTING_DATA              0x0041                // received data from a listing passed to application
#define FTP_CLIENT_EVENT_GET_DATA                  0x0042                // received data from a get passed to application
#define FTP_CLIENT_EVENT_PUT_CAN_START             0x8001                // the data connection is ready and the application can now start sending data
#define FTP_CLIENT_EVENT_APPEND_CAN_START          0x8002                // the data connection is ready and the application can now start sending data
#define FTP_CLIENT_EVENT_DATA_CONNECTION_FAILED    0x0100                // data connection not possible for listing
#define FTP_CLIENT_EVENT_LOCATION_SET              0x0020                // new directory location successfully set
#define FTP_CLIENT_EVENT_LISTING_DATA_COMPLETE     0x0021                // listing completely received
#define FTP_CLIENT_EVENT_PUT_DATA_COMPLETE         0x0022                // put completed sucessfully
#define FTP_CLIENT_EVENT_APPEND_DATA_COMPLETE      0x0023                // append completed sucessfully
#define FTP_CLIENT_EVENT_GET_DATA_COMPLETE         0x0024                // get completely received
#define FTP_CLIENT_EVENT_DIR_CREATED               0x0025                // new directory was successfully created
#define FTP_CLIENT_EVENT_DIR_DELETED               0x0026                // empty directory successfully deleted
#define FTP_CLIENT_EVENT_FILE_DELETED              0x0027                // file successfully deleted
#define FTP_CLIENT_EVENT_RENAMED                   0x0028                // file or directory successfully renamed
#define FTP_CLIENT_EVENT_DATA_CONNECTED            0x0043                // data port connection has been successfully established
#define FTP_CLIENT_EVENT_DATA_SENT                 0x0044                // previous tcp packet was acknowledged
#define FTP_CLIENT_EVENT_DATA_DISCONNECTED         0x0045                // data connection closed
#define FTP_CLIENT_EVENT_DATA_LOST                 0x0083                // previous tcp packet was lost and needs to be repeated
#define FTP_CLIENT_EVENT_ACTIVE_LISTEN_DATA        0x0400                // the application should set a listening TCP port on the port passed number for active FTP server data connection
#define FTP_CLIENT_EVENT_PASSIVE_CONNECT_DATA      0x0800                // details of data connection passed to application to establish its own TCP connection
#define FTP_CLIENT_EVENT_FLAG_ASCII_MODE           0x1000                // the mode is ASCII rather than binary
#define FTP_CLIENT_EVENT_FLAG_PUT_DIRECTION        0x2000                // the data transfer direction is to the FTP server rather than from it
#define FTP_CLIENT_EVENT_FLAG_LISTING              0x4000                // the data is listing and not file content
#define FTP_CLIENT_ERROR_RENAMING_FILE             0x0200                // ftp command errors
#define FTP_CLIENT_ERROR_CREATING_DIRECTORY        0x0201
#define FTP_CLIENT_ERROR_DELETING_DIR              0x0202
#define FTP_CLIENT_ERROR_DELETING_FILE             0x0203
#define FTP_CLIENT_ERROR_SETTING_LOCATION          0x0204
#define FTP_CLIENT_ERROR_SETTING_MODE              0x0205
#define FTP_CLIENT_ERROR_SETTING_PORT              0x0206
#define FTP_CLIENT_ERROR_PASSIVE_MODE              0x0207
#define FTP_CLIENT_ERROR_LISTING                   0x0208
#define FTP_CLIENT_ERROR_APPENDING                 0x0209
#define FTP_CLIENT_ERROR_PUTTING                   0x020a
#define FTP_CLIENT_ERROR_GETTING                   0x020b
#define FTP_CLIENT_ERROR_FLAG                      0x0200                // flag in the code signalling an ftp error

typedef struct stTCP_CLIENT_MESSAGE_BOX
{
    int            iCallbackEvent;                                       // event
    unsigned char *ptrData;                                              // pointer to data
    unsigned short usDataLength;                                         // lenght of data
    unsigned short usDataPort;                                           // data port number
    unsigned char  ucIP_data_address[IPV4_LENGTH];                       // IP address for use by the data connection
    USOCKET        uDataSocket;                                          // FTP client data socket
    USOCKET        uControlSocket;                                       // FTP client control socket
} TCP_CLIENT_MESSAGE_BOX;


/************************** SNMP ************************************************************************************/

#define SNMPV1                       0
#define SNMPV2                       1

#define SNMP_ERROR_STATUS_NO_ERROR      0
#define SNMP_ERROR_STATUS_TOO_BIG       1
#define SNMP_ERROR_STATUS_NO_SUCH_NAME  2
#define SNMP_ERROR_STATUS_BAD_VALUE     3
#define SNMP_ERROR_STATUS_READ_ONLY     4
#define SNMP_ERROR_STATUS_GENERAL_ERROR 5

#define SNMP_GET_REQUEST             0
#define SNMP_GET_NEXT_REQUEST        1
#define SNMP_GET_RESPONSE            2
#define SNMP_SET_REQUEST             3
#define SNMP_TRAP                    4

#define ASN1_SNMP_GET_REQUEST        0xa0
#define ASN1_SNMP_GET_NEXT_REQUEST   0xa1
#define ASN1_SNMP_GET_RESPONSE       0xa2
#define ASN1_SNMP_SET_REQUEST        0xa3
#define ASN1_SNMP_TRAP               0xa4

#define ASN1_SEQUENCE     0x30

#define ASN1_INTEGER      0x02
#define ASN1_BIT_STRING   0x03
#define ASN1_OCTET_STRING 0x04
#define ASN1_NULL         0x05
#define ASN1_OBJECT_IDENT 0x06
#define ASN1_IP_ADDRESS   0x40
#define ASN1_TIME_STAMP   0x43

// Traps
#define SNMP_COLDSTART               0
#define SNMP_WARMSTART               1
#define SNMP_LINK_DOWN               2
#define SNMP_LINK_UP                 3
#define SNMP_AUTH_FAILURE            4
#define SNMP_EGP_NEIGHBORLOSS        5
#define SNMP_ENTERPRISE_SPECIFIC     6

// Callback codes
//
#define SNMP_COMMUNITY_CHECK         0
#define SNMP_GET_ENTERPRISE          1
#define SNMP_GET_COMMUNITY           2

/************************** Well known Port numbers *****************************************************************/

// UDP ports
//
#define DNS_UDP_PORT               53
#define DHCP_SERVER_PORT           67
#define DHCP_CLIENT_PORT           68
#define TFTP_SERVER_PORT           69
#define SNTP_PORT                  123                                   // {27}
#define NetBIOS_PORT               137                                   // {7}
#define SNMP_AGENT_PORT            161
#define SNMP_MANAGER_PORT          162

// TCP ports
//
#define FTP_DATA_PORT              20
#define FTP_CONTROL_PORT           21
#define TELNET_SERVERPORT          23
#define SMTP_PORT                  25
#define TIME_PORT                  37
#define HTTP_SERVERPORT            80
#define POP_PORT                   110


/* =================================================================== */
/*                      global function definitions                    */
/* =================================================================== */


extern void fnTxStats(unsigned char ucProtType);
extern void fnRxStats(unsigned char ucProtType);
extern void fnIncrementEthernetStats(unsigned char ucStat);
extern unsigned long fnGetEthernetStats(unsigned char ucStat);
extern unsigned long fnGetuNetworkStats(unsigned char ucStat);
extern void fnResetuNetwork_stats(void);                                 // {16}
extern void fnDeleteEthernetStats(void);
extern int fnProcessARP (ETHERNET_FRAME *frame);                         // process a received ethernet frame which seems to be ARP type
extern ARP_TAB *fnGetIP_ARP(unsigned char *Search_IP, UTASK_TASK OwnerTask, USOCKET cSocket); // get destination details from ARP cache
extern unsigned char *fnGetARPentry(unsigned char ucEntry, int iIP_MAC); // get a pointer to an ARP cache entry (either IP or MAC)
extern unsigned char *fnGetNeighborEntry(unsigned char ucEntry, int iIP_MAC); // {34}
    #define GET_IP    1
    #define GET_MAC   0
extern void fnDeleteArp(void);                                           // delete ARP cache
#ifdef USE_ZERO_CONFIG
    extern void fnSendARP_request(ARP_TAB *ptrARPTab);
#endif
extern void fnDeleteNeighbors(void);                                     // {34} delete IPV6 neighbor cache
extern int fnSubnetBroadcast(unsigned char *ip_address, unsigned char *subnet_mask, unsigned char ucLength);
extern int fnHandleIP(ETHERNET_FRAME *frame, unsigned short *usTotalLength);
extern int fnHandleIP_ICP(ETHERNET_FRAME *frame, IP_PACKET *received_ip_packet);
#ifdef RUN_LOOPS_IN_RAM
    extern void fnInitIP(void);
    extern unsigned short (*fnCalcIP_CS)(unsigned short cs, unsigned char *dat, unsigned short usLen);
#else
    extern unsigned short fnCalcIP_CS(unsigned short cs, unsigned char *dat, unsigned short usLen);
#endif
    #define IP_GOOD_CS 0xffff
extern void fnHandleIPV6(ETHERNET_FRAME *frame, unsigned short usValidIPV4); // {34}
extern void fnAddARP(unsigned char *new_ip, unsigned char *rem_hwadr, unsigned char ucType);
extern int fnSendIPV6Discovery(unsigned char *ptrIPV6_address);
extern NEIGHBOR_TAB *fnEnterIPV6Neighbor(unsigned char *ucHWAddress, unsigned char *ucIPV6Address, unsigned char ucHWAddress_length); // {34}
    #define REFRESH_ADDRESS    0x00
    #define SEARCH_ADDRESS     0x40
    #define RESOLVED_ADDRESS   0x80
extern unsigned char *fnGetIPV6_NN(unsigned char *ucIPV6Address, UTASK_TASK OwnerTask, USOCKET Socket); // {34}
extern void fnHandleICP(unsigned char *icp_data, IP_PACKET *received_ip_packet, unsigned short usLen);
extern int  fnHandleICMPV6(ETHERNET_FRAME_CONTENT *frame_cont, IPV6_DISCOVERY_FRAME_RX *ptrDiscoveryFrame, unsigned short usPayloadLength); // {34}
extern int  fnSendPing(unsigned char *ping_address, unsigned char ucTTL, UTASK_TASK OwnerTask, USOCKET Socket);
extern int  fnSendV6Ping(unsigned char *ping_address, unsigned char ucTTL, UTASK_TASK OwnerTask, USOCKET Socket); // {34}
extern void fnHandleTCP(unsigned char *tcp_data, IP_PACKET *received_ip_packet, unsigned short usLen);
extern void fnHandleIGMP(int iVersion, unsigned short usOptionLength, IP_PACKET *received_ip_packet, unsigned short usLen); // {42}
extern void fnHandleUDP(unsigned short usIP_HeaderLength, IP_PACKET *received_ip_packet);
extern USOCKET fnGetTCP_Socket(unsigned char ucTos, unsigned short usIdleTimeout, int (*listener)(USOCKET, unsigned char, unsigned char *, unsigned short) );
    #define INFINITE_TIMEOUT 0xffff                                      // {13}
extern USOCKET fnGetUDP_socket(unsigned char ucTOS, int (*fnListener)(USOCKET, unsigned char, unsigned char *, unsigned short, unsigned char *, unsigned short), unsigned char ucOpts);
extern USOCKET fnReleaseUDP_socket(USOCKET SocketHandle);
extern USOCKET fnReleaseTCP_Socket(USOCKET TCPSocket);
extern USOCKET fnBindSocket(USOCKET SocketHandle, unsigned short usLocalPort);
extern USOCKET fnTCP_Listen(USOCKET TCP_socket, unsigned short usPort, unsigned short usMaxWindow);
extern unsigned short fnGetFreeTCP_Port(void);
extern signed short fnSendUDP(USOCKET cSocketHandle, unsigned char *dest_IP, unsigned short ucRemotePort, unsigned char *ptrBuf, unsigned short usDataLen, UTASK_TASK OwnerTask);
extern void fnReportUDP(unsigned short usSourcePort, unsigned short usDestPort, unsigned char ucEvent, unsigned char *ucIP);
extern signed short fnSendIP(unsigned char *prIP_to, unsigned char ucProtType, unsigned char ucTypeOfService, unsigned char ucTTL, unsigned char *dat, unsigned short usLen, UTASK_TASK OwnerTask, USOCKET cSocket);
extern signed short fnSendIPV6(unsigned char *prIP_to, unsigned char ucProtType, unsigned char ucTTL, unsigned char *dat, unsigned short usLen, UTASK_TASK Owner, USOCKET cSocket); // {34}
extern void fnSendICMPError(ICMP_ERROR *tICMP_error, unsigned short usLength);
extern USOCKET fnTCP_Connect(USOCKET TCP_socket, unsigned char *RemoteIP, unsigned short usRemotePort, unsigned short usOurPort, unsigned short usMaxWindow );
extern USOCKET fnTCP_close(USOCKET TCP_Socket);
extern unsigned char fnGetTCP_state(USOCKET TCP_socket);                 // {14}
extern signed short fnSendTCP(USOCKET TCP_socket, unsigned char *ptrBuf, unsigned short usDataLen, unsigned char ucTempFlags);
#ifdef _EXTENDED_BUFFERED_TCP                                            // {47}
    typedef unsigned short COMMAND_TYPE;
#else
    typedef unsigned char COMMAND_TYPE;
#endif
    extern QUEUE_TRANSFER fnSendBufTCP(USOCKET TCP_socket, unsigned char *ptrBuf, unsigned short usDataLen, COMMAND_TYPE Command);
    #define TCP_BUF_SEND               0x01
    #define TCP_BUF_NEXT               0x02
    #define TCP_BUF_REP                0x04
    #define TCP_BUF_CHECK              0x08
    #define TCP_BUF_SEND_REPORT_COPY   0x10
    #define TCP_CONTENT_NEGOTIATION    0x20
    #define TCP_REPEAT_WINDOW          0x40
    #define TCP_BUF_KICK_NEXT          0x80
    #define TCP_BUF_QUEUE              0x0100                            // {47} queue the data is the connection is not yet established
#ifdef INDIVIDUAL_BUFFERED_TCP_BUFFER_SIZE                               // {40}
    extern unsigned short fnDefineTCPBufferSize(USOCKET TCP_socket, unsigned short usBufferSize); // enter the buffer size associated with a buffered TCP socket
#endif
extern USOCKET fnModifyTCPWindow(USOCKET TCPSocket, unsigned short usBufferSpace); // {33}
extern signed short fnReportTCPWindow(USOCKET TCPSocket, unsigned short usBufferSpace); // {31}
extern void fnTCP_Activity(USOCKET TCP_socket);                          // {6}
extern int  fnActiveTCP_connections(int iReset);                         // {44}
    #define SEARCH_CONNECTION 0
    #define RESET_CONNECTIONS 1
extern USOCKET fnTCP_IdleTimeout(USOCKET TCPSocket, unsigned short usIdleTimeout); // {49}
extern signed short fnResolveHostName(const CHAR *cHostNamePtr, void (*fnListener)(unsigned char , unsigned char *));
extern int  fnConnectPOP3(unsigned char *ucIP);
extern void fnStartPopPolling(DELAY_LIMIT PollTime, CHAR *(*fnCallback)(unsigned char, unsigned char *));
extern int  fnStartDHCP(UTASK_TASK OwnerTask);
    #define FORCE_INIT 0x80
extern void fnStartZeroConfig(UTASK_TASK Task);                          // {43}
extern void fnStopZeroConfig(void);
extern void fnCheckZeroConfigCollision(unsigned char *ptrData);          // {43}
extern void fnStopDHCP(void);
extern int  fnStartNetBIOS_Server(CHAR *);                               // {7}
extern int  fnStartTFTP_server(void (*Callback)(unsigned short, CHAR *));
extern void fnStopTFTP_server(void);
extern int  fnStartTFTP_client(void (*Callback)(unsigned short, CHAR *), unsigned char *ucIP, unsigned char ucReadWrite, CHAR *cFile, CHAR uFile);
    #define TFTP_PUT          0x00
    #define TFTP_GET          0x01
    #define TFTP_GET_COMPARE  0x02
#ifdef FNGENERATOR_PASS_HTTP                                             // {38}
    #define FGEN_PROTO unsigned char (*fnGenerator)(unsigned char *, HTTP *)
#else
    #define FGEN_PROTO unsigned char (*fnGenerator)(unsigned char *)
#endif
#ifdef _VARIABLE_HTTP_PORT                                               // {41}
    #ifdef HTTP_DYNAMIC_CONTENT                                          // {11}{12}
        extern void fnStartHTTP(int (*fnWebHandler)(unsigned char, CHAR *, HTTP *), FGEN_PROTO, CHAR *(*fnInsertRoutine)(unsigned char *, LENGTH_CHUNK_COUNT, unsigned short *, HTTP *), unsigned char ucParameters, unsigned short usPort);
    #else
        extern void fnStartHTTP(int (*fnWebHandler)(unsigned char, CHAR *, HTTP *), FGEN_PROTO, CHAR *(*fnInsertRoutine)(unsigned char *, LENGTH_CHUNK_COUNT, unsigned short *), unsigned char ucParameters, unsigned short usPort);
    #endif
#else
    #ifdef HTTP_DYNAMIC_CONTENT                                          // {11}{12}
        extern void fnStartHTTP(int (*fnWebHandler)(unsigned char, CHAR *, HTTP *), FGEN_PROTO, CHAR *(*fnInsertRoutine)(unsigned char *, LENGTH_CHUNK_COUNT, unsigned short *, HTTP *), unsigned char ucParameters);
    #else
        extern void fnStartHTTP(int (*fnWebHandler)(unsigned char, CHAR *, HTTP *), FGEN_PROTO, CHAR *(*fnInsertRoutine)(unsigned char *, LENGTH_CHUNK_COUNT, unsigned short *), unsigned char ucParameters);
    #endif
#endif
    #define NOT_SELECTED   0
    #define IS_SELECTED    1
    #define IS_CHECKED     2
    #define IS_DISABLED    3
extern void fnStopHTTP(void);

#ifdef PASS_SERVER_DELAYED_STRING
    extern unsigned char fnServeDelayed(CHAR *cFile, unsigned char ucOption);
#else
    extern unsigned char fnServeDelayed(CHAR cFile, unsigned char ucOption);
#endif
    #define WEB_SUPPORT_PARAM_GEN 0x01
    #define WEB_SUPPORT_HANDLER   0x02
    #define WEB_AUTHENTICATE      0x04
    #define WEB_TRUSTED_IP        0x08
    #define WEB_BLACKLIST_IP      0x10                                   // {39}



extern USOCKET fnStartTelnet(unsigned short usTelnetPortNumber, unsigned short usIdleTimeout, unsigned short usMaxWindow, UTASK_TASK wakeOnAck, int (*listener)(USOCKET, unsigned char, unsigned char *, unsigned short) );
extern void fnStopTelnet(USOCKET TelnetSocket);
extern int  fnTelnet(USOCKET Telnet_socket, int iCommand);
extern int  fnCheckTelnetBinaryTx(USOCKET Socket);

extern int  fnConnectSMTP(unsigned char *ucIP, unsigned char ucMode, const CHAR *(*fnCallback)(unsigned char, unsigned short *));

extern int  fnStartSNMP(int (*fnAppCallback)(unsigned char ucEvent, unsigned char *data, unsigned short usLength), unsigned char *ucIP);
extern void fnSendSNMPTrap(unsigned char ucTrap, unsigned char ucSpecificCode);

extern void fnStartFtp(unsigned short usFTPTimeout, unsigned char ucFTP_operating_mode);
    #define FTP_AUTHENTICATE       0x01                                  // require authentication rather than accepting anonymous login

extern void fnStopFtp(void);
extern USOCKET fnFTP_client_connect(unsigned char ucIP_address[IPV4_LENGTH], unsigned short ucPortNumber, unsigned short usFTPTimeout, int (*user_callback)(TCP_CLIENT_MESSAGE_BOX *)); // {48}
extern int  fnFTP_client_disconnect(void);                               // {48}
extern int  fnFTP_client_dir(CHAR *ptrPath, int iAction);                // {48}
    #define FTP_DIR_LIST           0x00
    #define FTP_DIR_SET_PATH       0x01
    #define FTP_DIR_MAKE_DIR       0x02
    #define FTP_DIR_RENAME         0x04
    #define FTP_DIR_DELETE         0x08
    #define FTP_DIR_REMOVE_DIR     0x10
extern int  fnFTP_client_transfer(CHAR *ptrFilePath, int iMode);         // {48}
    #define FTP_TRANSFER_BINARY    0x00
    #define FTP_TRANSFER_ASCII     0x01
    #define FTP_DO_GET             0x00
    #define FTP_DO_PUT             0x02
    #define FTP_DO_APPEND          0x04
extern int  fnInsertHTMLString(CHAR *cToAdd, unsigned short usAddLength, unsigned char **ptrBuffer, unsigned short *usMaxLen, unsigned short *usLen, unsigned char *ptrBufferEnd); // {9}
extern void fnDecode64(CHAR *ptrInput, CHAR *ptrOutput);
extern MAX_FILE_LENGTH fnEncode64(unsigned char *ptrInput, CHAR *ptrOutput, MAX_FILE_LENGTH input_length); // {15}
extern int  fnVerifyUser(CHAR *cDecodedUser, unsigned char iCheckUser);
    #define DO_CHECK_USER_NAME     0x01
    #define DO_CHECK_PASSWORD      0x02
    #define HTML_PASS_CHECK        0x04
    #define FTP_PASS_CHECK         0x08

extern int  fnCheckPass(CHAR *ucReference, CHAR *ucNewInput);
extern CHAR *fnWebStrcpy(CHAR *cStrOut, CHAR *cStrIn);

// IP utilities functions
//
extern CHAR *fnStrIP(CHAR *ptr_input, unsigned char *ucIP_address);
extern CHAR *fnIPStr(unsigned char *ptrIP, CHAR *cStr);
extern CHAR *fnSetMAC(CHAR *ptr_input, unsigned char *ptrMac);
extern CHAR *fnMACStr(unsigned char *ptrMAC, CHAR *cStr);

// IPV6 utility functions                                                // {34}
//
extern CHAR *fnIPV6Str(unsigned char *ptrIP, CHAR *cStr);
extern CHAR *fnStrIPV6(CHAR *ptr_input, unsigned char *ucIP_address);


extern unsigned char fnGetMimeType(CHAR *ptrFileName);
extern const CHAR   *cMimeTable[];

/* =================================================================== */
/*              Global Ethernet and TCP/IP variables                   */
/* =================================================================== */


extern const unsigned char cucNullMACIP[MAC_LENGTH];                     // system constant - 0x00 0x00 0x00 0x00 0x00 0x00
extern const unsigned char cucBroadcast[MAC_LENGTH];                     // system constant - 0xff 0xff 0xff 0xff 0xff 0xff


extern const CHAR    cSMTP_provider[];                                   // supplied and initialised by application
extern unsigned char ucSMTP_server[IPV4_LENGTH];                         // supplied and initialised by application

// Web server support of IP parameter modification
//
#define ADD_IP_ADDRESS     0
#define ADD_MAC_ADDRESS    1
#define ADD_STATS          2
#define ADD_MEM            3



typedef struct _PACK stNETWORK_PARAMETERS
{
    unsigned short usNetworkOptions;                                     // options passed to the network device on configuration
    unsigned char  ucOurMAC[MAC_LENGTH];                                 // when no other value can be read from parameters this will be used
    unsigned char  ucOurIP[IPV4_LENGTH];                                 // our default IP address
    unsigned char  ucNetMask[IPV4_LENGTH];                               // our default network mask
    unsigned char  ucDefGW[IPV4_LENGTH];                                 // our default gateway
    unsigned char  ucDNS_server[IPV4_LENGTH];                            // our default DNS server
#ifdef SECOND_DNS_SERVER                                                 // {37}
    unsigned char  ucDNS_server_reserve[IPV4_LENGTH];                    // our fall-back DNS server
#endif
#ifdef USE_IPV6                                                          // {29}
    unsigned char  ucOurIPV6[IPV6_LENGTH];                               // IPV6 address
#endif
} NETWORK_PARAMETERS;

#define OFFSET_OUR_IP (sizeof(unsigned short) + MAC_LENGTH)

extern NETWORK_PARAMETERS network;

#ifdef SUPPORT_VLAN
    extern int vlan_active;
    extern unsigned short vlan_vid;
#endif

extern void fnGetEthernetPars(void);                                     // the application will tend to have to assure this is available since it knows where the parameters are located

#endif
