/*
 * Copyright (c) 2010 VECTOR.
 *	All rights reserved.
 *
 * Author: Andriy Korud <a.korud@vector.com.pl>
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef OID_EX_H_
#define OID_EX_H_

#include "snmp.h"
#include "snmpagent.h"
#include "oid_vector_mon.h"

/**
 *  Supported OIDs tree
 */
const snmp_node_t tree[] = {
	// MIB-II system part
	{{8, {1,3,6,1,2,1,1,1}}, SNMP_NODE_LEAF, SNMP_SYNTAX_OCTETSTRING, snmpSysDescr}, // sysDescr
	{{8, {1,3,6,1,2,1,1,3}}, SNMP_NODE_LEAF, SNMP_SYNTAX_TIMETICKS, snmpSysUpTime},  // sysUpTime
	//
	// VECTOR-HFC-MON-MIB including firmware upgrade
	{{10, {1,3,6,1,4,1,11195,1,1,2}}, SNMP_NODE_LEAF, SNMP_SYNTAX_OCTETSTRING, snmpFwVersion},	// MON fwVersion
	{{10, {1,3,6,1,4,1,11195,1,1,8}}, SNMP_NODE_LEAF | SNMP_NODE_CANSET, SNMP_SYNTAX_IPADDRESS, snmpFwTftp},		// TFTP server IP
	{{10, {1,3,6,1,4,1,11195,1,1,9}}, SNMP_NODE_LEAF | SNMP_NODE_CANSET, SNMP_SYNTAX_OCTETSTRING, snmpFwFilename},	// MON FW filename
};

#endif
