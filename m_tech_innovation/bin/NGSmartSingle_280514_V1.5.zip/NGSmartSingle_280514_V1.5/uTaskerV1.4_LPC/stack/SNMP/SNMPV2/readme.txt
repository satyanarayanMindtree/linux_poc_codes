This second generation of SNMP from Andrij K. is a full-featured v1/2 SNMP stack with all operations, tables support (without row adding/deleting).
Here are his comments:


"It has been very well tested and used it in production environments. 

It does use code from bsnmp package distributed under BSD license and license for this code is also BSD. 
 
How to use it:
- unpack to directory somewhere in your project, add to project and start by calling fnSNMPStart(); (don't forget to increase number of UDP sockets by 1, or by 2 if you want to use traps). 
- SNMP stack itself doesn't need task, but traps need task which is defined in trap.c, you must also add it to TaskConfig.h:
#define TASK_TRAP 'r' // tRap sending tas;
... 
{ "r", fnTrapTask, SMALL_QUEUE, (DELAY_LIMIT)(1 * SEC), 0, UTASKER_STOP}, // SNMP trap sending task
... 
All supported OIDs are defined in big table in oids.h file. They MUST be keep sorted in order walk operation to work. For each OID you just define function which will handle get/set operations.
I've included few function as example. 
 
I've tried to separate the code as much as possible from the entire application, however it may complain on some defines. Fixing of this should be simple, and I can always help. 

I hope this will usable for uTasker community, 

best regards, 

Andriy"


