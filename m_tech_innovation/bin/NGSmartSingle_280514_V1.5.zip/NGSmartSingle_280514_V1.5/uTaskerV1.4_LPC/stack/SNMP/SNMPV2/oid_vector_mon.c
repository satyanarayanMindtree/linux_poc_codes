/*
 * Copyright (c) 2010 VECTOR.
 *	All rights reserved.
 *
 * Author: Andriy Korud <a.korud@vector.com.pl>
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "config.h"
#include "snmp.h"
#include "snmpagent.h"
#include "oid_vector_mon.h"

// variables below are for example only, 
// normally they are stored somewhere in application
#define MAX_SNMP_FILENAME_LEN 32
const char *sysDescr = "example";
const char *fwVersion = "1.2.3.4";
char ucTFTP_server_ip[IPV4_LENGTH];
char monFwFileName[MAX_SNMP_FILENAME_LEN + 1];

/******************************************
 *  MIB-II system OID implementations     
 *****************************************/

int snmpSysDescr(struct snmp_value *argVal, u_int argOidLen, enum snmp_op op) {
	argVal->v.octetstring.len = uStrlen(sysDescr);
	argVal->v.octetstring.octets = (unsigned char*)sysDescr;
	return SNMP_ERR_NOERROR;
}

int snmpSysUpTime(struct snmp_value *argVal, u_int argOidLen, enum snmp_op op) {
	argVal->v.uint32 = uTaskerSystemTick * 5;  // for default 50ms system tick
	return SNMP_ERR_NOERROR;
}

/*************************************************************************
 *  VECTOR-HFC-MON OIDs implementation, firmware upgrade part
 *************************************************************************/

int snmpFwVersion(struct snmp_value *argVal, u_int argOidLen, enum snmp_op op) {
	argVal->v.octetstring.len = uStrlen(fwVersion);
	argVal->v.octetstring.octets = (unsigned char*)fwVersion;
	return SNMP_ERR_NOERROR;
}

int snmpFwTftp(struct snmp_value *argVal, u_int argOidLen, enum snmp_op op) 
{
	switch (op) {
		case SNMP_OP_GET:
			uMemcpy(argVal->v.ipaddress, ucTFTP_server_ip, IPV4_LENGTH);
			break;

		case SNMP_OP_SET:
			uMemcpy(ucTFTP_server_ip, argVal->v.ipaddress, IPV4_LENGTH);
			break;
	}
	return (SNMP_ERR_NOERROR);
}

#define MON_FILENAME_SUB 9
#define NODE_FILENAME_SUB 10

int snmpFwFilename(struct snmp_value *argVal, u_int sub, enum snmp_op op) 
{
	asn_subid_t which = argVal->var.subs[sub - 1];
	switch (op) {
		case SNMP_OP_GET:
			switch (which) {
				case MON_FILENAME_SUB:
  					argVal->v.octetstring.len = uStrlen(monFwFileName);
					argVal->v.octetstring.octets = (unsigned char*)monFwFileName;
					break;
				default: 
					return (SNMP_ERR_GENERR);
			}
			break;

		case SNMP_OP_SET:
			if (argVal->v.octetstring.len > MAX_SNMP_FILENAME_LEN) {
				return (SNMP_ERR_WRONG_LENGTH);
			}
			switch (which) {
				case MON_FILENAME_SUB:
					uMemcpy(monFwFileName, argVal->v.octetstring.octets, argVal->v.octetstring.len);
					monFwFileName[argVal->v.octetstring.len] = 0;
					break;
				default: 
					return (SNMP_ERR_GENERR);
			}
		}
	return (SNMP_ERR_NOERROR);
}

