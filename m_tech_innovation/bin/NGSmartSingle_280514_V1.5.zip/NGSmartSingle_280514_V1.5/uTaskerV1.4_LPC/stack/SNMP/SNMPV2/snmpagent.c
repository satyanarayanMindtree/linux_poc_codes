/*
 * Copyright (c) 2001-2003
 *	Fraunhofer Institute for Open Communication Systems (FhG Fokus).
 *	All rights reserved.
 *
 * Author: Harti Brandt <harti@freebsd.org>
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Begemot: bsnmp/lib/asn1.c,v 1.31 2005/10/06 07:14:58 brandt_h Exp $
 *
 * ASN.1 for SNMP.
 */

#include "config.h"
#include "snmp.h"
#include "snmpagent.h"
#include "oids.h"

#ifdef _WINDOWS
  #include "..\WinSim\WinSim.h"
#endif

#define OWN_TASK                   TASK_SNMP

#define snmp_error

USOCKET SNMP_UDP_socket = -1;

#define SNMP_BUFFER 512

// variables below are for example only, 
// normally they are stored somewhere in application
const char *snmp_admin = "private";
const char *snmp_user = "public";

typedef struct stUDP_MESSAGE
{
    UDP_HEADER       tUDP_Header;                                         // reserve header space
    unsigned char    ucUDP_Message[SNMP_BUFFER];
} UDP_MESSAGE;

// reserved space for responce UDP frame
static struct stUDP_MESSAGE respUdp;

// reserved space for incoming ASN and PDU
struct asn_buf asn;
static struct snmp_pdu pdu;

// reserved space for responce ASN and PDU
struct asn_buf resp_b;
static struct snmp_pdu resp;

static unsigned char tree_size = sizeof(tree)/sizeof(snmp_node_t);
		
static int fnSNMPListner(USOCKET SocketNr, unsigned char ucEvent, unsigned char *ucIP, unsigned short usPortNr, unsigned char *data, unsigned short usLength);

/**
 * Call this function to start SNMP
 **/
extern int fnSNMPStart(void)
{
    if (SNMP_UDP_socket == -1)
        SNMP_UDP_socket = fnGetUDP_socket(TOS_MINIMISE_DELAY, fnSNMPListner, UDP_OPT_SEND_CS | UDP_OPT_CHECK_CS);

    if (SNMP_UDP_socket >= 0) {
        fnBindSocket(SNMP_UDP_socket, SNMP_CLIENT_PORT);
        return SNMP_UDP_socket;                                          // OK
    }
    return NO_UDP_SOCKET_FOR_SNMP;                                       // error
}


/*
 * Find a variable for SET/GET and the first GETBULK pass.
 * Return the node pointer. If the search fails, set the errp to
 * the correct SNMPv2 GET exception code.
 */

static struct snmp_node *
find_node(const struct snmp_value *value, enum snmp_syntax *errp)
{
	struct snmp_node *tp;

	/*
	 * If we have an exact match (the entry in the table is a
	 * sub-oid from the variable) we have found what we are for.
	 * If the table oid is higher than the variable, there is no match.
	 */
	
	for (tp = 	(struct snmp_node *)tree; tp < tree + tree_size; tp++) {
		if (asn_is_suboid(&tp->oid, &value->var))
			goto found;
		if (asn_compare_oid(&tp->oid, &value->var) >= 0)
			break;
	}
	

	*errp = SNMP_SYNTAX_NOSUCHOBJECT;
	return (NULL);

  found:
	/* leafs must have a 0 instance identifier */
	if ((tp->type & 0x7f) == SNMP_NODE_LEAF &&
	    (value->var.len != tp->oid.len + 1 ||
	     value->var.subs[tp->oid.len] != 0)) {
		*errp = SNMP_SYNTAX_NOSUCHINSTANCE;
		return (NULL);
	}
	return (tp);
}


static struct snmp_node *
find_subnode(const struct snmp_value *value)
{
	struct snmp_node *tp;

	for (tp = (	struct snmp_node *)tree; tp < tree + tree_size; tp++) {
		if (asn_is_suboid(&value->var, &tp->oid))
			return (tp);
	}
	return (NULL);
}

/*
 * Execute a GET operation. The tree is rooted at the global 'root'.
 * Build the response PDU on the fly. If the return code is SNMP_RET_ERR
 * the pdu error status and index will be set.
 */
enum snmp_ret
snmp_get(struct snmp_pdu *pdu, struct asn_buf *resp_b,
    struct snmp_pdu *resp, void *data)
{
	int ret;
	u_int i;
	struct snmp_node *tp;
	enum snmp_syntax except;
	enum asn_err err;

	uMemset(resp, 0, sizeof(*resp));
	uMemcpy(resp->community, pdu->community, SNMP_COMMUNITY_MAXLEN + 1);
	resp->version = pdu->version;
	resp->type = SNMP_PDU_RESPONSE;
	resp->request_id = pdu->request_id;
	resp->version = pdu->version;

	if (snmp_pdu_encode_header(resp_b, resp) != SNMP_CODE_OK)
		/* cannot even encode header - very bad */
		return (SNMP_RET_IGN);

	for (i = 0; i < pdu->nbindings; i++) {
		resp->bindings[i].var = pdu->bindings[i].var;
/*----------------DEBUG--------------------------------------------------------
		fnDebugMsg("SNMP: get ");
		for (j = 0; j<pdu->bindings[i].var.len; j++) {
			fnDebugMsg(".");
			fnDebugDec(pdu->bindings[i].var.subs[j], 0, 0);
		}
		fnDebugMsg("\r\n");
  ----------------DEBUG--------------------------------------------------------*/
		if ((tp = find_node(&pdu->bindings[i], &except)) == NULL) {
			if (pdu->version == SNMP_V1) {
				pdu->error_status = SNMP_ERR_NOSUCHNAME;
				pdu->error_index = i + 1;
				return (SNMP_RET_ERR);
			}
			resp->bindings[i].syntax = except;

		} else {
			/* call the action to fetch the value. */
			resp->bindings[i].syntax = tp->syntax;
			if (tp->op != 0) {
				ret = (*tp->op)(&resp->bindings[i],
				    tp->oid.len, SNMP_OP_GET);

				if (ret == SNMP_ERR_NOSUCHNAME) {
					if (pdu->version == SNMP_V1) {
						pdu->error_status = SNMP_ERR_NOSUCHNAME;
						pdu->error_index = i + 1;
						return (SNMP_RET_ERR);
					}
					resp->bindings[i].syntax = SNMP_SYNTAX_NOSUCHINSTANCE;
	
				} else if (ret != SNMP_ERR_NOERROR) {
					pdu->error_status = SNMP_ERR_GENERR;
					pdu->error_index = i + 1;
					return (SNMP_RET_ERR);
				}
			} else {
				pdu->error_status = SNMP_ERR_GENERR;
				pdu->error_index = i + 1;
				return (SNMP_RET_ERR);
			}
		}
		resp->nbindings++;

		err = snmp_binding_encode(resp_b, &resp->bindings[i]);

		if (err == ASN_ERR_EOBUF) {
			pdu->error_status = SNMP_ERR_TOOBIG;
			pdu->error_index = 0;
			return (SNMP_RET_ERR);
		}
		if (err != ASN_ERR_OK) {
			pdu->error_status = SNMP_ERR_GENERR;
			pdu->error_index = i + 1;
			return (SNMP_RET_ERR);
		}
	}

	return (snmp_fix_encoding(resp_b, resp));
}

static struct snmp_node *
next_node(const struct snmp_value *value, int *pnext)
{
	struct snmp_node *tp;

	*pnext = 0;
	for (tp = (	struct snmp_node *)tree; tp < tree + tree_size; tp++) {
		if (asn_is_suboid(&tp->oid, &value->var)) {
			/* the tree OID is a sub-oid of the requested OID. */
			if ((tp->type & 0x7f) == SNMP_NODE_LEAF) {
				if (tp->oid.len == value->var.len) {
					/* request for scalar type */
					return (tp);
				}
				/* try next */
			} else {
				return (tp);
			}
		} else if (asn_is_suboid(&value->var, &tp->oid) ||
		    asn_compare_oid(&tp->oid, &value->var) >= 0) {
			*pnext = 1;
			return (tp);
		}
	}

	return (NULL);
}

static enum snmp_ret
do_getnext(struct context *context, const struct snmp_value *inb, struct snmp_value *outb, struct snmp_pdu *pdu)
{
	const struct snmp_node *tp;
	int ret, next;

	if ((tp = next_node(inb, &next)) == NULL)
		goto eofMib;

	/* retain old variable if we are doing a GETNEXT on an exact
	 * matched leaf only */
	if ((tp->type & 0x7f) == SNMP_NODE_LEAF || next)
		outb->var = tp->oid;
	else
		outb->var = inb->var;

	for (;;) {
		outb->syntax = tp->syntax;
		if ((tp->type & 0x7f) == SNMP_NODE_LEAF) {
			/* make a GET operation */
			outb->var.subs[outb->var.len++] = 0;
			ret = (*tp->op)(outb, tp->oid.len,
			    SNMP_OP_GET);
		} else {
			/* make a GETNEXT */
			ret = (*tp->op)(outb, tp->oid.len,
			     SNMP_OP_GETNEXT);
		}
		if (ret != SNMP_ERR_NOSUCHNAME) {
			break;
		}

		/* object has no data - try next */
		if (++tp == tree + tree_size)
			break;

		outb->var = tp->oid;
	}

	if (ret == SNMP_ERR_NOSUCHNAME) {
  eofMib:
		outb->var = inb->var;
		if (pdu->version == SNMP_V1) {
			pdu->error_status = SNMP_ERR_NOSUCHNAME;
			return (SNMP_RET_ERR);
		}
		outb->syntax = SNMP_SYNTAX_ENDOFMIBVIEW;

	} else if (ret != SNMP_ERR_NOERROR) {
		pdu->error_status = SNMP_ERR_GENERR;
		return (SNMP_RET_ERR);
	}
	return (SNMP_RET_OK);
}


/*
 * Execute a GETNEXT operation. The tree is rooted at the global 'root'.
 * Build the response PDU on the fly. The return is:
 */
enum snmp_ret
snmp_getnext(struct snmp_pdu *pdu, struct asn_buf *resp_b,
    struct snmp_pdu *resp, void *data)
{
	u_int i;
	enum asn_err err;
	enum snmp_ret result;

	uMemset(resp, 0, sizeof(*resp));
	uMemcpy(resp->community, pdu->community, SNMP_COMMUNITY_MAXLEN + 1);
	resp->type = SNMP_PDU_RESPONSE;
	resp->request_id = pdu->request_id;
	resp->version = pdu->version;

	if (snmp_pdu_encode_header(resp_b, resp))
		return (SNMP_RET_IGN);

	for (i = 0; i < pdu->nbindings; i++) {
		result = do_getnext(0, &pdu->bindings[i],
		    &resp->bindings[i], pdu);

		if (result != SNMP_RET_OK) {
			pdu->error_index = i + 1;
			return (result);
		}

		resp->nbindings++;

		err = snmp_binding_encode(resp_b, &resp->bindings[i]);

		if (err == ASN_ERR_EOBUF) {
			pdu->error_status = SNMP_ERR_TOOBIG;
			pdu->error_index = 0;
			return (SNMP_RET_ERR);
		}
		if (err != ASN_ERR_OK) {
			pdu->error_status = SNMP_ERR_GENERR;
			pdu->error_index = i + 1;
			return (SNMP_RET_ERR);
		}
	}
	return (snmp_fix_encoding(resp_b, resp));
}

enum snmp_ret
snmp_getbulk(struct snmp_pdu *pdu, struct asn_buf *resp_b,
    struct snmp_pdu *resp, void *data)
{
	u_int i;
	int cnt;
	u_int non_rep;
	int eomib;
	enum snmp_ret result;
	enum asn_err err;

	uMemset(resp, 0, sizeof(*resp));
	uStrcpy(resp->community, pdu->community);
	resp->version = pdu->version;
	resp->type = SNMP_PDU_RESPONSE;
	resp->request_id = pdu->request_id;
	resp->version = pdu->version;

	if (snmp_pdu_encode_header(resp_b, resp) != SNMP_CODE_OK)
		/* cannot even encode header - very bad */
		return (SNMP_RET_IGN);

	if ((non_rep = pdu->error_status) > pdu->nbindings)
		non_rep = pdu->nbindings;

	/* non-repeaters */
	for (i = 0; i < non_rep; i++) {
		result = do_getnext(0, &pdu->bindings[i],
		    &resp->bindings[resp->nbindings], pdu);

		if (result != SNMP_RET_OK) {
			pdu->error_status = SNMP_ERR_GENERR;
			pdu->error_index = i + 1;
			return (result);
		}

		err = snmp_binding_encode(resp_b,
		    &resp->bindings[resp->nbindings++]);

		if (err == ASN_ERR_EOBUF)
			goto done;

		if (err != ASN_ERR_OK) {
			pdu->error_status = SNMP_ERR_GENERR;
			pdu->error_index = i + 1;
			return (SNMP_RET_ERR);
		}
	}

	if (non_rep == pdu->nbindings)
		goto done;

	/* repeates */
	for (cnt = 0; cnt < pdu->error_index; cnt++) {
		eomib = 1;
		for (i = non_rep; i < pdu->nbindings; i++) {
			if (cnt == 0) 
				result = do_getnext(0, &pdu->bindings[i],
				    &resp->bindings[resp->nbindings], pdu);
			else
				result = do_getnext(0,
				    &resp->bindings[resp->nbindings -
				    (pdu->nbindings - non_rep)],
				    &resp->bindings[resp->nbindings], pdu);

			if (result != SNMP_RET_OK) {
				pdu->error_index = i + 1;
				return (result);
			}
			if (resp->bindings[resp->nbindings].syntax !=
			    SNMP_SYNTAX_ENDOFMIBVIEW)
				eomib = 0;

			err = snmp_binding_encode(resp_b,
			    &resp->bindings[resp->nbindings++]);

			if (err == ASN_ERR_EOBUF)
				goto done;

			if (err != ASN_ERR_OK) {
				pdu->error_status = SNMP_ERR_GENERR;
				pdu->error_index = i + 1;
				return (SNMP_RET_ERR);
			}
		}
		if (eomib)
			break;
	}

  done:
	return (snmp_fix_encoding(resp_b, resp));
}


/*
 * Do a SET operation.
 */
enum snmp_ret
snmp_set(struct snmp_pdu *pdu, struct asn_buf *resp_b,
    struct snmp_pdu *resp, void *data)
{
	int ret;
	u_int i;
	enum asn_err asnerr;
	struct snmp_node *np;
	struct snmp_value *b;
	enum snmp_syntax except;
	struct snmp_node *nodes[SNMP_MAX_BINDINGS];

	uMemset(resp, 0, sizeof(*resp));
	uStrcpy(resp->community, pdu->community);
	resp->type = SNMP_PDU_RESPONSE;
	resp->request_id = pdu->request_id;
	resp->version = pdu->version;

	if (snmp_pdu_encode_header(resp_b, resp))
		return (SNMP_RET_IGN);

	/* 
	 * 1. Find all nodes, check that they are writeable and
	 *    that the syntax is ok, copy over the binding to the response.
	 */
	for (i = 0; i < pdu->nbindings; i++) {
		b = &pdu->bindings[i];

		if ((nodes[i] = np = find_node(b, &except)) == NULL) {
			/* not found altogether or LEAF with wrong index */
			if (pdu->version == SNMP_V1) {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_NOSUCHNAME;
			} else if ((np = find_subnode(b)) != NULL) {
				/* 2. intermediate object */
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_NOT_WRITEABLE;
			} else if (except == SNMP_SYNTAX_NOSUCHOBJECT) {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_NO_ACCESS;
			} else {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_NO_CREATION;
			}
			return (SNMP_RET_ERR);
		}

		/*
		 * 2. write/createable?
		 * Can check this for leafs only, because in v2 we have
		 * to differentiate between NOT_WRITEABLE and NO_CREATION
		 * and only the action routine for COLUMNS knows, whether
		 * a column exists.
		 * CHANGED BY akorud:
		 * don't return NO_CREATION for colums, only for rows. 
		 */
		if (!(np->type & SNMP_NODE_CANSET)) {
			if (pdu->version == SNMP_V1) {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_NOSUCHNAME;
			} else {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_NOT_WRITEABLE;
			}
			return (SNMP_RET_ERR);
		}

		/*
		 * 3. Ensure the right syntax
		 */
		if (np->syntax != b->syntax) {
			if (pdu->version == SNMP_V1) {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_BADVALUE; /* v2: wrongType */
			} else {
				pdu->error_index = i + 1;
				pdu->error_status = SNMP_ERR_WRONG_TYPE;
			}
			return (SNMP_RET_ERR);
		}

		/*
		 * 4. Copy binding
		 */
		
		if (snmp_value_copy(&resp->bindings[i], b)) {
			pdu->error_index = i + 1;
			pdu->error_status = SNMP_ERR_GENERR;
			return (SNMP_RET_ERR);
		}
		asnerr = snmp_binding_encode(resp_b, &resp->bindings[i]);
		if (asnerr == ASN_ERR_EOBUF) {
			pdu->error_index = i + 1;
			pdu->error_status = SNMP_ERR_TOOBIG;
			return (SNMP_RET_ERR);
		} else if (asnerr != ASN_ERR_OK) {
			pdu->error_index = i + 1;
			pdu->error_status = SNMP_ERR_GENERR;
			return (SNMP_RET_ERR);
		}
		resp->nbindings++;
	}


	/*
	 * 2. Call the SET method for each node. If a SET fails, rollback
	 *    everything. Map error codes depending on the version.
	 */
	for (i = 0; i < pdu->nbindings; i++) {
		b = &pdu->bindings[i];
		np = nodes[i];

		ret = (*np->op)(b, np->oid.len, SNMP_OP_SET);

		if (pdu->version == SNMP_V1) {
			switch (ret) {
			  case SNMP_ERR_NO_ACCESS:
				ret = SNMP_ERR_NOSUCHNAME;
				break;
			  case SNMP_ERR_WRONG_TYPE:
				/* should no happen */
				ret = SNMP_ERR_BADVALUE;
				break;
			  case SNMP_ERR_WRONG_LENGTH:
				ret = SNMP_ERR_BADVALUE;
				break;
			  case SNMP_ERR_WRONG_ENCODING:
				/* should not happen */
				ret = SNMP_ERR_BADVALUE;
				break;
			  case SNMP_ERR_WRONG_VALUE:
				ret = SNMP_ERR_BADVALUE;
				break;
			  case SNMP_ERR_NO_CREATION:
				ret = SNMP_ERR_NOSUCHNAME;
				break;
			  case SNMP_ERR_INCONS_VALUE:
				ret = SNMP_ERR_BADVALUE;
				break;
			  case SNMP_ERR_RES_UNAVAIL:
				ret = SNMP_ERR_GENERR;
				break;
			  case SNMP_ERR_COMMIT_FAILED:
				ret = SNMP_ERR_GENERR;
				break;
			  case SNMP_ERR_UNDO_FAILED:
				ret = SNMP_ERR_GENERR;
				break;
			  case SNMP_ERR_AUTH_ERR:
				/* should not happen */
				ret = SNMP_ERR_GENERR;
				break;
			  case SNMP_ERR_NOT_WRITEABLE:
				ret = SNMP_ERR_NOSUCHNAME;
				break;
			  case SNMP_ERR_INCONS_NAME:
				ret = SNMP_ERR_BADVALUE;
				break;
			}
		}
		if (ret != SNMP_ERR_NOERROR) {
			pdu->error_index = i + 1;
			pdu->error_status = ret;
			goto errout;
		}
	}


	if (snmp_fix_encoding(resp_b, resp) != SNMP_CODE_OK) {
		snmp_error("set: fix_encoding failed");
	}

	/*
	 * Done
	 */
  errout:
	return (SNMP_RET_ERR);
}


// The SNMP listner function for SNMP port
//
static int fnSNMPListner(USOCKET SocketNr, unsigned char ucEvent, unsigned char *ucIP, unsigned short usPortNr, unsigned char *data, unsigned short usLength)
{
	int32_t ip;
	int err = SNMP_RET_IGN;

	if (SocketNr != SNMP_UDP_socket) {return NOT_SNMP_SOCKET;}                // not our socket so ignore

	asn.asn_cptr = data;
	asn.asn_len = usLength;

	if (snmp_pdu_decode(&asn, &pdu, &ip) != SNMP_CODE_OK) {return 0;}   // no time/codespace for analysys, just give up

	if (uStrcmp(pdu.community, snmp_admin) && uStrcmp(pdu.community, snmp_user)) {return 0;}
	if (uStrcmp(pdu.community, snmp_admin) && pdu.type == SNMP_PDU_SET) {return 0;}

	resp_b.asn_cptr = respUdp.ucUDP_Message;
	resp_b.asn_len = SNMP_BUFFER;

	if (pdu.type == SNMP_PDU_GET) {
		err = snmp_get(&pdu, &resp_b, &resp, 0);
	} 
	if (pdu.type == SNMP_PDU_GETNEXT) {
		err = snmp_getnext(&pdu, &resp_b, &resp, 0);
	}
	if (pdu.type == SNMP_PDU_SET) {
		err = snmp_set(&pdu, &resp_b, &resp, 0);
		//updateNodeConfig();
	}
	if (pdu.type == SNMP_PDU_GETBULK) {
		err = snmp_getbulk(&pdu, &resp_b, &resp, 0);
	}

	switch (err) {
		case SNMP_RET_OK:
			fnSendUDP(SNMP_UDP_socket, ucIP, usPortNr, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, 0);
			break;
		case SNMP_RET_ERR:
			// drop everything and encode error response from request PDU
			resp_b.asn_cptr = respUdp.ucUDP_Message;
			resp_b.asn_len = SNMP_BUFFER;
			pdu.type = SNMP_PDU_RESPONSE;
			if (snmp_pdu_encode(&pdu, &resp_b) == SNMP_CODE_OK) {
				fnSendUDP(SNMP_UDP_socket, ucIP, usPortNr, (unsigned char *)&respUdp.tUDP_Header, SNMP_BUFFER - resp_b.asn_len, 0);	
			}
			break;
		default:
			break;
	}

    return 0;
}

