Andriy K. has allowed me to distribute his code to anyone who is interested in it - his company kindly donated it to the project.
He welcomes feedback and I am sure he can also answer any questions if necessary.
He is a forum member (akorud) so can be contacted there.

Below are some notes from Andriy:



"Hi guys,
I have good news - I can share our snmp implementation. Actually it's v1 SNMP with traps support, we're currently working on v2c code including bulk requests and multiple OID request support. 
Attached file are working snapshots, however it works quite stable and used in presales demos. 
Mark, if you wish you can consider this as our contribution to uTasker project. 
 
Code is shared "as is" without any restrictive license (i.e. GPL), however I'd be happy to receive some feedback - bug reports (at least), improvements, some beer :), etc...
 
Best regards,
Andriy K.
 
P.S. Compilation may (and will) fail because MIB mapping table reference to our proprietary get/set functions I cannot disclosure. You should implement you own MIB mapping table."

 

