#define ASN_MAXOIDLEN	15
#define MIB_LEN			10
#define MAX_STR_LEN		256
#define MAX_PASS_LEN	40

typedef struct stSystem                                              // header define for transmitter use
{
    unsigned char  sysDescr[256];                                       // elements are defines in bytes to ensure correct length
    unsigned char  objID[7];
    unsigned long  sysUpTime;
    unsigned char  sysContact[256];
    unsigned char  sysName[256];
    unsigned char  sysLocation[256];
    unsigned int   sysServices;
    unsigned long  sysORLastChange;
} System;

typedef struct mib_types
{
	char  data[MAX_STR_LEN];
	char	type;
	unsigned char	len;
}mtypes;

typedef struct password
{
	char	name[MAX_PASS_LEN];
	char	type;
} passw;

#define sysD "Test system"

extern QUEUE_HANDLE SerialPortID_M;

extern void fnSendSNMPTrap(unsigned char ucTrap, unsigned char ucSpecificCode);

//static unsigned char sysDescr[MAX_STR_LEN]="TEST system";

#define SNMPV1                       0
#define SNMPV2                       1

#define RO					         -1
#define RW							  1

#define MIB_dod				         6
#define MIB_internet		         1
#define MIB_mgmt			         2
#define MIB_mib2			         1
#define MIB_system				     1
#define MIB_sysDescr			     1
#define MIB_sysObjectID			     2
#define MIB_sysUpTime			     3
#define MIB_sysContact			     4
#define MIB_sysName				     5
#define MIB_sysLocation			     6
#define MIB_sysServices			     7
#define MIB_sysORLastChange		     8

#define ASNOctetString				 0x04
#define ASNInteger					 0x02
#define ASNNull						 0x05
#define ASNObjectIdentifier			 0x06
#define ASNIPAddress				 0x40
#define ASNTimeStamp				 0x43
#define ASNSequence					 0x30
#define ASNGetRequestPDU			 0xA0
#define ASNGetNextRequestPDU		 0xA1
#define ASNGetResponsePDU			 0xA2
#define ASNSetRequestPDU			 0xA3
#define ASNSNMPTrap	                 0xA4
#define ASNGetBulkRequestPDU		 0xA5


#define NoErr						 0x00
#define tooBig						 0x01
#define noSuchName					 0x02
#define badValue					 0x03
#define readOnly					 0x04
#define genErr						 0x05
#define noAccess					 0x06

#define NULL 0

// Traps
#define SNMP_COLDSTART               0
#define SNMP_WARMSTART               1
#define SNMP_LINK_DOWN               2
#define SNMP_LINK_UP                 3
#define SNMP_AUTH_FAILURE            4
#define SNMP_EGP_NEIGHBORLOSS        5
#define SNMP_ENTERPRISE_SPECIFIC     6

typedef struct asn_oid {
	unsigned char	len;
	char subs[ASN_MAXOIDLEN];
} asnoid;

struct mibs {
	unsigned char	len;
	char obj;
	unsigned char (*func_get)(mtypes *mdata, struct asn_oid *moid);
	unsigned char (*func_set)(mtypes *mdata, struct asn_oid *moid);
};

typedef struct s_type
{
	struct asn_oid oid;
	unsigned char  *data;
	unsigned char	type;
} stype;

extern unsigned char ucIP_SNMP_Manager[IPV4_LENGTH];