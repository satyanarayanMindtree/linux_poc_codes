/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        icmp.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    15.03.2010 Extended to include ICMPV6 (USE_IPV6) to handle neighbor solicitation/advertisement and pings
    06.09.2010 Optimise code when the device performs rx or tx offloading {1}

*/
          
//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


#if (defined USE_IPV6 || defined USE_IP) && defined ICMP_SEND_PING
    static void fnReportPing(unsigned char ucTask, unsigned char ucSocket, unsigned char ucResult);
#endif

#if defined USE_ICMP && defined USE_IP                                   // IPV4 ICMP
// This routine is called when an IPV4 frame has been received, which has been recognised as an ICMP type
//
extern void fnHandleICP(unsigned char *icp_data, IP_PACKET *received_ip_packet, unsigned short usLen)
{
    ICMP_ERROR *ptrICP_frame = (ICMP_ERROR *)icp_data;
#if (!defined IP_RX_CHECKSUM_OFFLOAD || !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD) || defined _WINDOWS                  // {1}
    #ifdef ICMP_PING
    unsigned short usCheckSum;
    #endif
    if (IP_GOOD_CS != fnCalcIP_CS(0, icp_data, usLen)) {
        return;                                                          // if the checksum of the ICP frame is corrupt we ignore it
    }
#endif
    switch (ptrICP_frame->ucICMPType) {                                  // ICP type
    #ifdef ICMP_PING
    case (ECHO_PING):                                                    // we simply echo the ICP message back with ECHO_PING_REPLY
        ptrICP_frame->ucICMPType = ECHO_PING_REPLY;                      // overwrite the ICP type for reply
        ptrICP_frame->ucICMPCheckSum[0] = 0;                             // set check sum to zero
        ptrICP_frame->ucICMPCheckSum[1] = 0;
#if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS          // {1}
        usCheckSum = ~fnCalcIP_CS(0, icp_data, usLen);                   // calculate the new checksum of reply
        ptrICP_frame->ucICMPCheckSum[0] = (unsigned char)(usCheckSum>>8);
        ptrICP_frame->ucICMPCheckSum[1] = (unsigned char)(usCheckSum);
#endif
        // note that we do not add an owner to this IP attempt since we have just received an IP and so the IP is unconditionally resolved
        fnSendIP(received_ip_packet->source_IP_address, IP_ICMP, TOS_NORMAL_SERVICE, MAX_TTL, icp_data, usLen, 0, 0);
        break;
    #endif

    #ifdef ICMP_SEND_PING
    case ECHO_PING_REPLY: 
        fnReportPing(ptrICP_frame->ucICMP_variable[0], ptrICP_frame->ucICMP_variable[2], PING_RESULT);
        break;
    #endif

    #ifdef USE_UDP
        #ifdef ICMP_DEST_UNREACHABLE
    case DESTINATION_UNREACHABLE:                                        // if we support UDP we report an error here
        if (ptrICP_frame->ucICMPCode == PORT_UNREACHABLE) {
            if (ptrICP_frame->tCopy_IP_header.ip_protocol == IP_UDP) {
                unsigned char *ptrPort;                                  // UDP port was unreachable - inform listner from Port source
                unsigned short usEmbeddedLength = ((ptrICP_frame->tCopy_IP_header.version_header_length & IP_HEADER_LENGTH_MASK) << 2);  // lengt if IP including any options
                unsigned short usSourcePort, usDestPort;

                ptrPort = (icp_data + usEmbeddedLength + ICMP_HEADER_LENGTH);// set a pointer to the UDP port info in the error message

                usSourcePort = *ptrPort++;                               // extract the UDP ports involved
                usSourcePort <<= 8;
                usSourcePort |= *ptrPort++;
                usDestPort   = *ptrPort++;
                usDestPort   <<= 8;
                usDestPort   |= *ptrPort++;
                fnReportUDP(usSourcePort, usDestPort, UDP_EVENT_PORT_UNREACHABLE, received_ip_packet->destination_IP_address);
            }
        }
        break;
        #endif
    #endif
    }
}

    #if defined ICMP_SEND_PING
// Send an IPV4 ping request
//
extern int fnSendPing(unsigned char *ping_address, unsigned char ttl, UTASK_TASK OwnerTask, USOCKET Socket)
{
    int i = 0;
    unsigned char ucData = 'a';
#if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS          // {1}
    unsigned short usCheckSum;
#endif
    PING_FRAME ping_frame;

    uMemset((unsigned char*)&ping_frame, 0, sizeof(PING_FRAME));         // start with empty frame data

    ping_frame.ucICMPType = ECHO_PING;
  //ping_frame.ucICMPCode = 0;
  //ping_frame.ucICMPCheckSum[0] = 0;
  //ping_frame.ucICMPCheckSum[1] = 0;
    ping_frame.ucICMPIdent[0] = OwnerTask;                               // we pack our owner's details for identification purposes
  //ping_frame.ucICMPIdent[1] = 0;
    ping_frame.ucICMPSequence[0] = Socket;
  //ping_frame.ucICMPSequence[1] = 0;
    while (ucData <= 'z') {
        ping_frame.ucICMPData[i++] = ucData++;
    }
#if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS          // {1}
    usCheckSum = ~fnCalcIP_CS(0, (unsigned char*)&ping_frame, sizeof(PING_FRAME)); // calculate the ICMP frame checksum
    ping_frame.ucICMPCheckSum[0] = (unsigned char)(usCheckSum>>8);
    ping_frame.ucICMPCheckSum[1]   = (unsigned char)(usCheckSum);
#endif
    return (fnSendIP(ping_address, IP_ICMP, TOS_NORMAL_SERVICE, ttl, (unsigned char*)&ping_frame, sizeof(PING_FRAME), OwnerTask, Socket));
}
    #endif

// Report an IPV4 error
//
extern void fnSendICMPError(ICMP_ERROR *tICMP_error, unsigned short usLength)
{
#if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS          // {1}
    unsigned short usChecksum;

    usChecksum = ~fnCalcIP_CS(0, (unsigned char *)tICMP_error, usLength);
    tICMP_error->ucICMPCheckSum[0] = (unsigned char)(usChecksum>>8);     // insert the check sum
    tICMP_error->ucICMPCheckSum[1] = (unsigned char)(usChecksum);
#endif
    fnSendIP(tICMP_error->tCopy_IP_header.source_IP_address, IP_ICMP, TOS_NORMAL_SERVICE, MAX_TTL, (unsigned char *)tICMP_error, usLength, 0, 0);
}
#endif


#if defined USE_IPV6                                                     // IPV6 always uses ICMPV6

// Send a neighbor advertisement
//
static int fnSendIPV6Advertisement(unsigned char *ptrSourceMac, unsigned char *ptrIPV6_address)
{
    IPV6_DISCOVERY_FRAME discovery_frame;
    #if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS      // {1}
    unsigned short usCheckSum;
    #endif

    uMemcpy(discovery_frame.ethernetII.destination_mac_address, ptrSourceMac, MAC_LENGTH);
    uMemcpy(&discovery_frame.ethernetII.source_mac_address, network.ucOurMAC, MAC_LENGTH);
    discovery_frame.ethernetII.ethernet_type[0] = (unsigned char)(PROTOCOL_IPv6 >> 8);
    discovery_frame.ethernetII.ethernet_type[1] = (unsigned char)PROTOCOL_IPv6;
    discovery_frame.ipv6.version_traffic_class = IP_VERSION_6;
    discovery_frame.ipv6.traffic_class_flow = 0;
    discovery_frame.ipv6.flow_lable[0] = discovery_frame.ipv6.flow_lable[1] = 0;
    discovery_frame.ipv6.payload_length[0] = 0;
    discovery_frame.ipv6.payload_length[1] = 32;
    discovery_frame.ipv6.next_header = HEADER_TYPE_ICMPV6;
    discovery_frame.ipv6.hop_limit = 255;
    uMemcpy(discovery_frame.ipv6.source_IP_address, network.ucOurIPV6, IPV6_LENGTH);
    uMemcpy(discovery_frame.ipv6.destination_IP_address, ptrIPV6_address, sizeof(discovery_frame.ipv6.destination_IP_address));
    uMemset(&discovery_frame.icmpv6, 0, sizeof(discovery_frame.icmpv6));
    discovery_frame.icmpv6.ucICMPV6Type = ICMPV6_TYPE_NEIGHBOR_ADVERTISEMENT;
    discovery_frame.icmpv6.ucICMPV6Flags[0] = (SOLICITED_RESPONSE | OVERRIDE);
    uMemcpy(discovery_frame.icmpv6.target_IP_address, network.ucOurIPV6, IPV6_LENGTH);
    discovery_frame.icmpv6.ucICMPV6_option_type = TARGET_LINK_LAYER_ADDRESS;
    discovery_frame.icmpv6.ucICMPV6_option_length = ICMPV6_OPTION_LENGTH_8;
    uMemcpy(discovery_frame.icmpv6.ucICMPV6_option_data, network.ucOurMAC, MAC_LENGTH);
    #if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS      // {1}
    usCheckSum = (HEADER_TYPE_ICMPV6 + 32);
    usCheckSum = fnCalcIP_CS(usCheckSum, (unsigned char *)&discovery_frame.ipv6.source_IP_address, (2 * sizeof(discovery_frame.ipv6.source_IP_address))); // calculate the ICMPV6 checksum - first over pseudo header
    usCheckSum = ~fnCalcIP_CS(usCheckSum, (unsigned char *)&discovery_frame.icmpv6, sizeof(discovery_frame.icmpv6));
    if (usCheckSum == 0) {
        usCheckSum = 0xffff;
    }
    discovery_frame.icmpv6.ucICMPV6CheckSum[0] = (unsigned char)(usCheckSum >> 8);
    discovery_frame.icmpv6.ucICMPV6CheckSum[1] = (unsigned char)usCheckSum;
    #else
    discovery_frame.icmpv6.ucICMPV6CheckSum[0] = 0;
    discovery_frame.icmpv6.ucICMPV6CheckSum[1] = 0;
    #endif
    #ifdef USE_IP_STATS
    fnTxStats(HEADER_TYPE_ICMPV6);                                       // count ICMPV6 transmissions
    #endif

    fnWrite(Ethernet_handle, (unsigned char *)&discovery_frame, sizeof(discovery_frame)); // add the pay load
    return (fnWrite(Ethernet_handle, 0, 0));                             // transmit the ETHERNET frame
}

// Reply to an IPV6 ping by returning the message with rx and tx swapped
//
static int fnSendIPV6EchoResponse(ETHERNET_FRAME_CONTENT *frame_cont, IPV6_DISCOVERY_FRAME_RX *ptrDiscoveryFrame)
{
    unsigned short usLength = ((ptrDiscoveryFrame->ipv6.payload_length[0] << 8) + ptrDiscoveryFrame->ipv6.payload_length[1]);
    ptrDiscoveryFrame->icmpv6.ucICMPV6Type = ICMPV6_TYPE_ECHO_REPLY;
    ptrDiscoveryFrame->icmpv6.ucICMPV6CheckSum[0] = ptrDiscoveryFrame->icmpv6.ucICMPV6CheckSum[1] = 0;
    #ifdef USE_IP_STATS
    fnTxStats(HEADER_TYPE_ICMPV6);                                       // count ICMPV6 transmissions
    #endif
    return (fnSendIPV6(ptrDiscoveryFrame->ipv6.source_IP_address, HEADER_TYPE_ICMPV6, MAX_TTL, (unsigned char *)&ptrDiscoveryFrame->icmpv6, (unsigned short)(usLength), 0, 0));
}

// Send a discovery message to resolve an IPV6 address
//
extern int fnSendIPV6Discovery(unsigned char *ptrIPV6_address)
{
    IPV6_DISCOVERY_FRAME discovery_frame;
    #if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS      // {1}
    unsigned short usCheckSum;
    #endif

    discovery_frame.ethernetII.destination_mac_address[0] = 0x33;        // construct multicast destination address
    discovery_frame.ethernetII.destination_mac_address[1] = 0x33;
    discovery_frame.ethernetII.destination_mac_address[2] = 0xff;
    discovery_frame.ethernetII.destination_mac_address[3] = ptrIPV6_address[13];
    discovery_frame.ethernetII.destination_mac_address[4] = ptrIPV6_address[14];
    discovery_frame.ethernetII.destination_mac_address[5] = ptrIPV6_address[15];
    uMemcpy(&discovery_frame.ethernetII.source_mac_address, network.ucOurMAC, MAC_LENGTH);
    discovery_frame.ethernetII.ethernet_type[0] = (unsigned char)(PROTOCOL_IPv6 >> 8);
    discovery_frame.ethernetII.ethernet_type[1] = (unsigned char)PROTOCOL_IPv6;
    discovery_frame.ipv6.version_traffic_class = IP_VERSION_6;
    discovery_frame.ipv6.traffic_class_flow = 0;
    discovery_frame.ipv6.flow_lable[0] = discovery_frame.ipv6.flow_lable[1] = 0;
    discovery_frame.ipv6.payload_length[0] = 0;
    discovery_frame.ipv6.payload_length[1] = 32;
    discovery_frame.ipv6.next_header = HEADER_TYPE_ICMPV6;
    discovery_frame.ipv6.hop_limit = 255;
    uMemcpy(discovery_frame.ipv6.source_IP_address, network.ucOurIPV6, IPV6_LENGTH);
    uMemcpy(discovery_frame.ipv6.destination_IP_address, ptrIPV6_address, IPV6_LENGTH);
    uMemset(&discovery_frame.icmpv6, 0, sizeof(discovery_frame.icmpv6));
    discovery_frame.icmpv6.ucICMPV6Type = ICMPV6_TYPE_NEIGHBOR_SOLICITATION;
    uMemcpy(discovery_frame.icmpv6.target_IP_address, ptrIPV6_address, IPV6_LENGTH);
    discovery_frame.icmpv6.ucICMPV6_option_type = SOURCE_LINK_LAYER_ADDRESS;
    discovery_frame.icmpv6.ucICMPV6_option_length = ICMPV6_OPTION_LENGTH_8;
    uMemcpy(discovery_frame.icmpv6.ucICMPV6_option_data, network.ucOurMAC, MAC_LENGTH);
    #if !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD || defined _WINDOWS      // {1}
    usCheckSum = (HEADER_TYPE_ICMPV6 + 32);
    usCheckSum = fnCalcIP_CS(usCheckSum, (unsigned char *)&discovery_frame.ipv6.source_IP_address, (2 * sizeof(discovery_frame.ipv6.source_IP_address))); // calculate the ICMPV6 checksum - first over pseudo header
    usCheckSum = ~fnCalcIP_CS(usCheckSum, (unsigned char *)&discovery_frame.icmpv6, sizeof(discovery_frame.icmpv6));
    if (usCheckSum == 0) {
        usCheckSum = 0xffff;
    }
    discovery_frame.icmpv6.ucICMPV6CheckSum[0] = (unsigned char)(usCheckSum >> 8);
    discovery_frame.icmpv6.ucICMPV6CheckSum[1] = (unsigned char)usCheckSum;
    #else
    discovery_frame.icmpv6.ucICMPV6CheckSum[0] = 0;
    discovery_frame.icmpv6.ucICMPV6CheckSum[1] = 0;
    #endif
    #ifdef USE_IP_STATS
    fnTxStats(HEADER_TYPE_ICMPV6);                                       // count ICMPV6 transmissions
    #endif    
    fnWrite(Ethernet_handle, (unsigned char *)&discovery_frame, sizeof(discovery_frame)); // add the pay load
    return (fnWrite(Ethernet_handle, 0, 0));                             // transmit the ETHERNET frame
}

extern int fnHandleICMPV6(ETHERNET_FRAME_CONTENT *frame_cont, IPV6_DISCOVERY_FRAME_RX *ptrDiscoveryFrame, unsigned short usPayloadLength)
{
    #ifdef USE_IP_STATS
    fnRxStats(HEADER_TYPE_ICMPV6);                                       // count ICMPV6 receptions
    #endif
    switch (ptrDiscoveryFrame->icmpv6.ucICMPV6Type) {
    case ICMPV6_TYPE_NEIGHBOR_SOLICITATION:
        fnSendIPV6Advertisement(frame_cont->ethernet_source_MAC, (unsigned char *)ptrDiscoveryFrame->ipv6.source_IP_address);
        break;
    case ICMPV6_TYPE_NEIGHBOR_ADVERTISEMENT:
        fnEnterIPV6Neighbor(frame_cont->ethernet_source_MAC, (unsigned char *)ptrDiscoveryFrame->ipv6.source_IP_address, (MAC_LENGTH | RESOLVED_ADDRESS));
        return 1;                                                        // no need to refresh neighbor table
    #ifdef ICMP_SEND_PING
    case ICMPV6_TYPE_ECHO_REPLY:
        {
            ICMPV6_ECHO_REQUEST *ptrAnswer = (ICMPV6_ECHO_REQUEST *)&ptrDiscoveryFrame->icmpv6;
            fnReportPing(ptrAnswer->ucICMPV6ID[0], ptrAnswer->ucICMPV6sequence[0], PING_IPV6_RESULT);
        }
        break;
    #endif
    case ICMPV6_TYPE_ECHO_REQUEST:
        fnEnterIPV6Neighbor(frame_cont->ethernet_source_MAC, (unsigned char *)ptrDiscoveryFrame->ipv6.source_IP_address, (REFRESH_ADDRESS | MAC_LENGTH));
        fnSendIPV6EchoResponse(frame_cont, ptrDiscoveryFrame);
        return 1;                                                        // no need to refresh neighbor table
    }
    return 0;
}

    #ifdef ICMP_SEND_PING
// Send an IPV6 ping request
//
extern int fnSendV6Ping(unsigned char *ping_address, unsigned char ucttl, UTASK_TASK OwnerTask, USOCKET Socket)
{
    int i = 0;
    unsigned char ucData = 'a'; 
    ICMPV6_ECHO_REQUEST echo_request_frame;

    uMemset((unsigned char*)&echo_request_frame, 0, sizeof(ICMPV6_ECHO_REQUEST)); // start with empty frame data

    echo_request_frame.ucICMPV6Type = ICMPV6_TYPE_ECHO_REQUEST;
  //echo_request_frame.ucICMPV6Code = 0;
  //echo_request_frame.ucICMPV6CheckSum[0] = 0;
  //echo_request_frame.ucICMPV6CheckSum[1] = 0;
    echo_request_frame.ucICMPV6ID[0] = OwnerTask;                        // we pack our owner's details for identification purposes
  //echo_request_frame.ucICMPV6ID[1] = 0;
    echo_request_frame.ucICMPV6sequence[0] = Socket;
  //echo_request_frame.ucICMPV6sequence[1] = 0;
    while (ucData <= 'z') {
        echo_request_frame.ucICMPV6_data[i++] = ucData++;                // insert data content
    }
    return (fnSendIPV6(ping_address, HEADER_TYPE_ICMPV6, ucttl, (unsigned char*)&echo_request_frame, sizeof(ICMPV6_ECHO_REQUEST), OwnerTask, Socket));
}
    #endif
#endif

#if (defined USE_IPV6 || defined USE_IP) && defined ICMP_SEND_PING
// We have received an ECHO ping reply - either promiscuously or as a response to a request we made
// If it is for our IP address, inform the owner that a PING has been received
//
static void fnReportPing(unsigned char ucTask, unsigned char ucSocket, unsigned char ucResult)
{
    unsigned char int_message[ HEADER_LENGTH + 2 ]; // = { 0, 0 , ptrICP_frame->ucICMP_variable[0], TASK_ICMP, 2, PING_RESULT, ptrICP_frame->ucICMP_variable[2] };  define event message for delivery to the ping sending task
    int_message[MSG_DESTINATION_NODE] = int_message[MSG_SOURCE_NODE] = INTERNAL_ROUTE;
    int_message[MSG_DESTINATION_TASK] = ucTask;
    int_message[MSG_SOURCE_TASK]      = TASK_ICMP;
    int_message[MSG_CONTENT_LENGTH]   = 2;
    int_message[MSG_CONTENT_COMMAND]  = ucResult;
    int_message[MSG_CONTENT_COMMAND + 1] = ucSocket;
    fnWrite( INTERNAL_ROUTE, int_message, (HEADER_LENGTH + 2));          // we send details to the owner of the ping request
}
#endif
