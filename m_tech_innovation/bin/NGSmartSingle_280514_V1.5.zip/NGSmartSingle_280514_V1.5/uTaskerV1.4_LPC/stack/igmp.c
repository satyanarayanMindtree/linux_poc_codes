/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        igmp.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2011
    *********************************************************************

*/        

#include "config.h"

#ifdef USE_IGMP

extern signed short fnSendIP_multicast(unsigned char *prIP_to, unsigned char ucProtType, unsigned char *ptrOptions, unsigned short usOptLength, unsigned char *dat, unsigned short usLen);

extern void fnHandleIGMP(int iVersion, unsigned short usOptionLength, IP_PACKET *received_ip_packet, unsigned short usLen)
{
    unsigned char *ptrOptions = received_ip_packet->ip_options;          // pointer to IPv4 options with valid length is usOptionLength
    IGMP_FRAME    *ptrIGMP = (IGMP_FRAME *)(ptrOptions + usOptionLength);// pointer to IGMP field with length usLen

    // Test generating the same message with IP option
    //
    fnSendIP_multicast(ptrIGMP->ucIGMPMulticastAddress, IP_IGMPV2, ptrOptions, usOptionLength, (unsigned char *)ptrIGMP, usLen);
}

#endif

