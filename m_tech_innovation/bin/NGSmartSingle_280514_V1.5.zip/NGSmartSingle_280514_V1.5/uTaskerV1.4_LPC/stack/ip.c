/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        ip.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    08.04.2007 Add SUPPORT_SUBNET_BROADCAST - new function fnSubnetBroadcast() {1}
    25.08.2007 Use static RAM for code from RAM since uMalloc may not always be ready {2}
    11.01.2010 Allow use of fnCalcIP_CS() by IPV6 alone                  {3}
    05.02.2010 Add IPV6                                                  {4}
    06.09.2010 Optimise code when the device performs rx or tx offloading{5}
    06.07.2011 Removed unnecessary copy of received IP options           {6}

*/        

#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
//#include "config.h"


#ifdef USE_IP

#define OWN_TASK                 TASK_IP 

extern unsigned char  MY_ethernet_source_MAC[MAC_LENGTH];			//MAC
extern QUEUE_HANDLE Ethernet_handle;                                     // Ethernet interface handle

#endif

#if defined USE_IP || defined USE_IPV6                                   // {3}
// Check sum calculation used by IP, ICMP, UDP and TCP
//
#ifdef RUN_LOOPS_IN_RAM
unsigned short (*fnCalcIP_CS)(unsigned short cs, unsigned char *dat, unsigned short usLen);
static unsigned short _fnCalcIP_CS(unsigned short cs, unsigned char *dat, unsigned short usLen)
#else
extern unsigned short fnCalcIP_CS(unsigned short cs, unsigned char *dat, unsigned short usLen)
#endif
{
    unsigned char cs_l = (unsigned char)(cs);
    unsigned char cs_h = (unsigned char)(cs >> 8);                       // prime check sum initial value

    while (usLen--) {
        if ((cs_h += *dat) < *dat) {                                     // process MSB
            if ( ++cs_l == 0 ) {
                cs_h++;
            }
        }

        if (!usLen--) {
            break;
        }
        dat++;

        if ((cs_l += *dat) < *dat) {                                     // process LSB
            if ( ++cs_h == 0 ) {
                cs_l++;
            }
        }
        dat++;
    }
    return (((unsigned short)cs_h << 8) + cs_l);
}
#endif
#ifdef USE_IP

#ifdef RUN_LOOPS_IN_RAM
extern void fnInitIP(void)                                               // {2}
{
    #ifdef _WINDOWS
        #define PROG_SIZE  400
    #else
        #define PROG_SIZE  ((CAST_POINTER_ARITHMETIC)fnInitIP - (CAST_POINTER_ARITHMETIC)_fnCalcIP_CS)
    #endif
    static unsigned long ulProgSpace[PROG_SIZE/sizeof(unsigned long)];   // SRAM code space on long boundary

    uMemcpy(ulProgSpace, (unsigned char*)_fnCalcIP_CS, PROG_SIZE);
    fnCalcIP_CS = (unsigned short(*)(unsigned short, unsigned char *, unsigned short))ulProgSpace;
}
#endif

#ifdef SUPPORT_SUBNET_BROADCAST                                          // {1}
// Check to see whether an IP address is a broadcast to out subnet
//
extern int fnSubnetBroadcast(unsigned char *ip_address, unsigned char *subnet_mask, unsigned char ucLength)
{
    while (ucLength--) {
        if ((*ip_address++ | *subnet_mask++) != 0xff) {
            return 0;                                                    // not a broadcast to our subnet
        }
    }
    return 1;                                                            // yes, it is a broadcast to our subnet
}
#endif


// Handle a received IP frame
//
extern int fnHandleIP(ETHERNET_FRAME *frame, unsigned short *usTotalLength)
{    
    unsigned short tLen;
    unsigned char olen;
    IP_PACKET *received_ip_packet;
    if ((frame->ptEth->ethernet_frame_type[1] != (unsigned char)PROTOCOL_IPv4) // not IP frame
       || (frame->frame_size < ETH_HEADER_LEN) || ((frame->frame_size - ETH_HEADER_LEN) < IP_MIN_HLEN) // invalid length
       ) {
        return 0;                                 
    }
    received_ip_packet = (IP_PACKET *)frame->ptEth->ucData;              // use a structure for interpretation of frame

    if ((received_ip_packet->version_header_length & IP_VERSION_MASK) != (IPV4_LENGTH<<4)) { // check IP version
        return 0;                                                        // not IPv4
    }
        
    tLen = received_ip_packet->total_length[0];
    tLen <<= 8; 
    tLen += received_ip_packet->total_length[1];
#if !defined IP_RX_CHECKSUM_OFFLOAD || defined _WINDOWS                  // {5}    
    if (tLen > (frame->frame_size - ETH_HEADER_LEN)) {
        return 0;                                                        // length error
    }
#endif                                                                         
    if ((uMemcmp(received_ip_packet->destination_IP_address, &network.ucOurIP[0], IPV4_LENGTH)) && // check whether we are addressed
#ifdef SUPPORT_SUBNET_BROADCAST                                          // {1}
        (!fnSubnetBroadcast(received_ip_packet->destination_IP_address, &network.ucNetMask[0], IPV4_LENGTH))
#else
        (uMemcmp(received_ip_packet->destination_IP_address, cucBroadcast, IPV4_LENGTH))
#endif
        ) {
#ifdef USE_IP_STATS
        fnRxStats((unsigned char)(received_ip_packet->ip_protocol | FOREIGN_FRAME));
#endif
#ifdef USE_ICMP
                                                                         // not our address, but check whether ICMP
        if (received_ip_packet->ip_protocol != IP_ICMP) {                // if not ICMP protocol we don't accept foreign IP addresses
            return 0;        
        }
        if (uMemcmp(frame->ptEth->ethernet_destination_MAC, &network.ucOurMAC[0], MAC_LENGTH)) { // if we are not (MAC) addressed quit
            return 0;
        }
#else
        return 0;
#endif
    }
#ifdef USE_IP_STATS
    else {
        fnRxStats(received_ip_packet->ip_protocol);
    }
#endif

    olen = ((received_ip_packet->version_header_length & IP_HEADER_LENGTH_MASK) << 2) - IP_MIN_HLEN; // check options    
        
    if (olen > MAX_IP_OPTLEN) {
        return 0;                                                        // option too long
    }
    if (olen > (frame->frame_size - ETH_HEADER_LEN - IP_MIN_HLEN)) {
        return 0;                                                        // option field too long
    }

  //uMemcpy(received_ip_packet->ip_options, (frame->ptEth->ucData + IP_MIN_HLEN), olen); // copy option field {6}
#if !defined IP_RX_CHECKSUM_OFFLOAD || defined _WINDOWS                  // {5}    
    if (IP_GOOD_CS != fnCalcIP_CS(0, frame->ptEth->ucData, (unsigned short)(IP_MIN_HLEN + olen))) {
    #ifndef _WINDOWS                                                     // Win7 offloading is difficult to disable so ignore
        return 0;                                                        // check sum error - quit    
    #endif
    }
#endif
    if (uMemcmp(received_ip_packet->source_IP_address, cucBroadcast, IPV4_LENGTH)) { // add the address to ARP cache as long as not broadcast
        uMemcpy(MY_ethernet_source_MAC,frame->ptEth->ethernet_source_MAC,MAC_LENGTH);			 //MAC
        fnAddARP(received_ip_packet->source_IP_address, frame->ptEth->ethernet_source_MAC, ARP_TEMP_IP);
    }    
        
    if (received_ip_packet->fragment_offset[0] & (IP_MORE_FRAGMENTS >> 8)) {
        return 0;                                                        // fragmented packets not supported
    }
    *usTotalLength = tLen;     
    return (IP_MIN_HLEN + olen);                                         // return length of IP header
}

// This quickly extracts IP info from an embedded ICMP frame - since we sent the embedded frame and its contents have been checked, we do minimum work
//
extern int fnHandleIP_ICP(ETHERNET_FRAME *frame, IP_PACKET *received_ip_packet)
{
    unsigned char *ptrData;
    unsigned char olen;

    ptrData = frame->ptEth->ethernet_destination_MAC;                    // we have no mac addresses so use first location as data

    received_ip_packet->version_header_length = *ptrData;
    ptrData += 2;
    received_ip_packet->total_length[0]  = *ptrData++;
    received_ip_packet->total_length[1]  = *ptrData++;
    ptrData += 5;
    received_ip_packet->ip_protocol = *ptrData++;
    ptrData += 2;
    uMemcpy(received_ip_packet->source_IP_address, ptrData, IPV4_LENGTH);
    ptrData += IPV4_LENGTH;
    uMemcpy(received_ip_packet->destination_IP_address, ptrData, IPV4_LENGTH);
    ptrData += IPV4_LENGTH;
    olen = ((received_ip_packet->version_header_length & IP_HEADER_LENGTH_MASK) << 2) - IP_MIN_HLEN;
    return (IP_MIN_HLEN + olen);                                         // return IP header actual size
}

#if (!defined IP_TX_CHECKSUM_OFFLOAD && !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD) || defined _WINDOWS // {5}
// Check sum calculation over IP frame
//
static unsigned short usCalcIPCheckSum(unsigned char *prtData, unsigned char *ptrIP, unsigned short usLen)
{
    unsigned short usCS;

    usCS = fnCalcIP_CS(0, prtData, usLen); 
    usCS = fnCalcIP_CS(usCS, &network.ucOurIP[0], IPV4_LENGTH);
    usCS = fnCalcIP_CS(usCS, ptrIP, IPV4_LENGTH);

    return (~usCS);                                                      // we do not support options after the IP addresses !!
}
#endif

// Build and transmit an IP frame with payload
//
extern signed short fnSendIP(unsigned char *prIP_to, unsigned char ucProtType, unsigned char ucTypeOfService, unsigned char ucTTL, unsigned char *dat, unsigned short usLen, UTASK_TASK Owner, USOCKET cSocket)
{
    static const unsigned char ucIP_ProtV4[] = {(unsigned char)(PROTOCOL_IPv4 >> 8), (unsigned char)(PROTOCOL_IPv4)};
    static unsigned short usIP_identification_field = 0;                 // IP identification field content initially zero and is incremented in every IP frame

    #define MAX_IP (ETH_HEADER_LEN + IP_MIN_HLEN)                        // no options supported !!
    ARP_TAB *ptrARP;
    unsigned short i;
#if (!defined IP_TX_CHECKSUM_OFFLOAD && !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD) || defined _WINDOWS // {5}
    unsigned short usCheckSum;
#endif
    unsigned char  ucData[MAX_IP];                                       // space for temporary Ethernet II and IP header
    
    if ((ptrARP = fnGetIP_ARP(prIP_to, Owner, cSocket)) == 0) {          // see whether IP is in ARP table
        return NO_ARP_ENTRY;                                             // ARP will normally try to resolve the address here
    }

    uMemcpy(&ucData[0], ptrARP->ucMac, MAC_LENGTH);                      // add datalink (Ethernet addresses) information
    uMemcpy(&ucData[MAC_LENGTH], &network.ucOurMAC[0], MAC_LENGTH);
    uMemcpy(&ucData[2*MAC_LENGTH], ucIP_ProtV4, sizeof(ucIP_ProtV4));
    i = (2*MAC_LENGTH + sizeof(ucIP_ProtV4));
    
    ucData[i++]  = IP_DEFAULT_VERSION_HEADER_LENGTH;                     // construct the IP header with neither options nor fragmentation
    ucData[i++]  = ucTypeOfService;
    ucData[i++]  = (unsigned char)((IP_MIN_HLEN + usLen) >> 8);
    ucData[i++]  = (unsigned char)(IP_MIN_HLEN + usLen);
    ucData[i++]  = (unsigned char)((usIP_identification_field) >> 8);
    ucData[i++]  = (unsigned char)(usIP_identification_field++);
    ucData[i++]  = 0;                                                    // neither flags nor fragments
    ucData[i++]  = 0;
    ucData[i++]  = ucTTL;
    ucData[i++]  = ucProtType;
#if (!defined IP_TX_CHECKSUM_OFFLOAD && !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD) || defined _WINDOWS // {5}
    usCheckSum   = usCalcIPCheckSum(&ucData[i - 10], prIP_to, 10);       // calculate the checksum over the IP header (including source and destination IP addresses)
    ucData[i++]  = (unsigned char)((usCheckSum) >> 8);                   // insert the checksum value
    ucData[i++]  = (unsigned char)(usCheckSum);
#else
    ucData[i++]  = 0;
    ucData[i++]  = 0;
#endif
    uMemcpy(&ucData[i], &network.ucOurIP[0], IPV4_LENGTH);               // add source and destination IP addresses
    i += IPV4_LENGTH;    
    uMemcpy(&ucData[i], prIP_to, IPV4_LENGTH); 
    i += IPV4_LENGTH;
#ifdef USE_IP_STATS
    fnTxStats(ucProtType);                                               // perform Tx statistics
#endif
    
    if (!(i = (int)fnWrite(Ethernet_handle, ucData, (QUEUE_TRANSFER)i))) { // prepare the IP frame for transmission
        return 0;                                                        // failed
    }
#if defined USE_IPV6
    if (dat == 0) {                                                      // this is used when tunneling v6tov4 to leave IPV6 to addits header and payload
        return (unsigned short)i;
    }
#endif
    fnWrite(Ethernet_handle, dat, usLen);                                // add the pay load
    return (fnWrite(Ethernet_handle, 0, 0));                             // transmit the ETHERNET frame
}

#ifdef MULTICAST_IPV4
// Build and transmit a multicast IP frame with payload
//
extern signed short fnSendIP_multicast(unsigned char *prIP_to, unsigned char ucProtType, unsigned char *ptrOptions, unsigned short usOptLength, unsigned char *dat, unsigned short usLen)
{
    // First two fields should be shared with fnSendIP()
    //
    static const unsigned char ucIP_ProtV4[] = {(unsigned char)(PROTOCOL_IPv4 >> 8), (unsigned char)(PROTOCOL_IPv4)};
    static unsigned short usIP_identification_field = 0;                 // IP identification field content initially zero and is incremented in every IP frame




    static const unsigned char ucMulticastIPv4[MAC_LENGTH] = {0x01, 0x00, 0x5e, 0x00, 0x17, 0x0c}; // IPv4 multicast IP address (could be passed as parameter)



    unsigned short i;
#if (!defined IP_TX_CHECKSUM_OFFLOAD && !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD) || defined _WINDOWS
    unsigned short usCheckSum;
#endif
    unsigned char  ucData[ETH_HEADER_LEN + MAX_IP_OPTLEN];               // space for temporary Ethernet II and IP header
    
    uMemcpy(&ucData[0], ucMulticastIPv4, MAC_LENGTH);                    // add multicast address
    uMemcpy(&ucData[MAC_LENGTH], &network.ucOurMAC[0], MAC_LENGTH);      // add own MAC address
    uMemcpy(&ucData[2*MAC_LENGTH], ucIP_ProtV4, sizeof(ucIP_ProtV4));    // add IPv4 protocol identification
    i = (2*MAC_LENGTH + sizeof(ucIP_ProtV4));
    
    ucData[i++]  = (IP_DEFAULT_VERSION_HEADER_LENGTH + (usOptLength/4)); // construct the IP header with options
    ucData[i++]  = TOS_NORMAL_SERVICE;
    ucData[i++]  = (unsigned char)((IP_MIN_HLEN + usOptLength + usLen) >> 8); // length including options
    ucData[i++]  = (unsigned char)(IP_MIN_HLEN + usOptLength + usLen);
    ucData[i++]  = (unsigned char)((usIP_identification_field) >> 8);
    ucData[i++]  = (unsigned char)(usIP_identification_field++);
    ucData[i++]  = 0;                                                    // neither flags nor fragments
    ucData[i++]  = 0;
    ucData[i++]  = 1;                                                    // TTL
    ucData[i++]  = ucProtType;
    ucData[i++]  = 0;                                                    // temporarily set check sum to zero
    ucData[i++]  = 0;
    uMemset(&ucData[i], 0x00, IPV4_LENGTH);                              // source is 0.0.0.0
    i += IPV4_LENGTH;    
    uMemcpy(&ucData[i], prIP_to, IPV4_LENGTH);                           // add destination IP addresses
    i += IPV4_LENGTH;
    uMemcpy(&ucData[i], ptrOptions, usOptLength);                        // add options
#if (!defined IP_TX_CHECKSUM_OFFLOAD && !defined IP_TX_PAYLOAD_CHECKSUM_OFFLOAD) || defined _WINDOWS
    usCheckSum = ~fnCalcIP_CS(0, &ucData[2*MAC_LENGTH + sizeof(ucIP_ProtV4)], (unsigned short)(IP_MIN_HLEN + usOptLength)); // calculate the checksum over the IP header (including source and destination IP addresses and options)
    ucData[ETH_HEADER_LEN + 10]  = (unsigned char)((usCheckSum) >> 8); // insert the checksum value
    ucData[ETH_HEADER_LEN + 11]  = (unsigned char)(usCheckSum);
#endif
    i += usOptLength;
#ifdef USE_IP_STATS
    fnTxStats(ucProtType);                                               // perform Tx statistics
#endif
    
    if (!(i = (int)fnWrite(Ethernet_handle, ucData, (QUEUE_TRANSFER)i))) { // prepare the IP frame for transmission
        return 0;                                                        // failed
    }
#if defined USE_IPV6
    if (dat == 0) {                                                      // this is used when tunneling v6tov4 to leave IPV6 to add its header and payload
        return (unsigned short)i;
    }
#endif
    fnWrite(Ethernet_handle, dat, usLen);                                // add the pay load
    return (fnWrite(Ethernet_handle, 0, 0));                             // transmit the ETHERNET frame
}
#endif


#if defined USE_IPV6                                                     // {4}

static const unsigned char ucIP_ProtV6[] = {(unsigned char)(PROTOCOL_IPv6 >> 8), (unsigned char)(PROTOCOL_IPv6)};

// Build and transmit an IPV6 frame with payload
//
extern signed short fnSendIPV6(unsigned char *prIP_to, unsigned char ucProtType, unsigned char ucTTL, unsigned char *dat, unsigned short usLen, UTASK_TASK Owner, USOCKET cSocket)
{  
#define MAX_IPV6 (ETH_HEADER_LEN + sizeof(IP_PACKET_V6))                 // no options supported !!
    unsigned char *ptrHW_address;
    unsigned short i;
    unsigned char  ucData[MAX_IPV6];                                     // space for temporary Ethernet II and IPV6 header
    int iTunnel = 0;
    
    if ((ptrHW_address = fnGetIPV6_NN(prIP_to, Owner, cSocket)) == 0) {  // see whether IPV6 address is in IPV6 neighbor table
        return NO_ARP_ENTRY;                                             // ARP will normally try to resolve the address here
    }

    uMemcpy(&ucData[0], ptrHW_address, MAC_LENGTH);                      // add datalink (Ethernet addresses) information
    uMemcpy(&ucData[MAC_LENGTH], &network.ucOurMAC[0], MAC_LENGTH);
    uMemcpy(&ucData[2*MAC_LENGTH], ucIP_ProtV6, sizeof(ucIP_ProtV6));
    i = ((2 * MAC_LENGTH) + sizeof(ucIP_ProtV6));

    ucData[i++]       = 0x60;                                            // version_traffic_class
    ucData[i++]       = 0;                                               // traffic_class_flow
    ucData[i++]       = 0;                                               // flow_lable[2]
    ucData[i++]       = 0;
    ucData[i++]       = (unsigned char)(usLen >> 8);                     // payload_length[2]
    ucData[i++]       = (unsigned char)usLen;
    ucData[i++]       = ucProtType;                                      // next_header
    ucData[i++]       = ucTTL;                                           // hop_limit
    if (uMemcmp(prIP_to, &network.ucOurIPV6, 8) != 0) {                  // if not in the local subnet use the IPV4 gateway instead
        static const unsigned char fullIPV6[] = { _IP6_ADD_DIGIT(0x2001), _IP6_ADD_DIGIT(0x0470), _IP6_ADD_DIGIT(0x0026), _IP6_ADD_DIGIT(0x0105), _IP6_ADD_DIGIT(0), _IP6_ADD_DIGIT(0), _IP6_ADD_DIGIT(0), _IP6_ADD_DIGIT(0x0002) };
        uMemcpy(&ucData[i], fullIPV6, IPV6_LENGTH);
        iTunnel = 1;
    }
    else {
        uMemcpy(&ucData[i], &network.ucOurIPV6[0], IPV6_LENGTH);         // add source and destination IP addresses
    }
    i += IPV6_LENGTH;    
    uMemcpy(&ucData[i], prIP_to, IPV6_LENGTH); 
    i += IPV6_LENGTH;

    if (ucProtType == HEADER_TYPE_ICMPV6) {
        unsigned short usCheckSum;                                       // add the checksum by calculating over pseudo-header plus payload, where the pseudo-header consists of the next header type, the payload length, the source IPV6 and destination IPV6 addresses
        usCheckSum = fnCalcIP_CS(ucProtType, (unsigned char*)&ucData[((2 * MAC_LENGTH) + sizeof(ucIP_ProtV6)) + 4], 2);
        usCheckSum = fnCalcIP_CS(usCheckSum, (unsigned char*)&ucData[((2 * MAC_LENGTH) + sizeof(ucIP_ProtV6)) + 8], (2 * IPV6_LENGTH));
        usCheckSum = ~fnCalcIP_CS(usCheckSum, dat, usLen);
        dat[2] = (unsigned char)(usCheckSum >> 8);                       // insert new checksum
        dat[3] = (unsigned char)(usCheckSum);
#ifdef USE_IP_STATS
        fnTxStats(HEADER_TYPE_ICMPV6);                                   // count ICMPV6 transmissions
#endif
    }

    if (iTunnel != 0) {
        static const unsigned char ucTunnel[] = {216, 66, 80, 98};
        i -= ((2 * MAC_LENGTH) + sizeof(ucIP_ProtV6));
        if (!fnSendIP((unsigned char *)ucTunnel, IP_6TO4, TOS_NORMAL_SERVICE, ucTTL, 0, (QUEUE_TRANSFER)(i + usLen), Owner, cSocket)) {
            return 0;
        }
        fnWrite(Ethernet_handle, &ucData[((2 * MAC_LENGTH) + sizeof(ucIP_ProtV6))], (QUEUE_TRANSFER)i); // add IPV6
    }
    else {
        if (!fnWrite(Ethernet_handle, ucData, (QUEUE_TRANSFER)i)) {      // prepare the Ethernet II + IPV6 frame for transmission
            return 0;                                                    // failed
        }
    }
    fnWrite(Ethernet_handle, dat, usLen);                                // add the pay load
    return (fnWrite(Ethernet_handle, 0, 0));                             // transmit the ETHERNET frame
}


// Handle a received IPV6 frame
//
extern void fnHandleIPV6(ETHERNET_FRAME *frame, unsigned short usValidIPV4)
{
    static const unsigned char PC_IPV6[] = { _IP6_ADD_DIGIT(0x2001), _IP6_ADD_DIGIT(0x0470), _IP6_ADD_DIGIT(0x0025), _IP6_ADD_DIGIT(0x0105), _IP6_ADD_DIGIT(0), _IP6_ADD_DIGIT(0), _IP6_ADD_DIGIT(0), _IP6_ADD_DIGIT(0x0002) };
    IPV6_DISCOVERY_FRAME_RX *ptrDiscoveryFrame;
    unsigned short usPayloadLength;
    unsigned short usCheckSum;
    if (usValidIPV4 == 0) {
        ptrDiscoveryFrame = (IPV6_DISCOVERY_FRAME_RX *)(frame->ptEth->ucData);
    }
    else {
        ptrDiscoveryFrame = (IPV6_DISCOVERY_FRAME_RX *)(frame->ptEth->ucData + usValidIPV4);
    }
    usPayloadLength = (ptrDiscoveryFrame->ipv6.payload_length[0] << 8);
    usPayloadLength += ptrDiscoveryFrame->ipv6.payload_length[1];
    if (usPayloadLength > (frame->frame_size - usValidIPV4 - ETH_HEADER_LEN - sizeof(IP_PACKET_V6))) { // check basic payload size validity
        return;                                                          // ignore frames with unrealistic payload size
    }
    #if !defined IP_RX_CHECKSUM_OFFLOAD || defined _WINDOWS              // {5}
    usCheckSum = fnCalcIP_CS(ptrDiscoveryFrame->ipv6.next_header, (unsigned char*)&ptrDiscoveryFrame->ipv6.payload_length, 2); // check pseudo-header plus payload, where the pseudo-header consists of the next header type, the payload length, the source IPV6 and destination IPV6 addresses
    if (IP_GOOD_CS != fnCalcIP_CS(usCheckSum, (unsigned char*)&ptrDiscoveryFrame->ipv6.source_IP_address, (unsigned short)((2 * IPV6_LENGTH) + usPayloadLength))) {
        return;                                                          // quietly discard frame when there is a checksum error
    }
    #endif
    if (!uMemcmp(ptrDiscoveryFrame->ipv6.destination_IP_address, PC_IPV6, IPV6_LENGTH) != 0) { // if it is for PC
        static const unsigned char ucPC_MAC[] = {0x00, 0x1c, 0x23, 0x4d, 0x59, 0xe1};
        static const unsigned char ucPC_IP[] = {192, 168, 0, 187};
        uMemcpy(frame->ptEth->ethernet_destination_MAC, ucPC_MAC, MAC_LENGTH);
        uMemcpy(frame->ptEth->ethernet_source_MAC, &network.ucOurMAC[0], MAC_LENGTH);
        if (usValidIPV4 != 0) {
            IP_PACKET *ptrIPV4 = (IP_PACKET *)(frame->ptEth->ucData);
            uMemcpy(ptrIPV4->destination_IP_address, ucPC_IP, sizeof(ucPC_IP));
            ptrIPV4->ip_checksum[0] = ptrIPV4->ip_checksum[1] = 0;
            usCheckSum = ~fnCalcIP_CS(0, frame->ptEth->ucData, usValidIPV4);
            ptrIPV4->ip_checksum[0] = (unsigned char)(usCheckSum >> 8);
            ptrIPV4->ip_checksum[1] = (unsigned char)(usCheckSum);
            if (!fnWrite(Ethernet_handle, (unsigned char *)frame->ptEth, frame->frame_size)) { // prepare the frame for PC's MAC address
                return;                                                  // failed
            }
        }
        else {
            uMemcpy(frame->ptEth->ethernet_frame_type, ucIP_ProtV6, sizeof(ucIP_ProtV6));
            if (!fnWrite(Ethernet_handle, (unsigned char *)frame->ptEth, ETH_HEADER_LEN)) { // prepare the Ethernet II + IPV6 frame for transmission
                return;                                                  // failed
            }
            fnWrite(Ethernet_handle, (unsigned char *)ptrDiscoveryFrame, (unsigned short)(usPayloadLength + sizeof(ptrDiscoveryFrame->ipv6))); // add the pay load
        }
        fnWrite(Ethernet_handle, 0, 0);                                  // transmit the ETHERNET frame
        return;
    }
    switch (ptrDiscoveryFrame->ipv6.next_header) {
    case HEADER_TYPE_ICMPV6:
        if (fnHandleICMPV6(frame->ptEth, ptrDiscoveryFrame, usPayloadLength) != 0) {
            return;                                                      // no need to refresh neighbor table
        }
        break;
    }
    fnEnterIPV6Neighbor(frame->ptEth->ethernet_source_MAC, (unsigned char *)ptrDiscoveryFrame->ipv6.source_IP_address, (REFRESH_ADDRESS | MAC_LENGTH));
}

#endif

#endif

