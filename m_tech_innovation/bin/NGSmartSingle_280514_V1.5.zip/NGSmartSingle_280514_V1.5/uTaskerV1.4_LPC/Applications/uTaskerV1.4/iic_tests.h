/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        iic_tests.h
   Project:     uTasker Demonstration project
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************

   28.09.2010 Add TEST_SENSIRION

The file is otherwise not specifically linked in to the project since it
is included by application.c when needed.

*/

#if defined IIC_INTERFACE && !defined _IIC_CONFIG
    #define _IIC_CONFIG

  //#define TEST_IIC                                                     // test IIC EEPROM
  //#define TEST_IIC_INTENSIVE                                           // intensive transmitter test
  //#define TEST_DS1307                                                  // test DS1307 RTC via IIC bus
    #define TEST_SENSIRION                                               // test reading temperature and humidity 


    #ifdef TEST_IIC
        #define ADD_EEPROM_READ           0xa5                           // read address of I2C EEPROM
        #define ADD_EEPROM_WRITE          0xa4                           // write address of I2C EEPROM
    #endif
    #ifdef TEST_DS1307
        #define ADDRTC_READ               0xd1                           // read address of DS1307
        #define ADDRTC_WRITE              0xd0                           // write address of DS1307
        #define RTC_CONTROL               0x07                           // location of the RTC control register
        #define RTC_MODE                  0x10                           // enable 1Hz square wave output
        #define CLOCK_NOT_ENABLED         0x80                           // not-enabled bit

        #define STATE_INIT_RTC            0x01                           // in the process of initialising the RTC
        #define STATE_GET_RTC             0x02                           // in the process of retrieving the present time
    #endif
    #ifdef TEST_SENSIRION
        #define ADDSHT21_READ             0x81                           // read address of SHT21
        #define ADDSHT21_WRITE            0x80                           // write address of SHT21

        #define TRIGGER_TEMPERATURE_HOLD_MASTER 0xe3
        #define TRIGGER_HUMIDITY_HOLD_MASTER    0xe5

        #define STATE_READING_TEMPERATURE 0x01
        #define STATE_READING_HUMIDITY    0x02
        #define STATE_PAUSE               0x03
    #endif


/* =================================================================== */
/*                      local structure definitions                    */
/* =================================================================== */

    #ifdef TEST_DS1307                                                   // local structure of present time
        typedef struct stTIME_STRUCTURE
        {
          unsigned char ucYear;                                          // 6 is 2006, 7 is 2007 etc.
          unsigned char ucMonthOfYear;                                   // 0..11
          unsigned char ucDayOfMonth;                                    // 0..31
          unsigned char ucDayOfWeek;                                     // 0..6
          unsigned char ucHourOfDay;                                     // 0..23
          unsigned char ucMinuteOfHour;                                  // 0..59
          unsigned char ucSeconds;                                       // 0..59
        } TIME_STRUCTURE;
    #endif


/* =================================================================== */
/*                 local function prototype declarations               */
/* =================================================================== */
    #if defined TEST_IIC || defined TEST_DS1307 || defined TEST_SENSIRION
        static void fnConfigIIC_Interface(void);
    #endif

    #ifdef TEST_DS1307
        static void fnSaveTime(void);
        static void fnSetTimeStruct(unsigned char *ucInputMessage);
        static void seconds_interrupt(void);
    #endif
    #if defined TEST_SENSIRION
        static void fnNextSensorRequest(void);
    #endif

/* =================================================================== */
/*                     global variable definitions                     */
/* =================================================================== */

    #if defined TEST_IIC || defined TEST_DS1307 || defined TEST_SENSIRION
        QUEUE_HANDLE IICPortID = 0;                                      // handle of I2C interface
    #endif

/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */

    #if defined TEST_DS1307
        static int iRTC_state = 0;
        static TIME_STRUCTURE stPresentTime;                             // time structure with present data and time
    #elif defined TEST_SENSIRION
        static int iSensor_state = STATE_PAUSE;
    #endif
#endif



#if defined _IIC_INIT_CODE && (defined TEST_IIC || defined TEST_DS1307 || defined TEST_SENSIRION)

// Open IIC interface to communicate with an EEPROM or RTC. Read the first 8 bytes from the EEPROM
//
static void fnConfigIIC_Interface(void)
{
    IICTABLE tIICParameters;

    tIICParameters.Channel = OUR_IIC_CHANNEL;
    tIICParameters.usSpeed = 100;                                        // 100k
    tIICParameters.Rx_tx_sizes.TxQueueSize = 64;                         // transmit queue size
    tIICParameters.Rx_tx_sizes.RxQueueSize = 64;                         // receive queue size
    tIICParameters.Task_to_wake = 0;                                     // no wake on transmission

    if ((IICPortID = fnOpen( TYPE_IIC, FOR_I_O, &tIICParameters)) !=0) { // open the channel with defined configurations
    #if defined TEST_IIC
        #ifdef TEST_IIC_INTENSIVE
        iAppState |= STATE_POLLING;                                      // mark test running
        uTaskerStateChange(OWN_TASK, UTASKER_GO);                        // set to polling mode
        #else
        static const unsigned char ucSetEEPROMAddress0[] = {ADD_EEPROM_WRITE, 0};
        static const unsigned char ucReadEEPROM[] = {16, ADD_EEPROM_READ, OWN_TASK};
        fnWrite(IICPortID, (unsigned char *)ucSetEEPROMAddress0, sizeof(ucSetEEPROMAddress0)); // set the EEPROM address to read
        fnRead(IICPortID, (unsigned char *)ucReadEEPROM, 0);             // start the read process of 16 bytes
        #endif	
    #elif defined TEST_DS1307
        static const unsigned char ucStartRTC[] = {ADDRTC_WRITE, RTC_CONTROL, RTC_MODE};
        fnWrite(IICPortID, (unsigned char *)ucStartRTC, sizeof(ucStartRTC)); // initialise RTC - set 1Hz output mode
        fnGetRTCTime();                                                  // get the time (start RTC if not yet running)
        iRTC_state = STATE_INIT_RTC;                                     // mark that we are initialising
    #elif defined TEST_SENSIRION
        uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(4.0*SEC), E_NEXT_SENSOR_REQUEST); // start reading sequence after a delay
    #endif
    }
}
#endif



#if defined _IIC_READ_CODE && defined TEST_IIC
    #ifdef TEST_IIC_INTENSIVE
    if (iAppState & STATE_POLLING) {                                     // if I2C intensive test active
        static unsigned char iic_testMsg[] = {0xaa, 0x00};               // fictional I2C address
        int iLoop = 20;
        while (iLoop--) {
            if (fnWrite(IICPortID, 0, sizeof(iic_testMsg)) > 0) {        // check for room in output queue
                if (fnWrite(IICPortID, iic_testMsg, sizeof(iic_testMsg)) < sizeof(iic_testMsg)) {
                    iic_testMsg[1] = 0;                                  // error
                }
                iic_testMsg[1]++;
            }
            else {
                break;
            }
        }
        uTaskerStateChange(OWN_TASK, UTASKER_GO);                        // ensure we remain in polling mode
    }
    #endif
    if (fnMsgs(IICPortID) != 0) {                                        // if IIC message waiting
        while ((Length = fnRead(IICPortID, ucInputMessage, MEDIUM_MESSAGE)) != 0) {
            static const unsigned char ucSetWriteEEPROM1[] = {ADD_EEPROM_WRITE, 3, 5}; // prepare write of one byte to address 3
            static const unsigned char ucSetWriteEEPROM2[] = {ADD_EEPROM_WRITE, 5, 3,4,5,6,7,8,9,0xa}; // prepare write of multiple bytes to address 5

            int x = 0;
            while (x < Length) {                                         // display received bytes
                fnDebugHex(ucInputMessage[x++], (WITH_LEADIN | WITH_SPACE | 1));
            }
            fnDebugMsg("\r\n");
                                                                         // now change the contents using different writes
            fnWrite(IICPortID, (unsigned char *)&ucSetWriteEEPROM1, sizeof(ucSetWriteEEPROM1)); // start single byte write
            fnWrite(IICPortID, (unsigned char *)&ucSetWriteEEPROM2, sizeof(ucSetWriteEEPROM2)); // start page write
        }
    }
#elif defined _IIC_READ_CODE && defined TEST_DS1307
    if ((iRTC_state & (STATE_INIT_RTC | STATE_GET_RTC)) && (fnMsgs(IICPortID) >= 7)) {
        fnRead(IICPortID, ucInputMessage, 7);                            // get the time and put it into the local time structure
        if (ucInputMessage[0] & CLOCK_NOT_ENABLED) {
            uMemset(&stPresentTime, 0, sizeof(stPresentTime));           // start with cleared memory
            uMemset(ucInputMessage, 0, 7);
            fnSaveTime();                                                // write to RTC, which will also enable oscillator (performed once after power up only)
        }
        fnSetTimeStruct(ucInputMessage);                                 // convert the received time and date to a local format

        if (iRTC_state & STATE_INIT_RTC) {                               // define an input for 1s interrupt
            INTERRUPT_SETUP interrupt_setup;

            interrupt_setup.int_type = PORT_INTERRUPT;                   // identifier when configuring
            interrupt_setup.int_handler = seconds_interrupt;             // handling function
            interrupt_setup.int_port_sense = IRQ_RISING_EDGE;            // interrupt on this edge
    #if defined _M5223X
            interrupt_setup.int_priority = (INTERRUPT_LEVEL_6);          // edge port interrupt priority
            interrupt_setup.int_port_bit = 1;                            // the IRQ input connected
    #elif defined _HW_SAM7X
            interrupt_setup.int_priority = (0);                          // port interrupt priority
            interrupt_setup.int_port = PORT_A;                           // the port used
            interrupt_setup.int_port_bits = PA30;                        // the input connected
    #elif defined _HW_AVR32
            interrupt_setup.int_priority = PRIORITY_GPIO;                // port interrupt priority
            interrupt_setup.int_port = PORT_1;                           // the port used
            interrupt_setup.int_port_bits = PB30;                        // the input connected
    #elif defined _LM3SXXXX
            interrupt_setup.int_priority = 3;                            // port interrupt priority
            interrupt_setup.int_port = PORT_C;                           // the port used
            interrupt_setup.int_port_bit = 6;                            // the input connected
            interrupt_setup.int_port_characteristic = PULLUP_ON;         // enable a pullup
    #elif defined _LPC23XX
            interrupt_setup.int_priority = 8;                            // port interrupt priority
            interrupt_setup.int_port = PORT_0;                           // the port used
            interrupt_setup.int_port_bits = PORT0_BIT7;                  // the input connected
            interrupt_setup.int_port_sense = (IRQ_RISING_EDGE | PULLUP_ON);// interrupt on this edge and activate pullup resistor
    #endif
            fnConfigureInterrupt((void *)&interrupt_setup);              // configure the 1 second interrupt
        }
        iRTC_state = 0;                                                  // RTC state idle
    }
#elif defined _IIC_READ_CODE && defined TEST_SENSIRION
    if (fnRead(IICPortID, ucInputMessage, 3) != 0) {                     // one result at a time, always 3 bytes in length
        switch (iSensor_state) {
        case STATE_READING_TEMPERATURE:                                  // result is temperature measurement result
            {
                static const unsigned char ucTriggerHumidity[] = {ADDSHT21_WRITE, TRIGGER_HUMIDITY_HOLD_MASTER};
                static const unsigned char ucReadHumidity[] = {3, ADDSHT21_READ, OWN_TASK};
                signed long slTemperature;
#ifdef TEMP_HUM_TEST
                GLCD_TEXT_POSITION text_pos;// = {PAINT_LIGHT, 2, 0, FONT_NINE_DOT};
                CHAR cTemp[20];
                CHAR *ptrDecimalPoint;

                        #define ABOVE_LEFT_X   0
                        #define ABOVE_LEFT_Y   0
                        #define BOTTOM_RIGHT_X ((GLCD_X/CGLCD_PIXEL_SIZE) - 1)
                        #define BOTTOM_RIGHT_Y ((GLCD_Y/CGLCD_PIXEL_SIZE) - 1)
                GLCD_STYLE graphic_style;

                        GLCD_RECT_BLINK rect1;
                        rect1.ucMode = (PAINT_DARK);
                        rect1.rect_corners.usX_start = ABOVE_LEFT_X;
                        rect1.rect_corners.usY_start = ABOVE_LEFT_Y + 55;
                        rect1.rect_corners.usX_end = BOTTOM_RIGHT_X;
                        rect1.rect_corners.usY_end = rect1.rect_corners.usY_start + 25;
                        fnDoLCD_rect(&rect1);

                fnWrite(IICPortID, (unsigned char *)ucTriggerHumidity, sizeof(ucTriggerHumidity));
                fnRead(IICPortID, (unsigned char *)ucReadHumidity, 0);   // start the read process of humidity
                iSensor_state = STATE_READING_HUMIDITY;
                slTemperature = ucInputMessage[0];
                slTemperature <<= 8;
                slTemperature |= (ucInputMessage[1] & 0xfc);             // remove status bits
                slTemperature *= 17572;
                slTemperature >>= 16;
                slTemperature -= 4685;                                   // calculated temperature in �C x 100
                ptrDecimalPoint = fnBufferDec(slTemperature, DISPLAY_NEGATIVE, cTemp);
                *ptrDecimalPoint = *(ptrDecimalPoint - 1);
                *(ptrDecimalPoint - 1) = *(ptrDecimalPoint - 2);
                *(ptrDecimalPoint - 2) = '.';
                *(ptrDecimalPoint + 1) = ' ';
                *(ptrDecimalPoint + 2) = 'C';
                *(ptrDecimalPoint + 3) = 0;
              //fnDebugMsg("Temperature = ");
              //fnDebugMsg(cTemp);
              //fnDebugMsg(" C ");

                graphic_style.ucMode = STYLE_PIXEL_COLOR;
                slTemperature /= 100;
                if (slTemperature < 20) {
                    slTemperature = 20;
                }
                else if (slTemperature > 30) {
                    slTemperature = 30;
                }
                slTemperature -= 20;                                     // referenced to 20�C (max �10)
                slTemperature *= 20;                                     // range 0..200
                slTemperature += 55;                                     // range 55..255
                graphic_style.color = (COLORREF)RGB((unsigned char)slTemperature, (255 - ((unsigned char)slTemperature)), (255 - ((unsigned char)slTemperature))); // set color according to temperature
                fnDoLCD_style(&graphic_style);

                text_pos.usX = 40;
                text_pos.usY = 60;
                text_pos.ucFont = FONT_FIFTEEN_DOT;
                text_pos.ucMode = (PAINT_LIGHT | REDRAW /*| GIVE_ACK*/);
                fnDoLCD_text(&text_pos, cTemp);
                graphic_style.ucMode = STYLE_PIXEL_COLOR;
                graphic_style.color = (COLORREF)RGB(255,255,0);
                fnDoLCD_style(&graphic_style);                           // return text color
#else
                CHAR cTemp[20];
                CHAR *ptrDecimalPoint;
                fnWrite(IICPortID, (unsigned char *)ucTriggerHumidity, sizeof(ucTriggerHumidity));
                fnRead(IICPortID, (unsigned char *)ucReadHumidity, 0);   // start the read process of humidity
                iSensor_state = STATE_READING_HUMIDITY;
                slTemperature = ucInputMessage[0];
                slTemperature <<= 8;
                slTemperature |= (ucInputMessage[1] & 0xfc);             // remove status bits
                slTemperature *= 17572;
                slTemperature >>= 16;
                slTemperature -= 4685;                                   // calculated temperature in �C x 100
                ptrDecimalPoint = fnBufferDec(slTemperature, DISPLAY_NEGATIVE, cTemp);
                *ptrDecimalPoint = *(ptrDecimalPoint - 1);
                *(ptrDecimalPoint - 1) = *(ptrDecimalPoint - 2);
                *(ptrDecimalPoint - 2) = '.';
                *(ptrDecimalPoint + 1) = 0;
                fnDebugMsg("Temperature = ");
                fnDebugMsg(cTemp);
                fnDebugMsg(" C ");
#endif
            }
            break;
        case STATE_READING_HUMIDITY:                                     // result is humidity measurement result
            {
                CHAR cHumidity[20];
                CHAR *ptrDecimalPoint;
                unsigned long ulHumidity;
#ifdef TEMP_HUM_TEST
                GLCD_TEXT_POSITION text_pos;// = {PAINT_LIGHT, 2, 0, FONT_NINE_DOT};
                        GLCD_RECT_BLINK rect1;

                        rect1.ucMode = (PAINT_DARK);
                        rect1.rect_corners.usX_start = ABOVE_LEFT_X;
                        rect1.rect_corners.usY_start = ABOVE_LEFT_Y + 80;
                        rect1.rect_corners.usX_end = BOTTOM_RIGHT_X;
                        rect1.rect_corners.usY_end = BOTTOM_RIGHT_Y;
                        fnDoLCD_rect(&rect1);
                ulHumidity = ucInputMessage[0];
                ulHumidity <<= 8;
                ulHumidity |= (ucInputMessage[1] & 0xfc);             // remove status bits
                ulHumidity *= 12500;
                ulHumidity >>= 16;
                ulHumidity -= 600;                                         // calculated humidity in % x 100
                ptrDecimalPoint = fnBufferDec(ulHumidity, 0, cHumidity);
                *ptrDecimalPoint = *(ptrDecimalPoint - 1);
                *(ptrDecimalPoint - 1) = *(ptrDecimalPoint - 2);
                *(ptrDecimalPoint - 2) = '.';
                *(ptrDecimalPoint + 1) = ' ';
                *(ptrDecimalPoint + 2) = '%';
                *(ptrDecimalPoint + 3) = 0;
              //fnDebugMsg("Humidity = ");
              //fnDebugMsg(cHumidity);
              //fnDebugMsg("%\r\n");


                        rect1.ucMode = (PAINT_LIGHT);
                        rect1.rect_corners.usX_start = 5;
                        rect1.rect_corners.usY_start = 110;
                        rect1.rect_corners.usX_end = 155;
                        rect1.rect_corners.usY_end = 115;
                        fnDoLCD_rect(&rect1);

                        rect1.ucMode = (PAINT_DARK);
                        ulHumidity /= 100;
                        ulHumidity += (ulHumidity/2);
                        ulHumidity += 6;
                        rect1.rect_corners.usX_start = (unsigned char)ulHumidity;
                        rect1.rect_corners.usY_start = 111;
                        rect1.rect_corners.usX_end = 154;
                        rect1.rect_corners.usY_end = 114;
                        fnDoLCD_rect(&rect1);

                text_pos.usX = 25;
                text_pos.usY = 85;
                text_pos.ucFont = FONT_EIGHTEEN_DOT;
                text_pos.ucMode = (PAINT_LIGHT | REDRAW /*| GIVE_ACK*/);
                fnDoLCD_text(&text_pos, cHumidity);
                uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(1.0*SEC), E_NEXT_SENSOR_REQUEST); // repeat measurement pair after a delay
#else
                ulHumidity = ucInputMessage[0];
                ulHumidity <<= 8;
                ulHumidity |= (ucInputMessage[1] & 0xfc);             // remove status bits
                ulHumidity *= 12500;
                ulHumidity >>= 16;
                ulHumidity -= 600;                                         // calculated humidity in % x 100
                ptrDecimalPoint = fnBufferDec(ulHumidity, 0, cHumidity);
                *ptrDecimalPoint = *(ptrDecimalPoint - 1);
                *(ptrDecimalPoint - 1) = *(ptrDecimalPoint - 2);
                *(ptrDecimalPoint - 2) = '.';
                *(ptrDecimalPoint + 1) = 0;
                fnDebugMsg("Humidity = ");
                fnDebugMsg(cHumidity);
                fnDebugMsg("%\r\n");
                uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(8.0*SEC), E_NEXT_SENSOR_REQUEST); // repeat measurement pair after a delay
#endif
                iSensor_state = STATE_PAUSE;
            }
            break;
        }
    }
#endif


#if defined _IIC_SENSOR_CODE && defined TEST_SENSIRION
// This routine is called at a periodic rate to start next sensor value requests
//
static void fnNextSensorRequest(void)
{
    static const unsigned char ucTriggerTemperatur[] = {ADDSHT21_WRITE, TRIGGER_TEMPERATURE_HOLD_MASTER};
    static const unsigned char ucReadTemperature[] = {3, ADDSHT21_READ, OWN_TASK};
    fnWrite(IICPortID, (unsigned char *)ucTriggerTemperatur, sizeof(ucTriggerTemperatur));
    fnRead(IICPortID, (unsigned char *)ucReadTemperature, 0);            // start the read process of temperature
    iSensor_state = STATE_READING_TEMPERATURE;                           // mark that we expect the temperature result
}
#endif

#if defined _IIC_RTC_CODE && defined TEST_DS1307

// Get the time from the RTC - start RTC if it is not yet running
//
static void fnGetRTCTime(void)
{
    static const unsigned char ucGetTime[] =  {ADDRTC_WRITE, 0};
    static const unsigned char ucSlave[] = {7, ADDRTC_READ, OWN_TASK};   // read 7 bytes from this address
    fnWrite(IICPortID, (unsigned char*)ucGetTime, sizeof(ucGetTime));    // set the read address
    fnRead(IICPortID, (unsigned char *)ucSlave, 0);                      // start the read process of 7 bytes
}

// Converts between hex number and BCD, avoiding divides...
//
static unsigned char fnBCD(unsigned char ucHex)
{
    unsigned char ucTens = 0;

    while (ucHex >= 10) {
        ucHex -= 10;
        ucTens++;
    }
    ucTens <<= 4;
    ucTens += ucHex;
    return (ucTens);
}

// Save time to RTC and save user settings
//
static void fnSaveTime(void)
{
    unsigned char ucSetRTC[9]; //= {ADDRTC_WRITE, 0, 0, 0, 0, 0, 0, 0, 0}; {35}
    uMemset(ucSetRTC, 0, sizeof(ucSetRTC));
    ucSetRTC[0] = ADDRTC_WRITE;

    uDisable_Interrupt();                                                // protect from interrupts (increments of time) when converting
    ucSetRTC[2] = fnBCD(stPresentTime.ucSeconds);                        // Convert local time format to RTC format before saving
    ucSetRTC[3] = fnBCD(stPresentTime.ucMinuteOfHour);
    ucSetRTC[4] = fnBCD(stPresentTime.ucHourOfDay);
    ucSetRTC[6] = fnBCD(stPresentTime.ucDayOfMonth);
    ucSetRTC[7] = fnBCD(stPresentTime.ucMonthOfYear);
    ucSetRTC[8] = fnBCD(stPresentTime.ucYear);
    uEnable_Interrupt();

    fnWrite(IICPortID, (unsigned char *)ucSetRTC, sizeof(ucSetRTC));     // set new date and time
}

// Convert the received time to a local format
//
static void fnSetTimeStruct(unsigned char *ucInputMessage)
{
    stPresentTime.ucSeconds = ((*ucInputMessage & 0x70)>>4) * 10;
    stPresentTime.ucSeconds += *ucInputMessage++ & 0x0f;

    stPresentTime.ucMinuteOfHour = (*ucInputMessage >> 4) * 10;
    stPresentTime.ucMinuteOfHour += *ucInputMessage++ & 0x0f;

    stPresentTime.ucHourOfDay = ((*ucInputMessage & 0x30) >> 4) * 10;
    stPresentTime.ucHourOfDay += *ucInputMessage++ & 0x0f;

    stPresentTime.ucDayOfWeek = *ucInputMessage++;

    stPresentTime.ucDayOfMonth = (*ucInputMessage >> 4) * 10;
    stPresentTime.ucDayOfMonth += *ucInputMessage++ & 0x0f;

    stPresentTime.ucMonthOfYear = (*ucInputMessage >> 4) * 10;
    stPresentTime.ucMonthOfYear += *ucInputMessage++ & 0x0f;

    stPresentTime.ucYear = (*ucInputMessage >> 4) * 10;
    stPresentTime.ucYear += *ucInputMessage & 0x0f;
}

// This is called from an interrupt routine once a second to update the local time synchronous to the hardware RTC
//
static void seconds_interrupt(void)
{
    if (++stPresentTime.ucSeconds >= 60) {
        stPresentTime.ucSeconds = 0;
        if (++stPresentTime.ucMinuteOfHour >= 60) {
            stPresentTime.ucMinuteOfHour = 0;
            if (++stPresentTime.ucHourOfDay >= 24) {
                stPresentTime.ucHourOfDay = 0;
                if (!(iRTC_state & (STATE_GET_RTC | STATE_INIT_RTC))) {  // if we are not already getting the time
                    iRTC_state |= STATE_GET_RTC;                         // mark that we are expecting the time information
                    fnGetRTCTime();                                      // midnight - we update the date here since the hardware RTC handles the details of date changes
                }
            }
        }
    }
    TOGGLE_TEST_OUTPUT();
}
#endif

