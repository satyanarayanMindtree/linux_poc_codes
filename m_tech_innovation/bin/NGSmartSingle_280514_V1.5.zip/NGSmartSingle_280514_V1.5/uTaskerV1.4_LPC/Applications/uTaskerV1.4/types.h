/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        types.h
   Project:     Single Chip Embedded Internet
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************

   01.03.2007 Increased SAM7 file system dimensions {1} to allow boot loader to operate
   15.09.2007 Add support for Luminary LM3SXXXX
   12.10.2007 Add typedef MEMORY_RANGE_POINTER
   13.03.2008 Add typedef LENGTH_CHUNK_COUNT
   19.02.2009 Add MODBUS_BITS_ELEMENT
   26.02.2009 Add UART_MODE_CONFIG
   16.04.2009 Add optional STRING_OPTIMISATION - note that this is set as standard from V1.4
   26.04.2009 Add AVR32 hardware header
   07.09.2009 Promote app_hw_sam7x.h over sam7x.h                        // {2}
   22.09.2009 Remove "../../Hardware/m5223x/M5223X.h" include to app_hw_m5223x.h // {3}
   01.10.2009 {3} generally for all hardware types                       // {4}
   15.01.2010 Add LPC17XX                                                // {5}
   30.01.2010 Add Flexis32                                               // {6}
   18.06.2010 Add STM32                                                  // {7}
   29.11.2010 Add RX6XX                                                  // {8}
   22.12.2010 Add Kinetis                                                // {9}

*/


#ifndef __TYPES__
#define __TYPES__



// Here we have the capability of optimising the types used by the present system hardware
//
typedef unsigned long     UTASK_TICK;                                    // tick counts from 0 to 0xffffffff
typedef unsigned char     CONFIG_LIMIT;                                  // up to 255 configurations possible
typedef unsigned char     NETWORK_LIMIT;                                 // up to 255 nodes possible
typedef unsigned char     TASK_LIMIT;                                    // the system supports up to 255 tasks
typedef unsigned short    STACK_REQUIREMENTS;                            // the system supports up to 64k heap
typedef unsigned short    HEAP_REQUIREMENTS;                             // the system supports up to 64k heap
typedef unsigned char     TIMER_LIMIT;                                   // the system supports up to 255 timers
typedef   signed char     UTASK_TASK;                                    // task reference
typedef unsigned char     QUEUE_LIMIT;                                   // the system supports up to 255 queues
#define QUEUE_HANDLE      QUEUE_LIMIT                                    // as many queue handles as there are queues
typedef unsigned short    QUEUE_TRANSFER;                                // the system supports transfers to 64k bytes
typedef unsigned char     PHYSICAL_Q_LIMIT;                              // the system supports up to 255 physical queues
typedef unsigned short    DELAY_LIMIT;                                   // delays up to 64k TICKs
typedef unsigned short    MAX_MALLOC;                                    // upto 64k heap chunks
typedef unsigned short    LENGTH_CHUNK_COUNT;                            // http string insertion and chunk counter for dynamic generation {}
#if !defined _HW_NE64                                                    // {1}
    typedef unsigned long   MAX_FILE_LENGTH;                             // over 64k file lengths
    typedef unsigned long   MAX_FILE_SYSTEM_OFFSET;                      // offsets of over 64k in file system - use for file system sizes of larger than 64k
    #ifdef GLOBAL_HARDWARE_TIMER
        typedef unsigned long   CLOCK_LIMIT;                             // 32 bit hardware timer support
    #else
        typedef unsigned short  CLOCK_LIMIT;                             // 16 bit normal hardware timer support
    #endif
#else
    #if defined _HW_NE64 && (defined SPI_FILE_SYSTEM && defined FLASH_FILE_SYSTEM)
        typedef unsigned long   MAX_FILE_LENGTH;                         // up to 64k file lengths
        typedef unsigned long   MAX_FILE_SYSTEM_OFFSET;                  // offsets of up to 64k in file system
    #else
        typedef unsigned short  MAX_FILE_LENGTH;                         // up to 64k file lengths
        typedef unsigned short  MAX_FILE_SYSTEM_OFFSET;                  // offsets of up to 64k in file system
    #endif
    typedef unsigned short  CLOCK_LIMIT;                                 // 16 bit normal and hardware timer support
#endif

// TCP/IP support
//
typedef signed char       USOCKET;                                       // socket support from 0..127 (negative values are errors)


// UART mode
//
#define UART_EXTENDED_MODE
#ifdef UART_EXTENDED_MODE
    typedef unsigned long    UART_MODE_CONFIG;                          // UART mode (use unsigned long for extended mode support)
#else
    typedef unsigned short   UART_MODE_CONFIG;                          // UART mode (use unsigned short for normal mode support)
#endif

// MODBUS
//
#define MODBUS_BITS_ELEMENT_WIDTH 8
//#define MODBUS_BITS_ELEMENT_WIDTH 16
//#define MODBUS_BITS_ELEMENT_WIDTH 32
#if MODBUS_BITS_ELEMENT_WIDTH == 32
    typedef unsigned long   MODBUS_BITS_ELEMENT;
#elif MODBUS_BITS_ELEMENT_WIDTH == 16
    typedef unsigned short  MODBUS_BITS_ELEMENT;
#else
    typedef unsigned char   MODBUS_BITS_ELEMENT;
#endif

// General variable types for portability
//
typedef char              CHAR;

#define STRING_OPTIMISATION                                              // activate to optimise return pointers from string output functions. This is not fully compatible with existing project use

#if defined _HW_NE64 && defined SPI_FILE_SYSTEM && defined FLASH_FILE_SYSTEM // treat pointers as long so that extended virtual address range is possible
    #define MEMORY_RANGE_POINTER   unsigned long
#else
    #define MEMORY_RANGE_POINTER   unsigned char *
#endif


typedef unsigned int size_t;

#ifdef _HW_NE64
    #if defined (_CODE_WARRIOR) && !defined (_WINDOWS)
        #include "stdtypes.h"                                            // some non-standard typedefs required with this compiler
    #endif
  //#include "../../Hardware/ne64/ne64.h"
    #include "app_hw_ne64.h"
#endif
#ifdef _HW_SAM7X
    #include "app_hw_sam7x.h"                                            // {2}
  //#include "../../Hardware/sam7x/sam7x.h"
#endif
#ifdef _M5223X
//  #include "../../Hardware/m5223x/M5223X.h"                            // {3}
    #include "app_hw_m5223x.h"
#endif
#ifdef _FLEXIS32
//  #include "../../Hardware/Flexis32/Flexis32.h"                        // {6}
    #include "app_hw_flexis32.h"
#endif
#ifdef _STR91XF
  //#include "../../Hardware/STR91XF/STR91XF.h"
    #include "app_hw_str91xf.h"
#endif
#ifdef _LPC17XX
    #include "app_hw_lpc17xx.h"                                          // {5}
#endif
#ifdef _KINETIS
    #include "app_hw_kinetis.h"                                          // {9}
#endif
#ifdef _LPC23XX
  //#include "../../Hardware/LPC23XX/LPC23XX.h"
//    #include "app_hw_lpc23xx.h"
      #include "../../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/app_hw_lpc23xx.h"
#endif
#ifdef _LM3SXXXX
    #include "app_hw_LM3SXXXX.h"
  //#include "../../Hardware/LM3SXXXX/LM3SXXXX.h"
#endif
#ifdef _HW_AVR32
    #include "app_hw_AVR32.h"
  //#include "../../Hardware/AVR32/AVR32.h"
#endif
#ifdef _STM32                                                            // {7}
    #include "app_hw_STM32.h"
#endif
#ifdef _RX6XX                                                            // {8}
    #include "app_hw_RX6XX.h"
#endif

#endif                                                                   // end not defined __TYPES__


