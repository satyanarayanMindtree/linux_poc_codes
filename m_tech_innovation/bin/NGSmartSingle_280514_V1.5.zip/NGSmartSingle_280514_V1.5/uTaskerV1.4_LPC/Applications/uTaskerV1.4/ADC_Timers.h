/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        ADC_Timers.h
   Project:     uTasker Demonstration project
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************
   29.08.2009 Add timer frequency and PWM output tests                   {1}
   08.09.2009 Add INTERNAL_TEMP option for Luminary                      {2}
   07.11.2009 Add LPC2XXX PWM test and adjust PWM value to utilise macro {3}
   04.12.2009 Corrected syntax error                                     {4}
   14.01.2010 Add SAM7X PWM test                                         {5}
   03.03.2010 Add SAM7X capture mode test                                {6}
   13.04.2010 Add LPC17XX RIT test                                       {7}
   27.12.2010 Add SUPPORT_PWM_CONTROLLER mode for Luminary devices       {8}

The file is otherwise not specifically linked in to the project since it
is included by application.c when needed.

*/

#if !defined _ADC_TIMER_CONFIG
    #define _ADC_TIMER_CONFIG

    #if defined SUPPORT_ADC                                              // if HW support is enabled
    //#define TEST_ADC                                                   // enable test of ADC operation
    //#define INTERNAL_TEMP                                              // {2} read also internal temperature (Luminary Micro)

        #if defined TEST_ADC && (defined _HW_SAM7X || defined _HW_AVR32) // SAM7X and AVR32 specific tests
          //#define _SAM7X_ADC_TEST1                                     // software controlled ADC triggering with an interrupt on each channel
          //#define _SAM7X_ADC_TEST2                                     // software controlled ADC triggering with a single interrupt on last channel completion
            #define _SAM7X_ADC_TEST3                                     // ADTRG input triggered conversion with a single interrupt on last channel completion
          //#define _SAM7X_ADC_TEST4                                     // TIOA2 output triggered conversion with a single interrupt on last channel completion
          //#define _SAM7X_ADC_TEST5                                     // TIOA2 output triggered conversion with DMA support saving to a sample buffer
          //#define _SAM7X_ADC_TEST6                                     // test zero crossing, high and low triggers
        #endif
    #endif
    #if defined SUPPORT_PIT1 || defined SUPPORT_PITS                     // periodic interrupt
        #define TEST_PIT                                                 // test a user defined periodic interrupt
        #define TEST_PIT_SINGLE_SHOT
      //#define TEST_PIT_PERIODIC
    #endif
    #ifdef SUPPORT_DMA_TIMER                                             // M522XX DMA timers
      //#define TEST_DMA_TIMER                                           // test a user defined periodic interrupt
    #endif
    #ifdef SUPPORT_GENERAL_PURPOSE_TIMER                                 // general purpose timers
      //#define TEST_GPT                                                 // test general purpose timer operation
        #define GPT_CAPTURES     5                                       // when testing captures, collect this many values
    #endif
    #if defined SUPPORT_TIMER                                            // standard timers
      //#define TEST_TIMER                                               // test a user defined timer interrupt
        #ifdef TEST_TIMER
          //#define TEST_SINGLE_SHOT_TIMER                               // test single-shot mode
          //#define TEST_PERIODIC_TIMER                                  // test periodic interrupt mode
          //#define TEST_ADC_TIMER                                       // test periodic ADC trigger mode (Luminary)
            #define TEST_PWM                                             // {1} test generating PWM output from timer
          //#define TEST_CAPTURE                                         // {6} test timer capture mode
        #endif
    #endif
    #ifdef SUPPORT_RIT
        #define RIT_TEST                                                 // {7} LPC17XX repetitive interrupt timer
    #endif

/* =================================================================== */
/*                 local function prototype declarations               */
/* =================================================================== */

    #ifdef TEST_ADC
        static void fnConfigureADC(void);
        #ifdef _M5223X
        static void adc_level_change_low(ADC_INTERRUPT_RESULT *adc_result);
        static void adc_level_change_high(ADC_INTERRUPT_RESULT *adc_result);
        #endif
    #endif
    #ifdef TEST_PIT
        static void fnConfigurePIT(void);
    #endif
    #ifdef TEST_DMA_TIMER
        static void fnConfigure_DMA_Timer(void);
    #endif
    #ifdef TEST_GPT
        static void fnConfigure_GPT(void);
    #endif
    #ifdef TEST_TIMER
        static void fnConfigure_Timer(void);
    #endif
    #if defined TEST_ADC && defined _SAM7X_ADC_TEST5
        static void fnRestartADC(ADC_SETUP *adc_setup);
    #endif
    #ifdef RIT_TEST
        static void fnConfigureRIT(void);
    #endif

/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */

    #if defined TEST_ADC
        #if defined _SAM7X_ADC_TEST5
            unsigned short *ptrADCValues = 0;
        #elif defined _LM3SXXXX
            #ifdef INTERNAL_TEMP
                #define ADC_CHANNELS_LM3S   (ADC_CHANNELS + 1)
            #else
                #define ADC_CHANNELS_LM3S   ADC_CHANNELS
            #endif
            #define ADC_SEQUENCES  2
            #define ADC_SAMPLES_LM3SXXXX (ADC_CHANNELS_LM3S * ADC_SEQUENCES)  // 2 x all channel sample sequences (3 with temperature)
            static unsigned short usADC_samples[ADC_SAMPLES_LM3SXXXX];
        #endif
    #endif

    #ifdef TEST_GPT
        static unsigned long ulCaptureList[GPT_CAPTURES];                // make space for capture values
    #endif
#endif


/* =================================================================== */
/*                      Initialisation code                            */
/* =================================================================== */
#ifdef _ADC_TIMER_INIT
    #ifdef TEST_ADC
        fnConfigureADC();
    #endif
    #ifdef TEST_PIT
        fnConfigurePIT();
    #endif
    #ifdef TEST_DMA_TIMER
        fnConfigure_DMA_Timer();
    #endif
    #ifdef TEST_GPT
        fnConfigure_GPT();
    #endif
    #ifdef TEST_TIMER
        fnConfigure_Timer();
    #endif
    #ifdef RIT_TEST
        fnConfigureRIT();
    #endif
#endif

#ifdef _ADC_TIMER_TIMER_EVENTS                                           // monostable timer event handling
    #if defined TEST_ADC && (defined _HW_SAM7X || defined _HW_AVR32)
            else if (E_NEXT_SAMPLE == ucInputMessage[MSG_TIMER_EVENT]) {
                ADC_SETUP adc_setup;                                     // interrupt configuration parameters
                adc_setup.int_type = ADC_INTERRUPT;                      // identifier when configuring
        #if defined _SAM7X_ADC_TEST5
                fnRestartADC(&adc_setup);
        #else
                adc_setup.int_adc_mode = (ADC_START_OPERATION);          // start next software conversion
        #endif
                fnConfigureInterrupt((void *)&adc_setup);                // configure test interrupt on high level trigger
            }
    #endif
    #if defined TEST_ADC && defined _LM3SXXXX
            else if (E_NEXT_SAMPLE == ucInputMessage[ MSG_TIMER_EVENT ]) {
                fnConfigureADC();                                        // repeat the ADC test
            }
    #endif
#endif

#if defined _ADC_TIMER_INT_EVENTS_1 && defined TEST_GPT                  // specific interrupt event handling
            case CAPTURE_COMPLETE_EVENT:
                {
                    int i = 0;
                    fnDebugMsg("Capture complete\r\n");
                    fnDebugMsg("================\r\n");
                    while (i < GPT_CAPTURES) {                           // list the capture samples
                        fnDebugHex(ulCaptureList[i], (WITH_LEADIN | WITH_CR_LF | sizeof(ulCaptureList[i])));
                        i++;
                    }
                }
                break;
#endif
#if defined _ADC_TIMER_INT_EVENTS_2 && defined TEST_ADC                  // interrupt range event handling
    #if defined _M5223X
                if ((ADC_LOW_7 >= ucInputMessage[MSG_INTERRUPT_EVENT]) && (ADC_HIGH_0 <= ucInputMessage[MSG_INTERRUPT_EVENT])) {
                    ADC_SETUP adc_setup;                                 // interrupt configuration parameters
                    ADC_RESULTS results;
                    adc_setup.int_type = ADC_INTERRUPT;                  // identifier
                    adc_setup.int_priority = ADC_ERR_PRIORITY;           // port interrupt priority
                    adc_setup.int_adc_result = &results;
                    if (ucInputMessage[MSG_INTERRUPT_EVENT] < ADC_LOW_0) {
                        adc_setup.int_adc_bit = (ucInputMessage[MSG_INTERRUPT_EVENT] - ADC_HIGH_0);                           // ADC bit 0
                        fnDebugMsg("ADC change high: ");
                        adc_setup.int_handler = adc_level_change_low;
                        adc_setup.int_adc_int_type = (ADC_LOW_LIMIT_INT);// interrupt types
                        adc_setup.int_low_level_trigger = (unsigned short)(ADC_VOLT * 1.5);
                    }
                    else  {
                        adc_setup.int_adc_bit = (ucInputMessage[MSG_INTERRUPT_EVENT] - ADC_LOW_0);
                        fnDebugMsg("ADC change low: ");
                        adc_setup.int_handler = adc_level_change_high;
                        adc_setup.int_high_level_trigger = (unsigned short)(ADC_VOLT * 2);
                        adc_setup.int_adc_int_type = (ADC_HIGH_LIMIT_INT);// interrupt types
                    }
                    adc_setup.int_adc_mode = (ADC_START_OPERATION | ADC_GET_RESULT);// start operation now and return the present result
                    fnConfigureInterrupt((void *)&adc_setup);            // enter interrupt for low level trigger
                    fnDebugDec(adc_setup.int_adc_bit, 0);
                    fnDebugHex(results.sADC_value[adc_setup.int_adc_bit], (WITH_SPACE | WITH_LEADIN | WITH_CR_LF | 2));
                }
                else if ((ADC_ZERO_CROSS_7 >= ucInputMessage[MSG_INTERRUPT_EVENT]) && (ADC_ZERO_CROSS_0 <= ucInputMessage[MSG_INTERRUPT_EVENT])) {
                    fnDebugMsg("Zero Crossing - channel ");
                    fnDebugDec((ucInputMessage[MSG_INTERRUPT_EVENT] - ADC_ZERO_CROSS_0), WITH_CR_LF);
                }
                else if (ADC_TRIGGER == ucInputMessage[MSG_INTERRUPT_EVENT]) {
                    ADC_SETUP adc_setup;                                 // interrupt configuration parameters
                    ADC_RESULTS results;
                    adc_setup.int_type = ADC_INTERRUPT;                  // identifier
                    adc_setup.int_adc_mode = (ADC_READ_ONLY | ADC_GET_RESULT);
                    adc_setup.int_adc_bit = 0;
                    adc_setup.int_adc_result = &results;
                    fnConfigureInterrupt((void *)&adc_setup);
                    fnDebugMsg("ADC triggered:");
                    fnDebugHex(results.sADC_value[0], (WITH_SPACE | WITH_LEADIN | WITH_CR_LF | sizeof(results.sADC_value[0]))); // {4}
                }
    #elif defined _HW_SAM7X || defined _HW_AVR32
                if (ADC_TRIGGER == ucInputMessage[MSG_INTERRUPT_EVENT]) {
        #if defined _SAM7X_ADC_TEST5
                    int iSamples;
                    unsigned short *ptrSamples = ptrADCValues;
                    fnDebugMsg("ADC results ready:\r\n");
                    fnDebugMsg("First 128 samples -\r\n");
                    for (iSamples = 0; iSamples < 128; iSamples++) {
                        fnDebugHex(*ptrSamples++, (WITH_SPACE | WITH_LEADIN | 2));
                        if (iSamples%8 == 7) {
                            fnDebugMsg("\r\n");
                        }
                    }
                    uTaskerMonoTimer( OWN_TASK, (DELAY_LIMIT)(3.0*SEC), E_NEXT_SAMPLE );
        #else
                    ADC_SETUP   adc_setup;                               // interrupt configuration parameters
                    ADC_RESULTS results;
                    int iChannel;
                    adc_setup.int_type = ADC_INTERRUPT;                  // identifier
                    adc_setup.int_adc_mode = (ADC_READ_ONLY | ADC_ALL_RESULTS);
                    adc_setup.int_adc_result = &results;
                    fnConfigureInterrupt((void *)&adc_setup);
                    fnDebugMsg("ADC results:\r\n");
                    for (iChannel = 0; iChannel < ADC_CHANNELS; iChannel++) {
                        fnDebugDec(iChannel, 0);
                        fnDebugMsg(": ");
                        fnDebugHex(results.sADC_value[iChannel], (WITH_SPACE | WITH_LEADIN | WITH_CR_LF | 2));
                    }
            #if defined _SAM7X_ADC_TEST1 || defined _SAM7X_ADC_TEST2
                    uTaskerMonoTimer( OWN_TASK, (DELAY_LIMIT)(1.0*SEC), E_NEXT_SAMPLE );
            #endif
                    fnDebugMsg("\n");
        #endif
                }
                else if ((ADC_TRIGGER_0 <= ucInputMessage[MSG_INTERRUPT_EVENT]) && (ADC_TRIGGER_7 >= ucInputMessage[MSG_INTERRUPT_EVENT])) {
                    ADC_SETUP   adc_setup;                               // interrupt configuration parameters
                    ADC_RESULTS results;
                    adc_setup.int_type = ADC_INTERRUPT;                  // identifier
                    adc_setup.int_adc_mode = (ADC_READ_ONLY | ADC_GET_RESULT);
                    adc_setup.int_adc_bits = (0x01 << (ucInputMessage[MSG_INTERRUPT_EVENT] - ADC_TRIGGER_0));
                    adc_setup.int_adc_result = &results;
                    fnConfigureInterrupt((void *)&adc_setup);
                    fnDebugMsg("ADC-");
                    fnDebugDec((ucInputMessage[MSG_INTERRUPT_EVENT] - ADC_TRIGGER_0), 0);
                    fnDebugMsg(":");
                    fnDebugHex(results.sADC_value[ucInputMessage[MSG_INTERRUPT_EVENT] - ADC_TRIGGER_0], (WITH_SPACE | WITH_LEADIN | WITH_CR_LF | 2));
                    uTaskerMonoTimer( OWN_TASK, (DELAY_LIMIT)(1.0*SEC), E_NEXT_SAMPLE );
                }
        #if defined _SAM7X_ADC_TEST6
                else if ((ADC_TRIGGER_5_ZERO <= ucInputMessage[MSG_INTERRUPT_EVENT]) && (ADC_TRIGGER_6_HIGH >= ucInputMessage[MSG_INTERRUPT_EVENT])) {
                    fnDebugMsg("ADC trigger channel ");
                    if ((ADC_TRIGGER_5_HIGH == ucInputMessage[MSG_INTERRUPT_EVENT]) || (ADC_TRIGGER_5_ZERO == ucInputMessage[MSG_INTERRUPT_EVENT]) || (ADC_TRIGGER_5_LOW == ucInputMessage[MSG_INTERRUPT_EVENT])) {
                        fnDebugMsg("5:");
                    }
                    else {
                        fnDebugMsg("6: ");
                        ucInputMessage[MSG_INTERRUPT_EVENT] -= 1;
                    }
                    switch (ucInputMessage[MSG_INTERRUPT_EVENT]) {
                    case ADC_TRIGGER_5_LOW:
                        fnDebugMsg("low trigger\r\n");
                        break;
                    case ADC_TRIGGER_5_HIGH:
                        fnDebugMsg("high trigger\r\n");
                        break;
                    case ADC_TRIGGER_5_ZERO:
                        fnDebugMsg("zero crossing trigger\r\n");
                        break;
                    }
                }
        #endif
    #elif defined _LM3SXXXX
                if (ADC_TRIGGER == ucInputMessage[MSG_INTERRUPT_EVENT]) {
                    int x;
                    fnDebugMsg("ADC Values:\r\n");
                    fnDebugMsg("===========");
                    for (x = 0; x < ADC_SAMPLES_LM3SXXXX; x++) {
                        fnDebugMsg("\r\nSample-");
                        fnDebugDec(x, 0);
                        fnDebugMsg(" = ");
                        fnDebugHex(usADC_samples[x], (WITH_LEADIN | sizeof(usADC_samples[x])));
                    }
                    fnDebugMsg("\r\n");
                    uTaskerMonoTimer( OWN_TASK, (DELAY_LIMIT)(5*SEC), E_NEXT_SAMPLE );
                }
    #endif
#endif



#if defined _ADC_TIMER_ROUTINES && defined TEST_ADC
    #if defined _HW_SAM7X || defined _HW_AVR32
        #ifdef _SAM7X_ADC_TEST1
static void adc_sample_complete(ADC_INTERRUPT_RESULT *adc_result)
{
    fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_TRIGGER_0 + adc_result->ucADC_channel));
}
        #elif !defined _SAM7X_ADC_TEST6
static void adc_all_samples_complete(ADC_INTERRUPT_RESULT *adc_result)
{
    fnInterruptMessage(OWN_TASK, (unsigned char)ADC_TRIGGER);
}
        #endif
        #if defined _SAM7X_ADC_TEST6
static void adc_trigger(ADC_INTERRUPT_RESULT *adc_result)
{
    switch (adc_result->ucADC_channel) {
    case 5:
    case 6:
        if (adc_result->ucADC_flags & ADC_INT_ZERO_CROSSING) {
            fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_TRIGGER_5_ZERO + (adc_result->ucADC_channel - 5)));
        }
        if (adc_result->ucADC_flags & ADC_INT_LOW_LEVEL) {
            fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_TRIGGER_5_LOW  + (adc_result->ucADC_channel - 5)));
        }
        if (adc_result->ucADC_flags & ADC_INT_HIGH_LEVEL) {
            fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_TRIGGER_5_HIGH + (adc_result->ucADC_channel - 5)));
        }
        break;
    }
}
        #endif

// ADC configuration for SAM7X / AVR32
//
static void fnConfigureADC(void)
{
        #ifdef _WINDOWS
            #define ADC_SAMPLES 10
        #else
            #define ADC_SAMPLES 1024
        #endif
    #define ADC_INPUTS  3
    ADC_SETUP adc_setup;                                                 // interrupt configuration parameters
    adc_setup.int_type = ADC_INTERRUPT;                                  // identifier when configuring
    adc_setup.int_priority = ADC_ERR_PRIORITY;                           // ADC interrupt priority
    adc_setup.int_adc_bits = (ADC_CHANNEL_0 | ADC_CHANNEL_5 | ADC_CHANNEL_6); // enable ADC bits 0, 5 and 6
    adc_setup.int_adc_result = 0;                                        // no result is requested
    adc_setup.int_adc_speed = (ADC_SAMPLING_SPEED(5000000));             // 5MHz sampling (5MHz is maximum for 10 bit mode and 8MHz maximum for 8 bit mode)

        #if defined _SAM7X_ADC_TEST1
    adc_setup.int_adc_int_type = (ADC_END_OF_SCAN_INT);                  // interrupt type - interrupt for each channel
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_SINGLE_SHOT_MODE | ADC_START_OPERATION); // single shot conversion, triggered immediately
    adc_setup.int_handler = adc_sample_complete;                         // handling function
        #elif defined _SAM7X_ADC_TEST2
    adc_setup.int_adc_int_type = (ADC_END_OF_SCAN_INT | ADC_SINGLE_SHOT_TRIGGER_INT); // interrupt type - single interrupt for last channel completed
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_SINGLE_SHOT_MODE | ADC_START_OPERATION); // single shot conversion, triggered immediately
    adc_setup.int_handler = adc_all_samples_complete;                    // handling function
        #elif defined _SAM7X_ADC_TEST3
    adc_setup.int_adc_int_type = (ADC_END_OF_SCAN_INT | ADC_SINGLE_SHOT_TRIGGER_INT); // interrupt type - single interrupt for last channel completed
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_SINGLE_SHOT_MODE | ADC_TRIGGERED_EXT); // single shot conversion, triggered immediately
    adc_setup.int_handler = adc_all_samples_complete;                    // handling function
        #elif defined _SAM7X_ADC_TEST4
    adc_setup.int_adc_int_type = (ADC_END_OF_SCAN_INT | ADC_SINGLE_SHOT_TRIGGER_INT); // interrupt type - single interrupt for last channel completed
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_LOOP_MODE | ADC_TRIGGERED_TIM2); // single shot conversion, triggered immediately
    adc_setup.int_handler = adc_all_samples_complete;                    // handling function
    adc_setup.int_adc_sample_rate = 1;                                   // 1Hz sampling rate - controlled by timer 2
        #elif defined _SAM7X_ADC_TEST5
    ptrADCValues = uMalloc(ADC_SAMPLES * 2 * ADC_INPUTS);                // space for sample values (in 10 bit mode each sample occupies 2 bytes)
    adc_setup.int_adc_int_type = (ADC_ENABLE_INTS);                      // interrupt type - interrupt on sample buffer full
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_LOOP_MODE | ADC_TRIGGERED_TIM2); // single shot conversion, triggered immediately
    adc_setup.int_handler = adc_all_samples_complete;                    // handling function
    adc_setup.int_adc_sample_rate = 1000;                                // 1kHz sampling rate - controlled by timer 2
    adc_setup.int_samples = (ADC_SAMPLES * ADC_INPUTS);                  // sample buffer size to be filled before interrupting
    adc_setup.int_adc_result = (void *)ptrADCValues;
        #elif defined _SAM7X_ADC_TEST6
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_LOOP_MODE | ADC_TRIGGERED_TIM2); // configure automatic trigger mode of operation
    adc_setup.int_zero_crossing_trigger = (unsigned short)(ADC_VOLT_10BIT * 1.65); // zero crossing value
    adc_setup.int_high_level_trigger = (unsigned short)(ADC_VOLT_10BIT * 2.5);// high trigger level
    adc_setup.int_low_level_trigger = (unsigned short)(ADC_VOLT_10BIT * 0.7); // low trigger level
    adc_setup.int_adc_sample_rate = 1;                                   // 1Hz sampling rate - controlled by timer 2
    adc_setup.int_adc_bits = (ADC_CHANNEL_5);                            // enable ADC bit 5
    adc_setup.int_handler = adc_trigger;                                 // handling function
    adc_setup.int_adc_int_type = (ADC_ZERO_CROSSING_INT_POSITIVE | ADC_ZERO_CROSSING_INT_NEGATIVE | ADC_LOW_LIMIT_INT | ADC_HIGH_LIMIT_INT | ADC_SINGLE_SHOT_TRIGGER_INT | ADC_SINGLE_SHOT_CROSSING_INT); // interrupt type - interrupt on and triggers but only once on each type
    fnConfigureInterrupt((void *)&adc_setup);                            // configure
    adc_setup.int_adc_mode = (ADC_CONFIGURE_CHANNEL | ADC_LOOP_MODE);    // add a trigger channel
    adc_setup.int_zero_crossing_trigger = (unsigned short)(ADC_VOLT_10BIT * 1.65); // zero crossing value
    adc_setup.int_high_level_trigger = (unsigned short)(ADC_VOLT_10BIT * 3.1);// high trigger level
    adc_setup.int_low_level_trigger = (unsigned short)(ADC_VOLT_10BIT * 0.35);// low trigger level
    adc_setup.int_adc_bits = (ADC_CHANNEL_6);                            // enable ADC bit 6
    adc_setup.int_adc_int_type = (ADC_ZERO_CROSSING_INT_POSITIVE | ADC_ZERO_CROSSING_INT_NEGATIVE | ADC_LOW_LIMIT_INT | ADC_HIGH_LIMIT_INT); // interrupt type - interrupt continuously
        #endif
    fnConfigureInterrupt((void *)&adc_setup);                            // configure
}
        #ifdef _SAM7X_ADC_TEST5
static void fnRestartADC(ADC_SETUP *adc_setup)
{
    adc_setup->int_adc_int_type = (ADC_ENABLE_INTS);                     // interrupt type - interrupt on sample buffer full
    adc_setup->int_priority = ADC_ERR_PRIORITY;                          // ADC interrupt priority
    adc_setup->int_adc_bits = (ADC_CHANNEL_0 | ADC_CHANNEL_5 | ADC_CHANNEL_6);// enable ADC bits 0, 5 and 6
    adc_setup->int_adc_mode = (ADC_CONFIGURE_CHANNEL | ADC_LOOP_MODE | ADC_TRIGGERED_TIM2); // single shot conversion, triggered immediately
    adc_setup->int_handler = adc_all_samples_complete;                   // handling function
    adc_setup->int_adc_sample_rate = 1000;                               // 1kHz sampling rate - controlled by timer 2
    adc_setup->int_samples = (ADC_SAMPLES * ADC_INPUTS);                 // sample buffer
    adc_setup->int_adc_result = (void *)ptrADCValues;
}
        #endif
    #elif defined _LM3SXXXX
static void adc_samples_ready(void)
{
    fnInterruptMessage(OWN_TASK, (unsigned char)ADC_TRIGGER);
}

static void fnConfigureADC(void)
{
    ADC_SETUP adc_setup;                                                 // interrupt configuration parameters
    adc_setup.int_type = ADC_INTERRUPT;                                  // identifier when configuring
    adc_setup.int_handler = adc_samples_ready;                           // handling function
    adc_setup.int_priority = PRIORITY_ADC;                               // ADC interrupt priority
        #if ADC_CHANNELS >= 8                                            // Luminary devices with 8 or more ADC inputs
  //adc_setup.int_adc_single_ended_inputs = (ADC_CHANNEL_0 | ADC_CHANNEL_1 | ADC_CHANNEL_2 | ADC_CHANNEL_3); // ADC channels 0..3 as single ended inputs 
    adc_setup.int_adc_single_ended_inputs = (ADC_CHANNEL_8 | ADC_CHANNEL_9 | ADC_CHANNEL_10 | ADC_CHANNEL_11); // ADC channels 0..3 as single ended inputs 
  //adc_setup.int_adc_differential_inputs = (ADC_CHANNEL_4 | ADC_CHANNEL_5 | ADC_CHANNEL_6 | ADC_CHANNEL_7); // ADC channels 4-5 and 6-7 as differential inputs
    adc_setup.int_adc_differential_inputs = (ADC_CHANNEL_12 | ADC_CHANNEL_13 | ADC_CHANNEL_14 | ADC_CHANNEL_15); // ADC channels 12-13 and 14-15 as differential inputs
        #else
            #ifdef INTERNAL_TEMP
    adc_setup.int_adc_single_ended_inputs = (ADC_CHANNEL_0 | ADC_CHANNEL_1 | ADC_CHANNEL_4_INTERNAL_TEMP);// ADC channels 0..1 as single ended inputs plus internal temperature
            #else
    adc_setup.int_adc_single_ended_inputs = (ADC_CHANNEL_0 | ADC_CHANNEL_1); // ADC channels 0..1 as single ended inputs
            #endif
    adc_setup.int_adc_differential_inputs = (ADC_CHANNEL_2 | ADC_CHANNEL_3); // ADC channels 2..3 as differential inputs
        #endif
        #ifdef TEST_ADC_TIMER
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_TRIGGER_TIMER);    // triggered from timer
        #else
  //adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_TRIGGER_GPIO_PB4_FALLING); // triggered by Port B-4 on a falling edge
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_START_OPERATION);  // immediate start under SW control
        #endif
    adc_setup.int_adc_averaging = HW_AVERAGING_64;                       // basic sampling speed is 1MHz but can be averaged to improve accuracy or reduce speed
  //adc_setup.int_adc_averaging = NO_HW_AVERAGING;                       // disable hardware averaging for highest speed
    adc_setup.int_adc_result = usADC_samples;                            // location to save the samples to
    adc_setup.int_sequence_count = ADC_SEQUENCES;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure and start sequence
}
    #else                                                                // M5223X

// This interrupt is called when the ADC level changes above programmed threshold (on one of the enabled channels)
//
static void adc_level_change_high(ADC_INTERRUPT_RESULT *adc_result)
{
    if (!adc_result) {
        fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_TRIGGER));
        return;
    }
    if (adc_result->ucADC_flags == ADC_INT_ZERO_CROSSING) {
        fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_ZERO_CROSS_0 + adc_result->ucADC_channel));
    }
    else {
        fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_HIGH_0 + adc_result->ucADC_channel));
    }
}

// this interrupt is called when the ADC level changes below programmed threshold (on one of the enabled channels)
//
static void adc_level_change_low(ADC_INTERRUPT_RESULT *adc_result)
{
    fnInterruptMessage(OWN_TASK, (unsigned char)(ADC_LOW_0 + adc_result->ucADC_channel));
}


static void fnConfigureADC(void)
{
    ADC_SETUP adc_setup;                                                 // interrupt configuration parameters
    adc_setup.int_type = ADC_INTERRUPT;                                  // identifier when configuring
    adc_setup.int_handler = adc_level_change_high;                       // handling function
    adc_setup.int_priority = ADC_ERR_PRIORITY;                           // ADC interrupt priority
    adc_setup.int_adc_bit = 0;                                           // ADC bit 0
    adc_setup.int_adc_int_type = (ADC_HIGH_LIMIT_INT);                   // interrupt types
  //adc_setup.int_adc_int_type = (ADC_END_OF_SCAN_INT | ADC_SINGLE_SHOT_TRIGGER_INT); // use to test SYNCA trigger
    adc_setup.int_adc_offset = 0;                                        // no offset
    adc_setup.int_high_level_trigger = (unsigned short)(ADC_VOLT * 2);
    adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_SEQUENTIAL_MODE | ADC_SINGLE_ENDED | ADC_LOOP_MODE); // use to test single ended
  //adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_SEQUENTIAL_MODE | ADC_DIFFERENTIAL | ADC_LOOP_MODE); // use to test differential
  //adc_setup.int_adc_mode = (ADC_CONFIGURE_ADC | ADC_CONFIGURE_CHANNEL | ADC_SEQUENTIAL_MODE | ADC_TRIGGERED_MODE); // use to test SYNCA trigger
    adc_setup.int_adc_speed = (unsigned char)(ADC_SAMPLING_SPEED(5000000));// 5MHz sampling (must be between 100kHz and 5MHz)
    adc_setup.int_adc_result = 0;                                        // no result is requested
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger

  //return;                                                              // used when testing SYNCA trigger

/*  example of configuring all ADC inputs with same parameters
    adc_setup.int_adc_mode = (ADC_CONFIGURE_CHANNEL);
    adc_setup.int_adc_bit = 1;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
    adc_setup.int_adc_bit = 2;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
    adc_setup.int_adc_bit = 3;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
    adc_setup.int_adc_bit = 4;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
    adc_setup.int_adc_bit = 5;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
    adc_setup.int_adc_bit = 6;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
    adc_setup.int_adc_bit = 7;
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on high level trigger
*/
    adc_setup.int_adc_mode = (ADC_CONFIGURE_CHANNEL | ADC_SET_CHANNEL_OFFSET);
    adc_setup.int_adc_bit = 1;                                           // channel 1 used to test zero crossing with offset
    adc_setup.int_adc_offset = (unsigned short)(ADC_VOLT * 2.5);         // offset adjustment - for zero crossing
    adc_setup.int_adc_int_type = (ADC_ZERO_CROSSING_INT_POSITIVE | ADC_SINGLE_SHOT_CROSSING_INT); // interrupt types
    fnConfigureInterrupt((void *)&adc_setup);                            // configure test interrupt on zero crossing (2.5V)

    adc_setup.int_adc_int_type = 0;                                      // no interrupt configuration to perform
    adc_setup.int_adc_mode = (ADC_START_OPERATION);
    fnConfigureInterrupt((void *)&adc_setup);                            // start operation now
}
    #endif                                                               // end M5223X
#endif                                                                   // endif ADC configuration and interrupt handling routines




#if defined _ADC_TIMER_ROUTINES && defined TEST_PIT 
    #if defined TEST_PIT_SINGLE_SHOT
static void test_timer_int(void)
{
    static int iTimerTest = 0;
    PIT_SETUP pit_setup;                                                 // interrupt configuration parameters
    TOGGLE_TEST_OUTPUT();
    switch (iTimerTest++) {
    case 0:
        pit_setup.count_delay = PIT_MS_DELAY(1877);                      // 1.877s delay
        pit_setup.mode = PIT_SINGLE_SHOT;                                // one-shot interrupt
        break;
    case 1:
        pit_setup.count_delay = PIT_S_DELAY(5);                          // 5s periodic
        pit_setup.mode = PIT_PERIODIC;                                   // periodic interrupt
        break;
    case 6:
        iTimerTest = 0;                                                  // reset for next test
        pit_setup.mode = PIT_STOP;                                       // stop timer
        break;
    default:
        return;
    }
    pit_setup.int_type = PIT_INTERRUPT;
    pit_setup.int_handler = test_timer_int;
    pit_setup.int_priority = PIT1_INTERRUPT_PRIORITY;
    #ifdef SUPPORT_PITS
    pit_setup.ucPIT = 1;                                                 // use PIT1
    #endif
    fnConfigureInterrupt((void *)&pit_setup);                            // enter interrupt for PIT1 test
}
    #elif defined TEST_PIT_PERIODIC
static void test_nmi(void)
{
    TOGGLE_TEST_OUTPUT();
}
    #endif

// PIT configuration
//
static void fnConfigurePIT(void)
{
    PIT_SETUP pit_setup;                                                 // interrupt configuration parameters
    CONFIG_TEST_OUTPUT();
    pit_setup.int_type = PIT_INTERRUPT;
    #if defined TEST_PIT_SINGLE_SHOT
    pit_setup.int_handler = test_timer_int;                              // test a single shot timer
    pit_setup.int_priority = PIT1_INTERRUPT_PRIORITY;
    pit_setup.count_delay = PIT_US_DELAY(3245);                          // 3245us delay
    pit_setup.mode = PIT_SINGLE_SHOT;                                    // one-shot interrupt
    #elif defined TEST_PIT_PERIODIC
    PORTTC |= (PORT_TC_BIT1 | PORT_TC_BIT2); DDRTC |= (PORT_TC_BIT1 | PORT_TC_BIT2);
    pit_setup.int_handler = test_nmi;
    pit_setup.int_priority = (INTERRUPT_LEVEL_7 | INTERRUPT_PRIORITY_5); // NMI to give a high resolution 50us interrupt (the interrupt may not use operating system calls!)
    pit_setup.count_delay = PIT_US_DELAY(50);                            // 50us delay
    pit_setup.mode = PIT_PERIODIC;
    #endif
    #ifdef SUPPORT_PITS
    pit_setup.ucPIT = 1;                                                 // use PIT1
    #endif
    fnConfigureInterrupt((void *)&pit_setup);                            // enter interrupt for PIT1 test
}
#endif


#if defined _ADC_TIMER_ROUTINES && defined RIT_TEST                      // {7}

static void test_timer_int(void)
{
    static int iTimerTest = 0;
    RIT_SETUP rit_setup;                                                 // interrupt configuration parameters
    TOGGLE_TEST_OUTPUT();
    switch (iTimerTest++) {
    case 0:
        rit_setup.count_delay = RIT_MS_DELAY(1877);                      // 1.877s delay
        rit_setup.mode = RIT_SINGLE_SHOT;                                // one-shot interrupt
        break;
    case 1:
        rit_setup.count_delay = RIT_S_DELAY(5);                          // 5s periodic
        rit_setup.mode = RIT_PERIODIC;                                   // periodic interrupt
        break;
    case 6:
        iTimerTest = 0;                                                  // reset for next test
        rit_setup.mode = RIT_STOP;                                       // stop timer
        break;
    default:
        return;
    }
    rit_setup.int_type = RIT_INTERRUPT;
    rit_setup.int_handler = test_timer_int;
    rit_setup.int_priority = RIT_INTERRUPT_PRIORITY;
    fnConfigureInterrupt((void *)&rit_setup);                            // enter interrupt for RIT test
}

// RIT configuration
//
static void fnConfigureRIT(void)
{
    RIT_SETUP rit_setup;                                                 // interrupt configuration parameters
    CONFIG_TEST_OUTPUT();
    rit_setup.int_type = RIT_INTERRUPT;
    rit_setup.int_handler = test_timer_int;                              // test a single shot timer
    rit_setup.int_priority = RIT_INTERRUPT_PRIORITY;
    rit_setup.count_delay = RIT_US_DELAY(3245);                          // 3245us delay
    rit_setup.mode = RIT_SINGLE_SHOT;                                    // one-shot interrupt
    fnConfigureInterrupt((void *)&rit_setup);                            // enter interrupt for RIT test
}
#endif

#if defined _ADC_TIMER_ROUTINES && defined  TEST_DMA_TIMER
static void DMA_timer_int(void)
{
    static int iTimerTest = 0;
    DMA_TIMER_SETUP dma_timer_setup;                                     // interrupt configuration parameters
    TOGGLE_TEST_OUTPUT();
    switch (iTimerTest++) {
    case 0:
        dma_timer_setup.mode = (DMA_TIMER_INTERNAL_CLOCK | DMA_TIMER_SINGLE_SHOT_INTERRUPT); // one-shot interrupt
        dma_timer_setup.count_delay = DMA_TIMER_MS_DELAY(1,1,2345);      // 2.345s delay
        break;
    case 1:
        dma_timer_setup.mode = (DMA_TIMER_INTERNAL_CLOCK | DMA_TIMER_RESTART_ON_MATCH | DMA_TIMER_PERIODIC_INTERRUPT | DMA_TIMER_INTERNAL_CLOCK_DIV_16); // periodic interrupt
        dma_timer_setup.count_delay = DMA_TIMER_S_DELAY(16,1,2);         // 2s periodic
        break;
    case 6:
        iTimerTest = 0;                                                  // reset for next test
        dma_timer_setup.mode = DMA_TIMER_STOP;                           // stop timer
        break;
    default:
        return;
    }
    dma_timer_setup.channel = 1;
    dma_timer_setup.int_type = DMA_TIMER_INTERRUPT;
    dma_timer_setup.int_handler = DMA_timer_int;
    dma_timer_setup.int_priority = DMA_TIMER1_INTERRUPT_PRIORITY;
    fnConfigureInterrupt((void *)&dma_timer_setup);                      // enter interrupt for DMA timer test
    if (iTimerTest == 2) {                                               // on second test
        dma_timer_setup.channel = 2;
        dma_timer_setup.mode = (DMA_TIMER_RESTART_ON_MATCH | DMA_TIMER_TOGGLE_OUTPUT);
        dma_timer_setup.count_delay = DMA_TIMER_US_DELAY(1,1,(1000000/2/1500)); // 1500Hz signal
        fnConfigureInterrupt((void *)&dma_timer_setup);                  // generate a frequency on TOUT2
    }
}

static void fnConfigure_DMA_Timer(void)
{
    DMA_TIMER_SETUP dma_timer_setup;                                     // interrupt configuration parameters
    CONFIG_TEST_OUTPUT();
    dma_timer_setup.int_type = DMA_TIMER_INTERRUPT;
    dma_timer_setup.int_handler = DMA_timer_int;
    dma_timer_setup.channel = 1;                                         // DMA timer channel 1
    dma_timer_setup.int_priority = DMA_TIMER1_INTERRUPT_PRIORITY;        // define interrupt priority
    dma_timer_setup.mode = (DMA_TIMER_INTERNAL_CLOCK | DMA_TIMER_SINGLE_SHOT_INTERRUPT);
    dma_timer_setup.count_delay = DMA_TIMER_US_DELAY(1,1,6345);          // 6345us delay using no dividers
    fnConfigureInterrupt((void *)&dma_timer_setup);                      // enter interrupt for DMA timer test
}
#endif




#if defined _ADC_TIMER_ROUTINES && defined  TEST_GPT
// Interrupt call back from general purpose timer test
//
static void gptimer_int(void)
{
    fnInterruptMessage(OWN_TASK, CAPTURE_COMPLETE_EVENT);
}

static void fnConfigure_GPT(void)
{
    GPTIMER_SETUP gptimer_setup;                                         // interrupt configuration parameters
    gptimer_setup.int_type = GPT_TIMER_INTERRUPT;
    gptimer_setup.int_handler = gptimer_int;
    gptimer_setup.channel = 3;                                           // general purpose timer channel 3
    gptimer_setup.int_priority = GPTIMER0_INTERRUPT_PRIORITY;            // define interrupt priority
    gptimer_setup.mode = (GPT_CAPTURE_FALLING_EDGE | ENABLE_INPUT_PULLUP | GPT_INTERNAL_CLOCK | GPT_PRESCALE_16); // set up capture mode and define the timer clock
                                                                         // (in this example system clock / 2 / 16 = 1.875MHz with 60MHz: GTP timer overflows at 34.95ms but longer periods can be recorded using the extended option GPT_EXTENDED_COUNTER)
    gptimer_setup.usCaptureCount = GPT_CAPTURES;                         // request this many capture values to be recorded before calling our interrupt
    gptimer_setup.capture_list = ulCaptureList;                          // the capture list for saving to
    fnConfigureInterrupt((void *)&gptimer_setup);                        // enter interrupt for DMA timer test
}
#endif



#if defined _ADC_TIMER_ROUTINES && defined TEST_TIMER
static void timer_int(void)
{
    TOGGLE_TEST_OUTPUT();
    #if defined TEST_SINGLE_SHOT_TIMER
    fnConfigure_Timer();
    #endif
}

static void fnConfigure_Timer(void)
{
    static TIMER_INTERRUPT_SETUP timer_setup = {0};                      // interrupt configuration parameters
    CONFIG_TEST_OUTPUT();
    timer_setup.int_type = TIMER_INTERRUPT;
    timer_setup.int_priority = PRIORITY_TIMERS;
    timer_setup.int_handler = timer_int;
    timer_setup.timer_reference = 2;                                     // timer channel 2
    #ifdef _LM3SXXXX
        #if defined TEST_SINGLE_SHOT_TIMER
    timer_setup.timer_mode = (TIMER_SINGLE_SHOT | TIMER_US_VALUE/* | TIMER_16BIT_CHANNEL_B*/); // single shot timer
    timer_setup.timer_value += 100;                                      // each subsequent delay increased by 100us
        #elif defined TEST_ADC_TIMER
    timer_setup.timer_mode = (TIMER_TRIGGER_ADC | TIMER_PERIODIC | TIMER_MS_VALUE); // period timer
    timer_setup.int_handler = 0;                                         // no interrupts - used together with ADC triggering
    timer_setup.timer_value += 100;                                      // each subsequent delay increased by 100us
        #elif defined TEST_PERIODIC_TIMER
    timer_setup.timer_mode = (TIMER_PERIODIC | TIMER_MS_VALUE);          // period timer interrupt
    timer_setup.timer_value += 100;                                      // each subsequent delay increased by 100us
        #elif defined TEST_PWM                                           // {1}
            #if defined SUPPORT_PWM_CONTROLLER                           // {8}
    timer_setup.int_type    = PWM_CONFIGURATION;
    timer_setup.timer_mode  = PWM_DIV_1;                                 // don't start yet
    timer_setup.timer_value = PWM_FREQUENCY_VALUE(1000, 1);              // generate 1000Hz on timer output using PWM clock without divide
    timer_setup.pwm_value   = _PWM_PERCENT(20, PWM_FREQUENCY_VALUE(1000, 1)); // 20% PWM (high/low)
    fnConfigureInterrupt((void *)&timer_setup);                          // enter configuration for PWM test
    timer_setup.timer_reference = 5;
    timer_setup.timer_mode  = (TIMER_PWM_START_2 | TIMER_PWM_START_5 | PWM_DIV_1); // generate PWM signal on these outputs
    timer_setup.timer_value = PWM_FREQUENCY_VALUE(1500, 1);
    timer_setup.pwm_value   = _PWM_TENTH_PERCENT(706, PWM_FREQUENCY_VALUE(1500, 1)); // 70.6% PWM (high/low) on different channel
            #else
    timer_setup.timer_reference = 0;
    timer_setup.timer_mode  = (TIMER_PWM_B);                             // generate PWM signal on timer output port
    timer_setup.timer_value = TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000));// generate 1000Hz on timer output
    timer_setup.pwm_value   = _PWM_PERCENT(20, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000)));// {3} 20% PWM (high/low)
    timer_setup.int_handler = 0;                                         // no interrupts
    fnConfigureInterrupt((void *)&timer_setup);                          // enter interrupt for timer test
    timer_setup.timer_mode  = (TIMER_PWM_A | TIMER_DONT_DISTURB);        // now set output A but don't disturb (reset) output B
    timer_setup.timer_value = TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1500));// generate 1500Hz on timer output
    timer_setup.pwm_value   = _PWM_TENTH_PERCENT(352, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1500))); // 35.2% PWM (high/low)

//  example of stopping PWM outputs (first one and then complete timer module power down)
//  fnConfigureInterrupt((void *)&timer_setup);                          // enter interrupt for timer test
//  timer_setup.timer_mode  = (TIMER_STOP_PWM_B | TIMER_DONT_DISTURB);   // stop B but don't disturb A
//  fnConfigureInterrupt((void *)&timer_setup);                          // enter interrupt for timer test
//  timer_setup.timer_mode  = (TIMER_STOP_PWM_A);                        // stop A and power down timer module
            #endif
        #endif
    #elif defined _LPC23XX && defined TEST_PWM                           // {3}
    timer_setup.timer_mode  = (TIMER_PWM_MAT0);                          // generate PWM signal on MAT 2.0 output
    timer_setup.timer_value = TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000));// generate 1000Hz on timer output
    timer_setup.pwm_value   = _PWM_PERCENT(20, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000))); // 20% PWM (high/low)
    fnConfigureInterrupt((void *)&timer_setup);                          // enter configuration for PWM test
    timer_setup.timer_mode  = (TIMER_PWM_MAT1 | TIMER_DONT_DISTURB);     // generate PWM signal on MAT 2.1 output without disturbing present signal
    timer_setup.pwm_value   = _PWM_TENTH_PERCENT(706, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000))); // 70.6% PWM (high/low) using same timer but different output
    fnConfigureInterrupt((void *)&timer_setup);                          // enter configuration for PWM test
    timer_setup.timer_reference = 1;
    timer_setup.timer_value = TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1500));// generate 1500Hz on timer output
    timer_setup.pwm_value   = _PWM_PERCENT(50, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1500))); // 50% PWM (high/low)
    #elif (defined _LPC23XX && defined _HW_TIMER_MODE) || defined _LPC17XX || defined _STM32 || defined _KINETIS
        #if defined TEST_PERIODIC_TIMER
    timer_setup.timer_mode = (TIMER_PERIODIC);                           // period timer interrupt (activate HW timer mode if not accepted)
    timer_setup.timer_value = TIMER_MS_DELAY(1000);                      // 1s periodic interrupt
        #else
    timer_setup.timer_value += TIMER_US_DELAY(100);                      // each subsequent delay increased by 100us
        #endif
        #if defined _LPC214X
    timer_setup.timer_reference = 1;                                     // timer channel 1 since timers are limited
        #endif
    #elif defined _HW_SAM7X && defined TEST_PWM                          // {5}
    timer_setup.int_type    = PWM_CONFIGURATION;
    timer_setup.timer_mode  = (TIMER_PWM_ALT);                           // configure PWM signal on alternative PWM2 output
    timer_setup.timer_value = TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000));// generate 1000Hz on timer output
    timer_setup.pwm_value   = _PWM_PERCENT(20, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1000))); // 20% PWM (high/low)
    fnConfigureInterrupt((void *)&timer_setup);                          // enter configuration for PWM test
    timer_setup.timer_reference = 3;
    timer_setup.timer_mode  = (TIMER_PWM | TIMER_PWM_START_2 | TIMER_PWM_START_3); // generate PWM signal on PWM3 output and synchronise all PWM outputs
    timer_setup.timer_value = TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1500));
    timer_setup.pwm_value   = _PWM_TENTH_PERCENT(706, TIMER_US_DELAY(TIMER_FREQUENCY_VALUE(1500))); // 70.6% PWM (high/low) on different channel
    #elif defined _HW_SAM7X && defined TEST_CAPTURE
    timer_setup.timer_mode  = (TIMER_SOURCE_TIOA0);                      // configure clock source on 
    #else
        #if defined TEST_PERIODIC_TIMER
    timer_setup.timer_mode = (TIMER_PERIODIC);                           // period timer interrupt (activate HW timer mode if not accepted)
    timer_setup.timer_value = 1000;                                      // 1s periodic interrupt
        #else
    timer_setup.timer_value = 0;                                         // disable ms time delay
    timer_setup.timer_us_value += 100;                                   // each subsequent delay increased by 100us
        #endif
    #endif
    fnConfigureInterrupt((void *)&timer_setup);                          // enter interrupt for timer test
}
#endif
