/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        NetworkIndicator.c
   Project:     Single Chip Embedded Internet
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************
   20.01.2009  Add debug message for link up/down                        {1}

*/ 

//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


/* =================================================================== */
/*                       local structure definitions                   */
/* =================================================================== */

/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */

/* =================================================================== */
/*                          local definitions                          */
/* =================================================================== */

#ifdef LAN_REPORT_ACTIVITY

#define OWN_TASK               TASK_NETWORK_INDICATOR

#define COLLISION_TIME         (2*SEC)
#define TX_TIME                (0.05*SEC)
#define RX_TIME                (0.1*SEC)

#define E_TIMEOUT              1

#define LINK_LED_ON            0x01
#define COL_LED_ON             0x02
#define TX_LED_OFF             0x04
#define RX_LED_OFF             0x08


/* =================================================================== */
/*                 local function prototype declarations               */
/* =================================================================== */



extern void fnNetworkIndicator(TTASKTABLE *ptrTaskTable)                 // task
{
    QUEUE_HANDLE PortIDInternal = ptrTaskTable->TaskID;                  // queue ID for task input
    unsigned char ucInputMessage[HEADER_LENGTH];                         // reserve space for receiving messages
    static unsigned char ucEvent = 0;

    while (fnRead(PortIDInternal, ucInputMessage, HEADER_LENGTH)) {      // check input queue
        switch (ucInputMessage[ MSG_SOURCE_TASK ]) {
        case TIMER_EVENT:
            if (E_TIMEOUT == ucInputMessage[MSG_TIMER_EVENT]) {
                ACTIVITY_LED_OFF();
                ucEvent &= ~(TX_LED_OFF | RX_LED_OFF | COL_LED_ON);
            }
            break;

        case INTERRUPT_EVENT:
            if (!temp_pars) {
                break;                                                   // if the parameters are not known, we ignore to avoid bad pointer
            }

            switch (ucInputMessage[MSG_INTERRUPT_EVENT]) {

            case EMAC_RX_INTERRUPT:
            case EMAC_TX_INTERRUPT:
                if (ucEvent & (TX_LED_OFF | RX_LED_OFF)) {
                    break;                                               // don't disturb if already blinking
                }
                ACTIVITY_LED_ON();                                       // turn on activity LED (for a short time)

                if (ucInputMessage[MSG_INTERRUPT_EVENT] == EMAC_RX_INTERRUPT) {
                    uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(RX_TIME), E_TIMEOUT); // blink activity LED
                    ucEvent |= RX_LED_OFF;
                }
                else {
                    uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(TX_TIME), E_TIMEOUT); // blink activity LED
                    ucEvent |= TX_LED_OFF;
                }
                break;

            case LAN_LINK_UP_100:
            case LAN_LINK_UP_10:
                fnDebugMsg("LAN link-up 10");                            // {1}
                if (ucInputMessage[MSG_INTERRUPT_EVENT] == LAN_LINK_UP_100) {
                    SPEED_LED_ON();                                      // show link up with 100M
                    fnDebugMsg("0");                                     // {1}
                }
                else {
                    SPEED_LED_OFF();                                     // show link up with 10M
                }                                          
                fnDebugMsg("\r\n");                                      // {1}
                TURN_LINK_LED_ON();
                break;

            case LAN_LINK_DOWN:
                LINK_DOWN_LEDS();
                ucEvent &= ~LINK_LED_ON;
                fnDebugMsg("LAN link-down\r\n");                         // {2}
                break;

            case ETHERNET_COLLISION:
                break;
            }
            break;

        default:
#ifdef SUPPORT_FLUSH
            fnFlush( PortIDInternal, FLUSH_RX);                          // flush unexpected messages
#endif
            break;
        }
    }
}

#endif
