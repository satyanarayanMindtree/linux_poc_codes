/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:   	    KeyScan.c
   Project: 	uTasker Demonstration project
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************
   13.08.2009 Adapt to support non-muliplexed keys with up to 32 keys

   This task supports a matrix key pad with up to 8 columns and 8 rows [KEY_COLUMNS, KEY_ROWS]
   The hardware controls are defined in the project hardware file so that it can easily support various wiring
   on various processors. The ports used can be defined to be any bit on any port.
*/

//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


#ifdef SUPPORT_KEY_SCAN                                                  // activate this define to support Key Scan

#ifdef _WINDOWS
  #define SIM_MATRIX_KB()  fnSimMatrixKB()                               // interraction with the simulator
#else
  #define SIM_MATRIX_KB()                                                // no function on target
#endif



#define OWN_TASK                        TASK_KEY                         // task reference name

#if KEY_COLUMNS > 0
    unsigned char ucCols[KEY_COLUMNS] = {0};                             // present key state
    unsigned char ucColsLast[KEY_COLUMNS] = {0};                         // previous key state
#else
    unsigned long ulCols = INIT_KEY_STATE;                               // present key state
    unsigned long ulColsLast = INIT_KEY_STATE;                           // previous key state
#endif
#if KEY_COLUMNS > 0
    static void fnUpdateInputs(void);
    static void fnSendEvent(unsigned char ucChangedBits, unsigned char ucNewColumn, int iColumn);
#endif
static void fnCheckKeyChanges(void);



// This task is assumed to be polling at an adequate rate (or called directly from a timer interrupt)
//
extern void fnKey(TTASKTABLE *ptrTaskTable)                              // key scan task
{
#if KEY_COLUMNS > 0
    fnUpdateInputs();                                                    // update the present input states
#else
    ulCols = READ_KEY_INPUTS();                                          // read all key inputs
#endif
    fnCheckKeyChanges();                                                 // generate events on changes
}



#if KEY_COLUMNS > 0
// A column is being driven, collect the corresponding row inputs
//
static void fnGetCol(int iRow)
{
    unsigned char ucBits = 0x01;
    ucCols[iRow]    = 0x00;

    #ifdef KEY_ROWS
    if (!(KEY_ROW_IN_PORT_1 & KEY_ROW_IN_1)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 1
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_2 & KEY_ROW_IN_2)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 2
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_3 & KEY_ROW_IN_3)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 3
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_4 & KEY_ROW_IN_4)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 4
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_5 & KEY_ROW_IN_5)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 5
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_6 & KEY_ROW_IN_6)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 6
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_7 & KEY_ROW_IN_7)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
    #if KEY_ROWS > 7
    ucBits <<= 1;
    if (!(KEY_ROW_IN_PORT_8 & KEY_ROW_IN_8)) {
        ucCols[iRow] |= ucBits;
    }
    #endif
}

// Scan all columns - called periodically
//
static void fnUpdateInputs(void)
{
    #ifdef KEY_COLUMNS
    DRIVE_COLUMN_1();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(0);
    RELEASE_COLUMN_1();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 1
    DRIVE_COLUMN_2();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(1);
    RELEASE_COLUMN_2();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 2
    DRIVE_COLUMN_3();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(2);
    RELEASE_COLUMN_3();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 3
    DRIVE_COLUMN_4();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(3);
    RELEASE_COLUMN_4();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 4
    DRIVE_COLUMN_5();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(4);
    RELEASE_COLUMN_5();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 5
    DRIVE_COLUMN_6();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(5);
    RELEASE_COLUMN_6();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 6
    DRIVE_COLUMN_7();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(6);
    RELEASE_COLUMN_7();                                                  // set column to high impedance (with active drive high)
    #endif
    #if KEY_COLUMNS > 7
    DRIVE_COLUMN_8();                               SIM_MATRIX_KB();     // set as output to drive column low
    fnGetCol(7);
    RELEASE_COLUMN_8();                                                  // set column to high impedance (with active drive high)
    #endif
    RESET_SCAN();                                                        // reset any changes ready for next scan sequence
}
#endif


// Check for key press changes. If changes are detected, generate an event for each change and send it to the controlling task
//
static void fnCheckKeyChanges(void)
{
#if KEY_COLUMNS > 0
    int i;
    for (i = 0; i < KEY_COLUMNS; i++) {
        if (ucCols[i] != ucColsLast[i]) {                                // has a change in key pad state been detected?
            fnSendEvent((unsigned char)(ucColsLast[i] ^ ucCols[i]), ucCols[i], i);
            ucColsLast[i] = ucCols[i];                                   // update the backup
        }
    }
#else
    unsigned long ulInput = 0x00000001;
    unsigned long ulChanges = (ulColsLast ^ ulCols);
    unsigned char ucEvent = KEY_EVENT_COL_1_ROW_1_PRESSED;               // event on first input pressed
    while (ulChanges != 0) {
        if (ulChanges & ulInput) {
            ulChanges &= ~ulInput;
            if (ulCols & ulInput) {
                fnInterruptMessage(KEYPAD_PARTNER_TASK, ucEvent);           // send as pressed interrupt event
            }
            else {
                fnInterruptMessage(KEYPAD_PARTNER_TASK, (unsigned char)(ucEvent + 1));// send as released interrupt event
            }
        }
        ucEvent += 2;
        ulInput <<= 1;
    }
    ulColsLast = ulCols;
#endif
}

#if KEY_COLUMNS > 0
// This is called when one or more key press/releases have been detected in a column.
// It generates one event per change and send it as interrupt event to the application task
//
static void fnSendEvent(unsigned char ucChangedBits, unsigned char ucNewColumn, int iColumn)
{
    unsigned char ucBit = 0x01;
    unsigned char ucEvent = KEY_EVENT_COL_1_ROW_1_PRESSED + (iColumn * 2 * KEY_ROWS);

    while (ucChangedBits) {
        if (ucChangedBits & ucBit) {
            if (ucChangedBits & ucNewColumn) {
                fnInterruptMessage(KEYPAD_PARTNER_TASK, ucEvent);           // send as pressed interrupt event
            }
            else {
                fnInterruptMessage(KEYPAD_PARTNER_TASK, (unsigned char)(ucEvent + 1));// send as released interrupt event
            }
            ucChangedBits &= ~ucBit;
        }
        ucBit <<= 1;
        ucEvent += 2;
    }
}
#endif

#endif
