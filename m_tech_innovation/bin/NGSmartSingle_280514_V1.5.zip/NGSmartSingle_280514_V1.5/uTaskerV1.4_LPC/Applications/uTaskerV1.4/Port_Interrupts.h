/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        Port_Interrupts.h
   Project:     uTasker Demonstration project
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************

   28.10.2009 Modify SAM7X initialisation to include glitch filer configuration {1}
   30.12.2009 Modify M522xx use of IRQ7 to NMI technique                 {2}
   10.02.2010 NMI port check only with _M5223X                           {3}
   21.04.2011 Update calls from sendCAN() to fnSendCAN()                 {4}
   Note that the external interrupt tests are not suitable for LPC210x as in this file

The file is otherwise not specifically linked in to the project since it
is included by application.c when needed.

*/

#if !defined _PORT_INTS_CONFIG
    #define _PORT_INTS_CONFIG

  //#define IRQ_TEST                                                     // test IRQ port interrupts


/* =================================================================== */
/*                 local function prototype declarations               */
/* =================================================================== */
    #if defined IRQ_TEST
        static void fnInitIRQ(void);

        #if defined _M5223X                                              // {2}
            static unsigned long ulNMI_event_count = 0;
            static unsigned long ulNMI_processed_count = 0;
        #endif
    #endif
#endif

#if defined _M5223X && defined _PORT_NMI_CHECK && defined IRQ_TEST       // {2}{3} check for NMI interrupt each time the application is scheduled
        while (ulNMI_event_count != ulNMI_processed_count) {             // if there are open events
            ulNMI_processed_count++;                                     // this one processed - note that ulNMI_event_count is not written since it may be modified by the NMI during such an access
            fnDebugMsg("NMI_int\r\n");
        }
#endif

#if defined _PORT_INTS_EVENTS && defined IRQ_TEST                        // monostable timer event handling
                if ((IRQ1_EVENT <= ucInputMessage[MSG_INTERRUPT_EVENT]) && (IRQ11_EVENT >= ucInputMessage[MSG_INTERRUPT_EVENT])) {
                    fnDebugMsg("IRQ_");
                    switch (ucInputMessage[MSG_INTERRUPT_EVENT]) {
                    case IRQ1_EVENT:
                        fnDebugMsg("1");
                        break;
                    case IRQ4_EVENT:
                        fnDebugMsg("4");
    #if defined CAN_INTERFACE && defined TEST_CAN
                        fnSendCAN(1);                                    // {4}
    #endif
                        break;
                    case IRQ5_EVENT:
                        fnDebugMsg("5");
    #if defined CAN_INTERFACE && defined TEST_CAN
                        fnSendCAN(7);                                    // {4}
    #endif
                        break;
                    case IRQ7_EVENT:
                        fnDebugMsg("7");
                        break;
                    case IRQ11_EVENT:
                        fnDebugMsg("11");
                        break;
                    default:
                        break;
                    }
                    fnDebugMsg("\r\n");
                    break;
                }
#endif






#if defined _PORT_INT_CODE && defined IRQ_TEST
// Test routines to handle the IRQ test inputs
//
    #if !defined TEST_DS1307 && !(defined _M5225X && !defined INTERRUPT_TASK_PHY)  // use this input for RTC
static void test_irq_1(void)
{
    fnInterruptMessage(OWN_TASK, IRQ1_EVENT);
}
    #endif


static void test_irq_4(void)
{
    fnInterruptMessage(OWN_TASK, IRQ4_EVENT);
}
    #if !defined M52259DEMO && !defined _LPC23XX && !defined _LPC17XX
static void test_irq_5(void)
{
    fnInterruptMessage(OWN_TASK, IRQ5_EVENT);
}
    #endif
    #if defined _M5223X                                                  // {2}
static void test_nmi_7(void)
{
    // The M522XX irq7 has NMI characteristics and so should avoid operating system calls involving queues
    // Thsi technique shows a safe method of achieving the same effect
    ulNMI_event_count++;                                                 // mark that new event has occurred
    uTaskerStateChange(OWN_TASK, UTASKER_ACTIVATE);                      // safely schedule the task to handle the event
}
    #elif !defined _LPC23XX && !defined _LPC17XX

static void test_irq_7(void)
{
    fnInterruptMessage(OWN_TASK, IRQ7_EVENT);
}
    #endif
    #ifndef _M521X
static void test_irq_11(void)
{
    fnInterruptMessage(OWN_TASK, IRQ11_EVENT);
}
    #endif

// Configure several IRQ inputs to demonstrate port change interrupts
//
static void fnInitIRQ(void)
{
    INTERRUPT_SETUP interrupt_setup;                                     // interrupt configuration parameters
    #if defined _HW_SAM7X
    interrupt_setup.int_type = PORT_INTERRUPT;                           // identifier when configuring
    interrupt_setup.int_handler = test_irq_4;                            // handling function
    interrupt_setup.int_priority = PRIORITY_PIOA;                        // port interrupt priority
    interrupt_setup.int_port = PORT_A;                                   // the port used
    interrupt_setup.int_port_sense = (IRQ_FALLING_EDGE | IRQ_GLITCH_ENABLE); // {1} interrupt on this edge
    interrupt_setup.int_port_bits = PA29;                                // the input connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_port = PORTA_IRQ0;                               // the port used (fixed interrupt)
    interrupt_setup.int_handler = test_irq_5;                            // handling function
    interrupt_setup.int_port_sense = IRQ_FALLING_EDGE;                   // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_7;                            // handling function
    interrupt_setup.int_priority = PRIORITY_PIOB;                        // port interrupt priority
    interrupt_setup.int_port = PORT_B;                                   // the port used
    interrupt_setup.int_port_sense = (IRQ_RISING_EDGE | IRQ_GLITCH_ENABLE); // {1} interrupt on rising edges
    interrupt_setup.int_port_bits = (PB25);                              // the inputs connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_11;                           // handling function
    interrupt_setup.int_port_sense = (IRQ_RISING_EDGE | IRQ_FALLING_EDGE | IRQ_GLITCH_ENABLE); // {1} interrupt on both edges
    interrupt_setup.int_port_bits = (PB27 | PB24);                       // the inputs connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
    #elif defined _HW_AVR32
    interrupt_setup.int_type = PORT_INTERRUPT;                           // identifier when configuring
    interrupt_setup.int_handler = test_irq_4;                            // handling function
    interrupt_setup.int_priority = PRIORITY_GPIO;                        // port interrupt priority
    interrupt_setup.int_port = PORT_0;                                   // the port used
    interrupt_setup.int_port_sense = (IRQ_FALLING_EDGE | IRQ_ENABLE_GLITCH_FILER); // interrupt on this edge with active glitch filter
    interrupt_setup.int_port_bits = PA22;                                // the input connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_port = PORT_1;                                   // the port used
    interrupt_setup.int_handler = test_irq_5;                            // handling function
    interrupt_setup.int_port_sense = (IRQ_FALLING_EDGE | IRQ_ENABLE_GLITCH_FILER); // interrupt on this edge with active glitch filter
    interrupt_setup.int_port_bits = (PB22 | PB23);                       // the inputs connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_7;                            // handling function
    interrupt_setup.int_port_sense = (IRQ_RISING_EDGE);                  // interrupt on rising edges
    interrupt_setup.int_port_bits = (PB24);                              // the inputs connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_1;                            // handling function
    interrupt_setup.int_port_sense = (IRQ_RISING_EDGE);                  // interrupt on rising edges
    interrupt_setup.int_port_bits = (PB31);                              // the inputs connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_port = EXT_INT_CONTROLLER;                       // external interrupt controller
    interrupt_setup.int_handler = test_irq_11;                           // handling function
    interrupt_setup.int_port_sense = (IRQ_RISING_EDGE | IRQ_ENABLE_GLITCH_FILER); // interrupt on rising edge with active filter
    interrupt_setup.int_port_bits = (EXT_INT_0 | EXT_INT_3);             // the inputs connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
    #elif _STR91XF
    interrupt_setup.int_type = PORT_INTERRUPT;                           // identifier when configuring
    interrupt_setup.int_handler = test_irq_4;                            // handling function
    interrupt_setup.int_priority = (0);                                  // port interrupt priority
    interrupt_setup.int_port_bit = EXINT_2;                              // the input connected
    interrupt_setup.int_port_sense = WUI_RISING_EDGE;                    // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_5;                            // handling function
    interrupt_setup.int_port_bit = EXINT_15;                             // the input connected
    interrupt_setup.int_port_sense = WUI_FALLING_EDGE;                   // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_7;                            // handling function
    interrupt_setup.int_port_bit = EXINT_21;                             // the input connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_handler = test_irq_1;                            // handling function
    interrupt_setup.int_port_bit = EXINT_22;                             // the input connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt

    interrupt_setup.int_type = PORT_CHANNEL_INTERRUPT;
    interrupt_setup.int_handler = test_irq_11;                           // handling function
    interrupt_setup.int_port_bit = EXINT_31;                             // the input connected
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
    #elif defined _LM3SXXXX
    interrupt_setup.int_type = PORT_INTERRUPT;                           // identifier when configuring
    interrupt_setup.int_handler = test_irq_4;                            // handling function
    interrupt_setup.int_port = PORT_C;                                   // the port used
    interrupt_setup.int_priority = 3;                                    // port interrupt priority
    interrupt_setup.int_port_bit = 7;                                    // the input connected
    interrupt_setup.int_port_characteristic = PULLUP_ON;                 // enable pull-up resistor at input
    interrupt_setup.int_port_sense = IRQ_RISING_EDGE;                    // interrupt on this edge
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    interrupt_setup.int_port = PORT_A;                                   // the port used
    interrupt_setup.int_port_bit = 7;                                    // the input connected
    interrupt_setup.int_handler = test_irq_1;                            // handling function
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    interrupt_setup.int_port_bit = 6;                                    // the input connected
    interrupt_setup.int_handler = test_irq_5;                            // handling function
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    interrupt_setup.int_port_bit = 5;                                    // the input connected
    interrupt_setup.int_port_sense = IRQ_FALLING_EDGE;                   // interrupt on this edge
    interrupt_setup.int_handler = test_irq_7;                            // handling function
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    interrupt_setup.int_port_bit = 4;                                    // the input connected
    interrupt_setup.int_handler = test_irq_11;                           // handling function
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    #elif defined _LPC23XX || defined _LPC17XX
    interrupt_setup.int_type = PORT_INTERRUPT;                           // identifier when configuring
    interrupt_setup.int_handler = test_irq_4;                            // handling function
    interrupt_setup.int_port = PORT_0;                                   // the port used
    interrupt_setup.int_priority = 3;                                    // port interrupt priority
    interrupt_setup.int_port_bits = PORT0_BIT0;                          // the input connected
    interrupt_setup.int_port_sense = (IRQ_FALLING_EDGE | PULLUP_DOWN_OFF); // interrupt on this edge
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    interrupt_setup.int_handler = test_irq_1;                            // handling function
    interrupt_setup.int_port_bits = PORT0_BIT4;                          // the input connected
    interrupt_setup.int_port_sense = (IRQ_RISING_EDGE | PULLUP_DOWN_OFF); // interrupt on this edge
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    interrupt_setup.int_handler = test_irq_11;                           // handling function
    interrupt_setup.int_port = EXTERNALINT;                              // an external interrupt rather than a port interrupt
    interrupt_setup.int_port_bits = EINT3;                               // the input connected is EINT1 (0 to 3 is possible whereby EINT3 is shared with GPIO interrupts)
    interrupt_setup.int_priority = 12;                                   // external interrupt priority
    fnConfigureInterrupt(&interrupt_setup);                              // configure test interrupt
    #else                                                                // M5223X
    interrupt_setup.int_type     = PORT_INTERRUPT;                       // identifier when configuring
        #if !defined TEST_DS1307 && !(defined _M5225X && !defined INTERRUPT_TASK_PHY) // uses this input for RTC or PHY
    interrupt_setup.int_handler  = test_irq_1;                           // handling function
    interrupt_setup.int_priority = (INTERRUPT_LEVEL_1);                  // interrupt priority level (this can not be modified for IRQ1..IRQ7 so the value is not really relevant)
    interrupt_setup.int_port_bit = 1;                                    // the IRQ input connected
    interrupt_setup.int_port_sense = IRQ_BOTH_EDGES;                     // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
        #endif
    interrupt_setup.int_priority = (INTERRUPT_LEVEL_4);                  // interrupt priority level (this can not be modified for IRQ1..IRQ7 so the value is not really relevant)
    interrupt_setup.int_handler  = test_irq_4;                           // handling function
    interrupt_setup.int_port_bit = 4;                                    // the IRQ input connected
    interrupt_setup.int_port_sense = IRQ_RISING_EDGE;                    // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
        #if !defined M52259DEMO                                          // this board uses the pin for PHY communication
    interrupt_setup.int_priority = (INTERRUPT_LEVEL_5);                  // interrupt priority level (this can not be modified for IRQ1..IRQ7 so the value is not really relevant)
    interrupt_setup.int_handler  = test_irq_5;                           // handling function
    interrupt_setup.int_port_bit = 5;                                    // the IRQ input connected
    interrupt_setup.int_port_sense = IRQ_RISING_EDGE;                    // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
        #endif
    interrupt_setup.int_priority = (INTERRUPT_LEVEL_7);                  // interrupt priority level (this can not be modified for IRQ1..IRQ7 so the value is not really relevant)
    interrupt_setup.int_handler  = test_nmi_7;                           // {2} handling function
    interrupt_setup.int_port_bit = 7;                                    // the NMI input connected
    interrupt_setup.int_port_sense = IRQ_FALLING_EDGE;                   // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt  (test not available on 80 pin devices)
        #ifndef _M521X
    interrupt_setup.int_priority = (IRQ11_INTERRUPT_PRIORITY);           // set level and priority
    interrupt_setup.int_handler  = test_irq_11;                          // handling function
    interrupt_setup.int_port_bit = 11;                                   // the IRQ input connected (on all devices)
    interrupt_setup.int_port_sense = IRQ_RISING_EDGE;                    // interrupt on this edge
    fnConfigureInterrupt((void *)&interrupt_setup);                      // configure test interrupt
        #endif
    #endif
}
#endif



