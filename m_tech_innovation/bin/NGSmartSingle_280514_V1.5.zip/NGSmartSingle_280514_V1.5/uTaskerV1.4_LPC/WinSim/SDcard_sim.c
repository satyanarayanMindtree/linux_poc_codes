/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:         SDcard_sim.c
    Project:      uTasker project
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    19.06.2010 Rename fnWriteSector() to fnWriteSDSector() to avoid confilict with new external function with same name {1}
    20.07.2010 Add SD card controller interface                          {2}


*/        


#include "config.h"

#ifdef SDCARD_SUPPORT

#include "conio.h"
#include "Fcntl.h"
#include "io.h"

#include <sys/stat.h>

#if _VC80_UPGRADE>=0x0600
    #include <share.h>
#endif


//#define _NO_SD_CARD_INSERTED
#define _PARTITIONED
//#define _SIMPLE_FIXED
//#define _HC_SD_CARD

#ifdef _HC_SD_CARD
    #define OFFSET_CONVERSION 1

    static unsigned char ucCardDetails[18] = {                           // 4G card
        0xff, 0xfe,
        0x40, 0x0e, 0x00, 0x32, 0x5b, 0x58, 0x00, 0x00, 0x1d, 0x7b, 0x7f, 0x80, 0x6a, 0x40, 0x00, 0x91
    };
#else
    #define OFFSET_CONVERSION 512

    static unsigned char ucCardDetails[18] = {                           // 2G card
        0xff, 0xfe,
        0x00, 0x2e, 0x00, 0x32, 0x5b, 0x5a, 0x83, 0xa9, 0xff, 0xff, 0xff, 0x80, 0x16, 0x80, 0x00, 0x91
    };
#endif

static unsigned char ucCardInfo[18] = {
    0xff, 0xfe,
    0x40, 0x0e, 0x00, 0x32, 0x5b, 0x58, 0x00, 0x00, 0x1d, 0x7b, 0x7f, 0x80, 0x6a, 0x40, 0x00, 0x91
};

static unsigned char ucCardRCA[4] = {
    0x12, 0x34,
    0x05, 0x00
};

static unsigned char ucCardSelected[4] = {
    0x12, 0x34,
    0x05, 0x00
};

static const EXTENDED_BOOT_RECORD SD_Card_partition = {
    {0},
    {0},
    {0},
    {
        { 0, 2, 0xc, 0, 0xb, 0x38, 0xf8, 0xb8, {LITTLE_LONG_WORD_BYTES(0x89)}, {LITTLE_LONG_WORD_BYTES(0x003a9f77)}},
        {0}
    },
    {0},
    0x55,
    0xaa
};

static const BOOT_SECTOR_FAT32 SD_Card_boot_sector = {                   // 2G reference
    {
        {0xeb, 0x58, 0x90},
        {'M', 'S', 'D', 'O', 'S', '5', '.', '0'},
        {LITTLE_SHORT_WORD_BYTES(512)},                                  // 512 bytes per sector
        0x01,                                                            // sectors per cluster
        {LITTLE_SHORT_WORD_BYTES(6530)},                                 // number of reserved sectors in the Reserved region of the volume
        2,                                                               // number of FATs
        {LITTLE_SHORT_WORD_BYTES(0)},
        {LITTLE_SHORT_WORD_BYTES(0)},
        0xf8,                                                            // media
        {LITTLE_SHORT_WORD_BYTES(0)},
        {0xf3, 0x00},
        {0xff, 0x00},
        {0x89, 0x00, 0x00, 0x00},
        {LITTLE_LONG_WORD_BYTES(3841911)},
    },
    {LITTLE_LONG_WORD_BYTES(29503)},                                     // sectors per FAT
    {LITTLE_SHORT_WORD_BYTES(0)},
    {LITTLE_SHORT_WORD_BYTES(0)},
    {LITTLE_LONG_WORD_BYTES(2)},
    {LITTLE_SHORT_WORD_BYTES(0x01)},                                     // location of info section
    {LITTLE_SHORT_WORD_BYTES(6)},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    0x80,
    0, 
    0x29,
    {0xf0, 0x7e, 0xde, 0x0e},
    {'N', 'O', ' ', 'N', 'A', 'M', 'E', ' ', ' ', ' ', ' '},
    {'F', 'A', 'T', '3', '2', ' ', ' ', ' '},
    {0},                                                                 // this tends not be be filled with zeros
    0x55,
    0xaa
};

static const INFO_SECTOR_FAT32 SD_Card_info_sector = {
    {LITTLE_LONG_WORD_BYTES(0x41615252)},
    {0},
    {LITTLE_LONG_WORD_BYTES(0x61417272)},
    {LITTLE_LONG_WORD_BYTES(0x00399f76)},
    {LITTLE_LONG_WORD_BYTES(0x00000003)},
    {0},
    {0x00, 0x00, 0x55, 0xAA},
};

static const DIR_ENTRY_STRUCTURE_FAT32 SD_Card_volume[16] = {
    {
        {'V', 'O', 'L', 'U', 'M', 'E', ' ', 'I', 'D', 0, 0},
        0x08,                                                            // volume ID attribute
        0, 0, {0}, {0}, {0}, {0}, {0}, {0}, {0}, {0}
    },
    {
        {'T', 'E', 'S', 'T', '1', ' ', ' ', ' ', 'T', 'X', 'T'},
        0x20,                                                            // archive attribute
        0, 0x24, {0xe7, 0xb3}, {0x77, 0x3b}, {0x77, 0x3b}, {0}, {0xee, 0xb3}, {0x77, 0x3b}, {0x03, 0x00}, {0x09, 0, 0, 0}
    },
    {
        {'D', 'I', 'R', '_', '1', ' ', ' ', ' ', ' ', ' ', ' '},
        0x10,                                                            // directory attribute
        0, 0x2f, {0xf0, 0xb3}, {0x77, 0x3b}, {0x77, 0x3b}, {0, 0}, {0xf1, 0xb3}, {0x77, 0x3b}, {0x04, 0x00}, {0x09, 0, 0, 0}
    },
    {
        {0x42, 0x68, 0, 0x69, 0, 0x63, 0, 0x5f, 0, 0x32, 0},             // long file name 2nd and last
        0x0f,                                                            // LFN
        0, 0xa6,                                                         // checksum
        {0x2e, 0}, {0x6a, 0}, {0x70, 0}, {0x65, 0}, {0x67, 0}, {0, 0}, {0, 0}, {0xff, 0xff, 0xff, 0xff}
    },
    {
        {0x01, 0x43, 0, 0x6f, 0, 0x6c, 0, 0x64, 0, 0x46, 0},             // long file name 1st
        0x0f,                                                            // LFN
        0, 0xa6,                                                         // checksum
        {0x69, 0}, {0x72, 0}, {0x65, 0}, {0x5f, 0}, {0x47, 0}, {0x72, 0}, {0, 0}, {0x61, 0x00, 0x70, 0x00}
    },
    {
        {'C', 'O', 'L', 'D', 'F', 'I', '~', '1', 'J', 'P', 'E'},         // ColdFire_Graphic_2.jpeg as short file name 
        0x20,                                                            // archive attribute
        0, 0xc7, {0x6d, 0x88}, {0x7d, 0x3b}, {0x7d, 0x3b}, {0}, {0x53, 0x8a}, {0x0c, 0x39}, {0x12, 0x00}, {0x87, 0xdf, 0x04, 0x00}
    },
    {
        {0x41, 0x75, 0, 0x54, 0, 0x61, 0, 0x73, 0, 0x6b, 0},             // long file name 1st and last
        0x0f,                                                            // LFN
        0, 0xb0,                                                         // checksum
        {0x65, 0}, {0x72, 0}, {0x57, 0}, {0x65, 0}, {0x62, 0}, {0x00, 0x00}, {0, 0}, {0xff, 0xff, 0xff, 0xff}
    },
    {
        {'U', 'T', 'A', 'S', 'K', 'E', '~', '1', ' ', ' ', ' '},         // uTaskerweb directory as short file name 
        0x10,                                                            // directory attribute
        0, 0xb0, {0x6d, 0x88}, {0x7d, 0x3b}, {0x7d, 0x3b}, {0}, {0xbd, 0x71}, {0x7c, 0x3b}, {0x06, 0x00}, {0, 0, 0, 0}
    },
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0}
};

static const DIR_ENTRY_STRUCTURE_FAT32 SD_Card_cluster_4[16] = {
    {0},
    {0},
    {
        {'D', 'E', 'M', 'O', 'S', ' ', ' ', ' ', ' ', ' ', ' '},         // uTaskerweb directory as short file name 
        0x10,                                                            // directory attribute
        0, 0x24, {0x6f, 0x88}, {0x7d, 0x3b}, {0x7d, 0x3b}, {0}, {0xb0, 0x79}, {0x42, 0x3b}, {0x6f, 0x00}, {0, 0, 0, 0}
    },
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0}
};

static const DIR_ENTRY_STRUCTURE_FAT32 SD_Card_files[16] = {
    {0},
    {0},
    {                                                                    // always start at index 2 (why???)
        {0xe5, 'O', 'L', 'U', 'M', 'E', ' ', 'I', 'D', 0, 0},            // deleted entry
        0x08,
        0, 0, {0}, {0}, {0}, {0}, {0}, {0}, {0}, {0}
    },
    {
        {'T', 'E', 'S', 'T', '2', ' ', ' ', ' ', 'T', 'X', 'T'},
        0x20,                                                            // archive attribute
        0x18, 
        0x49, {0xf6, 0xb3}, {0x77, 0x3b}, {0x77, 0x3b}, {0, 0}, {0x01, 0xb3}, {0x77, 0x3b}, {0x05, 0x00}, {LITTLE_LONG_WORD_BYTES(17)}
    },
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0},
    {0}
};

unsigned char SD_Card_file_1[512] = {
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',   0
};

unsigned char SD_Card_file_2[512] = {
    'z', 'y', 'x', 'w', 'v', 'u', 't', 's', 'r', 'q', 'p', 'o', 'n', 'm', 'l', 'k', 'j',   0
};

static int iSD_card_file = -1;


static void fnExtractSector(unsigned long ulSectorNumber, unsigned char *ptrBuffer)
{
    if (ulSectorNumber == 0) {
        static int iSimCard_state = 0;
        if (iSimCard_state == 0) {                                       // first time the boot sector is read
#if _VC80_UPGRADE < 0x0600
	        iSD_card_file = _open("SD_CARD.bin", (_O_BINARY  | _O_CREAT | _O_RDWR ), _S_IREAD | _S_IWRITE ); 
#else
	        _sopen_s(&iSD_card_file, "SD_CARD.bin", (_O_BINARY  | _O_CREAT | _O_RDWR), _SH_DENYNO, _S_IREAD | _S_IWRITE); 
#endif
            iSimCard_state = 1;                    
        }
        _lseek(iSD_card_file, 0, SEEK_SET);                              // set to start of file
        if (_read(iSD_card_file, ptrBuffer, 512) < 512) {                // read the partition sector which is always the first one
            memset(ptrBuffer, 0, 512);
/*
            _lseek(iSD_card_file, 0, SEEK_SET);

#ifdef _PARTITIONED
            _write(iSD_card_file, &SD_Card_partition, 512);
            memcpy(ptrBuffer, &SD_Card_partition, 512);                 // partition sector content
            _write(iSD_card_file, &SD_Card_partition.EBR_partition_table->start_sector[0], sizeof(unsigned long));
#endif
            _write(iSD_card_file, &SD_Card_boot_sector, 512);            // boot sector content
            */
        }
    }
    else {
        unsigned long ulSectorFromFile;
        _lseek(iSD_card_file, 512, SEEK_SET);                            // set to first numbered sector
        while (1) {
            if (_read(iSD_card_file, &ulSectorFromFile, sizeof(unsigned long)) < sizeof(unsigned long)) { // read the sector number
                memset(ptrBuffer, 0, 512);                               // empty sector
                return;
            }
            if (ulSectorNumber == ulSectorFromFile) {
                _read(iSD_card_file, ptrBuffer, 512);                    // read the sector content
                return;
            }
            _lseek(iSD_card_file, 512, SEEK_CUR);                        // move to next numbered sector
        }
    }
}

static void fnWriteSDSector(unsigned long ulSectorNumber, unsigned char *ptrBuffer) // {1}
{
    if (ulSectorNumber == 0) {                                           // writing to partition sector - this is a special case becasue it causes a new file to be created (old file's contents are destroyed)
#if _VC80_UPGRADE < 0x0600
	    iSD_card_file = _open("SD_CARD.bin", (_O_BINARY | _O_TRUNC | _O_CREAT | _O_RDWR ), _S_IREAD | _S_IWRITE ); 
#else
	    _sopen_s(&iSD_card_file, "SD_CARD.bin", (_O_BINARY | _O_TRUNC | _O_CREAT | _O_RDWR), _SH_DENYNO, _S_IREAD | _S_IWRITE); 
#endif
        _lseek(iSD_card_file, 0, SEEK_SET);                              // set to start of file
    }
    else {
        unsigned long ulSectorFromFile;
        _lseek(iSD_card_file, 512, SEEK_SET);                            // set to first numbered sector
        while (1) {
            if (_read(iSD_card_file, &ulSectorFromFile, sizeof(unsigned long)) < sizeof(unsigned long)) { // read the sector number
                int iLength = 512;
                int iFound = 0;
                unsigned char *ptrTest = ptrBuffer;
                while (iLength--) {
                    if (*ptrTest++ != 0) {
                        iFound = 1;
                        break;
                    }
                }
                if (!iFound) {
                    return;                                              // don't write zeroed sectors
                }
                _write(iSD_card_file, &ulSectorNumber, sizeof(ulSectorNumber)); // sector not found so create 
                break;
            }
            if (ulSectorNumber == ulSectorFromFile) {                    // found existing sector content
                break;
            }
            _lseek(iSD_card_file, 512, SEEK_CUR);                        // move to next numbered sector
        }
    }
    _write(iSD_card_file, ptrBuffer, 512);                               // write
}


extern void fnSaveSDcard(void)
{
    if (iSD_card_file > 0) {
        _close(iSD_card_file);
    }
}


// Simulate SD card in SPI mode
//
extern unsigned char _fnSimSD_write(unsigned char ucTxByte)
{
#define SD_CARD_START            0
#define SD_CARD_INIT             1
#define SD_CARD_ARGUMENTS        2
#define SD_CARD_CRC              3
#define SD_CARD_ANSWER           4
#define SD_CARD_ANSWER_EXTRA     5
#define SD_CARD_BLOCK_WRITE      6
#define SD_CARD_BLOCK_WRITING    7
#define SD_CARD_BLOCK_COLLECTING 8
#define SD_CARD_RX_CRC_1         9
#define SD_CARD_RX_CRC_2         10
#define SD_CARD_RX_CRC_3         11

#ifdef SD_CONTROLLER_AVAILABLE                                           // {2}
    static int iSD_Card_State = SD_CARD_INIT;
#else
    static int iSD_Card_State = SD_CARD_START;
#endif
    static unsigned long ulWriteOffset;
    static int iArguments = 0;
    static int iSendArg = 0;
    static unsigned char ucCommand = 0;
    static unsigned char ucAnswer = 0xff;
    static unsigned char ucArguments[515];
#ifdef _NO_SD_CARD_INSERTED
    return 0xff;
#endif
    switch (iSD_Card_State) {
    case SD_CARD_START:                                                  // with DI and CS held high it is expected that >= 74 clocks are received to enter native command mode
        {
            static int iStartUp = 0;
            if (++iStartUp >= 10) {                                      // count 10 bytes
                iSD_Card_State = SD_CARD_INIT;
            }
        }
        break;
    case SD_CARD_INIT:
        if ((ucTxByte == 0x40) || (ucTxByte == 0x42) || (ucTxByte == 0x43) || (ucTxByte == 0x46) || (ucTxByte == 0x47) || (ucTxByte == 0x48) || (ucTxByte == 0x50) || (ucTxByte == 0x77) || (ucTxByte == 0x69) || (ucTxByte == 0x7a) || (ucTxByte == 0x58) || (ucTxByte == 0x51) || (ucTxByte == 0x49)) { // all expected commands
            ucCommand = ucTxByte;
            iArguments = 0;
            iSD_Card_State = SD_CARD_ARGUMENTS;
            break;
        }
        else if (ucTxByte != 0xff) {                                     // accept idle line, which is used when poll for busy
            *(unsigned char *)0 = 0;
        }
        break;
    case SD_CARD_ARGUMENTS:
        ucArguments[iArguments++] = ucTxByte;
        if (iArguments == 4) {
            iSD_Card_State = SD_CARD_CRC;
            break;
        }
        break;
    case SD_CARD_CRC:
        if (ucCommand == 0x51) {                                         // single block read
            unsigned long ulByteOffset = ((ucArguments[0] << 24) + (ucArguments[1] << 16) + (ucArguments[2] << 8) + ucArguments[3]);
            iSD_Card_State = SD_CARD_ANSWER;
            iArguments = 515;                                            // a block answer is expected
            ucArguments[0] = 0xfe;
            iSendArg = 0;
#ifdef _SIMPLE_FIXED
    #ifdef _PARTITIONED
            if (ulByteOffset == 0) {
                memcpy(&ucArguments[1], &SD_Card_partition, 512);       // boot sector content
            }
            else if (ulByteOffset == (0x8a * OFFSET_CONVERSION)) {       // info sector 
                memcpy(&ucArguments[1], &SD_Card_info_sector, 512);
            }
            else if (ulByteOffset == (0x10089 * OFFSET_CONVERSION)) {    // volume directory
                memcpy(&ucArguments[1], &SD_Card_volume[0], 512);
            }
            else if (ulByteOffset == (0x1008b * OFFSET_CONVERSION)) {    // file
                memcpy(&ucArguments[1], &SD_Card_files[0], 512);
            }
            else if (ulByteOffset == (0x1008a * OFFSET_CONVERSION)) {    // file content
                memcpy(&ucArguments[1], &SD_Card_file_1[0], 512);
            }
            else if (ulByteOffset == (0x1008d * OFFSET_CONVERSION)) {    // file content
                memcpy(&ucArguments[1], &SD_Card_cluster_4[0], 512);
            }
            else if (ulByteOffset == (0x1008c * OFFSET_CONVERSION)) {    // file content
                memcpy(&ucArguments[1], &SD_Card_file_2[0], 512);
            }
            else if (ulByteOffset == (0x89 * OFFSET_CONVERSION)) {
                memcpy(&ucArguments[1], &SD_Card_boot_sector, 512);     // boot sector content
            }
    #else
            if (ulByteOffset == 0) {
                memcpy(&ucArguments[1], &SD_Card_boot_sector, 512);     // boot sector content
            }
            else if (ulByteOffset == (1 * OFFSET_CONVERSION)) {         // info sector 
                memcpy(&ucArguments[1], &SD_Card_info_sector, 512);     // boot sector content
            }
    #endif
            else {
                memset(&ucArguments[1], 0x00, 512);
            }
#else
            fnExtractSector((ulByteOffset / OFFSET_CONVERSION), &ucArguments[1]);
#endif
            ucAnswer = 0x00;                                             // in idle state
        }
#ifdef SD_CONTROLLER_AVAILABLE
        else if (ucCommand == 0x50) {                                    // set block length
            iSD_Card_State = SD_CARD_ANSWER;
            iArguments = 4;
            iSendArg = 0;
            memcpy(&ucArguments[0], ucCardSelected, 4);
            ucAnswer = 0x00;                                             // in idle state
        }
        else if (ucCommand == 0x47) {                                    // select card
            iSD_Card_State = SD_CARD_ANSWER;
            iArguments = 4;
            iSendArg = 0;
            memcpy(&ucArguments[0], ucCardSelected, 4);
            ucAnswer = 0x00;                                             // in idle state
        }
        else if (ucCommand == 0x46) {                                    // set interface width
            iSD_Card_State = SD_CARD_ANSWER;
            iArguments = 4;
            iSendArg = 0;
            memcpy(&ucArguments[0], ucCardSelected, 4);
            ucAnswer = 0x00;                                             // in idle state
        }
        else if (ucCommand == 0x43) {                                    // request RCA address
            iSD_Card_State = SD_CARD_ANSWER;
            iArguments = 4;
            iSendArg = 0;
            memcpy(&ucArguments[0], ucCardRCA, 4);
            ucAnswer = 0x00;                                             // in idle state
        }
        else if (ucCommand == 0x69) {                                    // read OCR
            iSD_Card_State = SD_CARD_ANSWER;            
            iArguments = 4;
            iSendArg = 0;
            ucArguments[0] |= 0x80;                                      // set the not-busy bit and echo back the arguments
    #ifdef _HC_SD_CARD
            ucArguments[0] |= 0x40;
    #else
            ucArguments[0] &= ~0x40;
    #endif
            ucAnswer = 0;
        }
#endif
        else if (ucCommand == 0x58) {                                    // single block write
            ulWriteOffset = ((ucArguments[0] << 24) + (ucArguments[1] << 16) + (ucArguments[2] << 8) + ucArguments[3]);
            iSD_Card_State = SD_CARD_BLOCK_WRITE;                        // a block write is expected
            iArguments = 0;
            ucArguments[0] = 0xfe;
            ucAnswer = 0;
        }
        else if (ucCommand == 0x42) {                                    // read card information
            iSD_Card_State = SD_CARD_ANSWER;
#ifdef SD_CONTROLLER_AVAILABLE
            iArguments = 16;
#else
            iArguments = 21;
#endif
            iSendArg = 0;
            memcpy(&ucArguments[0], ucCardInfo, 18);
            ucArguments[17] = 0x55;                                      // dummy CRC
            ucArguments[18] = 0xaa;
            ucAnswer = 0x00;                                             // in idle state
        }
        else if (ucCommand == 0x49) {                                    // read card specific data
            iSD_Card_State = SD_CARD_ANSWER;
#ifdef SD_CONTROLLER_AVAILABLE
            iArguments = 16;
#else
            iArguments = 21;
#endif
            iSendArg = 0;
            memcpy(&ucArguments[0], ucCardDetails, 18);
            ucArguments[17] = 0x55;                                      // dummy CRC
            ucArguments[18] = 0xaa;
            ucAnswer = 0x00;                                             // in idle state
        }
        else if (ucCommand == 0x40) {
#ifdef SD_CONTROLLER_AVAILABLE                                           // {2}
            ucTxByte = 0x95;
#endif
            if (ucTxByte == 0x95) {                                      // check that the CRC is as expected
                iSD_Card_State = SD_CARD_ANSWER;
                iArguments = 0;
                ucAnswer = 0x01;                                         // in idle state
            }
        }
        else if (ucCommand == 0x48) {
#ifdef SD_CONTROLLER_AVAILABLE                                           // {2}
            ucTxByte = 0x87;
#endif
            if (ucTxByte == 0x87) {                                      // check that the CRC is as expected
                iSD_Card_State = SD_CARD_ANSWER;
              //ucAnswer = 0x00;                                         // SD version 1 or MMC
                ucAnswer = 0x01;                                         // SD version 2+
                iArguments = 4;                                          // 4 additional bytes of data
                iSendArg = 0;
                ucArguments[0] = 0;                                      // the card's characteristics
                ucArguments[1] = 0;
                ucArguments[2] = 0x01;
                ucArguments[3] = 0xaa;
#ifdef SD_CONTROLLER_AVAILABLE                                           // {2}
                ucArguments[4] = 0x01;
                ucArguments[5] = 0xaa;
                iArguments = 6;
#endif
            }
        }
        else if ((ucCommand == 0x77) || (ucCommand == 0x69)) {           // no CRC
            iSD_Card_State = SD_CARD_ANSWER;
            ucAnswer = 0x00;
            iArguments = 0;                                              // 4 additional bytes of data
        }
        else if (ucCommand == 0x7a) {
            iSD_Card_State = SD_CARD_ANSWER;
            ucAnswer = 0x00;
            iArguments = 4;                                              // 4 additional bytes of data
            iSendArg = 0;
    #ifdef _HC_SD_CARD
            ucArguments[0] = 0x40;                                       // high capacity
    #else
            ucArguments[0] = 0x00;                                       // high capacity
    #endif
            ucArguments[1] = 0;
            ucArguments[2] = 0;
            ucArguments[3] = 0;
        }
        break;
    case SD_CARD_RX_CRC_1:
        iSD_Card_State = SD_CARD_RX_CRC_2;
        break;
    case SD_CARD_RX_CRC_2:
        iSD_Card_State = SD_CARD_RX_CRC_3;
        break;
    case SD_CARD_RX_CRC_3:
        iSD_Card_State = SD_CARD_INIT;
        return 0x05;
    case SD_CARD_BLOCK_WRITING:
        if (ucTxByte == 0xfe) {
            iSD_Card_State = SD_CARD_BLOCK_COLLECTING;
        }
        break;
    case SD_CARD_BLOCK_COLLECTING:
        ucArguments[iArguments++] = ucTxByte;
        if (iArguments >= 512) {
            fnWriteSDSector((ulWriteOffset / OFFSET_CONVERSION), &ucArguments[0]);
            iSD_Card_State = SD_CARD_RX_CRC_1;
        }
        break;
    case SD_CARD_BLOCK_WRITE:
        iSD_Card_State = SD_CARD_BLOCK_WRITING;
        return ucAnswer;
    case SD_CARD_ANSWER:
        if (iArguments == 0) {
            iSD_Card_State = SD_CARD_INIT;
        }
        else {
            iSD_Card_State = SD_CARD_ANSWER_EXTRA;
        }
        return ucAnswer;
    case SD_CARD_ANSWER_EXTRA:
        {
            unsigned char ucReturnData = ucArguments[iSendArg++];
            if (iSendArg >= iArguments) {
                iSD_Card_State = SD_CARD_INIT;
            }
            return ucReturnData;
        }
    }
    return 0xff;
}

#endif

