/**********************************************************************
   Mark Butcher    Bsc (Hons) MPhil MIET

   M.J.Butcher Consulting
   Birchstrasse 20f,    CH-5406, R�tihof
   Switzerland

   www.uTasker.com    Skype: M_J_Butcher

   ---------------------------------------------------------------------
   File:        Watchdog.c
   Project:     Single Chip Embedded Internet
   ---------------------------------------------------------------------
   Copyright (C) M.J.Butcher Consulting 2004..2011
   *********************************************************************/        

//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


extern void fnTaskWatchdog(TTASKTABLE *ptrTaskTable)                     // watchdog called regularly
{
    fnRetriggerWatchdog();                                               // hardware dependent
} 

