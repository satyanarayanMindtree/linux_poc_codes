/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:         glcd_tft.h
    Project:      uTasker Demonstration project
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2011
    *********************************************************************
    09.08.2010 Add CGLCD_PIXEL_SIZE to control effective size             {1}
    10.08.2010 Don't remove pull-up from P1-27 when USB is used           {2}
    11.08.2010 Add touch screen operation                                 {3}
    13.11.2011 Remove prototype CollectCommand()                          {4}
       
*/

#if defined TFT_GLCD_MODE && !defined CGLCD_GLCD_MODE && !defined KITRONIX_GLCD_MODE && !defined MB785_GLCD_MODE
    #if !defined _GLCD_TFT_DEFINES
        #define GLCD_BUSY()                 0                            // no LCD busy check
        #define X_BYTES	                    (GLCD_X/CGLCD_PIXEL_SIZE/8)  // {1} the number of bytes holding the X-pixels
        #define Y_BYTES	                    (GLCD_Y/CGLCD_PIXEL_SIZE)    // {1} the number of rows of X_BYTES holding the Y rows
        #define DISPLAY_LEFT_PIXEL          0  
        #define DISPLAY_TOP_PIXEL           0
        #define DISPLAY_RIGHT_PIXEL         (GLCD_X - 1)
        #define DISPLAY_BOTTOM_PIXEL        (GLCD_Y - 1)
        #define UPDATE_WIDTH                ((X_BYTES + 7)/8)
        #define UPDATE_HEIGHT               Y_BYTES


        // SDRAM characteristics
        //
        #define SDRAM_REFRESH            7813
        #define SDRAM_TRP                20
        #define SDRAM_TRAS               45
        #define SDRAM_TAPR               1
        #define SDRAM_TDAL               3
        #define SDRAM_TWR                3
        #define SDRAM_TRC                65
        #define SDRAM_TRFC               66
        #define SDRAM_TXSR               67
        #define SDRAM_TRRD               15
        #define SDRAM_TMRD               3

        #define SDRAM_PERIOD             (float)((float)1000000000 / (float)MASTER_CLOCK)
        #define CALC_PERIOD(Period)      (((Period < SDRAM_PERIOD) ? 0:(unsigned long)((float)Period / SDRAM_PERIOD)) + 1)

        // TFT LCD characteristics
        //
        #define PIXEL_CLOCK_RATE         6400000
        #define HORIZONTAL_BACK_PORCH    38
        #define HORIZONTAL_FRONT_PORCH   20
        #define HORIZONTAL_PULSE         30
        #define VERTICAL_BACK_PORCH      15
        #define VERTICAL_FRONT_PORCH     5
        #define VERTICAL_PULSE           3

        #define LCD_VRAM_BASE_ADDR       SDRAM_ADDR                      // LCD ram set to the start of SDRAM

        static void fnInit_SDRAM(void);
        static void fnInitLCD_Controller(void);
        static void fnStartTouch(void);
        #ifdef _WINDOWS
          //extern void CollectCommand(int bRS, unsigned long ulByte);   // {4}
            extern unsigned char *fnGetSDRAM(unsigned char *ptrSDRAM);
        #else
            #define fnGetSDRAM(x) x
        #endif

        #define _GLCD_TFT_DEFINES                                        // include only once
    #endif

    #ifdef _GLCD_COMMANDS                                                // link in TFT specific interface commands

#ifdef _WINDOWS
static unsigned char ucSDRAM[SDRAM_SIZE];                                // SDRAM, used to store the display image - automatically refreshed by the LCD controller

extern unsigned char *fnGetSDRAM(unsigned char *ptrSDRAM)
{
    CAST_POINTER_ARITHMETIC offsetSDRAM = (CAST_POINTER_ARITHMETIC)ptrSDRAM - SDRAM_ADDR;
    return (ucSDRAM + offsetSDRAM);
}
#endif


#ifdef SUPPORT_TOUCH_SCREEN
static unsigned short usResults[2] = {0};

#define TOUCH_X_DRIVE_PLUS   PORT0_BIT24
#define TOUCH_X_DRIVE_MINUS  PORT0_BIT22
#define TOUCH_Y_DRIVE_PLUS   PORT0_BIT21
#define TOUCH_Y_DRIVE_MINUS  PORT0_BIT23

#define MIN_X_TOUCH          0x2000                                      // tuned values - for calibration these should be taken from parameters
#define MAX_X_TOUCH          0xe800
#define MIN_Y_TOUCH          0x2900
#define MAX_Y_TOUCH          0xe000

#define MAX_MOVEMENT_Y       6
#define MAX_MOVEMENT_X       6

#define PEN_DOWN_DEBOUNCE    6


static int iTouchState = 0;
static int iPenDown = 0;                                                 // initially pen is up (not touching touch screen)

// 4ms touch screen interrupt (from ADC result)
//
static void fnTouchValue(unsigned short usX, unsigned short usY)         // x and y values ready
{
    static unsigned short usLastPixelX, usLastPixelY;
    int iMove = 0;
    unsigned char ucMemoryContent, ucNewContent;

    if (iPenDown < PEN_DOWN_DEBOUNCE) {
        if (usX > MAX_X_TOUCH) {                                         // since the ADC default to high input value when not connected check with maximum values
            iPenDown = 0;
            return;
        }
        if (usY > MAX_Y_TOUCH) {
            iPenDown = 0;
            return;
        }
    #ifdef _WINDOWS
        iPenDown = (PEN_DOWN_DEBOUNCE - 1);
    #endif
        if (++iPenDown < PEN_DOWN_DEBOUNCE) {
            return;
        }                                                                // just detected pen being applied
    }
    else {                                                               // pen presently down
        if (usX > MAX_X_TOUCH) {
            if (usY > MAX_Y_TOUCH) {
                iPenDown = 0;                                            // just detected pen being removed
            }
            return;
        }
        else if (usY > MAX_Y_TOUCH) {                                    // pen probably being lifted
            return;
        }
        iMove = 1;
    }
    if (usX <= MIN_X_TOUCH) {                                            // limit
        usX = 0;                                                         // left of screen
    }
    else {
        usX = (unsigned short)(((unsigned long)((usX - MIN_X_TOUCH) * (GLCD_X - 1)))/(MAX_X_TOUCH - MIN_X_TOUCH)); // convert to pixel location
        if (usX >= GLCD_X) {
            usX = (GLCD_X - 1);
        }
    }
    if (usY <= MIN_Y_TOUCH) {
        usY = 0;
    }
    else {
        usY = (unsigned short)(((unsigned long)((usY - MIN_Y_TOUCH) * (GLCD_Y - 1)))/(MAX_Y_TOUCH - MIN_Y_TOUCH));
        if (usY >= GLCD_Y) {
            usY = (GLCD_Y - 1);
        }
    }
    if (iMove != 0) {
    #ifndef _WINDOWS
        if (usX > usLastPixelX) {                                        // movement to right
            if ((usX - usLastPixelX) > MAX_MOVEMENT_X) {
                return;                                                  // step too large so ignore
            }
        }
        else {
            if ((usLastPixelX - usX) > MAX_MOVEMENT_X) {
                return;                                                  // step too large so ignore
            }
        }
        if (usY > usLastPixelY) {                                        // movement down
            if ((usY - usLastPixelY) > MAX_MOVEMENT_Y) {
                return;                                                  // step too large so ignore
            }
        }
        else {
            if ((usLastPixelY - usY) > MAX_MOVEMENT_Y) {
                return;                                                  // step too large so ignore
            }
        }
    #endif
    }
    usLastPixelX = usX;                                                  // save last valid pixel location
    usLastPixelY = usY;
    #if CGLCD_PIXEL_SIZE > 1
    usY /= CGLCD_PIXEL_SIZE;
    usX /= CGLCD_PIXEL_SIZE;
    #endif
    ucNewContent = ucMemoryContent = ucPixelArray[usY][usX/8];           // original content
    ucNewContent |= (0x80 >> usX%8);                                     // set the pixel
    if (ucNewContent != ucMemoryContent) {
        ucPixelArray[usY][usX/8] = ucNewContent;
        ucByteUpdateArray[usY][usX/64] |= (0x80 >> (usX/8)%8);           // mark the need for an update
    }
}

static void fnTouchInterrupt(void)
{
    #ifdef _WINDOWS
    extern void fnGetPenSamples(unsigned short *ptrX, unsigned short *ptrY);
    #endif
    ADC_SETUP adc_setup; 
    switch (iTouchState++) {
    case 0:                                                              // delay to allow stabilisation ready of Y measurement
        {
            _FLOAT_PORT(0, (TOUCH_Y_DRIVE_PLUS | TOUCH_Y_DRIVE_MINUS));
            _DRIVE_PORT_OUTPUT_VALUE(0, (TOUCH_X_DRIVE_PLUS | TOUCH_X_DRIVE_MINUS), TOUCH_X_DRIVE_PLUS);
        }
        break;
    case 1:
        adc_setup.int_type = ADC_INTERRUPT;                              // identifier when configuring
        adc_setup.int_handler = 0;
        adc_setup.int_adc_single_ended_inputs = (ADC_CHANNEL_0);         // ADC channel 0 as single ended inputs (only one channel should be selected in SW mode
        adc_setup.int_adc_mode = (ADC_SINGLE_SHOT_SW | ADC_CONFIGURE_ADC); // configure and start single conversion
        adc_setup.SamplingSpeed = ADC_SAMPLING_SPEED(10000);             // slow sampling speed
        fnConfigureInterrupt((void *)&adc_setup);                        // configure and start sequence
        break;
    case 2:
        usResults[0] = (unsigned short)AD0GDR;                           // read X value
        PINSEL1 &= ~(PINSEL1_P0_23_RESET);                               // remove the AD pin function
        _FLOAT_PORT(0, (TOUCH_X_DRIVE_PLUS | TOUCH_X_DRIVE_MINUS));
        _DRIVE_PORT_OUTPUT_VALUE(0, (TOUCH_Y_DRIVE_PLUS | TOUCH_Y_DRIVE_MINUS), TOUCH_Y_DRIVE_PLUS);
        break;
    case 3:
        adc_setup.int_type = ADC_INTERRUPT;                              // identifier when configuring
        adc_setup.int_handler = 0;
        adc_setup.int_adc_single_ended_inputs = (ADC_CHANNEL_1);         // ADC channel 1 as single ended inputs (only one channel should be selected in SW mode
        adc_setup.int_adc_mode = (ADC_SINGLE_SHOT_SW | ADC_CONFIGURE_ADC); // configure and start single conversion
        adc_setup.SamplingSpeed = ADC_SAMPLING_SPEED(10000);             // slow sampling speed
        fnConfigureInterrupt((void *)&adc_setup);                        // configure and start sequence
        break;
    case 4:        
        usResults[1] = (unsigned short)AD0GDR;                           // read Y value
        PINSEL1 &= ~(PINSEL1_P0_24_RESET);                               // remove the AD pin function
        _FLOAT_PORT(0, (TOUCH_Y_DRIVE_PLUS | TOUCH_Y_DRIVE_MINUS));
        _DRIVE_PORT_OUTPUT_VALUE(0, (TOUCH_X_DRIVE_PLUS | TOUCH_X_DRIVE_MINUS), TOUCH_X_DRIVE_PLUS);
    #ifdef _WINDOWS
        fnGetPenSamples(&usResults[0], &usResults[1]);
    #endif
        fnTouchValue(usResults[0], usResults[1]);                        // process the input co-ordinate
        iTouchState = 1;                                                 // start the process again
        break;
    }
}

// The function is presently dedicated to LPC24XX
//
static void fnStartTouch(void)                                           // {3}
{
    TIMER_INTERRUPT_SETUP timer_setup;                                   // interrupt configuration parameters

    _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, (TOUCH_X_DRIVE_PLUS | TOUCH_X_DRIVE_MINUS), 0); // configure and drive initial line state
    _CONFIG_DRIVE_PORT_OUTPUT_VALUE(0, (TOUCH_Y_DRIVE_PLUS | TOUCH_Y_DRIVE_MINUS), 0);

    timer_setup.int_type = TIMER_INTERRUPT;
    timer_setup.int_priority = PRIORITY_TIMERS;
    timer_setup.int_handler = fnTouchInterrupt;
    timer_setup.timer_reference = TOUCH_HW_TIMER;                        // HW timer channel for touch time base
    #ifdef _HW_TIMER_MODE
    timer_setup.timer_mode = (TIMER_PERIODIC | TIMER_MS_VALUE);          // period timer
    timer_setup.timer_value = TIMER_MS_DELAY(1);                         // 1ms interrupt rate
    #else
    timer_setup.timer_value = 1;                                         // 1ms interrupt rate
    #endif
    fnConfigureInterrupt((void *)&timer_setup);                          // enter interrupt for timer test
}
#endif

// SDRAM initialisation
//
static void fnInit_SDRAM(void)
{
    volatile unsigned long ulDelay;

    // Configure the SDRAM pins 
    //
    PINSEL5  |= (PINSEL5_P2_16_CAS | PINSEL5_P2_17_RAS | PINSEL5_P2_18_CLKOUT0 | PINSEL5_P2_20_DYCS0 | PINSEL5_P2_24_CKEOUT1 | PINSEL5_P2_28_DQMOUT0 | PINSEL5_P2_29_DQMOUT1); // assign the pins required by the SDRAM controller
    PINMODE5 |= (PINMODE_NO_PULLS_16 | PINMODE_NO_PULLS_17 | PINMODE_NO_PULLS_18 | PINMODE_NO_PULLS_20 | PINMODE_NO_PULLS_24 | PINMODE_NO_PULLS_28 | PINMODE_NO_PULLS_29);
    PINSEL6  = (PINSEL6_P3_0_D0 | PINSEL6_P3_1_D1 | PINSEL6_P3_2_D2 | PINSEL6_P3_3_D3 | PINSEL6_P3_4_D4 | PINSEL6_P3_5_D5 | PINSEL6_P3_6_D6 | PINSEL6_P3_7_D7 | PINSEL6_P3_8_D8 | PINSEL6_P3_9_D9 | PINSEL6_P3_10_D10 | PINSEL6_P3_11_D11 | PINSEL6_P3_12_D12 | PINSEL6_P3_13_D13 | PINSEL6_P3_14_D14 | PINSEL6_P3_15_D15); // data lines D0..D15
    PINMODE6 = (PINMODE_NO_PULLS_0 | PINMODE_NO_PULLS_1 | PINMODE_NO_PULLS_2 | PINMODE_NO_PULLS_3 | PINMODE_NO_PULLS_4 | PINMODE_NO_PULLS_5 | PINMODE_NO_PULLS_6 | PINMODE_NO_PULLS_7 | PINMODE_NO_PULLS_8 | PINMODE_NO_PULLS_9 | PINMODE_NO_PULLS_10 | PINMODE_NO_PULLS_11 | PINMODE_NO_PULLS_12 | PINMODE_NO_PULLS_13 | PINMODE_NO_PULLS_14 | PINMODE_NO_PULLS_15);
    PINSEL8  |= (PINSEL8_P4_0_A0 | PINSEL8_P4_1_A1 | PINSEL8_P4_2_A2 | PINSEL8_P4_3_A3 | PINSEL8_P4_4_A4 | PINSEL8_P4_5_A5 | PINSEL8_P4_6_A6 | PINSEL8_P4_7_A7 | PINSEL8_P4_8_A8 | PINSEL8_P4_9_A9 | PINSEL8_P4_10_A10 | PINSEL8_P4_11_A11 | PINSEL8_P4_12_A12 | PINSEL8_P4_13_A13 | PINSEL8_P4_14_A14); // address lines A0..A14
    PINMODE8 |= (PINMODE_NO_PULLS_0 | PINMODE_NO_PULLS_1 | PINMODE_NO_PULLS_2 | PINMODE_NO_PULLS_3 | PINMODE_NO_PULLS_4 | PINMODE_NO_PULLS_5 | PINMODE_NO_PULLS_6 | PINMODE_NO_PULLS_7 | PINMODE_NO_PULLS_8 | PINMODE_NO_PULLS_9 | PINMODE_NO_PULLS_10 | PINMODE_NO_PULLS_11 | PINMODE_NO_PULLS_12 | PINMODE_NO_PULLS_13 | PINMODE_NO_PULLS_14);
    PINSEL9  |= (PINSEL9_P4_25_WE);
    PINMODE9 |= (PINMODE_NO_PULLS_25);
    
    EMCControl           = EMC_ENABLE;                                   // initialise the SDRAM controller and enable EMC clock
    EMCDynamicReadConfig = READ_DATA_STRATEGY_CMD_DLY;
    EMCDynamicRasCas0    = (RAS_LATENCY_THREE_CCLK | CAS_LATENCY_THREE_CCLK);
    EMCDynamicRP         = CALC_PERIOD(SDRAM_TRP);
    EMCDynamicRAS        = CALC_PERIOD(SDRAM_TRAS);
    EMCDynamicSREX       = CALC_PERIOD(SDRAM_TXSR);
    EMCDynamicAPR        = SDRAM_TAPR;
    EMCDynamicDAL        = SDRAM_TDAL + CALC_PERIOD(SDRAM_TRP);
    EMCDynamicWR         = SDRAM_TWR;
    EMCDynamicRC         = CALC_PERIOD(SDRAM_TRC);
    EMCDynamicRFC        = CALC_PERIOD(SDRAM_TRFC);
    EMCDynamicXSR        = CALC_PERIOD(SDRAM_TXSR);
    EMCDynamicRRD        = CALC_PERIOD(SDRAM_TRRD);
    EMCDynamicMRD        = SDRAM_TMRD;
    EMCDynamicConfig0    = ADDRESS_MAP_16M_16BIT;                        // 13 row, 9 - col, SDRAM

    // SDRAM initialisation sequence
    //
    EMCDynamicControl = (SDRAM_NOP_CMD | DYNAMIC_CLKOUT_CONTINUOUS | DYNAMIC_MEM_CLK_EN);
    ulDelay = 200*30;
    while (ulDelay--) {}
    EMCDynamicControl = (SDRAM_PRECHARGE_ALL_CMD | DYNAMIC_CLKOUT_CONTINUOUS | DYNAMIC_MEM_CLK_EN); // PALL
    EMCDynamicRefresh = 1;
    ulDelay = 128;
    while (ulDelay--) {}                                                 // 128 clock delay
    EMCDynamicRefresh = CALC_PERIOD(SDRAM_REFRESH) >> 4;
    EMCDynamicControl = (SDRAM_MODE_CMD | DYNAMIC_CLKOUT_CONTINUOUS | DYNAMIC_MEM_CLK_EN); // COMM
    ulDelay = *(volatile unsigned short *)fnGetSDRAM((unsigned char *)(SDRAM_ADDR + (0x33UL << (12)))); // burst 8, sequential, CAS-2
    EMCDynamicControl = 0;                                               // NORM
    EMCDynamicConfig0 |= CS_BUFFER_ENABLE;
}


// Initialise the LCD pins and also configure the LCD controller
//
static void fnInitLCD_Controller(void)
{
    PINSEL0   |= (PINSEL0_P0_4_LCD | PINSEL0_P0_5_LCD | PINSEL0_P0_6_LCD | PINSEL0_P0_7_LCD | PINSEL0_P0_8_LCD | PINSEL0_P0_9_LCD);
    PINMODE0  |= (PINMODE_NO_PULLS_4 | PINMODE_NO_PULLS_5 | PINMODE_NO_PULLS_6 | PINMODE_NO_PULLS_7 | PINMODE_NO_PULLS_8 | PINMODE_NO_PULLS_9);
    PINSEL3   |= (PINSEL3_P1_20_LCD | PINSEL3_P1_21_LCD | PINSEL3_P1_22_LCD | PINSEL3_P1_23_LCD | PINSEL3_P1_24_LCD | PINSEL3_P1_25_LCD | PINSEL3_P1_26_LCD | PINSEL3_P1_27_LCD | PINSEL3_P1_28_LCD | PINSEL3_P1_29_LCD);
#ifdef USB_INTERFACE                                                     // {2}
    PINMODE3  |= (PINMODE_NO_PULLS_20 | PINMODE_NO_PULLS_21 | PINMODE_NO_PULLS_22 | PINMODE_NO_PULLS_23 | PINMODE_NO_PULLS_24 | PINMODE_NO_PULLS_25 | PINMODE_NO_PULLS_26 /*| PINMODE_NO_PULLS_27*/ | PINMODE_NO_PULLS_28 | PINMODE_NO_PULLS_29); // when USB is used, disabling the pull-up on P1-27 causes various problems, therefore just leave it connected...
#else
    PINMODE3  |= (PINMODE_NO_PULLS_20 | PINMODE_NO_PULLS_21 | PINMODE_NO_PULLS_22 | PINMODE_NO_PULLS_23 | PINMODE_NO_PULLS_24 | PINMODE_NO_PULLS_25 | PINMODE_NO_PULLS_26 | PINMODE_NO_PULLS_27 | PINMODE_NO_PULLS_28 | PINMODE_NO_PULLS_29);
#endif
    PINSEL4   |= (PINSEL4_P2_0_LCD | PINSEL4_P2_1_LCD | PINSEL4_P2_2_LCD | PINSEL4_P2_3_LCD | PINSEL4_P2_4_LCD | PINSEL4_P2_5_LCD | PINSEL4_P2_6_LCD | PINSEL4_P2_7_LCD | PINSEL4_P2_8_LCD | PINSEL4_P2_9_LCD | PINSEL4_P2_11_LCD | PINSEL4_P2_12_LCD | PINSEL4_P2_13_LCD);
    PINMODE4  |= (PINMODE_NO_PULLS_0 | PINMODE_NO_PULLS_1 | PINMODE_NO_PULLS_2 | PINMODE_NO_PULLS_3 | PINMODE_NO_PULLS_4 | PINMODE_NO_PULLS_5 | PINMODE_NO_PULLS_6 | PINMODE_NO_PULLS_7 | PINMODE_NO_PULLS_8 | PINMODE_NO_PULLS_9 | PINMODE_NO_PULLS_11 | PINMODE_NO_PULLS_12 | PINMODE_NO_PULLS_13);
    PINSEL9   |= (PINSEL9_P4_28_LCD | PINSEL9_P4_29_LCD);
    PINMODE9  |= (PINMODE_NO_PULLS_28 | PINMODE_NO_PULLS_29);
    PINSEL11   = (LCD_MODE_TFT_24_BIT | LCDPE);                          // set TFT mode and enable LCD port

    LCD_CTRL   = (PIXEL_24 | TFT_DISPLAY);                               // configure the LCD controller itself
    LCD_CFG    = (MASTER_CLOCK / PIXEL_CLOCK_RATE);
    LCD_POL    = (BYPASS_PIXEL_CLOCK_DIVIDER | INVERT_VERT_SYNC | INVERT_HORIZ_SYNC | INVERT_PANEL_CLOCK | ((GLCD_X - 1) << 16));
    LCD_TIMH   = (((HORIZONTAL_BACK_PORCH - 1) << 24) | ((HORIZONTAL_FRONT_PORCH - 1) << 16) | ((HORIZONTAL_PULSE - 1) << 8) | (((GLCD_X/16) - 1) << 2)); // horizontal timing
    LCD_TIMV   = ((VERTICAL_BACK_PORCH << 24) | (VERTICAL_FRONT_PORCH << 16) | (VERTICAL_PULSE << 10) | (GLCD_Y - 1)); // vertical timing
    LCD_LPBASE = LCD_UPBASE = (LCD_VRAM_BASE_ADDR & 0xfffffff8);         // frame base double work aligned
    LCD_LPBASE = (LCD_VRAM_BASE_ADDR & 0xfffffff8);
}
    #endif

    #if defined GLCD_INIT
            POWER_UP(PCEMC | PCLCD);                                     // power up the External Memory Controller and enable LCD controller clock
            fnInit_SDRAM();                                              // initialise the SDRAM controller
            LCD_CTRL &= ~LCD_PWR;                                        // disable power
            uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(0.01*SEC), E_STABILISE_DELAY);
            iLCD_State = STATE_POWER_LCD_0;
            return;

        case STATE_POWER_LCD_0:
            LCD_CTRL &= ~LCD_EN;
            fnInitLCD_Controller();                                      // initialise the LCD controller
            uTaskerMonoTimer(OWN_TASK, (DELAY_LIMIT)(0.01*SEC), E_STABILISE_DELAY);
            iLCD_State = STATE_POWER_LCD_1;
            return;

        case STATE_POWER_LCD_1:
            {
                unsigned long *ptrSDRAM = (unsigned long *)fnGetSDRAM((unsigned char *)SDRAM_ADDR);
                int i = (GLCD_X * GLCD_Y);
                while (i--) {
                    *ptrSDRAM++ = LCD_ON_COLOUR;
                }
                LCD_CTRL |= LCD_EN;                                      // enable but don't power until after the stabilising delay
                uTaskerMonoTimer( OWN_TASK, (DELAY_LIMIT)(0.01*SEC), E_STABILISE_DELAY );
                iLCD_State = STATE_POWER_LCD_2;
            }
            return;

        case STATE_POWER_LCD_2:
            fnClearScreen();
            LCD_CTRL |= LCD_PWR;                                         // enable power
            fnStartTouch();                                              // {3} initialise and start touch screen operation
    #endif
#endif
