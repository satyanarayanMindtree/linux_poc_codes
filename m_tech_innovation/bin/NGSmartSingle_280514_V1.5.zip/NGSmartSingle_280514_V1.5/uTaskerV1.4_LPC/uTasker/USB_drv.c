/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        USB_drv.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2012
    *********************************************************************

    06.10.2008 Adjust USB read/writes to support FIFO operation          {1}
    17.10.2008 Add control endpoint direction control and setup clear    {2}
    25.12.2008 Additional tx buffer depth check (no longer optional)     {3}
    04.01.2009 Additional setup clears added                             {4}
    10.01.2009 Correct tx buffer depth check                             {5}
    10.01.2009 Break from loop rather than individual return values      {6}
    29.01.2009 Clear endpoint FIFO depth on disconnect                   {7}
    07.03.2009 Remove unnecessary usEndPoints                            {8}
    12.05.2009 Optionally don't sent zero-data frame on non-control endpoints {9}
    02.02.2010 Sum outstanding data when multiple buffers                {10}
    21.03.2010 Allow control of whether an endpoint sends zero-date frame{11}
    21.03.2010 Allow receptions to be handled by both a callback and a buffer {12}
    21.03.2010 Add USB_REQUEST_CLEAR_FEATURE support                     {13}
    21.03.2010 Modify the routine fnSetUSBEndpointState() to only set state bits {14}
    22.03.2010 Extract indexed data from FIFO, when FIFO used            {15}
    02.04.2010 Add VALIDATE_NEW_CONFIGURATION() and fnGetPairedIN()      {16}
    18.04.2010 Add USB DMA support                                       {17}
    20.06.2010 Add CRITICAL_OUT for FIFO endpoints which have to consume data {18}
    13.07.2010 Add intermediate FIFO support                             {19}
    14.02.2011 Configure usb_endpoint_control before configuring hardware to avoid possibility of reset interrupt trying to use it too soon {20}
    15.02.2012 Correct queuing for devices with more than double-buffer depth {21} (this correction isn't important for devices previously supported up to its introduction)
    15.02.2012 Add MULTIPLE_TX option for devices that can independently handle multiple IN packets {22}

*/

/* =================================================================== */
/*                           include files                             */
/* =================================================================== */

//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"

#ifdef USB_INTERFACE

#define MJB_CATCH_ERROR                                                  // evaluation settings [confirmed and to be used as standard]
#define MJB_TEST_PROTECT_NEW_WRITE
#define MJB_WAIT_UNTIL_ALL_BUFFERS_SENT


#ifdef MJB_CATCH_ERROR
static void fnError(int iErrorNumber)
{
    while (1) {}
}
#endif

/* =================================================================== */
/*                          local definitions                          */
/* =================================================================== */

#define DIRECTION_OUT() ((ucFirstByte & TYPE_AND_DIRECTION_MASK) != STANDARD_DEVICE_TO_HOST)
#define DIRECTION_IN()  ((ucFirstByte & TYPE_AND_DIRECTION_MASK) == STANDARD_DEVICE_TO_HOST)

#if defined USB_FIFO && !defined _WINDOWS                                // {1}
    #define GET_USB_DATA()         (unsigned char)(*(volatile unsigned char *)ptrData)
    #define GET_USB_DATA_NO_INC()  (unsigned char)(*(volatile unsigned char *)ptrData)
#else
    #define GET_USB_DATA()         *ptrData++
    #define GET_USB_DATA_NO_INC()  *ptrData
#endif

/* =================================================================== */
/*                       local structure definitions                   */
/* =================================================================== */

/* =================================================================== */
/*                 local function prototype declarations               */
/* =================================================================== */

/* =================================================================== */
/*                             constants                               */
/* =================================================================== */

static const unsigned short usInterfaceStatus = 0x0000;                  // the interface status is presently reserved in the USB specification so a fixed value of zeros can be used
static const unsigned short usEndpointStalled = LITTLE_SHORT_WORD(ENDPOINT_STATUS_STALLED);
#define usEndpointOK usInterfaceStatus                                   // use the same zero status


/* =================================================================== */
/*                      local variable definitions                     */
/* =================================================================== */

static USB_ENDPOINT  *usb_endpoint_control = 0;                          // pointer to a list of endpoint control structures
static unsigned short usDeviceStatus = 0;                                // state of device (SELF_POWERED_BIT, REMOTE_WAKEUP_BIT)
static unsigned char  ucActiveConfiguration = 0;                         // present active configuration
//static unsigned char  usEndPoints = 0;                                 // {8} the number of endpoints configured


/* =================================================================== */
/*                      local function definitions                     */
/* =================================================================== */

static QUEUE_TRANSFER fnPrepareOutData(unsigned char *ptrData, unsigned short usLength, unsigned short ucMaxLength, int iEndpoint, USB_HW *ptrUSB_HW);
static void *fnSetUSBInterfaceState(int iCommand, unsigned char ucInterface, unsigned char ucAlternativeInterface);
      #define USB_INTERFACE_DEACTIVATE 0
      #define USB_INTERFACE_ACTIVATE   1
      #define USB_INTERFACE_ALTERNATE  2

/* =================================================================== */
/*                      global function definitions                    */
/* =================================================================== */



// Standard entry call to driver - dispatches required sub-routine
//
extern QUEUE_TRANSFER entry_usb(QUEUE_HANDLE channel, unsigned char *ptBuffer, QUEUE_TRANSFER Counter, unsigned char ucCallType, QUEUE_HANDLE DriverID)
{
    QUEUE_TRANSFER rtn_val = 0;
    USBQUE *ptrUsbQue;

    uDisable_Interrupt();                                                // disable all interrupts

    switch ( ucCallType ) {
    case CALL_DRIVER:                                                    // request changes and return status
        if ((CAST_POINTER_ARITHMETIC)ptBuffer & MODIFY_TX) {
            ptrUsbQue = (USBQUE *)(que_ids[DriverID].output_buffer_control); // set to output control block
        }
        else {
            ptrUsbQue = (USBQUE *)(que_ids[DriverID].input_buffer_control); // set to input control block
        }
        if (Counter & MODIFY_WAKEUP) {
            if (ptrUsbQue->endpoint_control->ucState & USB_ENDPOINT_ACTIVE) { // don't allow changes when endpoint is not active
                ptrUsbQue->endpoint_control->event_task = (UTASK_TASK)((CAST_POINTER_ARITHMETIC)ptBuffer & 0x7f);
            }
        }
        rtn_val = ptrUsbQue->endpoint_control->ucState;                  // return the present state
        break;

    case CALL_INPUT:                                                     // request the number or input characters waiting
        ptrUsbQue = (USBQUE *)(que_ids[DriverID].input_buffer_control);  // set to input control block
        rtn_val = ptrUsbQue->USB_queue.chars;
        break;

    case CALL_WRITE:                                                     // write data into the output queue
                                                                         // copy the data to the output buffer and start transmission if not already done
        ptrUsbQue = (USBQUE*)que_ids[DriverID].output_buffer_control;    // set to output control block
        if (ptrUsbQue == 0) {                                            // no output buffer so use direct method
            USB_HW usb_hardware;
            if (fnGetUSB_HW(channel, &usb_hardware) == ENDPOINT_FREE) {  // if hardware is ready and buffers not full
#ifdef MJB_TEST_PROTECT_NEW_WRITE
                rtn_val = fnPrepareOutData(ptBuffer, Counter, Counter, channel, &usb_hardware);
#else
                uEnable_Interrupt();                                     // enable interrupts
                return (fnPrepareOutData(ptBuffer, Counter, Counter, channel, &usb_hardware));
#endif
            }
            break;
        }
        if (!(ptrUsbQue->endpoint_control->ucState & USB_ENDPOINT_ACTIVE)) {// only allow the copy if the endpoint is active
            break;
        }
        if (!ptBuffer) {                                                 // the caller wants to see whether the data will fit and not copy data so inform
            if ((ptrUsbQue->USB_queue.buf_length - ptrUsbQue->USB_queue.chars) >= Counter) {
                rtn_val = ptrUsbQue->USB_queue.buf_length - ptrUsbQue->USB_queue.chars;// the remaining space
            }
        }
        else {                                                           // buffered mode
            USB_HW usb_hardware;
            uEnable_Interrupt();                                         // fnFillBuffer disables and then re-enables interrupts - be sure we are compatible
            rtn_val = fnFillBuf(&ptrUsbQue->USB_queue, ptBuffer, Counter);// copy the input data to the output circular buffer
            uDisable_Interrupt();
#if defined USB_DMA_TX && defined USB_RAM_START
            if (!(ptrUsbQue->endpoint_control->ucState & TX_ACTIVE)) {   // if transmission is already in progress don't activate any more activity
                ptrUsbQue->endpoint_control->ucState |= TX_ACTIVE;       // mark that the transmitter is active
                (usb_endpoint_control + channel)->usCompleteMessage = rtn_val = (usb_endpoint_control + channel)->usSent = fnPrepareUSBOutData(ptrUsbQue, rtn_val, channel, &usb_hardware);
            }
#else
            if ((!(ptrUsbQue->endpoint_control->ucState & TX_ACTIVE)) && (fnGetUSB_HW(channel, &usb_hardware) == ENDPOINT_FREE)) { // first block in buffer, hardware is ready and buffers not full
                unsigned short usLength = (ptrUsbQue->USB_queue.buffer_end - ptrUsbQue->USB_queue.get); // maximum linear part of buffer
                ptrUsbQue->endpoint_control->ucState |= TX_ACTIVE;       // mark that the transmitter is active
    #ifdef MJB_TEST_PROTECT_NEW_WRITE
                if (rtn_val < usLength) {
                    usLength = rtn_val;
                }
                rtn_val = fnPrepareOutData(ptrUsbQue->USB_queue.get, usLength, usLength, channel, &usb_hardware);
    #else
                uEnable_Interrupt();
                if (rtn_val < usLength) {
                    usLength = rtn_val;
                }
                return (fnPrepareOutData(ptrUsbQue->USB_queue.get, usLength, usLength, channel, &usb_hardware));
    #endif
            }
#endif
        }
        break;

    case CALL_READ:                                                      // read data from the queue
        ptrUsbQue = (USBQUE *)(que_ids[DriverID].input_buffer_control);  // set to input control block
        rtn_val = fnGetBuf(&ptrUsbQue->USB_queue, ptBuffer, Counter);    // interrupts are re-enabled as soon as no longer critical
        if (ptrUsbQue->endpoint_control->ucState & USB_ENDPOINT_BLOCKED) {// the buffer has been previously blocked due to lack of space
            uDisable_Interrupt();
            ptrUsbQue->endpoint_control->ucState &= ~USB_ENDPOINT_BLOCKED;// remove the blocked state - it will be set again if the data in the input USB buffer still can't be put to the buffer
            while (fnConsumeUSB_out(ptrUsbQue->endpoint_control->ucEndpointNumber) == USB_BUFFER_FREED) {} // copy data from waiting buffer and free buffer for further use
            uEnable_Interrupt();
        }
        return rtn_val;

#ifdef SUPPORT_FLUSH
    case CALL_FLUSH:                                                     // flush input or output queue completely
        if (Counter != FLUSH_RX) {                                       // tx
            ptrUsbQue = (USBQUE *)(que_ids[DriverID].output_buffer_control);  // set to output control block
        }
        else {                                                           // rx
            ptrUsbQue = (USBQUE *)(que_ids[DriverID].input_buffer_control); // set to input control block
        }
        ptrUsbQue->USB_queue.get = ptrUsbQue->USB_queue.put = ptrUsbQue->USB_queue.QUEbuffer;
        ptrUsbQue->USB_queue.chars = 0;
        break;
#endif

    default:
       break;
    }
    uEnable_Interrupt();                                                 // enable interrupts
    return (rtn_val);
}

// fnOpen() calls this for the USB interface
//
extern QUEUE_HANDLE fnOpenUSB(USBTABLE *pars, unsigned char driver_mode)
{
    QUEUE_HANDLE DriverID = NO_ID_ALLOCATED;
    QUEUE_TRANSFER (*entry_add)(QUEUE_HANDLE channel, unsigned char *ptBuffer, QUEUE_TRANSFER Counter, unsigned char ucCallType, QUEUE_HANDLE DriverID) = entry_usb;
    USB_ENDPOINT *usb_endpoint_queue = usb_endpoint_control;
    DriverID = fnAllocateQueue(&pars->queue_sizes, pars->Endpoint, entry_add, sizeof(USBQUE)); // allocate queue and buffers
    if (pars->Endpoint != 0) {                                           // endpoint 0, used for general configuration
        usb_endpoint_queue += pars->Endpoint;
        usb_endpoint_queue->usMax_frame_length = pars->usEndpointSize;   // enter end point limit
        if (pars->usConfig & USB_TERMINATING_ENDPOINT) {                 // {11}
            usb_endpoint_queue->ucParameters = USB_ENDPOINT_TERMINATES;  // set endpoints mode parameter
        }
    }
    else {                                                               // default control endpoint
      //fnConfigUSB(0, pars);                                            // configure hardware for control end point
      //usEndPoints = (pars->ucEndPoints + 1);                           // {8}
        usb_endpoint_control = usb_endpoint_queue = uMalloc((MAX_MALLOC)((pars->ucEndPoints + 1) * sizeof(USB_ENDPOINT)));// {8} create the control queue for all end points
        usb_endpoint_queue->usMax_frame_length = ENDPOINT_0_SIZE;        // enter end point 0 limit
        usb_endpoint_queue->event_task = pars->owner_task;               // the task notified of USB state changes
        fnConfigUSB(0, pars);                                            // configure hardware for control end point {20}
    }
    if ((usb_endpoint_queue->ptrEndpointInCtr = (que_ids[DriverID - 1].output_buffer_control)) != 0) { // set to output control block
        ((USBQUE *)(usb_endpoint_queue->ptrEndpointInCtr))->endpoint_control = usb_endpoint_queue;
    #ifdef WAKE_BLOCKED_USB_TX
        usb_endpoint_queue->low_water_level = pars->low_water_level;
      //usb_endpoint_queue->event_task = 0;                              // uMalloc returns this as zero
    #endif
    }
    usb_endpoint_queue->ucEndpointNumber = pars->Endpoint;               // enter the endpoint number
    if ((pars->Endpoint != 0) && (pars->Paired_RxEndpoint != 0)) {       // this is a paired endpoint, where this endpoint is the receiver (OUT) in the paired channel
        usb_endpoint_queue = usb_endpoint_control + pars->Paired_RxEndpoint;
        usb_endpoint_queue->ucEndpointNumber = pars->Paired_RxEndpoint;  // enter the endpoint number
        usb_endpoint_queue->ucPaired_IN = pars->Endpoint;                // {16}
        usb_endpoint_queue->usMax_frame_length = pars->usEndpointSize;   // enter endpoint size limit
    }
    if ((usb_endpoint_queue->ptrEndpointOutCtr = (que_ids[DriverID - 1].input_buffer_control)) != 0) { // set to input control block
        ((USBQUE *)(usb_endpoint_queue->ptrEndpointOutCtr))->endpoint_control = usb_endpoint_queue;
        usb_endpoint_queue->event_task = pars->owner_task;
    }
    usb_endpoint_queue->usb_callback = pars->usb_callback;               // enter optional callback routine for endpoint (used by reception - OUT)
    #if (defined USB_DMA_TX || defined USB_DMA_RX) && defined USB_RAM_START // {17}
    if (NO_MEMORY == fnAllocateUSBBuffer(DriverID, usb_endpoint_queue, &pars->queue_sizes)) {
        return NO_ID_ALLOCATED;
    }
    #endif
    return (DriverID);                                                   // return the allocated ID (handle for the end point)
}

// Send a message to the endpoint owner task
//
static void fnUSB_message(unsigned char ucEvent, unsigned char *ptrData, unsigned char ucDataLength, UTASK_TASK destination)
{
    unsigned char ucMessage[ HEADER_LENGTH + 1 + 2 ];
    if (!destination) {
        return;
    }
#ifdef _WINDOWS
    if (ucDataLength > 2) {
        *(int *)0 = 0;                                                   // we need to increase the message queue length above if this happens
    }
#endif

    uMemcpy(&ucMessage[ HEADER_LENGTH + 1 ], ptrData, ucDataLength);

    ucMessage[ MSG_DESTINATION_NODE ] = INTERNAL_ROUTE;                  // destination node
    ucMessage[ MSG_SOURCE_NODE ]      = INTERNAL_ROUTE;                  // own node
    ucMessage[ MSG_DESTINATION_TASK ] = destination;                     // destination task
    ucMessage[ MSG_SOURCE_TASK ]      = TASK_USB;                        // own task (fictional)
    ucMessage[ MSG_CONTENT_LENGTH ]   = ++ucDataLength;                  // message length
    ucMessage[ MSG_CONTENT_COMMAND ]  = ucEvent;                         // event message type

    fnWrite( INTERNAL_ROUTE, ucMessage, (QUEUE_TRANSFER)(ucDataLength + HEADER_LENGTH));// send message to USB task
}

// Handle the lengths of individual FIFO buffers - the depth is hardware dependent
//
static void fnPushLastLength(USBQUE *endpoint_queue, unsigned short usLength)
{
    if (endpoint_queue != 0) {
#ifdef MJB_CATCH_ERROR
        if (endpoint_queue->endpoint_control->ucFIFO_depth > 1) {        // catch writing beyond end of FIFO length buffer
            fnError(1);
        }
#endif
        endpoint_queue->endpoint_control->usLength[endpoint_queue->endpoint_control->ucFIFO_depth++] = usLength; // enter next
    }
}

// Get the length of a previously transmitted buffer
// 
static unsigned short fnPullLastLength(USB_ENDPOINT *endpoint_control)
{
    int iEntry = 1;
    unsigned short usLength = endpoint_control->usLength[0];             // length of last data token
    while (iEntry < endpoint_control->ucFIFO_depth) {
        endpoint_control->usLength[iEntry - 1] = endpoint_control->usLength[iEntry]; // shift the lengths in the queue
        iEntry++;
    }
#ifdef MJB_CATCH_ERROR
    if (endpoint_control->ucFIFO_depth == 0) {                           // catch writing before start of FIFO length buffer
        fnError(2);
    }
#endif
    endpoint_control->ucFIFO_depth--;                                    // FIFO one less in depth
    return (usLength);
}

// Get the total amount of data passed to USB buffers but not yet acknowledged
//
static unsigned short fnOutstandingData(USB_ENDPOINT *endpoint_control)
{
    int iEntries = endpoint_control->ucFIFO_depth;
    unsigned short usOutstanding = 0;
#ifdef MJB_CATCH_ERROR
    if (iEntries > 1) {                                                  // catch writing beyond end of FIFO length buffer
        fnError(3);
    }
#endif
    while (iEntries--) {
        usOutstanding += endpoint_control->usLength[iEntries];           // {10}
    }
    return usOutstanding;
}

// Request whether an endpoint is a control endpoint
//
static int fnControlEndpoint(int iEndpoint, unsigned char ucCheck)       // {11}
{
    if (iEndpoint == 0) {
        return 1;                                                        // endpoint 0 is always a control endpoint
    }
    else {
        USB_ENDPOINT *usb_endpoint_queue = usb_endpoint_control + iEndpoint;
        if (usb_endpoint_queue->ucState & ucCheck) {                     // this endpoint is configured as the check state
            return 1;
        }
    }
    return 0;
}


// Enter the data to be transmitted into the management queue of its specific end point and start first packet transfer
//
static QUEUE_TRANSFER fnPrepareOutData(unsigned char *ptrData, unsigned short usLength, unsigned short ucMaxLength, int iEndpoint, USB_HW *ptrUSB_HW)
{
    USB_ENDPOINT *tx_queue = (usb_endpoint_control + iEndpoint);
    unsigned short usAdditionalLength;                                   // {21}

    if (tx_queue->usCompleteMessage != 0) {                              // transmission already in progress
        return 0;
    }
    tx_queue->usLimitLength = ucMaxLength;
    if (usLength > ucMaxLength) {                                        // if host can not accept full length, cut it shorter
        usLength = ucMaxLength;
    }

    tx_queue->usCompleteMessage = usLength;                              // total queued length
#if defined MULTIPLE_TX                                                  // {22}
    if (iEndpoint == 0) {
        if (usLength > (MULTIPLE_TX*tx_queue->usMax_frame_length)) {
            tx_queue->usSent = (MULTIPLE_TX*tx_queue->usMax_frame_length); // maximum endpoint length
        }
        else {
            tx_queue->usSent = usLength;                                 // complete message in one buffer
        }
    }
    else {
        if (usLength > tx_queue->usMax_frame_length) {
            tx_queue->usSent = tx_queue->usMax_frame_length;             // maximum endpoint length
        }
        else {
            tx_queue->usSent = usLength;                                 // complete message in one buffer
        }
    }
#else
    if (usLength > tx_queue->usMax_frame_length) {
        tx_queue->usSent = tx_queue->usMax_frame_length;                 // maximum endpoint length
    }
    else {
        tx_queue->usSent = usLength;                                     // complete message in one buffer
    }
#endif
    usAdditionalLength = tx_queue->usSent;
    FNSEND_USB_DATA(ptrData, usAdditionalLength, iEndpoint, ptrUSB_HW);  // prepare hardware buffer
    fnPushLastLength((USBQUE *)(tx_queue->ptrEndpointInCtr), usAdditionalLength); // save last length for use later
    tx_queue->ptrStart = ptrData;

    while (tx_queue->usCompleteMessage != tx_queue->usSent) {            // controllers usually have multiple output buffers so fill up as many as possible
      //unsigned short usAdditionalLength = tx_queue->usSent;            // {21} set before entering the loop
        USBQUE *endpoint_queue = (USBQUE *)(tx_queue->ptrEndpointInCtr); // {3} additional check on tx buffer depth
        if (endpoint_queue != 0) {
            if (endpoint_queue->endpoint_control->ucFIFO_depth >= USB_FIFO_BUFFER_DEPTH) { // {5}
              //return tx_queue->usCompleteMessage;
                break;                                                   // {6}
            }
        }
        if (fnGetUSB_HW(iEndpoint, ptrUSB_HW) != ENDPOINT_FREE) {        // no more buffer space
            //return tx_queue->usCompleteMessage;
            break;                                                       // {6}
        }
        usLength -= usAdditionalLength;                                  // remaining
        ptrData += usAdditionalLength;
        if (usLength > tx_queue->usMax_frame_length) {
            usAdditionalLength = tx_queue->usMax_frame_length;           // maximum endpoint length
        }
        else {
            usAdditionalLength = usLength;                               // complete message prepared
        }
        FNSEND_USB_DATA(ptrData, usAdditionalLength, iEndpoint, ptrUSB_HW);// prepare hardware buffer
        fnPushLastLength((USBQUE *)(tx_queue->ptrEndpointInCtr), usAdditionalLength); // save last length for use later
        tx_queue->usSent += usAdditionalLength;
    }
    return tx_queue->usCompleteMessage;
}

// Extract (certain values) from standard descriptor requests in little-endian format
//
static void fnExtract(unsigned char *ptrData, unsigned char ucFlags, unsigned short *usValues)
{
    #define VALUE_INDEX   0x01
    #define INDEX_INDEX   0x02
    #define LENGTH_INDEX  0x04

    if (ucFlags & VALUE_INDEX) {
        *usValues =  GET_USB_DATA();
        *usValues++ |= (GET_USB_DATA() << 8);
    }
    else {
#ifdef USB_FIFO
        GET_USB_DATA();GET_USB_DATA();                                   // {15}
#else
        ptrData += sizeof(unsigned short);
#endif
    }
    if (ucFlags & INDEX_INDEX) {
        *usValues =  GET_USB_DATA();
        *usValues++ |= (GET_USB_DATA() << 8);
    }
    else {
#ifdef USB_FIFO
        GET_USB_DATA();GET_USB_DATA();                                   // {15}
#else
        ptrData += sizeof(unsigned short);
#endif
    }
    if (ucFlags & LENGTH_INDEX) {
        *usValues =  GET_USB_DATA();
        *usValues |= (GET_USB_DATA() << 8);
    }
}

#ifdef WAKE_BLOCKED_USB_TX
// Wake a blocked USB IN endpoint queue by informing its owner task that there is space available to put new data to
//
static void fnWakeBlockedTx(USBQUE *ptrUsbQueue, QUEUE_TRANSFER low_water)
{
    if ((ptrUsbQueue->endpoint_control->event_task != 0) && (ptrUsbQueue->USB_queue.chars <= low_water)) { // we have just adeqately emptied buffer content so inform waiting transmitter task
        unsigned char tx_continue_message[ HEADER_LENGTH ]; // = { INTERNAL_ROUTE, INTERNAL_ROUTE , ptrUsbQue->tx_queue->event_task, INTERRUPT_EVENT, TX_FREE };  // define standard interrupt event
        tx_continue_message[MSG_DESTINATION_NODE] = INTERNAL_ROUTE;
        tx_continue_message[MSG_SOURCE_NODE]      = INTERNAL_ROUTE;
        tx_continue_message[MSG_DESTINATION_TASK] = ptrUsbQueue->endpoint_control->event_task;
        tx_continue_message[MSG_SOURCE_TASK]      = INTERRUPT_EVENT;
        tx_continue_message[MSG_INTERRUPT_EVENT]  = TX_FREE;

        fnWrite( INTERNAL_ROUTE, (unsigned char*)tx_continue_message, HEADER_LENGTH); // inform the blocked task
        ptrUsbQueue->endpoint_control->event_task = 0;                   // remove task since this is only performed once
    }
}
#endif

// Generic USB data handler - called from interrupt routine
//
extern int fnUSB_handle_frame(unsigned char ucType, unsigned char *ptrData, int iEndpoint, USB_HW *ptrUSB_HW)
{
    switch (ucType) {
    case USB_TX_ACKED:                                                   // a previous transmission has been successfully acked
        {
            USB_ENDPOINT *tx_queue = (usb_endpoint_control + iEndpoint);
            USBQUE *ptrUsbQueue = (USBQUE *)(tx_queue->ptrEndpointInCtr);
            if (tx_queue->usCompleteMessage == 0) {                      // no message in queue
#ifdef MJB_WAIT_UNTIL_ALL_BUFFERS_SENT
                if (ptrUsbQueue == 0) {
                    break;
                }
                if (ptrUsbQueue->USB_queue.chars != 0) {                 // more data added to queue in the mean time
    #if defined USB_DMA_TX && defined USB_RAM_START
                    tx_queue->usCompleteMessage = tx_queue->usSent = fnPrepareUSBOutData(ptrUsbQueue, ptrUsbQueue->USB_queue.chars, iEndpoint, ptrUSB_HW);
    #else
                    unsigned short usLength;
                    if (ptrUsbQueue->USB_queue.get >= ptrUsbQueue->USB_queue.buffer_end) { // handle circular buffer
                        ptrUsbQueue->USB_queue.get -= ptrUsbQueue->USB_queue.buf_length;
                    }
                    usLength = (ptrUsbQueue->USB_queue.buffer_end - ptrUsbQueue->USB_queue.get); // linear buffer remaining (maximum linear block size possible)
                    if (ptrUsbQueue->USB_queue.chars < usLength) {       // if there are less additional characters waiting reduce
                        usLength = ptrUsbQueue->USB_queue.chars;         // next block length required
                    }
                    fnPrepareOutData(ptrUsbQueue->USB_queue.get, usLength, usLength, iEndpoint, ptrUSB_HW); // prepare next buffer(s)
    #endif
    #ifdef WAKE_BLOCKED_USB_TX
                    fnWakeBlockedTx(ptrUsbQueue, ptrUsbQueue->endpoint_control->low_water_level); // we have just emptied buffer content so inform waiting transmitter task
    #endif
                }
                else {
                    ptrUsbQueue->endpoint_control->ucState &= ~TX_ACTIVE;// mark that the transmitter is idle and should be started when the next data is added to the buffer
                }
#endif
                break;
            }
            if (tx_queue->usSent >= tx_queue->usCompleteMessage) {       // block transmission is completely in transmission so we can prepare next block if available
                if ((ptrUsbQueue != 0) && (ptrUsbQueue->USB_queue.chars != 0)) { // if there is transmit buffer data waiting add it now
#if defined USB_DMA_TX && defined USB_RAM_START
                    ptrUsbQueue->USB_queue.chars -= tx_queue->usCompleteMessage;
    #ifdef WAKE_BLOCKED_USB_TX
                    fnWakeBlockedTx(ptrUsbQueue, ptrUsbQueue->endpoint_control->low_water_level); // we have just reduced buffer content so inform waiting transmitter task
    #endif
                    ptrUsbQueue->USB_queue.get += tx_queue->usCompleteMessage; // set get pointer to end of outstanding block
                    tx_queue->usCompleteMessage = 0;
                    tx_queue->usSent = 0;
                    if (ptrUsbQueue->USB_queue.get >= ptrUsbQueue->USB_queue.buffer_end) { // handle circular buffer
                        ptrUsbQueue->USB_queue.get -= ptrUsbQueue->USB_queue.buf_length;
                    }
                    if (ptrUsbQueue->USB_queue.chars == 0) {         // no more data queued
                        ptrUsbQueue->endpoint_control->ucState &= ~TX_ACTIVE;// mark that the transmitter is idle
                    }
                    else {
                        fnPrepareUSBOutData(ptrUsbQueue, ptrUsbQueue->USB_queue.chars, iEndpoint, ptrUSB_HW);
                    }
#else
                    unsigned short usNonAcknowledged;
                    ptrUsbQueue->USB_queue.chars -= fnPullLastLength(ptrUsbQueue->endpoint_control); // the acknowledged data (there may be still open buffers)
                    usNonAcknowledged = fnOutstandingData(ptrUsbQueue->endpoint_control);
                    if (ptrUsbQueue->USB_queue.chars == usNonAcknowledged) { // no further data waiting in the output buffer which has not already been placed in the output FIFO buffers
                        if (ptrUsbQueue->USB_queue.chars == 0) {         // no more data queued
                            if (fnControlEndpoint(iEndpoint, (USB_CONTROL_ENDPOINT | USB_ENDPOINT_TERMINATES))) { // {9}{11} if the endpoint is a control end point send zero data on termination if last frame was the same length as the endpoint
                                if ((tx_queue->usCompleteMessage % tx_queue->usMax_frame_length) == 0) {
                                    FNSEND_ZERO_DATA(ptrUSB_HW, iEndpoint); // send a zero frame to terminate status stage
    #ifdef MJB_WAIT_UNTIL_ALL_BUFFERS_SENT
                                    usNonAcknowledged = 1;               // ensure that the transmitter state is not deactivated yet
    #endif
                                }
                            }
                            ptrUsbQueue->USB_queue.get += tx_queue->usCompleteMessage; // set get pointer to end of outstanding block
                            if (ptrUsbQueue->USB_queue.get >= ptrUsbQueue->USB_queue.buffer_end) { // handle circular buffer
                                ptrUsbQueue->USB_queue.get -= ptrUsbQueue->USB_queue.buf_length;
                            }
                            tx_queue->usCompleteMessage = 0;             // no more processing required
    #ifdef MJB_WAIT_UNTIL_ALL_BUFFERS_SENT
                            if (usNonAcknowledged == 0) {
                                ptrUsbQueue->endpoint_control->ucState &= ~TX_ACTIVE;// mark that the transmitter is idle
                            }
    #else
                            ptrUsbQueue->endpoint_control->ucState &= ~TX_ACTIVE;// mark that the transmitter is idle
    #endif
                        }
                        else {                                           // wait for final buffer acknowledgement(s) - nothing to do otherwise
                        }
                    }
                    else {                                               // there is follow-on data waiting in the buffer so start this now
                        unsigned short usLength;
                        ptrUsbQueue->USB_queue.get += tx_queue->usCompleteMessage; // set get pointer to end of outstanding block
                        if (ptrUsbQueue->USB_queue.get >= ptrUsbQueue->USB_queue.buffer_end) { // handle circular buffer
                            ptrUsbQueue->USB_queue.get -= ptrUsbQueue->USB_queue.buf_length;
                        }
                        usLength = (ptrUsbQueue->USB_queue.buffer_end - ptrUsbQueue->USB_queue.get); // linear buffer remaining (maximum linear block size possible)
                        if ((ptrUsbQueue->USB_queue.chars - usNonAcknowledged) < usLength) {   // if there are less additional characters waiting reduce
                            usLength = (ptrUsbQueue->USB_queue.chars - usNonAcknowledged); // next block length required
                        }
                        tx_queue->usCompleteMessage = 0;                 // reset old block length so that the new one will be accepted
                        fnPrepareOutData(ptrUsbQueue->USB_queue.get, usLength, usLength, iEndpoint, ptrUSB_HW); // prepare next buffer(s)
                    }
    #ifdef WAKE_BLOCKED_USB_TX
                    fnWakeBlockedTx(ptrUsbQueue, ptrUsbQueue->endpoint_control->low_water_level); // we have just emptied buffer content so inform waiting transmitter task
    #endif
#endif
                }
                else {
                    if ((tx_queue->usCompleteMessage % tx_queue->usMax_frame_length) == 0) {
                        if ((tx_queue->usLimitLength != tx_queue->usCompleteMessage) || (!fnControlEndpoint(iEndpoint, USB_CONTROL_ENDPOINT))) {
                            FNSEND_ZERO_DATA(ptrUSB_HW, iEndpoint);      // send a zero frame to terminate status stage
                        }
                    }
                    tx_queue->usCompleteMessage = 0;
                }
            }
            else {                                                       // part of a linear block
                unsigned short usDataLength;
                unsigned short usRemaining = (tx_queue->usCompleteMessage - tx_queue->usSent);
                if (usRemaining < tx_queue->usMax_frame_length) {
                    usDataLength = usRemaining;                          // limit packet length
                }
                else {
                    usDataLength = tx_queue->usMax_frame_length;
                }
                if (ptrUsbQueue != 0) {
                    unsigned short usLastLength = fnPullLastLength(ptrUsbQueue->endpoint_control); // the amount of data being acknowledged
                    ptrUsbQueue->USB_queue.chars -= usLastLength;        // make space for fresh data to be queued
    #ifdef WAKE_BLOCKED_USB_TX
                    fnWakeBlockedTx(ptrUsbQueue, ptrUsbQueue->endpoint_control->low_water_level); // we have just emptied buffer content so inform waiting transmitter task
    #endif
                }
                FNSEND_USB_DATA((tx_queue->ptrStart + tx_queue->usSent), usDataLength, iEndpoint, ptrUSB_HW); // transmit next buffer
                fnPushLastLength(ptrUsbQueue, usDataLength);             // save last length for use later
                tx_queue->usSent += usDataLength;
            }
        }
        break;

    case USB_SETUP_FRAME:                                                // a setup token has been received (usually during enumeration - always end point 0)
        {
            unsigned char ucFirstByte = GET_USB_DATA();
            unsigned char ucRequest;                                     // {1}
            usb_endpoint_control->usCompleteMessage = 0;                 // a setup frame will cancel any existing transmissions so ensure the count is reset
            SET_CONTROL_DIRECTION(ptrUSB_HW, ucFirstByte);               // {2} prepare the direction of endpoint response
            switch ((ucFirstByte & ~STANDARD_DEVICE_TO_HOST)) {          // set up packet recipient and type, masking the direction
            case REQUEST_DEVICE_STANDARD:                                // 0x00 - bmRequestType.Recipient == Device, bmRequestType.Type == Standard
                ucRequest = GET_USB_DATA();                              // {1}
                switch (ucRequest) {                                     // bRequest
                case USB_REQUEST_GET_DESCRIPTOR:                         // 0x06
                    {
                        unsigned short wLength;
                        unsigned short wIndex;
                        unsigned short wValue = GET_USB_DATA();          // get descriptor type in little-endian format
                        wValue |= (GET_USB_DATA() << 8);
                        wIndex  = GET_USB_DATA();                        // language-ID
                        wIndex |= (GET_USB_DATA() << 8);
                        wLength = GET_USB_DATA();
                        wLength |= (GET_USB_DATA_NO_INC() << 8);         // the length that the host can accept
                        CLEAR_SETUP(ptrUSB_HW);                          // {2}
                        switch (wValue & 0xff00) {
                        case STANDARD_DEVICE_DESCRIPTOR:                 // 0x01xx
                            {
                                unsigned char *ptrDecr;
                                unsigned short usLength;
                                ptrDecr = fnGetUSB_device_descriptor(&usLength); // the application must return the configuration descriptor
                                fnPrepareOutData(ptrDecr, usLength, wLength, 0, ptrUSB_HW);
                            }
                            break;

                        case STANDARD_CONFIG_DESCRIPTOR:                 // 0x02xx
                            {
                                unsigned char *ptrDecr;
                                unsigned short usLength;
                                ptrDecr = fnGetUSB_config_descriptor(&usLength); // the application must return the configuration descriptor
                                fnPrepareOutData(ptrDecr, usLength, wLength, 0, ptrUSB_HW);
                            }
                            break;

                        case STANDARD_STRING_DESCRIPTOR:                 // 0x03xx optional
                            {
            #ifdef USB_STRING_OPTION
                                unsigned short usLength;
                                unsigned char *ptrStart;
                                wValue &= 0x00ff;                        // take the index
                                ptrStart = fnGetUSB_string_entry(wValue, &usLength); // get the corresponding string
                                if (ptrStart == 0) {                     // check for invalid string index receptions
                                    return STALL_ENDPOINT;               // stall endpoint - this happens, for example, when the String Microsoft OS string is requested
                                }
                                fnPrepareOutData(ptrStart, usLength, wLength, 0, ptrUSB_HW);
            #else
                                return STALL_ENDPOINT;                   // no string support, stall endpoint
            #endif
                            }
                            break;
                        case DEVICE_QUALIFIER_DESCRIPTOR:                // 0x06xx we presently support USB2.0 devices which can only operate at full speed so the answer is fixed
                            {
                                static const USB_DEVICE_QUALIFIER_DESCRIPTOR qualifier_descriptor = {
                                    DEVICE_QUALIFIER_DESCRIPTOR_LENGTH,  // device qualifier descriptor length (0x0a)
                                    DESCRIPTOR_DEVICE_QUALIFIER,
                                    {LITTLE_SHORT_WORD_BYTES(USB_SPEC_VERSION_2_0)}, // always USB2.0
                                    DEVICE_CLASS_AT_INTERFACE,           // device class, sub-class and protocol
                                    64,                                  // size of endpoint reception buffer - must be 64
                                    NUMBER_OF_POSSIBLE_CONFIGURATIONS,   // number of configurations possible
                                    0
                                };
                                fnPrepareOutData((unsigned char *)&qualifier_descriptor, sizeof(qualifier_descriptor), wLength, 0, ptrUSB_HW);
                            }
                            break;
                        default:
                            if (!(usb_endpoint_control->usb_callback)) {
                                return STALL_ENDPOINT;                   // stall on any unknown requests if no application support
                            }
            #ifdef USB_FIFO                                              // {1}
                            ptrData = fnReadUSB_FIFO(ptrData, 2, 6);     // extract remaining data from FIFO input
                            *ptrData++ = ucFirstByte;                    // add the read bytes to the intermediate buffer
                            *ptrData++ = (unsigned char)wValue;
                            *ptrData++ = (unsigned char)(wValue >> 8);
                            *ptrData++ = (unsigned char)wIndex;
                            *ptrData++ = (unsigned char)(wIndex >> 8);
                            *ptrData++ = (unsigned char)wLength;
                            *ptrData++ = (unsigned char)(wLength >> 8);
            #endif
                            CLEAR_SETUP(ptrUSB_HW);                      // {2}
                            return (usb_endpoint_control->usb_callback((ptrData - 6), ptrUSB_HW->usLength, SETUP_DATA_RECEPTION)); // allow the USB application to handle any non-standard (or non-supported) requests
                        }
                    }
                    break;

                case USB_REQUEST_SET_ADDRESS:                            // 0x05 - we are receiving an address to use
                    ptrUSB_HW->ucUSBAddress = GET_USB_DATA_NO_INC();     // this is the address which we will commit once the status stage has successfully terminated
                    CLEAR_SETUP(ptrUSB_HW);                              // {2}
                    return TERMINATE_ZERO_DATA;

                case USB_REQUEST_SET_CONFIGURATION:                      // 0x09 - activate a configuration
                    ucActiveConfiguration = GET_USB_DATA_NO_INC();       // save the active configuration
                    if (fnSetUSBConfigState(USB_CONFIG_ACTIVATE, ucActiveConfiguration) != 0) {
                        ucActiveConfiguration = 0;
                        return STALL_ENDPOINT;                           // invalid configuration so stall
                    }
                    VALIDATE_NEW_CONFIGURATION();                        // {16}
                    fnUSB_message(E_USB_ACTIVATE_CONFIGURATION, ptrData, 1, usb_endpoint_control->event_task); // inform the task of successful activation of this configuration
                    CLEAR_SETUP(ptrUSB_HW);                              // {2}
                    return TERMINATE_ZERO_DATA;

                case USB_REQUEST_GET_CONFIGURATION:                      // 0x08 - answer with presently active configuration
                    CLEAR_SETUP(ptrUSB_HW);                              // {4}
                    fnPrepareOutData(&ucActiveConfiguration, sizeof(ucActiveConfiguration), sizeof(ucActiveConfiguration), 0, ptrUSB_HW);
                    break;

                case USB_REQUEST_GET_STATUS:                             // 0x00
                    CLEAR_SETUP(ptrUSB_HW);                              // {4}
                    fnPrepareOutData((unsigned char *)&usDeviceStatus, sizeof(usDeviceStatus), sizeof(usDeviceStatus), 0, ptrUSB_HW);
                    break;

              //case USB_REQUEST_CLEAR_FEATURE:                          // 0x01 - not supported
              //case USB_REQUEST_SET_FEATURE:                            // 0x03
              //case USB_REQUEST_SET_DESCRIPTOR:                         // 0x07
              //case USB_REQUEST_SYNCH_FRAME:                            // 0x0c
                default:
                    if (!(usb_endpoint_control->usb_callback)) {
                        return STALL_ENDPOINT;                           // stall on any unknown requests if no application support
                    }
            #ifdef USB_FIFO                                              // {1}
                    ptrData = fnReadUSB_FIFO(ptrData, 6, 2);             // extract remaining data from FIFO input
                    *ptrData++ = ucFirstByte;                            // add the read bytes to the intermediate buffer
                    *ptrData++ = ucRequest;
            #endif
                    CLEAR_SETUP(ptrUSB_HW);                              // {2}
                    return (usb_endpoint_control->usb_callback((ptrData - 2), ptrUSB_HW->usLength, SETUP_DATA_RECEPTION)); // allow the USB application to handle any non-standard (or non-supported) requests
                }
                break;

            case REQUEST_INTERFACE_STANDARD:                             // 0x01 - bmRequestType.Recipient == Interface, bmRequestType.Type == Standard
                ucRequest = GET_USB_DATA();                              // {1}
                switch (ucRequest) {                                     // bRequest
                case USB_REQUEST_SET_INTERFACE:                          // 0x0b - set an alternative interface
                    if (ucActiveConfiguration == 0) {
                        return STALL_ENDPOINT;                           // stall if not configured
                    }
                    else {
                        unsigned short usReferences[2];
                        fnExtract(ptrData, (INDEX_INDEX | VALUE_INDEX), usReferences); // extract the interface and alternative interface from the request
                        fnSetUSBInterfaceState(USB_INTERFACE_DEACTIVATE, (unsigned char)usReferences[1], 0xff); // deactivate all endpoints on this interface
                        if (fnSetUSBInterfaceState(USB_INTERFACE_ACTIVATE, (unsigned char)usReferences[1], (unsigned char)usReferences[0]) != 0) { // activate this alternative interface, adjusting endpoint sizes where needed
                            return STALL_ENDPOINT;                           // stall if alternative interface not valid
                        }
                    }
                    CLEAR_SETUP(ptrUSB_HW);                              // {4}
                    return TERMINATE_ZERO_DATA;

                case USB_REQUEST_GET_INTERFACE:                          // 0x0a - request alternative interface
                    if (ucActiveConfiguration == 0) {
                        return STALL_ENDPOINT;                           // stall if not configured
                    }
                    else {
                        unsigned short alternative_interface;
                        const USB_INTERFACE_DESCRIPTOR *interface_descriptor;
                        fnExtract(ptrData, (INDEX_INDEX), &alternative_interface); // extract the interface and alternative interface from the request
                        interface_descriptor = (const USB_INTERFACE_DESCRIPTOR *)fnSetUSBInterfaceState(USB_INTERFACE_ALTERNATE, (unsigned char)alternative_interface, 0); // get alternative interface
                        if (interface_descriptor == 0) {
                            return STALL_ENDPOINT;                       // stall if interface is not valid
                        }
                        CLEAR_SETUP(ptrUSB_HW);                          // {4}
                        fnPrepareOutData((unsigned char *)&interface_descriptor->bAlternateSetting, 1, 1, 0, ptrUSB_HW);
                    }
                    break;

                case USB_REQUEST_GET_STATUS:                             // 0x00 - get status of interface
                    if (ucActiveConfiguration == 0) {                    // only allowed when configured
                        return STALL_ENDPOINT;
                    }
                    CLEAR_SETUP(ptrUSB_HW);                              // {4}
                    fnPrepareOutData((unsigned char *)&usInterfaceStatus, sizeof(usInterfaceStatus), sizeof(usInterfaceStatus), 0, ptrUSB_HW);
                    break;

                default:
                    if (!(usb_endpoint_control->usb_callback)) {
                        return STALL_ENDPOINT;                           // stall on any unknown requests if no applicatin support
                    }
            #ifdef USB_FIFO                                              // {1}
                    ptrData = fnReadUSB_FIFO(ptrData, 6, 2);             // extract remaining data from FIFO input
                    *ptrData++ = ucFirstByte;                            // add the read bytes to the intermediate buffer
                    *ptrData++ = ucRequest;
            #endif
                    CLEAR_SETUP(ptrUSB_HW);                              // {2}
                    return (usb_endpoint_control->usb_callback((ptrData - 2), ptrUSB_HW->usLength, SETUP_DATA_RECEPTION)); // allow the USB application to handle any non-standard (or non-supported) requests
                }
                break;

            case REQUEST_ENDPOINT_STANDARD:                              // 0x02
                ucRequest = GET_USB_DATA();                              // {1}
                switch (ucRequest) {                                     // bRequest
                case USB_REQUEST_CLEAR_FEATURE:                          // {13}                    
                case USB_REQUEST_GET_STATUS:                             // 0x00 - get status of endpoint
                    {
                        USB_ENDPOINT *tx_queue = usb_endpoint_control;
                        unsigned short usEndpoint;
                        fnExtract(ptrData, (INDEX_INDEX), &usEndpoint);  // extract the endpoint from the request details
                        if ((ucActiveConfiguration == 0) && (usEndpoint != 0)) {// only endpoint 0 allowed when not configured
                            return STALL_ENDPOINT;
                        }
                        tx_queue += (usEndpoint & 0x1f);                 // {13}
                        CLEAR_SETUP(ptrUSB_HW);                          // {4}
                        if (ucRequest == USB_REQUEST_CLEAR_FEATURE) {    // {13}
                            if (tx_queue->ucState & USB_ENDPOINT_STALLED) {
                                tx_queue->ucState &= ~USB_ENDPOINT_STALLED;
                                if ((usb_endpoint_control->usb_callback) != 0) {
                                    unsigned char ucEndpoint = (unsigned char)usEndpoint;
                                    fnUnhaltEndpoint(ucEndpoint);        // clear the stall state in the hardware
                                    return (usb_endpoint_control->usb_callback(&ucEndpoint, 0, ENDPOINT_CLEARED));// inform that the endpoint has been freed
                                }                                
                            }
                            break;
                        }
                        if (tx_queue->ucState & USB_ENDPOINT_STALLED) {
                            fnPrepareOutData((unsigned char *)&usEndpointStalled, sizeof(usEndpointStalled), sizeof(usEndpointStalled), 0, ptrUSB_HW);
                        }
                        else {
                            fnPrepareOutData((unsigned char *)&usEndpointOK, sizeof(usEndpointOK), sizeof(usEndpointOK), 0, ptrUSB_HW);
                        }
                    }
                    break;              
                default:
                    if (!(usb_endpoint_control->usb_callback)) {
                        return STALL_ENDPOINT;                           // stall on any unknown requests if no application support
                    }
            #ifdef USB_FIFO                                              // {1}
                    ptrData = fnReadUSB_FIFO(ptrData, 6, 2);             // extract remaining data from FIFO input
                    *ptrData++ = ucFirstByte;                            // add the read bytes to the intermediate buffer
                    *ptrData++ = ucRequest;
            #endif
                    CLEAR_SETUP(ptrUSB_HW);                              // {2}
                    return (usb_endpoint_control->usb_callback((ptrData - 2), 8, ENDPOINT_REQUEST_TYPE)); // allow the USB application to handle any non-standard (or non-supported) requests
                }
                break;
            default:                                                     // let the application call back handle any class specific requests
                if (!(usb_endpoint_control->usb_callback)) {
                    return STALL_ENDPOINT;                               // stall on any unknown requests if no application support
                }
            #ifdef USB_FIFO                                              // {1}
                ptrData = fnReadUSB_FIFO(ptrData, 7, 1);                 // extract remaining data from FIFO input
                *ptrData++ = ucFirstByte;                                // add the first byte to the intermediate buffer
            #endif
                CLEAR_SETUP(ptrUSB_HW);                                  // {2}
                return (usb_endpoint_control->usb_callback((ptrData - 1), ptrUSB_HW->usLength, SETUP_DATA_RECEPTION)); // allow the USB application to handle any non-standard (or non-supported) requests
            }
        }
        break;

    case USB_CONTROL_OUT_FRAME:
        if (ptrUSB_HW->usLength == 0) {                                  // a zero data packet status
            return (fnEndpointData(iEndpoint, ptrData, 0, STATUS_STAGE_RECEPTION));
        }
        // fall through
    case USB_OUT_FRAME:
        return (fnEndpointData(iEndpoint, ptrData, ptrUSB_HW->usLength, OUT_DATA_RECEPTION));

    case USB_RESET_DETECTED:                                             // USB bus reset detected
        if (ptrUSB_HW->ucUSBAddress != 0) {                              // if we are past the address definition phase
            fnInterruptMessage(usb_endpoint_control->event_task, EVENT_USB_RESET); // inform of the occurrence
        }
        fnSetUSBConfigState(USB_CONFIG_ACTIVATE, 0);                     // set zero configuration to deactivate all endpoint control structures
        _SIM_USB(USB_SIM_RESET, 0, 0);                                   // simulate reset
        break;

    case USB_SUSPEND_DETECTED:
        fnInterruptMessage(usb_endpoint_control->event_task, EVENT_USB_SUSPEND); // inform of the occurrence - it is up to the application to reduce power to conform to the specification if required
        _SIM_USB(USB_SIM_SUSPEND, 0, 0);                                 // simulate reset
        break;
    case USB_RESUME_DETECTED:
        fnInterruptMessage(usb_endpoint_control->event_task, EVENT_USB_RESUME); // inform of the occurrence - the application can adjust power consumption accordingly
        break;
    case USB_DATA_REPEAT:                                                // a repeated data reception occurs only when our ACK has been lost. This should be extremely rare.
        break;                                                           // we do nothing, except free the buffer - it could be counted if required
#ifdef USB_HOST_SUPPORT
    case USB_DEVICE_DETECTED:                                            // device has been connected to the USB bus (non-zero iEndpoint indicates full speed rather than low speed), reset has been completed and SOFs are being sent
        {
            static const USB_HOST_DESCRIPTOR get_device_descriptor = {
                (STANDARD_DEVICE_TO_HOST),                               // 0x80 - recipient device, type standard, device-to-host
                USB_REQUEST_GET_DESCRIPTOR,
                {LITTLE_SHORT_WORD_BYTES(STANDARD_DEVICE_DESCRIPTOR)},
                {LITTLE_SHORT_WORD_BYTES(0)},
                {LITTLE_SHORT_WORD_BYTES(ENDPOINT_0_SIZE)}               // size of endpoint 0 reception buffer
            };
            fnPrepareOutData((unsigned char *)&get_device_descriptor, sizeof(get_device_descriptor), 8, 0, ptrUSB_HW);
            return SEND_SETUP;
        }
        break;
#endif
    }
    return BUFFER_CONSUMED;
}


// This is the generic OUT data handler
//
extern int fnEndpointData(int iEndpoint, unsigned char *ptrData, unsigned short usLength, int iControl)
{
    USB_ENDPOINT *usb_endpoint_queue = usb_endpoint_control;
    USBQUE *ptrQueue;
    usb_endpoint_queue += iEndpoint;
    if (usb_endpoint_queue->usb_callback != 0) {                         // if there is a callback defined to handle this endpoint
        int iReturn;                                                     // {12} 
    #ifdef USB_FIFO                                                      // {1}
        ptrData = fnReadUSB_FIFO(ptrData, usLength, 0);                  // extract data from FIFO input to an intermediate working buffer
    #endif       
        iReturn = usb_endpoint_queue->usb_callback(ptrData, usLength, iControl); // call the callback
        if (iReturn != TRANSPARENT_CALLBACK) {                           // {12} allow use of buffered into if the callback doesn't want to handle the processing
            return iReturn;
        }
    }
    if (usb_endpoint_queue->ptrEndpointOutCtr == 0) {
        return BUFFER_CONSUMED;                                          // neither a call back nor a buffer available - data ignored
    }
    if (usb_endpoint_queue->event_task != 0) {
        uTaskerStateChange(usb_endpoint_queue->event_task, UTASKER_ACTIVATE); // wake task monitoring this endpoint
    }
    ptrQueue = (USBQUE *)usb_endpoint_queue->ptrEndpointOutCtr;
    #if defined USB_FIFO                                                 // {18}
    if (usb_endpoint_queue->usb_callback != 0) {                         // {12} the FIFO has already been extracted
        fnFillBuf(&ptrQueue->USB_queue, ptrData, (QUEUE_TRANSFER)usLength); // unconditionally copy to input buffer since there will be space to accept it
        if ((ptrQueue->USB_queue.buf_length - ptrQueue->USB_queue.chars) < usb_endpoint_queue->usMax_frame_length) { // {18} check whether there is space to receive maximum following data
            usb_endpoint_queue->ucState |= USB_ENDPOINT_BLOCKED;         // mark that this FIFO endpoint is critically full and needs to be stopped
            return CRITICAL_OUT;                                         // inform that the input queue content is critical and no further data should be accepted at the moment
        }
    }
    else {
        if (usb_endpoint_queue->ucState & USB_ENDPOINT_BLOCKED) {
            return MAINTAIN_OWNERSHIP;                                   // the input buffer is presently blocked so maintain the USB buffer until it is freed by the application
        }
        if ((ptrQueue->USB_queue.buf_length - ptrQueue->USB_queue.chars) >= usLength) { // is there enough space to put this data packet in to the input buffer?
            fnFillBuf_FIFO(&ptrQueue->USB_queue, ptrData, (QUEUE_TRANSFER)usLength); // copy to input buffer, bypassing the intermediate memory
        }
        else {
            usb_endpoint_queue->ucState |= USB_ENDPOINT_BLOCKED;         // mark that this endpoint is presently blocked
            return MAINTAIN_OWNERSHIP;                                   // this buffer could not be freed so keep it until it is cleared
        }
    }
    #elif defined USB_FIFO_INTERMEDIATE_BUFFER                           // {19}
    if (usb_endpoint_queue->usb_callback != 0) {                         // the FIFO has already been extracted
        fnFillBuf(&ptrQueue->USB_queue, ptrData, (QUEUE_TRANSFER)usLength); // unconditionally copy to input buffer since there will be space to accept it
        if ((ptrQueue->USB_queue.buf_length - ptrQueue->USB_queue.chars) < usb_endpoint_queue->usMax_frame_length) { // check whether there is space to receive maximum following data
            usb_endpoint_queue->ucState |= USB_ENDPOINT_BLOCKED;         // mark that this FIFO endpoint is critically full and needs to be stopped
            return CRITICAL_OUT;                                         // inform that the input queue content is critical and no further data should be accepted at the moment
        }
    }
    else {
        if ((ptrQueue->USB_queue.buf_length - ptrQueue->USB_queue.chars) >= usLength) { // is there enough space to put this data packet in to the input buffer?
            fnFillBuf(&ptrQueue->USB_queue, ptrData, (QUEUE_TRANSFER)usLength); // copy to input buffer
        }
        else {
            usb_endpoint_queue->ucState |= USB_ENDPOINT_BLOCKED;         // mark that this endpoint is presently blocked
            return MAINTAIN_OWNERSHIP;                                   // this buffer could not be freed so keep it until it is cleared
        }
    }
    #else
    if (usb_endpoint_queue->ucState & USB_ENDPOINT_BLOCKED) {
        return MAINTAIN_OWNERSHIP;                                       // the input buffer is presently blocked so maintain the USB buffer until it is freed by the application
    }
    if ((ptrQueue->USB_queue.buf_length - ptrQueue->USB_queue.chars) >= usLength) { // is there enough space to put this data packet in to the input buffer?
        fnFillBuf(&ptrQueue->USB_queue, ptrData, (QUEUE_TRANSFER)usLength); // copy to input buffer
    }
    else {
        usb_endpoint_queue->ucState |= USB_ENDPOINT_BLOCKED;             // mark that this endpoint is presently blocked
        return MAINTAIN_OWNERSHIP;                                       // this buffer could not be freed so keep it until it is cleared
    }
    #endif
    return BUFFER_CONSUMED;                                              // OK - data consumed so free buffer for more
}

// Called to activated an endpoint, calling the hardware activation after setting endpoint variables
//
static void fnActivateEndpoint(const USB_ENDPOINT_DESCRIPTOR *ptrEndpointDesc, unsigned short usMaxLength)
{
    unsigned short usEndpointLength = ptrEndpointDesc->wMaxPacketSize[0];
    unsigned char ucEndpointRef = (ptrEndpointDesc->bEndpointAddress & 0x7f);
    unsigned char ucEndpointType = (ptrEndpointDesc->bmAttributes | (ptrEndpointDesc->bEndpointAddress & IN_ENDPOINT));
    USB_ENDPOINT *usb_endpoint_queue = (usb_endpoint_control + ucEndpointRef);
    usEndpointLength |= (ptrEndpointDesc->wMaxPacketSize[1] << 8);
    fnActivateHWEndpoint(ucEndpointType, ucEndpointRef, usEndpointLength, usMaxLength);// activate the hardware based on the details
    if (ptrEndpointDesc->bmAttributes == ENDPOINT_CONTROL) {
        usb_endpoint_queue->ucState = (USB_ENDPOINT_ACTIVE | USB_CONTROL_ENDPOINT);
    }
    else {
        usb_endpoint_queue->ucState = (USB_ENDPOINT_ACTIVE | usb_endpoint_queue->ucParameters); // {11} set active state plus any extra parameters
    }
}

// Called to deactivate an endpoint, calling hardware deactivation as well as resetting variables and flushing queues
//
static void fnDeactivateEndpoint(const USB_ENDPOINT_DESCRIPTOR *ptrEndpointDesc)
{
    unsigned char ucEndpointRef = (ptrEndpointDesc->bEndpointAddress & 0x7f);
    USB_ENDPOINT *usb_endpoint_queue = (usb_endpoint_control + ucEndpointRef);
    USBQUE *ptrUsbQueue = (USBQUE *)(usb_endpoint_queue->ptrEndpointInCtr);
    fnActivateHWEndpoint(ENDPOINT_DISABLE, ucEndpointRef, 0, 0);         // deactivate the hardware
    usb_endpoint_queue->ucState = 0;                                     // return to addressed state
    usb_endpoint_queue->usCompleteMessage = 0;                           // stop any transmission
    usb_endpoint_queue->ucFIFO_depth = 0;                                // {7}
    if (ptrUsbQueue != 0) {                                              // flush any input queue
        ptrUsbQueue->USB_queue.chars = 0;
        ptrUsbQueue->USB_queue.get = ptrUsbQueue->USB_queue.put = ptrUsbQueue->USB_queue.QUEbuffer;
    }
    ptrUsbQueue = (USBQUE *)(usb_endpoint_queue->ptrEndpointOutCtr);
    if (ptrUsbQueue != 0) {                                              // flush any output queue
        ptrUsbQueue->USB_queue.chars = 0;
        ptrUsbQueue->USB_queue.get = ptrUsbQueue->USB_queue.put = ptrUsbQueue->USB_queue.QUEbuffer;
    }
}

// Routine for building a temporary queue of endpoints and their required buffer characteristics
//
static void fnAdd_to_EndpointList(USB_ENDPOINT_DESCRIPTOR_ENTRIES *ptrEndpoints, const USB_ENDPOINT_DESCRIPTOR *ptrEndpointdesc, int iAdd)
{
    while (ptrEndpoints->ptrActiveEndpoint != 0) {                       // search through present list
        if ((ptrEndpointdesc->bEndpointAddress & 0x7f) == (ptrEndpoints->ptrActiveEndpoint->bEndpointAddress & 0x7f)) { // entry alread present
            if (!iAdd) {
                unsigned short usMaxLength = ptrEndpoints->ptrActiveEndpoint->wMaxPacketSize[0];
                usMaxLength |= (ptrEndpoints->ptrActiveEndpoint->wMaxPacketSize[1] << 8);
                if (usMaxLength > ptrEndpoints->usMaxEndpointLength) {
                     ptrEndpoints->usMaxEndpointLength = usMaxLength;    // enter maximum length on this endpoint
                }
            }
            return;                                                      // entry already exists so complete
        }
        ptrEndpoints++;
    }
    if (iAdd != 0) {                                                     // new entry to be added
        ptrEndpoints->ptrActiveEndpoint = ptrEndpointdesc;
    }
}

// Collect endpoint information based on the configuration descriptor, configuration, interface and alternative interface
//
static void *fnConfigInformation(unsigned char ucConfig, unsigned char ucInterface, unsigned char ucAlternativeInterface, USB_ENDPOINT_DESCRIPTOR_ENTRIES *ptrEndpoints)
{
    int iConfigNotFound = 1;
    int iConfigValid = 0;
    unsigned short usLength;
    unsigned char *ptrDesc = (unsigned char *)fnGetUSB_config_descriptor(&usLength); // request the configuration descriptor and activate all endpoints belonging to the configuration
    unsigned char ucThisLength;                                          // the individual descriptor length

    do {
        ucThisLength = *ptrDesc;                                         // length of this descriptor
        usLength -= ucThisLength;                                        // remove from total length
        switch (*(ptrDesc+1)) {                                          // the descriptor type
        case DESCRIPTOR_TYPE_CONFIGURATION:
            {
                USB_CONFIGURATION_DESCRIPTOR *config_desc = (USB_CONFIGURATION_DESCRIPTOR *)ptrDesc;
                if ((!ucConfig) | (config_desc->bConfigurationValue == ucConfig)) {
                    iConfigValid = 1;                                    // this configuration should be counted
                    iConfigNotFound = 0;                                 // the searched configuration has been found
                }
                else {
                    iConfigValid = 0;                                    // this configuration should not be counted
                }
            }
            break;
        case DESCRIPTOR_TYPE_INTERFACE:
            {
                if (iConfigValid != 0) {
                    USB_INTERFACE_DESCRIPTOR *interface_descriptor = (USB_INTERFACE_DESCRIPTOR *)ptrDesc;
                    if ((ucInterface == 0xff) || (interface_descriptor->bInterfaceNumber == ucInterface)) { // interface match
                        if ((ucAlternativeInterface == 0xff) || (interface_descriptor->bAlternateSetting == ucAlternativeInterface)) {
                            iConfigValid = 2;                            // endpoints belonging to this interface should be counted
                            if (ptrEndpoints == 0) {                     // request for alternative interface
                                return (interface_descriptor);           // return a pointer to the interface descriptor
                            }
                        }
                        else {
                            iConfigValid = 3;                            // endpoints belonging to this interface should not be counted but their size should be respected (for memory initialisation purposes)
                        }
                    }
                }
            }
            break;
        case DESCRIPTOR_TYPE_ENDPOINT:                                   // endpoint type
            if ((iConfigValid != 0) && (ptrEndpoints != 0)) {            // add endpoint
                fnAdd_to_EndpointList(ptrEndpoints, (USB_ENDPOINT_DESCRIPTOR *)ptrDesc, (iConfigValid == 2));
            }
            break;
        default:                                                         // ignore the content of other types
            break;
        }
        ptrDesc += ucThisLength;                                         // progress to next
    } while (usLength != 0);
    if (iConfigNotFound != 0) {
        return 0;
    }
    return (void *)ptrEndpoints;                                        // no more endpoints belonging to this configuration
}


// Change state of a specified configuration
//
extern int fnSetUSBConfigState(int iCommand, unsigned char ucConfig)
{
    int iEndpoints = 0;
    USB_ENDPOINT_DESCRIPTOR_ENTRIES EndpointList[NUMBER_OF_USB_ENDPOINTS]; // temporary list of endpoints belonging to this particular configuration
    uMemset(EndpointList, 0x00, sizeof(EndpointList));

    if (fnConfigInformation(ucConfig, 0xff, 0, EndpointList) == 0) {     // collect a list of endpoints belonging to all default interfaces of this configuration
        return 1;                                                        // not a valid configuration
    }

    while (EndpointList[iEndpoints].ptrActiveEndpoint != 0) {
        switch (iCommand) {
        case USB_CONFIG_ACTIVATE:
            if (ucConfig == 0) {
                fnDeactivateEndpoint(EndpointList[iEndpoints].ptrActiveEndpoint); // deactivate the endpoint
            }
            else {
                fnActivateEndpoint(EndpointList[iEndpoints].ptrActiveEndpoint, EndpointList[iEndpoints].usMaxEndpointLength); // configure and activate the endpoint for operation
            }
            break;

        default:                                                         // USB_DEVICE_SUSPEND / USB_DEVICE_RESUME
            {
                USB_ENDPOINT *usb_endpoint_queue = usb_endpoint_control;
                usb_endpoint_queue += (EndpointList[iEndpoints].ptrActiveEndpoint->bEndpointAddress & 0x7f);
                if (USB_DEVICE_SUSPEND == iCommand) {
                    usb_endpoint_queue->ucState |= USB_ENDPOINT_SUSPENDED;
                    usb_endpoint_queue->ucState &= ~USB_ENDPOINT_ACTIVE;
                }
                else {                                               // USB_DEVICE_RESUME
                    usb_endpoint_queue->ucState &= ~USB_ENDPOINT_SUSPENDED;
                    usb_endpoint_queue->ucState |= USB_ENDPOINT_ACTIVE;
                }
            }
            break;
        }
        iEndpoints++;
    }
    return 0;
}

// Change state of specified interface
//
static void *fnSetUSBInterfaceState(int iCommand, unsigned char ucInterface, unsigned char ucAlternativeInterface)
{
    if (USB_INTERFACE_ALTERNATE == iCommand) {
        return (fnConfigInformation(ucActiveConfiguration, ucInterface, 1, 0));
    }
    else {
        int iEndpoint = 0;
        USB_ENDPOINT_DESCRIPTOR_ENTRIES EndpointList[NUMBER_OF_USB_ENDPOINTS]; // temporary list of endpoints belonging to this particular configuration
        uMemset(EndpointList, 0x00, sizeof(EndpointList));

        switch (iCommand) {
        case USB_INTERFACE_DEACTIVATE:                                       // deactivate the specified interface
            fnConfigInformation(ucActiveConfiguration, ucInterface, 0xff, EndpointList); // get a list of endpoints belonging to this main interface and deactivate them all
            while (EndpointList[iEndpoint].ptrActiveEndpoint != 0) {
                fnDeactivateEndpoint(EndpointList[iEndpoint].ptrActiveEndpoint); // deactivate the endpoint
                iEndpoint++;
            }
            break;

        case USB_INTERFACE_ACTIVATE:                                         // activate the alternative interface
            if (fnConfigInformation(ucActiveConfiguration, ucInterface, ucAlternativeInterface, EndpointList) == 0) { // get a list of endpoints belonging to this alternative interface and activate them all
                return (void *)1;                                            // the alternative interface does not exist
            }
            while (EndpointList[iEndpoint].ptrActiveEndpoint != 0) {
                fnActivateEndpoint(EndpointList[iEndpoint].ptrActiveEndpoint, 0); // deactivate the endpoint
                iEndpoint++;
            }
            break;
        }
    }
    return 0;
}

// Called to set a new endpoint state (for example when the hardware driver needs to flag stalled state)
//
extern void fnSetUSBEndpointState(int iEndpoint, unsigned char ucStateSet)
{
    USB_ENDPOINT *usb_endpoint_queue = (usb_endpoint_control + iEndpoint);
    usb_endpoint_queue->ucState |= ucStateSet;                           // {14}
}

// Called to get the reference to the IN endpoint belonging to an IN/OUT pair
//
extern int fnGetPairedIN(int iEndpoint_OUT)                              // {16}
{
    USB_ENDPOINT *usb_endpoint_queue = usb_endpoint_control;
    usb_endpoint_queue += iEndpoint_OUT;
    return usb_endpoint_queue->ucPaired_IN;
}

#endif
