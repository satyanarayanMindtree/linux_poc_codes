/**********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        low_power.c
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2011
    *********************************************************************

    25.11.2007 Add optional low power monitoring                          {1}

*/        



//#include "config.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"


#ifdef SUPPORT_LOW_POWER

#define OWN_TASK  TASK_LOW_POWER

extern void fnLowPower(TTASKTABLE *ptrTaskTable)                         // lowpower task called on every scheduling pass
{
    if (!uNoSchedule(OWN_TASK)) {                                        // is the scheduler idle?
        MEASURE_LOW_POWER_ON();                                          // {1}
        fnDoLowPower();                                                  // switch to low power mode until woken
        MEASURE_LOW_POWER_OFF();                                         // {1}
    }
}

#endif
