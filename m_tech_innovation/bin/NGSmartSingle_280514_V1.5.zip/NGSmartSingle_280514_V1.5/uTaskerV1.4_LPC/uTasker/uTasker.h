/***********************************************************************
    Mark Butcher    Bsc (Hons) MPhil MIET

    M.J.Butcher Consulting
    Birchstrasse 20f,    CH-5406, R�tihof
    Switzerland

    www.uTasker.com    Skype: M_J_Butcher

    ---------------------------------------------------------------------
    File:        uTasker.h
    Project:     Single Chip Embedded Internet
    ---------------------------------------------------------------------
    Copyright (C) M.J.Butcher Consulting 2004..2011
    *********************************************************************

    11.05.2007 UTASK_TASK used consistently for node ids
    23.08.2007 enabled flag added to Timer table                         {1}
    10.04.2008 move fnSetHardwareTimer() to hardware.h
    30.05.2009 Add uTaskerRemainingTime()
    30.11.2010 Add CHECK_QUEUE                                           {2}
    09.02.2011 Add MONITOR_PERFORMANCE support                           {3}

*/

#ifndef __UTASKER__
#define __UTASKER__


#define SEC     ( 1000 / TICK_RESOLUTION )                               // used for sec conversions


/*********************************** uTaster states *************************************/
#define UTASKER_STOP      0x00                                           // task stopped. Waiting for event to cause it to run again.
#define UTASKER_GO        0x01                                           // task free to run. It will however only run once if it has a repetition timer set. Otherwise this
                                                                         // is equivalent to polling mode
#define UTASKER_SUSPENDED 0x02                                           // the task is suspended when its monostable timer has been stopped
#define UTASKER_ACTIVATE  0x04                                           // the task has been activated by a timer or other system event


/********************************** uTasker message queues *****************************/

#define GLOBAL_MESSAGE            0x00

#define INTERNAL_ROUTE            0

#define MSG_DESTINATION_NODE      0                                      // message header constitution
#define MSG_SOURCE_NODE           1
#define MSG_DESTINATION_TASK      2
#define MSG_SOURCE_TASK           3
#define MSG_CONTENT_LENGTH        4
#define MSG_INTERRUPT_EVENT       4
#define MSG_TIMER_EVENT           4
#define MSG_TIMER_INTERRUPT_EVENT 4
#define MSG_CONTENT_COMMAND       5
#define MSG_CONTENT_DATA_START    6

#define HEADER_LENGTH             5                                      // a message header has always this length

#define NO_QUE                    0

#define SMALL_MESSAGE            32                                      // these are a few message length defines - users can befine their own in config.h if special sizes are required
#define MEDIUM_MESSAGE           64
#define LARGE_MESSAGE           128
#define LARGER_MESSAGE          256
#define BIG_MESSAGE             512
#define BIGGER_MESSAGE         1024

#define SMALLEST_QUE  (HEADER_LENGTH + 0)                                // absolutely smallest size - use when only a timer or interrupt event can arrive
#define SMALL_QUEUE   (HEADER_LENGTH + SMALL_MESSAGE)
#define MEDIUM_QUE    (HEADER_LENGTH + MEDIUM_MESSAGE)
#define LARGE_QUE     (HEADER_LENGTH + LARGE_MESSAGE)

#define NO_DELAY_RESERVE_MONO (DELAY_LIMIT)(0 - 1)                       // zero delay but reserve a mono stable timer for the task

/********************************** uTasker timer and interrupt events *****************************/

#define TIMER_EVENT               0x00                                   // message from task 0x00 can only be timer
#define INTERRUPT_EVENT           0x01                                   // message from task 0x01 can only be interrupt
#define FUNCTION_EVENT            0x02                                   // message from task 0x02 is a function event, specifying handling by a function rather than a task
#define CHECK_QUEUE               0x03                                   // task reference used to check input queues {2}

#define TIMER_EVENT_PERIODIC      0xff                                   // timer event sent to task when periodicall scheduled (when PERIODIC_TIMER_EVENT is enabled and task has queue)
#define TIMER_EVENT_INITIAL_DELAY 0xfe                                   // timer event sent to task when scheduled for first time after a delay (when PERIODIC_TIMER_EVENT and DELAYED_TIMER_EVENT are enabled and task has queue)

/* =================================================================== */
/*                     global structure definitions                    */
/* =================================================================== */

// Define task table structure
//
typedef struct stTaskTable
{
    CHAR          *pcTaskName;                                           // name of task
    void        ( *ptrTaskEntry )( void *);                              // entry address of routine
#ifdef MONITOR_PERFORMANCE                                               // {3}
    unsigned long ulExecutions;                                          // total number of times that the task was executed
    unsigned long ulTotalExecution;                                      // total duration of task execution since last monitoring reset
    unsigned long ulMaximumExection;                                     // longest execution duration recorded
    unsigned long ulMinimumExection;                                     // shortest execution duration recorded
    unsigned long ulTimeStamp;                                           // tick time stamp of maximum execution duration detected
#endif
    QUEUE_TRANSFER QueLength;                                            // length of input que to task
    DELAY_LIMIT    TaskDelay;                                            // delay before starting or pause length ticks)
    DELAY_LIMIT    TaskRepetition;                                       // repetition time for repetitive task (ticks)
    QUEUE_HANDLE   TaskID;                                               // identity given to read from input que
    unsigned char  ucTaskState;                                          // initial / present state of task
    unsigned char  ucEvent;                                              // event to send on wake up from timer
} TTASKTABLE;



// Define task performance structure                                     {3}
//
typedef struct stUTASK_PERFORMANCE
{
    unsigned long ulTotalExecution;                                      // total duration of task execution since last monitoring reset
    unsigned long ulExecutions;                                          // number of times that the task was executed
    unsigned long ulMaximumExection;                                     // longest execution duration recorded
    unsigned long ulAverageExection;                                     // average execution duration
    unsigned long ulMinimumExection;                                     // shortest execution duration recorded
    unsigned long ulTimeStamp;                                           // tick time stamp of maximum execution duration detected
    unsigned long ulTotalTasksDuration;                                  // total system task duraction
    unsigned long ulTotalIdle;                                           // total idle duraction
} UTASK_PERFORMANCE;

// Define task table initialisation structure
//
typedef struct stTaskTableInit
{
    CHAR          *pcTaskName;                                           // name of task
    void ( *ptrTaskEntry )( TTASKTABLE * );                              // entry address of routine
    QUEUE_TRANSFER QueLength;                                            // length of input que to task
    DELAY_LIMIT    TaskDelay;                                            // delay before starting or pause length (ticks)
    DELAY_LIMIT    TaskRepetition;                                       // repetition time for repetitive task (ticks)
    unsigned char  ucTaskState;                                          // Initial / present state of task
} UTASKTABLEINIT;


// Define timer table structure
//
typedef struct stTimeTable
{
    TTASKTABLE    *ptTaskEntry;                                          // address of task table for entry
    UTASK_TICK    taskDelay;                                             // count value to be matched
    unsigned char ucEvent;                                               // event to send on wake up from timer
    unsigned char ucTimerEnabled;                                        // indicate whether timer is presently enabled {1}
} TTIMETABLE;

typedef struct stHEAP_NEEDS
{
    CONFIG_LIMIT      ConfigNr;
    HEAP_REQUIREMENTS need_this_amount;
} HEAP_NEEDS;


typedef struct stJUMP_TABLE
{
    unsigned char     ucVersion;                                         // version for table compatibility
    void             *fncPtr;                                            // list of jump functions (or others)
} JUMP_TABLE;

typedef struct stMULTISTART_TABLE
{
#ifdef DYNAMIC_MULTISTART
    unsigned char     *(*new_hw_init)(JUMP_TABLE *, void **, unsigned char);
#else
    unsigned char     *(*new_hw_init)(JUMP_TABLE *);
#endif
    HEAP_NEEDS        *ptHeapNeed;
    UTASKTABLEINIT    *ptTaskTable;
    const UTASK_TASK  *ptNodesTable;
} MULTISTART_TABLE;


extern const UTASKTABLEINIT ctTaskTable[];
extern const UTASK_TASK ctNodes[];

/* =================================================================== */
/*                 global variables/consts definitions                 */
/* =================================================================== */

extern volatile UTASK_TICK   uTaskerSystemTick;                          // global tick timer
extern const HEAP_NEEDS      ctOurHeap[];                                // constant table with list of heap requirements per configuration
extern CONFIG_LIMIT          OurConfigNr;                                // present configuration
extern NETWORK_LIMIT         OurNetworkNumber;                           // present network node number
#ifdef MULTISTART
    extern MULTISTART_TABLE *ptMultiStartTable;                          // pointer to a multi-start table
    extern JUMP_TABLE       *JumpTable;                                  // pointer to table holding jump table
#endif
#ifdef MONITOR_PERFORMANCE
    extern unsigned long ulMaximumIdle;                                  // this value contains the maximum idle duration that has occurred - setting it to 0xffffffff causes the performance monitoring to be reset after the next schedule sequence
#endif

/* =================================================================== */
/*                 global function prototype declarations              */
/* =================================================================== */

extern TASK_LIMIT uTaskerStart(const UTASKTABLEINIT *ptATaskTable, const UTASK_TASK *a_node_descriptions, const PHYSICAL_Q_LIMIT nr_physical_queues);
#ifdef MULTISTART
    extern MULTISTART_TABLE *uTaskerSchedule(void);
#else
    extern void uTaskerSchedule( void );
#endif
extern int  uNoSchedule(UTASK_TASK pcTaskName);
extern void uTaskerStateChange(UTASK_TASK pcTaskName, unsigned char ucSetState); // change the state of a task

extern void fnRtmkSystemTick(void);
extern void uTaskerMonoTimer(UTASK_TASK pcTaskName, DELAY_LIMIT delay, unsigned char time_out_nr);
extern UTASK_TICK uTaskerRemainingTime(UTASK_TASK pcTaskName);
extern void uTaskerStopTimer( UTASK_TASK pcTaskName);
extern void fnInitialiseHeap(const HEAP_NEEDS *ctOurHeap, void *HeapStart);
extern HEAP_REQUIREMENTS  fnHeapAvailable(void);
extern HEAP_REQUIREMENTS  fnHeapFree(void);
extern STACK_REQUIREMENTS fnStackFree(void);
extern HEAP_REQUIREMENTS fnPresentHeap(void);
extern TTASKTABLE *fnGetTaskPerformance(int iTaskNumber, UTASK_PERFORMANCE *ptrDetails); // {3}

extern unsigned short fnRandom(void);
extern unsigned long GetPresentHeapLocation(void);
#endif
