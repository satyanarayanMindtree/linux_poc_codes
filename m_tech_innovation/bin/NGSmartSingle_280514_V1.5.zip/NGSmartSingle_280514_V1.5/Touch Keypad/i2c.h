/*****************************************************************************
 *   i2c.h:  Header file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.19  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __I2C_H 
#define __I2C_H

#include "type.h"

// #define I2C_BUFSIZE			0x20
// #define I2C_MAX_TIMEOUT			0x00FFFFFF

// #define I2CMASTER		0x01
// #define I2CSLAVE		0x02

// /* For more info, read Philips's SE95 datasheet */
// #define LM75_ADDR		0x90
// #define LM75_TEMP		0x00
// #define LM75_CONFIG		0x01
// #define LM75_THYST		0x02
// #define LM75_TOS		0x03
// #define RD_BIT			0x01
// //#define TKEY_ADR		0x30
// //#define TKEY_ADR		0x60
// #define TKEY_ADR		0xC0

// #define I2C_IDLE			0
// #define I2C_STARTED			1
// #define I2C_RESTARTED		2
// #define I2C_REPEATED_START	3
// #define DATA_ACK			4
// #define DATA_NACK			5

// #define I2CONSET_I2EN		0x00000040  /* I2C Control Set Register */
// #define I2CONSET_AA			0x00000004
// #define I2CONSET_SI			0x00000008
// #define I2CONSET_STO		0x00000010
// #define I2CONSET_STA		0x00000020

#define I2CONCLR_AAC		0x00000004  /* I2C Control clear Register */
#define I2CONCLR_SIC		0x00000008
#define I2CONCLR_STAC		0x00000020
#define I2CONCLR_I2ENC		0x00000040

// #define I2DAT_I2C			0x00000000  /* I2C Data Reg */
// #define I2ADR_I2C			0x00000000  /* I2C Slave Address Reg */
#define I2SCLH_SCLH			0x00000100  /* I2C SCL Duty Cycle High Reg */
#define I2SCLL_SCLL			0x00000100  /* I2C SCL Duty Cycle Low Reg */
// // #define I2SCLH_SCLH			0x00000049  /* I2C SCL Duty Cycle High Reg *///for 100 kHz
// // #define I2SCLL_SCLL			0x00000049  /* I2C SCL Duty Cycle Low Reg */

// #define I2CBUFSIZE  50
// extern volatile BYTE I2CKeyData;
// extern volatile DWORD I2CCmd;

// extern void I2C0MasterHandler( void ) __irq;
// extern DWORD I2CInit( DWORD I2cMode );
// extern DWORD I2CStart( void );
// extern DWORD I2CStop( void );
// extern DWORD I2CEngine( void );

extern char I2C_Read(char addr_write,unsigned long int word_addr,char addr_read);
extern void delay(unsigned int del_ind);
extern void i2c_init(void);
extern char I2C_n_Read(char *s,unsigned long int word_addr,char bytecount,char Divece_read_add,char Divece_write_add);
//void I2C_n_Read(char *s,unsigned long int word_addr,char bytecount,char Divece_read_add,char Divece_write_add);
extern void i2c_n_write(char Device_add_write, unsigned long int word_addr, char *s, unsigned int byte_cont);
extern void i2c_write(char Device_add_write, unsigned long int word_addr, char s);
//char wait_StrtStop_ack(char status);
extern void wait_StrtStop_ack(char status);
extern char wait_ReadWrite_ack(char status, unsigned long int addr, unsigned long int slave_addr);

#define ENABLE 0x040
#define I2CSTART  0x020
#define I2CSTOP   0x10
#define SI     0x08
#define AA     0x04

#define DISABLE   0x040
#define START_CLR 0x020
#define STOP_CLR  0x10
#define SI_CLR    0x08
#define AA_CLR    0x04

#endif /* end __I2C_H */
/****************************************************************************
**                            End Of File
*****************************************************************************/
