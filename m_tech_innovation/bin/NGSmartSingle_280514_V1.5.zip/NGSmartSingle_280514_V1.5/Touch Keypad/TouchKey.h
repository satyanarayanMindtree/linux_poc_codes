//TouchKey.h

#ifndef __TOUCHKEY_H 
#define __TOUCHKEY_H

extern void Capsence_Write_Register(unsigned short int write_address, unsigned short int value);
extern int Capsence_Read_Register(unsigned long int register_addr);
extern void Capsence_Init(void);
extern char check_cap_keypad(void);


#endif
