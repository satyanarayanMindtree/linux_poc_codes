/*****************************************************************************
 *   i2c.c:  I2C C file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.19  ver 1.00    Prelimnary version, first Release
***************************************************************************** *****************************************************************************
http://code.google.com/p/32bitmicro/source/browse/trunk/src/nxp/lpc17xx/LPC17xxSampleSoftware/I2C/?r=111
**************************************************************************************************************************/
#include "LPC23xx.h"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "type.h"
#include "irq.h"

#define MTECH_I2CCODE

#ifdef SUPPORT_TOUCHKEYPAD
#include "i2c.h"

#ifndef MTECH_I2CCODE

extern volatile DWORD I2CMasterState;
volatile DWORD I2CSlaveState = I2C_IDLE;


extern volatile DWORD I2CMode;

extern volatile BYTE I2CMasterBuffer[I2C_BUFSIZE];
volatile BYTE I2CSlaveBuffer[I2C_BUFSIZE];
extern volatile DWORD I2CCount;
extern volatile DWORD I2CReadLength;
extern volatile DWORD I2CWriteLength;

volatile DWORD RdIndex = 0;
volatile DWORD WrIndex = 0;

extern BYTE I2CRxFlag;

/* 
From device to device, the I2C communication protocol may vary, 
in the example below, the protocol uses repeated start to read data from or 
write to the device:
For master read: the sequence is: STA,Addr(W),offset,RE-STA,Addr(r),data...STO 
for master write: the sequence is: STA,Addr(W),length,RE-STA,Addr(w),data...STO
Thus, in state 8, the address is always WRITE. in state 10, the address could 
be READ or WRITE depending on the I2CCmd.
*/   

/*****************************************************************************
** Function name:		I2C0MasterHandler
**
** Descriptions:		I2C0 interrupt handler, deal with master mode
**				only.
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void I2C0MasterHandler(void) __irq 
{
  BYTE StatValue;

  // this handler deals with master read and master write only
  StatValue = I20STAT;
  IENABLE;				// handles nested interrupt 
  switch ( StatValue )
  {
	case 0x60://0x60 = Own SLA+W has been received; ACK has been returned.
		I20CONCLR = I2CONCLR_SIC;	
	break;
	case 0x80://0x80 Previously addressed with own SLV address; DATA has been received; ACK has been returned.
		I2CRxFlag = 1;
		I2CKeyData = I20DAT;
		I20CONCLR = I2CONCLR_SIC;	

	break;
	case 0xa0://0xA0 A STOP condition or repeated START condition has been received while still addressed as SLV/REC or SLV/TRX.
		I20CONCLR = I2CONCLR_SIC;	
	break;


	  case 0x08:			/* A Start condition is issued. */
	I20DAT = I2CMasterBuffer[0];
	I20CONCLR = (I2CONCLR_SIC | I2CONCLR_STAC);
	I2CMasterState = I2C_STARTED;
	break;
	
	case 0x10:			//A repeated started is issued
		if ( I2CCmd == LM75_TEMP )
		{
			I20DAT = I2CMasterBuffer[2];
		}
		I20CONCLR = (I2CONCLR_SIC | I2CONCLR_STAC);
		I2CMasterState = I2C_RESTARTED;
	break;
	
	case 0x18:			// Regardless, it's a ACK 
		if ( I2CMasterState == I2C_STARTED )
		{
			I20DAT = I2CMasterBuffer[1+WrIndex];
			WrIndex++;
			I2CMasterState = DATA_ACK;
		}
		I20CONCLR = I2CONCLR_SIC;
	break;
	
	case 0x28:	//Data byte has been transmitted, regardless ACK or NACK
	case 0x30:
		if ( WrIndex != I2CWriteLength )
		{   
			I20DAT = I2CMasterBuffer[1+WrIndex]; // this should be the last one 
			WrIndex++;
			if ( WrIndex != I2CWriteLength )
			{   
				I2CMasterState = DATA_ACK;
			}
			else
			{
				I2CMasterState = DATA_NACK;
				if(( I2CReadLength == 2 ) || ( I2CReadLength == 1 ))
				{
					I20CONSET = I2CONSET_STA;	// Set Repeated-start flag 
					I2CMasterState = I2C_REPEATED_START;
				}
			}
		}
		else
		{
			if(( I2CReadLength == 2 ) || ( I2CReadLength == 1 ))
			{
			I20CONSET = I2CONSET_STA;	// Set Repeated-start flag 
			I2CMasterState = I2C_REPEATED_START;
			}
			else
			{
			I2CMasterState = DATA_NACK;
			I20CONSET = I2CONSET_STO;      // Set Stop flag 
			}
		}
		I20CONCLR = I2CONCLR_SIC;
	break;
	
	case 0x40:	// Master Receive, SLA_R has been sent 
		I20CONSET = I2CONSET_AA;	// assert ACK after data is received
		I20CONCLR = I2CONCLR_SIC;
	break;
	
	case 0x50:	// Data byte has been received, regardless following ACK or NACK 
	case 0x58:
		I2CMasterBuffer[3+RdIndex] = I20DAT;
		RdIndex++;
		if(RdIndex != I2CReadLength)
		{   
			I2CMasterState = DATA_ACK;
		}
		else
		{
			RdIndex = 0;
			I2CMasterState = DATA_NACK;
		}
		I20CONSET = I2CONSET_AA;	// assert ACK after data is received 
		I20CONCLR = I2CONCLR_SIC;
	break;
	
	case 0x20:		//regardless, it's a NACK 
	case 0x48:
		I20CONCLR = I2CONCLR_SIC;
		I2CMasterState = DATA_NACK;
	
	break;
	
	case 0x38:		/* Arbitration lost, in this example, we don't
					deal with multiple master situation */

	default:
		I20CONCLR = I2CONCLR_SIC;	
	break;
  }
  IDISABLE;
  VICVectAddr = 0;		/* Acknowledge Interrupt */
}


/*****************************************************************************
** Function name:		I2CStart
**
** Descriptions:		Create I2C start condition, a timeout
**				value is set if the I2C never gets started,
**				and timed out. It's a fatal error. 
**
** parameters:			None
** Returned value:		true or false, return false if timed out
** 
*****************************************************************************/
DWORD I2CStart( void )
{
  DWORD timeout = 0;
  DWORD retVal = FALSE;
 
  /*--- Issue a start condition ---*/
  I20CONSET = I2CONSET_STA;	/* Set Start flag */
    
  /*--- Wait until START transmitted ---*/
  while( 1 )
  {
	if ( I2CMasterState == I2C_STARTED )
	{
	  retVal = TRUE;
	  break;	
	}
	if ( timeout >= I2C_MAX_TIMEOUT )
	{
	  retVal = FALSE;
	  break;
	}
	timeout++;
  }
  return( retVal );
}

/*****************************************************************************
** Function name:		I2CStop
**
** Descriptions:		Set the I2C stop condition, if the routine
**				never exit, it's a fatal bus error.
**
** parameters:			None
** Returned value:		true or never return
** 
*****************************************************************************/
DWORD I2CStop( void )
{
  I20CONSET = I2CONSET_STO;      /* Set Stop flag */ 
  I20CONCLR = I2CONCLR_SIC;  /* Clear SI flag */ 
            
  /*--- Wait for STOP detected ---*/
  while( I20CONSET & I2CONSET_STO );
  return TRUE;
}

/*****************************************************************************
** Function name:		I2CInit
**
** Descriptions:		Initialize I2C controller
**
** parameters:			I2c mode is either MASTER or SLAVE
** Returned value:		true or false, return false if the I2C
**				interrupt handler was not installed correctly
** 
*****************************************************************************/
DWORD I2CInit( DWORD I2cMode ) 
{
  
	PCONP |= (1 << 19);
  PINSEL1 &= ~0x03C00000;
  PINSEL1 |= 0x01400000;	/* set PIO0.27 and PIO0.28 to I2C0 SDA and SCK */
							/* function to 01 on both SDA and SCK. */
  /*--- Clear flags ---*/
  I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;    

  /*--- Reset registers ---*/
  I20SCLL   = I2SCLL_SCLL;
  I20SCLH   = I2SCLH_SCLH;
  if ( I2cMode == I2CSLAVE )
  {
	I20ADR = TKEY_ADR;
  }    

  /* Install interrupt handler */	
   if ( install_irq( I2C0_INT, (void *)I2C0MasterHandler, HIGHEST_PRIORITY ) == FALSE )
   {
 	return( FALSE );
   }

  if ( I2cMode == I2CSLAVE )
  {
//  I20CONSET = I2CONSET_AA;
  I20CONSET = I2CONSET_I2EN | I2CONSET_AA;
  }
  else
  {
  I20CONSET = I2CONSET_I2EN;
  }	  
  return( TRUE );
}

/*****************************************************************************
** Function name:		I2CEngine
**
** Descriptions:		The routine to complete a I2C transaction
**				from start to stop. All the intermitten
**				steps are handled in the interrupt handler.
**				Before this routine is called, the read
**				length, write length, I2C master buffer,
**				and I2C command fields need to be filled.
**				see i2cmst.c for more details. 
**
** parameters:			None
** Returned value:		true or false, return false only if the
**				start condition can never be generated and
**				timed out. 
** 
*****************************************************************************/
DWORD I2CEngine( void ) 
{
  I2CMasterState = I2C_IDLE;
  RdIndex = 0;
  WrIndex = 0;
  if ( I2CStart() != TRUE )
  {
	I2CStop();
	return ( FALSE );
  }

  while ( 1 )
  {
	if ( I2CMasterState == DATA_NACK )
	{
	  I2CStop();
	  break;
	}
  }    
  return ( TRUE );      
}

#else 

void i2c_n_write(char Device_add_write, unsigned long int word_addr, char *s, unsigned int byte_cont)		
{
	char addrh, addrl;
	unsigned int temp;
	unsigned long int timeout = 0x2FFFF; 
	int i=0;

	temp = word_addr;
	 addrl = temp;
	 temp>>=8;
	 addrh = temp;

//	printf("ByteCount:%d\n",byte_cont);
//	delay(1000);
	I20CONSET  = ENABLE;
	delay(1000);
/*---------------------transmit a START and address with write---------------------*/
	I20CONSET = I2CSTART;
	wait_StrtStop_ack(0x08);
	I20DAT = Device_add_write;		// transmit slave address with write bit
	I20CONCLR = SI_CLR;
	I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
	wait_ReadWrite_ack(0x18,word_addr,Device_add_write);
	/*-----------------------transmit page no-----------------------------*/
	I20DAT = addrh;				// transmit page address
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x28,word_addr,Device_add_write);
//	printf("E1");
	I20DAT = addrl;				// transmit offset within the page
	I20CONCLR =  SI_CLR;
	/*-----------------------------transmit data------------------------------*/
	i = 0;
//	printf("E");
	while(byte_cont > 0)
	{
//		printf("count:%d",(int)i);
		wait_ReadWrite_ack(0x28,word_addr,Device_add_write);
//		PrintHex(s[i]);
		I20DAT = s[i];
		byte_cont--;
		i++;
		I20CONCLR = SI_CLR;
	}
	/*-------------------transmit a STOP and do acknowledge polling---------------------------------*/
	wait_ReadWrite_ack(0x28,word_addr,Device_add_write);
	I20CONCLR = SI_CLR;
	I20CONSET = I2CSTOP ;
	while(!(I20CONSET & SI))
	{
		I20CONSET = I2CSTART;			// do acknowledge polling
		delay(100);
		I20DAT = 0XA1;	
	/*	while(1)				
		{
			if(I20CONSET & SI) 
			break;
		}
	*/
		while ((!(I20CONSET & SI)) && (timeout!= 0))		   // wait till the UART1 receiver FIFO is empty.
		{
			timeout --;
		} 
	}	
	I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;
}


void i2c_write(char Device_add_write, unsigned long int word_addr, char s)		
{
	char addrh, addrl;
	unsigned int temp;
	unsigned long int timeout = 0x2FFFF; 

	temp = word_addr;
	 addrl = temp;
	 temp>>=8;
	 addrh = temp;


	I20CONSET = ENABLE;
	delay(500);
//	printf("\ndata on I2c");
//	PrintHex(s);
/*---------------------transmit a START and address with write---------------------*/
	I20CONSET = I2CSTART;
	wait_StrtStop_ack(0x08);
	I20DAT = Device_add_write;		// transmit slave address with write bit
	I20CONCLR = SI_CLR;
	I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
	wait_ReadWrite_ack(0x18,word_addr,Device_add_write);
	/*-----------------------transmit page no-----------------------------*/
	I20DAT = addrh;				// transmit page address
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x28,word_addr,Device_add_write);
	
	I20DAT = addrl;				// transmit offset within the page
	I20CONCLR =  SI_CLR;
	/*-----------------------------transmit data------------------------------*/
	wait_ReadWrite_ack(0x28,word_addr,Device_add_write);
	I20DAT = s;
	I20CONCLR = SI_CLR;
	/*-------------------transmit a STOP and do acknowledge polling---------------------------------*/
	wait_ReadWrite_ack(0x28,word_addr,Device_add_write);
	I20CONCLR = SI_CLR;
	I20CONSET = I2CSTOP ;
	while(!(I20CONSET & SI))
	{
		I20CONSET = I2CSTART;			// do acknowledge polling
		delay(50);
		I20DAT = 0XA1;	
	/*	while(1)				
		{
			if(I20CONSET & SI) 
			break;
		}
	 */
		while ((!(I20CONSET & SI)) && (timeout!= 0))		   // wait till the UART1 receiver FIFO is empty.
		{
			timeout --;
		} 
	}	
	I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;
}

//--------------  FUNCTION FOR READ A BYTE ----------------------------
/*char I2C_ReadByte(void)
{
	 char ret;
	 char i = 0;
	 ret = 0;

	  LPC_GPIO0->FIODIR = 0x00058815;
	SET_SDA;			//SDA = SET;
	 CLR_SCL;			//SCL = CLEAR;
     Delay(0);  
	 for(; i<8 ; i++)
	 {
		  SET_SCL;		//SCL = SET;
		  Delay(400);          
		  ret = (ret << 1);
		  if((LPC_GPIO0->FIOPIN & 0x00000400)) 
		  	ret++;
		  CLR_SCL;		//SCL = CLEAR;
		  Delay(400);   
//		  PrintHex(ret);
	 }
 LPC_GPIO0->FIODIR = 0x00058C15;
 return ret;
}	*/		

//------------- Initialize I2C ----------------------------
/*void i2c_init()
{

//	LPC_PINCON->PINSEL0 = LPC_PINCON->PINSEL0 & 0XFFFFFF0F;	// SELECT THE PIN for  I2C
//	LPC_PINCON->PINSEL0 = LPC_PINCON->PINSEL0 | 0X00000050;
	LPC_PINCON->PINSEL1 = 0x01400000;
	I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;
//	I20CONSET = 0x40 ;
	LPC_I2C0->I2SCLH = 150;		//set the bit frequency to 50 khz
	LPC_I2C0->I2SCLL = 150;	
}*/

void i2c_init()
{
  PINSEL1 |= 0x01400000;	/* set PIO0.27 and PIO0.28 to I2C0 SDA and SCK */
							/* function to 01 on both SDA and SCK. */
  /*--- Clear flags ---*/
  I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;    

  /*--- Reset registers ---*/
  I20SCLL   = I2SCLL_SCLL;
  I20SCLH   = I2SCLH_SCLH;
}

char I2C_Read(char addr_write,unsigned long int word_addr,char addr_read)
{	
	char read_data, addrh, addrl;
	unsigned int temp;

//	printf("I2C Read\n");
	temp = word_addr;
	 addrl = temp;
	 temp>>=8;
	 addrh = temp;

 	I20CONSET = ENABLE ;
	delay(1000);
/*---------------------transmit a START and address---------------------*/
	I20CONSET = I2CSTART;
	wait_StrtStop_ack(0x08);
	I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
	I20DAT = addr_write;
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x18,word_addr,addr_write);	
	/*-----------------------transmit page no-----------------------------*/
	I20DAT = addrh;
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x28,word_addr,addr_write);
	I20DAT = addrl;
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x28,word_addr,addr_write);
	wait_ReadWrite_ack(0x28,word_addr,addr_write);
	I20CONCLR = SI_CLR;
	I20CONSET =  I2CSTART ;
	wait_StrtStop_ack(0x10);
	I20CONCLR = START_CLR;				//put the address and the read bit	
	I20CONSET = AA;
	I20DAT = addr_read;
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x40,word_addr,addr_read);
	I20CONCLR =  SI_CLR;
/*-----------------------------receive data------------------------------*/	
	wait_ReadWrite_ack(0x50,word_addr,addr_read); 
//	read_data = I20DATA_BUFFER;
	read_data = I20DAT;
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x50,word_addr,addr_read);
	I20CONCLR = AA_CLR;
	I20CONCLR =  SI_CLR;
	wait_ReadWrite_ack(0x58,word_addr,addr_read);
/*-------------------transmit a STOP---------------------------------*/
	I20CONSET =I2CSTOP ;
	I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;
	return read_data;
}


char wait_ReadWrite_ack(char status, unsigned long int addr, unsigned long int slave_addr)
{
//	unsigned long timeout = 0x2FFFF; 
	char status1;
	char addrh;//, addrl;
	unsigned int temp;
	static unsigned char wdg_enabled = 0x00;

	temp = addr;
	 temp>>=8;
	 addrh = temp;

/*	if(slave_addr == 0xd0)			// by satya for resolve RTC Hang problem
	{
		if(wdg_enabled == 0xff)
		{
			printf("\nRTC restart_reader");
			reset_with_watchdog();
			while(1);
		}
		else
		{
		 	wdg_enabled++;
		}
	}			*/
	  
//	delay(10000); 
	while(1)				
	{
		if(I20CONSET & SI)  
		{
			status1 = I20STAT;
			if(status1 == status) 
			{
//				if(slave_addr == 0xd0)
//				{	
//					wdg_enabled = 0x00;
//				}
				return 0x00;
			}
			if(status1 == 0x20) 
			{
				I20CONSET = I2CSTART;
				I20CONCLR =  SI_CLR;
				wait_StrtStop_ack(0x10);
				I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
				I20DAT = slave_addr;
				I20CONCLR =  SI_CLR;
				wait_ReadWrite_ack(0x18,addr,slave_addr);	 //recrr
				return 0x02;
			}
			if(status1 == 0x30)
			{
				I20CONSET = I2CSTART;
				I20CONCLR =  SI_CLR;
				wait_StrtStop_ack(0x10);
				I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
				I20DAT = slave_addr;
				I20CONCLR =  SI_CLR;
				wait_ReadWrite_ack(0x18,addr,slave_addr);	
				/*-----------------------transmit page no-----------------------------*/
				I20DAT = addrh;
				I20CONCLR =  SI_CLR;
				wait_ReadWrite_ack(0x28,addr,slave_addr);
				return 0x00;
			}
			if(status1 == 0x48) 
			{
				I20CONSET = I2CSTART;
				I20CONCLR =  SI_CLR;
				wait_StrtStop_ack(0x10);
				I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
				I20DAT = slave_addr;
				I20CONCLR =  SI_CLR;
				wait_ReadWrite_ack(0x40,addr,slave_addr);
				return 0x00;	
			}
			if(status1 == 0x58)
			{
				I20CONSET = I2CSTART;
				I20CONCLR =  SI_CLR;
				wait_StrtStop_ack(0x10);
				I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
				I20DAT = slave_addr;
				I20CONCLR =  SI_CLR;
				wait_ReadWrite_ack(0x50,addr,slave_addr);
				return 0x00;	
			}
			if(status1 == 0x38)
			{
				i2c_init();
				return 0x01;	
			}
			else
			{
				I20CONSET = I2CSTOP;
				I20CONCLR = 0xFF;
				return 0x01;
			}
		}
	}

}

void wait_StrtStop_ack(char status)
{
	unsigned long int timeout = 0x2FFFF; 
	char status1;
				 
	delay(10000);
	while ((!(I20CONSET & SI)) && (timeout!= 0))		   // wait till the UART1 receiver FIFO is empty.
		{
			timeout --;
		} 
		if(timeout != 0) 
		{
			status1 = I20STAT;
			if(status1 == status)
			{
			   ;
			}
			else
			{
//				printf("SS");
//				PrintHex(status1);
				I20CONSET = I2CSTOP;
				I20CONCLR = 0xFF;
			}
 		}
}


char I2C_n_Read(char *s,unsigned long int word_addr,char bytecount,char Divece_read_add,char Divece_write_add)
//void I2C_n_Read(char *s,unsigned long int word_addr,char bytecount,char Divece_read_add,char Divece_write_add)
{	
	char addrh, addrl;
	unsigned int temp;
	int i=0;
	char res_val;

//	printf("I2C Read\n");
	temp = word_addr;
	 addrl = temp;
	 temp>>=8;
	 addrh = temp;

XX:	i = 0;
 	I20CONSET = ENABLE ;
	delay(1000);
/*---------------------transmit a START and address---------------------*/
//	printf("I2C Read\n");
	I20CONSET = I2CSTART;
	wait_StrtStop_ack(0x08);
	I20CONCLR = START_CLR;				// clear the START bit to avoid retransmit of START	
	I20DAT = Divece_write_add;
	I20CONCLR = SI_CLR;
	wait_ReadWrite_ack(0x18,word_addr,Divece_write_add);	
	/*-----------------------transmit page no-----------------------------*/
//	printf("transamit\n");
	I20DAT = addrh;
	I20CONCLR = SI_CLR;
	wait_ReadWrite_ack(0x28,word_addr,Divece_write_add);
	I20DAT = addrl;
	I20CONCLR = SI_CLR;
	wait_ReadWrite_ack(0x28,word_addr,Divece_write_add);
	wait_ReadWrite_ack(0x28,word_addr,Divece_write_add);
	I20CONCLR = SI_CLR;
	I20CONSET =  I2CSTART ;
	wait_StrtStop_ack(0x10);
	I20CONCLR = START_CLR;				//put the address and the read bit	
	I20CONSET = AA;
	I20DAT = Divece_read_add;
	I20CONCLR = SI_CLR;
	res_val = wait_ReadWrite_ack(0x40,word_addr,Divece_read_add);
	I20CONCLR = SI_CLR;
	if(res_val == 0x01)
		goto XX;
/*-----------------------------receive data------------------------------*/	
//	printf("receiving Data\n");
	for(; i < bytecount;i++)
	{
		wait_ReadWrite_ack(0x50,word_addr,Divece_read_add);	
//		s[i] = I20DATA_BUFFER;
		s[i] = I20DAT;
		I20CONCLR = SI_CLR;
	}
	s[i] = '\0';
	wait_ReadWrite_ack(0x50,word_addr,Divece_read_add);
	I20CONCLR = AA_CLR;
	I20CONCLR = SI_CLR;
	wait_ReadWrite_ack(0x58,word_addr,Divece_read_add);
/*-------------------transmit a STOP---------------------------------*/
	I20CONSET =I2CSTOP ;
	I20CONCLR = I2CONCLR_AAC | I2CONCLR_SIC | I2CONCLR_STAC | I2CONCLR_I2ENC;
return 0;
}

void delay(unsigned int del_ind)
{
	while(del_ind != 0)
	{
		del_ind--;
	}
}
#endif // end of // MTECH_I2CCODE
#endif // endof SUPPORT_TOUCHKEYPAD
/******************************************************************************
**                            End Of File
******************************************************************************/

