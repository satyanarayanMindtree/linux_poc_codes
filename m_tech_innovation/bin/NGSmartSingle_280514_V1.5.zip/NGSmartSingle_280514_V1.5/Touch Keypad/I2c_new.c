#include "LPC23xx.h"                        /* LPC23xx/24xx definitions */
#include "portdef.h"
#include "config.h"
#include "type.h"
#include "irq.h"
// #include "config.h"
// #include "portdef.h"
// #include "type.h"
// #include "timer.h"
// #include "target.h"
// #include "uart.h"

#include "i2cNew.h"

#ifdef NEW_TOUCH_KEYPAD

#define I2CDELAY		10

void I2CInit(void)
{
	SDA0_HIGH();
	SCL0_HIGH();	
}

void I2CdelayRTC(unsigned int val)
{
while(--val);
}

void I2CWaitAck(void)
{
		SCL0_HIGH();
		I2CdelayRTC(I2CDELAY);
		SCL0_LOW();	
		I2CdelayRTC(I2CDELAY);	
}

void I2CWrByte(unsigned char data1)
{   																													
	register unsigned char count;
	count = 8;
	while(count --)
	{		
		if(data1 & 0x80)
		{
			SDA0_HIGH();//			FIO0SET |= PIN0_SDA0;//SDA0_HIGH();
		}
		else
		{
			SDA0_LOW();////			FIO0CLR |= PIN0_SDA0;//SDA0_LOW();
		}	
		data1 = data1 << 1;
		SCL0_HIGH();
		I2CdelayRTC(I2CDELAY);
		SCL0_LOW();
		I2CdelayRTC(I2CDELAY);
	}
	  SDA0_HIGH();//			FIO0SET |= PIN0_SDA0;//SDA0_HIGH();
 	  I2CWaitAck();
	  I2CdelayRTC(I2CDELAY);        /*delay after write*/
	  I2CdelayRTC(I2CDELAY);
}

unsigned char I2CRdByte(void)
{
register unsigned char count,tmprtc;
	count  = 8;
	tmprtc = 0;
		SDA0_HIGH();//			FIO0SET |= PIN0_SDA0;//SDA0_HIGH();
	while(count--)
	{
		tmprtc = tmprtc<<1;
		SCL0_HIGH();
		I2CdelayRTC(I2CDELAY);
		I2CdelayRTC(I2CDELAY);
		if((FIO0PIN & PIN0_SDA0)>> 27) //if(SDA)
			tmprtc = tmprtc | 0x01;
		else
			tmprtc = tmprtc & 0xFE;		
		SCL0_LOW();		
		I2CdelayRTC(I2CDELAY);
		
	}
	return(tmprtc);
}

void SEND_START(void)
{
	SDA0_HIGH();	
	SCL0_HIGH();
	I2CdelayRTC(I2CDELAY);
	SDA0_LOW();
	I2CdelayRTC(I2CDELAY);
	SCL0_LOW();
	I2CdelayRTC(I2CDELAY);
}

void I2CPollSlave(unsigned char  SlaveAddr)
{   
 	SEND_START();
 	I2CWrByte(SlaveAddr);
} 

void I2CStop(void)
{	
	SCL0_LOW();
	SDA0_LOW();	
	I2CdelayRTC(I2CDELAY);
	SCL0_HIGH();
	I2CdelayRTC(I2CDELAY);
	SDA0_HIGH();
}

void I2CContRd(void) 
{
	SDA0_LOW();	
	I2CdelayRTC(I2CDELAY);
	SCL0_HIGH();
 	I2CdelayRTC(I2CDELAY);
 	SCL0_LOW();
	SDA0_HIGH();
}

void I2CStopRd(void) 
{	
	SDA0_HIGH();	
	SCL0_HIGH();
	I2CdelayRTC(I2CDELAY);
	SCL0_LOW();
}

void I2CStopWr(void)
{
	SDA0_LOW();
	SCL0_HIGH();
  SDA0_HIGH();
}
//============================================================================================================================

#ifdef DISABLE_NOW
void I2Cclk(void)
{      
	I2CdelayRTC();
	SCL = 1; 
	I2CdelayRTC();
	SCL = 0;
	I2CdelayRTC();
}

void WriteTime(void)
{
	unsigned char  tByte1,tByte2,tByte3,tByte4,tByte5;
	tByte1 = HEXTOBCD(0x09);	//sec
	tByte2 = HEXTOBCD(0x03);       //Min
	tByte3 = HEXTOBCD(0x03);       //Hour
	tByte4 = HEXTOBCD(0x10);       //date
	tByte5 = HEXTOBCD(0xA);       //month
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(0); 					/*Address*/  
	I2CWrByte(tByte1); 				/*Sec*/
	I2CWrByte(tByte2); 			/*Min*/
	I2CWrByte(tByte3); 			/*Hour*/
	I2CWrByte(0x01); 	/*week day*/
	I2CWrByte(tByte4); 	/*Date*/
	I2CWrByte(tByte5);	/*Month*/
	I2CWrByte(HEXTOBCD(0x3)); 	/*Year*/
	I2CStopWr();
}

/*-------------------------------------------------------------*/

void SetRTCTimeDate(struct DATE_TIME *timedate,unsigned char weekday)
{
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(0); 	/*Address*/  
	I2CWrByte(HEXTOBCD(timedate->Time.Bit.Secs)*2); 	/*Sec*/
	I2CWrByte(HEXTOBCD(timedate->Time.Bit.Min)); 	/*Min*/
	I2CWrByte(HEXTOBCD(timedate->Time.Bit.Hour)); 	/*Hour*/
	I2CWrByte(weekday); 	/*week day*/
	I2CWrByte(HEXTOBCD(timedate->Date.Bit.Day)); 	/*Date*/
	I2CWrByte(HEXTOBCD(timedate->Date.Bit.Month));	/*Month*/
	I2CWrByte(HEXTOBCD(timedate->Date.Bit.Year)); 	/*Year*/
	I2CStopWr();
#ifdef TEST_SYSTEM
	SendDecimalToPC(timedate->Time.Bit.Hour);
	TransmitChar(':');
	SendDecimalToPC(timedate->Time.Bit.Min);
	TransmitChar(':');
	SendDecimalToPC(timedate->Time.Bit.Secs);
	TransmitChar(' ');
	SendDecimalToPC(timedate->Date.Bit.Day);
	TransmitChar('/');
	SendDecimalToPC(timedate->Date.Bit.Month);
	TransmitChar('/');
	SendDecimalToPC(timedate->Date.Bit.Year);
	TransmitChar('\r');
#endif
}
/*--------------------------------------------------------*/
/*
void WriteRTCint(unsigned int Data,unsigned char Address)
{
  I2CPollSlave(0xD0+I2C_WRITE);
  I2CWrByte(Address); 	// Address  
  I2CWrByte(Data/0x100); 
  I2CWrByte((unsigned char)Data);
  I2CStopWr();
}
*/
/*--------------------------------------------------------*/

unsigned int WriteIntToRTC(unsigned char Address,unsigned int rtcdata)
{
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(Address); 	/*Address*/  
	I2CWrByte(rtcdata/0x100); 
	I2CWrByte((unsigned char)rtcdata);
	I2CStopWr();
	return(0);
}
/*--------------------------------------------------------*/

unsigned int ReadIntFromRTC(unsigned char Address)
{
	register unsigned int tempint;
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(Address); 
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_READ);
	tempint = I2CRdByte() * 0x100; 			/*Higher byte*/
	I2CContRd();
	tempint = tempint + I2CRdByte();		       /*lower byte*/	
	I2CStopRd(); 	
	return(tempint);
}

/*--------------------------------------------------------*/

unsigned int WriteLongToRTC(unsigned char address,unsigned long rtcdata)
{
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(address); 	
	I2CWrByte((unsigned char)(rtcdata/0x1000000L)); 
	I2CWrByte((unsigned char)(rtcdata/0x10000L)); 
	I2CWrByte((unsigned char)(rtcdata/0x100)); 
	I2CWrByte((unsigned char)(rtcdata&0xFF));
	I2CStopWr();
	return(0);
}
//--------------------------------------------------------

unsigned long ReadLongFromRTC(unsigned char address)
{
	register unsigned long tempint;
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(address); 
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_READ);
	tempint = I2CRdByte() * 0x1000000L; 		//	Higher byte
	I2CContRd();
	tempint = tempint + I2CRdByte() * 0x10000L; 			//Higher byte
	I2CContRd();
	tempint = tempint + I2CRdByte() * 0x100L; 			//Higher byte
	I2CContRd();
	tempint = tempint + I2CRdByte();		       //lower byte
	I2CStopRd(); 	
	return(tempint);
}
//-------------------------------------------------------

/*
void ReadRTCint(unsigned char Address,unsigned char *ptr)
{ I2CStopWr();
  I2CPollSlave(0xD0+I2C_WRITE);
  I2CWrByte(Address); 
  I2CStopWr();
  I2CPollSlave(0xD0+I2C_READ);
  *ptr=I2CRdByte(); 			//Higher byte
  ptr++;
  I2CContRd();
  *ptr = I2CRdByte();		       //lower byte
  I2CStopRd(); 	
   return;
}
*/

/*--------------------------------------------------------*/
unsigned char ReadRTCByte(unsigned char Address)
{
	unsigned char Data;
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(Address); 
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_READ);
	Data=I2CRdByte(); 			/*Higher byte*/
	I2CStopRd(); 	
	return(Data);
}

/*--------------------------------------------------------*/
void WriteRTCByte(unsigned char Address,unsigned char rtcdata)
{
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(Address); 	/*Address*/  
	I2CWrByte((unsigned char)rtcdata);
	I2CStopWr();
}

/*--------------------------------------------------------*/
void READ_RTC(void)
{   
unsigned char Minuts,Hours,Date,Secs,Month,Year,TWeekDay; 
	WDT();
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_WRITE);
	I2CWrByte(0x0); 
	I2CStopWr();
	I2CPollSlave(0xD0+I2C_READ);
	Secs = I2CRdByte(); 			/*Sec*/
	I2CContRd();
	Minuts = I2CRdByte(); 	/*min*/
	I2CContRd();
	Hours = I2CRdByte();	 	/*hr*/
	I2CContRd();
	TWeekDay = I2CRdByte();	 	/*week day*/
	I2CContRd();
	Date = I2CRdByte();	 	/*date */
	I2CContRd();
	Month = I2CRdByte();	 	/*month*/
	I2CContRd();
	Year =  I2CRdByte();	 	/* Year */
	I2CStopRd();
	WDT();
	if(CTime.Time.Bit.Min != BCDTOHEX(Minuts))
		F_OneMinute = SET;

/*	if(CTime.Time.Bit.Min != BCDTOHEX(Minuts))
		F_OneMinute = SET;
	if(CTime.Time.Bit.Hour != BCDTOHEX(Hours))
		F_OneHour = SET;
	if(CTime.Date.Bit.Day != BCDTOHEX(Date))	
		F_OneDay = SET;
*/
	CWeekDay = TWeekDay;
	CTime.Date.Bit.Day = BCDTOHEX(Date);
	CTime.Date.Bit.Month = BCDTOHEX(Month);
	CTime.Date.Bit.Year = BCDTOHEX(Year);
	CTime.Time.Bit.Hour = BCDTOHEX(Hours); 
	CTime.Time.Bit.Min = BCDTOHEX(Minuts);
	CTime.Time.Bit.Secs = BCDTOHEX(Secs)/2;
/*
	SendDecimalToPC(CTime.Time.Bit.Hour);
	TransmitChar(':');
	SendDecimalToPC(CTime.Time.Bit.Min);
	TransmitChar(':');
	SendDecimalToPC(CTime.Time.Bit.Secs);
	TransmitChar(' ');
	SendDecimalToPC(CTime.Date.Bit.Day);
	TransmitChar('/');
	SendDecimalToPC(CTime.Date.Bit.Month);
	TransmitChar('/');
	SendDecimalToPC(CTime.Date.Bit.Year );
	TransmitChar('\r');
*/
	return;
}

#endif
#endif

