
#ifndef __I2CNEW_H 
#define __I2CNEW_H


//#define EXTERN_I2C
#define EXTERN_I2C	extern

#define PIN0_SDA0  0x08000000   // FOR SDA0 --> 0.27
#define PIN0_SCL0  0x10000000   // FOR SCL0 --> 0.28

#define DIR_SDA0_IN()	{FIO0DIR &= ~PIN0_SDA0;}
// #define READ_SDA0(x)		{DIR_SDA0_IN();\
// 							x = (FIO0PIN&PIN0_SDA0)>>27;}
//#define READ_SDA0(x)		{x = (FIO0PIN&PIN0_SDA0)>>27;}

#define SDA0_HIGH_IN() {DIR_SDA0_IN(); FIO0SET |= PIN0_SDA0;}
#define SDA0_LOW_IN() {DIR_SDA0_IN(); FIO0CLR |= PIN0_SDA0;}

#define DIR_SDA0()	{FIO0DIR |= PIN0_SDA0;}
#define SDA0_HIGH() { FIO0SET |= PIN0_SDA0;}
#define SDA0_LOW() { FIO0CLR |= PIN0_SDA0;}

#define DIR_SCL0()	{FIO0DIR |= PIN0_SCL0;}  // Make direction out 
#define SCL0_HIGH() { FIO0SET |= PIN0_SCL0;} // 
#define SCL0_LOW() { FIO0CLR |= PIN0_SCL0;} // 

#define	I2C_READ	1
#define	I2C_WRITE	0

EXTERN_I2C volatile unsigned char I2CKeyData;
EXTERN_I2C volatile unsigned char I2CKeyData;

EXTERN_I2C unsigned char  I2CRxFlag;
EXTERN_I2C void I2CInit(void);
EXTERN_I2C void I2Cclk(void);
EXTERN_I2C void I2CPollSlave(unsigned char  SlaveAddr);
EXTERN_I2C void I2CWrByte(unsigned char  Data);
EXTERN_I2C void I2CStop(void);
EXTERN_I2C unsigned char I2CRdByte(void);
EXTERN_I2C void I2CContRd(void);
EXTERN_I2C void I2CStopRd(void);
EXTERN_I2C void I2CStopWr(void);
EXTERN_I2C void I2CWaitAck(void);
EXTERN_I2C void WriteTime(void);
EXTERN_I2C void SEND_START(void);
EXTERN_I2C void SCL_HIGH(void);


#endif

