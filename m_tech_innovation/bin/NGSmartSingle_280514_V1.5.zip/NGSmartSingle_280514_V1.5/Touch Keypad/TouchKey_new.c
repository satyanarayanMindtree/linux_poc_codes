//note: only I2C calling function you have to configure 



#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "portdef.h"
#include "config.h"
#include "type.h"
#include "irq.h"

#include "Keypad.h"

#include "i2cNew.h"
#include "TouchKey.h"
//#include "Timer.h"
//#include "delay.h"

#ifdef NEW_TOUCH_KEYPAD

void Capsence_Write_Register(unsigned short int write_address, unsigned short int value);
int Capsence_Read_Register(unsigned long int register_addr);
void Capsence_Init(void);
char check_cap_keypad(void);
extern void Delay_X10ms(unsigned int value);

static const char CAP_Device_addr_write = 0x58;
static const char CAP_Device_addr_read = 0x59;


//I2CRxFlag
/********************************************************************
Function name: Capsence_Write_Register
Description : this function is written for writing value to register
of capsence IC	specially during initialisation process 
remove comment for debugging of register, value we can read back.
call :	Capsence_Write_Register(address of register,value to be written in register)
********************************************************************/
void Capsence_Write_Register(unsigned short int write_address, unsigned short int value)
{
	I2CPollSlave(CAP_Device_addr_write); // configuration value, no change from default for WRITE 	
	I2CWrByte((write_address & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CWrByte(write_address &0x00FF);				//REGISTER ADDRESS LSB	
	
	I2CWrByte((value & 0xFF00) >> 8); 				//REGISTER DATA(to Write) MSB
	I2CWrByte(value & 0x00FF);  							//REGISTER DATA(to Write) LSB
	I2CStop();
}

/********************************************************************
Function name: int Capsence_Read_Register
Description : this function is written for writing value to register
of capsence IC specially during initialisation process 
call :	Capsence_Read_Register(address of register)
return : 2 byte integer value.
**********************************************************************/
int Capsence_Read_Register(unsigned long int register_addr)
{
	unsigned int reg_val_int=0,temp=0;
	
	I2CStop();	
	I2CPollSlave(CAP_Device_addr_write); // send Strat Sequence then device address with read or write 
	I2CWrByte((register_addr & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CWrByte(register_addr & 0x00FF);				//REGISTER ADDRESS LSB	
	I2CPollSlave(CAP_Device_addr_read); // send Strat Sequence then device address with read or write 
	reg_val_int = I2CRdByte(); 			//READ REGISTER DATA MSB
	I2CContRd();
	reg_val_int = reg_val_int <<= 8 ;
	temp = I2CRdByte(); 											//READ REGISTER DATA LSB
	I2CStopRd();
	reg_val_int = reg_val_int | temp;
	I2CStop();
  return (reg_val_int);
}

/********************************************************************
Function Name: Initialisation Function
Description:
********************************************************************/ 
void Capsence_Init(void)
{
	Capsence_Write_Register(0x0000,0xFFFF);

	Capsence_Read_Register(0x0002);

	Capsence_Write_Register(0x000A,0x0000);
	Capsence_Write_Register(0x0041,0x03FF);
	Capsence_Write_Register(0x0042,0x03FF);	

	Capsence_Write_Register(0x0008,0x8003);	
	Capsence_Write_Register(0x0043,0x03FF);	
	Capsence_Write_Register(0x0044,0x03FF);	
	Capsence_Write_Register(0x005F,0x0001);
	Capsence_Write_Register(0x0060,0x0014);
	Capsence_Write_Register(0x0061,0x0014);
	Capsence_Write_Register(0x0062,0x0014);
	Capsence_Write_Register(0x0063,0x0014);
	Capsence_Write_Register(0x0064,0x0014);
	Capsence_Write_Register(0x0065,0x0014);
	Capsence_Write_Register(0x0066,0x0014);	 
	Capsence_Write_Register(0x0067,0x0014);	 
	Capsence_Write_Register(0x0068,0x0014);	 
	Capsence_Write_Register(0x0069,0x0014);	 
	Capsence_Write_Register(0x006A,0x0014);	 
	Capsence_Write_Register(0x006B,0x0014);	 
	Capsence_Write_Register(0x006C,0x0014);	 
	Capsence_Write_Register(0x006D,0x0014);	 
	Capsence_Write_Register(0x006E,0x0014);	 
	Capsence_Write_Register(0x006F,0x0014);	 
	Capsence_Write_Register(0x0070,0x0014);	 
	Capsence_Write_Register(0x0071,0x0014);	 
	Capsence_Write_Register(0x0072,0x0014);	   
	Capsence_Write_Register(0x0073,0x0014);	   

	Capsence_Write_Register(0x004E,0x5000);
	Delay_X10ms(20);
	Capsence_Write_Register(0x0051,0x0A0A);	   

	Capsence_Write_Register(0x0052,0x0108);	   
	Delay_X10ms(20);
	Capsence_Write_Register(0x0053,0x0148);	   
	Delay_X10ms(20);

	Capsence_Write_Register(0x0075,0x0005);
	Delay_X10ms(20);

	Capsence_Write_Register(0x0077,0x8FFF);	   
	Delay_X10ms(20);
	Capsence_Write_Register(0x0040,0x8130);		
	Delay_X10ms(20);
	Capsence_Write_Register(0x0050,0x00FF);	   

	Capsence_Write_Register(0x0057,0x2020);	   
	Delay_X10ms(20);

  	Capsence_Write_Register(0x0001,0xFFFF);	 
	Delay_X10ms(20);
}
/********************************************************************
Function Name: 	char check_cap_keypad(void)
Description:	this function returns value of key from the matrix. it is recomanded to
use this function as it is.
********************************************************************/ 
char check_cap_keypad(void)
{
	int register_val_45 = 0x00,register_val_46 = 0x00;
	char ret_val='#';

	static const char key_mat[17]={	'1','2','3','#',
									'4','5','6','#',
									'7','8','9','#',
									'C','0','E','#',};

   	register_val_45 = Capsence_Read_Register(0x0045);
	register_val_46 = Capsence_Read_Register(0x0046);

	if(register_val_45==0x0000 && register_val_46==0x0000 )
	{
		 ret_val='#';
		 return ret_val;
	}
	switch(register_val_45)
	{
		case 0x0002:			     
		{
		 	ret_val= key_mat[1];		
			break;
		}
		case 0x0001:				   
		{
		 	ret_val=key_mat[2];	
			break;
		}
		case 0x0008:		  		  
		{
		 	ret_val=key_mat[5];		
			break;
		}
		case 0x0004:				    
		{
		 	ret_val=key_mat[6];		
			break;
		}
		case 0x0200:					  
		{
		 	ret_val=key_mat[8];		
			break;
		}
		case 0x0020:					  
		{
		 	ret_val=key_mat[9];		
			break;
		}
		case 0x0010:					   
		{
		 	ret_val=key_mat[10];		
			break;
		}
		case 0x0040:					   
		{
		 	ret_val=key_mat[13];		
			break;
		}
		case 0x0100:					     
		{
		 	ret_val=key_mat[12];		
			break;
		}
		case 0x0080:					     
		{
		 	ret_val=key_mat[14];		
			break;
		}
	}
	switch(register_val_46)
	{
		case 0x001:				    
		{
		 	ret_val=key_mat[4];		
			break;
		}
		case 0x0002:			     
		{
		 	ret_val=key_mat[0];		
			break;
		}
	}
	Delay_X10ms(5);	
	return	 ret_val;
}	
		

/*
void Capsence_Write_Register(unsigned short int write_address, unsigned short int value)
{
	for ( i = 0; i < BUFSIZE; i++ )	// clear buffer 
  {
		I2CMasterBuffer[i] = 0;
  }
  I2CWriteLength = 4;
  I2CReadLength = 0;
  I2CMasterBuffer[0] = CAPKEY_DEV_ADDR; // configuration value, no change from default 
  I2CMasterBuffer[1] = ((write_address & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CMasterBuffer[2] = (write_address & 0x00FF);				//REGISTER ADDRESS LSB	
	I2CMasterBuffer[3] = ((value & 0xFF00) >> 8); 				//REGISTER DATA(to Write) MSB
	I2CMasterBuffer[4] = (value & 0x00FF);; 							//REGISTER DATA(to Write) LSB
  I2CCmd = LM75_CONFIG;
//  I2CEngine(); 
}

int Capsence_Read_Register(unsigned long int register_addr)
{
	for ( i = 0; i < BUFSIZE; i++ )	// clear buffer 
  {
	I2CMasterBuffer[i] = 0;
  }
  I2CWriteLength = 2;
  I2CReadLength = 4;
  I2CMasterBuffer[0] = CAPKEY_DEV_ADDR;
  I2CMasterBuffer[1] = ((register_addr & 0xFF00) >> 8); //REGISTER ADDRESS MSB 
	I2CMasterBuffer[2] = (register_addr & 0x00FF);				//REGISTER ADDRESS LSB		
  I2CMasterBuffer[3] = CAPKEY_DEV_RD_ADDR;	//CAPKEY_ADDR | RD_BIT;
  I2CCmd = LM75_TEMP;
//  I2CEngine();
}
*/
#endif


