
#ifndef __OCR_A_EXTENDED__
#define __OCR_A_EXTENDED__

#include "bitmapfonts.h"

// Font data for OCR A Extended 16pt
extern const uint8_t oCRAExtended_16ptBitmaps[];
extern const FONT_INFO oCRAExtended_16ptFontInfo;
extern const FONT_CHAR_INFO oCRAExtended_16ptDescriptors[];

#endif
