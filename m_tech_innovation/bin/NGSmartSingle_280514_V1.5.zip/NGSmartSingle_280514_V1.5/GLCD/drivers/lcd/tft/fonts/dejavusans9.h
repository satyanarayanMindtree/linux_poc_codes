#ifndef __DEJA_VU_SANS_9__
#define __DEJA_VU_SANS_9__

#include "bitmapfonts.h"

extern const uint8_t dejaVuSans9ptCharBitmaps[];
extern const FONT_CHAR_INFO dejaVuSans9ptCharDescriptors[];
extern const FONT_INFO dejaVuSans9ptFontInfo;

#endif

