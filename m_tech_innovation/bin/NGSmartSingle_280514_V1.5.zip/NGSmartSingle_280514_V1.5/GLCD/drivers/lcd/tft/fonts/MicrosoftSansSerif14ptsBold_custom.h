#ifndef __MICROSOFT_SANS_SERIF_BOLD_14_POINT_
#define __MICROSOFT_SANS_SERIF_BOLD_14_POINT_

#include "bitmapfonts.h"
// Font data for Microsoft Sans Serif 14pt
extern const uint8_t microsoftSansSerif_14ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_14ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_14ptDescriptors[];
#endif
