#ifndef __DEJA_VU_SANS_MONO_8__
#define __DEJA_VU_SANS_MONO_8__

#include "bitmapfonts.h"

extern const uint8_t dejaVuSansMono8ptCharBitmaps[];
extern const FONT_CHAR_INFO dejaVuSansMono8ptCharDescriptors[];
extern const FONT_INFO dejaVuSansMono8ptFontInfo;

#endif

