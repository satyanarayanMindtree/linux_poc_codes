#ifndef __MICROSOFT_SANS_SERIF_BOLD_20__
#define __MICROSOFT_SANS_SERIF_BOLD_20__

#include "bitmapfonts.h"

// Font data for Microsoft Sans Serif 20pt
extern const uint8_t microsoftSansSerif_20ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_20ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_20ptDescriptors[];

#endif

