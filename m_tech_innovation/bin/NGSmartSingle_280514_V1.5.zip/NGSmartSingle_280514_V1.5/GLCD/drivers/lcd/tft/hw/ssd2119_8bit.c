//*****************************************************************************
//
// kitronix320x240x16_ssd2119_8bit.c - Display driver for the Kitronix
//                                     K350QVG-V1-F TFT display with an SSD2119
//                                     controller.  This version assumes an
//                                     8080-8bit interface between the micro
//                                     and display (PS3-0 = 0011b).
//
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup display_api
//! @{
//
//*****************************************************************************
#include "config.h"
#include <LPC23xx.h>      // Keil: Register definition file for LPC2378
#include "portdef.h"
#include "type.h"
#include "timer.h"
#include "serial.h"
//#include "portlcd.h"
#include "INOUT.h"
#include "rdcont.h"
#include "rdpoll.h"
#include "uart.h"
#include "SmartBio.h"

// #include "inc/hw_gpio.h"
// #include "inc/hw_ints.h"
// #include "inc/hw_memmap.h"
// #include "inc/hw_types.h"
// #include "driverlib/gpio.h"
// #include "driverlib/epi.h"
// #include "driverlib/interrupt.h"
// #include "driverlib/sysctl.h"
// #include "driverlib/timer.h"
// #include "grlib/grlib.h"
#include "ssd2119_8bit.h"
//#include "set_pinout.h"
#include "../../GLCD/drivers/lcd/tft/colors.h"
#include "../../GLCD/drivers/lcd/tft/lcd.h"
//*****************************************************************************
//
// This driver operates in four different screen orientations.  They are:
//
// * Portrait - The screen is taller than it is wide, and the flex connector is
//              on the left of the display.  This is selected by defining
//              PORTRAIT.
//
// * Landscape - The screen is wider than it is tall, and the flex connector is
//               on the bottom of the display.  This is selected by defining
//               LANDSCAPE.
//
// * Portrait flip - The screen is taller than it is wide, and the flex
//                   connector is on the right of the display.  This is
//                   selected by defining PORTRAIT_FLIP.
//
// * Landscape flip - The screen is wider than it is tall, and the flex
//                    connector is on the top of the display.  This is
//                    selected by defining LANDSCAPE_FLIP.
//
// These can also be imagined in terms of screen rotation; if portrait mode is
// 0 degrees of screen rotation, landscape is 90 degrees of counter-clockwise
// rotation, portrait flip is 180 degrees of rotation, and landscape flip is
// 270 degress of counter-clockwise rotation.
//
// If no screen orientation is selected, "landscape flip" mode will be used.
//
//*****************************************************************************
#if ! defined(PORTRAIT) && ! defined(PORTRAIT_FLIP) && \
    ! defined(LANDSCAPE) && ! defined(LANDSCAPE_FLIP)
#define LANDSCAPE_FLIP
#endif

//*****************************************************************************
//
// Various definitions controlling coordinate space mapping and drawing
// direction in the four supported orientations.
//
//*****************************************************************************
#ifdef PORTRAIT
#define HORIZ_DIRECTION 0x28
#define VERT_DIRECTION 0x20
#define MAPPED_X(x, y) (319 - (y))
#define MAPPED_Y(x, y) (x)
#endif
#ifdef LANDSCAPE
#define HORIZ_DIRECTION 0x00
#define VERT_DIRECTION  0x08
#define MAPPED_X(x, y) (319 - (x))
#define MAPPED_Y(x, y) (239 - (y))
#endif
#ifdef PORTRAIT_FLIP
#define HORIZ_DIRECTION 0x18
#define VERT_DIRECTION 0x10
#define MAPPED_X(x, y) (y)
#define MAPPED_Y(x, y) (239 - (x))
#endif
#ifdef LANDSCAPE_FLIP
#define HORIZ_DIRECTION 0x30
#define VERT_DIRECTION  0x38
#define MAPPED_X(x, y) (x)
#define MAPPED_Y(x, y) (y)
#endif

//*****************************************************************************
//
// Defines for the pins that are used to communicate with the SSD2119.
//
//*****************************************************************************

#define LCD_DATAH_PINS          0xFF
#define LCD_DATAH_PERIPH        SYSCTL_PERIPH_GPIOD
#define LCD_DATAH_BASE          GPIO_PORTD_BASE

//
// LCD control line GPIO definitions.
//
#define LCD_RST_PERIPH          SYSCTL_PERIPH_GPIOB
#define LCD_RST_BASE            GPIO_PORTB_BASE
#define LCD_RST_PIN             GPIO_PIN_7
#define LCD_RD_PERIPH           SYSCTL_PERIPH_GPIOB
#define LCD_RD_BASE             GPIO_PORTB_BASE
#define LCD_RD_PIN              GPIO_PIN_5
#define LCD_WR_PERIPH           SYSCTL_PERIPH_GPIOH
#define LCD_WR_BASE             GPIO_PORTH_BASE
#define LCD_WR_PIN              GPIO_PIN_6
#define LCD_DC_PERIPH           SYSCTL_PERIPH_GPIOH
#define LCD_DC_BASE             GPIO_PORTH_BASE
#define LCD_DC_PIN              GPIO_PIN_7

//*****************************************************************************
//
// Macro used to set the LCD data bus in preparation for writing a byte to the
// device.
//
//*****************************************************************************
#define SET_LCD_DATA(ucByte)                                                  \
{                                                                             \
    HWREG(LCD_DATAH_BASE + GPIO_O_DATA + (LCD_DATAH_PINS << 2)) = (ucByte);   \
}


#define ENTRY_MODE_DEFAULT 0x6830
#define MAKE_ENTRY_MODE(x) ((ENTRY_MODE_DEFAULT & 0xFF00) | (x))


//*****************************************************************************
//
// Translates a 24-bit RGB color to a display driver-specific color.
//
// \param c is the 24-bit RGB color.  The least-significant byte is the blue
// channel, the next byte is the green channel, and the third byte is the red
// channel.
//
// This macro translates a 24-bit RGB color into a value that can be written
// into the display's frame buffer in order to reproduce that color, or the
// closest possible approximation of that color.
//
// \return Returns the display-driver specific color.
//
//*****************************************************************************
#define DPYCOLORTRANSLATE(c)    ((((c) & 0x00f80000) >> 8) |               \
                                 (((c) & 0x0000fc00) >> 5) |               \
                                 (((c) & 0x000000f8) >> 3))

//#define WriteCommand 	WriteCommandGPIO
//#define WriteData 		WriteDataGPIO


//*****************************************************************************
//
// Function pointer types for low level LCD controller access functions.
//
//*****************************************************************************
typedef void (*pfnWriteData)(unsigned short usData);
typedef void (*pfnWriteCommand)(unsigned char ucData);

//*****************************************************************************
//
// Function pointers for low level LCD controller access functions.
//
//*****************************************************************************

//static void WriteDataGPIO(unsigned short usData);
void TFTWriteCommand(unsigned char ucData);

//pfnWriteData WriteData = WriteDataGPIO;
//pfnWriteCommand WriteCommand = WriteCommandGPIO;

void my_delay(unsigned int val)
{
	while(--val);
}

#ifdef	INTERFACE_8080
//*****************************************************************************
//
// read a data word from the SSD2119.  This function implements the basic GPIO
// interface to the LCD display.
//
//*****************************************************************************
unsigned short TFTReadCommand(void)
{
	unsigned short dat;
	unsigned char cdat;
DIR_IN_GLCD_DATALINE();
//SET_WR;
//SET_CD;
CLR_CD;
CLR_CS;
	
	//CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
    //my_delay(100);
	BYTE_GLCD_READ(cdat);
    //my_delay(100);
	SET_RD;
	SET_RD;
	SET_RD;
	SET_RD;
	dat = cdat<<8;
	
	CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
    //my_delay(100);
	BYTE_GLCD_READ(cdat);
    //my_delay(100);
	SET_RD;
	SET_RD;
	SET_RD;
	SET_RD;
	dat |= cdat;
	
SET_CS;
SET_CD;

DIR_OUT_GLCD_DATALINE();
	return dat; 
}

//*****************************************************************************
//
// Writes a data word to the SSD2119.  This function implements the basic GPIO
// interface to the LCD display.
//
//*****************************************************************************
void TFTWriteData(unsigned short usData)
{
	unsigned char dat;
CLR_CS;
SET_CD;
    // Write the most significant byte of the data to the bus.
	dat = (usData >> 8)&0xff;
    BYTE_GLCD_OUT(dat);
	
    // Assert the write enable signal.  We need to do this 3 times to ensure
    // that we don't violate the timing requirements for the display (when
    // running with a 50MHz system clock).
	CLR_WR;

    // Deassert the write enable signal.
	SET_WR;

    // Write the least significant byte of the data to the bus.
	dat = usData & 0xFF;
    BYTE_GLCD_OUT(dat);
	
    // Assert the write enable signal.
	CLR_WR;

    // Deassert the write enable signal.  WR needs to be high for at least
    // 50nS and back-to-back inlined calls to this function could just,
    // conceivably violate this so add one access to pad the time a bit.
	SET_WR_CS;
}

void TFTWriteByteData(unsigned char usData)
{
CLR_CS;
SET_CD;
    // Write the most significant byte of the data to the bus.

	BYTE_GLCD_OUT(usData);
	
    // Assert the write enable signal.  We need to do this 3 times to ensure
    // that we don't violate the timing requirements for the display (when
    // running with a 50MHz system clock).
	CLR_WR;
	SET_WR_CS;  // for SD card 
	
    // Deassert the write enable signal.
//	SET_WR;
//	usData++;
    // Write the least significant byte of the data to the bus.
//	dat = *usData;
//    BYTE_GLCD_OUT(dat);

    // Assert the write enable signal.
//	CLR_WR;

    // Deassert the write enable signal.  WR needs to be high for at least
    // 50nS and back-to-back inlined calls to this function could just,
    // conceivably violate this so add one access to pad the time a bit.
//	SET_WR_CS;
}

// #define TFTWriteData(usData)   {                                               \
// 	unsigned char dat;                                                      \
// SET_CD;                                                                     \
// 	dat = (usData >> 8)&0xff;                                               \
//     BYTE_GLCD_OUT(dat);                                                     \
// 	CLR_WR;                                                                 \
// 	SET_WR;                                                                 \
// 	dat = usData & 0xFF;                                                    \
//     BYTE_GLCD_OUT(dat);                                                     \
// 	CLR_WR;                                                                 \
// 	SET_WR;                                                                 \
// }                                                                           

//*****************************************************************************
//
// Writes a command to the SSD2119.  This function implements the basic GPIO
// interface to the LCD display.
//
//*****************************************************************************
void TFTWriteCommand(unsigned char ucData)
{
//SET_RD;
CLR_CD;
CLR_CS;
//SET_WR;
    //
    // Write the most significant byte of the data to the bus. This is always
    // 0 since commands are no more than 8 bits currently.
    //
    //SET_LCD_DATA(0);
	BYTE_GLCD_OUT(0x00);

    //
    // Assert DC
    //
    //HWREG(LCD_DC_BASE + GPIO_O_DATA + (LCD_DC_PIN << 2)) = 0;

    //
    // Assert the write enable signal.  Do this twice to 3 times to slow things
    // down a bit.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //my_delay(100);
	CLR_WR;
	//CLR_WR;
	//CLR_WR;
    //my_delay(100);

    //
    // Deassert the write enable signal. We need to leave WR high for at least
    // 50nS so, again, stick in a dummy write to pad the timing.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = LCD_WR_PIN;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = LCD_WR_PIN;
	SET_WR;
	///SET_WR;
    //my_delay(100);

    //
    // Write the least significant byte of the data to the bus.
    //
    //SET_LCD_DATA(ucData);
	BYTE_GLCD_OUT(ucData);

    //
    // Assert the write enable signal.  Again, do this twice to ensure
    // we meet the timing spec.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //my_delay(100);
	//CLR_WR;
	CLR_WR;
    //my_delay(100);

    //
    // Deassert the write enable signal.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = LCD_WR_PIN;
	//SET_WR;
	SET_WR;

    //
    // Set the DC signal high, indicating that following writes are data.  There
    // is no need to pad the timing here since we won't violate the 50nS rule
    // even if this function is inlined and it or WriteData are called
    // immediately after we exit.
    //
    //HWREG(LCD_DC_BASE + GPIO_O_DATA + (LCD_DC_PIN << 2)) = LCD_DC_PIN;
SET_CS;
    //my_delay(100);
//SET_CD;
}

#else   //#ifdef	INTERFACE_8080

//*****************************************************************************
// read a data word from the SSD2119.  This function implements the basic GPIO
// interface to the LCD display.
//*****************************************************************************
unsigned short ReadCommandGPIO(void)   //IT IS READ COMMAND
{
	unsigned short dat;
	unsigned char cdat;
DIR_IN_GLCD_DATALINE();
SET_WR;  //READ
CLR_CD;  //read command
	
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);
	BYTE_GLCD_READ(cdat);

	dat = cdat<<8;
	
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);
	BYTE_GLCD_READ(cdat);

	dat |= cdat;
	
SET_CD;

DIR_OUT_GLCD_DATALINE();
	return dat; 
}
unsigned short ReadDataGPIO(void)   //IT IS READ COMMAND
{
	unsigned short dat;
	unsigned char cdat;
DIR_IN_GLCD_DATALINE();
SET_WR;  //READ
SET_CD;  //read command
	
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);
	BYTE_GLCD_READ(cdat);

	dat = cdat<<8;
	
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);
	BYTE_GLCD_READ(cdat);

	dat |= cdat;
	
SET_CD;

DIR_OUT_GLCD_DATALINE();
	return dat; 
}

//*****************************************************************************
//
// Writes a data word to the SSD2119.  This function implements the basic GPIO
// interface to the LCD display.
//
//*****************************************************************************
static void WriteDataGPIO(unsigned short usData)
{
	unsigned char dat;
SET_CD;
CLR_WR;//write
	
	dat = (usData >> 8)&0xff;
    BYTE_GLCD_OUT(dat);
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);

	dat = usData & 0xFF;
    BYTE_GLCD_OUT(dat);
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);

SET_CD;
}

//*****************************************************************************
// Writes a command to the SSD2119.  This function implements the basic GPIO
// interface to the LCD display.
//*****************************************************************************
static void WriteCommandGPIO(unsigned char ucData)
{
CLR_CD;
//CLR_CS;
CLR_WR;

	BYTE_GLCD_OUT(0x00);//HIGHER BYTE WRITE
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);

	BYTE_GLCD_OUT(ucData);//LOWER BYTE WRITE
    my_delay(100);
SET_E;
    my_delay(100);
CLR_E;
    my_delay(100);

SET_CD;
}
#endif	//#else   //#ifdef	INTERFACE_8080


//*****************************************************************************
//
//! Initializes the pins required for the GPIO-based LCD interface.
//!
//! This function configures the GPIO pins used to control the LCD display
//! when the basic GPIO interface is in use.  On exit, the LCD controller
//! has been reset and is ready to receive command and data writes.
//!
//! \return None.
//
//*****************************************************************************
void InitGPIOLCDInterface(unsigned long ulClockMS)
{
	DIR_OUT_GLCD_CTRL_BITS();
	DIR_OUT_GLCD_DATALINE();
	DIR_IO_DEC_PINS();
	DISABLE_DECODER();
	CLR_BL;
	SET_BL;
    //
    // Convert the PB7/NMI pin into a GPIO pin.  This requires the use of the
    // GPIO lock since changing the state of the pin is otherwise disabled.
    //
    //HWREG(GPIO_PORTB_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY_DD;
    //HWREG(GPIO_PORTB_BASE + GPIO_O_CR) = 0x80;

    //
    // Make PB7 an output.
    //
    //GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_7);
	DIR_OUT_GLCD_CTRL_BITS();
	DIR_OUT_GLCD_DATALINE();

    //
    // Clear the commit register, effectively locking access to registers
    // controlling the PB7 configuration.
    //
    //HWREG(GPIO_PORTB_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY_DD;
    //HWREG(GPIO_PORTB_BASE + GPIO_O_CR) = 0x00;

    //
    // Configure the pins that connect to the LCD as GPIO outputs.
    //
    //GPIOPinTypeGPIOOutput(LCD_DATAH_BASE, LCD_DATAH_PINS);
    //GPIOPinTypeGPIOOutput(LCD_DC_BASE, LCD_DC_PIN);
    //GPIOPinTypeGPIOOutput(LCD_RD_BASE, LCD_RD_PIN);
    //GPIOPinTypeGPIOOutput(LCD_WR_BASE, LCD_WR_PIN);
    //GPIOPinTypeGPIOOutput(LCD_RST_BASE, LCD_RST_PIN);

    //
    // Set the LCD control pins to their default values.  This also asserts the
    // LCD reset signal.
    //
    //GPIOPinWrite(LCD_DATAH_BASE, LCD_DATAH_PINS, 0x00);
	BYTE_GLCD_OUT(0x00);
    //GPIOPinWrite(LCD_DC_BASE, LCD_DC_PIN, 0x00);
    //GPIOPinWrite(LCD_RD_BASE, LCD_RD_PIN, LCD_RD_PIN);
    //GPIOPinWrite(LCD_WR_BASE, LCD_WR_PIN, LCD_WR_PIN);
    //GPIOPinWrite(LCD_RST_BASE, LCD_RST_PIN, 0x00);
    SET_CD;
	SET_CS;
	SET_WR;
	SET_RD
	CLR_RESET; //reset device
    //
    // Delay for 1ms.
    //
    //SysCtlDelay(ulClockMS);
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    //
    // Deassert the LCD reset signal.
    //
    //GPIOPinWrite(LCD_RST_BASE, LCD_RST_PIN, LCD_RST_PIN);
    SET_RESET
    my_delay(10000);
    my_delay(10000);

	CLR_RESET; //reset device
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    SET_RESET
    my_delay(10000);
}

//*****************************************************************************
//
//! Initializes the display driver.
//!
//! This function initializes the SSD2119 display controller on the panel,
//! preparing it to display data.
//!
//! \return None.
//
//*****************************************************************************
void lcdInit(void)
{
    unsigned long ulClockMS, ulCount;
    //
    // Get the current processor clock frequency.
    //
    //ulClockMS = SysCtlClockGet() / (3 * 1000);

    //
    // Perform low level interface initialization depending upon how the LCD
    // is connected to the Stellaris microcontroller.  This varies depending
    // upon the daughter board connected it is possible that a daughter board
    // can drive the LCD directly rather than via the basic GPIO interface.
    //
//    switch(g_eDaughterType)
    {
//        case DAUGHTER_NONE:
        {
            //
            // Initialize the GPIOs used to interface to the LCD controller.
            //
            InitGPIOLCDInterface(ulClockMS);
//            break;
        }
    }
	
	//read device ID
    TFTWriteCommand(SSD2119_DEVICE_CODE_READ_REG);
	ulClockMS = TFTReadCommand();	
	
    //
    // Enter sleep mode (if we are not already there).
    //
    TFTWriteCommand(SSD2119_SLEEP_MODE_REG);
    TFTWriteData(0x0001);
    
    // Set initial power parameters.
    //
    TFTWriteCommand(SSD2119_PWR_CTRL_5_REG);
    TFTWriteData(0x00BA);
    TFTWriteCommand(SSD2119_VCOM_OTP_1_REG);
    TFTWriteData(0x0006);

    //
    // Start the oscillator.
    //
    TFTWriteCommand(SSD2119_OSC_START_REG);
    TFTWriteData(0x0001);

    //
    // Set pixel format and basic display orientation (scanning direction).
    //
    TFTWriteCommand(SSD2119_OUTPUT_CTRL_REG);
#ifdef ROTATE_DISPLAY
    TFTWriteData(0x30EF);// for display from bottom to top 
#else
    TFTWriteData(0x72EF); // display from top to bottom
#endif
    TFTWriteCommand(SSD2119_LCD_DRIVE_AC_CTRL_REG);
    TFTWriteData(0x0600);

    //
    // Exit sleep mode.
    //
    TFTWriteCommand(SSD2119_SLEEP_MODE_REG);
    TFTWriteData(0x0000);

    //
    // Delay 30mS
    //
//    SysCtlDelay(30 * ulClockMS);
       my_delay(30000);

    //
    // Configure pixel color format and MCU interface parameters.
    //
    TFTWriteCommand(SSD2119_ENTRY_MODE_REG);
    TFTWriteData(ENTRY_MODE_DEFAULT);

    //
    // Enable the display.
    //
    TFTWriteCommand(SSD2119_DISPLAY_CTRL_REG);
    TFTWriteData(0x0033);

    //
    // Set VCIX2 voltage to 6.1V.
    //
    TFTWriteCommand(SSD2119_PWR_CTRL_2_REG);
    TFTWriteData(0x0005);

    //
    // Configure gamma correction.
    //
    TFTWriteCommand(SSD2119_GAMMA_CTRL_1_REG);
    TFTWriteData(0x0000);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_2_REG);
    TFTWriteData(0x0400);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_3_REG);
    TFTWriteData(0x0106);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_4_REG);
    TFTWriteData(0x0700);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_5_REG);
    TFTWriteData(0x0002);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_6_REG);
    TFTWriteData(0x0702);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_7_REG);
    TFTWriteData(0x0707);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_8_REG);
    TFTWriteData(0x0203);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_9_REG);
    TFTWriteData(0x1400);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_10_REG);
    TFTWriteData(0x0F03);

    //
    // Configure Vlcd63 and VCOMl.
    //
    TFTWriteCommand(SSD2119_PWR_CTRL_3_REG);
    TFTWriteData(0x0007);
    TFTWriteCommand(SSD2119_PWR_CTRL_4_REG);
    TFTWriteData(0x3100);

    //
    // Set the display size and ensure that the GRAM window is set to allow
    // access to the full display buffer.
    //
    TFTWriteCommand(SSD2119_V_RAM_POS_REG);
    TFTWriteData((LCD_VERTICAL_MAX-1) << 8);
    TFTWriteCommand(SSD2119_H_RAM_START_REG);
    TFTWriteData(0x0000);
    TFTWriteCommand(SSD2119_H_RAM_END_REG);
    TFTWriteData(LCD_HORIZONTAL_MAX-1);
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(0x00);
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(0x00);

    //
    // Clear the contents of the display buffer.
    //
    TFTWriteCommand(SSD2119_RAM_DATA_REG);
    for(ulCount = 0; ulCount < (320 * 240); ulCount++)
    {
        TFTWriteData(0x0000);
        //WriteData(ulCount);
    }

}
// void SSD2119InitNew(void)
// {
//     unsigned long  ulCount;
// 	//************* Reset LCD Driver ****************//
// 	SET_RESET;
// 	my_delay(10000); 			 // Delay 10ms
// 	CLR_RESET;
// 	my_delay(50000); 			 // Delay 50ms // This delay time is necessary
// 	SET_RESET;
// 	my_delay(50000);			 // Delay 100 ms
// 	//************* Start Initial Sequence **********// 
// 	WriteCommandGPIO(0x0028); WriteDataGPIO(0x0006);	//Vcom OTP
// 	WriteCommandGPIO(0x0000); WriteDataGPIO(0x0001);	//Oscillator
// 	WriteCommandGPIO(0x0010); WriteDataGPIO(0x0000);	//Sleep set 
// 	WriteCommandGPIO(0x0001); WriteDataGPIO(0x72ef);	//Driver Output Control------------------------------
// 	WriteCommandGPIO(0x0002); WriteDataGPIO(0x0600);	//LCD-Driving-Waveform Control
// 	WriteCommandGPIO(0x0003); WriteDataGPIO(0x6a38);	//Power control 1--------------------
// 	WriteCommandGPIO(0x0011); WriteDataGPIO(0x6870);	//Entry Mode---------------------
// 	WriteCommandGPIO(0x0007); WriteDataGPIO(0x0033);	//Display Control
// 	WriteCommandGPIO(0x0016); WriteDataGPIO(0x001D);	//Horizontal Porch-----------------
// 	WriteCommandGPIO(0x0017); WriteDataGPIO(0x0003);	//Vertical Porch------------------
// 	//*************Power On sequence ****************
// 	WriteCommandGPIO(0x000f); WriteDataGPIO(0x0000);	//Gate Scan Position------all below reg
// 	WriteCommandGPIO(0x000b); WriteDataGPIO(0x5308);	//Frame Cycle Control
// 	WriteCommandGPIO(0x000c); WriteDataGPIO(0x0003);	//Power Control 2----------
// 	WriteCommandGPIO(0x000d); WriteDataGPIO(0x000a);	//Power Control 3
// 	WriteCommandGPIO(0x000e); WriteDataGPIO(0x2e00);	//Power Control 4
// 	WriteCommandGPIO(0x001e); WriteDataGPIO(0x00be);	//Power Control 5
// 	WriteCommandGPIO(0x0020); WriteDataGPIO(0xb0eb);	//Uniformity improvement scheme
// 	WriteCommandGPIO(0x0025); WriteDataGPIO(0xe000);	//Frame Frequency Control
// 	WriteCommandGPIO(0x0026); WriteDataGPIO(0x3800);	//Analogue Setting
// 	WriteCommandGPIO(0x0027); WriteDataGPIO(0x0078);	
// 	WriteCommandGPIO(0x004e); WriteDataGPIO(0x0000);	//Horizontal start position
// 	WriteCommandGPIO(0x004f); WriteDataGPIO(0x0000);	//Vertical start position
// 	WriteCommandGPIO(0x0012); WriteDataGPIO(0x0999);	//Sleep set
// 	//--------------- Gamma control---------------//
// 	WriteCommandGPIO(0x0030); WriteDataGPIO(0x0000);
// 	WriteCommandGPIO(0x0031); WriteDataGPIO(0x0104);
// 	WriteCommandGPIO(0x0032); WriteDataGPIO(0x0100);
// 	WriteCommandGPIO(0x0033); WriteDataGPIO(0x0305);
// 	WriteCommandGPIO(0x0034); WriteDataGPIO(0x0505);
// 	WriteCommandGPIO(0x0035); WriteDataGPIO(0x0305);
// 	WriteCommandGPIO(0x0036); WriteDataGPIO(0x0707);
// 	WriteCommandGPIO(0x0037); WriteDataGPIO(0x0300);
// 	WriteCommandGPIO(0x003a); WriteDataGPIO(0x1200);
// 	WriteCommandGPIO(0x003b); WriteDataGPIO(0x0800);

// 	WriteCommandGPIO(0x0022);		//Write Data to GRAM
//     for(ulCount = 0; ulCount < (320 * 240); ulCount++)
//     {
//         //WriteData(0x0000);
//         WriteData(ulCount);
//     }
// }
//*****************************************************************************
//
//! Draws a pixel on the screen.
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//! \param lX is the X coordinate of the pixel.
//! \param lY is the Y coordinate of the pixel.
//! \param ulValue is the color of the pixel.
//!
//! This function sets the given pixel to a particular color.  The coordinates
//! of the pixel are assumed to be within the extents of the display.
//!
//! \return None.
//
//*****************************************************************************
//static void Kitronix320x240x16_SSD2119PixelDraw(void *pvDisplayData, long lX, long lY,
//                                   unsigned long ulValue)
void lcdDrawPixel(long lX, long lY, unsigned long ulValue)
{
    //
    // Set the X address of the display cursor.
    //
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(MAPPED_X(lX, lY));

    //
    // Set the Y address of the display cursor.
    //
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(MAPPED_Y(lX, lY));

    //
    // Write the pixel value.
    //
    TFTWriteCommand(SSD2119_RAM_DATA_REG);
    TFTWriteData(ulValue);
}

//*****************************************************************************
//
//! Draws a horizontal sequence of pixels on the screen.
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//! \param lX is the X coordinate of the first pixel.
//! \param lY is the Y coordinate of the first pixel.
//! \param lX0 is sub-pixel offset within the pixel data, which is valid for 1
//! or 4 bit per pixel formats.
//! \param lCount is the number of pixels to draw.
//! \param lBPP is the number of bits per pixel; must be 1, 4, or 8.
//! \param pucData is a pointer to the pixel data.  For 1 and 4 bit per pixel
//! formats, the most significant bit(s) represent the left-most pixel.
//! \param pucPalette is a pointer to the palette used to draw the pixels.
//!
//! This function draws a horizontal sequence of pixels on the screen, using
//! the supplied palette.  For 1 bit per pixel format, the palette contains
//! pre-translated colors; for 4 and 8 bit per pixel formats, the palette
//! contains 24-bit RGB values that must be translated before being written to
//! the display.
//!
//! \return None.
//
//*****************************************************************************
// static void
// Kitronix320x240x16_SSD2119PixelDrawMultiple(void *pvDisplayData, long lX,
//                                            long lY, long lX0, long lCount,
//                                            long lBPP,
//                                            const unsigned char *pucData,
//                                            const unsigned char *pucPalette)
// {
//     unsigned long ulByte;

//     //
//     // Set the cursor increment to left to right, followed by top to bottom.
//     //
//     TFTWriteCommand(SSD2119_ENTRY_MODE_REG);
//     TFTWriteData(MAKE_ENTRY_MODE(HORIZ_DIRECTION));

//     //
//     // Set the starting X address of the display cursor.
//     //
//     TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
//     TFTWriteData(MAPPED_X(lX, lY));

//     //
//     // Set the Y address of the display cursor.
//     //
//     TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
//     TFTWriteData(MAPPED_Y(lX, lY));

//     //
//     // Write the data RAM write command.
//     //
//     TFTWriteCommand(SSD2119_RAM_DATA_REG);

//     //
//     // Determine how to interpret the pixel data based on the number of bits
//     // per pixel.
//     //
//     switch(lBPP)
//     {
//         //
//         // The pixel data is in 1 bit per pixel format.
//         //
//         case 1:
//         {
//             //
//             // Loop while there are more pixels to draw.
//             //
//             while(lCount)
//             {
//                 //
//                 // Get the next byte of image data.
//                 //
//                 ulByte = *pucData++;

//                 //
//                 // Loop through the pixels in this byte of image data.
//                 //
//                 for(; (lX0 < 8) && lCount; lX0++, lCount--)
//                 {
//                     //
//                     // Draw this pixel in the appropriate color.
//                     //
//                     TFTWriteData(((unsigned long *)pucPalette)[(ulByte >>
//                                                              (7 - lX0)) & 1]);
//                 }

//                 //
//                 // Start at the beginning of the next byte of image data.
//                 //
//                 lX0 = 0;
//             }

//             //
//             // The image data has been drawn.
//             //
//             break;
//         }

//         //
//         // The pixel data is in 4 bit per pixel format.
//         //
//         case 4:
//         {
//             //
//             // Loop while there are more pixels to draw.  "Duff's device" is
//             // used to jump into the middle of the loop if the first nibble of
//             // the pixel data should not be used.  Duff's device makes use of
//             // the fact that a case statement is legal anywhere within a
//             // sub-block of a switch statement.  See
//             // http://en.wikipedia.org/wiki/Duff's_device for detailed
//             // information about Duff's device.
//             //
//             switch(lX0 & 1)
//             {
//                 case 0:
//                     while(lCount)
//                     {
//                         //
//                         // Get the upper nibble of the next byte of pixel data
//                         // and extract the corresponding entry from the
//                         // palette.
//                         //
//                         ulByte = (*pucData >> 4) * 3;
//                         ulByte = (*(unsigned long *)(pucPalette + ulByte) &
//                                   0x00ffffff);

//                         //
//                         // Translate this palette entry and write it to the
//                         // screen.
//                         //
//                         TFTWriteData(DPYCOLORTRANSLATE(ulByte));

//                         //
//                         // Decrement the count of pixels to draw.
//                         //
//                         lCount--;

//                         //
//                         // See if there is another pixel to draw.
//                         //
//                         if(lCount)
//                         {
//                 case 1:
//                             //
//                             // Get the lower nibble of the next byte of pixel
//                             // data and extract the corresponding entry from
//                             // the palette.
//                             //
//                             ulByte = (*pucData++ & 15) * 3;
//                             ulByte = (*(unsigned long *)(pucPalette + ulByte) &
//                                       0x00ffffff);

//                             //
//                             // Translate this palette entry and write it to the
//                             // screen.
//                             //
//                             TFTWriteData(DPYCOLORTRANSLATE(ulByte));

//                             //
//                             // Decrement the count of pixels to draw.
//                             //
//                             lCount--;
//                         }
//                     }
//             }

//             //
//             // The image data has been drawn.
//             //
//             break;
//         }

//         //
//         // The pixel data is in 8 bit per pixel format.
//         //
//         case 8:
//         {
//             //
//             // Loop while there are more pixels to draw.
//             //
//             while(lCount--)
//             {
//                 //
//                 // Get the next byte of pixel data and extract the
//                 // corresponding entry from the palette.
//                 //
//                 ulByte = *pucData++ * 3;
//                 ulByte = *(unsigned long *)(pucPalette + ulByte) & 0x00ffffff;

//                 //
//                 // Translate this palette entry and write it to the screen.
//                 //
//                 TFTWriteData(DPYCOLORTRANSLATE(ulByte));
//             }

//             //
//             // The image data has been drawn.
//             //
//             break;
//         }

//         //
//         // We are being passed data in the display's native format.  Merely
//         // write it directly to the display.  This is a special case which is
//         // not used by the graphics library but which is helpful to
//         // applications which may want to handle, for example, JPEG images.
//         //
//         case 16:
//         {
//             unsigned short usByte;

//             //
//             // Loop while there are more pixels to draw.
//             //
//             while(lCount--)
//             {
//                 //
//                 // Get the next byte of pixel data and extract the
//                 // corresponding entry from the palette.
//                 //
//                 usByte = *((unsigned short *)pucData);
//                 pucData += 2;

//                 //
//                 // Translate this palette entry and write it to the screen.
//                 //
//                 TFTWriteData(usByte);
//             }
//         }
//     }
// }

//*****************************************************************************
//
//! Draws a horizontal line.     Modifed for speed
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//! \param lX1 is the X coordinate of the start of the line.
//! \param lX2 is the X coordinate of the end of the line.
//! \param lY is the Y coordinate of the line.
//! \param ulValue is the color of the line.
//!
//! This function draws a horizontal line on the display.  The coordinates of
//! the line are assumed to be within the extents of the display.
//!
//! \return None.
//
//*****************************************************************************
//void Kitronix320x240x16_SSD2119LineDrawH(void *pvDisplayData, long lX1, long lX2,
//                                   long lY, unsigned long ulValue)
void lcdDrawHLine(long lX1, long lX2, long lY, unsigned long ulValue)
{
    //
    // Set the cursor increment to left to right, followed by top to bottom.
    //
    TFTWriteCommand(SSD2119_ENTRY_MODE_REG);
    TFTWriteData(MAKE_ENTRY_MODE(HORIZ_DIRECTION));

    //
    // Set the starting X address of the display cursor.
    //
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(MAPPED_X(lX1, lY));

    //
    // Set the Y address of the display cursor.
    //
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(MAPPED_Y(lX1, lY));

    //
    // Write the data RAM write command.
    //
    TFTWriteCommand(SSD2119_RAM_DATA_REG);

    //
    // Loop through the pixels of this horizontal line.
    //
	CLR_CS;
	FIO1MASK = ~PINS_P1_GLCD_DATA;
	SET_CD;
	//dat = (x >> 8)&0xff;  // Write the most significant byte of the data to the bus.
    while(lX1++ <= lX2)
    {
        //
        // Write the pixel value.
        //
        //TFTWriteData(ulValue);
		GLCD_OUT_LINES=ulValue<<(GLCD_OUT_LINES_SHIFT-8);
		CLR_WR;
		SET_WR;
		GLCD_OUT_LINES=ulValue<<GLCD_OUT_LINES_SHIFT;
		CLR_WR;
		SET_WR;
    }
	FIO1MASK = 0;
	SET_CS;
}

//*****************************************************************************
//
//! Draws a vertical line.
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//! \param lX is the X coordinate of the line.
//! \param lY1 is the Y coordinate of the start of the line.
//! \param lY2 is the Y coordinate of the end of the line.
//! \param ulValue is the color of the line.
//!
//! This function draws a vertical line on the display.  The coordinates of the
//! line are assumed to be within the extents of the display.
//!
//! \return None.
//
//*****************************************************************************
// static void
// Kitronix320x240x16_SSD2119LineDrawV(void *pvDisplayData, long lX, long lY1,
//                                    long lY2, unsigned long ulValue)
// {
//     //
//     // Set the cursor increment to top to bottom, followed by left to right.
//     //
//     TFTWriteCommand(SSD2119_ENTRY_MODE_REG);
//     TFTWriteData(MAKE_ENTRY_MODE(VERT_DIRECTION));

//     //
//     // Set the X address of the display cursor.
//     //
//     TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
//     TFTWriteData(MAPPED_X(lX, lY1));

//     //
//     // Set the starting Y address of the display cursor.
//     //
//     TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
//     TFTWriteData(MAPPED_Y(lX, lY1));

//     //
//     // Write the data RAM write command.
//     //
//     TFTWriteCommand(SSD2119_RAM_DATA_REG);

//     //
//     // Loop through the pixels of this vertical line.
//     //
//     while(lY1++ <= lY2)
//     {
//         //
//         // Write the pixel value.
//         //
//         TFTWriteData(ulValue);
//     }
// }

//*****************************************************************************
//
//! Fills a rectangle.
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//! \param pRect is a pointer to the structure describing the rectangle.
//! \param ulValue is the color of the rectangle.
//!
//! This function fills a rectangle on the display.  The coordinates of the
//! rectangle are assumed to be within the extents of the display, and the
//! rectangle specification is fully inclusive (in other words, both sXMin and
//! sXMax are drawn, along with sYMin and sYMax).
//!
//! \return None.
//
//*****************************************************************************
// static void
// Kitronix320x240x16_SSD2119RectFill(void *pvDisplayData, const tRectangle *pRect,
//                                   unsigned long ulValue)
// {
//     long lCount;

//     //
//     // Write the Y extents of the rectangle.
//     //
//     WriteCommand(SSD2119_ENTRY_MODE_REG);
//     WriteData(MAKE_ENTRY_MODE(HORIZ_DIRECTION));

//     //
//     // Write the X extents of the rectangle.
//     //
//     WriteCommand(SSD2119_H_RAM_START_REG);
// #if (defined PORTRAIT) || (defined LANDSCAPE)
//     WriteData(MAPPED_X(pRect->sXMax, pRect->sYMax));
// #else
//     WriteData(MAPPED_X(pRect->sXMin, pRect->sYMin));
// #endif

//     WriteCommand(SSD2119_H_RAM_END_REG);
// #if (defined PORTRAIT) || (defined LANDSCAPE)
//     WriteData(MAPPED_X(pRect->sXMin, pRect->sYMin));
// #else
//     WriteData(MAPPED_X(pRect->sXMax, pRect->sYMax));
// #endif

//     //
//     // Write the Y extents of the rectangle
//     //
//     WriteCommand(SSD2119_V_RAM_POS_REG);
// #if (defined LANDSCAPE_FLIP) || (defined PORTRAIT)
//     WriteData(MAPPED_Y(pRect->sXMin, pRect->sYMin) |
//              (MAPPED_Y(pRect->sXMax, pRect->sYMax) << 8));
// #else
//     WriteData(MAPPED_Y(pRect->sXMax, pRect->sYMax) |
//              (MAPPED_Y(pRect->sXMin, pRect->sYMin) << 8));
// #endif

//     //
//     // Set the display cursor to the upper left of the rectangle (in application
//     // coordinate space).
//     //
//     WriteCommand(SSD2119_X_RAM_ADDR_REG);
//     WriteData(MAPPED_X(pRect->sXMin, pRect->sYMin));

//     WriteCommand(SSD2119_Y_RAM_ADDR_REG);
//     WriteData(MAPPED_Y(pRect->sXMin, pRect->sYMin));

//     //
//     // Tell the controller we are about to write data into its RAM.
//     //
//     WriteCommand(SSD2119_RAM_DATA_REG);

//     //
//     // Loop through the pixels of this filled rectangle.
//     //
//     for(lCount = ((pRect->sXMax - pRect->sXMin + 1) *
//                   (pRect->sYMax - pRect->sYMin + 1)); lCount >= 0; lCount--)
//     {
//         //
//         // Write the pixel value.
//         //
//         WriteData(ulValue);
//     }

//     //
//     // Reset the X extents to the entire screen.
//     //
//     WriteCommand(SSD2119_H_RAM_START_REG);
//     WriteData(0x0000);
//     WriteCommand(SSD2119_H_RAM_END_REG);
//     WriteData(0x013F);

//     //
//     // Reset the Y extent to the full screen
//     //
//     WriteCommand(SSD2119_V_RAM_POS_REG);
//     WriteData(0xEF00);
// }

//*****************************************************************************
//
//! Translates a 24-bit RGB color to a display driver-specific color.
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//! \param ulValue is the 24-bit RGB color.  The least-significant byte is the
//! blue channel, the next byte is the green channel, and the third byte is the
//! red channel.
//!
//! This function translates a 24-bit RGB color into a value that can be
//! written into the display's frame buffer in order to reproduce that color,
//! or the closest possible approximation of that color.
//!
//! \return Returns the display-driver specific color.
//
//*****************************************************************************
// static unsigned long
// Kitronix320x240x16_SSD2119ColorTranslate(void *pvDisplayData,
//                                         unsigned long ulValue)
// {
//     //
//     // Translate from a 24-bit RGB color to a 5-6-5 RGB color.
//     //
//     return(DPYCOLORTRANSLATE(ulValue));
// }

//*****************************************************************************
//
//! Flushes any cached drawing operations.
//!
//! \param pvDisplayData is a pointer to the driver-specific data for this
//! display driver.
//!
//! This functions flushes any cached drawing operations to the display.  This
//! is useful when a local frame buffer is used for drawing operations, and the
//! flush would copy the local frame buffer to the display.  For the SSD2119
//! driver, the flush is a no operation.
//!
//! \return None.
//
//*****************************************************************************
// static void
// Kitronix320x240x16_SSD2119Flush(void *pvDisplayData)
// {
//     //
//     // There is nothing to be done.
//     //
// }

//*****************************************************************************
//
//! The display structure that describes the driver for the Kitronix
//! K350QVG-V1-F TFT panel with an SSD2119 controller.
//
//*****************************************************************************
// const tDisplay g_sKitronix320x240x16_SSD2119 =
// {
//     sizeof(tDisplay),
//     0,
// #if defined(PORTRAIT) || defined(PORTRAIT_FLIP)
//     240,
//     320,
// #else
//     320,
//     240,
// #endif
//     Kitronix320x240x16_SSD2119PixelDraw,
//     Kitronix320x240x16_SSD2119PixelDrawMultiple,
//     Kitronix320x240x16_SSD2119LineDrawH,
//     Kitronix320x240x16_SSD2119LineDrawV,
//     Kitronix320x240x16_SSD2119RectFill,
//     Kitronix320x240x16_SSD2119ColorTranslate,
//     Kitronix320x240x16_SSD2119Flush
// };

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************

void FillScreen(unsigned short Color)
{
unsigned long ulCount;
    // Clear the contents of the display buffer.
    //
    TFTWriteCommand(SSD2119_RAM_DATA_REG);
    for(ulCount = 0; ulCount < (320 * 240); ulCount++)
    {
        TFTWriteData(Color);
        //WriteData(ulCount);
    }
	
}
void LcdSetCursor(long lX, long lY)
{
    //
    // Set the X address of the display cursor.
    //
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(lX);

    //
    // Set the Y address of the display cursor.
    //
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(lY);
}
/**************************************************************************/
/*! 
    @brief  Gets the height in pixels of the LCD screen (varies depending
            on the current screen orientation)
*/
/**************************************************************************/
unsigned short lcdGetHeight(void)
{
//   switch (lcdOrientation)
//   {
//     case LCD_ORIENTATION_PORTRAIT:
//       return ili9328Properties.height;
//       break;
//     case LCD_ORIENTATION_LANDSCAPE:
//     default:
//       return ili9328Properties.width;
//   }
	return LCD_VERTICAL_MAX;
}
/**************************************************************************/
/*! 
    @brief  Gets the width in pixels of the LCD screen (varies depending
            on the current screen orientation)
*/
/**************************************************************************/
unsigned short lcdGetWidth(void)
{
//   switch (lcdOrientation) 
//   {
//     case LCD_ORIENTATION_PORTRAIT:
//       return ili9328Properties.width;
//       break;
//     case LCD_ORIENTATION_LANDSCAPE:
//     default:
//       return ili9328Properties.height;
//   }
	return LCD_HORIZONTAL_MAX;
}
/**************************************************************************/
/*! 
    @brief  Renders a simple test pattern on the LCD
*/
/**************************************************************************/
void lcdTest(void)
{
  unsigned short i,j;
  LcdSetCursor(0,0);
  
  for(i=0;i<320;i++)
  {
    for(j=0;j<240;j++)
    {
      if(i>279)TFTWriteData(COLOR_WHITE);
      else if(i>239)TFTWriteData(COLOR_BLUE);
      else if(i>199)TFTWriteData(COLOR_GREEN);
      else if(i>159)TFTWriteData(COLOR_CYAN);
      else if(i>119)TFTWriteData(COLOR_RED);
      else if(i>79)TFTWriteData(COLOR_MAGENTA);
      else if(i>39)TFTWriteData(COLOR_YELLOW);
      else TFTWriteData(COLOR_BLACK);
    }
  }
}
/**************************************************************************/
/*! 
    @brief  Gets the current screen orientation (horizontal or vertical)
*/
/**************************************************************************/
lcdOrientation_t lcdGetOrientation(void)
{
//  return lcdOrientation;
	return LCD_ORIENTATION_LANDSCAPE;
}
/**************************************************************************/
/*! 
    @brief  Optimised routine to draw a horizontal line faster than
            setting individual pixels,we have takenbuffer for entire line
*/
/**************************************************************************/
void lcdDrawHLineWithBuff(uint16_t x0, uint16_t x1, uint16_t y, uint16_t *colorBuff)
{
  // Allows for slightly better performance than setting individual pixels
  unsigned short x, pixels;
//		unsigned char dat,*ptr;

  if (x1 < x0)
  {
    // Switch x1 and x0
    x = x1;
    x1 = x0;
    x0 = x;
  }

  // Check limits
  if (x1 >= lcdGetWidth())
  {
    x1 = lcdGetWidth() - 1;
  }
  if (x0 >= lcdGetWidth())
  {
    x0 = lcdGetWidth() - 1;
  }

  LcdSetCursor(x0, y);
  TFTWriteCommand(SSD2119_RAM_DATA_REG);  // Write Data to GRAM (R22h)
//	SET_CD;

//		ptr = (unsigned char*)&colorBuff[0];
  for (pixels = 0; pixels < x1 - x0 + 1; pixels++)
  {
    TFTWriteData(colorBuff[pixels]);
// 	{
// 		// Write the most significant byte of the data to the bus.
// 		BYTE_GLCD_OUT(*ptr);
// 		
// 		// Assert the write enable signal.  We need to do this 3 times to ensure
// 		// that we don't violate the timing requirements for the display (when
// 		// running with a 50MHz system clock).
// 		CLR_WR;

// 		// Deassert the write enable signal.
// 		SET_WR;

// 		// Write the least significant byte of the data to the bus.
// 		//dat = usData & 0xFF;
// 		++ptr;
// 		BYTE_GLCD_OUT(*ptr);

// 		// Assert the write enable signal.
// 		CLR_WR;

// 		// Deassert the write enable signal.  WR needs to be high for at least
// 		// 50nS and back-to-back inlined calls to this function could just,
// 		// conceivably violate this so add one access to pad the time a bit.
// 		SET_WR;
// 		++ptr;
// 	}

  }
}
void EnableSleepMode(void)
{
    // enable the sleep mode.
    TFTWriteCommand(SSD2119_SLEEP_MODE_REG);
    TFTWriteData(0x0000);
}
void DisableSleepMode(void)
{
    // Disable the sleep mode.
    TFTWriteCommand(SSD2119_SLEEP_MODE_REG);
    TFTWriteData(0x0001);
}
void EnableDisplay(void)
{
//     // Enable the display.
//     TFTWriteCommand(SSD2119_DISPLAY_CTRL_REG);
//     TFTWriteData(0x0033);
// 	
// //	EnableSleepMode();
}
void DisableDisplay(void)
{
//     // Disable the display.
//     TFTWriteCommand(SSD2119_DISPLAY_CTRL_REG);
//     TFTWriteData(0x0023);//
//     //TFTWriteData(0x0000);//halt display ;this will diaply gray screen only.
//     //TFTWriteData(0x0001);//;this will diaply gray screen only.
//     //TFTWriteData(0x0021);//
// 	
// //	DisableSleepMode();
}

void DiaplyInverted(void)
{
	//this function reverses the color on screen i.e white become black and black become white
    TFTWriteCommand(SSD2119_OUTPUT_CTRL_REG);
    //TFTWriteData(0x30EF);// actual data on init
    TFTWriteData(0x10EF);// to rotate display vertivally
}

