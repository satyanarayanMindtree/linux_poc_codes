#ifndef __MICROSOFT_SANS_SERIF_48_POINT___
#define __MICROSOFT_SANS_SERIF_48_POINT___

#include "bitmapfonts.h"
// Font data for Microsoft Sans Serif 48pt
extern const uint8_t microsoftSansSerif_48ptBitmaps[];
extern const FONT_INFO microsoftSansSerif_48ptFontInfo;
extern const FONT_CHAR_INFO microsoftSansSerif_48ptDescriptors[];
#endif
