#ifndef __VERA_MONO_9__
#define __VERA_MONO_9__

#include "bitmapfonts.h"

/* Font data for Bitstream Vera Sans Mono 9pt */
extern const uint8_t bitstreamVeraSansMono9ptCharBitmaps[];
extern const FONT_CHAR_INFO bitstreamVeraSansMono9ptCharDescriptors[];
extern const FONT_INFO bitstreamVeraSansMono9ptFontInfo;

#endif


