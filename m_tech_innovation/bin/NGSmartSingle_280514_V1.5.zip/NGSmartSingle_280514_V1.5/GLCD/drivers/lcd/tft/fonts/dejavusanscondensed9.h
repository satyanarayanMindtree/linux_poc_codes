#ifndef __DEJA_VU_SANS_CONDENSED_9__
#define __DEJA_VU_SANS_CONDENSED_9__

#include "bitmapfonts.h"

extern const uint8_t dejaVuSansCondensed9ptCharBitmaps[];
extern const FONT_CHAR_INFO dejaVuSansCondensed9ptCharDescriptors[];
extern const FONT_INFO dejaVuSansCondensed9ptFontInfo;

#endif

