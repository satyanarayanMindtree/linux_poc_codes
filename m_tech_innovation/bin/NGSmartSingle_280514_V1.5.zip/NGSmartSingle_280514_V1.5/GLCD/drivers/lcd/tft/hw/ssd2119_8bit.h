//***************************************************************************** 
 // 
 // kitronix320x240x16_ssd2119_8bit.h - Prototypes for the Kitronix K350QVG-V1-F 
 // display driver with an SSD2119 
 // controller. 
 // 
 
 // 
 //***************************************************************************** 
  
 #ifndef __KITRONIX320X240X16_SSD2119_8BIT_H__ 
 #define __KITRONIX320X240X16_SSD2119_8BIT_H__ 
 

//*****************************************************************************
//
// Various internal SD2119 registers name labels
//
//*****************************************************************************
#define SSD2119_DEVICE_CODE_READ_REG  0x00
#define SSD2119_OSC_START_REG         0x00
#define SSD2119_OUTPUT_CTRL_REG       0x01
#define SSD2119_LCD_DRIVE_AC_CTRL_REG 0x02
#define SSD2119_PWR_CTRL_1_REG        0x03
#define SSD2119_DISPLAY_CTRL_REG      0x07
#define SSD2119_FRAME_CYCLE_CTRL_REG  0x0B
#define SSD2119_PWR_CTRL_2_REG        0x0C
#define SSD2119_PWR_CTRL_3_REG        0x0D
#define SSD2119_PWR_CTRL_4_REG        0x0E
#define SSD2119_GATE_SCAN_START_REG   0x0F
#define SSD2119_SLEEP_MODE_REG        0x10
#define SSD2119_ENTRY_MODE_REG        0x11
#define SSD2119_GEN_IF_CTRL_REG       0x15
#define SSD2119_PWR_CTRL_5_REG        0x1E
#define SSD2119_RAM_DATA_REG          0x22
#define SSD2119_FRAME_FREQ_REG        0x25
#define SSD2119_VCOM_OTP_1_REG        0x28
#define SSD2119_VCOM_OTP_2_REG        0x29
#define SSD2119_GAMMA_CTRL_1_REG      0x30
#define SSD2119_GAMMA_CTRL_2_REG      0x31
#define SSD2119_GAMMA_CTRL_3_REG      0x32
#define SSD2119_GAMMA_CTRL_4_REG      0x33
#define SSD2119_GAMMA_CTRL_5_REG      0x34
#define SSD2119_GAMMA_CTRL_6_REG      0x35
#define SSD2119_GAMMA_CTRL_7_REG      0x36
#define SSD2119_GAMMA_CTRL_8_REG      0x37
#define SSD2119_GAMMA_CTRL_9_REG      0x3A
#define SSD2119_GAMMA_CTRL_10_REG     0x3B
#define SSD2119_V_RAM_POS_REG         0x44
#define SSD2119_H_RAM_START_REG       0x45
#define SSD2119_H_RAM_END_REG         0x46
#define SSD2119_X_RAM_ADDR_REG        0x4E
#define SSD2119_Y_RAM_ADDR_REG        0x4F

//*****************************************************************************
//
// The dimensions of the LCD panel.
//
//*****************************************************************************
#define LCD_VERTICAL_MAX 240
#define LCD_HORIZONTAL_MAX 320

 
 //***************************************************************************** 
 // 
 // Prototypes for the globals exported by this driver. 
 // 
 //***************************************************************************** 
extern void Kitronix320x240x16_SSD2119Init(void); 
// extern const tDisplay g_sKitronix320x240x16_SSD2119; 
extern void Kitronix320x240x16_SSD2119LineDrawH(void *pvDisplayData, long lX1, long lX2, long lY, unsigned long ulValue);
extern unsigned short ReadDataGPIO(void);
extern unsigned short ReadCommandGPIO(void);   //IT IS READ COMMAND
extern void FillScreen(unsigned short Color);
extern void WriteCommand(unsigned char ucData);
void LcdSetCursor(long lX, long lY);
void lcdDrawHLine(long lX1, long lX2, long lY, unsigned long ulValue) ;
void lcdDrawPixel(long lX, long lY, unsigned long ulValue);
void lcdInit(void);
void InitGPIOLCDInterface(unsigned long ulClockMS);
void TFTWriteCommand(unsigned char ucData);
void TFTWriteByteData(unsigned char usData);
void TFTWriteData(unsigned short usData);
unsigned short TFTReadCommand(void);
void EnableDisplay(void);
void DisableDisplay(void);

 #endif // __KITRONIX320X240X16_SSD2119_H__ 

