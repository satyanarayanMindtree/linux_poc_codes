#ifndef __VERA_MONO_BOLD_11__
#define __VERA_MONO_BOLD_11__

#include "bitmapfonts.h"

/* Font data for Bitstream Vera Sans Mono Bold 11pt */
extern const uint8_t bitstreamVeraSansMonoBold11ptCharBitmaps[];
extern const FONT_CHAR_INFO bitstreamVeraSansMonoBold11ptCharDescriptors[];
extern const FONT_INFO bitstreamVeraSansMonoBold11ptFontInfo;

#endif

