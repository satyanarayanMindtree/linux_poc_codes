
#define COLOR_BPP          16
#define COLOR_STORAGE_SIZE 2
#define BMPWIDTH           320
#define BMPHEIGHT          240
extern const  unsigned short image16;


