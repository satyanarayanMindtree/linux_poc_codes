extern const unsigned short  icon1[];
extern const unsigned short  icon2[];
extern const unsigned short  icon3[];
extern const unsigned char GridIconNormalPaletteArray[9][4];
extern const unsigned char GridIconHighlightPaletteArray[9][4];
extern const unsigned char GridIconDataArray[9][480];
extern const unsigned char TopStatusIconPaletteArray[][4];
extern const unsigned char TopStatusIconDataArray[][32];
extern const unsigned char BottomStatusIconPaletteArray[][4];
extern const unsigned char BottomStatusIconDataArray[][32];

