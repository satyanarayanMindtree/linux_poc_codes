/*******************************************************
FileName: Fat32.c
Author:Creative
Description: ROUTINES FOR FAT32 IMPLEMATATION OF SD CARD
********************************************************/

//Includes ===============================================================================
#include "config.h"
#include "FAT32.h"
#include "SD_routines.h"
//#include "NewSdUart.h"
#include "NewSdMain.h"
#include "type.h"
#include "serial.h"
#include <stdio.h>
#include <string.h>
#include "uart.h"
#include "SmartBio.h"

#ifdef INSERT_SDCARD

#define BUF1	0
#define BUF2	1

#define SUCCESS	0
#define FAILURE	1

//#define	MsgPrintInt	 	MsgPrint

//#define Delay50Micro(X)	Delay(X*15) 

// comment below if you want to disable debugging in this file	defect X0018
//#undef MsgPrint	
//#define MsgPrint  //MsgPrint1

//Variables ==============================================================================
unsigned char gucNumberofFATs;
unsigned char gucFreeClusterCountUpdated;
unsigned char gucFileDelStatus = 0;
unsigned short dateFAT, timeFAT;
unsigned short gusBytesPerSector, gusSectorPerCluster, gusReservedSectorCount;
unsigned long gulUnusedSectors, gulAppendFileSector, gulAppendFileLocation, fileSize, gusAppendStartCluster;
unsigned long gulFATsize_F32, gulTotalSectors_F32, gulHiddenSectors;
unsigned long gulFirstDataSector, gulRootCluster, gulTotalClusters;
unsigned long gllCardCap = 0;
struct MBRinfo_Structure gstMBR_Info;
struct BS_Structure gstBS_Structure;
struct partitionInfo_Structure *partition;
struct partitionInfo_Structure partsn;

//************* functions *************
unsigned char getBootSectorData (void);
unsigned char ucFnSetFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize);
unsigned char ucFnAppendFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize);
unsigned char ucFnReadFileOffset(u8 *pFN, u8 *pBuf, u32 lulOffSet, u16 lusDataSize);
unsigned char getDateTime_FAT(u8 dt,u8 mth, u16 yr, u8 hr, u8 min, u8 sec);
unsigned char ucFnSearchFile(u8 *pFN);
unsigned short fnShiftShort(unsigned char lucBufType, unsigned short i);
unsigned long fnShiftLong(unsigned char lucBufType, unsigned short i);
unsigned long ulFnGetFileSize(unsigned char *pFN);
void memoryStatistics (void);
struct dir_Structure* findFiles (unsigned char flag, unsigned char *fileName);

unsigned long getFirstSector(unsigned long clusterNumber);
unsigned long getSetFreeCluster(unsigned char totOrNext, unsigned char get_set, unsigned long FSEntry);
unsigned long getSetNextCluster (unsigned long clusterNumber,unsigned char get_set,unsigned long clusterEntry);
unsigned char readFile (unsigned char flag, unsigned char *fileName);
unsigned char convertFileName (unsigned char *fileName);
unsigned long searchNextFreeCluster (unsigned long startCluster);
unsigned char ucFnDeleteFile (unsigned char *fileName);
void freeMemoryUpdate (unsigned char flag, unsigned long size);
void writeFile (unsigned char *fileName);
void appendFile (void);
void displayMemory (unsigned char lucFlag, unsigned long memory);

//Functions ================================================================================

/*==========================================================================================
//Function: To read data from boot sector of SD card, to determine important
//parameters like gusBytesPerSector, sectorsPerCluster etc.
//This function is to be called before any file functions are called.
//Arguments: none
//Return: SUCCESS-0 / FAILURE-1
==========================================================================================*/
unsigned char getBootSectorData(void)
{
	unsigned long gulDataSectors;
	unsigned long lulData = 0;
	unsigned short i;
	
	gulUnusedSectors = 0;
	// Read the Boot sector to calculate the parameters
	SD_readSingleBlock(0);//partition1 is from byte 446 to 461 =>16 byte
	lulData = fnShiftLong(BUF2, 197);//"LBA begins" adress is in byte 254,255,256,257
	if(SDbuf1[0]!=0xE9 && SDbuf1[0]!=0xEB)
	{
		if( (SDbuf2[251] != 0xAA) && (SDbuf2[250] != 0x55) )//check end byte of sector 0
		{
			return FAILURE;
		}

		gulUnusedSectors = lulData;
		SD_readSingleBlock(lulData);//read the bpb sector
		
		gusBytesPerSector = fnShiftShort(BUF1, 12);//read byte per sector from BPB
		i = 13;
		gusSectorPerCluster = SDbuf1[i]; //read sector per cluster from BPB
		
		gusReservedSectorCount = fnShiftShort(BUF1, 15); //read reserved sector count
		i = 16;
		gucNumberofFATs = SDbuf1[i];//number of FATS
		
		gulHiddenSectors	= fnShiftLong(BUF1, 31);//
		gulTotalSectors_F32	= fnShiftLong(BUF1, 35); //Sectors Per FAT
		gulFATsize_F32	= fnShiftLong(BUF1, 39);//
		gulRootCluster	= fnShiftLong(BUF1, 47);
		
		if(SDbuf1[0]!=0xE9 && SDbuf1[0]!=0xEB) 
		{
			return FAILURE;
		}

	}
#ifdef DEBUG_EN	
	sprintf((char*)&gaucDebDuf, "\n\rBytesPerSector = %d Bytes", gusBytesPerSector);
	TransmitStrToPC(&gaucDebDuf[0]);
	sprintf((char*)&gaucDebDuf, "\n\rSectorPerCluster = %d", gusSectorPerCluster);
	TransmitStrToPC(&gaucDebDuf[0]);
#endif	

	gulFirstDataSector = gulHiddenSectors + gusReservedSectorCount + (gucNumberofFATs * gulFATsize_F32);
	gulDataSectors = gulTotalSectors_F32
								- gusReservedSectorCount
								- ( gucNumberofFATs * gulFATsize_F32);

	gulTotalClusters = gulDataSectors / gusSectorPerCluster;
#ifdef DEBUG_EN		
	sprintf((char*)&gaucDebDuf, "\n\rTotalClusters = %lu \n\r", gulTotalClusters);
	TransmitStrToPC(&gaucDebDuf[0]);
  
  if(gulTotalClusters == 1927331)
	{
		//this data is hard coded as could not find the data type unsigned long long.
		sprintf((char*)&gaucDebDuf, "\n\rCard Capacity =  15788695552 Bytes\n\r");
	}
	else if(gulTotalClusters == 1935671)
	{
		//this data is hard coded as could not find the data type unsigned long long.
		sprintf((char*)&gaucDebDuf, "\n\rCard Capacity =  7928508416 Bytes\n\r");
	}
	else
	{
		gllCardCap = gulTotalClusters * gusSectorPerCluster * gusBytesPerSector;
		sprintf((char*)&gaucDebDuf, "\n\rCard Capacity = %lu Bytes\n\r", gllCardCap);
	}
	TransmitStrToPC(&gaucDebDuf[0]);
#endif	

	if((getSetFreeCluster (TOTAL_FREE, GET, 0)) > gulTotalClusters)  //check if FSinfo free clusters count is valid
			 gucFreeClusterCountUpdated = 0;
	else
		 gucFreeClusterCountUpdated = 1;
	
	return SUCCESS;
}


/*==========================================================================================
//Function: to calculate first sector address of any given cluster
//Arguments: cluster number for which first sector is to be found
//Return: first sector address
==========================================================================================*/
unsigned long getFirstSector(unsigned long lulClusterNumber)
{
	return (((lulClusterNumber - 2) * gusSectorPerCluster) + gulFirstDataSector);
}


/*==========================================================================================
//Function: get cluster entry value from FAT to find out the next cluster in the chain
//or set new cluster entry in FAT
//Arguments: 1. current cluster number, 2. get_set (=GET, if next cluster is to be found or = SET,
//if next cluster is to be set 3. next cluster number, if argument#2 = SET, else 0
//Return: next cluster number, if if argument#2 = GET, else 0
==========================================================================================*/
unsigned long getSetNextCluster (unsigned long lulClusterNumber,
																 unsigned char lucGetSet,
																 unsigned long lulClusterEntry)
{
	unsigned short lusFATEntryOffset;
	#pragma pack(1)
	__packed unsigned long *FATEntryValue;
	unsigned long lulFATEntrySector;
	unsigned char retry = 0;
	unsigned short z = 0;

	//get sector number of the cluster entry in the FAT
	lulFATEntrySector = gulUnusedSectors + gusReservedSectorCount + ((lulClusterNumber * 4) / gusBytesPerSector) ;

	//get the offset address in that sector number
	lusFATEntryOffset = (unsigned short) ((lulClusterNumber * 4) % gusBytesPerSector);

	//read the sector into a buffer
	while(retry <10)
	{ if(!SD_readSingleBlock(lulFATEntrySector)) break; retry++;}

	//get the cluster address from the buffer
	FATEntryValue = (unsigned long *) &SDbuffer[lusFATEntryOffset];

	if(lucGetSet == GET)
		return ((*FATEntryValue) & 0x0fffffff);

	*FATEntryValue = lulClusterEntry;   //for setting new value in cluster entry in FAT

	for(z = 0; z < 512; z++)
	{
		if (z <= 259)
		{
			SDbuf1[z] = SDbuffer[z];
		}
		else
		{
			SDbuf2[z-260] = SDbuffer[z];
		}
	}
	
	SD_writeSingleBlock(lulFATEntrySector);

	return (0);
}


/*==========================================================================================
//Function: to get or set next free cluster or total free clusters in FSinfo sector of SD card
//Arguments: 1.flag:TOTAL_FREE or NEXT_FREE, 
//			 2.flag: GET or SET 
//			 3.new FS entry, when argument2 is SET; or 0, when argument2 is GET
//Return: next free cluster, if arg1 is NEXT_FREE & arg2 is GET
//        total number of free clusters, if arg1 is TOTAL_FREE & arg2 is GET
//		  0xffffffff, if any error or if arg2 is SET
==========================================================================================*/
unsigned long getSetFreeCluster(unsigned char lucTotOrNext, unsigned char lucGetSet, unsigned long lulFSEntry)
{
	#pragma pack(1)
	__packed struct FSInfo_Structure *FS = (struct FSInfo_Structure *) &SDbuffer;
	
	
	unsigned short i = 0;


	SD_readSingleBlock(gulUnusedSectors + 1);

	if((FS->leadSignature != 0x41615252) || (FS->structureSignature != 0x61417272) || (FS->trailSignature !=0xaa550000))
		return 0xffffffff;

	if(lucGetSet == GET)
	{
		 if(lucTotOrNext == TOTAL_FREE)
				return(FS->freeClusterCount);
		 else // when totOrNext = NEXT_FREE
		 {
			 if(FS->nextFreeCluster == 3)
				{
					if(gllCardCap > 0x77132000) // if greater than 2GB
					{
						FS->nextFreeCluster = 513;
					}
					else
					{
						FS->nextFreeCluster = 257;
					}
					for(i=0; i<512; i++) //read 512 bytes
					{
						if(i <= 259)
						{
							SDbuf1[i] = SDbuffer[i];
						}
						else
						{
							SDbuf2[i-260] = SDbuffer[i];
						}
					}
					SD_writeSingleBlock(gulUnusedSectors + 1);
				}
				
				return(FS->nextFreeCluster);
			}	
				
	}
	else
	{
		if(lucTotOrNext == TOTAL_FREE)
			FS->freeClusterCount = lulFSEntry;
		else // when totOrNext = NEXT_FREE
			FS->nextFreeCluster = lulFSEntry;
	 
		for(i=0; i<512; i++) //read 512 bytes
		{
			if(i <= 259)
			{
				SDbuf1[i] = SDbuffer[i];
			}
			else
			{
				SDbuf2[i-260] = SDbuffer[i];
			}
		}
		SD_writeSingleBlock(gulUnusedSectors + 1);	//update FSinfo
	}
	return 0xffffffff;
}



/*==========================================================================================
//Function: to get DIR/FILE list or a single file address (cluster number) or to delete a specified file
//Arguments: #1 - flag: GET_LIST, GET_FILE or DELETE #2 - pointer to file name (0 if arg#1 is GET_LIST)
//Return: first cluster of the file, if flag = GET_FILE
//        print file/dir list of the root directory, if flag = GET_LIST
//		  Delete the file mentioned in arg#2, if flag = DELETE
==========================================================================================*/
struct dir_Structure* findFiles (unsigned char lucFlag, unsigned char *fileName)
{
	unsigned long lulCluster, lulSector, lulFirstSector, lulFirstCluster, lulNextCluster;
	#pragma pack(1) 
	__packed struct dir_Structure *dir;
	unsigned short i, lusTemp1;
	unsigned char j;

	lulCluster = gulRootCluster; //root cluster
	
	gucFileDelStatus = 1;
	while(1)
	{
		 lulFirstSector = getFirstSector (lulCluster);

		 for(lulSector = 0; lulSector < gusSectorPerCluster; lulSector++)
		 {
			 SD_readSingleBlock (lulFirstSector + lulSector);
		

			 for(i=0; i<gusBytesPerSector; i+=32)
			 {
					dir = (struct dir_Structure *) &SDbuffer[i];
					if(dir->name[0] == EMPTY) //indicates end of the file list of the directory// JP
					{
						if((lucFlag == GET_FILE) || (lucFlag == DELETE))
						{
							;//TransmitStrToPC(("File does not exist!"));
						}
						return 0;   
					}
			
					if((dir->name[0] != DELETED) && (dir->attrib != ATTR_LONG_NAME))
					{
						if((lucFlag == GET_FILE) || (lucFlag == DELETE))
						{
							for(j=0; j<11; j++)
							{
								if(dir->name[j] != fileName[j]) break; //JP
							}
							if(j == 11)
							{
								if(lucFlag == GET_FILE)
								{
									gulAppendFileSector = lulFirstSector + lulSector;
									gulAppendFileLocation = i;
									gusAppendStartCluster = (((unsigned long) dir->firstClusterHI) << 16) | dir->firstClusterLO;  //JP
									fileSize = dir->fileSize;	// JP
										return (dir);
								}	
								else    //when lucFlag = DELETE
								{
									//TX_NEWLINE;
									//TransmitStrToPC(("Deleting.."));
									//TX_NEWLINE;
									//TX_NEWLINE;
									
									lulFirstCluster = (((unsigned long) dir->firstClusterHI) << 16) | dir->firstClusterLO;			
									//mark file as 'deleted' in FAT table
									dir->name[0] = DELETED;  
									for(lusTemp1 = 0; lusTemp1 < 512; lusTemp1++)
									{
										if(lusTemp1 <= 259)
										{
											SDbuf1[lusTemp1] = SDbuffer[lusTemp1];
										}
										else
										{
											SDbuf2[lusTemp1-260] = SDbuffer[lusTemp1];
										}
									}
									SD_writeSingleBlock (lulFirstSector+lulSector);
												 
									fileSize = dir->fileSize;	// JP
									
									freeMemoryUpdate (ADD, fileSize);

									//update next free cluster entry in FSinfo sector
									lulCluster = getSetFreeCluster (NEXT_FREE, GET, 0); 
									if(lulFirstCluster < lulCluster)
									getSetFreeCluster (NEXT_FREE, SET, lulFirstCluster);

									//mark all the clusters allocated to the file as 'free'
									while(1)  
									{
										lulNextCluster = getSetNextCluster (lulFirstCluster, GET, 0);
										getSetNextCluster (lulFirstCluster, SET, 0);
										if(lulNextCluster > 0x0ffffff6) 
										{
											//TransmitStrToPC(("File deleted!"));
											gucFileDelStatus = 2;
											return 0;
										}
										lulFirstCluster = lulNextCluster;
										} 
									}//else    //when lucFlag = DELETE
								}//if(j == 11)
							}
							else  //when lucFlag = GET_LIST
							{
								
//								TX_NEWLINE;
								
								for(j=0; j<11; j++)
								{
								 if(j == 8) TransmitChar(' ');
									TransmitChar (dir->name[j]);
								 //TransmitChar (buf1[j]);
								}

								if((dir->attrib != 0x10) && (dir->attrib != 0x08))
								{
									fileSize = fnShiftLong(BUF1, 31);
									displayMemory (LOW, dir->fileSize);
									//displayMemory (LOW, fileSize);
								}
								else
								{
									if(dir->attrib == 0x10)
									{
										;//TransmitStrToPC("DIR");
									}
									else
									{
										;//TransmitStrToPC("ROOT");
									}
									
									//TransmitStrToPC((dir->attrib == 0x10)? ("DIR") : ("ROOT"));
								}
							
							}//else  //when lucFlag = GET_LIST	
						 
						}//if((dir->name[0] != DELETED) && (dir->attrib != ATTR_LONG_NAME))
				
					}//for(i=0; i<gusBytesPerSector; i+=32)
					
				}// for(lulSector = 0; lulSector < gusSectorPerCluster; lulSector++)

				lulCluster = (getSetNextCluster (lulCluster, GET, 0));

				if(lulCluster > 0x0ffffff6)
					return 0;
				if(lulCluster == 0) 
				{
					//TransmitStrToPC(("Error in getting cluster"));  
					return 0;
				}
		}// while(1)
	//return 0;
}




/*==========================================================================================
//Function: if flag=READ then to read file from SD card and send contents to UART 
//if flag=VERIFY then functions will verify whether a specified file is already existing
//Arguments: flag (READ or VERIFY) and pointer to the file name
//Return: 0, if normal operation or flag is READ
//	      1, if file is already existing and flag = VERIFY
//		  2, if file name is incompatible
==========================================================================================*/
unsigned char readFile (unsigned char lucFlag, unsigned char *fileName)
{
	#pragma pack(1)
	__packed struct dir_Structure *dir;
	unsigned long lulCluster, lulByteCounter = 0, lulFirstSector;
	unsigned short k;
	unsigned char j, lucError;
	unsigned char laucFN[12];
	unsigned char *lpFN;

	lpFN = &laucFN[0];
	
	for(j = 0; j < 12; j++)
	{
		laucFN[j] = fileName[j];
	}
	
	lucError = convertFileName (lpFN); //convert fileName into FAT format
	if(lucError) return 2;

	dir = findFiles (GET_FILE, lpFN); //get the file location
	if(dir == 0) 
		return (0);

	if(lucFlag == VERIFY) return (1);	//specified file name is already existing

	lulCluster = (((unsigned long) dir->firstClusterHI) << 16) | dir->firstClusterLO;
	fileSize = dir->fileSize;

//	TX_NEWLINE;
//	TX_NEWLINE;

	while(1)
	{
		lulFirstSector = getFirstSector (lulCluster);

		for(j=0; j<gusSectorPerCluster; j++)
		{
			SD_readSingleBlock(lulFirstSector + j);
				
			for(k=0; k<512; k++)
			{
				if(k <= 259)
				{
					TransmitChar(SDbuf1[k]);
				}
				else
				{
					TransmitChar(SDbuf2[k-260]);
				}

				if ((lulByteCounter++) >= fileSize ) return 0;
			}//for(k=0; k<512; k++)
		}//for(j=0; j<gusSectorPerCluster; j++)
		
		lulCluster = getSetNextCluster (lulCluster, GET, 0);
		if(lulCluster == 0) 
		{
//		TransmitStrToPC(("Error in getting cluster")); 
//			MsgPrint(MSG_MEM,0,"Error in getting cluster");
		return 0;
		}
	}
	//return 0;
}


/*==========================================================================================
//Function: to convert normal short file name into FAT format
//Arguments: pointer to the file name
//Return: 0, if successful else 1.
==========================================================================================*/
unsigned char convertFileName (unsigned char *fileName)
{
	unsigned char laucFileNameFAT[11];
	unsigned char j, k;

	for(j=0; j<12; j++)
	if(fileName[j] == '.') break;

	if(j>8) {//TransmitStrToPC_F(PSTR("Invalid fileName..")); 
	return 1;
	}

	for(k=0; k<j; k++) //setting file name
		laucFileNameFAT[k] = fileName[k];

	for(k=j; k<=7; k++) //filling file name trail with blanks
		laucFileNameFAT[k] = ' ';

	j++;
	for(k=8; k<11; k++) //setting file extention
	{
		if(fileName[j] != 0)
			laucFileNameFAT[k] = fileName[j++];
		else //filling extension trail with blanks
			while(k<11)
				laucFileNameFAT[k++] = ' ';
	}

	for(j=0; j<11; j++) //converting small letters to caps
		if((laucFileNameFAT[j] >= 0x61) && (laucFileNameFAT[j] <= 0x7a))
			laucFileNameFAT[j] -= 0x20;

	for(j=0; j<11; j++)
		fileName[j] = laucFileNameFAT[j];

	return 0;
}

	
/*==========================================================================================
//Function: to create a file in FAT32 format in the root directory if given 
//			file name does not exist; if the file already exists then append the data
//Arguments: pointer to the file name
//Return: none
==========================================================================================*/
void writeFile (unsigned char *fileName)
{
#if 1
	unsigned char j, lucData, lucError, lucFileCreatedFlag = 0, lucStart = 0, lucAppendFile = 0, lucSectorEndFlag = 0, lucSector=0;
	unsigned short i, lusFirstClusterHigh=0, lusFirstClusterLow=0;  //value 0 is assigned just to avoid warning in compilation
	struct dir_Structure *dir;
	unsigned long lulCluster, lulNextCluster, lulPrevCluster, lulFirstSector, lulClusterCount, lulExtraMemory;
	unsigned long lulTempVar;
	unsigned short lusTemp;
	unsigned char laucData[27] = "File Created SuccessFully~";
	unsigned char lucIndex = 0;
	unsigned short z = 0;


	j = readFile (VERIFY, fileName);

	if(j == 1) 
	{ 
#ifdef DEBUG_EN
		TransmitStrToPC((" File exists, appending lucData..")); 
#endif		
		lucAppendFile = 1;
		lulCluster = gusAppendStartCluster;
		lulClusterCount=0;
		while(1)
		{
			lulNextCluster = getSetNextCluster (lulCluster, GET, 0);
			if(lulNextCluster == CARD_EOF) break;
			lulCluster = lulNextCluster;
			lulClusterCount++;
		}

		lucSector = (fileSize - (lulClusterCount * gusSectorPerCluster * gusBytesPerSector)) / gusBytesPerSector; //last lucSector number of the last cluster of the file
		lucStart = 1;
		//appendFile();
		//return;
	}
	else if(j == 2) 
	{
		 return; //invalid file name
	}
	else
	{
#ifdef DEBUG_EN
		TX_NEWLINE;
		TransmitStrToPC((" Creating File.."));
#endif
		lulCluster = getSetFreeCluster (NEXT_FREE, GET, 0);
		if(lulCluster > gulTotalClusters)
			 lulCluster = gulRootCluster;

		lulCluster = searchNextFreeCluster(lulCluster);
		if(lulCluster == 0)
		{
#ifdef DEBUG_EN
			TX_NEWLINE;
			TransmitStrToPC((" No free cluster!"));
#endif			
			return;
		}
		getSetNextCluster(lulCluster, SET, CARD_EOF);   //last cluster of the file, marked EOF
		 
		lusFirstClusterHigh = (unsigned short) ((lulCluster & 0xffff0000) >> 16 );
		lusFirstClusterLow = (unsigned short) ( lulCluster & 0x0000ffff);
		fileSize = 0;
	}



	while(1)
	{
		if(lucStart)
		{
			lucStart = 0;
			SDstartBlock = getFirstSector (lulCluster) + lucSector;
			SD_readSingleBlock (SDstartBlock);
			i = fileSize % gusBytesPerSector;
			j = lucSector;
		}
		else
		{
			SDstartBlock = getFirstSector (lulCluster);
			i=0;
			j=0;
		}
		 

		//TX_NEWLINE;
		//TransmitStrToPC((" Enter text (end with ~):"));
		lucIndex = 0;
		
		do
		{
		 if(lucSectorEndFlag == 1) //special case when the last character in previous sector was '\r'
		{
		TransmitChar ('\n');
				SDbuffer[i++] = '\n'; //appending 'Line Feed (LF)' character

		fileSize++;
		}

		lucSectorEndFlag = 0;

		 //lucData = receiveByte();
		 lucData = laucData[lucIndex];
		 lucIndex++;
		 if(lucData == 0x08)	//'Back Space' key pressed
		 { 
			 if(i != 0)
			 { 
				 TransmitChar(lucData);
			 TransmitChar(' '); 
				 TransmitChar(lucData); 
				 i--; 
			 fileSize--;
			 } 
			 continue;     
		 }
		 TransmitChar(lucData);
		 SDbuffer[i] = lucData;
		 z=i;
		 if(z <= 259)
		 {
			 SDbuf1[z] = lucData;
		 }
		 else
		 {
			 SDbuf2[z-260] = lucData;
		 }
		 
		 i++;
		 fileSize++;
		 if(lucData == '\r')  //'Carriege Return (CR)' character
		 {
			if(i == 512)
			lucSectorEndFlag = 1;  //lucFlag to indicate that the appended '\n' char should be put in the next sector
			else
			{ 
				 TransmitChar ('\n');
						 SDbuffer[i++] = '\n'; //appending 'Line Feed (LF)' character
				 fileSize++;
			}
		 }
		 
		 if(i >= 512)   //though 'i' will never become greater than 512, it's kept here to avoid 
		 {				//infinite loop in case it happens to be greater than 512 due to some data corruption
			 i=0;
			 lucError = SD_writeSingleBlock (SDstartBlock);
			 j++;
			 if(j == gusSectorPerCluster) {j = 0; break;}
			 SDstartBlock++; 
		 }
		}while (lucData != '~');
	
#ifdef DEBUG_EN
		TX_NEWLINE;
		TransmitStrToPC((" Char end received"));
#endif		
		if(lucData == '~') 
		{
			fileSize--;	//to remove the last entered '~' character
			i--;
			for(;i<512;i++)  //fill the rest of the SDbuffer with 0x00
			{
				SDbuffer[i]= 0x00;
				if(i <= 259)
				{
					SDbuf1[i] = 0x00;
				}
				else
				{
					SDbuf2[i-260] = 0x00;
				}
			}
			lucError = SD_writeSingleBlock (SDstartBlock);

			break;
		} 
			
		lulPrevCluster = lulCluster;

		lulCluster = searchNextFreeCluster(lulPrevCluster); //look for a free cluster starting from the current cluster

		if(lulCluster == 0)
		{
#ifdef DEBUG_EN
			TX_NEWLINE;
			TransmitStrToPC((" No free cluster - 1!"));
#endif			
			return;
		}

		getSetNextCluster(lulPrevCluster, SET, lulCluster);
		getSetNextCluster(lulCluster, SET, CARD_EOF);   //last cluster of the file, marked EOF
	}        

	getSetFreeCluster (NEXT_FREE, SET, lulCluster); //update FSinfo next free cluster entry

#if 1
	lucError = getDateTime_FAT(24, 6, 12, 11, 54, 30);    //get current date & time from the RTC
#endif
#if 1
	if(lucError) { dateFAT = 0; timeFAT = 0;}
#endif

	if(lucAppendFile)  //executes this loop if file is to be appended
	{
		SD_readSingleBlock (gulAppendFileSector);   
		dir = (struct dir_Structure *) &SDbuffer[gulAppendFileLocation]; 

		dir->lastAccessDate = 0;   //date of last access ignored JP
#if 1
		dir->writeTime = timeFAT;  //setting new time of last write, obtained from RTC
		dir->writeDate = dateFAT;  //setting new date of last write, obtained from RTC
		if(gulAppendFileLocation<=259)
		{
			SDbuf1[gulAppendFileLocation+22] = (u8)timeFAT;
			SDbuf1[gulAppendFileLocation+23] = (u8)(timeFAT>>8);
			SDbuf1[gulAppendFileLocation+24] = (u8)dateFAT;
			SDbuf1[gulAppendFileLocation+25] = (u8)(dateFAT>>8);
		}
		else
		{
			SDbuf2[gulAppendFileLocation+22-260] = (u8)timeFAT;
			SDbuf2[gulAppendFileLocation+23-260] = (u8)(timeFAT>>8);
			SDbuf2[gulAppendFileLocation+24-260] = (u8)dateFAT;
			SDbuf2[gulAppendFileLocation+25-260] = (u8)(dateFAT>>8);
		}
		
		
		
#endif
		
		//lulTempVar = fnShiftLong(BUF1, 31);				   
		lulExtraMemory = fileSize - dir->fileSize;	 //JP
		dir->fileSize = fileSize;

		/*lulExtraMemory = fileSize - lulTempVar; //JP*/
		lulTempVar = fileSize;
		if(gulAppendFileLocation<=259)
		{
			SDbuf1[gulAppendFileLocation+28] = (u8)lulTempVar;  lulTempVar >>= 8;
			SDbuf1[gulAppendFileLocation+29] = (u8)lulTempVar;  lulTempVar >>= 8;
			SDbuf1[gulAppendFileLocation+30] = (u8)lulTempVar;  lulTempVar >>= 8;
			SDbuf1[gulAppendFileLocation+31] = (u8)lulTempVar;
    }
		else
		{
			SDbuf1[gulAppendFileLocation+28-260] = (u8)lulTempVar;  lulTempVar >>= 8;
			SDbuf2[gulAppendFileLocation+29-260] = (u8)lulTempVar;  lulTempVar >>= 8;
			SDbuf2[gulAppendFileLocation+30-260] = (u8)lulTempVar;  lulTempVar >>= 8;
			SDbuf2[gulAppendFileLocation+31-260] = (u8)lulTempVar;
		}
		
		SD_writeSingleBlock (gulAppendFileSector);
		freeMemoryUpdate (REMOVE, lulExtraMemory); //updating free memory count in FSinfo sector;
		
#ifdef DEBUG_EN
		TX_NEWLINE;
		TransmitStrToPC((" File appended!"));
		//TX_NEWLINE;
#endif
		return;
	}

#ifdef DEBUG_EN
	TX_NEWLINE;
	TransmitStrToPC((" File going on!"));
	//executes following portion when new file is created
#endif
	lulPrevCluster = gulRootCluster; //root cluster

	while(1)
	{
		 lulFirstSector = getFirstSector (lulPrevCluster);

		 for(lucSector = 0; lucSector < gusSectorPerCluster; lucSector++)
		 {
			 SD_readSingleBlock (lulFirstSector + lucSector);

			 for(i=0; i<gusBytesPerSector; i+=32)
			 {
				dir = (struct dir_Structure *) &SDbuffer[i];

				if(lucFileCreatedFlag)   //to mark last directory entry with 0x00 (empty) mark
				{ 					  //indicating end of the directory file list
				 //dir->name[0] = EMPTY;
				 //SD_writeSingleBlock (lulFirstSector + lucSector);
				 return;
				}

				if((dir->name[0] == EMPTY) || (dir->name[0] == DELETED))  //looking for an empty slot to enter file info
				{
					for(j=0; j<11; j++)
					{
						dir->name[j] = fileName[j];
						SDbuf1[i+j] = fileName[j];

					}
					
					dir->attrib = ATTR_ARCHIVE;	//settting file attribute as 'archive'
					dir->NTreserved = 0;			//always set to 0
					dir->timeTenth = 0;			//always set to 0
					dir->createTime = timeFAT; 	//setting time of file creation, obtained from RTC
					dir->createDate = dateFAT; 	//setting date of file creation, obtained from RTC
					dir->lastAccessDate = 0;   	//date of last access ignored
					dir->writeTime = timeFAT;  	//setting new time of last write, obtained from RTC
					dir->writeDate = dateFAT;  	//setting new date of last write, obtained from RTC
					dir->firstClusterHI = lusFirstClusterHigh;
					dir->firstClusterLO = lusFirstClusterLow;
					dir->fileSize = fileSize;
					
					if(i<=259)
					{
						SDbuf1[i+11] = ATTR_ARCHIVE;
						SDbuf1[i+12] = 0x10;
						SDbuf1[i+13] = 0x39;//6B;
						SDbuf1[i+14] = (u8)timeFAT;
						SDbuf1[i+15] = (u8)(timeFAT >> 8);
						SDbuf1[i+16] = (u8)dateFAT;
						SDbuf1[i+17] = (u8)(dateFAT >> 8);
						SDbuf1[i+18] = 0;
						SDbuf1[i+19] = 0x40;
						
						lusTemp = lusFirstClusterHigh;
						SDbuf1[i+20] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf1[i+21] = (u8)lusTemp;
						
						SDbuf1[i+22] = (u8)timeFAT;
						SDbuf1[i+23] = (u8)(timeFAT >> 8);
						SDbuf1[i+24] = (u8)dateFAT;
						SDbuf1[i+25] = (u8)(dateFAT >> 8);
						lusTemp = lusFirstClusterLow;
						SDbuf1[i+26] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf1[i+27] = (u8)lusTemp;
						lulTempVar = fileSize;
						SDbuf1[i+28] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf1[i+29] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf1[i+30] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf1[i+31] = (u8)lulTempVar;
					}
					else
					{
						SDbuf2[i+11-260] = ATTR_ARCHIVE;
						SDbuf2[i+12-260] = 0x10;
						SDbuf2[i+13-260] = 0x39;//6B;
						SDbuf2[i+14-260] = (u8)timeFAT;
						SDbuf2[i+15-260] = (u8)(timeFAT >> 8);
						SDbuf2[i+16-260] = (u8)dateFAT;
						SDbuf2[i+17-260] = (u8)(dateFAT >> 8);
						SDbuf2[i+18-260] = 0;
						SDbuf2[i+19-260] = 0x40;
						
						lusTemp = lusFirstClusterHigh;
						SDbuf2[i+20-260] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf2[i+21-260] = (u8)lusTemp;
						
						SDbuf2[i+22-260] = (u8)timeFAT;
						SDbuf2[i+23-260] = (u8)(timeFAT >> 8);
						SDbuf2[i+24-260] = (u8)dateFAT;
						SDbuf2[i+25-260] = (u8)(dateFAT >> 8);

						lusTemp = lusFirstClusterLow;
						SDbuf2[i+26-260] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf2[i+27-260] = (u8)lusTemp;
						
						lulTempVar = fileSize;
						SDbuf2[i+28-260] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf2[i+29-260] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf2[i+30-260] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf2[i+31-260] = (u8)lulTempVar;
					}

					SD_writeSingleBlock (lulFirstSector + lucSector);
					lucFileCreatedFlag = 1;

#ifdef DEBUG_EN
					TX_NEWLINE;
					TX_NEWLINE;
					TransmitStrToPC(" File Created! ");
#endif
					freeMemoryUpdate (REMOVE, fileSize); //updating free memory count in FSinfo sector
				 
				}
		 }
	 }

	 lulCluster = getSetNextCluster (lulPrevCluster, GET, 0);

	 if(lulCluster > 0x0ffffff6)
	 {
			if(lulCluster == CARD_EOF)   //this situation will come when total files in root is multiple of (32*gusSectorPerCluster)
			{  
				lulCluster = searchNextFreeCluster(lulPrevCluster); //find next cluster for root directory entries
				getSetNextCluster(lulPrevCluster, SET, lulCluster); //link the new cluster of root to the previous cluster
				getSetNextCluster(lulCluster, SET, CARD_EOF);  //set the new cluster as end of the root directory
			} 

			else
			{	
				//TransmitStrToPC(("End of Cluster Chain")); 
				return;
			}
	 }
	 if(lulCluster == 0) 
	 {
		 //TransmitStrToPC(("Error in getting cluster")); 
			return;
	 }
	 lulPrevCluster = lulCluster;

	 }// while(1);
	 
	 //return;
#endif
}



/*==========================================================================================
//Function: to search for the next free cluster in the root directory
//          starting from a specified cluster
//Arguments: Starting cluster
//Return: the next free cluster
==========================================================================================*/
unsigned long searchNextFreeCluster (unsigned long lulStartCluster)
{
	#pragma pack(1)
	__packed unsigned long lulCluster, *value, lulSector;
	unsigned char i;
			
	lulStartCluster -=  (lulStartCluster % 128);   //to start with the first file in a FAT sector
	for(lulCluster =lulStartCluster; lulCluster <gulTotalClusters; lulCluster+=128) 
	{
		lulSector = gulUnusedSectors + gusReservedSectorCount + ((lulCluster * 4) / gusBytesPerSector);
		SD_readSingleBlock(lulSector);
		for(i=0; i<128; i++)
		{
			 value = (unsigned long *) &SDbuffer[i*4];
			 if(((*value) & 0x0fffffff) == 0)
					return(lulCluster+i);
		}  
	} 

	return 0;
}


/*==========================================================================================
//Function: to display total memory and free memory of SD card, using UART
//Arguments: none
//Return: none
//Note: this routine can take upto 15sec for 1GB card (@1MHz clock)
//it tries to read from SD whether a free cluster count is stored, if it is stored
//then it will return immediately. Otherwise it will count the total number of
//free clusters, which takes time
==========================================================================================*/
void memoryStatistics (void)
{
	unsigned long lulFreeClusters, lulTotalClusterCount, lulCluster;
	unsigned long lulTotalMemory, lulFreeMemory;
	unsigned long lulSector, *value;
	unsigned short i = 0, j = 0;

	lulTotalMemory = gulTotalClusters * gusSectorPerCluster / 1024;
	lulTotalMemory *= gusBytesPerSector;

#ifdef	DEBUG_EN
	TX_NEWLINE;
	TX_NEWLINE;
	TransmitStrToPC("Total Memory: ");
#endif
	TotalSDMem = lulTotalMemory;
	displayMemory (HIGH, lulTotalMemory);

	lulFreeClusters = getSetFreeCluster (TOTAL_FREE, GET, 0);
	//lulFreeClusters = 0xffffffff;    
				
	if(lulFreeClusters > gulTotalClusters)
	{
		 gucFreeClusterCountUpdated = 0;
		 lulFreeClusters = 0;
		 lulTotalClusterCount = 0;
		 lulCluster = gulRootCluster;    
			while(1)
			{
				lulSector = gulUnusedSectors + gusReservedSectorCount + ((lulCluster * 4) / gusBytesPerSector) ;
				SD_readSingleBlock(lulSector);
				for(i=0; i<128; i++)
				{
					//value = (unsigned long *) &buffer[i*4];					
					j = i * 4;
					if(j <= 260)
					{
						value = (unsigned long *) &SDbuf1[j];
					}
					else
					{
						value = (unsigned long *) &SDbuf2[j-260];
					}
					
					if(((*value)& 0x0fffffff) == 0)
							lulFreeClusters++;
					
					 lulTotalClusterCount++;
					 if(lulTotalClusterCount == (gulTotalClusters+2)) break;
				}  
				if(i < 128) break;
				lulCluster+=128;
			} 
	}

	if(!gucFreeClusterCountUpdated)
		getSetFreeCluster (TOTAL_FREE, SET, lulFreeClusters); //update FSinfo next free cluster entry
	gucFreeClusterCountUpdated = 1;  //set flag
	lulFreeMemory = lulFreeClusters * gusSectorPerCluster / 1024;
	//lulFreeMemory = lulFreeMemory / 1024;
	lulFreeMemory *= gusBytesPerSector ;
	FreeSDMemory = lulFreeMemory;///1024;  // In MB 
#ifdef DEBUG_EN	
	TX_NEWLINE;
	TransmitStrToPC(" Free Memory: ");
#endif	
// 	displayMemory (HIGH, lulFreeMemory);
// 	lulFreeMemory = LIMIT_SD_FATSYSTEM ;  //for testing 
// 	TransmitStrToPC(" Free Memory: ");
#ifdef DEBUG_EN
 	displayMemory (HIGH, lulFreeMemory);
	TX_NEWLINE; 
#endif	

}



/*==========================================================================================
//Function: To convert the unsigned long value of memory into 
//          text string and send to UART
//Arguments: 1. unsigned char flag. If flag is HIGH, memory will be displayed in KBytes, else in Bytes. 
//			 2. unsigned long memory value
//Return: none
==========================================================================================*/
void displayMemory (unsigned char lucFlag, unsigned long memory)
{
	unsigned char memoryString[] = "              Bytes"; //19 character long string for memory display
	unsigned char i;
	
	for(i=12; i>0; i--) //converting freeMemory into ASCII string
	{
		if(i==5 || i==9) 
		{
			memoryString[i-1] = ',';  
			i--;
		}
		memoryString[i-1] = (memory % 10) | 0x30;
		memory /= 10;
		if(memory == 0) break;
	}
	if(lucFlag == HIGH)  
	{
			memoryString[13] = 'K';
	}
#ifdef DEBUG_EN	
	TransmitStrToPC(memoryString);
#endif	
}


/*==========================================================================================
//Function: to delete a specified file from the root directory
//Arguments: pointer to the file name
//Return: status
==========================================================================================*/
unsigned char ucFnDeleteFile (unsigned char *fileName)
{
	unsigned char lucError;
	SET_SD_CS_LOW();

	lucError = convertFileName (fileName);
	if(lucError) return 1;

	findFiles (DELETE, fileName);
	
	if(gucFileDelStatus == 2)
	{
		return 0;	// File deleted successfully
	}
	else
	{
		return 1; // Error in deleting file
	}
}


/*==========================================================================================
//Function: update the free memory count in the FSinfo sector. 
//			Whenever a file is deleted or created, this function will be called
//			to ADD or REMOVE clusters occupied by the file
//Arguments: #1.flag ADD or REMOVE #2.file size in Bytes
//Return: none
==========================================================================================*/
void freeMemoryUpdate (unsigned char lucFlag, unsigned long lulSize)
{
	unsigned long lulFreeClusters;
	//convert file lulSize into number of clusters occupied
	if((lulSize % 512) == 0) lulSize = lulSize / 512;
	else lulSize = (lulSize / 512) +1;
	if((lulSize % 8) == 0) lulSize = lulSize / 8;
	else lulSize = (lulSize / 8) +1;

	if(gucFreeClusterCountUpdated)
	{
	lulFreeClusters = getSetFreeCluster (TOTAL_FREE, GET, 0);
	if(lucFlag == ADD)
			 lulFreeClusters = lulFreeClusters + lulSize;
	else  //when lucFlag = REMOVE
		 lulFreeClusters = lulFreeClusters - lulSize;
	getSetFreeCluster (TOTAL_FREE, SET, lulFreeClusters);
	}
}

/*==========================================================================================
Function:u8 ucFnSetFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize)
Inputs: 
1. Pointer to the FileName
2. Pointer to the Buffer holding the data to be written in the file
3. DataSize
Return : 
0. Success: File Created and Data Written
1. File Exists
2. Invalid FileName
3. No free Cluster
4. Error in getting cluster

==========================================================================================*/
u8 ucFnSetFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize)
{
	unsigned short j;
	unsigned char lucData, lucError, lucFileCreatedFlag = 0, lucStart = 0, lucSectorEndFlag = 0, lucSector=0;
	unsigned short i, lusFirstClusterHigh=0, lusFirstClusterLow=0;  //value 0 is assigned just to avoid warning in compilation
	unsigned long lulCluster, lulPrevCluster, lulFirstSector;
	unsigned long lulTempVar;
	unsigned short lusTemp;
	unsigned short lusDataCnt = 0;
	//unsigned char laucData[27] = "File Created SuccessFully~";
	unsigned char lucIndex = 0;
	unsigned short z = 0;
	__packed struct dir_Structure *dir;
	unsigned char laucFN[12];
	unsigned char *lpFN;

	SET_SD_CS_LOW();
	lpFN = &laucFN[0];
	
	for(j = 0; j < 12; j++)
	{
		laucFN[j] = pFN[j];
	}

	lucError = readFile (VERIFY, lpFN);
	
	if(lucError == 2)
	{
#ifdef	DEBUG_EN	
		TX_NEWLINE;
//    	MsgPrint(MSG_WARNING,0," Invalid File Name..");
//		TransmitStrToPC((" Invalid File Name.."));
#endif		
		return 2; //Invalid File Name
	}
	else if(lucError == 1)
	{
#ifdef	DEBUG_EN	
		TX_NEWLINE;
//		TransmitStrToPC(" File Exists. Cannot Create New File of Same Name..");
//		MsgPrint(MSG_WARNING,0," File Exists. Cannot Create New File of Same Name..");
#endif		
		return 1; // File Exists. Cannot Create new file
	}
	else // 
	{
#ifdef	DEBUG_EN	
		//TX_NEWLINE;
		//TransmitStrToPC((" Creating File.."));
//		MsgPrint(MSG_WARNING,0," Creating File..");
#endif
		
		lucError = convertFileName (lpFN); //convert fileName into FAT format
		if(lucError) return 2;
		
		lulCluster = getSetFreeCluster (NEXT_FREE, GET, 0);
		if(lulCluster > gulTotalClusters)
			 lulCluster = gulRootCluster;

		lulCluster = searchNextFreeCluster(lulCluster);
		if(lulCluster == 0)
		{
#ifdef	DEBUG_EN
			TX_NEWLINE;
//			TransmitStrToPC((" No free cluster!"));
//     		MsgPrint(MSG_WARNING,0," No free cluster!");
#endif			
			return 3;
		}
		getSetNextCluster(lulCluster, SET, CARD_EOF);   //last cluster of the file, marked EOF
		 
		lusFirstClusterHigh = (unsigned short) ((lulCluster & 0xffff0000) >> 16 );
		lusFirstClusterLow = (unsigned short) ( lulCluster & 0x0000ffff);
		fileSize = 0;
	}

	lusDataCnt = 0;
	while(1)
	{
		if(lucStart)
		{
			lucStart = 0;
			SDstartBlock = getFirstSector (lulCluster) + lucSector;
			SD_readSingleBlock (SDstartBlock);
			i = fileSize % gusBytesPerSector;
			j = lucSector;
		}
		else
		{
			SDstartBlock = getFirstSector (lulCluster);
			i=0;
			j=0;
		}
		 
		lucIndex = 0;
		
		do
		{
			if(lucSectorEndFlag == 1) //special case when the last character in previous sector was '\r'
			{
#ifdef	DEBUG_EN
//				TransmitChar ('\n');
#endif				
				SDbuffer[i++] = '\n'; //appending 'Line Feed (LF)' character
				fileSize++;
			}

			lucSectorEndFlag = 0;

			// Get the Next Byte
			//lucData = laucData[lucIndex];
			lucData = pBuf[lucIndex];
			lucIndex++;
			lusDataCnt++;
#ifdef	DEBUG_EN
			//TransmitChar(lucData);
#endif
			SDbuffer[i] = lucData;
			z=i;
			if(z <= 259)
			{
				SDbuf1[z] = lucData;
			}
			else
			{
				SDbuf2[z-260] = lucData;
			}
		 
			i++;
			fileSize++;
			if(lucData == '\r')  //'Carriege Return (CR)' character
			{
				if(i == 512)
				lucSectorEndFlag = 1;  //lucFlag to indicate that the appended '\n' char should be put in the next sector
				else
				{ 
#ifdef	DEBUG_EN
//					TransmitChar ('\n');
#endif					
					 //buffer[i++] = '\n'; //appending 'Line Feed (LF)' character
					if(i <= 259)
					{
						SDbuf1[i] = '\n';
					}
					else
					{
						SDbuf2[i-260] = '\n';
					}
					 fileSize++;
				}
			}
		 
			if(i >= 512)   //though 'i' will never become greater than 512, it's kept here to avoid 
			{			       	//infinite loop in case it happens to be greater than 512 due to some data corruption
				i=0;
				lucError = SD_writeSingleBlock (SDstartBlock);
				j++;
				if(j == gusSectorPerCluster) {j = 0; break;}
				SDstartBlock++; 
			}
		
		}while (lusDataCnt < lusDataSize); //(lucData != '~');
		
		
		//lusDataCnt++;

#ifdef DEBUG_EN	
		//TX_NEWLINE;
//     	 MsgPrint(MSG_WARNING,0," Char end received" );
		//TransmitStrToPC((" Char end received"));
#endif
		
		if(lusDataCnt == lusDataSize)
		{
			//fileSize--;	//to remove the last entered '~' character
			//i--;
			for(;i<512;i++)  //fill the rest of the buffer with 0x00
			{
				SDbuffer[i]= 0x00;
				if(i <= 259)
				{
					SDbuf1[i] = 0x00;
				}
				else
				{
					SDbuf2[i-260] = 0x00;
				}
			}
			lucError = SD_writeSingleBlock (SDstartBlock);

			break;
		} 
			
		lulPrevCluster = lulCluster;

		lulCluster = searchNextFreeCluster(lulPrevCluster); //look for a free cluster starting from the current cluster

		if(lulCluster == 0)
		{
#ifdef DEBUG_EN
			//TX_NEWLINE;
//     	     MsgPrint(MSG_WARNING,0," No free cluster - 1!");
			//TransmitStrToPC((" No free cluster - 1!"));
#endif			
			return 3;
		}

		getSetNextCluster(lulPrevCluster, SET, lulCluster);
		getSetNextCluster(lulCluster, SET, CARD_EOF);   //last cluster of the file, marked EOF
	}        
	
	
	getSetFreeCluster (NEXT_FREE, SET, lulCluster); //update FSinfo next free cluster entry

	lucError = getDateTime_FAT(24, 6, 12, 11, 54, 30);    //get current date & time 
	if(lucError) { dateFAT = 0; timeFAT = 0;}

	//executes following portion when new file is created
	lulPrevCluster = gulRootCluster; //root cluster

	while(1)
	{
		 lulFirstSector = getFirstSector (lulPrevCluster);

		 for(lucSector = 0; lucSector < gusSectorPerCluster; lucSector++)
		 {
			 SD_readSingleBlock (lulFirstSector + lucSector);

			 for(i=0; i<gusBytesPerSector; i+=32)
			 {
				dir = (struct dir_Structure *) &SDbuffer[i];

				if(lucFileCreatedFlag)   //to mark last directory entry with 0x00 (empty) mark
				{ 					  //indicating end of the directory file list
				 //dir->name[0] = EMPTY;
				 //SD_writeSingleBlock (lulFirstSector + lucSector);
				 return 0;
				}

				if((dir->name[0] == EMPTY) || (dir->name[0] == DELETED))  //looking for an empty slot to enter file info
				{
					for(j=0; j<11; j++)
					{
						dir->name[j] = lpFN[j];
						SDbuf1[i+j] = lpFN[j];

					}
					
					dir->attrib = ATTR_ARCHIVE;	//settting file attribute as 'archive'
					dir->NTreserved = 0;			//always set to 0
					dir->timeTenth = 0;			//always set to 0
					dir->createTime = timeFAT; 	//setting time of file creation, obtained from RTC
					dir->createDate = dateFAT; 	//setting date of file creation, obtained from RTC
					dir->lastAccessDate = 0;   	//date of last access ignored
					dir->writeTime = timeFAT;  	//setting new time of last write, obtained from RTC
					dir->writeDate = dateFAT;  	//setting new date of last write, obtained from RTC
					dir->firstClusterHI = lusFirstClusterHigh;
					dir->firstClusterLO = lusFirstClusterLow;
					dir->fileSize = fileSize;
					

					if(i<=259)
					{
						SDbuf1[i+11] = ATTR_ARCHIVE;
						SDbuf1[i+12] = 0x10;
						SDbuf1[i+13] = 0x39;//6B;
						SDbuf1[i+14] = (u8)timeFAT;
						SDbuf1[i+15] = (u8)(timeFAT >> 8);
						SDbuf1[i+16] = (u8)dateFAT;
						SDbuf1[i+17] = (u8)(dateFAT >> 8);
						SDbuf1[i+18] = 0;
						SDbuf1[i+19] = 0x40;
						
						lusTemp = lusFirstClusterHigh;
						SDbuf1[i+20] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf1[i+21] = (u8)lusTemp;
						
						SDbuf1[i+22] = (u8)timeFAT;
						SDbuf1[i+23] = (u8)(timeFAT >> 8);
						SDbuf1[i+24] = (u8)dateFAT;
						SDbuf1[i+25] = (u8)(dateFAT >> 8);
						lusTemp = lusFirstClusterLow;
						SDbuf1[i+26] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf1[i+27] = (u8)lusTemp;
						lulTempVar = fileSize;
						SDbuf1[i+28] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf1[i+29] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf1[i+30] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf1[i+31] = (u8)lulTempVar;
					}
					else
					{
						SDbuf2[i+11-260] = ATTR_ARCHIVE;
						SDbuf2[i+12-260] = 0x10;
						SDbuf2[i+13-260] = 0x39;//6B;
						SDbuf2[i+14-260] = (u8)timeFAT;
						SDbuf2[i+15-260] = (u8)(timeFAT >> 8);
						SDbuf2[i+16-260] = (u8)dateFAT;
						SDbuf2[i+17-260] = (u8)(dateFAT >> 8);
						SDbuf2[i+18-260] = 0;
						SDbuf2[i+19-260] = 0x40;
						
						lusTemp = lusFirstClusterHigh;
						SDbuf2[i+20-260] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf2[i+21-260] = (u8)lusTemp;
						
						SDbuf2[i+22-260] = (u8)timeFAT;
						SDbuf2[i+23-260] = (u8)(timeFAT >> 8);
						SDbuf2[i+24-260] = (u8)dateFAT;
						SDbuf2[i+25-260] = (u8)(dateFAT >> 8);

						lusTemp = lusFirstClusterLow;
						SDbuf2[i+26-260] = (u8)lusTemp;  lusTemp >>= 8;
						SDbuf2[i+27-260] = (u8)lusTemp;
						
						lulTempVar = fileSize;
						SDbuf2[i+28-260] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf2[i+29-260] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf2[i+30-260] = (u8)lulTempVar;  lulTempVar >>= 8;
						SDbuf2[i+31-260] = (u8)lulTempVar;
					}


				
					SD_writeSingleBlock (lulFirstSector + lucSector);
					lucFileCreatedFlag = 1;

#ifdef DEBUG_EN
					//TX_NEWLINE;
					//TX_NEWLINE;
					//TransmitStrToPC(" File Created! ");
//					MsgPrint(MSG_WARNING,0," File Created! ");
#endif
					freeMemoryUpdate (REMOVE, fileSize); //updating free memory count in FSinfo sector
				 
				}
		 }// for(i=0; i<gusBytesPerSector; i+=32)
	 }

	 lulCluster = getSetNextCluster (lulPrevCluster, GET, 0);

	 if(lulCluster > 0x0ffffff6)
	 {
			if(lulCluster == CARD_EOF)   //this situation will come when total files in root is multiple of (32*gusSectorPerCluster)
			{  
				lulCluster = searchNextFreeCluster(lulPrevCluster); //find next cluster for root directory entries
				getSetNextCluster(lulPrevCluster, SET, lulCluster); //link the new cluster of root to the previous cluster
				getSetNextCluster(lulCluster, SET, CARD_EOF);  //set the new cluster as end of the root directory
			} 

			else
			{	
#ifdef DEBUG_EN
				//TransmitStrToPC("End of Cluster Chain"); 
//				MsgPrint(MSG_WARNING,0,"End of Cluster Chain");
#endif				
				return 4;
			}
	 }
	 if(lulCluster == 0) 
	 {
#ifdef DEBUG_EN
		 //TransmitStrToPC("Error in getting cluster"); 
//		  MsgPrint(MSG_WARNING,0,"Error in getting cluster");
#endif
			return 4;
	 }
	 lulPrevCluster = lulCluster;

	 }// while(1)
	 //return 0;

}// u8 ucFnSetFile()



/*==========================================================================================
Function:u8 ucFnAppendFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize)
Inputs: 
1. Pointer to the FileName
2. Pointer to the Buffer holding the data to be written in the file
3. DataSize
Return : 
0. Success: Data Appended
1. File Does not Exists
2. Invalid FileName

==========================================================================================*/
u8 ucFnAppendFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize)
{
	unsigned short j;
	unsigned char lucData, lucError, lucStart = 0, lucSectorEndFlag = 0, lucSector=0, lucAppendFile;
	unsigned short i;  //value 0 is assigned just to avoid warning in compilation
	unsigned long lulCluster, lulPrevCluster, lulNextCluster, lulClusterCount, lulExtraMemory;
	unsigned long lulTempVar;
	unsigned short lusDataCnt = 0;
	//unsigned char laucData[27] = "File Created SuccessFully~";
	unsigned char lucIndex = 0;
	unsigned short z = 0;
	#pragma pack(1)
	__packed struct dir_Structure *dir;
	
	SET_SD_CS_LOW();

	lucError = readFile (VERIFY, pFN);
	
	if(lucError == 2)//Invalid File Name
	{
#ifdef	DEBUG_EN	
//		TX_NEWLINE;
//		TransmitStrToPC((" Invalid File Name.."));
//MsgPrint(MSG_WARNING,0," Invalid File Name..");
#endif		
		return 2; 
	}
	else if(lucError == 1) // File Exists
	{
#ifdef	DEBUG_EN	
		//TX_NEWLINE;
		//TransmitStrToPC((" File Exists. "));
//		MsgPrint(MSG_WARNING,0," File Exists. ");
#endif		
		
		lucAppendFile = 1;
		lulCluster = gusAppendStartCluster;
		lulClusterCount=0;
		while(1)
		{
			lulNextCluster = getSetNextCluster (lulCluster, GET, 0);
			if(lulNextCluster == CARD_EOF) break;
//			if(lulNextCluster == 0x0FFF8) break;
			lulCluster = lulNextCluster;
			lulClusterCount++;
		}

		lucSector = (fileSize - (lulClusterCount * gusSectorPerCluster * gusBytesPerSector)) / gusBytesPerSector; //last lucSector number of the last cluster of the file
		lucStart = 1;
		
		lusDataCnt = 0;
		while(1)
		{
			if(lucStart)
			{
				lucStart = 0;
				SDstartBlock = getFirstSector (lulCluster) + lucSector;
				SD_readSingleBlock (SDstartBlock);
				i = fileSize % gusBytesPerSector;
				j = lucSector;
			}
			else
			{
				SDstartBlock = getFirstSector (lulCluster);
				i=0;
				j=0;
			}
			 
			lucIndex = 0;
			
			do
			{
				if(lucSectorEndFlag == 1) //special case when the last character in previous sector was '\r'
				{
	#ifdef	DEBUG_EN
					TransmitChar ('\n');
	#endif				
					SDbuffer[i++] = '\n'; //appending 'Line Feed (LF)' character
					if(i <= 259)
					{
						SDbuf1[i] = '\n';
					}
					else
					{
						SDbuf2[i-260] = '\n';
					}
					fileSize++;
				}

				lucSectorEndFlag = 0;

				// Get the Next Byte
				//lucData = laucData[lucIndex];
				lucData = pBuf[lucIndex];
				lucIndex++;
				lusDataCnt++;
	#ifdef	DEBUG_EN
				//TransmitChar(lucData);
	#endif
				SDbuffer[i] = lucData;
				z=i;
				if(z <= 259)
				{
					SDbuf1[z] = lucData;
				}
				else
				{
					SDbuf2[z-260] = lucData;
				}
			 
				i++;
				fileSize++;
				if(lucData == '\r')  //'Carriege Return (CR)' character
				{
					if(i == 512)
					lucSectorEndFlag = 1;  //lucFlag to indicate that the appended '\n' char should be put in the next sector
					else
					{ 
						 TransmitChar ('\n');
						 SDbuffer[i++] = '\n'; //appending 'Line Feed (LF)' character
						 fileSize++;
					}
				}
			 
				if(i >= 512)   //though 'i' will never become greater than 512, it's kept here to avoid 
				{				//infinite loop in case it happens to be greater than 512 due to some data corruption
					i=0;
					lucError = SD_writeSingleBlock (SDstartBlock);
					j++;
					if(j == gusSectorPerCluster) {j = 0; break;}
					SDstartBlock++; 
				}
			
			}while (lusDataCnt < lusDataSize); //(lucData != '~');
			
			
			//lusDataCnt++;

	#ifdef DEBUG_EN	
			//TX_NEWLINE;
			//TransmitStrToPC((" Char end received"));
	#endif
			
			if(lusDataCnt == lusDataSize)
			{
				//fileSize--;	//to remove the last entered '~' character
				//i--;
				for(;i<512;i++)  //fill the rest of the buffer with 0x00
				{
					SDbuffer[i]= 0x00;
					if(i <= 259)
					{
						SDbuf1[i] = 0x00;
					}
					else
					{
						SDbuf2[i-260] = 0x00;
					}
				}
				lucError = SD_writeSingleBlock (SDstartBlock);

				break;
			} 
				
			lulPrevCluster = lulCluster;

			lulCluster = searchNextFreeCluster(lulPrevCluster); //look for a free cluster starting from the current cluster

			if(lulCluster == 0)
			{
	#ifdef DEBUG_EN
				//TX_NEWLINE;
				//TransmitStrToPC((" No free cluster - 1!"));
	#endif			
				return 3;
			}

			getSetNextCluster(lulPrevCluster, SET, lulCluster);
			getSetNextCluster(lulCluster, SET, CARD_EOF);   //last cluster of the file, marked EOF
		}        
		
		
		getSetFreeCluster (NEXT_FREE, SET, lulCluster); //update FSinfo next free cluster entry

		lucError = getDateTime_FAT(24, 6, 12, 11, 54, 30);    //get current date & time from the RTC
		if(lucError) { dateFAT = 0; timeFAT = 0;}


		if(lucAppendFile)  //executes this loop if file is to be appended
		{
			SD_readSingleBlock (gulAppendFileSector);   
			dir = (struct dir_Structure *) &SDbuffer[gulAppendFileLocation]; 

			dir->lastAccessDate = 0;   //date of last access ignored JP
			dir->writeTime = timeFAT;  //setting new time of last write, obtained from RTC
			dir->writeDate = dateFAT;  //setting new date of last write, obtained from RTC

			lulExtraMemory = fileSize - dir->fileSize;	 //JP
			dir->fileSize = fileSize;
			lulTempVar = fileSize;
			
			if(gulAppendFileLocation<=259)
			{			
				SDbuf1[gulAppendFileLocation+22] = (u8)timeFAT;
				SDbuf1[gulAppendFileLocation+23] = (u8)(timeFAT>>8);
				SDbuf1[gulAppendFileLocation+24] = (u8)dateFAT;
				SDbuf1[gulAppendFileLocation+25] = (u8)(dateFAT>>8);
				
				SDbuf1[gulAppendFileLocation+28] = (u8)lulTempVar;  lulTempVar >>= 8;
				SDbuf1[gulAppendFileLocation+29] = (u8)lulTempVar;  lulTempVar >>= 8;
				SDbuf1[gulAppendFileLocation+30] = (u8)lulTempVar;  lulTempVar >>= 8;
				SDbuf1[gulAppendFileLocation+31] = (u8)lulTempVar;
			}
			else
			{
				SDbuf2[gulAppendFileLocation+22-260] = (u8)timeFAT;
				SDbuf2[gulAppendFileLocation+23-260] = (u8)(timeFAT>>8);
				SDbuf2[gulAppendFileLocation+24-260] = (u8)dateFAT;
				SDbuf2[gulAppendFileLocation+25-260] = (u8)(dateFAT>>8);
				
				SDbuf2[gulAppendFileLocation+28-260] = (u8)lulTempVar;  lulTempVar >>= 8;
				SDbuf2[gulAppendFileLocation+29-260] = (u8)lulTempVar;  lulTempVar >>= 8;
				SDbuf2[gulAppendFileLocation+30-260] = (u8)lulTempVar;  lulTempVar >>= 8;
				SDbuf2[gulAppendFileLocation+31-260] = (u8)lulTempVar;
			}

			SD_writeSingleBlock (gulAppendFileSector);
			freeMemoryUpdate (REMOVE, lulExtraMemory); //updating free memory count in FSinfo sector;
			
			//TX_NEWLINE;
			//TransmitStrToPC((" File appended!"));
			//TX_NEWLINE;

			return 0;
		}
	}
	else // 
	{
#ifdef	DEBUG_EN	
		//TX_NEWLINE;
		//TransmitStrToPC((" File Does not Exist.."));
#endif
		return 1; // File Does not Exists
	}	
	
	return 1;

}// u8 ucFnAppendFile()


/*==========================================================================================
Function:u32 ulFnGetFileSize(unsigned char *pFN)
Inputs: 
1. Pointer to the FileName
Return : 
0. File Does not Exists or File Size 0 or Invalid File Name
Rest 1 - 0xFFFFFFFF to be considered as file size
==========================================================================================*/
u32 ulFnGetFileSize(unsigned char *pFN)
{
	u8 lucError;
	
	
	SET_SD_CS_LOW();
	lucError = readFile (VERIFY, pFN);
	
	if(lucError == 2) // Invalid File name
	{
		return 0;
	}
	else if(lucError == 1) // File Exists
	{
//#ifdef DEBUG_EN		
//		TX_NEWLINE;
//		TransmitStrToPC("File Size: "); 
		
		displayMemory(LOW, fileSize);
//#endif		
		return fileSize;
	}
	else
	{
		return 0; // File Does not exist
	}
}// ulFnGetFileSize


/*==========================================================================================
Function:u8 ucFnReadFileOffset(u8 *pFN, u8 *pBuf, u32 lulOffSet, u16 lusDataSize)
Inputs: 
1. Pointer to the FileName
2. Pointer to the Buffer in which the data is to be transferred
3. Offset from where the data is to be read (if first byte is to be read offset is to be 0)
3. DataSize (if 2 bytes are to be read, data size has to be 2)

Return : 
0. Success: File Read
1. Invalid FileName or Invalid File Location
2. Invalid Offset 
3. Invalid DataSize
==========================================================================================*/
u8 ucFnReadFileOffset(u8 *pFN, u8 *pBuf, u32 lulOffSet, u16 lusDataSize)
{
	#pragma pack(1)
	__packed struct dir_Structure *dir;
	unsigned long lulCluster, lulByteCounter = 0, lulFirstSector;
	unsigned short k;
	unsigned char j, lucError, lucStart;
	unsigned short lusInd = 0;
	
	unsigned char laucFN[12];
	unsigned char *lpFN;

	SET_SD_CS_LOW();
	
	lpFN = &laucFN[0];
	
	for(j = 0; j < 12; j++)
	{
		laucFN[j] = pFN[j];
	}
	
	
	lucError = convertFileName (lpFN); //convert fileName into FAT format
	if(lucError) return 1; // Invalid File Name

	dir = findFiles (GET_FILE, lpFN); //get the file location
	if(dir == 0) return 1; // Invalid File Location

	//specified file name is existing, Now Get the File Size
	lulCluster = (((unsigned long) dir->firstClusterHI) << 16) | dir->firstClusterLO;
	fileSize = dir->fileSize;

	//lusDataSize = fileSize;
	
	if(lulOffSet >= fileSize) 
	{
		return 2; // Invalid Offset
	}
	if( (lusDataSize == 0) || ((lulOffSet + lusDataSize) > fileSize))
	{
		//return 3; // Invalid Data Size
		lulOffSet = 0;
		lusDataSize = fileSize; // Return Whatever we have 
	}
	lucStart = 0;
	// Get the Cluster Number
	while(1)
	{
		lulFirstSector = getFirstSector (lulCluster);

		for(j=0; j<gusSectorPerCluster;)
		{
			if((lucStart == 1) || (lucStart == 2))
			{
				SD_readSingleBlock(lulFirstSector + j);
				if(lucStart == 1)
				{
					lusInd = 0; // Initialize only once
					lucStart = 2;
					
				}//if(lucStart == 1)
				
			}// if((lucStart == 1) || (lucStart == 2))
			
			for(k=0; k<512; k++)
			{
				if (lulByteCounter >= lulOffSet )
				{
					if(lucStart == 0)
					{
						lucStart = 1;
						lulByteCounter = lulByteCounter - k;
						break;
					}
					
					
					if(k <= 259)
					{
						pBuf[lusInd] = SDbuf1[k];
						TransmitChar(SDbuf1[k]);
					}
					else
					{
						pBuf[lusInd] = SDbuf2[k-260];
						TransmitChar(SDbuf2[k-260]);
					}
					lusInd++;
					if (lusInd >= lusDataSize) return 0;
					
					//lulByteCounter++;
				}
				lulByteCounter++;

			}// for(k=0;..
		
			if((lucStart == 0) || (lucStart == 2))
			{
				j++;
			}
				
			
		}// for(j=0;..
		
	}// while(1)
		
}


/*
Function:u8 ucFnSearchFile(u8 *pFN)
Inputs: 
1. Pointer to the FileName

Return : 
0. File Does not Exists or File Size 0 or Invalid File Name
1. File Exists
*/
u8 ucFnSearchFile(u8 *pFN)
{
	u8 lucError;
	
	SET_SD_CS_LOW();
	lucError = readFile (VERIFY, pFN);
	
	if(lucError == 2) // Invalid File name
	{
		return 0;
	}
	else if(lucError == 1) // File Exists
	{
#ifdef DEBUG_EN		
		TX_NEWLINE;
		TransmitStrToPC("File Exists..");
#endif		
		return 1;
	}
	else
	{
		return 0; // File Does not exist
	}
}// ucFnSearchFile


unsigned long fnShiftLong(unsigned char lucBufType, unsigned short i)
{
	unsigned long lulData = 0;

	if(lucBufType == 1)
	{
		lulData = SDbuf2[i];lulData <<= 8;
		lulData = lulData | SDbuf2[i - 1];lulData <<= 8;
		lulData = lulData | SDbuf2[i - 2];lulData <<= 8;
		lulData = lulData | SDbuf2[i - 3];
	}
	else
	{
		lulData = SDbuf1[i];lulData <<= 8;
		lulData = lulData | SDbuf1[i - 1];lulData <<= 8;
		lulData = lulData | SDbuf1[i - 2];lulData <<= 8;
		lulData = lulData | SDbuf1[i - 3];
	}
	return lulData;
}


unsigned short fnShiftShort(unsigned char lucBufType, unsigned short i)
{
	unsigned short lusData = 0;

	if(lucBufType == 1)
	{
		lusData = 0;
		lusData = SDbuf2[i];lusData <<= 8;
		lusData = lusData | SDbuf2[i - 1];
	}
	else
	{
		lusData = 0;
		lusData = SDbuf1[i];lusData <<= 8;
		lusData = lusData | SDbuf1[i - 1];
	}
	return lusData;
}


//******************************************************************
//Function to get RTC date & time in FAT32 format
//22-23   Time (5/6/5 bits, for hour/minutes/doubleseconds)
//24-25   Date (7/4/5 bits, for year-since-1980/month/day)
//******************************************************************   
unsigned char getDateTime_FAT(u8 dt1, u8 mth1, u16 yr1, u8 hr1, u8 min1, u8 sec1)
{
	
	timeFAT = 0;
	dateFAT = 0;
   //error = RTC_read();
   //if(error) return 1;

  yr1 = yr1+2000-1980;
  dateFAT = yr1;
  dateFAT = (dateFAT << 4) | mth1;
  dateFAT = (dateFAT << 5) | dt1;

	timeFAT = hr1;
  timeFAT = (timeFAT << 6) | min1;
  sec1 = sec1 / 2;    //FAT32 fromat accepts dates with 2sec resolution (e.g. value 5 => 10sec)
  timeFAT = (timeFAT << 5) | sec1;
   
  return 0;
}

void clearSDbuffer(void)	
{
	unsigned int i;
// 	for(i=0;i<=sizeof(SBuffer);i++)
// 	{
// 		  SBuffer[i] = '\0';
// 	}
	for(i=0;i<512;i++)
	{
     SDbuffer[i] = '\0';	
	}
	for(i=0;i<260;i++)
	{
		SDbuf1[i] = '\0';
	}
	for(i=0;i<260;i++)
	{
		SDbuf2[i] = '\0';
	}
}

#endif
/*--------------------------File Ends----------------------------*/
