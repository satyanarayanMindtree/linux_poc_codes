/*******************************************************
FileName: Fat32.h
Author:Creative
Description: ROUTINES FOR FAT32 IMPLEMATATION OF SD CARD
********************************************************/

#ifndef _FAT32_H_
#define _FAT32_H_

#include "NewSdMain.h"

#pragma pack(1)
//Structure to access Master Boot Record for getting info about partioions
__packed struct MBRinfo_Structure{
unsigned char	nothing[446];		//ignore, placed here to fill the gap in the structure
unsigned char	partitionData[64];	//partition records (16x4)
unsigned short	signature;		//0xaa55
};

#pragma pack(1)
//Structure to access info of the first partioion of the disk 
__packed struct partitionInfo_Structure{ 				
unsigned char	status;				//0x80 - active partition
unsigned char 	headStart;			//starting head
unsigned short	cylSectStart;		//starting cylinder and sector
unsigned char	type;				//partition type 
unsigned char	headEnd;			//ending head of the partition
unsigned short	cylSectEnd;			//ending cylinder and sector
unsigned long	firstSector;		//total sectors between MBR & the first sector of the partition
unsigned long	sectorsTotal;		//size of this partition in sectors
};

#pragma pack(1)
//Structure to access boot sector data
__packed struct BS_Structure{
unsigned char jumpBoot[3]; //default: 0x009000EB		 //  2
unsigned char OEMName[8];								 //  10
unsigned short bytesPerSector; //deafault: 512			 //  12
unsigned char sectorPerCluster;							 //  13
unsigned short reservedSectorCount;						 //  15
unsigned char numberofFATs;								 //  16
unsigned short rootEntryCount;							 //  18
unsigned short totalSectors_F16; //must be 0 for FAT32	 //  20
unsigned char mediaType;								 //  21
unsigned short FATsize_F16; //must be 0 for FAT32		     //  23
unsigned short sectorsPerTrack;							 //  25
unsigned short numberofHeads;								 //  27
unsigned long hiddenSectors;							 //  31
unsigned long totalSectors_F32;							 //  35
unsigned long FATsize_F32; //count of sectors occupied by one FAT 39
unsigned short extFlags;				 //41
unsigned short FSversion; //0x0000 (defines version 0.0)  43
unsigned long rootCluster; //first cluster of root directory (=2)  47
unsigned short FSinfo; //sector number of FSinfo structure (=1)
unsigned short BackupBootSector;
unsigned char reserved[12];
unsigned char driveNumber;
unsigned char reserved1;
unsigned char bootSignature;
unsigned long volumeID;
unsigned char volumeLabel[11]; //"NO NAME "
unsigned char fileSystemType[8]; //"FAT32"
unsigned char bootData[420];
unsigned short bootEndSignature; //0xaa55
};

#pragma pack(1)

//Structure to access FSinfo sector data
__packed struct FSInfo_Structure
{
unsigned long leadSignature; //0x41615252	3
unsigned char reserved1[480];				//483 		223
unsigned long structureSignature; //0x61417272	 //487	227
unsigned long freeClusterCount; //initial: 0xffffffff  491	231
unsigned long nextFreeCluster; //initial: 0xffffffff	  495  235
unsigned char reserved2[12];							 //507 247
unsigned long trailSignature; //0xaa550000					   251
};

#pragma pack(1)
//Structure to access Directory Entry in the FAT
__packed struct dir_Structure{
unsigned char name[11];				//10
unsigned char attrib; //file attributes	 11
unsigned char NTreserved; //always 0	  12
unsigned char timeTenth; //tenths of seconds, set to 0 here	   13
unsigned short createTime; //time file was created	  15
unsigned short createDate; //date file was created	  17
unsigned short lastAccessDate;						//19
unsigned short firstClusterHI; //higher word of the first cluster number 21
unsigned short writeTime; //time of last write					   23
unsigned short writeDate; //date of last write						 25
unsigned short firstClusterLO; //lower word of the first cluster number  27
unsigned long fileSize; //size of file in bytes						   31
};

//Attribute definitions for file/directory
#define ATTR_READ_ONLY     0x01
#define ATTR_HIDDEN        0x02
#define ATTR_SYSTEM        0x04
#define ATTR_VOLUME_ID     0x08
#define ATTR_DIRECTORY     0x10
#define ATTR_ARCHIVE       0x20
#define ATTR_LONG_NAME     0x0f


#define DIR_ENTRY_SIZE     0x32
#define EMPTY              0x00
#define DELETED            0xe5
#define GET     0
#define SET     1
#define READ	0
#define VERIFY  1
#define ADD		0
#define REMOVE	1
#define LOW		0
#define HIGH	1	
#define TOTAL_FREE   1
#define NEXT_FREE    2
#define GET_LIST     0
#define GET_FILE     1
#define DELETE		 2
#define CARD_EOF		0x0fffffff

//#define LIMIT_SD_FATSYSTEM  0xEE200   // For 1GB        // to limit FAT File System for Text File 
//924 



// #define START_BLOCKNO_ICON2  0x1876   // Start block no 6262  for ICON 2 of 60x60 pixels -> 9 Icons
// #define MAX_ICON2  9
// // Second for Touch ICons of differnt funtions 
// // 60x60*2/512 = 15 total = 135
// #define START_BLOCKNO_ICON3  0x6398   // Start block no 6398  for ICON 3 of XXX pixels -> 9 Icons
// #define MAX_ICON3  5
// // Fire ,Egress, Door Open etc 
// // 
// //#define START_BLOCKNO_ICON4  0x6398   // Start block no 6398  for ICON 3 of XXX pixels -> 9 Icons
// // battery level , NW status , loged in or not 


//extern unsigned char gaucDataBuf[4100];
extern unsigned char SDFileName[12],SDDataLength;	
extern unsigned int  guintBlockNum,gusDataSize ;
extern unsigned long FreeSDMemory,TotalSDMem;


extern void clearSDbuffer(void);	
extern unsigned char getBootSectorData (void);
extern unsigned char ucFnSetFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize);
extern unsigned char ucFnAppendFile(unsigned char *pFN, unsigned char *pBuf, unsigned short lusDataSize);
extern unsigned long ulFnGetFileSize(unsigned char *pFN);
extern unsigned char ucFnReadFileOffset(u8 *pFN, u8 *pBuf, u32 lulOffSet, u16 lusDataSize);
extern unsigned char ucFnSearchFile(u8 *pFN);
extern unsigned char ucFnDeleteFile (unsigned char *fileName);
extern struct dir_Structure* findFiles (unsigned char flag, unsigned char *fileName);
extern void memoryStatistics (void);

#endif
//#endif // end of #ifdef INSERT_SDCARD
/*--------------------------File Ends----------------------------*/


