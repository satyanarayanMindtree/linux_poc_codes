
#include "dejavusansbold9.h"

typedef unsigned          char uint8_t;
typedef unsigned short     int uint16_t;
typedef unsigned           int uint32_t;
typedef unsigned       __int64 uint64_t;

//#define NULL 	(0)
void drawString(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo, unsigned char *str);
void drawCharBitmap(const unsigned short xPixel, const unsigned short yPixel, unsigned short color, const unsigned char  *glyph, uint8_t glyphHeightPages, unsigned char glyphWidthBits);
void NewDrawPixel(uint16_t x, uint16_t y, uint16_t color);


void L_DisplayROMStr(unsigned char *strdata,unsigned char len,unsigned char row);
void L_DisplayROMStrLoc(unsigned char *strdata,unsigned char len,unsigned char row, unsigned char pos);

////////////////////////////////////////// Start of Grid View ////////////////////////
#define DISPLAY_HEIGHT						240
#define DISPLAY_WIDTH						320

#define	COLOR_BLACK         0x0000
#define	COLOR_BLUE          0x001F
#define	COLOR_RED           0xF800
#define	COLOR_GREEN         0x07E0
#define COLOR_CYAN          0x07FF
#define COLOR_MAGENTA       0xF81F
#define COLOR_YELLOW        0xFFE0
#define COLOR_WHITE         0xFFFF

#define TOUCH_KEY_SECTION_HEIGHT			50
#define TOUCH_KEY_SECTION_WIDTH				DISPLAY_WIDTH


#define BOOT_MSG_SECTION_HEIGHT					TOUCH_KEY_SECTION_HEIGHT
#define BOOT_MSG_SECTION_WIDTH					TOUCH_KEY_SECTION_WIDTH
#define BOOT_MSG_SECTION_X0					0
#define BOOT_MSG_SECTION_Y0					(DISPLAY_HEIGHT - BOOT_MSG_SECTION_HEIGHT)


#define BOOT_MSG1			1
#define BOOT_MSG2	        2
#define BOOT_MSG3	        3
#define ROW_USER_TITLE	    4
#define ROW_USER_FUNCTION   5
#define ROW_USER_ENTRY      6
#define ROW_USER_ENTRY2	    7
#define ROW_USER_ENTRY3	    8
#define ROW_USER_ENTRY4	    9
#define ROW_USER_ENTRY5	    10

#define BOOT_MSG_HEIGHT			16
#define BOOT_MSG1_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG1_Y0			(BOOT_MSG_SECTION_Y0)
#define BOOT_MSG2_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG2_Y0			(BOOT_MSG1_Y0+BOOT_MSG_HEIGHT+1)
#define BOOT_MSG3_X0			(BOOT_MSG_SECTION_X0+1)
#define BOOT_MSG3_Y0			(BOOT_MSG2_Y0+BOOT_MSG_HEIGHT+1)
#define BOOT_MSG_COLOR			COLOR_RED
#define BOOT_MSG_FONT			dejaVuSansBold9ptFontInfo

#define FORMAT_BOOT_SCREEN					1
#define FORMAT_WELCOME_SCREEN       2
#define FORMAT_GRID_SCREEN          3
#define FORMAT_SCROLL_SCREEN        4
#define FORMAT_SUBMENU_SCREEN       5
#define FORMAT_EVENT_ICON       		6
#define FORMAT_SCROLL_MENU					7
#define FORMAT_CONNECT_GPRS					8
