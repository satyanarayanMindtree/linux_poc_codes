//-----------------------------------------------------------------------------
// Software that is described herein is for illustrative purposes only  
// which provides customers with programming information regarding the  
// products. This software is supplied "AS IS" without any warranties.  
// NXP Semiconductors assumes no responsibility or liability for the 
// use of the software, conveys no license or title under any patent, 
// copyright, or mask work right to the product. NXP Semiconductors 
// reserves the right to make changes in the software without 
// notification. NXP Semiconductors also make no representation or 
// warranty that such application will be suitable for the specified 
// use without further testing or modification. 
//-----------------------------------------------------------------------------

/*

17-5-2011
=========
1) Added three different boot strings
	To indicate boot loaded was run in two different conditions
	To indicate that we completed boot loading after firmware upgrade.	

*/
#include "LPC23XX.H"                        /* LPC23xx definitions */
#include <string.h>
#include "sbl_config.h"
#include "comms.h"
#include ".\isp\isp_iap.h"
#include ".\board_init\board_init.h"
#include "spi.h"
#include"TFT.h"

#include "lcd_disp.h"

//#include "dejavusansbold9.h"


void UART_init(unsigned int);
void print(char *);
int putchar(int);
void printhexa(char);
void printascii(char);

const unsigned crp __attribute__((section(".ARM.__at_0x1FC"))) = CRP;
const unsigned fcclk_KHz = FCCLK / 1000;

//JUST TO CHECK AFTER RESTART 
//#define CHECK_AFTER_BOOTLOADER 	(*((unsigned int *) 0xE0084014))

#define MEM_ADD_BOOT_STRING  		(((char *) 0xE0084014))
#define BOOT_STRING_LENGTH	8

// Last 4 characters in string indicates Boot loader version which we can read from main program.

#define BOOT_STRING					"BOOTVER1"			// Just to program that entered boot path
#define BOOT_STRING_2				"bootVER1"			// Just to know that it entered different code path
#define BOOT_STRING_COMPLETE		"DONEVER1"			// Just to know that Bootloading done 
#define BOOT_STRING_UPGRADE			"SMARTUPG"


/***********************************************************************/
/*  This file is part of the ARM Toolchain package                     */
/*  Copyright KEIL ELEKTRONIK GmbH 2003 - 2006                         */
/***********************************************************************/
/*                                                                     */
/*  FlashDev.C:  Flash Programming Functions adapted                   */
/*               for Philips LPC2xxx 512kB Flash                       */
/*               	with IAP                      */
/*                                                                     */
/***********************************************************************/

#include "FlashOS.H"        // FlashOS Structures

// Memory Mapping Control
//#define MEMMAP   (*((volatile unsigned char *) 0xE01FC040))

// Phase Locked Loop (PLL)
//#define PLLCON   (*((volatile unsigned char *) 0xE01FC080))
//#define PLLCFG   (*((volatile unsigned char *) 0xE01FC084))
//#define PLLSTAT  (*((volatile unsigned short*) 0xE01FC088))
//#define PLLFEED  (*((volatile unsigned char *) 0xE01FC08C))


#define STACK_SIZE     64      // Stack Size

#define SET_VALID_CODE 1       // Set Valid User Code Signature


unsigned long CCLK;            // CCLK in kHz

struct sIAP {                  // IAP Structure
  unsigned long cmd;           // Command
  unsigned long par[4];        // Parameters
  unsigned long stat;          // Status
  unsigned long res;           // Result
} IAP;

//New Firmware code structure
__packed struct NEW_FW_INFO
{
   	unsigned int ChkSum;
	unsigned int CodeSz;
	unsigned short NoOfPages;
	unsigned short ErrInfo;
   	unsigned char FWInfo[8];
   	unsigned char HWInfo[8];
   	unsigned char CompileDate[8];
}NewFWInfo;


/*
 * IAP Execute
 *    Parameter:      pIAP:  Pointer to IAP
 *    Return Value:   None (stat in IAP)
 */

void IAP_Execute (struct sIAP *pIAP);
unsigned char GetSectorFromFlash(unsigned long fladdr);


/*
 * Get Sector Number
 *    Parameter:      adr:  Sector Address
 *    Return Value:   Sector Number
 */

unsigned long GetSecNum (unsigned long adr) {
  unsigned long n;

  n = (adr >> 12) & 0x7F;                      // Pseudo Sector Number
  if (n >= 0x78) {                             // High Small 4kB Sectors
    n -= 0x62;
  }
  else if (n >= 0x08) {                        // Large 32kB Sectors
    n  = 0x07 + (n >> 3);
  }

  return (n);                                  // Sector Number
}

/* 
void enable_interrupts(unsigned interrupts)
{
    VICIntEnable = interrupts;
}

void disable_interrupts(unsigned interrupts)
{
    VICIntEnClr = interrupts;
}
*/

/*
 *  Initialize Flash Programming Functions
 *    Parameter:      adr:  Device Base Address
 *                    clk:  Clock Frequency (Hz)
 *                    fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int Init (unsigned long adr, unsigned long clk, unsigned long fnc) {

  IAP.cmd = 54;                                // Read Part ID
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  if ((IAP.res & 0x000F0000) == 0x00030000) {  // LPC23xx/24xx
    CCLK  =  4000;                             // 4MHz RC Oscillator
  } else {
//  CCLK /=  1000;                             // Clock Frequency in kHz
    CCLK  = (1049*(clk >> 10)) >> 10;          // Approximate (no Library Code)
  }

  PLLCON  = 0x00;                              // Disable PLL (use Oscillator)
  PLLFEED = 0xAA;                              // Feed Sequence Part #1
  PLLFEED = 0x55;                              // Feed Sequence Part #2

  MEMMAP  = 0x01;                              // User Flash Mode

  return (0);
}


/*
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int UnInit (unsigned long fnc) {
  return (0);
}


/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseChip (void) {

  IAP.cmd    = 50;                             // Prepare Sector for Erase
  IAP.par[0] = 3;                              // Start Sector
  IAP.par[1] = 27;                             // End Sector
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  IAP.cmd    = 52;                             // Erase Sector
  IAP.par[0] = 3;                              // Start Sector
  IAP.par[1] = 27;                             // End Sector
  IAP.par[2] = CCLK;                           // CCLK in kHz
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  return (0);                                  // Finished without Errors
}


/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseSector (unsigned long adr) {
  unsigned long n;

  n = GetSecNum(adr);                          // Get Sector Number

  IAP.cmd    = 50;                             // Prepare Sector for Erase
  IAP.par[0] = n;                              // Start Sector
  IAP.par[1] = n;                              // End Sector
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  IAP.cmd    = 52;                             // Erase Sector
  IAP.par[0] = n;                              // Start Sector
  IAP.par[1] = n;                              // End Sector
  IAP.par[2] = CCLK;                           // CCLK in kHz
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  return (0);                                  // Finished without Errors
}


/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

int ProgramPage (unsigned long adr, unsigned long sz, unsigned char *buf) {
  unsigned long n;

#if SET_VALID_CODE != 0                        // Set valid User Code Signature
  if (adr == 0) {                              // Check for Interrupt Vectors
    n = *((unsigned long *)(buf + 0x00)) +     // Reset Vector
        *((unsigned long *)(buf + 0x04)) +     // Undefined Instruction Vector
        *((unsigned long *)(buf + 0x08)) +     // Software Interrupt Vector
        *((unsigned long *)(buf + 0x0C)) +     // Prefetch Abort Vector
        *((unsigned long *)(buf + 0x10)) +     // Data Abort Vector
        *((unsigned long *)(buf + 0x18)) +     // IRQ Vector
        *((unsigned long *)(buf + 0x1C));      // FIQ Vector
    *((unsigned long *)(buf + 0x14)) = 0 - n;  // Signature at Reserved Vector
  }
#endif

  n = GetSecNum(adr);                          // Get Sector Number

  IAP.cmd    = 50;                             // Prepare Sector for Write
  IAP.par[0] = n;                              // Start Sector
  IAP.par[1] = n;                              // End Sector
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  IAP.cmd    = 51;                             // Copy RAM to Flash
  IAP.par[0] = adr;                            // Destination Flash Address
  IAP.par[1] = (unsigned long)buf;             // Source RAM Address
  IAP.par[2] = sz;							   // Fixed Page Size
  IAP.par[3] = CCLK;                           // CCLK in kHz
  IAP_Execute (&IAP);                          // Execute IAP Command
  if (IAP.stat) return (1);                    // Command Failed

  return (0);                                  // Finished without Errors
}


void enter_isp(void)
{
int i;
unsigned long addr,codesz;
unsigned char prev_secno,curr_secno;
unsigned char tempwrbuf[PAGE_SIZE];
	board_init();
	init_VIC();
	GPIOInit(0,FAST_PORT,DIR_OUT);	//Initialised SPI port as fast port for commnication
	SPIInit();	//Initialise SPI port as fast port for commnication before SPI initialisation	
	lcdInit();// Initialise TFT
	drawString(BOOT_MSG1_X0,BOOT_MSG1_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,"Booting Firmware");
	drawString(BOOT_MSG2_X0,BOOT_MSG2_Y0,BOOT_MSG_COLOR,&BOOT_MSG_FONT,"Please Wait...");

//	UART_init(9600);

//	SendDecimalLong(9600);
//	print("inside ISP\n");
//	print("PageNo:");
//	SendDecimalLong(FL_NEW_FW_CODE_INFO);
 
	MainMem_ReadPage(FL_NEW_FW_CODE_INFO,0,(BYTE *)&NewFWInfo,sizeof(NewFWInfo));//dummy read
//	print("\ncodeSize");
//	SendDecimalLong(NewFWInfo.CodeSz);

	MainMem_ReadPage(FL_NEW_FW_CODE_INFO,0,(BYTE *)&NewFWInfo,sizeof(NewFWInfo));
//	print("\ncodeSize");
//	SendDecimalLong(NewFWInfo.CodeSz);

	if(NewFWInfo.CodeSz > SUPPORT_MAX_CODE_SZ)
		execute_user_code();
	prev_secno = curr_secno = 0;
	addr = USER_START_SECTOR_ADDRESS;// + 217088;	 //offset added for testing
	codesz = NewFWInfo.CodeSz/CODE_PAGE_SIZE;//code size in pages
	if((NewFWInfo.CodeSz%CODE_PAGE_SIZE) != 0)
		codesz += 1;		
//	codesz = SUPPORT_MAX_CODE_SZ/CODE_PAGE_SIZE;
	for(i=0;i<codesz;i++)
	{
//Read External memory
 		MainMem_ReadPage(FL_NEW_FW_BASE_ADDRESS+i,0,(BYTE *)&tempwrbuf,PAGE_SIZE);
//	interrupts  = VICIntEnable;
//	disable_interrupts(interrupts);
//		IDISABLE;
		curr_secno = GetSectorFromFlash(addr);
		if(curr_secno != 0xFF)
		{
			if(curr_secno != prev_secno)
			{
	    		prev_secno = curr_secno;
				Init(addr,4000000,2);
				EraseSector(addr);	
			}
//			*CHECK_AFTER_BOOTLOADER = i;//FOR TESTING
			ProgramPage(addr, CODE_PAGE_SIZE , tempwrbuf);
			addr += CODE_PAGE_SIZE;
		}
//		IENABLE;
	}
	memcpy((char *)MEM_ADD_BOOT_STRING,BOOT_STRING_COMPLETE,BOOT_STRING_LENGTH);
	execute_user_code();
}
int check_string(const char *temp1Str,const char *temp2Str,int length)
{
// 	const char *temp1Str=MEM_ADD_BOOT_STRING;
//	const char *temp2Str=StrCheck;
//	const char *temp2Str="SMARTUPG";
//	int i=BOOT_STRING_LENGTH;

	while( (*temp2Str!='\0') && length--)
	{
		if(*temp1Str != *temp2Str)
			return 0;   //not equal
		temp1Str++;
		temp2Str++;
	}
	return 1;		//string is equal
}

/* Main Program */
void sbl_main (void) 
{
	if( user_code_present() )
  {
      if ( crp == CRP3 )
	  {
		  memcpy((char *)MEM_ADD_BOOT_STRING,BOOT_STRING_2,BOOT_STRING_LENGTH);
          /* CRP3 is enabled and user flash start sector is not blank, 
		     execute the user code */
		  execute_user_code();
      }
	  else
	  {
		 if(check_string(MEM_ADD_BOOT_STRING,BOOT_STRING_UPGRADE,BOOT_STRING_LENGTH))
		  {
		      /* isp entry requested and CRP3 not enabled */
			  //CHECK_AFTER_BOOTLOADER = 0;
			enter_isp();
		  }
		  else
		  {
		 	if( !check_string(MEM_ADD_BOOT_STRING,BOOT_STRING_COMPLETE,BOOT_STRING_LENGTH) )
			{
				memcpy((char *)MEM_ADD_BOOT_STRING,BOOT_STRING,BOOT_STRING_LENGTH);
			}  
		      /* isp entry not requested and CRP3 not enabled */			  
		      execute_user_code();
		  }
	  }
  }
  /* User code not present, enter isp */
  enter_isp();
}
/*---------------------------------------------------------------------------------
Flash Memory Sectors in a LPC2300 device
===================================================================================
SecNo	SecSz[kB]	Address Range				128kB Part	256kB Part	512kB Part
===================================================================================
0		4			0X0000 0000 - 0X0000 0FFF	x			x			x
1		4			0X0000 1000 - 0X0000 1FFF	x			x			x
2		4			0X0000 2000 - 0X0000 2FFF	x			x			x
3		4			0X0000 3000 - 0X0000 3FFF	x			x			x
4		4			0X0000 4000 - 0X0000 4FFF	x			x			x
5		4			0X0000 5000 - 0X0000 5FFF	x			x			x
6		4			0X0000 6000 - 0X0000 6FFF	x			x			x
7		4			0X0000 7000 - 0X0000 7FFF	x			x			x
8		32			0x0000 8000 - 0X0000 FFFF	x			x			x
9		32			0x0001 0000 - 0X0001 7FFF	x			x			x
10 0x0A	32			0x0001 8000 - 0X0001 FFFF	x			x			x
11 0x0B 32			0x0002 0000 - 0X0002 7FFF				x			x
12 0x0C 32			0x0002 8000 - 0X0002 FFFF				x			x
13 0x0D 32			0x0003 0000 - 0X0003 7FFF				x			x
14 0x0E 32			0x0003 8000 - 0X0003 FFFF				x			x
15 0x0F 32			0x0004 0000 - 0X0004 7FFF							x
16 0x10 32			0x0004 8000 - 0X0004 FFFF							x
17 0x11 32			0x0005 0000 - 0X0005 7FFF							x
18 0x12 32			0x0005 8000 - 0X0005 FFFF							x
19 0x13 32			0x0006 0000 - 0X0006 7FFF							x
20 0x14 32			0x0006 8000 - 0X0006 FFFF							x
21 0x15 32			0x0007 0000 - 0X0007 7FFF							x
22 0x16 4			0x0007 8000 - 0X0007 8FFF							x
23 0x17 4			0x0007 9000 - 0X0007 9FFF							x
24 0x18 4			0x0007 A000 - 0X0007 AFFF							x
25 0x19 4			0x0007 B000 - 0X0007 BFFF							x
26 0x1A 4			0x0007 C000 - 0X0007 CFFF							x
27 0x1B 4			0x0007 D000 - 0X0007 DFFF							x
---------------------------------------------------------------------------------*/
unsigned char GetSectorFromFlash(unsigned long fladdr)
{
unsigned char secno;
//	if((fladdr >= 0x00000000) && (fladdr <= 0x00000FFF))		 //Bootloader code
//		secno = 0;
//	else if((fladdr >= 0x00001000) && (fladdr <= 0x00001FFF))
//		secno = 1;
//	else if((fladdr >= 0x00002000) && (fladdr <= 0x00002FFF))
//		secno = 2;
	if((fladdr >= 0x00003000) && (fladdr <= 0x00003FFF))
		secno = 3;
	else if((fladdr >= 0x00004000) && (fladdr <= 0x00004FFF))
		secno = 4;
	else if((fladdr >= 0X00005000) && (fladdr <= 0X00005FFF))
		secno = 5;
	else if((fladdr >= 0X00006000) && (fladdr <= 0X00006FFF))
		secno = 6;
	else if((fladdr >= 0X00007000) && (fladdr <= 0X00007FFF))
		secno = 7;
	else if((fladdr >= 0x00008000) && (fladdr <= 0X0000FFFF))
		secno = 8;
	else if((fladdr >= 0x00010000) && (fladdr <= 0X00017FFF))
		secno = 9;
	else if((fladdr >= 0x00018000) && (fladdr <= 0X0001FFFF))
		secno = 10;
	else if((fladdr >= 0x00020000) && (fladdr <= 0X00027FFF))
		secno = 11;
	else if((fladdr >= 0x00028000) && (fladdr <= 0X0002FFFF))
		secno = 12;
	else if((fladdr >= 0x00030000) && (fladdr <= 0X00037FFF))
		secno = 13;
	else if((fladdr >= 0x00038000) && (fladdr <= 0X0003FFFF))
		secno = 14;
	else if((fladdr >= 0x00040000) && (fladdr <= 0X00047FFF))
		secno = 15;
	else if((fladdr >= 0x00048000) && (fladdr <= 0X0004FFFF))
		secno = 16;
	else if((fladdr >= 0x00050000) && (fladdr <= 0X00057FFF))
		secno = 17;
	else if((fladdr >= 0x00058000) && (fladdr <= 0X0005FFFF))
		secno = 18;
	else if((fladdr >= 0x00060000) && (fladdr <= 0X00067FFF))
		secno = 19;
	else if((fladdr >= 0x00068000) && (fladdr <= 0X0006FFFF))
		secno = 20;
	else if((fladdr >= 0x00070000) && (fladdr <= 0X00077FFF))
		secno = 21;
	else if((fladdr >= 0x00078000) && (fladdr <= 0X00078FFF))
		secno = 22;
	else if((fladdr >= 0x00079000) && (fladdr <= 0X00079FFF))
		secno = 23;
	else if((fladdr >= 0x0007A000) && (fladdr <= 0X0007AFFF))
		secno = 24;
	else if((fladdr >= 0x0007B000) && (fladdr <= 0X0007BFFF))
		secno = 25;
	else if((fladdr >= 0x0007C000) && (fladdr <= 0X0007CFFF))
		secno = 26;
	else if((fladdr >= 0x0007D000) && (fladdr <= 0X0007DFFF))
		secno = 27;
	else
		return(0xFF);

	return(secno);
}
