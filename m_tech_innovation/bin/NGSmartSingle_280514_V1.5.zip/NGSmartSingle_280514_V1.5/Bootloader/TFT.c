#include "LPC23XX.H"                        /* LPC23xx definitions */
#include"TFT.h"
#include "lcd_disp.h"
//#include "../GLCD/drivers/lcd/tft/fonts/dejavusansbold9.h"

#include "dejavusansbold9.h"


#define ENTRY_MODE_DEFAULT 0x6830
#define MAKE_ENTRY_MODE(x) ((ENTRY_MODE_DEFAULT & 0xFF00) | (x))


void my_delay(unsigned int val)
{
	while(--val);
}

void lcdInit(void)
{
    unsigned long ulClockMS, ulCount;
    //
    // Get the current processor clock frequency.
    //
    //ulClockMS = SysCtlClockGet() / (3 * 1000);

    //
    // Perform low level interface initialization depending upon how the LCD
    // is connected to the Stellaris microcontroller.  This varies depending
    // upon the daughter board connected it is possible that a daughter board
    // can drive the LCD directly rather than via the basic GPIO interface.
    //
//    switch(g_eDaughterType)
    {
//        case DAUGHTER_NONE:
        {
            //
            // Initialize the GPIOs used to interface to the LCD controller.
            //
            InitGPIOLCDInterface(ulClockMS);
//            break;
        }
    }
	
	//read device ID
    TFTWriteCommand(SSD2119_DEVICE_CODE_READ_REG);
	ulClockMS = TFTReadCommand();	
	
    //
    // Enter sleep mode (if we are not already there).
    //
    TFTWriteCommand(SSD2119_SLEEP_MODE_REG);
    TFTWriteData(0x0001);
    
    // Set initial power parameters.
    //
    TFTWriteCommand(SSD2119_PWR_CTRL_5_REG);
    TFTWriteData(0x00BA);
    TFTWriteCommand(SSD2119_VCOM_OTP_1_REG);
    TFTWriteData(0x0006);

    //
    // Start the oscillator.
    //
    TFTWriteCommand(SSD2119_OSC_START_REG);
    TFTWriteData(0x0001);

    //
    // Set pixel format and basic display orientation (scanning direction).
    //
    TFTWriteCommand(SSD2119_OUTPUT_CTRL_REG);
#ifdef ROTATE_DISPLAY
    TFTWriteData(0x30EF);// for display from bottom to top 
#else
    TFTWriteData(0x72EF); // display from top tobottom
#endif
    TFTWriteCommand(SSD2119_LCD_DRIVE_AC_CTRL_REG);
    TFTWriteData(0x0600);

    //
    // Exit sleep mode.
    //
    TFTWriteCommand(SSD2119_SLEEP_MODE_REG);
    TFTWriteData(0x0000);

    //
    // Delay 30mS
    //
//    SysCtlDelay(30 * ulClockMS);
       my_delay(30000);

    //
    // Configure pixel color format and MCU interface parameters.
    //
    TFTWriteCommand(SSD2119_ENTRY_MODE_REG);
    TFTWriteData(ENTRY_MODE_DEFAULT);

    //
    // Enable the display.
    //
    TFTWriteCommand(SSD2119_DISPLAY_CTRL_REG);
    TFTWriteData(0x0033);

    //
    // Set VCIX2 voltage to 6.1V.
    //
    TFTWriteCommand(SSD2119_PWR_CTRL_2_REG);
    TFTWriteData(0x0005);

    //
    // Configure gamma correction.
    //
    TFTWriteCommand(SSD2119_GAMMA_CTRL_1_REG);
    TFTWriteData(0x0000);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_2_REG);
    TFTWriteData(0x0400);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_3_REG);
    TFTWriteData(0x0106);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_4_REG);
    TFTWriteData(0x0700);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_5_REG);
    TFTWriteData(0x0002);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_6_REG);
    TFTWriteData(0x0702);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_7_REG);
    TFTWriteData(0x0707);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_8_REG);
    TFTWriteData(0x0203);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_9_REG);
    TFTWriteData(0x1400);
    TFTWriteCommand(SSD2119_GAMMA_CTRL_10_REG);
    TFTWriteData(0x0F03);

    //
    // Configure Vlcd63 and VCOMl.
    //
    TFTWriteCommand(SSD2119_PWR_CTRL_3_REG);
    TFTWriteData(0x0007);
    TFTWriteCommand(SSD2119_PWR_CTRL_4_REG);
    TFTWriteData(0x3100);

    //
    // Set the display size and ensure that the GRAM window is set to allow
    // access to the full display buffer.
    //
    TFTWriteCommand(SSD2119_V_RAM_POS_REG);
    TFTWriteData((LCD_VERTICAL_MAX-1) << 8);
    TFTWriteCommand(SSD2119_H_RAM_START_REG);
    TFTWriteData(0x0000);
    TFTWriteCommand(SSD2119_H_RAM_END_REG);
    TFTWriteData(LCD_HORIZONTAL_MAX-1);
    TFTWriteCommand(SSD2119_X_RAM_ADDR_REG);
    TFTWriteData(0x00);
    TFTWriteCommand(SSD2119_Y_RAM_ADDR_REG);
    TFTWriteData(0x00);

    //
    // Clear the contents of the display buffer.
    //
    TFTWriteCommand(SSD2119_RAM_DATA_REG);
    for(ulCount = 0; ulCount < (320 * 240); ulCount++)
    {
        TFTWriteData(0x0000);
        //WriteData(ulCount);
    }

}
void InitGPIOLCDInterface(unsigned long ulClockMS)
{
	DIR_OUT_GLCD_CTRL_BITS();
	DIR_OUT_GLCD_DATALINE();
	DIR_IO_DEC_PINS();
	DISABLE_DECODER();
	CLR_BL;
	SET_BL;
    //
    // Convert the PB7/NMI pin into a GPIO pin.  This requires the use of the
    // GPIO lock since changing the state of the pin is otherwise disabled.
    //
    //HWREG(GPIO_PORTB_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY_DD;
    //HWREG(GPIO_PORTB_BASE + GPIO_O_CR) = 0x80;

    //
    // Make PB7 an output.
    //
    //GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_7);
	DIR_OUT_GLCD_CTRL_BITS();
	DIR_OUT_GLCD_DATALINE();

    //
    // Clear the commit register, effectively locking access to registers
    // controlling the PB7 configuration.
    //
    //HWREG(GPIO_PORTB_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY_DD;
    //HWREG(GPIO_PORTB_BASE + GPIO_O_CR) = 0x00;

    //
    // Configure the pins that connect to the LCD as GPIO outputs.
    //
    //GPIOPinTypeGPIOOutput(LCD_DATAH_BASE, LCD_DATAH_PINS);
    //GPIOPinTypeGPIOOutput(LCD_DC_BASE, LCD_DC_PIN);
    //GPIOPinTypeGPIOOutput(LCD_RD_BASE, LCD_RD_PIN);
    //GPIOPinTypeGPIOOutput(LCD_WR_BASE, LCD_WR_PIN);
    //GPIOPinTypeGPIOOutput(LCD_RST_BASE, LCD_RST_PIN);

    //
    // Set the LCD control pins to their default values.  This also asserts the
    // LCD reset signal.
    //
    //GPIOPinWrite(LCD_DATAH_BASE, LCD_DATAH_PINS, 0x00);
	BYTE_GLCD_OUT(0x00);
    //GPIOPinWrite(LCD_DC_BASE, LCD_DC_PIN, 0x00);
    //GPIOPinWrite(LCD_RD_BASE, LCD_RD_PIN, LCD_RD_PIN);
    //GPIOPinWrite(LCD_WR_BASE, LCD_WR_PIN, LCD_WR_PIN);
    //GPIOPinWrite(LCD_RST_BASE, LCD_RST_PIN, 0x00);
    SET_CD;
	SET_CS;
	SET_WR;
	SET_RD
	CLR_RESET; //reset device
    //
    // Delay for 1ms.
    //
    //SysCtlDelay(ulClockMS);
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    //
    // Deassert the LCD reset signal.
    //
    //GPIOPinWrite(LCD_RST_BASE, LCD_RST_PIN, LCD_RST_PIN);
    SET_RESET
    my_delay(10000);
    my_delay(10000);

	CLR_RESET; //reset device
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    my_delay(10000);
    SET_RESET
    my_delay(10000);
}

void TFTWriteCommand(unsigned char ucData)
{
//SET_RD;
CLR_CD;
CLR_CS;
//SET_WR;
    //
    // Write the most significant byte of the data to the bus. This is always
    // 0 since commands are no more than 8 bits currently.
    //
    //SET_LCD_DATA(0);
	BYTE_GLCD_OUT(0x00);

    //
    // Assert DC
    //
    //HWREG(LCD_DC_BASE + GPIO_O_DATA + (LCD_DC_PIN << 2)) = 0;

    //
    // Assert the write enable signal.  Do this twice to 3 times to slow things
    // down a bit.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //my_delay(100);
	CLR_WR;
	//CLR_WR;
	//CLR_WR;
    //my_delay(100);

    //
    // Deassert the write enable signal. We need to leave WR high for at least
    // 50nS so, again, stick in a dummy write to pad the timing.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = LCD_WR_PIN;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = LCD_WR_PIN;
	SET_WR;
	///SET_WR;
    //my_delay(100);

    //
    // Write the least significant byte of the data to the bus.
    //
    //SET_LCD_DATA(ucData);
	BYTE_GLCD_OUT(ucData);

    //
    // Assert the write enable signal.  Again, do this twice to ensure
    // we meet the timing spec.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = 0;
    //my_delay(100);
	//CLR_WR;
	CLR_WR;
    //my_delay(100);

    //
    // Deassert the write enable signal.
    //
    //HWREG(LCD_WR_BASE + GPIO_O_DATA + (LCD_WR_PIN << 2)) = LCD_WR_PIN;
	//SET_WR;
	SET_WR;

    //
    // Set the DC signal high, indicating that following writes are data.  There
    // is no need to pad the timing here since we won't violate the 50nS rule
    // even if this function is inlined and it or WriteData are called
    // immediately after we exit.
    //
    //HWREG(LCD_DC_BASE + GPIO_O_DATA + (LCD_DC_PIN << 2)) = LCD_DC_PIN;
SET_CS;
    //my_delay(100);
//SET_CD;
}

unsigned short TFTReadCommand(void)
{
	unsigned short dat;
	unsigned char cdat;
DIR_IN_GLCD_DATALINE();
//SET_WR;
//SET_CD;
CLR_CD;
CLR_CS;
	
	//CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
    //my_delay(100);
	BYTE_GLCD_READ(cdat);
    //my_delay(100);
	SET_RD;
	SET_RD;
	SET_RD;
	SET_RD;
	dat = cdat<<8;
	
	CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
	CLR_RD;
    //my_delay(100);
	BYTE_GLCD_READ(cdat);
    //my_delay(100);
	SET_RD;
	SET_RD;
	SET_RD;
	SET_RD;
	dat |= cdat;
	
SET_CS;
SET_CD;

DIR_OUT_GLCD_DATALINE();
	return dat; 
}
void TFTWriteData(unsigned short usData)
{
	unsigned char dat;
CLR_CS;
SET_CD;
    // Write the most significant byte of the data to the bus.
	dat = (usData >> 8)&0xff;
    BYTE_GLCD_OUT(dat);
	
    // Assert the write enable signal.  We need to do this 3 times to ensure
    // that we don't violate the timing requirements for the display (when
    // running with a 50MHz system clock).
	CLR_WR;

    // Deassert the write enable signal.
	SET_WR;

    // Write the least significant byte of the data to the bus.
	dat = usData & 0xFF;
    BYTE_GLCD_OUT(dat);
	
    // Assert the write enable signal.
	CLR_WR;

    // Deassert the write enable signal.  WR needs to be high for at least
    // 50nS and back-to-back inlined calls to this function could just,
    // conceivably violate this so add one access to pad the time a bit.
	SET_WR_CS;
}



/*
*/
