/*****************************************************************************
 *   wdt.h:  Header file for NXP LPC214x Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __WDT_H 
#define __WDT_H

#define WDEN		0x00000001
#define WDRESET		0x00000002
#define WDTOF		0x00000004
#define WDINT		0x00000008

#define NORMAL_RESET						0
#define WDT_SYSTEM_START					1
#define WDT_MAIN_LOOP						2
#define WDT_DEL_ALL_CARDS					3
#define WDT_DEL_ALL_NAMES_FROM_FLASH		4
#define WDT_WAIT_MODEM_RESPONSE				5
#define WDT_NEW_ADD_SERIAL_CARD				6
#define WDT_C_INITIALISE					7
#define WDT_C_ADD_CARD						8
#define WDT_C_TRNX_STORE					9
#define WDT_WRITE_ALLCARD_DATA_TO_FLASH		10
#define WDT_READ_ALLCARD_DATA_FROM_FLASH	11
#define WDT_GET_FLASH_CARDDATA_CHKSUM		12
#define WDT_WAIT_SMARTCARD_RESPONSE			13
#define WDT_WAIT_BIO_RESPONSE				14
#define WDT_TIME_WAIT_BIO_RESPONSE			15
#define WDT_WRITE_TRANS						16
#define WDT_GET_CARD_BY_INDEXNO				17
#define WDT_WAIT_SLAVE_RESPONSE				18
#define WDT_WAIT_ICLASS_READWRITE			19
#define WDT_C_IPSETTING						20
#define WDT_C_BULK_TRNX_DWNLD				21
#define WDT_WAIT_SMARTCARD_READWRITE		22
#define WDT_WAIT_ETHERNET_INITIALISE		23


//#define WDT_FEED_VALUE	0x003FFFFF
#define WDT_FEED_VALUE	0x000FFFFF		 //1sec	wdreset
#define WDTResetType	(*((unsigned int *) 0xE0084010))   //Battery backup RAM

extern void WDTHandler(void) __irq;
extern unsigned long WDTInit(unsigned long wdtime);
extern void WDTFeed(void);

extern unsigned char WDTHandleType;


#endif /* end __WDT_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/
