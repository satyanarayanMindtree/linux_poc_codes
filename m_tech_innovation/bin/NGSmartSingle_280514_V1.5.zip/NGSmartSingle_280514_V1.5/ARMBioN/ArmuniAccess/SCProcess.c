
#include <string.h>
#include <stdio.h>
#include "LPC23xx.h"			/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "irq.h"
#include "rtc.h"
//#include "timer.h"
#include "tranxmgmt.h"
#include "spi.h"
#include "serial.h"
#include "access.h"
#include "portlcd.h"
#include "Smartcard.h"
#include "userintf.h"
#include "rdcont.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "SCProcess.h"
#include "supremabio.h"

#ifndef SUPPORT_ICLASS_RDR
#ifdef SMART_CARD

//===============================================================================
unsigned char ReadSmartCardLayout(void);		  
char ReadSmartCardLayoutBARC(void);			   
char ReadSmartCardLayoutZICOM(void);	   
char ReadSmartCardLayoutHCL(unsigned char clayout);
extern SmartCardData CurrentCard;
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;

#ifdef	BIO_METRIC
//	extern unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE];
//	extern unsigned char BufferTemp[MAX_BIO_TEMPLATE_SIZE]; 

#else 
	unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE]; 
#endif
/*** BeginHeader ReadSmartCardAllData*/
unsigned char ReadSmartCardAllData(unsigned char rdno);
/*** EndHeader */
unsigned char ReadSmartCardAllData(unsigned char rdno)
{
unsigned char i,status;
//int x;
//	x = sizeof(BufferTemp);
	memset(BufferTemp,0,sizeof(BufferTemp));
	status = ReadSmartCardLayout();
	if(status != 0)
		return(status);
#ifndef SMART_USER_INT
	if((SysInfo.CardDataSource & CDATA_SOURCE_TEMPLATE) && (CurrentCard.CType & UTYPE_FINGER_SMARTCARD))
	{
#ifdef BIO_METRIC
	   	if(CHECK_DENY_LIST_BIO_NOCHK(rdno) || CHECK_BIO_NOCHK(rdno))     //do not read finger from card
	   		return(0);
#endif
	   	for(i=0;i<CurrentCard.NoOfTemp;i++)
	   	{
	      	status = ReadSmartCardDataBlock(CurrentCard.TempPos[i],CurrentCard.Template,BufferTemp[i],CurrentCard.CLayout);
	      	if(status != 0)
	         	return(status);
	   	}						   
	}
#endif
	return(status);
}

//==============================================================================
// Smartcard Info Block Details
//   0		1		2		3		4		5		6		7		8		9		10		11		12		13		14		15
//  CMSB  	C    C   CLSB  	PinM 	PinL 	DD    MM    YY		HH		MM		EMSB	E		E		ELSB	CTYPE
/*** BeginHeader ReadSmartCardLayoutHCL*/
char ReadSmartCardLayoutHCL(unsigned char clayout);
/*** EndHeader */
char ReadSmartCardLayoutHCL(unsigned char clayout)
{
unsigned char tempbuf[17],i,status,readdata,lastauthblock;
unsigned long cno;
	readdata = 0;
	CurrentCard.CardNo = ReceivedCardNo;
   	status = 0;
	CurrentCard.CType = 0x10;
	lastauthblock = 0;
	memset((unsigned char*)&CurrentCard,0,sizeof(CurrentCard));
   	CurrentCard.CLayout = clayout;
	if(SysInfo.CardDataSource & CDATA_SOURCE_TEMPLATE)
   	{
	   	readdata = 1;
		lastauthblock = SysInfo.SCTemplateBlock[clayout-1];
      	status = ReqAntiSelAuthSmartCard(SysInfo.SCKeyType[clayout],SysInfo.SCKeySector[clayout],lastauthblock,&cno);
	   	if(status != 0)
	      return(status);
		CurrentCard.CardNo = cno;
	   status = ReadSmartCardBlock(lastauthblock,tempbuf);
	   if(status != 0)
	      return(status);
	   if(SysInfo.SCCardNoType == SC_CT_TEMPLATE_BLOCK)
	   {
	      CurrentCard.CardNo = (unsigned long)tempbuf[0] * (unsigned long)0x1000000;
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[1]*0x10000)&0x00FFFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[2]*0x100)&0xFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)(tempbuf[3]&0xFF);
	   }
	   CurrentCard.Template = tempbuf[4]*0x100;
	   CurrentCard.Template = CurrentCard.Template + tempbuf[5];
	   CurrentCard.NoOfTemp = tempbuf[6];
		if(MAX_NO_OF_SC_TEMPLATES < CurrentCard.NoOfTemp)
      {
      	CurrentCard.NoOfTemp = 4;
			return(ERR_SC_LAYOUT_ERROR);
      }
//		printf(" Card no %08x, \n",CurrentCard.CardNo,CurrentCard.Template,CurrentCard.NoOfTemp);
//		printf(" template %d  nooftemp %d \n",CurrentCard.Template,CurrentCard.NoOfTemp);
	   for(i=0;i<CurrentCard.NoOfTemp;i++)
	   {
	      CurrentCard.TempPos[i] = tempbuf[7+i];
//			printf(" Template no %d  %d \n",i,CurrentCard.TempPos[i]);
	   }
   }
   if(SysInfo.CardDataSource & CDATA_SOURCE_NAME)
   {
   	readdata = 1;
   	//indicates that name is to be takenfrom Smartcard
      if((SysInfo.SCNameBlock[clayout-1]/4) != (lastauthblock/4))
      {  //Check if we have already authenticated to same sector
			lastauthblock = SysInfo.SCNameBlock[clayout-1];
      	status = AuthSmartCard(SysInfo.SCKeyType[clayout],SysInfo.SCKeySector[clayout],SysInfo.SCNameBlock[clayout-1]);
	      if(status != 0)
	         return(status);
      }
		status = ReadSmartCardBlock(SysInfo.SCNameBlock[clayout-1],tempbuf);
	   if(status != 0)
	   	return(status);
      memcpy(CurrentCard.Name,tempbuf,sizeof(CurrentCard.Name));
   }
   if((SysInfo.CardDataSource & CDATA_SOURCE_VALIDITY) || (SysInfo.CardDataSource & CDATA_SOURCE_USER_TYPE) || (SysInfo.CardDataSource & CDATA_SOURCE_PIN))
   {
   	readdata = 1;
   	// indicates that name is to be takenfrom Smartcard
      if((lastauthblock/4) != (SysInfo.SCInfoBlock[clayout-1]/4))
      {  // Check if we have already authenticated to same sector
      	status = AuthSmartCard(SysInfo.SCKeyType[clayout],SysInfo.SCKeySector[clayout],SysInfo.SCInfoBlock[clayout-1]);
	      if(status != 0)
	         return(status);
      }
		status = ReadSmartCardBlock(SysInfo.SCInfoBlock[clayout-1],tempbuf);
	   if(status != 0)
	   	return(status);
      CurrentCard.Pin = (tempbuf[4]*0x100) + tempbuf[5];
      if(SysInfo.SCCardNoType == SC_CT_INFO_BLOCK)
      {
	      CurrentCard.CardNo = (unsigned long)tempbuf[0] * (unsigned long)0x1000000;
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[1]*0x10000)&0x00FFFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[2]*0x100)&0xFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)(tempbuf[3]&0xFF);
      }
	   CurrentCard.VDate.tm_mday = tempbuf[6];
	   CurrentCard.VDate.tm_mon = tempbuf[7];
	   CurrentCard.VDate.tm_year = YEAR_BASE_VALUE + tempbuf[8];
	   CurrentCard.VDate.tm_hour = tempbuf[9];
	   CurrentCard.VDate.tm_min = tempbuf[10];
	   CurrentCard.VDate.tm_sec = 59;
	   CurrentCard.VDate.tm_wday = 0;
	   CurrentCard.CType = tempbuf[15];
   }
   if(readdata == 0)
   {
   	//Dummy read so that we can halt the card...
		 status = AuthSmartCard(SysInfo.SCKeyType[0],SysInfo.SCKeySector[0],0);
		 status = ReadSmartCardBlock(0,tempbuf);
   }
   return(status);
}

//==============================================================================
/*
Sector 1: User data
Block 4 --> Name of employee
Received data Alphanumeric --> TEST 2

Block 5 --> Card no
Received data Hex --> F29FB945000102203135393030363031
Card no in Hex = 0xF29FB9
Card Type = 0x41 � A (Admin)
    = 0x45 � E (Employee)
PIN = 0x0001 � 1
Blood Group = 0x00 � A+
	          0x01 � A-
	          0x02 � B+
	          0x03 � B-
	          0x04 � O+
	          0x05 � O-
	          0x06 � AB+
	          0x07 � AB-
	          0x08 � not above
Space � 0x020
Actual Card no in ASCII = 3135393030363031 � 15900601

Block 6 --> Company Info
Received data Hex --> 02024A0101960101685A49434F202020
Date of birth = 02024A � 02/02/74
Expiry date = 010196 � 01/01/50
If year < 100 then yy
Else year = yy - 100
For e.g. 0x96 =150
		Year = 150 - 100 = 50
Date of joining = 010168 � 01/01/04
Department = 5A49434F202020 � ZICO
*/
/*** BeginHeader ReadSmartCardLayoutZICOM*/
char ReadSmartCardLayoutZICOM(void);
/*** EndHeader */
char ReadSmartCardLayoutZICOM(void)
{
unsigned char tempbuf[18],i,status,readdata,lastauthblock;
unsigned long tempcard;

	readdata = 0;
	CurrentCard.CardNo = ReceivedCardNo;
   status = 0;
	CurrentCard.CType = 0x10;
	lastauthblock = 0;
	memset((unsigned char*)&CurrentCard,0,sizeof(struct SMART_CARD_DATA));
   CurrentCard.CLayout = 1;  	//set same as HCL
	if(SysInfo.CardDataSource & CDATA_SOURCE_TEMPLATE)
   {
	   readdata = 1;
		lastauthblock = SysInfo.SCTemplateBlock[0];
	   status = AuthSmartCard(SysInfo.SCKeyType[1],SysInfo.SCKeySector[1],SysInfo.SCTemplateBlock[0]);
	   if(status != 0)
	      return(status);
	   status = ReadSmartCardBlock(SysInfo.SCTemplateBlock[0],tempbuf);
	   if(status != 0)
	      return(status);
	   if(SysInfo.SCCardNoType == SC_CT_TEMPLATE_BLOCK)
	   {
	      CurrentCard.CardNo = (unsigned long)tempbuf[0] * (unsigned long)0x1000000;
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[1]*0x10000)&0x00FFFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo+ (unsigned long)((tempbuf[2]*0x100)&0xFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo+ (unsigned long)( tempbuf[3]&0xFF);
	   }
	   CurrentCard.Template = tempbuf[4]*0x100;
	   CurrentCard.Template = CurrentCard.Template + tempbuf[5];
	   CurrentCard.NoOfTemp = tempbuf[6];
		if(MAX_NO_OF_SC_TEMPLATES < CurrentCard.NoOfTemp)
      {
      	CurrentCard.NoOfTemp = 4;
			return(ERR_SC_LAYOUT_ERROR);
      }
//		printf(" Card no %08x, \n",CurrentCard.CardNo,CurrentCard.Template,CurrentCard.NoOfTemp);
//		printf(" template %d  nooftemp %d \n",CurrentCard.Template,CurrentCard.NoOfTemp);
	   for(i=0;i<CurrentCard.NoOfTemp;i++)
	   {
	      CurrentCard.TempPos[i] = tempbuf[7+i];
//			printf(" Template no %d  %d \n",i,CurrentCard.TempPos[i]);
	   }
	   CurrentCard.CType = tempbuf[15];
   }
   if(SysInfo.CardDataSource & CDATA_SOURCE_NAME)
   {
   	readdata = 1;
   	//indicates that name is to be takenfrom Smartcard
      if((SysInfo.SCNameBlock[0]/4) != (lastauthblock/4))
      {  //Check if we have already authenticated to same sector
			lastauthblock = SysInfo.SCNameBlock[0];
      	status = AuthSmartCard(SysInfo.SCKeyType[1],SysInfo.SCKeySector[1],SysInfo.SCNameBlock[0]);
	      if(status != 0)
	         return(status);
      }
		status = ReadSmartCardBlock(SysInfo.SCNameBlock[0],tempbuf);
	   if(status != 0)
	   	return(status);
      memcpy(CurrentCard.Name,tempbuf,sizeof(CurrentCard.Name));
   }
   // ZICOM
   if((SysInfo.NameType == NAME_AS_ZICOM_EMP_NO) || (SysInfo.SCCardNoType == SC_CT_INFO_BLOCK) || (SysInfo.CardDataSource & CDATA_SOURCE_PIN) || (SysInfo.CardDataSource & CDATA_SOURCE_USER_TYPE))
   {
   	readdata = 1;
      	if((lastauthblock/4) != (ZICOM_SC_CARD_NO_INFO_BLOCK/4))		// in Zicome format Block 5 is used for card number and pin
      	{  // Check if we have already authenticated to same sector
      		status = AuthSmartCard(SysInfo.SCKeyType[1],SysInfo.SCKeySector[1],ZICOM_SC_CARD_NO_INFO_BLOCK);
	      	if(status != 0)
	         	return(status);
      	}
		lastauthblock = ZICOM_SC_CARD_NO_INFO_BLOCK;
		status = ReadSmartCardBlock(ZICOM_SC_CARD_NO_INFO_BLOCK,tempbuf);
	   	if(status != 0)
	   		return(status);
      	CurrentCard.Pin = (tempbuf[4]*0x100) + tempbuf[5];
	   	tempcard = (unsigned long)tempbuf[0] * (unsigned long)0x10000;
	   	tempcard = (unsigned long)tempcard + (unsigned long)((tempbuf[1]*0x100)&0xFFFF);
	   	tempcard = (unsigned long)tempcard + (unsigned long)(tempbuf[2]&0xFF);
      	CurrentCard.EMP_NO = tempcard;				// Pankaj to store employee number

      if(SysInfo.SCCardNoType == SC_CT_INFO_BLOCK)
	      CurrentCard.CardNo = tempcard;
		if(SysInfo.NameType == NAME_AS_ZICOM_EMP_NO)
      {
      	 sprintf((char *)tempbuf,"EMPNo:       ");
         LongToStr(&tempbuf[6],tempcard,0);
         memcpy(CurrentCard.EmpNo,tempbuf,sizeof(CurrentCard.EmpNo));
         memcpy(CurrentCard.Name,tempbuf,sizeof(CurrentCard.EmpNo));
      }
//	   CurrentCard.CType = tempbuf[3];
   }
	if(SysInfo.CardDataSource & CDATA_SOURCE_VALIDITY)
   {
   	readdata = 1;
      if((lastauthblock/4) != (ZICOM_SC_VALIDITY_INFO_BLOCK/4))		// in Zicome format Block 5 is used for card number and pin
      {  // Check if we have already authenticated to same sector
      	status = AuthSmartCard(SysInfo.SCKeyType[1],SysInfo.SCKeySector[1],ZICOM_SC_VALIDITY_INFO_BLOCK);
	      if(status != 0)
	         return(status);
      }
		lastauthblock = ZICOM_SC_CARD_NO_INFO_BLOCK;
		status = ReadSmartCardBlock(ZICOM_SC_VALIDITY_INFO_BLOCK,tempbuf);
	   if(status != 0)
	   	return(status);

   	CurrentCard.VDate.tm_mday = tempbuf[3];
	   CurrentCard.VDate.tm_mon = tempbuf[4];
		if(tempbuf[5] >= 100)
			CurrentCard.VDate.tm_year = tempbuf[5];		// As this is maintained in rabbit format in smartcard
      else
			CurrentCard.VDate.tm_year = tempbuf[5]+100;
	   CurrentCard.VDate.tm_hour = 23;
	   CurrentCard.VDate.tm_min = 59;
	   CurrentCard.VDate.tm_sec = 59;
	   CurrentCard.VDate.tm_wday = 0;
   }
   if(readdata == 0)
   {
   	//Dummy read so that we can halt the card...
		 status = AuthSmartCard(SysInfo.SCKeyType[0],SysInfo.SCKeySector[0],0);
		 status = ReadSmartCardBlock(0,tempbuf);
   }
   return(status);

}

//==============================================================================
/*** BeginHeader ReadSmartCardLayoutBARC*/
char ReadSmartCardLayoutBARC(void);
/*** EndHeader */
char ReadSmartCardLayoutBARC(void)
{
unsigned char tempbuf[17],i,status,readdata,lastauthblock;
unsigned char rdrkeyloc,card_status;

   readdata = 0;
	CurrentCard.CardNo = ReceivedCardNo;
   status = 0;
	CurrentCard.CType = 0x10;
	lastauthblock = 0;
	memset((unsigned char*)&CurrentCard,0,sizeof(struct SMART_CARD_DATA));
   CurrentCard.CLayout = 1;  	//set same as HCL
   CurrentCard.CSN = ReceivedCardNo;
   status = AuthSmartCard(0,0,1);	//Auth with Sec-0, Key-A, Block-1
	if(status != 0)
		return(EVENT_INVALID_CARD);

	status = ReadSmartCardBlock(1,tempbuf);		//Read MAD id
	SysInfo.SCKeySector[1] = rdrkeyloc = tempbuf[3];
   if(status == 0)
   {
   	if((Doorinfo.BARCCardType & (0x1<<(rdrkeyloc-1))))
      {
      	if(tempbuf[2]== 0x55)
	      {
				// just for temperary reason I kept it same for all card type BARC
	         if((rdrkeyloc == 1) || (rdrkeyloc == 2) || (rdrkeyloc == 3))   // VGIL Card Support
	         {
	            if(SysInfo.CardDataSource & CDATA_SOURCE_TEMPLATE)
	            {
	               readdata=1;
	               lastauthblock = SysInfo.SCTemplateBlock[0];
	               status = AuthSmartCard(0,rdrkeyloc,SysInfo.SCTemplateBlock[0]);    //AuthSmartCard(0,1,SysInfo.SCTemplateBlock);
	               if(status != 0)
	                  return(EVENT_INVALID_CARD);
	               status = ReadSmartCardBlock(SysInfo.SCTemplateBlock[0],tempbuf);
	               if(status !=0)
	                  return(status);
	               if(SysInfo.SCCardNoType == SC_CT_TEMPLATE_BLOCK)
	               {
	                  CurrentCard.CardNo= (unsigned long)tempbuf[0]*(unsigned long)0x1000000;
	                  CurrentCard.CardNo= (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[1]*0x10000)&0x00FFFFFF);
	                  CurrentCard.CardNo= (unsigned long)CurrentCard.CardNo+ (unsigned long)((tempbuf[2]*0x100)&0xFFFF);
	                  CurrentCard.CardNo= (unsigned long)CurrentCard.CardNo+ (unsigned long)( tempbuf[3]&0xFF);
	               }
	               CurrentCard.Template = tempbuf[4]*0x100;
	               CurrentCard.Template = CurrentCard.Template+tempbuf[5];
	               CurrentCard.NoOfTemp= tempbuf[6];
	               if(MAX_NO_OF_SC_TEMPLATES < CurrentCard.NoOfTemp)
	               {
	                  CurrentCard.NoOfTemp =4;
	                  return(ERR_SC_LAYOUT_ERROR);
	               }

	               for(i=0;i<CurrentCard.NoOfTemp;i++)
	                CurrentCard.TempPos[i]=tempbuf[7+i];
	            }
	         }
	         else
	         	return(EVENT_INVALID_CARD);
         }
         else
     			return(EVENT_INVALID_CARD);
		}
      else
         return(EVENT_INVALID_CARD);

   }

   if(SysInfo.CardDataSource & CDATA_SOURCE_NAME)
   {
   	readdata = 1;
   	// indicates that name is to be takenfrom Smartcard
      if((SysInfo.SCNameBlock[0]/4) != (lastauthblock/4))
      {  // Check if we have already authenticated to same sector
			lastauthblock = SysInfo.SCNameBlock[0];
      	status = AuthSmartCard(0,rdrkeyloc,SysInfo.SCNameBlock[0]);
	      if(status != 0)
	         return(status);
      }
		status = ReadSmartCardBlock(SysInfo.SCNameBlock[0],tempbuf);
	   if(status != 0)
	   	return(status);
      memcpy(CurrentCard.Name,tempbuf,sizeof(CurrentCard.Name));
   }

   if((SysInfo.CardDataSource & CDATA_SOURCE_VALIDITY) ||(SysInfo.CardDataSource & CDATA_SOURCE_USER_TYPE) ||(SysInfo.CardDataSource & CDATA_SOURCE_PIN) )
   {
   	readdata=1;
   	// indicates that name is to be takenfrom Smartcard
      if( (lastauthblock/4) != (SysInfo.SCInfoBlock[0]/4))
      {  // Check if we have already authenticated to same sector
      	status = AuthSmartCard(0,rdrkeyloc,SysInfo.SCInfoBlock[0]);
	      if(status != 0)
	         return(status);
      }
		status = ReadSmartCardBlock(SysInfo.SCInfoBlock[0],tempbuf);
	   if(status != 0)
	   	return(status);
      CurrentCard.Pin = (tempbuf[4]*0x100) + tempbuf[5];

      if(SysInfo.SCCardNoType == SC_CT_INFO_BLOCK)
      {
	      CurrentCard.CardNo = (unsigned long)tempbuf[0]*(unsigned long)0x1000000;
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[1]*0x10000)&0x00FFFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)((tempbuf[2]*0x100)&0xFFFF);
	      CurrentCard.CardNo = (unsigned long)CurrentCard.CardNo + (unsigned long)(tempbuf[3]&0xFF);
      }
	   CurrentCard.VDate.tm_mday  = tempbuf[6];
	   CurrentCard.VDate.tm_mon   = tempbuf[7];
	   CurrentCard.VDate.tm_year  = 100 + tempbuf[8];
	   CurrentCard.VDate.tm_hour  = tempbuf[9];
	   CurrentCard.VDate.tm_min   = tempbuf[10];
	   CurrentCard.VDate.tm_sec   = 59;
	   CurrentCard.VDate.tm_wday  = 0;
	   CurrentCard.CType = tempbuf[15];
   }
   card_status = status;
/*   PortObj[SER_UDP_PORT].Type = SET;			// ready to send UDP
//=================================
  SendUDP_BARCData(&CurrentCard,SER_UDP_PORT);
*/
  return(card_status);
}

/*** BeginHeader ReadSmartCardLayout*/
unsigned char ReadSmartCardLayout(void);
/*** EndHeader */
unsigned char ReadSmartCardLayout(void)
{
unsigned char status;

   	if(SysInfo.SmartCardLayout == SC_LAYOUT_ZICOM)
	{
		status = ReadSmartCardLayoutZICOM();
   	}
	else if(SysInfo.SmartCardLayout == SC_LAYOUT_BARC)
   	{
		return(ReadSmartCardLayoutBARC());
	}
#ifdef LPU_CARD_SUPPORT
   		else if(SysInfo.SmartCardLayout == SC_LAYOUT_LPU)
   		{
	   		status = AuthSmartCard(SysInfo.SCKeyType[SC_CARD_TYPE_HCL],SysInfo.SCKeySector[SC_CARD_TYPE_HCL],SysInfo.SCInfoBlock[SC_CARD_TYPE_HCL-1]);
	   		if(status != 0)   //Authentication with HCL keys fails then read LPU card Layout
	     	 	return(ReadSmartCardLayoutHCL(SC_CARD_TYPE_LPU));
	   		else
	      		return(ReadSmartCardLayoutHCL(SC_CARD_TYPE_HCL));
   		}
#endif
   		else
   			return(ReadSmartCardLayoutHCL(SC_CARD_TYPE_HCL));
	return(status);
}
#endif
#endif //SUPPORT_ICLASS_RDR


