/*
This file is created to hold hardware information for board ARM Biolite
This is for Biolite board where reader is connected on weigand
*/
//HW_ARM_BioLite1_0
												
//===========================================================================
/* LCD Display */
/* LCD IO definitions */
#define PINO_P1_LCD_E     0x02000000	/* Enable control pin                */

#define PINO_P1_LCD_RW    0x00000000	/* Read/Write control pin            */

#define PINO_P1_LCD_RS    0x00800000	/* Data/Instruction control          */

#define DIR_LCD_PORT_BITS()	{}//FIO1DIR |= PINO_P1_LCD_E | PINO_P1_LCD_RW | PINO_P1_LCD_RS;}
#define DIR_LCD_OUT_PORT()	{}//FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000;}

#define B_LCD_E(X)	{}//(X == SET) ? (FIO1SET |= PINO_P1_LCD_E) : (FIO1CLR |= PINO_P1_LCD_E);}
#define B_LCD_RW(X)	{}//{(X == SET) ? (FIO1SET |= PINO_P1_LCD_RW) : (FIO1CLR |= PINO_P1_LCD_RW);}
#define B_LCD_RS(X) {}//(X == SET) ? (FIO1SET |= PINO_P1_LCD_RS) : (FIO1CLR |= PINO_P1_LCD_RS);}

//LCD OUT Port is created using Port 2 and port 3 
//port 2 = 0000 0000 0000 0000 0000 0000 1111 1100	 
//port 3 = 0000 0110 0000 0000 0000 0000 0000 0000	
#define BYTE_LCD_OUT(x) 	{DIR_LCD_OUT_PORT(); FIO2PIN &= ~0x000000FC; 		\
								FIO3PIN &= ~0x06000000; 						\
								FIO2PIN |= (x & 0x3F)<<2; FIO3PIN |= (x & 0xC0) << 19;}


//LCD backlite control definations
#ifdef ENABLE_LCD_BACKLITE
	#define PINO_P1_LCD_BKLT    0x80000000		//P1.31
	#define DIR_LCD_BKLT_PORT()	{FIO1DIR |= PINO_P1_LCD_BKLT;}
	#define B_LCD_BKLT(X)		{(X == SET) ? (FIO1SET |= PINO_P1_LCD_BKLT) : (FIO1CLR |= PINO_P1_LCD_BKLT);}
	#define ON_LCD_BACKLIGHT()	{DIR_LCD_BKLT_PORT(); B_LCD_BKLT(SET);}
	#define OFF_LCD_BACKLIGHT()	{DIR_LCD_BKLT_PORT(); B_LCD_BKLT(CLR);}
#endif

//=================================================================================================
/* Input Output Selection using 138 IC */
#define CS_IPCS1	0
#define CS_IPCS2	1
#define CS_OPCS1	2	//this pin is used as output in Biolite and as input in v1.6 board.
#define CS_OPCS2	3
#define CS_IPCS3	4
#define CS_OPCS3	5
#define CS_BUZZER	7
#define CS_NO_SEL 	8

//=================================================================================================
//I/O selection pins
#define PINO_P4_CSIP	0x10000000	  		//P4.28
#define PINO_P4_CSOP  	0x20000000			//P4.29

#define DIR_IO_DEC_PINS()		{FIO4DIR |= PINO_P4_CSIP | PINO_P4_CSOP;}

#define DIR_IO_OUT_PORT()		{FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000;}

#define DIR_IO_IN_PORT()		{FIO2DIR &= ~0x000000FC; FIO3DIR &= ~0x06000000;}

#define BYTE_IO_OUT_PORT(x)		{DIR_IO_OUT_PORT(); FIO2PIN &= ~0x000000FC; 	\
							  	  FIO3PIN &= ~0x06000000; 						\
							      FIO2PIN |= (x & 0x3F)<<2; FIO3PIN |= (x & 0xC0) << 19;}

#define BYTE_IO_READ_PORT(X)	{DIR_IO_IN_PORT(); X = (FIO2PIN & 0x000000FC) >> 2;	\
									X = X | ((FIO3PIN & 0x06000000) >> 19);}	   //ARMD0063								



extern volatile unsigned int BuffOPCS1Latch,BuffOPCS2Latch;			// Buffer to keep data which needs to be output to OPCS1 Latch
// Following is just to define the Latch 1 Output which we will use 
#define DEFAULT_CS1_OUT		0x05


#define CS1_IO_DOOR1	0x01
#define CS1_IO_DOTL1	0x02
#define CS1_IO_DOOR2	0x04
#define CS1_IO_RDBZ2	0x08
#define CS1_IO_RDLED2	0x10
#define CS1_IO_BUZOB	0x20
#define CS1_IO_NC1		0x40
#define CS1_IO_NC2		0x80


extern unsigned char F_BuzzerStatus;

#define BUZZER_OFF_INTERRUPT()	{F_BuzzerStatus=0;}	
#define BUZZER_ON_INTERRUPT()	{F_BuzzerStatus=1;}	


#define DOOR_OPEN(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_DOOR##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define DOOR_CLOSE(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_IO_DOOR##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define SET_DOTL(X)		{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch |= CS1_IO_DOTL##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define CLR_DOTL(X)		{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_DOTL##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define RDR_BUZ_ON(X)	{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch |= CS1_IO_RDBZ##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define RDR_BUZ_OFF(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_RDBZ##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define RDR_LED_ON(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_IO_RDLED##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL);	\
						}

#define RDR_LED_OFF(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_RDLED##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define BUZZER_ON()		{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_IO_BUZOB;		\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); BUZZER_ON_INTERRUPT(); 	\
						}

#define BUZZER_OFF()	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_BUZOB;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); BUZZER_OFF_INTERRUPT();	\
						}
extern volatile unsigned int readinput;


#define READ_INPUT(X)								\
	{   												\
		SelectIOCS(CS_IPCS1);							\
		BYTE_IO_READ_PORT(readinput);					\
		X = readinput; 									\
		SelectIOCS(CS_NO_SEL);							\
	}


#define BIT_PORT_EGRESS1	0
#define BIT_PORT_DORL1		1
#define BIT_PORT_FIRE		2								
#define BIT_PORT_TAMPER		3
#define BIT_PORT_IRSENSE	4
#define BIT_PORT_WOLED		5
#define BIT_PORT_INTRUSION	6//ARMD0326
#define BIT_PORT_NC2		7

#ifdef HARDWARE_SI032
	#define IN_IRSense		((IOInput >> BIT_PORT_IRSENSE) & 0x1)
#else
	#define IN_IRSense	1			 
#endif



// Active low intrusion indicates that intrusion happned .. as this hardware do not have same we make it default as 1
//#define IN_Intrusion		1 //use this for BLS h/w

#define IN_Intrusion	((IOInput >> BIT_PORT_INTRUSION) & 0x1)	//change this when using same code for arm biolite.BLS h/w
                        //ARMD0326
#define IN_Egress1		((IOInput >> BIT_PORT_EGRESS1) & 0x1)	
#define IN_Dotl1		((IOInput >> BIT_PORT_DORL1) & 0x1)
#define IN_Fire			((IOInput >> BIT_PORT_FIRE) & 0x1)
#define IN_Tamper		((IOInput >> BIT_PORT_TAMPER) & 0x1)
#define IN_WOLed		((IOInput >> BIT_PORT_WOLED) & 0x1)


/*---------------------------------------------------------------
Weigand O/P port definations
D0 = P0.28
D1 = P1.24 
WOLEDIN = I/P Bus pin6 
---------------------------------------------------------------*/		  
#define PINO_B_WOUTD0	0x10000000
#define PINO_B_WOUTD1	0x01000000

#define DIR_WEIGAND_OUT_PORT()	{FIO0DIR |= PINO_B_WOUTD0; FIO1DIR |= PINO_B_WOUTD1;}

#define B_WOUTD0(X)	{(X == SET) ? (FIO0SET |= PINO_B_WOUTD0) : (FIO0CLR |= PINO_B_WOUTD0);}
#define B_WOUTD1(X)	{(X == SET) ? (FIO1SET |= PINO_B_WOUTD1) : (FIO1CLR |= PINO_B_WOUTD1);}

#define WEIGAND_0_HIGH()	{DIR_WEIGAND_OUT_PORT(); B_WOUTD0(SET);} 
#define WEIGAND_1_HIGH()	{DIR_WEIGAND_OUT_PORT(); B_WOUTD1(SET);}
#define WEIGAND_0_LOW()		{DIR_WEIGAND_OUT_PORT(); B_WOUTD0(CLR);}
#define WEIGAND_1_LOW()		{DIR_WEIGAND_OUT_PORT(); B_WOUTD1(CLR);}

#define CHK_WIGAND_IN_GRANT() 	(IN_WOLed == CLR)


extern unsigned char F_OutPutLock;
extern void SelectIOCS(unsigned char iotype);
extern void DoorClose(unsigned char drno);
extern void DoorOpen(unsigned char drno);
extern void DOTLLedOff(unsigned int rdno);
extern void DOTLLedOn(unsigned int rdno);
extern void WeigandLedOff(unsigned char rdno);
extern void WeigandLedOn(unsigned char rdno);
extern void WeigandBuzOn(unsigned char rdno);
extern void WeigandBuzOff(unsigned char rdno);
extern void InitialiseIO(void);
extern void MakeWeigandBuzON(unsigned char rdrno, unsigned char type);
extern void WeigandBuzControl(unsigned char rdno);
