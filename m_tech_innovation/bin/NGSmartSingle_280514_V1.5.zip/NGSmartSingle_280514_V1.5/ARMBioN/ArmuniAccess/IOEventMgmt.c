#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "LPC23xx.h"
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "spi.h"
#include "rtc.h"
#include "access.h"
#include "tranxmgmt.h" 
#include "userintf.h" 
#include "cardmgmt.h"
#include "memory.h"
#include "memmap.h"
#include "rdcont.h"
#include "IOEventMgmt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "emailsend.h"
__packed unsigned short IOEventInfo[MAX_EVENT_IO+1];


/*** BeginHeader GenerateEvent*/
unsigned char GenerateEvent(unsigned char eventno,unsigned char channel);
/*** EndHeader */
unsigned char GenerateEvent(unsigned char eventno,unsigned char channel)
{
unsigned int eventio;
 //  ReadIOEventInfoFromFlash();
   eventio = IOEventInfo[eventno];
   if(eventio & EV_IOCONTROL_ON_IO1)			//Camera (Relay 2) o/p in share dotl mode
   {
		if(CHECK_SHARED_DOTL(0))      //Make relay 2 on
			DoorConditionControl(1,DR_EXT_RLY_ON,ReaderInfo[1].DOpTime,ReaderInfo[1].DOTLTime);
      if(Doorinfo.DotlEvent)
      {
         DRStruct[channel-1].EVENT_DOTL = SET;
         DRStruct[channel-1].EventDotlTime = ReaderInfo[channel-1].DOpTime;
      }	
	}
#ifdef ENABLE_EMAIL_SEND
	if((((EV_EMAIL_PATTERN & eventio)/0x100) & 0x000F) != 0)
		EmailAddToBuffer(TransWritePtr,EMAIL_TYPE_NORMAL);
#endif

 return 0;
}

