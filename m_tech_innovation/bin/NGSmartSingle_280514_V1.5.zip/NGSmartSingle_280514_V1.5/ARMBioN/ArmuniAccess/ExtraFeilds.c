// Birthdate , present, Template , etc 
// these information will be stored in 2nd flash 
// card no sho

#define FL_EXTRA_DATA_PAGE_NO   1   // 


__packed struct EXTRA_DATA 
{
		struct DATE_FORMAT BirthDate;   //3  // DOB
		unsigned char F_Present;				//2
		unsigned short ImageNo;					//1
}_ExtraData

#define SIZE_EXTRA_DATA 	(sizeof(_ExtraData)


