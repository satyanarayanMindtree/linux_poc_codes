#include <string.h>
#include "LPC23xx.h"			/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "irq.h"
#include "rtc.h"
//#include "timer.h"
#include "tranxmgmt.h"
#include "spi.h"
#include "serial.h"
#include "access.h"
#include "portlcd.h"
#include "Smartcard.h"
#include "userintf.h"
#include "rdcont.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#ifndef SUPPORT_ICLASS_RDR
	#include "scprocess.h"
#else
	#include "IClassRdrProcess.h"
#endif
	
#include "supremabio.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif

#ifdef	SMART_CARD 

/*

9)	Different Card information data source ( i.e. card info to be taken from smartcard or from local interface )

Command to set same is
$1lu,57,XXXX,chksum,enter
XXXXX = decimal value

To understand following convert above decimal to hex value and each bit is used to represent one data

#define CDATA_SOURCE_NAME			0x0001
#define CDATA_SOURCE_PIN			0x0002
#define CDATA_SOURCE_VALIDITY		0x0004
#define CDATA_SOURCE_TEMPLATE		0x0008
#define CDATA_SOURCE_USER_TYPE 	0x0010     // Card is visitor or normal employee
#define CDATA_SOURCE_ACCESSLEVEL	0x0020

 Red is yet to implement in current version code�

Value	Hex	6	5=accesslevel	4=usertype	3=template	2=validity	1=Pin	0 = Name
0	0x0000		LocalFlash	LocalFlash	LocalFlash	LocalFlash	LocalFlash	LocalFlash
1	0x0001		LocalFlash	LocalFlash	LocalFlash	LocalFlash	LocalFlash	SmartCard
2	0x0002		LocalFlash	LocalFlash	LocalFlash	LocalFlash	SmartCard	LocalFlash
3	0x0003		LocalFlash	LocalFlash	LocalFlash	LocalFlash	SmartCard	SmartCard
4	0x0004		LocalFlash	LocalFlash	LocalFlash	SmartCard	LocalFlash	LocalFlash
5	0x0005		LocalFlash	LocalFlash	LocalFlash	SmartCard	LocalFlash	SmartCard
|	|
|	|

To use pin and template from smartcard and rest from controller flash command will be
0x00A
$1lu,57,10,chksum,enter

To take all template, validity, pin anf name from smartcard use command 0x000F

$1lu,57,15,chkusm,enter

Note:
1) You have to ensure that if u r going to use controller for smartcard template then above bit should be enabled.
2) If u have programmed in Name Type as smartcard then u need to enable name from smartcard in above..



10)	Card Expired  implemented for smart card V date time need to enable same using above functionality.. data source should be smartcard. I have not implemented card validity from flash
Transaction code for same is
#define EVENT_Card_Expired	3

11)	Smartcard layout
InfoBlock
// Smartcard Info Block Details
0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15
CnoMSB	CNo	CNo	CnoLSB	PinMSB	PinLSB	V DD	V MM	V YY	V HH	V MM	 Emp No MSB	Emp No 	Emp No 	Emp No LSB	 Emp Type < FUTURE


*/
#define ENABLE_SMART_CARD_RDR

#ifdef ENABLE_SMART_CARD_RDR


/*-------------------------------------------------------------------------*/
//external variable
extern BYTE F_KeyIdleTime,F_CardFound1;
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo,cardno;
extern BYTE FaclityCode1,FaclityCode2,FaclityCode,ReaderNo;
extern BYTE UserName[MESSAGE_BYTES+1];
extern SYSInfo SysInfo;
extern BYTE FacCode;
extern unsigned char IdleKeyCounter;
extern unsigned char DisplayMode;

static unsigned char SCPollType;
//local variable

extern BYTE SC1_PollTime;

//extern unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE]; 
//	extern unsigned char BufferTemp[MAX_BIO_TEMPLATE_SIZE]; 


BYTE SC2_PollTime;

BYTE  SmartCardTimeOut;
char SCError;

extern  BYTE  SCReaderNo;
BYTE F_SerialSmartCardPollProxy;

BYTE F_SerialECheckSum;
WORD SerialEReceiveCount;


extern SmartCardData CurrentCard;
unsigned char TempSCBuffer[64];			// contain the data to be write on smart card   MANDAR


/*-------------------------------------------------------------------------*/
/*** BeginHeader MainLoopPollForSCardRDR*/
void MainLoopPollForSCardRDR(void);
/*** EndHeader */
void MainLoopPollForSCardRDR(void)
{
   if(SysInfo.SCReaderEnDis[0])     // DA00147
   {
      if(SC1_PollTime >= POLL_DELAY_TIME)
      {
         SC1_PollTime = 0;
         SCReaderNo = 1;
         if(SysInfo.SCCardNoType == 0)
            SCPollType = '7';
         else
            SCPollType = '2';
         SendSpecialPollCommandSC(SCPollType,0,0,0);
      }
   }
#ifdef USE_SMART_READER2
   if(SysInfo.SCReaderEnDis[1])
   {
      if(SC2_PollTime >= POLL_DELAY_TIME)
      {

         SC2_PollTime = 0;
         SCReaderNo = 2;
         if(SysInfo.SCCardNoType == 0)
           SCPollType = '7';
         else
            SCPollType = '2';
         SendSpecialPollCommandSC(SCPollType,0,0,0);
      }
   }
#endif
}

/*-------------------------------------------------------------------------*/


/*** BeginHeader SmartCardSerialMainLoop*/
void SmartCardSerialMainLoop(void);
/*** EndHeader */
void SmartCardSerialMainLoop(void)
{

	if(PortObj[SER_SMART_RD1_PORT].F_SerProxy != CLR)
	{
	   PortObj[SER_SMART_RD1_PORT].F_SerProxy = CLR;
	   HandleSerialSmartCardReceiveData(1,(char *)PortObj[SER_SMART_RD1_PORT].RxBuffer);
	}
#ifdef  USE_SMART_READER2
	if(PortObj[SER_SMART_RD2_PORT].F_SerProxy != CLR)
	{
	   PortObj[SER_SMART_RD2_PORT].F_SerProxy = CLR;
	   HandleSerialSmartCardReceiveData(2,PortObj[SER_SMART_RD1_PORT].RxBuffer);
	}
#endif
}

/*-------------------------------------------------------------------------*/
//Read date from smart card and authenticate data
/*** BeginHeader AuthSmartCard*/
char AuthSmartCard(unsigned char key, unsigned char sector,unsigned char block);
/*** EndHeader */
char AuthSmartCard(unsigned char key,unsigned char sector,unsigned char block)
{
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_AUTH_BLOCK);
  	TransmitCharToSmart(HexToAscii(key&0x01));
  	TransmitCharToSmart(HexToAscii(sector/0x10));
  	TransmitCharToSmart(HexToAscii(sector & 0x0f));
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	if(block == 0)
	{
      SCError = 0;
		return(0);
	}
	else
	{
		MsgPrint(1,block,"AuthSmartCard:Smart card ERROR = ");
      SCError = block;
		return(block);
	}
}
/*-------------------------------------------------------------------------*/
/*** BeginHeader ReqAntiSelAuthSmartCard*/
char ReqAntiSelAuthSmartCard(unsigned char key, unsigned char sector,unsigned char block,unsigned long *card);
/*** EndHeader */
char ReqAntiSelAuthSmartCard(unsigned char key,unsigned char sector,unsigned char block,unsigned long *card)
{
	F_SerialECheckSum = 1;
	SerialECheckSum = 0;
	SerialEReceiveCount = 0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_REQ_ANTI_SEL_AUTH_CARD);
  	TransmitCharToSmart(HexToAscii(0x00));  					//request to card not in Halt state
  	TransmitCharToSmart(HexToAscii(key&0x01));
  	TransmitCharToSmart(HexToAscii(sector/0x10));
  	TransmitCharToSmart(HexToAscii(sector & 0x0f));
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	if(block == 0)
	{
      SCError = 0;
      *card = (unsigned long)SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION+2]) * (unsigned long)0x1000000;
      *card += (unsigned long)(SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION+4]) * 0x10000) & 0x00FFFFFF;
      *card += (unsigned long)(SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION+6]) * 0x100) & 0xFFFF;
      *card += (unsigned long)SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION+8]) & 0xFF;
		return(0);
	}
	else
	{
		MsgPrint(1,block,"ReqAntiSelAuthSmartCard:Smart card ERROR = ");
      SCError = block;
		return(block);
	}
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader ReadSmartCardValue*/
char ReadSmartCardValue(unsigned char block, unsigned long *value);
/*** EndHeader */
char ReadSmartCardValue(unsigned char block, unsigned long *value)
{
	unsigned char t_data,rbuffer[20];
   unsigned long cmpvalue;
	t_data = ReadSmartCardBlock(block,rbuffer);
   SCError = t_data;
   *value = 0;
	if( t_data ==0)
	{
   		*value= rbuffer[3]*0x1000000;
		*value= *value + rbuffer[2]*0x10000;
		*value= *value + rbuffer[1]*0x100;
		*value= *value + rbuffer[0];
   		cmpvalue= rbuffer[7]*0x1000000;
		cmpvalue= cmpvalue + rbuffer[6]*0x10000;
		cmpvalue= cmpvalue + rbuffer[5]*0x100;
		cmpvalue= cmpvalue + rbuffer[4];
		cmpvalue = ~cmpvalue;
      if(cmpvalue == *value)
      {
       	return(0);
      }
      else
      {
      	*value = 0;
       	return(MI_BAD_VALUE_DATA);
      }
   }
   else
   	return(t_data);
}

/*** BeginHeader RequestSmartCard*/
char RequestSmartCard(void);
/*** EndHeader */
char RequestSmartCard(void)
{
/* Check smart Card present or not and give type of Card 1K == 400 & 4K == 200 */
	unsigned char status;
   F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_CARD_REQUEST);
	TransmitCharToSmart('r');
   TransmitCharToSmart(SMART_TERMINATOR2);

	SmartCardTimeOut = 0;
	status = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
   	if(status == 0)
   	{
   		return(SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION + 2]));    //trasmitt either 2/4
   	}
   	else
   		return(SMART_CARD_READ_ERROR);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader ReadSmartCardBlock*/
char ReadSmartCardBlock(unsigned char block,unsigned char *rbuffer);
/*** EndHeader */
char ReadSmartCardBlock(unsigned char block,unsigned char *rbuffer)
{
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_READ_CARD);
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	SCError = block;
	if(block == 0)
	{
		for(block=0;block<16; block++)
		{
			rbuffer[block] = SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION + 2 + (block*2)]);
		}
		return(0);
	}
	else
	{
		MsgPrint(1,block,"ReadSmartCardBlock:Smart card ERROR = ");
		return(SMART_CARD_READ_ERROR);
	}

}

/*-------------------------------------------------------------------------*/
/*** BeginHeader SmartDecrementBlock*/
char SmartDecrementBlock(unsigned char block,unsigned long value);
/*** EndHeader */
char SmartDecrementBlock(unsigned char block,unsigned long value)
{
/*	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_DECREMENT_BLOCK);
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
	SendLongBCDToX(value,(SCReaderNo == 2)?SER_SMART_RD2_PORT:SER_SMART_RD1_PORT);    //  (SCReaderNo == 2)?SER_SMART_RD2_PORT:SER_SMART_RD1_PORT;  SmartR (Poll.ReqType ==0)?0x26:0x52
    TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	SCError = block;
	if(block == 0)
	{
		return(0);
	}
	else
	{
		return(MI_DECRERR);
	}
*/
		return(MI_DECRERR);

}
/*-------------------------------------------------------------------------*/
/*** BeginHeader PrepareValueBlock*/
char PrepareValueBlock(unsigned char *valuestr,unsigned long value,unsigned char transadd);
/*** EndHeader */
char PrepareValueBlock(unsigned char *valuestr,unsigned long value,unsigned char transadd)
{
/*
   Lltoxr(value,valuestr);
   Lltoxr(~value,&valuestr[4]);
   Lltoxr(value,&valuestr[4+4]);
   valuestr[4+4+4]= transadd & 0xFF;
   valuestr[4+4+4+1]= (~transadd) & 0xFF;
   valuestr[4+4+4+2]= (transadd )& 0xFF;
   valuestr[4+4+4+3]= (~transadd ) & 0xFF;
   return(0);
*/
return(0);
}

// Following function reads valus from string of smartcard read data block

/*** BeginHeader ReadValueFromBlockStr*/
char ReadValueFromBlockStr(unsigned char *blockstr, unsigned long *value);
/*** EndHeader */
char ReadValueFromBlockStr(unsigned char *blockstr, unsigned long *value)
{
      unsigned long cmpvalue;

   	*value= blockstr[3]*0x1000000;
		*value= *value + blockstr[2]*0x10000;
		*value= *value + blockstr[1]*0x100;
		*value= *value + blockstr[0];
   	cmpvalue= blockstr[7]*0x1000000;
		cmpvalue= cmpvalue + blockstr[6]*0x10000;
		cmpvalue= cmpvalue + blockstr[5]*0x100;
		cmpvalue= cmpvalue + blockstr[4];
		cmpvalue = ~cmpvalue;
      if(*value == cmpvalue)
      {
       	return(0);
      }
      else
      {
      	*value = 0;
       	return(MI_BAD_VALUE_DATA);
      }
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader SendPollCommandToSmartCard*/
void SendPollCommandToSmartCard(void);
/*** EndHeader */
void SendPollCommandToSmartCard(void)
{
//   printf("Poll command send \n");
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_POLL_CARD);
	TransmitCharToSmart(SMART_POLL_TYPE_FOR_CARD_NO);
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader SendStopPollCommandToSmartCard*/
void SendStopPollCommandToSmartCard(void);
/*** EndHeader */
void SendStopPollCommandToSmartCard(void)
{
//   printf("Poll command send \n");
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_POLL_CARD);
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader SendSpecialPollCommandSC*/
char SendSpecialPollCommandSC(unsigned char poll,unsigned char key, unsigned char sector, unsigned char block);
/*** EndHeader */
char SendSpecialPollCommandSC(unsigned char poll,unsigned char key, unsigned char sector, unsigned char block)
{
//   printf("Poll command send \n");
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_POLL_CARD);
	TransmitCharToSmart(poll);
	TransmitCharToSmart('0');
  	TransmitCharToSmart(HexToAscii(key&0x01));
  	TransmitCharToSmart(HexToAscii(sector/0x10));
  	TransmitCharToSmart(HexToAscii(sector & 0x0f));
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	return(WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo));
//	MsgPrint(1,block,"SendSpecialPollCommandSC Smart card RDR CONNECTION ERROR = ");
}

/*** BeginHeader SendHaltToSmartCard*/
void SendHaltToSmartCard(void);
/*** EndHeader */
void SendHaltToSmartCard(void)
{
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_CARD_HALT_COMMAND);
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
}
/*-------------------------------------------------------------------------*/
/*** BeginHeader AuthReadSmartCardBlock*/
char AuthReadSmartCardBlock(unsigned char block,unsigned long *cardno,unsigned char *rBuffer);
/*** EndHeader */
// This will do authentication and then Read
char AuthReadSmartCardBlock(unsigned char block,unsigned long *cardno,unsigned char *rBuffer)
{
//	unsigned char temp1;

	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_AUTH_READ_BLOCK);
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	SCError = block;
	if(block == 0)
	{
   	if(cardno !=NULL)
      {
	      *cardno = HexNoToInteger(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION + 2]);
	      *cardno = (*cardno * 0x10000) + HexNoToInteger(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION + 6]);
      }
      if(rBuffer!=NULL)
		{
	      for(block=0;block<16; block++)
	      {
	         rBuffer[block] = SerialAsciiToHex(&SmartSerBuffer[SMART_CARD_COMMAND_POSITION + 10 + (block*2)]);
//            printf("%x ",rBuffer[block]);
//				TransmitChar(rbuffer[block]);
	      }
//         printf("\n-->");
      }
//		TransmitChar(ETX);
		return(0);
	}
	else
	{
		MsgPrint(1,block,"AuthReadSmartCardBlock Smart card ERROR = ");
		return(SMART_CARD_READ_ERROR);
	}
}

/*** BeginHeader  AuthWriteSmartCardBlock*****/
char AuthWriteSmartCardBlock(unsigned char block,unsigned char datalength,unsigned char *sdata);
/*** EndHeader */
char AuthWriteSmartCardBlock(unsigned char block,unsigned char datalength,unsigned char *sdata)
{
//chk whether we can use SysInfo.SCKeyType and SysInfo.SCKeySector parameter for reading using programmable key
	// Sector No. is 0
  	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_AUTH_WRITE_BLOCK);
    TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
	TransmitCharToSmart('0');
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
   for(block=0;block<16; block++)
	{
		if(block > datalength )
      {
			TransmitCharToSmart('2');
			TransmitCharToSmart('0');
      }
      else
      {
			TransmitCharToSmart(HexToAscii(sdata[block]/0x10));
			TransmitCharToSmart(HexToAscii(sdata[block]&0x0F));
		}
	}
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	SCError = block;
	if(block == 0)
		return 0;
	else
		return(STATUS_SMART_CARD_WRITE_ERROR);
}
/*------------------------------------------------------------------------------------------------*/

char WaitSmartCardResponse(WORD timeout,BYTE scrdnumber)
{
	while(1)
	{
		if(PortObj[SER_SMART_RD1_PORT].F_SerProxy)
		{
			PortObj[SER_SMART_RD1_PORT].F_SerProxy = CLR;
			if(PortObj[SER_SMART_RD1_PORT].RxBuffer[1] =='x')
			{
				return((AsciiToHex(PortObj[SER_SMART_RD1_PORT].RxBuffer[2])*0x10 )+ AsciiToHex(PortObj[SER_SMART_RD1_PORT].RxBuffer[3]));
			}
			else
				return(0);
		}
		else if(SmartCardTimeOut >= timeout)				 //ARMD0440
	    {
		    //	MsgPrint(MSG_SMART_CARD,SmartCardTimeOut,"Smart card Time out");     
//			L_DisplayROMStr("SC_RDR TimeOut   ",16,ROW_USER_ENTRY);		   //?? Not working
//			F_KeyIdleTime = CLR;
//			IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
			if((DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == USER_IDENTIFY_MODE) || (DisplayMode == USER_VERIFY_MODE))
	        {
	        	MakeSound(SOUND_SYS_ERROR);
				L_DisplayROMStr("SC Reader Fail   ",16,ROW_USER_ENTRY);			  //ARMD0439
				L_DisplayCharAtRow(14,SCReaderNo+'0',ROW_USER_ENTRY);
				F_KeyIdleTime = CLR;
				IdleKeyCounter = MAX_KEY_IDLE_TIME - 4;
				DisplayMode = MODE_WAIT_FOR_CARD;
				F_BIO_COMM = CLR; //DISABLE_BIO_COMM();
	        }
			return(MI_TIME_OUT);	  	//ARMD0440
	    }
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
	}
}


/*-------------------------------------------------------------------------*/
//This Function is used to write the data onto the smart card block
/*** BeginHeader WriteSmartCardBlock*/
char WriteSmartCardBlock(unsigned char block, unsigned char datalength,unsigned char *sdata) ;
/*** EndHeader */
char WriteSmartCardBlock(unsigned char block, unsigned char datalength,unsigned char *sdata)
{
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_WRITE_CARD);
  	TransmitCharToSmart(HexToAscii(block/0x10));
  	TransmitCharToSmart(HexToAscii(block & 0x0f));
   for(block=0;block<16; block++)
	{
		if(block > datalength )
      {
			TransmitCharToSmart('2');
			TransmitCharToSmart('0');
      }
      else
      {
			TransmitCharToSmart(HexToAscii(sdata[block]/0x10));
			TransmitCharToSmart(HexToAscii(sdata[block]&0x0F));
		}
	}
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
	block = WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	SCError = block;
	if(block == 0)
		return 0;
	else
		return(STATUS_SMART_CARD_WRITE_ERROR);
}


/*-------------------------------------------------------------------------*/

/*** BeginHeader TransmitCharToSmart*/
char TransmitCharToSmart(unsigned char data) ;
/*** EndHeader */
char TransmitCharToSmart(unsigned char data)
{
	return( TransmitCharToX(data,SER_SMART_RD1_PORT));

	/*if(SCReaderNo ==2)
	{
	   	return( TransmitCharToX(data,SER_SMART_RD2_PORT));
	}
	else
	{
	   return( TransmitCharToX(data,SER_SMART_RD1_PORT));
	}
	return(0);*/
}

/*------------------------------------------------------------------------------------------------*/

/*** BeginHeader HandleSerialSmartCardData*/
void HandleSerialSmartCardData(unsigned char n,unsigned char *smartpollbuff);
/*** EndHeader */
void HandleSerialSmartCardData(unsigned char n,unsigned char *smartpollbuff)
{
   if(F_SerialSmartCardPollProxy == CLR)
    {
       if(n == SMART_START_RESPONSE_CHAR)
       {
          F_ReceiveSmartCardPortData = SET;
          SerialEReceiveCount = 0 ;
       }
       if(F_ReceiveSmartCardPortData == SET)
       {
          if(SerialEReceiveCount>=MAX_SMART_SER_BUFF)
          {
             SerERcvdCnt = SerialEReceiveCount = MAX_SMART_SER_BUFF;
             F_SerialSmartCardPollProxy = SET;
             F_ReceiveSmartCardPortData = CLR;
          }
          else
          {
             smartpollbuff[SerialEReceiveCount] = n;
             SerialEReceiveCount ++;
             SerERcvdCnt = SerialEReceiveCount;
          }
          if((n == SMART_TERMINATOR1)||(n == SMART_TERMINATOR2))
          {  //if(  SerialEReceiveCount > 6)
             F_SerialSmartCardPollProxy = SET;
             SerERcvdCnt = SerialEReceiveCount;
             F_ReceiveSmartCardPortData = CLR;
          }
       }
    }
}


/*-------------------------------------------------------------------------*/


/*
void HandleSerSCData(BYTE n,BYTE readerno)
{
	if( readerno ==2 )
   {
   		if(SC2_F_RecProxy == CLR)
		{
	     	if(n == SMART_START_RESPONSE_CHAR)
	     {
	        SC2_F_RecData = SET;
	        SC2_RecCount = 0 ;
	     }
	     if(SC2_F_RecData == SET)
	     {
	        if(SC2_RecCount>=MAX_SC_POLL_BUFF)
	        {
	           SC2_FCount = SC2_RecCount = MAX_SC_POLL_BUFF;
	           SC2_F_RecProxy = SET;
	           SC2_F_RecData = CLR;
	        }
	        else
	        {
	           SC2_Buffer[SC2_RecCount] = n;
	           SC2_RecCount ++;
	           SC2_FCount = SC2_RecCount;
	        }
	        if((n == SMART_TERMINATOR1)||(n == SMART_TERMINATOR2))
	        {  //if(  SerialEReceiveCount > 6)
	           SC2_F_RecProxy = SET;
	           SC2_F_RecData = CLR;
	           SC2_FCount = SC2_RecCount;
	        }
	     }
	  	}
   }
   else
   {
		if(SC1_F_RecProxy == CLR)
		{
	     	if(n == SMART_START_RESPONSE_CHAR)
	     {
	        SC1_F_RecData = SET;
	        SC1_RecCount = 0 ;
	     }
	     if(SC1_F_RecData == SET)
	     {
	        if(SC1_RecCount>=MAX_SC_POLL_BUFF)
	        {
	           SC1_FCount = SC1_RecCount = MAX_SC_POLL_BUFF;
	           SC1_F_RecProxy = SET;
	           SC1_F_RecData = CLR;
	        }
	        else
	        {
	           SC1_Buffer[SC1_RecCount] = n;
	           SC1_RecCount ++;
	           SC1_FCount = SC1_RecCount;
	        }
	        if((n == SMART_TERMINATOR1)||(n == SMART_TERMINATOR2))
	        {  //if(  SerialEReceiveCount > 6)
	           SC1_F_RecProxy = SET;
	           SC1_F_RecData = CLR;
	           SC1_FCount = SC1_RecCount;
	        }
	     }
	  	}
  	}
}

*/
/*-------------------------------------------------------------------------*/
/*** BeginHeader SendKeyToSmartCardReader*/
char SendKeyToSmartCardReader(unsigned char *buffer);
/*** EndHeader */
char SendKeyToSmartCardReader(unsigned char *buffer)
{
unsigned char len;
//   printf("Poll command send \n");
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_KEY_SEND);
	for(len=0;len<12+3;len++)
   {
   	TransmitCharToSmart(buffer[len]);
		TransmitChar(buffer[len]);
   }
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   len= WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
   return(len);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader SendKeyToSCReader*/
char SendKeyToSCReader(unsigned char keytype,unsigned char sector,unsigned char *buffer);
/*** EndHeader */
char SendKeyToSCReader(unsigned char keytype,unsigned char sector,unsigned char *buffer)
{
// Write Key on smart card
unsigned char len;
//   printf("Poll command send \n");
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_KEY_SEND);
	TransmitCharToSmart(HexToAscii((sector/0x10)&0x0f));
	TransmitCharToSmart(HexToAscii((sector%0x10)&0x0f));
	TransmitCharToSmart(keytype+'0');
	for(len=0;len<12;len++)
   {
   	TransmitCharToSmart(buffer[len]);
   }
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   len= WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
   return(len);
}

/*-------------------------------------------------------------------------*/
/*** BeginHeader SendCommandToSCReader*/
char SendCommandToSCReader( char *buffer, unsigned char len, char *outstr);
/*** EndHeader */
char SendCommandToSCReader( char *buffer, unsigned char len,char *outstr)
{
unsigned char i;
//   printf("Poll command send \n");
	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	for(i=0;i<len;i++)
   	{
   		TransmitCharToSmart(buffer[i]);
   	}
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   	len= WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
	if(len == 0)
	{
   		if(SerERcvdCnt >=127)
			SerERcvdCnt=126;
      	SmartSerBuffer[SerERcvdCnt-1]='\0';
		strncpy(outstr,(char *)SmartSerBuffer,SerERcvdCnt);
	}
   return(len);
}



/*-------------------------------------------------------------------------*/
/*** BeginHeader SendLEDContToSCReader*/
char SendLEDContToSCReader(unsigned char type,unsigned char time);
/*** EndHeader */
char SendLEDContToSCReader(unsigned char type,unsigned char time)
{
unsigned char len;

	F_SerialECheckSum = 1;
	SerialECheckSum=0;
	SerialEReceiveCount=0;
	SmartCardTimeOut = 0;
	F_ReceiveSmartCardPortData = CLR;
	TransmitCharToSmart('$');
	TransmitCharToSmart('1');
	TransmitCharToSmart(SMART_LED_CONTROL);
	TransmitCharToSmart(HexToAscii((type/0x10)&0x0f));
	TransmitCharToSmart(HexToAscii((type%0x10)&0x0f));
   TransmitCharToSmart(HexToAscii((time/0x10)&0x0f));
	TransmitCharToSmart(HexToAscii((time%0x10)&0x0f));
	TransmitCharToSmart(SMART_TERMINATOR2);
	SmartCardTimeOut = 0;
   len= WaitSmartCardResponse(SMART_CARD_COMMAND_TIMEOUT,SCReaderNo);
   return(len);
}


/*** BeginHeader ReadSmartCardDataBlock*/
unsigned char ReadSmartCardDataBlock(unsigned char boffset,unsigned int bsize,unsigned char *buffer,unsigned char clayout);
/*** EndHeader */
unsigned char ReadSmartCardDataBlock(unsigned char boffset,unsigned int bsize,unsigned char *buffer,unsigned char clayout)
{
// Read Smart Card Data from Smart Card Memory

	unsigned char blocks,count,status,i;
//   long cardno;
   blocks = bsize/16;
   count =boffset;
	status = AuthSmartCard(SysInfo.SCKeyType[clayout],SysInfo.SCKeySector[clayout],boffset);
	for(i=0;i<blocks;i++)
   {
      if(((((count+1)%4)==0)&&(count<=127))||((((count+1)%16)==0)&&(count>=128)))  // Pankaj modified to support 4K card layout if((((count+1)%4)==0) &&(count<=127) ))
      {
      	// indicates this is sector trailer
			count++;
			status = AuthSmartCard(SysInfo.SCKeyType[clayout],SysInfo.SCKeySector[clayout],count);
			if(status !=0)
      		return(status);
      }
		status = ReadSmartCardBlock(count,&buffer[i*16]);
//      status=AuthReadSmartCardBlock(count,&cardno,&buffer[i*16]);
//      printf("Authread block %d \n",count);
		if(status !=0)
      	return(status);
		count++;
   }
   return(0);
}



void HandleSerialSmartCardReceiveData(char readerno,char *scbuffer)
{
// This is to handle smartcard response when Poll command is issued
	unsigned int t_data;
   	char status;
   	unsigned long cardno;
//   SmartCardPollTimeout = 0;
   	if(readerno ==1 )
   		SC1_PollTime = 0;
   	else
		SC2_PollTime = 0;
   	SCReaderNo = readerno;    // this gives from which reader we have got card, SCReader
	switch(DisplayMode)
	{
      	case MODE_ADMIN_PASSWORD:
	  		if(DisplaySubMode == 0xFF)
	         	return;
		case MODE_ADMIN_ADD:
		case MODE_ADMIN_DEL:
		case MODE_ADMIN_CHANGE:
   		case MODE_SEARCH_CARD:
   		case MODE_DUA_SEARCH_CARD:			//ARMF2010
	   	case MODE_ADD_CARD:
	   	case MODE_WAIT_FOR_CARD:
	   	case MODE_FACILITY_CODE:
	   	case MODE_DEL_CARD:
		case MODE_CHANGE_PIN:
		case MODE_CARD_ADD_DATA:    		//shree 19Nov
//#ifndef  BIO_METRIC
	   	case MODE_BULK_ADD_CARD:         //201210-2
//#endif
#ifdef BIO_SMART_TEMPLATE
#ifdef BIO_METRIC
		case MODE_ADD_FINGER_TO_ID:
      	case USER_IDENTIFY_MODE :
#endif
#endif
		case MODE_WRITE_TEMPLATE_TO_CARD:
      	if(scbuffer[SMART_CARD_COMMAND_POSITION ]!='x')
	      {
	         if((scbuffer[SMART_CARD_COMMAND_POSITION + 1]=='0')&&(scbuffer[SMART_CARD_COMMAND_POSITION]=='0'))
	         {
	            if((scbuffer[SMART_CARD_COMMAND_POSITION + 2] == 'P')&&(scbuffer[SMART_CARD_COMMAND_POSITION + 3] == SCPollType))
	            {
               		t_data = 0;
					ReceivedCardNo =0;
				    SMARTReaderNo =readerno;
					ReaderNo = readerno;
					t_data = HexNoToInteger((BYTE *)&scbuffer[SMART_CARD_COMMAND_POSITION + 4]);
                  	cardno = t_data;
	               	t_data = HexNoToInteger((BYTE *)&scbuffer[SMART_CARD_COMMAND_POSITION + 8]);
	               	cardno = (unsigned long) ( cardno *(unsigned long)0x10000) + (unsigned long) t_data ;
					ReceivedCardNo = cardno;
#ifdef BIO_METRIC
            		if((DisplayMode == MODE_WAIT_FOR_CARD) || (USER_IDENTIFY_MODE ==DisplayMode) || (DisplayMode == MODE_ADMIN_PASSWORD))
#else
                  	if((DisplayMode == MODE_WAIT_FOR_CARD) || (DisplayMode == MODE_ADMIN_PASSWORD))
#endif
                  	{
#ifndef BIO_SMART_TEMPLATE
                   		ReaderData[0].F_CardFound = SET;
#endif
#ifdef BIO_SMART_TEMPLATE
						if(INTRUSION_STATUS == CLR)            		//A00016
                 		{
             				L_DisplayROMStr("Reading Card.....",16,ROW_USER_ENTRY);
                   		}
#ifdef BIO_METRIC	
						if((readerno == 1)||(CHECK_TWO_DOOR(readerno)))		// if we are going to support biometric for both in and out reader then use following
#else					
						if(readerno == 1)
#endif
						{
#ifdef BIO_METRIC
                       		status = ReadSmartCardAllData(readerno);
#else
							status = ReadSmartCardLayout();
#endif
							if( status !=0)
	                    	{
                       			if(status == ERR_SC_LAYOUT_ERROR)
									L_DisplayROMStr("SC Layout ERROR",16,ROW_USER_ENTRY);
                           		else if(status == EVENT_INVALID_CARD)
                           		{
	                              	MsgPrint(MSG_WARNING,EVENT_INVALID_CARD,"Invalid Card returncode=");      //shree 19Jan09
	         	                  	StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,ReaderNo,EVENT_INVALID_CARD);  //shree 19Jan09
		                           	MakeSound(SOUND_CARD_NOT_FOUND);
		                           	HandleDisplayErrorMessages(EVENT_INVALID_CARD);     //shree 19Jan09
		                           	F_KeyIdleTime = CLR;
		                           	IdleKeyCounter = MAX_KEY_IDLE_TIME-2;
		                      		return;
                           		}
                           		else
                           			L_DisplayROMStr("Show Card Again ",16,ROW_USER_ENTRY);
	                      		goto G_DelayedHaltcommand;
	                     	}
                     	}
                     	else
                     	{
                     		status = ReadSmartCardLayout();
	                     	if(status !=0)
	                        {
	                           if(status == ERR_SC_LAYOUT_ERROR)
	                              L_DisplayROMStr("SC Layout ERROR",16,ROW_USER_ENTRY);
	                           else if(status == EVENT_INVALID_CARD)
	                           {
	                              MsgPrint(MSG_WARNING,EVENT_INVALID_CARD,"Invalid Card returncode=");      //shree 19Jan09
	                              StoreCardInTrDB((CARDNO_DATA_STORAGE_TYPE)CurrentUser.SearchCard.CardNo,ReaderNo,EVENT_INVALID_CARD);  //shree 19Jan09
	                              MakeSound(SOUND_CARD_NOT_FOUND);
	                              HandleDisplayErrorMessages(EVENT_INVALID_CARD);     //shree 19Jan09
	                              F_KeyIdleTime = CLR;
	                              IdleKeyCounter = MAX_KEY_IDLE_TIME-2;
	                              return;
	                           }
	                           else
	                              L_DisplayROMStr("Show Card Again ",16,ROW_USER_ENTRY);
	                           goto G_DelayedHaltcommand;
		                     }
	                     }
 	                 	if((SysInfo.SCCardNoType == SC_CT_TEMPLATE_BLOCK)||(SysInfo.SCCardNoType == SC_CT_INFO_BLOCK) )
							cardno = CurrentCard.CardNo;

#ifdef BIO_METRIC
	                  	if( SysInfo.IdentifyMode == BIO_POLL_TYPE_SMART_TEMPLATE)
	                   	{
	                     	if(SysInfo.CardDataSource & CDATA_SOURCE_TEMPLATE )
	                      	{
	                        	if(CurrentCard.NoOfTemp !=0)
	                           	NextDisplayMode = USER_VERIFY_BY_HOST_MODE;
	                         	else
	                           	NextDisplayMode =0;
	                      	}
	                      	else
	                      	{
	                        	NextDisplayMode =0;
	                        	L_DisplayROMStr("ERR::TmpltNotSet",16,ROW_USER_ENTRY);
	                         	goto G_DelayedHaltcommand;
	                      	}
	                   	}
	                   	else
#endif
						NextDisplayMode =0;
#endif
					}
                	else
					{
#ifdef BIO_SMART_TEMPLATE
                  		status = ReadSmartCardLayout();
                     	if(status !=0)
                     		break;
	                 	if((SysInfo.SCCardNoType == SC_CT_TEMPLATE_BLOCK)||(SysInfo.SCCardNoType == SC_CT_INFO_BLOCK) )
	                     	cardno = CurrentCard.CardNo;
                      	else
							CurrentCard.CardNo=cardno;
#endif
                  	}
#ifdef BIO_SMART_TEMPLATE
                 	memset(UserName,' ', sizeof(UserName));
					if((SysInfo.NameType==NAME_AS_ZICOM_EMP_NO)||(SysInfo.CardDataSource & CDATA_SOURCE_NAME ))
                 		memcpy(UserName,CurrentCard.Name, sizeof(UserName));
#else
	               MsgPrint(1,(unsigned int)ReceivedCardNo,"Card Received From SmartCard =");
	               // Now Read Employee name from smartcard which is at block 2
                 // ENABLE_SMART_CARD();
//                  Delay(1000);
                  	t_data = AuthReadSmartCardBlock(SMART_EMP_NAME_BLOCK,NULL,&UserName[0]);
                  	if(t_data !=0)
                  	{
                  		Delay(3000);
                  		t_data = AuthReadSmartCardBlock(SMART_EMP_NAME_BLOCK,NULL,&UserName[0]);
                  	}
#endif
#ifdef	CARD_NO_8_DIGIT
#ifndef	CARD_NO_10_DIGIT
					ReceivedCardNo = cardno & 0x00FFFFFF;
#endif
#else
					ReceivedCardNo = cardno & 0x0000FFFF;
#endif
					if( Doorinfo.CardMask ==16)
					     ReceivedCardNo = cardno & 0x0000FFFF;
					else
						ReceivedCardNo = cardno;
					ReaderData[0].FacCode = (unsigned char)(cardno / 0x1000000);
					ReaderData[1].FacCode = ReaderData[0].FacCode;
					CurrentUser.FCode = ReaderData[0].FacCode;
					CurrentUser.InputType = INPUT_USER_FROM_SMART;						
					if(readerno == 1)
						ReaderData[0].F_CardFound = SET;
					else
						ReaderData[1].F_CardFound = SET;
					if(DisplayMode == MODE_WAIT_FOR_CARD)
					{
	                  	IdleKeyCounter = MAX_KEY_IDLE_TIME -5;
	               		F_KeyIdleTime = CLR;
					}
                  	if(DisplayMode != MODE_WRITE_TEMPLATE_TO_CARD)
		               SendHaltToSmartCard();
					SendDelayedPollCommandToSmartCard();
                  	return;
	            }
	            else
	               MsgPrint(MSG_SMART_CARD,readerno,"Error Mode P not received ");
	         }
	         else
	            MsgPrint(MSG_SMART_CARD,readerno,"Error Mode");
	      }
	      else
	         MsgPrint(MSG_SMART_CARD,readerno,"Error Mode Smart Card x Received");

   	break;
	default:
			MsgPrint(MSG_SMART_CARD,DisplayMode,"SmartCarareceived sendPoll M=");
         SendDelayedPollCommandToSmartCard();
			break;
	}
G_DelayedHaltcommand:
  	SendDelayedPollCommandToSmartCard();

}



extern unsigned char AdminLogOutTimer;

/*** BeginHeader SendWriteCurrentDataToSCR*/
unsigned char SendWriteCurrentDataToSCR(unsigned int len, unsigned char *blockno, unsigned char *senddata);
/*** EndHeader */
unsigned char SendWriteCurrentDataToSCR(unsigned int len, unsigned char *blockno, unsigned char *senddata)
{
unsigned char icnt;
unsigned char tblocks, status;
unsigned char count=0;

tblocks = len/16;		//to find no of blocks required

#ifdef ENABLE_WATCHDOG
	WDTHandleType = WDT_NEW_ADD_SERIAL_CARD;
#endif
	for(icnt=0;icnt<tblocks;icnt++)
	{
#ifdef ENABLE_WATCHDOG
				WDTFeed();		//Clear watchdog timer
#endif
	   if(AdminLogOutTimer >= (MAX_ADMIN_TIME_OUT-5))
	      AdminLogOutTimer = 0;
	   count = 0;
	   while(count<=10)
	   {
	      count++;
	      if((count%3) == 0)
	      {
			#ifdef ENABLE_WATCHDOG
							WDTFeed();		//Clear watchdog timer
			#endif
		  }
	     	Delay(1000);
	      	status = AuthWriteSmartCardBlock(blockno[icnt],16,&senddata[icnt*0x0f]);      // authenticate and write smart card block,datalength 16
	      	if(status == 0)
	         	break;
	   }
	   if(count == 10)
	      return(0xFF);
	}
	return(0);
}

/*** BeginHeader WritePersonalInfoToSCR*/
char WritePersonalInfoToSCR(struct SMART_CARD_DATA *ccard);
/*** EndHeader */
char WritePersonalInfoToSCR(struct SMART_CARD_DATA *ccard)
{
/* Writing
	1)Personal Information Block
   2)Personal Name Block
   3)Tempelate Information Block
   */
//unsigned char status,temp_start_block;
//unsigned char block;
//unsigned char tempbuf[17];

	TempSCBuffer[0]	= (unsigned char)(ccard->CardNo / 0x1000000L);
	TempSCBuffer[1]	= (unsigned char)(ccard->CardNo / 0x10000L);
	TempSCBuffer[2]	= (unsigned char)(ccard->CardNo / 0x100L);
	TempSCBuffer[3]	= (unsigned char)(ccard->CardNo & 0x000000FF);
   TempSCBuffer[4]	= (unsigned char)(ccard->Pin / 0x100);
	TempSCBuffer[5]	= (unsigned char)(ccard->Pin & 0xFF);
   TempSCBuffer[6]	= ccard->VDate.tm_mday;
	TempSCBuffer[7]	= ccard->VDate.tm_mon;
	TempSCBuffer[8]	= ccard->VDate.tm_year - 100;
	TempSCBuffer[9]	= ccard->VDate.tm_hour;
	TempSCBuffer[10]	= ccard->VDate.tm_min;
	TempSCBuffer[11]	= (unsigned char)(ccard->CardNo / 0x1000000L);
	TempSCBuffer[12]	= (unsigned char)(ccard->CardNo / 0x10000L);
	TempSCBuffer[13]	= (unsigned char)(ccard->CardNo / 0x100L);
	TempSCBuffer[14]	= (unsigned char)(ccard->CardNo & 0x000000FF);
	TempSCBuffer[15]	= UTYPE_FINGER_SMARTCARD; // 0x20;			//ccard->CType;     //templete on card(Smart Card & Biometric)
   memcpy(&TempSCBuffer[16],ccard->Name,16);
   // Temperary disable for testing mandar of tempelate menu addition
   /*
   TempSCBuffer[32]	= TempSCBuffer[0];   	// CNo. is again stored in Tempelate Block
	TempSCBuffer[33]	= TempSCBuffer[1];
	TempSCBuffer[34]	= TempSCBuffer[2];
	TempSCBuffer[35]	= TempSCBuffer[3];
   TempSCBuffer[36]	= ccard->Template / 0x100;
   TempSCBuffer[37]	= ccard->Template & 0xFF;
	TempSCBuffer[38]	= ccard->NoOfTemp;
   // Temp starting block remain
   temp_start_block =  (SysInfo.SCInfoBlock + MAX_SC_BLOCKS_FOR_CARDINFO);
   if(((((temp_start_block+1)%4)==0)&&(temp_start_block<=127))||((((temp_start_block+1)%16)==0)&&(temp_start_block>=128)))
   	temp_start_block++;
   TempSCBuffer[39] = temp_start_block;

   temp_start_block = temp_start_block + MAX_SC_BLOCKS_FOR_TEMPLATE ;
   if(((((temp_start_block+1)%4)==0)&&(temp_start_block<=127))||((((temp_start_block+1)%16)==0)&&(temp_start_block>=128)))
   	temp_start_block++;
   TempSCBuffer[40] = temp_start_block;

   if(TempSCBuffer[38]==4) // if no of tempelates are 4
   {
     temp_start_block = temp_start_block + MAX_SC_BLOCKS_FOR_TEMPLATE ;
   	if(((((temp_start_block+1)%4)==0)&&(temp_start_block<=127))||((((temp_start_block+1)%16)==0)&&(temp_start_block>=128)))
   		temp_start_block++;
   	TempSCBuffer[41] = temp_start_block;

      temp_start_block = temp_start_block + MAX_SC_BLOCKS_FOR_TEMPLATE ;
   	if(((((temp_start_block+1)%4)==0)&&(temp_start_block<=127))||((((temp_start_block+1)%16)==0)&&(temp_start_block>=128)))
   		temp_start_block++;
   	TempSCBuffer[42] = temp_start_block;
   } */

   if(AuthWriteSmartCardBlock(SysInfo.SCInfoBlock[0],SMART_CARD_BLOCK_LENGTH,&TempSCBuffer[0]) == STATUS_SMART_CARD_WRITE_ERROR)
		return(STATUS_SMART_CARD_WRITE_ERROR);
  if(AuthWriteSmartCardBlock(SysInfo.SCNameBlock[0],SMART_CARD_BLOCK_LENGTH,&TempSCBuffer[0+SMART_CARD_BLOCK_LENGTH]) == STATUS_SMART_CARD_WRITE_ERROR)
		return(STATUS_SMART_CARD_WRITE_ERROR);
//   if(AuthWriteSmartCardBlock(SysInfo.SCTemplateBlock[0],SMART_CARD_BLOCK_LENGTH,&TempSCBuffer[2 * SMART_CARD_BLOCK_LENGTH]) == STATUS_SMART_CARD_WRITE_ERROR)
//		return(STATUS_SMART_CARD_WRITE_ERROR);
   return(0);
}

/*** BeginHeader WriteSmartCardTempelate*/
unsigned char WriteSmartCardTempelate(unsigned char blockno,unsigned int tempsize,unsigned char *tempdata);
/*** EndHeader */
unsigned char WriteSmartCardTempelate(unsigned char blockno,unsigned int tempsize,unsigned char *tempdata)
{
/* Writing Tempelate on Smart Card*/
  unsigned char blocks,count,status,i;
//  unsigned char cardtype;
 /* Always assume card is 1K
  cardtype = RequestSmartCard();		//return smart card type 1K / 4K
  switch(cardtype)
  {
  	case 0x02: 	break;
   case 0x04:  if(TempSCBuffer[38]==4)
               return(STATUS_SMART_CARD_WRITE_ERROR);
               break;
   default :	return(STATUS_SMART_CARD_WRITE_ERROR);
  }
*/
  /*if((cardtype == 4) && (TempSCBuffer[38]==4))
  {
    return(STATUS_SMART_CARD_WRITE_ERROR);
  } */

  blocks = tempsize/16;			// total blocks used to store tempelate
  count =blockno;					//init block no
  //status = AuthSmartCard(SysInfo.SCKeyType[0],SysInfo.SCKeySector[0],blockno);

  for(i=0;i<blocks;i++)
  {
    if(((((count+1)%4)==0)&&(count<=127))||((((count+1)%16)==0)&&(count>=128)))  // Pankaj modified to support 4K card layout if((((count+1)%4)==0) &&(count<=127) ))
      {
      	// indicates this is sector trailer
			count++;
      }
      status = AuthWriteSmartCardBlock(count,SMART_CARD_BLOCK_LENGTH,&tempdata[i*SMART_CARD_BLOCK_LENGTH]);
      if(status !=0)
      	return(status);
		count++;
  }
  return(0);
}

/*** BeginHeader WriteTempelateInfoToSerialSCR*/
char WriteTempelateInfoToSerialSCR(struct SMART_CARD_DATA *ccard);
/*** EndHeader */
char WriteTempelateInfoToSerialSCR(struct SMART_CARD_DATA *ccard)
{
	unsigned char  temp_start_block;

  	TempSCBuffer[32]	= (unsigned char)(ccard->CardNo / 0x1000000L);
	TempSCBuffer[33]	= (unsigned char)(ccard->CardNo / 0x10000L);
	TempSCBuffer[34]	= (unsigned char)(ccard->CardNo / 0x100L);
	TempSCBuffer[35]	= (unsigned char)(ccard->CardNo & 0x000000FF);
   TempSCBuffer[36]	= ccard->Template / 0x100;
   TempSCBuffer[37]	= ccard->Template & 0xFF;
	TempSCBuffer[38]	= ccard->NoOfTemp;
	temp_start_block =  (SysInfo.SCInfoBlock[0] + MAX_SC_BLOCKS_FOR_CARDINFO);
   if(((((temp_start_block+1)%4)==0)&&(temp_start_block<=127))||((((temp_start_block+1)%16)==0)&&(temp_start_block>=128)))
   	temp_start_block++;
	ccard->TempPos[0] = temp_start_block;
   TempSCBuffer[39]  = ccard->TempPos[0];

	temp_start_block = temp_start_block + 32;		//actual 24 block are required but because of sector trailer we need some extra blocks..
	if(((((temp_start_block+1)%4)==0)&&(temp_start_block<=127))||((((temp_start_block+1)%16)==0)&&(temp_start_block>=128)))
   	temp_start_block++;
	ccard->TempPos[1] = temp_start_block ;
   TempSCBuffer[40] = ccard->TempPos[1];
   TempSCBuffer[41] = 0;
   TempSCBuffer[42] = 0;
   ccard->TempPos[2]=0;
   ccard->TempPos[3]=0;
   if(AuthWriteSmartCardBlock(SysInfo.SCTemplateBlock[0],SMART_CARD_BLOCK_LENGTH,&TempSCBuffer[2 * SMART_CARD_BLOCK_LENGTH]) == STATUS_SMART_CARD_WRITE_ERROR)
		return(STATUS_SMART_CARD_WRITE_ERROR);
   return(0);
}

#endif

#endif

