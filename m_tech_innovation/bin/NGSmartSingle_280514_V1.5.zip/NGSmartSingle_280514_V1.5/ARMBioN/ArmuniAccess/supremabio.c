#include <string.h>
#include "LPC23xx.h"			/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include "type.h"
#include "irq.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
//#include "timer.h"
#include "spi.h"
#include "serial.h"
#include "access.h"
#include "uart.h"
#include "portlcd.h"
#include "tranxmgmt.h"
#include "userintf.h"
#include "Supremabio.h"


#ifdef BIO_METRIC
/*---------------------------------------------------------------------------------------*/
/*** BeginHeader EnrollNewFingerID */
BYTE EnrollNewFingerID(CARDNO_DATA_STORAGE_TYPE fingerid,BYTE addtype);
/*** EndHeader */
BYTE EnrollNewFingerID(CARDNO_DATA_STORAGE_TYPE fingerid,BYTE addtype)
{
/*
add type
= 0		Always add new user with finger

= 0x71	this is to add  user with given id if same ID is not present and
			 if ID is present it will add finger new finger at same ID location.
= 0x74	continue ..
= 0x70	Check if provided ID is present .. no enrollment
*/
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(CMD_ENROLL_FINGER_SCAN);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(addtype);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	BioCommand = CMD_ENROLL_FINGER_SCAN;
	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader IdentifyFinger */
BYTE IdentifyFinger(void);
/*** EndHeader */
BYTE IdentifyFinger(void)
{
BYTE sensorfail;

	sensorfail = BioSensorFail;   // as clear finger will reset sensor fail...
	ClearBioSerBuffer();
	BioSensorFail = sensorfail;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(CMD_IDENTIFY_FINGER);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	BioCommand = CMD_IDENTIFY_FINGER;
	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader VerifyFinger */
BYTE VerifyFinger(CARDNO_DATA_STORAGE_TYPE fingerid);
/*** EndHeader */
BYTE VerifyFinger(CARDNO_DATA_STORAGE_TYPE fingerid)
{
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_USER_ID_SCAN;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);

	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader DeleteBioUserID */
BYTE DeleteBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid);
/*** EndHeader */
BYTE DeleteBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_USER_ID;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
 		return(status);
}

/*-------------------------------------------------------------------------------------------------------------*/
// This cimmand is for delete template for user or same can also be used for delete multiple templete for userIDs which start from idstart to idend
// del type will decide what to delete
// DELETE_ONLY_ONE(0x70)*
// DELETE_MULTIPLE_ID(0x71)*
/*** BeginHeader DeleteBioFingerID */
BYTE DeleteBioFingerID(CARDNO_DATA_STORAGE_TYPE idstart,CARDNO_DATA_STORAGE_TYPE idend,BYTE deltype);
/*** EndHeader */
BYTE DeleteBioFingerID(CARDNO_DATA_STORAGE_TYPE idstart,CARDNO_DATA_STORAGE_TYPE idend,BYTE deltype)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_USER_ID;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(idstart & 0x00ff));
	TransmitCharBio((BYTE)((idstart & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((idstart & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((idstart & 0xFF000000) / 0x1000000));

	TransmitCharBio((BYTE)(idend & 0x00ff));
	TransmitCharBio((BYTE)((idend & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((idend & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((idend & 0xFF000000) / 0x1000000));

	TransmitCharBio(deltype);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
 		return(status);
}

/*--------------------------------------------------------------------------------------*/
// This will delete all user IDs from Biometric Reader
/*** BeginHeader DeleteAllBioUserID */
BYTE DeleteAllBioUserID(void);
/*** EndHeader */
BYTE DeleteAllBioUserID(void)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_ALL_USER_ID;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(status);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader CheckBioUserID */
BYTE CheckBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid);
/*** EndHeader */
BYTE CheckBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_CHECK_USER_ID;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
 	if(status == STATUS_BIO_EXIST_ID)
		return(0);
	else
		return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
// THIS COMMAND IS NOT FULLY IMPLEMENTED AS WE GET LIST ALL USER IDS WHICH IS DIFFICULT TO MANAGE
/*** BeginHeader ListBioUserID */
BYTE ListBioUserID(void);
/*** EndHeader */
BYTE ListBioUserID(void)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_LIST_USER_ID;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(status);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader WaitBioResponse */
BYTE WaitBioResponse(void);
/*** EndHeader */
BYTE WaitBioResponse(void)
{
	while(1)
	{
		if(F_SerialCommandBio == SET)
		{
			F_SerialCommandBio = CLR;
//			if(F_BIO_COMM == SET)
			{
				ProcessBioSerialResponse();
				break;
			}
		}

		if(FingerWaitTimeOut >= MAX_BIO_TIME_OUT)
		{
			BioCmdStatus = STATUS_BIO_TIME_OUT;
			break;
		}
	}
	return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader TimeWaitBioResponse */
BYTE TimeWaitBioResponse(WORD time);
/*** EndHeader */
BYTE TimeWaitBioResponse(WORD time)
{
	while(1)
	{
		if(F_SerialCommandBio == SET)
		{
			F_SerialCommandBio  = CLR;
//			if(F_BIO_COMM == SET)
			{
				ProcessBioSerialResponse();
				break;
			}
		}

		if(FingerWaitTimeOut >= time)
		{
			BioCmdStatus = STATUS_BIO_TIME_OUT;
			break;
		}
	}
	return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ProcessBioSerialResponse */
void ProcessBioSerialResponse(void);
/*** EndHeader */
void ProcessBioSerialResponse(void)
{
	if(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION] == BioCommand)
	{
		PortObj[SER_BIO_PORT].RxPtr = 0;
		BioCmdStatus = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+9];
		BioCmdData = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+1] + 			\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+2]*0x100 +		\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+3]*0x10000 +	\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+4]*0x1000000;
		BioCmdSize = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+5] + 			\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+6]*0x100 +		\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+7]*0x10000 + 	\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+8]*0x1000000;
	}
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader WriteSystemParameter */
BYTE WriteSystemParameter(BYTE paraid,WORD value);
/*** EndHeader */
BYTE WriteSystemParameter(BYTE paraid,WORD value)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET ;
	Biochecksum = 0;
	BioCommand = CMD_WRITE_SYS_PARA;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(value&0xFF);
	TransmitCharBio((value/0x100)&0xFF);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(paraid);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ReadBioSystemParameter */
BYTE ReadBioSystemParameter(BYTE para);
/*** EndHeader */
BYTE ReadBioSystemParameter(BYTE para)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_READ_SYS_PARA;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(para);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader CancelBioCommand */
BYTE CancelBioCommand(void);
/*** EndHeader */
BYTE CancelBioCommand(void)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_CANCEL;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
	{
//      printf("CancelBioCommand Success 1 %x \n",status);
		PortObj[SER_BIO_PORT].RxPtr =0;
		FingerWaitTimeOut = 0;
		status = WaitBioResponse();
		Delay(2000);
		return(0);
	}
	else
	{
//      printf("CancelBioCommand 1 %x \n",status);
		PortObj[SER_BIO_PORT].RxPtr = 0;
		FingerWaitTimeOut = 0;
		status = WaitBioResponse();
		Delay(2000);
//      printf("CancelBioCommand 2 %x \n",status);
		return(BioCmdStatus);
	}
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader SaveBioSystemParameter */
BYTE SaveBioSystemParameter(void);
/*** EndHeader */
BYTE SaveBioSystemParameter(void)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_SAVE_SYS_PARA;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

//===========================================
 /*** BeginHeader ReadDownloadTemplate */
BYTE ReadDownloadTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf);
/*** EndHeader */
BYTE ReadDownloadTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf)
{
//BYTE temp1;
//WORD ptrdata;
WORD tempsize;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_READ_BIO_TEMPLATE;
	F_Template_Download = SET;
	F_CriticalSection = SET;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio((BYTE)(userID & 0x00ff));
	TransmitCharBio((BYTE)((userID & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((userID & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((userID & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);

	FingerWaitTimeOut = 0;
//	temp1 = WaitBioResponse();
	F_Template_Download = CLR;
	FingerWaitTimeOut = 0;
	tempsize = 500;

	if(BioCmdStatus == STATUS_BIO_TIME_OUT)
		return(BioCmdStatus);
	ProcessBioSerialResponse();
	tempsize = (WORD)BioCmdSize;
//	F_CriticalSection = CLR;
	
	if(BioCmdStatus != STATUS_BIO_SUCCESS)
		return(BioCmdStatus);

	memcpy(tempbuf,&PortObj[SER_BIO_PORT].RxBuffer[(15*fingno)+((fingno-1)*(tempsize+1))],tempsize);
	FingerWaitTimeOut = 0;
//	ptrdata = 0;
//PRINTF_REMOVE   printf(" BioCmdData = %d BioCmdSize =%d \n",BioCmdData,BioCmdSize);
	PortObj[SER_BIO_PORT].RxPtr = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ReadSingleTemplate */
BYTE ReadSingleTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf);
/*** EndHeader */
BYTE ReadSingleTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf)
{
//BYTE temp1;
WORD /*ptrdata,*/tempsize;
DWORD datasize;
	ClearBioSerBuffer();
	memset(PortObj[SER_BIO_PORT].RxBuffer,0,PortObj[SER_BIO_PORT].MAXINBUF);
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_EX_READ_BIO_TEMPLATE;
	F_Template_Download = SET;
	F_CriticalSection = SET;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio((BYTE)(userID & 0x00ff));
	TransmitCharBio((BYTE)((userID & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((userID & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((userID & 0xFF000000) / 0x1000000));

//	datasize = (long)((fingno-1) *0x10000) + MAX_BIO_TEMPLATE_SIZE;
	datasize = (long)((fingno-1) *0x10000) + SensorTemplateSize;

	TransmitCharBio((BYTE)(datasize & 0x00ff));
	TransmitCharBio((BYTE)((datasize & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((datasize & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((datasize & 0xFF000000) / 0x1000000));

	TransmitCharBio(1);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);

	FingerWaitTimeOut = 0;
	/*temp1 = */WaitBioResponse();
	F_Template_Download = CLR;
	FingerWaitTimeOut = 0;
	tempsize = 500;

	if(BioCmdStatus == STATUS_BIO_TIME_OUT)
		return(BioCmdStatus);
	ProcessBioSerialResponse();
	tempsize = (WORD)BioCmdSize;
//	F_CriticalSection = CLR;
	
	if(BioCmdStatus != STATUS_BIO_SUCCESS)
		return(BioCmdStatus);
	memcpy(tempbuf,(BYTE *)&PortObj[SER_BIO_PORT].RxBuffer[15+15],tempsize);
	FingerWaitTimeOut = 0;

   // Send data received OK command to complete the protocol
	F_BioCheckSum = SET;
	Biochecksum = 0;
//==========================================

	BioCommand = CMD_EX_READ_BIO_TEMPLATE;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	
	TransmitCharBio(0x83);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);

	return(0);
}

/*** BeginHeader EnrollByBioTemplate */
BYTE EnrollByBioTemplate(CARDNO_DATA_STORAGE_TYPE fingerid,WORD templatesize,BYTE * tempbuf);
/*** EndHeader */
BYTE EnrollByBioTemplate(CARDNO_DATA_STORAGE_TYPE fingerid,WORD templatesize,BYTE * tempbuf)
{
WORD temp1;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_ENROLL_BIO_TEMPLATE;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

	TransmitCharBio(templatesize & 0x00ff);
	TransmitCharBio(templatesize / 0x100);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0x71);

	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
/*	
	temp1 = WaitBioResponse();
	printf("EnrollByBioTemplate:WaitBioResponse=%x\n",temp1);
*/
	temp1 = 0;
	while(temp1 < templatesize)
	{
		TransmitCharBio(tempbuf[temp1]);
//		SendAsciiToPC(tempbuf[temp1]);
//		Delay(10);
		temp1++;
	}
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	temp1 = WaitBioResponse();
	MsgPrint(1,temp1,"EnrollByBioTemplate= ");
	if(temp1 == STATUS_BIO_FINGER_FOUND)
	{
   	// This indicates one more command is pending to come from module which is STATUS_SUCCESSFUL so read same now
		FingerWaitTimeOut = 0;
		PortObj[SER_BIO_PORT].RxPtr = 0;
		temp1 = WaitBioResponse();
	}
	return(temp1);
}

/*** BeginHeader ClearBioSerBuffer */
void ClearBioSerBuffer(void);
/*** EndHeader */
void ClearBioSerBuffer(void)
{
	PortObj[SER_BIO_PORT].RxPtr = 0;
	memset(PortObj[SER_BIO_PORT].RxBuffer,0,PortObj[SER_BIO_PORT].MAXINBUF);
   	FingerWaitTimeOut = 0;
}

/*** BeginHeader VerifyBioTemplateFromHost */
BYTE VerifyBioTemplateFromHost(WORD templatesize,BYTE nooftemp,char (*template)[MAX_BIO_TEMPLATE_SIZE]);
/*** EndHeader */
BYTE VerifyBioTemplateFromHost(WORD templatesize,BYTE nooftemp,char (*template)[MAX_BIO_TEMPLATE_SIZE])
{
WORD temp1;
char i;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(nooftemp);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(templatesize & 0x00ff);
	TransmitCharBio(templatesize / 0x100);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	for(i=0;i<nooftemp;i++)
	{
		temp1 = 0;
		while(temp1 < templatesize)
		{
			TransmitCharBio(template[i][temp1]);
			temp1++;
		}
		TransmitCharBio(0x0A);
	}

	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ResetSensorModule */
BYTE ResetSensorModule(void);
/*** EndHeader */
BYTE ResetSensorModule(void)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_RESET_MODULE;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

#ifdef DISABLE_TEMPLATE			// Functions not in use
/*--------------------------------------------------------------------------------------*/
BYTE VerifyBioTemplate(WORD fingerid,WORD templatesize)
{																	 
WORD temp1;
	Serial2ReceiveCount = 0;
	F_Serial2CheckSum = 1;
	Serial2CheckSum = 0;
	BioCommand = CMD_VERIFY_BIO_TEMPLATE;					   
	TransmitChar2(0x41);
	TransmitChar2(0x01);
	TransmitChar2(0x0);
	TransmitChar2(BioCommand);

	TransmitChar2(fingerid & 0x00ff);
	TransmitChar2(fingerid / 0x100);
	TransmitChar2(0);
	TransmitChar2(0);

	TransmitChar2(templatesize & 0x00ff);
	TransmitChar2(templatesize / 0x100);
	TransmitChar2(0);
	TransmitChar2(0);

	TransmitChar2(0);
	TransmitChar2(Serial2CheckSum);
	TransmitChar2(0x0A);

	temp1 = 0;
	while(temp1 < BIO_TEMPLATE_SIZE)
	{
		TransmitChar2(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
		SendAsciiToSerial(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
		temp1++;
	}
	TransmitChar2(0x0A);

	FingerWaitTimeOut = 0;
	temp1 = WaitBioResponse();
	if(temp1 == STATUS_BIO_FINGER_FOUND)
	{
		Serial2ReceiveCount = 0;
		F_SerialPort2CommandProxy = CLR;
		temp1 = WaitBioResponse();
	}
	MsgPrint(1,temp1,"VerifyBioTemplate=");
	return(temp1);
}

/*--------------------------------------------------------------------------------------*/
BYTE IdenifyByBioTemplate(WORD templatesize)
{
WORD temp1;
	Serial2ReceiveCount = 0;
	F_Serial2CheckSum = 1;
	Serial2CheckSum = 0;
	BioCommand = CMD_IDENTIFY_BY_BIO_TEMPLATE;
	TransmitChar2(0x41);
	TransmitChar2(0x01);
	TransmitChar2(0x0);
	TransmitChar2(BioCommand);

	TransmitChar2(0);
	TransmitChar2(0);
	TransmitChar2(0);
	TransmitChar2(0);

	TransmitChar2(templatesize & 0x00ff);
	TransmitChar2(templatesize / 0x100);
	TransmitChar2(0);
	TransmitChar2(0);

	TransmitChar2(0);
	TransmitChar2(Serial2CheckSum);
	TransmitChar2(0x0A);

	temp1 = 0;
	while(temp1 < BIO_TEMPLATE_SIZE)
	{
		TransmitChar2(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
		SendAsciiToSerial(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
		temp1++;
	}
	TransmitChar2(0x0A);
	FingerWaitTimeOut = 0;
	temp1 = WaitBioResponse();
	MsgPrint(1,temp1,"IdentifyByBioTemplate=");
	MsgPrint(MSG_WARNING,BioCmdData,"BioCmdData=");
	return(temp1);
}

/*--------------------------------------------------------------------------------------*/
BYTE VerifyBioTemplateFromHost(WORD templatesize)
{
WORD temp1;
	Serial2ReceiveCount = 0;
	F_Serial2CheckSum = SET;
	Serial2CheckSum = 0;
	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
	TransmitChar2(0x41);
	TransmitChar2(0x01);
	TransmitChar2(0x0);
	TransmitChar2(BioCommand);

	TransmitChar2(0);
	TransmitChar2(0);
	TransmitChar2(0);
	TransmitChar2(0);

	TransmitChar2(templatesize & 0x00ff);
	TransmitChar2(templatesize / 0x100);
	TransmitChar2(0);
	TransmitChar2(0);
	TransmitChar2(0);
	TransmitChar2(Serial2CheckSum);
	TransmitChar2(0x0A);

	temp1 = 0;
	while(temp1 < BIO_TEMPLATE_SIZE)
	{
		TransmitChar2(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
		SendAsciiToSerial(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
		temp1++;
	}
	TransmitChar2(0x0A);

	FingerWaitTimeOut = 0;
	temp1 = WaitBioResponse();
	if(temp1 == STATUS_BIO_FINGER_FOUND)
	{
		Serial2ReceiveCount = 0;
		F_SerialPort2CommandProxy = CLR;
		temp1 = WaitBioResponse();
	}
	MsgPrint(1,temp1,"VerifyBioTemplateFromHost=");
	return(temp1);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader TransmitCharBio1 */
void TransmitCharBio1(BYTE t_data);
/*** EndHeader */
void TransmitCharBio1(BYTE t_data)
{
BYTE a;
	if(F_BioCheckSum)
#ifdef ENABLE_BIOMETRIC
		Biochecksum = Biochecksum + t_data;
#else
		Biochecksum = Biochecksum ^ t_data;
#endif
	a = 0;
	while(1)
	{
		if(serCputc(t_data) == 1)
			break;
		a++;
		Delay(100);
		if(a > 20)
			break;
	}
//	if(DeabugLevel)
//		printf("%x",t_data);
}

#endif // DISABLE_TEMPLATE
//===============================================

#endif
