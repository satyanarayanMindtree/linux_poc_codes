
#ifndef __ICLASSRDR_H 
#define __ICLASSRDR_H

#define SUPPORT_RETRIVEVE_DATA       //Read 4 blocks from reader memory 
#define PORT_ICLASSRDR 			SER_SMART_RD1_PORT 		  


#define ICR_POLL_DELAY_TIME		10
#define ICR_WAIT_DELAY				5

#define ICR_ERROR_CODE					0xFF
#define ICR_CARDNO_ERROR_CODE		0xFE
#define ICR_ERROR_CARDINFO_BL		0xFD
//#define ERR_SC_LAYOUT_ERROR   	0xFC
//#define ERR_SC_NO_TEMPLATE      0xFB


//I-Class reader instruction set
#define SEL_CURRKEY_DIVKEY		0x52
#define SELECT_CARD				0xA4
#define PAGE_SELECT_16K			0xA6
#define TRANSMIT 				0xC2
#define CONTROL_LED_BUZZER		0x70
#define CONTROL_OUTPUT			0x71
#define LOAD_KEYS				0xD8
#define ASK_RANDOM_NO			0x84
#define RETRIVE_DATA			0xC0
#define READ_EEPROM				0xF2
#define WR_EEPROM_RST_RF		0xF4

//Authentication Key type
#define NO_AUTH			0x00
#define USE_KEY1_AUTH	0x30		//will be used for app area 1
#define USE_KEY2_AUTH	0x10		//will be used for app area 2


//P1 data for Read/Write Commands
#define P1_RD_4BLOCKS 	0xF1			//Read 4 blocks in 15693 Mode
#define P1_RD_1BLOCK		0xF5        //Read 1 block in 15693 Mode
#define P1_WR_1BLOCK		0x69        //Write 1 block in 15693 Mode

//P2 data for Read/Write Commands
#define P2_RW_1BLOCK		0x08			//To read or write a single block
#define P2_RD_4BLOCKS	0x20			//To read 4 blocks

//Type for Read/Write Commands
#define TYPE_RD_4BLOCKS	0x06			//To read 4 blocks
#define TYPE_RD_1BLOCK	0x0C			//To read a single block
#define TYPE_WR_1BLOCK	0x87			//To write a single block



#define ICLASS_CMD_POSITION		0

// Serial Frame Stuff/destuff definitions
#define ICRDR_CLA				0x80

#define STATUS_ICR_TIME_OUT		0xFF 

#define  MAX_ICR_SER_BUFF		1024 


#define SER_ICRDR1_RDUSED()		serDrdUsed()
#define SER_ICRDR1_GETC()		serDgetc()
#define SER_ICRDR1_BAUDRATE()	serDopen(57600)
#define SER_ICRDR1_PARITY()		serDparity(PARAM_EPARITY)

//Iclass Card types
#define SUPPORT_16K_2CARD			0
#define SUPPORT_16K_16CARD		1

extern BYTE IdleKeyCounter,F_KeyIdleTime;
extern volatile unsigned char ICR1_PollTime,ICRTimeOut;		//,ICR1_F_Poll; 
extern unsigned char CurrentICRStatus,ICRERRORCode, RDRChkCount,gReccount; 
//int SerialICRReceiveCount; 
extern char F_SerialICRProxy;//,ICRSerBuffer[MAX_ICR_SER_BUFF];
 
extern unsigned char SendCommand;
//extern unsigned char RecRandomNo[8];

extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;
extern BYTE ReaderNo;
extern unsigned char WDTHandleType;






extern unsigned char SendGetRandomNoFromIClassRDR(void);
extern char WaitICRResponse(WORD timeout,BYTE scrdnumber, unsigned char reccount);
extern unsigned char SendReadCurrentDataToICR(unsigned int len, unsigned char *blockno, unsigned char *recdata);
extern char SendKeyToIClassReader(unsigned char keytype,unsigned char sector,unsigned char *ibuffer);

//extern char WaitICRResponse(unsigned int timeout, unsigned char scrdnumber, unsigned char reccount);

#endif /* end __ICLASSRDR_H */


