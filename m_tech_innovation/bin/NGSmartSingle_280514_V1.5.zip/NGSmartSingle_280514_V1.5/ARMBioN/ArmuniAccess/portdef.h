/*
This file is created to put portdef file. 
This file includes hardware specific file for hardware port definition.
*/

//#ifdef HW_ARM_8RD1_0
// This is for 4 Door 8 Reader board where reader is connected on serial

#ifdef HARDWARE_SI065
	#include "HW_armNGBiosmart1_0.h"
#else 
	#include "HW_armBiolite1_0.h"			  
// #else
// 	#include "HW_SmartSingle1_6.h"	   
#endif

//#else
//#include "rabit2DR.h"
//#endif

