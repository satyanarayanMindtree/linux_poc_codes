/*
//ARMF2004:
Following fie is created to manage Server based card checking.
Following functionality is implemented

1) Depending on configuration setting we take action to send command to PC/ Server to get decision
2) We send command to PC/Server using UDP Push method and this command has sequence number
3) we keep queue of sequence number so that we can track response of same
4) If we do not receive response for specific sequence number in XX time then we send this command to Other backup PC/ Server
5) If response is not received we remove this entry and just create transaction indicating no response.
6) If response is received we will process response and remove entry from queue.. action will generate normal transaction 
	which we generate in existing logic. 
7) Queue size will be of 4 size for 4 door system as we will assume 4 cards may come  one from each reader.
8) Card will not be processed by for that reader we have not received action from PC/Server untill time out occurs. 
*/

//=========================================================================================================================

#include "config.h"
#include "portdef.h"
#include "type.h"
#include "timer.h"
#include "target.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "webpage.h"                             // webside for our HTTP server (HTML)
#include "target.h"
#include "irq.h"
#include "fio.h"
#include "portlcd.h"
#include "spi.h"
#include "Access.h"
#include "serial.h"
#include "Smartcard.h"
#include "userIntf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "memory.h"
#include "Keypad.h"
#include "INOUT.h"
#include "Cardmgmt.h"
#include "memmap.h"
#include "rdcont.h"
#include "rdpoll.h"
#include "version.h"
#ifdef ENABLE_WATCHDOG
	#include "wdt.h"
#endif
#include "ProcessWeiCard.h"
#include "weigand.h"
#include"App.h"

#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "TcpPush.h"

#include "SplCardMgnt.h"
#include "IOEventMgmt.h"
#include "ServerCheck.h"
//SERVER_QUEUE SerQue[MAX_READERS];

//=========================================================================================================================

//=========================================================================================================================


//=========================================================================================================================

extern USOCKET MyUDP_Socket;
WORD ServSeqNumber;
//=========================================================================================================================
unsigned char SendUDPSeqNo(struct SERVER_QUEUE  *serqueue,unsigned char port,unsigned char servno)
{

 BYTE arrip[4];
	PortObj[port].BufPtr = 0;
	PortObj[port].F_ChkSum = SET;
	PortObj[port].ChkSum = 0;
	TransmitReplyStartToX(port);
	TransmitCharToX('S',port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(1,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(serqueue->SeqNo,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(serqueue->ChNo,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(serqueue->Event,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX(serqueue->CNo,port);
	TransmitCharToX(',',port);
	SendDecimalToX(serqueue->DT.Time.Hour,port);
	SendDecimalToX(serqueue->DT.Time.Min,port);
	SendDecimalToX(serqueue->DT.Time.Secs,port);
	TransmitCharToX(',',port);
	SendDecimalToX(serqueue->DT.Date.Day,port);
	SendDecimalToX(serqueue->DT.Date.Month,port);
	SendDecimalToX(serqueue->DT.Date.Year,port);
	TransmitCharToX(',',port);
	SendDecimalLongToX6digit(TotalNosOfTrans+1,port);		//??
	TransmitCharToX(',',port);          
	SendDecimalLongToX6digit(TransWritePtr,port);			//??
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(serqueue->CardType,port);
	TransmitCharToX(',',port);
	SendDecimalToPC3CharToX(serqueue->IpType,port);
	TransmitCharToX(',',port);
	SendDecimalIntToX(Doorinfo.ControllerNo,port);
	TransmitCharToX(',',port);
	TransmitCheckSumX(port);
	TransmitCharToX(',',port);
	TransmitCharToX(TERMINATOR,port);
	StrToArr((char*)&(SysInfo.SB_AUTH_ServAdd1[0]),arrip);	 					
	fnSendUDP(MyUDP_Socket,arrip, SysInfo.SB_AUTH_Port1, PortObj[port].Buffer, PortObj[port].BufPtr-sizeof(UDP_HEADER), 0);
	
	return(0);
}
//=========================================================================================================================
void InitServerPara(void)
{
	char i =0;
	ServSeqNumber=1;
	for(i=0;i<MAX_SERVER_QUEUE;i++)
	 	SerQue[i].SeqNo=0;
}
//=========================================================================================================================
char SendMessageToServer(struct USER_CARD_INFO *cardInfo,unsigned char chno,unsigned char event)
{

	if(SerQue[chno].SeqNo !=0)
		return(1);
	ServSeqNumber++;
	if(ServSeqNumber == 0)
		ServSeqNumber = 1;
	SerQue[chno].SeqNo = ServSeqNumber;
	SerQue[chno].CNo = cardInfo->SearchCard.CardNo;
	SerQue[chno].ChNo = chno+1;		//SHIVRAJ  Changed from SerQue[chno].ChNo = chno; 
	SerQue[chno].DT = Datetime;
	SerQue[chno].Event = event;	
	SerQue[chno].TimeOut = 0;
	SerQue[chno].CardType = cardInfo->SearchCard.Info.CType;
	SerQue[chno].IpType = cardInfo->InputType;
	SerQue[chno].SrchCardPtr = cardInfo->SearchCardPtr;
	SerQue[chno].APB = cardInfo->SearchCard.CardInfo.APB;	
	SendUDPSeqNo(&SerQue[chno],SER_UDP_PORT,1);
	return(0);
}
//=========================================================================================================================
char CheckServerQueueFree(char chno)
{
	if(SerQue[chno].SeqNo ==0)
		return(0);
	else
		return(1);	
}

//=========================================================================================================================
// This should be called every seconds
void ServCheckMainLoop(void)
{
unsigned char i;

	for(i=0;i<MAX_SERVER_QUEUE;i++)
	{ 	
		if(SerQue[i].SeqNo!=0)
		{
			SerQue[i].TimeOut++;
			if(SerQue[i].TimeOut >=MAX_SERVER_TIME_OUT)
			{
				// Need to add code so we switch to another server for communication.
				SerQue[i].SeqNo = 0;
				StoreCardInTrDBFull(SerQue[i].CNo,SerQue[i].ChNo,EVENT_SERVER_CHECK_TIMEOUT,1,1);											
#ifdef BIO_METRIC
				if((SysInfo.IdentifyMode == BIO_POLL_TYPE_AUTO_IDENTIFY) || (SysInfo.IdentifyMode == BIO_POLL_TYPE_FINGER_SENSE))
				{
			  		DISABLE_BIO_COMM();   	
					if(F_BIO_COMM == CLR)
						PollBioSensorTimeOut = MAX_FINGER_POLL_TIME_OUT - 1;	
				}
#endif																	
			}				
		}
	}
}
//=========================================================================================================================
// This function is used in protocol command to check if received sequence number matches with my seq no
// if yes then we success and remove message from queue.
int ServerChkResponseVerify(struct USER_CARD_INFO *servuser,WORD seqno,char chno)
{
	if(chno>MAX_READERS)
	{
		SerQue[chno].SeqNo = 0;		//timeout transaction will occur for this
		return(10);
	}
	if(SerQue[chno].SeqNo == 0)
	{
		return(11);					//timeout transaction will occur for this as it is wrong reader no error
	}
	if(SerQue[chno].SeqNo == seqno)
	{
		if(servuser->SearchCard.CardNo == SerQue[chno].CNo)
		{
			servuser->SearchCard.Info.CType	= SerQue[chno].CardType;
			servuser->InputType = SerQue[chno].IpType;
			servuser->SearchCardPtr	=SerQue[chno].SrchCardPtr;
			SerQue[chno].SeqNo =0;
			return(0);
		}
		else
		{
			SerQue[chno].SeqNo =0;
			return(12);			
		}
	}
	else 
	{
		SerQue[chno].SeqNo = 0;
		return(13);
	}
}
//=========================================================================================================================




