//Implementing Phase-I and Phase-II features.
//Enable following for auto card generation swipes
//#define TEST_SYSTEM
//Compiling for ARM-Biolite board.Comment this if to compile for Rabbit V1.6 based board.
//This is for hardware selection
//=========================================================================

// New hardware similar to SI032 with buildin Weigand but Regular Keypad

#define HARDWARE_SI065   //NG biosmart

//#define HARDWARE_SI049

// This is hardware with extra Key and weigand out. This is BioLite Series

//#define HARDWARE_SI032

// Old 1.6 hardware with Regular Keypad 
//#define HARDWARE_1_6
	
//#define BIO_METRIC	//enable this to support bio  //Disable for standalone/SmartSingle 

// Following is not used and will be used when we use Smart Card interface 
//#define SMART_CARD   //enble this to support 1.6 board 
//#define ENABLE_BANNER_GLOBAL_MSG
//#define INSERT_SDCARD
#define SUPPORT_TOUCHKEYPAD   
//#define SUPPORT_SPEECHIC
//enable this to support to	uch key pad from  Capasence, disable this to support touch key pad from kitronix 
//#define NEW_TOUCH_KEYPAD   //  this is for Capasence Keypad 
#define EXTENDED_USER 	 // for user more than 65536 & less than 100000

//#define INTRUSION_ENDIS

// #define ETHERNET_ENABLE     // for testing of Ethernet is working on board it is commneted
// #define TEST_SDCARD

#ifdef	SMART_CARD 
	#define	LPU_CARD_SUPPORT
#endif

//=================== ICLASS_RDR/CARD ============================================================
//#define SUPPORT_ICLASS_RDR          
//========================================================================

// Note : we have main two type of hardware ARM_BIOLITE_HW  and   ARM_BIOSMART_HW

#ifdef HARDWARE_SI049
	#define ARM_BIOLITE_HW	//enable this to support SI049
#endif

#ifdef HARDWARE_SI032
	#define ARM_BIOLITE_HW
	#define EXTENDED_KEYPAD			// This is used to provide extra Keys like in out etc..
	#define BIOLITE_HARDWARE		// ARMD0433 //To Disable finger sense
#endif

#ifdef HARDWARE_SI065
	#define ARM_BIOLITE_HW	//enable this to support SI049
#endif

#ifdef HARDWARE_1_6
#define ARM_BIOSMART_HW
#endif

#define ENABLE_TCP_PUSH 
//========================================================================
//Enables software watchdog in the code
 //#define ENABLE_WATCHDOG	  
//======================================================================== 
//#define ONE_LK_TXN_30K_CARDS //define this to use 30,000 cards and 100,000 transactions.
//#define TELNET_TEST

#define PROCESS_HEARTBEAT //enable this to use udp heart beat for dyna dns

#ifdef BIO_METRIC
	#define DISP_ENROLL_SCORE
	#ifdef	SMART_CARD	
		#define BIO_SMART_TEMPLATE			//This is required when we support smart Card Template
	#endif
	#ifndef HARDWARE_SI065
		#define ENABLE_LCD_BACKLITE
	#endif	
	//#define BIOLITE_LOW_END
	//#define BIOLITE_HIGH_END
	#define SUPPORT_SUPREMA
#endif

#ifdef ARM_BIOLITE_HW	//ARMD0356
	#define CHK_WEIGAND_PARITY			//Enables Weigand Parity checking in the code
	#define ENABLE_WEIGAND_FUNCTIONS
	#define WEIGAND_OUT_READER
#endif

#define ENABLE_UDP
#define MY_UDP_PORT            2001                                  // test UDP port
#define DUMMY_UDP_HEADER_SIZE	8

#define EN_CARD_EXP_DATE
#define HW_ARM_8RD1_0

#define ENABLE_EMAIL_SEND
#define MAX_EMAIL_ADDRESS	16


#define CARD_NO_10_DIGIT
#define CARD_NO_8_DIGIT

#define		SET			1
#define		CLR			0
#define SUPPORT_ONLY_2_DOOR
#define MAX_LOCAL_DOORS		2	  

//#ifdef BIO_METRIC
#define MAX_LOCAL_READER	2
//#else
//	#define MAX_LOCAL_READER	8
//#endif

#define SUPPORT_ACCESS_LEVEL
#define	PAGE_SIZE	528
#define	CODE_PAGE_SIZE	512
#define CHK_SUM_MOD_VALUE	0x55AA


#define ENABLE_PIN
#define TRANS_EXTRA_DATA
#define NEW_CARD_FORMAT   // birtdate & month are not in CardData-> we store it in Extra CardDara info

#ifdef HARDWARE_SI065
				#define MAX_ADMIN_USER_NEW		16    
				#define APPROX_MAX_CARD 			75000	    //  for NG we are will give 82000 Cards	
#else				
	#ifdef BIOLITE_LOW_END						  //ARMD0138-144
		#define MAX_ADMIN_USER_NEW		3
		#define APPROX_MAX_CARD			600				
	#else											//ARMD0398 
		#ifdef BIOLITE_HIGH_END
			#define APPROX_MAX_CARD		1300
			#define MAX_ADMIN_USER_NEW		8	
		#else	
			#ifdef ONE_LK_TXN_30K_CARDS
				#define MAX_ADMIN_USER_NEW		16
				#define APPROX_MAX_CARD			30000	
			#else
				#define MAX_ADMIN_USER_NEW		16
				#define APPROX_MAX_CARD			12000		
			#endif //#ifdef ONE_LK_TXN_30K_CARDS
		#endif//#ifdef BIOLITE_HIGH_END
	#endif//#ifdef BIOLITE_LOW_END
#endif// end of #ifedf HARDWARE_SI065

#define MAX_CARD_BLOCKS			10
//#define MAX_NO_OF_CARD   		(MAX_CARD_PER_BLOCK *  MAX_CARD_BLOCKS)	  
#ifdef HARDWARE_SI065
	#define MAX_TRANS			250000
#endif			
// 	#ifdef ONE_LK_TXN_30K_CARDS  
// 		#define MAX_TRANS				100000	/* this should be number of transactions per Page * number of pages in bug buffer*/
// 	#else
// 		#ifdef BIOLITE_LOW_END
// 			#define MAX_TRANS			10000
// 		#else
// 			#ifdef BIOLITE_HIGH_END
// 				#define MAX_TRANS		10000
// 			#else	
// 				#define MAX_TRANS		250000
// 				//#define MAX_TRANS		100000
// 			#endif//BIOLITE_HIGH_END
// 		#endif//#ifdef BIOLITE_LOW_END
// 	#endif//#ifdef ONE_LK_TXN_30K_CARDS 
//#endif   // #ifdef HARDWARE_SI065

#define MAX_SLAVE_NO			128
#define MAX_ACCESS_LEVEL		128				
#define MAX_TIME_ZONE			64				
#define MAX_TZ_SLOTS			4
#define MAX_HOLIDAY				42
#define MAX_CONTROLLER_NO		10000   

#define MAX_READERS_SUPPORT		MAX_LOCAL_READER	//8
#define MAX_READERS   			MAX_READERS_SUPPORT
#define MAX_RDR_HOLIDAY			MAX_HOLIDAY

#define ERROR_MESSAGE_BASE    50  //use 50 to 94 for event messages   //FA00084
#define MAX_ERROR_MSGS        45

//following is used to enable pinprox weigand interface reader
#define ENABLE_PIN_PROX

//Enable Phase2 features
#define SUPPORT_NSERIES2

//Enable following to display Event msgs from Flash
#define DISP_EVENT_MSGS_FROM_FLASH

#ifdef BIO_METRIC
// This mode will support any dual finger
	#define MODE_ANY_DUAL_MODE_FINGER
	#define TIMEOUT_DUAL_FINGER		25
#endif
 	#define TIMEOUT_DUAL_FINGER		25
#define ENABLE_SLAVE_SUPPORT


#define EMP_DISPLAY_PORT	PC_PORT 
//enable this so.
/*
when we write data.....
	1st read data
		if 1st 8 bytes are ff then read again
	now write data
	read writen data
		if it doesnt match with 1st write then write again

when we read data.......
	read data
		if 1st 8 bytes are ff then read again 
*/
#define READ_WRITE_CHECK

//#define SMART_SENSOR_DISPLAY //small seven seg display comment this to use 4 inch seven seg display.
//Select following to support 4-Digit 7 segment Bigger display
#define SUPPORT_7SEG_DISPLAY 

//#define ENABLE_GSM_GPRS

// This should be Commented to Disable DoorAccess Functionality
#define EN_DOORACCESS

//THIS is enable to disable all ph2 functionality on initialise
#define DISABLE_PHASE2_FUNCTIONALITY_FOR_THIS_CODE
#define MAX_TRNX_DOWNLOAD_SUPPORT	25		//this limits maximum trnx to be upload by tcppush

#define GLCD_SUPPPORT

#define SUPPORT_TOUCH_KEY
//Enabl3 this to support 8080 mode disable this for 6800 mode.
#define INTERFACE_8080

//enable this to support 2.8"tft with ili2398 controller and 16 bit mode, disable this to support 3.5" tft with ssd2119 controller and 8bit mode.
//#define ILI9328

//#define ADMIN_NO_LOG_OUT
//#define SENDING_IMAGE_DATA   //if enabled it will disable time display and scrolling display to speed up code.

//#define REMOVE_ICON_DELAY // for asthetic point of veiw 

//#define ROTATE_DISPLAY

//ENABLE THIS TO ENABLE SERVER AUTH FUNCTIONALITY.
//#define ENABLE_SERVER_AUTH

//ENABLE THIS TO ENABLE dual AUTH FUNCTIONALITY.
//#define ENABLE_DUAL_AUTH

