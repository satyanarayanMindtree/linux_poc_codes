#define WEI_DEF

#include "config.h"
#include "LPC23xx.h"      // Keil: Register definition file for LPC2378
#include "portdef.h"
#include "type.h"
#include "serial.h"
#include "irq.h"
#include "uart.h"
#include "SmartBio.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "protocol.h"
#include "ProcessWeiCard.h"
#include "rdcont.h"
#include "Access.h"
#include "weigand.h"

#define	MsgPrintInt	 	MsgPrint

//#define Delay50Micro(X)	Delay(X*15) 

// comment below if you want to disable debugging in this file	defect X0018
//#undef MsgPrint	
//#define MsgPrint  MsgPrint1


#ifdef ENABLE_WEIGAND_FUNCTIONS

void SendToWeigend26(unsigned char *cardno);
void SendToWeigend34(unsigned char *cardno);
void SendToWeigend32(unsigned char *cardno);
void SendToWeigend42(unsigned char *cardno);
void SendToWeigend44(unsigned char *cardno);
void SendToWeigend35(unsigned char *cardno);

void Delay50Micro(unsigned char delay);

#define PULSE_TIME 1
#define DELAY_TIME 48

#ifdef WEIGAND_OUT_READER
void SendWeigandData(struct USER_CARD_INFO *empcard,unsigned char weiin)
{
	MsgPrintInt(0x01,empcard->SearchCard.CardNo/0x10000,"SendWeigandData: MSB ");
	MsgPrintInt(0x01,empcard->SearchCard.CardNo%0x10000,"SendWeigandData: LSB ");

	CardArry[0] = empcard->SearchCard.CardNo & 0xff;
	CardArry[1] = (empcard->SearchCard.CardNo / 0x100) & 0xff;		
	CardArry[2] = (empcard->SearchCard.CardNo / 0x10000) & 0xff;
	CardArry[3] = (empcard->SearchCard.CardNo / 0x1000000) & 0xff;
	if( (empcard->InputType == INPUT_USER_FROM_FINGER)  ||   //only finger is received
		(empcard->InputType == INPUT_USER_FROM_KEYBOARD) ||  
		( empcard->InputType == (INPUT_USER_FROM_FINGER | INPUT_USER_FROM_KEYBOARD) )  )
	{
		weiin = SysInfo.WeigandOutCont & 0x3f;	//ARMF0554
		MsgPrint(0x01,weiin,"Taking Stored Weigand Bits=");
	}
	else 
	{
		if(SysInfo.WeigandOutCont & 0x40)//input not from finger and transparent is enabled
		{
			SendTransparentWeigendData();  //receives card data and count from global structure.
			return;
		}
	 	else if( !(SysInfo.WeigandOutCont & 0x80) )//not as per card 
	 	{
			weiin = SysInfo.WeigandOutCont & 0x3f;	//ARMF0554
			MsgPrint(0x01,weiin,"Taking Stored Weigand Bits=");
	 	}
	}
	MsgPrint(0x01,weiin,"Taking Weigand Bits=");
	switch(weiin)
	{
		case 32:
			SendToWeigend32(CardArry);
			break;
		case 34:
			SendToWeigend34(CardArry);
			break;
		case 35:					   //X0035
			SendToWeigend35(CardArry);
			break;
	
#ifdef DISABLE_WEIG_NOT_REQUIRED_FUN
		case 44:
			SendToWeigend44(CardArry);
			break;
		case 42:
			SendToWeigend42(CardArry);
			break;
#endif
		case 26:
		default:
			SendToWeigend26(CardArry);
			break;
    }
}

void SendToWeigend26(unsigned char *cardno)
{		
unsigned char i;
unsigned long cardnumber;

	cardnumber = 0;	
	cardnumber = (cardno[0]*0x100) & 0x0000FF00;
	cardnumber = cardnumber + (unsigned long)cardno[2] * 0x1000000; 
	cardnumber = (unsigned long)cardnumber  + (unsigned long)(cardno[1] * 0x10000);
	cardnumber = (unsigned long)cardnumber / 2;
	
	MsgPrintInt(0x01,cardnumber/0x10000,"Card number 3MSB ");
	MsgPrintInt(0x01,cardnumber%0x10000,"Card number 3LSB ");

	// Even Parity
	if((CheckNoOfOneInInt(cardno[2] * 0x100 + (cardno[1] & 0xF0)) % 2) == 0)
		cardnumber = (unsigned long)(cardnumber & 0x7FFFFFFF);
	else
		cardnumber = (unsigned long)(cardnumber | 0x80000000);

	if((CheckNoOfOneInInt((cardno[1] & 0x0F) * 0x100 + cardno[0]) % 2) == 0)
	{	// Odd parity
		cardnumber = (unsigned long)(cardnumber | 0x00000040);													 
	}
	else
	{
		cardnumber = (unsigned long)(cardnumber & 0xFFFFFFB0);  //   1011  B
	}
//	MsgPrintInt(0x01,cardnumber/0x10000,"Card number MSB RAW");
//	MsgPrintInt(0x01,cardnumber%0x10000,"Card number LSB RAW");

		DISABLE_INTERRUPT();
	//the data is given out on d0 and d1 
		WEIGAND_0_HIGH();			// WD0 = SET ;
		WEIGAND_1_HIGH();			// WD1 = SET ;
		for(i=0;i<26;i++)
		{
			if(cardnumber & 0x80000000)							
			{ 
				WEIGAND_1_LOW();		// WD1 = CLR ;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_1_HIGH();       //WD1 = SET;
			}
			else
			{ 
				WEIGAND_0_LOW();		// WD0 = CLR;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_0_HIGH();		//WD0 = SET;
			}
			Delay50Micro(DELAY_TIME);
			cardnumber = (unsigned long)(cardnumber * 2);
		}
		Delay50Micro(DELAY_TIME);
		WEIGAND_0_HIGH();			// WD0 = SET ;
		WEIGAND_1_HIGH();			// WD1 = SET ;
		ENABLE_INTERRUPT();
}

//====================================================================================
void SendToWeigend32(unsigned char *cardno)
{		
unsigned char i;
unsigned long cardnumber;
	/* the data is given out on d0 and d1 */

	cardnumber = cardno[0];	
	cardnumber = cardnumber + ((cardno[1]*0x100) & 0x0000FF00 );
	cardnumber = cardnumber + (unsigned long)cardno[2] * 0x10000; 
	cardnumber = (unsigned long)cardnumber + (unsigned long)(cardno[3] * 0x1000000);
	MsgPrintInt(0x01,cardnumber/0x10000,"Card number 3MSB ");
	MsgPrintInt(0x01,cardnumber%0x10000,"Card number 3LSB ");
	DISABLE_INTERRUPT();
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;
	for(i=0;i<32;i++)
	{
		if(cardnumber & 0x80000000)							
		{ 
			WEIGAND_1_LOW();		// WD1 = CLR ;
			Delay50Micro(PULSE_TIME);		
			WEIGAND_1_HIGH();       //WD1 = SET;
		}
		else
		{ 
			WEIGAND_0_LOW();		// WD0 = CLR;
			Delay50Micro(PULSE_TIME);		
			WEIGAND_0_HIGH();		//WD0 = SET;
		}
		Delay50Micro(DELAY_TIME);
		cardnumber = (unsigned long)(cardnumber * 2);
	}
	Delay50Micro(DELAY_TIME);
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;
	ENABLE_INTERRUPT();
}

void SendToWeigend34(unsigned char *cardno)
{		
unsigned char i;
unsigned char parity;
unsigned long cardnumber;
		/* the data is given out on d0 and d1 */

	cardnumber = cardno[0];	
	cardnumber = cardnumber + ((cardno[1]*0x100) & 0x0000FF00);
	cardnumber = cardnumber + (unsigned long)cardno[2] * 0x10000; 
	cardnumber = (unsigned long)cardnumber + (unsigned long)(cardno[3] * 0x1000000);
	MsgPrintInt(0x01,cardnumber/0x10000,"Card number 3MSB ");
	MsgPrintInt(0x01,cardnumber%0x10000,"Card number 3LSB ");

	if((CheckNoOfOneInInt(cardnumber / 0x10000) % 2) == 0)	// Even parity
		parity = 0;
	else
		parity = 1;
	if((CheckNoOfOneInInt(cardnumber & 0xFFFF) % 2) != 0)	// Odd parity
		parity = parity & 0x01;
	else
		parity = parity | 0x02;
	MsgPrintInt(0x01,parity,"Parity = ");	

	DISABLE_INTERRUPT();
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;
	if(parity & 0x01)							
	{ 
		WEIGAND_1_LOW();		// WD1 = CLR ;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_1_HIGH();       //WD1 = SET;
	}
	else
	{ 
		WEIGAND_0_LOW();		// WD0 = CLR;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_0_HIGH();		//WD0 = SET;
	}
	Delay50Micro(DELAY_TIME);

	for(i=0;i<32;i++)
	{
		if(cardnumber & 0x80000000)							
		{ 
			WEIGAND_1_LOW();		// WD1 = CLR ;
			Delay50Micro(PULSE_TIME);		
			WEIGAND_1_HIGH();       //WD1 = SET;
		}
		else
		{ 
			WEIGAND_0_LOW();		// WD0 = CLR;
			Delay50Micro(PULSE_TIME);		
			WEIGAND_0_HIGH();		//WD0 = SET;
		}
		Delay50Micro(DELAY_TIME);
		cardnumber = (unsigned long) (cardnumber * 2);
	}
	if(parity & 0x02)							
	{ 
		WEIGAND_1_LOW();		// WD1 = CLR ;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_1_HIGH();       //WD1 = SET;
	}
	else
	{ 
		WEIGAND_0_LOW();		// WD0 = CLR;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_0_HIGH();		//WD0 = SET;
	}
	Delay50Micro(DELAY_TIME);
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;
	ENABLE_INTERRUPT();
}

void SendToWeigend35(unsigned char *cardno)	   //X0035
{		
unsigned char i;
unsigned char parity;
unsigned long cardnumber;
	/* the data is given out on d0 and d1 */

	cardnumber = cardno[0];	
	cardnumber = cardnumber + ((cardno[1] * 0x100) & 0x0000FF00);
	cardnumber = cardnumber  + (unsigned long)cardno[2] * 0x10000; 
	cardnumber = (unsigned long)cardnumber + (unsigned long)(cardno[3] * 0x1000000);
	MsgPrintInt(0x01,cardnumber/0x10000,"Card number 3MSB ");
	MsgPrintInt(0x01,cardnumber%0x10000,"Card number 3LSB ");

	if((Check35BitEvenParity(cardnumber) % 2) == 0)			//Even parity
		parity = 0;
	else
		parity = 1;

	if((Check35BitOddParity1(cardnumber,parity) % 2) != 0)	//Odd parity 1
		parity = parity & 0x01;
	else
		parity = parity | 0x02;


	if((Check35BitOddParity2(cardnumber,parity) % 2) != 0)	//Odd parity 2
		parity = parity & 0x03;
	else
		parity = parity | 0x04;

	MsgPrintInt(0x01,parity,"Parity = ");	

	DISABLE_INTERRUPT();
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;

	if(parity & 0x04)			//Odd2 Parity				
	{ 
		WEIGAND_1_LOW();		// WD1 = CLR ;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_1_HIGH();       //WD1 = SET;
	}
	else
	{ 
		WEIGAND_0_LOW();		// WD0 = CLR;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_0_HIGH();		//WD0 = SET;
	}
	Delay50Micro(DELAY_TIME);

	if(parity & 0x01)			//Even Parity				
	{ 
		WEIGAND_1_LOW();		// WD1 = CLR ;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_1_HIGH();       //WD1 = SET;
	}
	else
	{ 
		WEIGAND_0_LOW();		// WD0 = CLR;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_0_HIGH();		//WD0 = SET;
	}
	Delay50Micro(DELAY_TIME);

	for(i=0;i<32;i++)
	{
		if(cardnumber & 0x80000000)							
		{ 
			WEIGAND_1_LOW();		// WD1 = CLR ;
			Delay50Micro(PULSE_TIME);		
			WEIGAND_1_HIGH();       //WD1 = SET;
		}
		else
		{ 
			WEIGAND_0_LOW();		// WD0 = CLR;
			Delay50Micro(PULSE_TIME);		
			WEIGAND_0_HIGH();		//WD0 = SET;
		}
		Delay50Micro(DELAY_TIME);
		cardnumber = (unsigned long) (cardnumber * 2);
	}
	if(parity & 0x02)			//Odd1 Parity				
	{ 
		WEIGAND_1_LOW();		// WD1 = CLR ;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_1_HIGH();       //WD1 = SET;
	}
	else
	{ 
		WEIGAND_0_LOW();		// WD0 = CLR;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_0_HIGH();		//WD0 = SET;
	}

	Delay50Micro(DELAY_TIME);
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;
	ENABLE_INTERRUPT();
}

void SendTransparentWeigendData(void)
{		
unsigned char i,count;
unsigned long cardnumber,cardnumber2;
		// the data is given out on d0 and d1 

	MsgPrintInt(0x01,TransparentCardData.WCount ,"Transparent mode :wcount:");
	MsgPrintInt(0x01,TransparentCardData.WeigandData/0x10000,"Card number 3MSB:");
	MsgPrintInt(0x01,TransparentCardData.WeigandData%0x10000,"Card number 2   :");
	MsgPrintInt(0x01,TransparentCardData.WeigandExData/0x10000,"Card number 1   :");
	MsgPrintInt(0x01,TransparentCardData.WeigandExData%0x10000,"Card number 0LSB:");


	if(TransparentCardData.WCount <= 32)
	{
		cardnumber = TransparentCardData.WeigandData << (32-TransparentCardData.WCount);
		
		DISABLE_INTERRUPT();
		WEIGAND_0_HIGH();			// WD0 = SET ;
		WEIGAND_1_HIGH();			// WD1 = SET ;
		for(i=0;i<TransparentCardData.WCount;i++)
		{
			if(cardnumber & 0x80000000)							
			{ 
				WEIGAND_1_LOW();		// WD1 = CLR ;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_1_HIGH();       //WD1 = SET;
			}
			else
			{ 
				WEIGAND_0_LOW();		// WD0 = CLR;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_0_HIGH();		//WD0 = SET;
			}
			Delay50Micro(DELAY_TIME);
			cardnumber = (unsigned long) (cardnumber * 2);
		}
		Delay50Micro(DELAY_TIME);
		WEIGAND_0_HIGH();			// WD0 = SET ;
		WEIGAND_1_HIGH();			// WD1 = SET ;
		ENABLE_INTERRUPT();
	}
	else
	{
		cardnumber = TransparentCardData.WeigandData;
		count = TransparentCardData.WCount - 32;
		cardnumber2 =  TransparentCardData.WeigandExData << (32-count);
		
		
		DISABLE_INTERRUPT();
		WEIGAND_0_HIGH();			// WD0 = SET ;
		WEIGAND_1_HIGH();			// WD1 = SET ;
		for(i=0;i<32;i++)
		{
			if(cardnumber & 0x80000000)							
			{ 
				WEIGAND_1_LOW();		// WD1 = CLR ;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_1_HIGH();       //WD1 = SET;
			}
			else
			{ 
				WEIGAND_0_LOW();		// WD0 = CLR;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_0_HIGH();		//WD0 = SET;
			}
			Delay50Micro(DELAY_TIME);
			cardnumber = (unsigned long) (cardnumber * 2);
		}
		for(i=0; i<count; i++)
		{
			if(cardnumber2 & 0x80000000)							
			{ 
				WEIGAND_1_LOW();		// WD1 = CLR ;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_1_HIGH();       //WD1 = SET;
			}
			else
			{ 
				WEIGAND_0_LOW();		// WD0 = CLR;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_0_HIGH();		//WD0 = SET;
			}
			Delay50Micro(DELAY_TIME);
			cardnumber2 = (unsigned long) (cardnumber2 * 2);
		}
		Delay50Micro(DELAY_TIME);
		WEIGAND_0_HIGH();			// WD0 = SET ;
		WEIGAND_1_HIGH();			// WD1 = SET ;
		ENABLE_INTERRUPT();
	}
}                                             

void Delay50Micro(unsigned char delay)
{
unsigned int tempdelay;

//	tempdelay = delay * 500;
	tempdelay = delay * 160;
	while(tempdelay--){}
	return;
}

#endif
#ifdef DISABLE_WEIG_NOT_REQUIRED_FUN
void SendToWeigend42(unsigned char data *cardno)
{		
unsigned char j,i;
unsigned char datatosend;

	DISABLE_INTERRUPT();
	j = 0;

	/* the data is given out on d0 and d1 */
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;

	while(j < 4)
	{  /* Just send last three bytes */
		datatosend = cardno[3-j];			
		for(i=0;i<8;i++)
		{
			if(datatosend & 0x80)
			{ 
				WEIGAND_1_LOW();		// WD1 = CLR ;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_1_HIGH();       //WD1 = SET;
			}
			else
			{ 
				WEIGAND_0_LOW();		// WD0 = CLR;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_0_HIGH();		//WD0 = SET;
			}
			Delay50Micro(DELAY_TIME);
			datatosend= datatosend << 1;
		} 
		j++;
//		WDT_RESET();
	}
	Delay50Micro(DELAY_TIME);
	WEIGAND_0_HIGH();
	Delay50Micro(PULSE_TIME);							
	WEIGAND_1_HIGH();				
	ENABLE_INTERRUPT();
}

void SendToWeigend44(unsigned char data *cardno)
{		
unsigned char j,i;
unsigned char datatosend;

	DISABLE_INTERRUPT();
	j = 0;

	/* the data is given out on d0 and d1 */
	WEIGAND_0_HIGH();			// WD0 = SET ;
	WEIGAND_1_HIGH();			// WD1 = SET ;
	for(i=0;i<1;i++)
	{	
		WEIGAND_0_LOW();		// WD0 = CLR ;
		Delay50Micro(PULSE_TIME);		
		WEIGAND_0_HIGH();		//WD0 = SET;
		Delay50Micro(DELAY_TIME);
	}
	while(j < 4)
	{  /* Just send last three bytes */
		datatosend = cardno[3-j];			
		for(i=0;i<8;i++)
		{
			if(datatosend & 0x80)
			{ 
				WEIGAND_1_LOW();		// WD1 = CLR ;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_1_HIGH();       //WD1 = SET;
			}
			else
			{ 
				WEIGAND_0_LOW();		// WD0 = CLR;
				Delay50Micro(PULSE_TIME);		
				WEIGAND_0_HIGH();		//WD0 = SET;
			}
			Delay50Micro(DELAY_TIME);
			datatosend= datatosend << 1;
		} 
		j++;
//		WDT_RESET();
	}
	WEIGAND_1_HIGH();			
	Delay50Micro(PULSE_TIME);		
	WEIGAND_1_HIGH();		
	ENABLE_INTERRUPT();
}

#endif

#endif



