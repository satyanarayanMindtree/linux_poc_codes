

#define MAX_POLL_SLAVE_ID		128
#define MAX_SLAVE_SER_BUFF  	1024

#define STATUS_SLAVE_TIME_OUT	0x90
#define SLAVE_TERMINATOR		'\r'
#define SLAVE_TERMINATOR1		'\n'

extern unsigned char SlaveSerBuffer[MAX_SLAVE_SER_BUFF+2];//ARMD0322
//unsigned char F_SerialPollSlaveProxy, F_PollSlave_Serial_Data, F_SerialSlaveDataProxy, F_SerialDumpData;
extern unsigned char F_SerialDumpData,F_SerialPollSlaveProxy,F_PollSlave_Serial_Data;
extern unsigned char F_Slave_DataStart, F_WaitForSlaveResponse, SlaveCMD;
//unsigned int SlaveWaitTimeOut;
static unsigned int SlaveSerPtr;
static unsigned char WaitDataSocketNo;

void HandleSerialSlaveCmd(volatile unsigned char *buffer,unsigned char port);
extern unsigned char SendCommandToSlave(volatile unsigned char *buffer,unsigned int count,unsigned char port);
extern unsigned char WaitForSlaveRespTimeout(unsigned int time);
extern unsigned char WaitForMainloopSlaveResponse(void);
extern unsigned char HandleSlaveSerialData(unsigned char serdata);
extern void InitliaseSlaveFlags(void);	//ARMD0341


