

extern void ReadAllCardDataFromFlash(void);
extern unsigned char WriteAllCardDataToFlash(void);
extern unsigned char WriteCardDataToFlash(unsigned int cardpos);
extern unsigned char ReadDoorInfoFromFlash(void);
extern unsigned char WriteDoorInfoToFlash(void);
extern unsigned char ReadSysInfoFromFlash(void);
extern unsigned char WriteSysInfoToFlash(void);
extern void PrintAccessMemMap(void);
extern void TimeZoneRestore(void);
extern void TimeZoneBackup(void);
extern unsigned int GetCheckSum(unsigned char *datastr,unsigned int datasize);
extern unsigned long GetFlashCardDataChkSum(void);
extern void xmem2root(BYTE *data,BYTE *buffer,short Length);
extern unsigned char DisplayFlashpage(BYTE pageno);

extern unsigned char WriteDefaultReaderInfo(void);
extern unsigned char ReadReaderInfoFromFlash(void); 
extern unsigned char WriteReaderInfoToFlash(void);
extern unsigned char ReadBatteryRam(unsigned int start,unsigned int bytes);
extern int GetAccessLevel(unsigned char alno,struct ACCESS_LEVEL_STR *accesslevel);
extern int StoreAccessLevel(unsigned char alno,struct ACCESS_LEVEL_STR *accesslevel);
extern unsigned char WriteModelInfoToFlash(void);
extern unsigned char ReadModelInfoFromFlash(void);
#ifdef SUPPORT_NSERIES2
extern int GetAccessMonth(unsigned char amno,struct ACCESS_MONTH_STR *accessmonth);
extern int StoreAccessMonth(unsigned char amno,struct ACCESS_MONTH_STR *accessmonth);
#endif
unsigned char WriteIOEventInfoToFlash(void);
unsigned char ReadIOEventInfoFromFlash(void);
unsigned char WriteTimeBasedAction(struct TIME_BASED_ACTION (*pTimeBasedAction)[MAX_TIME_BASED_ACTIONS]);
unsigned char ReadTimeBasedAction(struct TIME_BASED_ACTION (*pTimeBasedAction)[MAX_TIME_BASED_ACTIONS]);
extern unsigned char WriteSplCardFlagInfoToFlash(void);
extern unsigned char ReadSplCardFlagInfoFromFlash(void);
