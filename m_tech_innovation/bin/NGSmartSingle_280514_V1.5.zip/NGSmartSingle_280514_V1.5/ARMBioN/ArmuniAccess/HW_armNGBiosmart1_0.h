/*
This file is created to hold hardware information for board ARM Biolite
This is for Biolite board where reader is connected on weigand
*/
//HW_ARM_BioLite1_0
												
//===========================================================================
/* LCD Display */
/* LCD IO definitions */
//#define PINO_P1_LCD_E     0x02000000	/* Enable control pin                */

//#define PINO_P1_LCD_RW    0x00000000	/* Read/Write control pin            */

//#define PINO_P1_LCD_RS    0x00800000	/* Data/Instruction control          */

#define DIR_LCD_PORT_BITS()	{}//{FIO1DIR |= PINO_P1_LCD_E | PINO_P1_LCD_RW | PINO_P1_LCD_RS;}
#define DIR_LCD_OUT_PORT()	{}//{FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000;}

#define B_LCD_E(X)	{}//{(X == SET) ? (FIO1SET |= PINO_P1_LCD_E) : (FIO1CLR |= PINO_P1_LCD_E);}
#define B_LCD_RW(X)	{}//{(X == SET) ? (FIO1SET |= PINO_P1_LCD_RW) : (FIO1CLR |= PINO_P1_LCD_RW);}
#define B_LCD_RS(X) {}//{(X == SET) ? (FIO1SET |= PINO_P1_LCD_RS) : (FIO1CLR |= PINO_P1_LCD_RS);}

//LCD OUT Port is created using Port 2 and port 3 
//port 2 = 0000 0000 0000 0000 0000 0000 1111 1100	 
//port 3 = 0000 0110 0000 0000 0000 0000 0000 0000	
#define BYTE_LCD_OUT(x) 	{}


//LCD backlite control definations
#ifdef ENABLE_LCD_BACKLITE
	#define PINO_P1_LCD_BKLT    0x80000000		//P1.31
	#define DIR_LCD_BKLT_PORT()	{FIO1DIR |= PINO_P1_LCD_BKLT;}
	#define B_LCD_BKLT(X)		{(X == SET) ? (FIO1SET |= PINO_P1_LCD_BKLT) : (FIO1CLR |= PINO_P1_LCD_BKLT);}
	#define ON_LCD_BACKLIGHT()	{DIR_LCD_BKLT_PORT(); B_LCD_BKLT(SET);}
	#define OFF_LCD_BACKLIGHT()	{DIR_LCD_BKLT_PORT(); B_LCD_BKLT(CLR);}
#endif

//=================================================================================================
/* Input Output Selection using 138 IC */
#define CS_IPCS1	0
#define CS_IPCS2	1
#define CS_OPCS1	2	//this pin is used as output in Biolite and as input in v1.6 board.
#define CS_OPCS2	3
#define CS_IPCS3	4
#define CS_OPCS3	5
#define CS_BUZZER	7
#define CS_NO_SEL 	8

//=================================================================================================
//I/O selection pins
//#define PINO_P4_CSIP	0x10000000	  		//P4.28
//#define PINO_P4_CSOP  	0x20000000			//P4.29

#define PIN_P0_CSIP  	  0x00000010			//P0.4 ,cs1   //cs_ipcs1 , CS input Latch
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
#define PIN_P1_CSOP  	  0x80000000			//P1.31 ,cs3  //cs_opcs1 , CS output Latch
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs2
//#define PIN_P0_CS1  	0x00000008			//P0.4 ,cs8

#define PINS_P1_IO     		0x07f80000	// :pin 1.19 to p1.26   D0 to D7           

//#define DIR_IO_DEC_PINS()		{FIO4DIR |= PINO_P4_CSIP | PINO_P4_CSOP;}
#define DIR_IO_DEC_PINS()		{FIO1DIR |= PIN_P1_CSOP ; FIO0DIR |= PIN_P0_CSIP ;}     //select cs as out pins

//#define DIR_IO_OUT_PORT()		{FIO2DIR |= 0x000000FC; FIO3DIR |= 0x06000000;}
#define DIR_IO_OUT_PORT()		{FIO1DIR |= PINS_P1_IO; } //select data pin as out

//#define DIR_IO_IN_PORT()		{FIO2DIR &= ~0x000000FC; FIO3DIR &= ~0x06000000;}
#define DIR_IO_IN_PORT()		{FIO1DIR &= ~PINS_P1_IO; } //select data pin as in

#define DISABLE_DECODER() 			{FIO1SET |= PIN_P1_CSOP ; FIO0SET |= PIN_P0_CSIP ;}

#define BYTE_IO_OUT_PORT(x)		{DIR_IO_OUT_PORT(); FIO1PIN &= ~PINS_P1_IO; 	\
	FIO1PIN |= (x<<19 & PINS_P1_IO);		}

//#define BYTE_IO_READ_PORT(X)	{DIR_IO_IN_PORT(); X = (FIO2PIN & 0x000000FC) >> 2;	\
//									X = X | ((FIO3PIN & 0x06000000) >> 19);}	   //ARMD0063								
#define BYTE_IO_READ_PORT(x)	{	DIR_IO_IN_PORT();				\
	x = (FIO1PIN & PINS_P1_IO) >> 19;	\
}



extern volatile unsigned int BuffOPCS1Latch,BuffOPCS2Latch;			// Buffer to keep data which needs to be output to OPCS1 Latch
// Following is just to define the Latch 1 Output which we will use 
#define DEFAULT_CS1_OUT		0x05


#define CS1_IO_DOOR1	0x01   //d0	
#define CS1_IO_DOTL1	0x02   //D1
#define CS1_IO_DOOR2	0x04   //D2
#define CS1_IO_RDBZ2	0x08   //D3
#define CS1_IO_RDLED2	0x10   //D4
#define CS1_IO_BUZOB	0x20   //D5
#define CS1_LED_INT		0x40   // // Weigand Out LED_INT  d6  
#define CS1_R_TAMP		0x80   // Weigand Out Tamper      d7



extern unsigned char F_BuzzerStatus;

#define BUZZER_OFF_INTERRUPT()	{F_BuzzerStatus=0;}	
#define BUZZER_ON_INTERRUPT()	{F_BuzzerStatus=1;}	


//#define DOOR_OPEN(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_DOOR##X;	\
//						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
//						}

#define DOOR_OPEN(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_DOOR##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define DOOR_CLOSE(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_IO_DOOR##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define SET_DOTL(X)		{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch |= CS1_IO_DOTL##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define CLR_DOTL(X)		{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_DOTL##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define RDR_BUZ_ON(X)	{ SelectIOCS(CS_OPCS1);BuffOPCS1Latch |= CS1_IO_RDBZ##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define RDR_BUZ_OFF(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_RDBZ##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define RDR_LED_ON(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_IO_RDLED##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL);	\
						}

#define RDR_LED_OFF(X)	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_RDLED##X;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); 	\
						}

#define BUZZER_ON()		{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_IO_BUZOB;		\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); BUZZER_ON_INTERRUPT(); 	\
						}

#define BUZZER_OFF()	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_IO_BUZOB;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); BUZZER_OFF_INTERRUPT();	\
						}
						
						
// 		LED_INT_ON is of LED_INT of U17 IC in SIO65V1.0			
// Wigand out Tamper-> R_TAMP of J23 pin in SI065V1.0
//red led on
#define LED_INT_OFF()		{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= CS1_LED_INT;		\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL);	\
						}
//green led on
#define LED_INT_ON()	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= ~CS1_LED_INT;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); \
						}

#define R_TAMP_O()		{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch |= ~CS1_R_TAMP;		\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); \
						}

#define R_TAMP_OFF()	{ SelectIOCS(CS_OPCS1); BuffOPCS1Latch &= CS1_R_TAMP;	\
						  BYTE_IO_OUT_PORT(BuffOPCS1Latch);	SelectIOCS(CS_NO_SEL); \
						}

extern volatile unsigned int readinput;
//extern void  PROCESS_INPUT_DEBOUNCE_INTERRUPT(void);



#define READ_INPUT(X)								\
	{   												\
		SelectIOCS(CS_IPCS1);							\
		BYTE_IO_READ_PORT(readinput);					\
		X = readinput; 									\
		SelectIOCS(CS_NO_SEL);							\
	}


#define BIT_PORT_EGRESS1	0
#define BIT_PORT_DORL1		1
#define BIT_PORT_FIRE		2								
#define BIT_PORT_TAMPER		3
#define BIT_PORT_IRSENSE	4       //ir sense or touch sense depending on j9
#define BIT_PORT_INTRUSION	5//ARMD0326
#define BIT_PORT_WOLED		6
#define BIT_PORT_RD2_TMP	7

#ifdef HARDWARE_SI065    //for ng
	#define IN_IRSense		((IOInput >> BIT_PORT_IRSENSE) & 0x1)
#else
	#ifdef HARDWARE_SI032
		#define IN_IRSense		((IOInput >> BIT_PORT_IRSENSE) & 0x1)
	#else
		#define IN_IRSense	1			 
	#endif
#endif

//Active low intrusion indicates that intrusion happned .. as this hardware do not have same we make it default as 1
//#define IN_Intrusion		1 //use this for BLS h/w

#define IN_Intrusion	((IOInput >> BIT_PORT_INTRUSION) & 0x1)	//change this when using same code for arm biolite.BLS h/w
                        //ARMD0326
#define IN_Egress1		((IOInput >> BIT_PORT_EGRESS1) & 0x1)	
#define IN_Dotl1		((IOInput >> BIT_PORT_DORL1) & 0x1)
#define IN_Fire			((IOInput >> BIT_PORT_FIRE) & 0x1)
#define IN_Tamper		((IOInput >> BIT_PORT_TAMPER) & 0x1)
#define IN_WOLed		((IOInput >> BIT_PORT_WOLED) & 0x1)


/*---------------------------------------------------------------
Weigand O/P port definations
D0 = P3.25  
D1 = P3.26
WOLEDIN = I/P Bus pin6 

//For NG BioSmart SI065
D0 = P0.19  
D1 = P0.20

---------------------------------------------------------------*/		  
//#define PINO_B_WOUTD0	0x10000000
//#define PINO_B_WOUTD1	0x01000000

#define P3_25_WOUTD0	0x02000000
#define P3_26_WOUTD1	0x04000000
#define DIR_WEIGAND_OUT_PORT()	{FIO3DIR |= P3_25_WOUTD0; FIO3DIR |= P3_26_WOUTD1;}

#define B_WOUTD0(X)	{(X == SET) ? (FIO3SET |= P3_25_WOUTD0) : (FIO3CLR |= P3_25_WOUTD0);}
#define B_WOUTD1(X)	{(X == SET) ? (FIO3SET |= P3_26_WOUTD1) : (FIO3CLR |= P3_26_WOUTD1);}

#define WEIGAND_0_HIGH()	{DIR_WEIGAND_OUT_PORT(); B_WOUTD0(CLR);}//for NG we use trasistor at out put so invert signals 
#define WEIGAND_1_HIGH()	{DIR_WEIGAND_OUT_PORT(); B_WOUTD1(CLR);}
#define WEIGAND_0_LOW()		{DIR_WEIGAND_OUT_PORT(); B_WOUTD0(SET);}
#define WEIGAND_1_LOW()		{DIR_WEIGAND_OUT_PORT(); B_WOUTD1(SET);}

#define CHK_WIGAND_IN_GRANT() 	(IN_WOLed == CLR)   //  IN NG BIOSmart it LED_EXt
#define CHK_WIGAND_IN_GRANT_OVER() 	(IN_WOLed == SET)	// NGD00077

#define PIN4_LED_RED  0x10000000   // for RED LED 
#define DIR_LED_RED()	{FIO4DIR |= PIN4_LED_RED;}
#define LED_RED_HIGH() {DIR_LED_RED(); FIO4SET |= PIN4_LED_RED;}
#define LED_RED_LOW() {DIR_LED_RED(); FIO4CLR |= PIN4_LED_RED;}

#define PIN0_LED_BLUE  0x00000020   // FOR BLUE LED 
#define DIR_LED_BLUE()	{FIO0DIR |= PIN0_LED_BLUE;}
#define LED_BLUE_HIGH() {DIR_LED_BLUE(); FIO0SET |= PIN0_LED_BLUE;}
#define LED_BLUE_LOW() {DIR_LED_BLUE(); FIO0CLR |= PIN0_LED_BLUE;}

//----------------------End Of Weigand Out ----------------

extern unsigned char F_OutPutLock;
extern void SelectIOCS(unsigned char iotype);
extern void DoorClose(unsigned char drno);
extern void DoorOpen(unsigned char drno);
extern void DOTLLedOff(unsigned int rdno);
extern void DOTLLedOn(unsigned int rdno);
extern void WeigandLedOff(unsigned char rdno);
extern void WeigandLedOn(unsigned char rdno);
extern void WeigandBuzOn(unsigned char rdno);
extern void WeigandBuzOff(unsigned char rdno);
extern void InitialiseIO(void);
extern void MakeWeigandBuzON(unsigned char rdrno, unsigned char type);
extern void WeigandBuzControl(unsigned char rdno);
////////////////////////////////////////// GLCD 3.2" /////////////////////////////////////

#define PIN_P2_GLCD_E     0x00000004	// Enable control pin    p2.2            
#define PIN_P2_GLCD_RS    0x00000008	// Data/Instruction control  p2.3        
#define PIN_P2_GLCD_WR    0x00000010	// RI_VD:pin: 2.4               
#define PIN_P2_GLCD_RD    0x00000020	// IORD:pin: 2.5              
#define PIN_P2_GLCD_RESET 0x00000040	// IORD:pin: 2.6              
#define PIN_P2_GLCD_BL	  0x00002000	// IORD:pin: 2.13

#define PINS_P1_GLCD_DATA     		0x07f80000	// IORD:pin 1.19 to p1.26              

#define DIR_OUT_GLCD_CTRL_BITS()	{FIO2DIR |= PIN_P2_GLCD_E | PIN_P2_GLCD_RS | PIN_P2_GLCD_RD | PIN_P2_GLCD_WR | PIN_P2_GLCD_RESET | PIN_P2_GLCD_BL; }

#define DIR_OUT_GLCD_DATALINE()		{FIO1DIR |= PINS_P1_GLCD_DATA; }

#define DIR_IN_GLCD_DATALINE()		{FIO1DIR &= ~PINS_P1_GLCD_DATA;}
			
// #define B_GLCD_E(X)  {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_E) :  (FIO2CLR |= PIN_P2_GLCD_E);}
// #define B_GLCD_RS(X) {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_RS) : (FIO2CLR |= PIN_P2_GLCD_RS);}
// #define B_GLCD_RD(X) {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_RD) : (FIO2CLR |= PIN_P2_GLCD_RD);}
// #define B_GLCD_WR(X) {(X == SET) ? (FIO2SET |= PIN_P2_GLCD_WR) : (FIO2CLR |= PIN_P2_GLCD_WR);}
			
// #define BYTE_GLCD_OUT(x) 	{		   			\
// 	FIO1PIN &= ~PINS_P1_GLCD_DATA;	 		   	\
// 	FIO1PIN |= (x<<19 & PINS_P1_GLCD_DATA);		\
// }

#define BYTE_GLCD_OUT(x) 	{		   			\
	FIO1CLR = PINS_P1_GLCD_DATA;	 		   	\
	FIO1SET = (x<<19 & PINS_P1_GLCD_DATA);		\
}

#define GLCD_OUT_LINES 			FIO1PIN
#define GLCD_OUT_LINES_SHIFT 	19

#define BYTE_GLCD_READ(x)	{					\
	x = (FIO1PIN & PINS_P1_GLCD_DATA) >> 19;	\
}

#define CLR_CD			{FIO2CLR = PIN_P2_GLCD_RS;}
#define SET_CD          {FIO2SET = PIN_P2_GLCD_RS;}
#define CLR_CS			{FIO2CLR = PIN_P2_GLCD_E;}
#define SET_CS			{FIO2SET = PIN_P2_GLCD_E;}
#define CLR_WR			{FIO2CLR = PIN_P2_GLCD_WR;}
#define SET_WR          {FIO2SET = PIN_P2_GLCD_WR;}                                             
#define CLR_RESET       {FIO2CLR = PIN_P2_GLCD_RESET;}
#define SET_RESET       {FIO2SET = PIN_P2_GLCD_RESET;}
#define CLR_RD			{FIO2CLR = PIN_P2_GLCD_RD;}                                             
#define SET_RD          {FIO2SET = PIN_P2_GLCD_RD;}
#define CLR_BL			{FIO2CLR = PIN_P2_GLCD_BL;}                                             
#define SET_BL          {FIO2SET = PIN_P2_GLCD_BL;}

#define CLR_CS_CD				{FIO2CLR = PIN_P2_GLCD_E|PIN_P2_GLCD_RS;}
#define SET_RD_WR				{FIO2SET = PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}           
#define SET_WR_CS				{FIO2SET = PIN_P2_GLCD_WR|PIN_P2_GLCD_E;}	           
#define SET_CD_RD_WR			{FIO2SET = PIN_P2_GLCD_RS|PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}
#define CLR_CS_CD_SET_RD_WR		{FIO2CLR = PIN_P2_GLCD_E|PIN_P2_GLCD_RS;   FIO2SET = PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}
#define CLR_CS_SET_CD_RD_WR 	{FIO2CLR = PIN_P2_GLCD_E;   FIO2SET = PIN_P2_GLCD_RS|PIN_P2_GLCD_RD|PIN_P2_GLCD_WR;}

#define B_LCD_E(X)   {}
#define B_LCD_RW(X)  {}
#define B_LCD_RS(X)  {}
#define BYTE_LCD_OUT(x)       {}
#define DIR_LCD_PORT_BITS()   {}
#define DIR_LCD_OUT_PORT()    {}
#define DECODER_ENABLE()      {}
#define DECODER_DISABLE()     {}

//-------------for 6800 interface
//ENABLE PIN WORKS ON FALLING EDGE
#define CLR_E	CLR_RD			                                           
#define SET_E	SET_RD     

///////////////////////////// touch screen ////////////////
//Interchange XM to XP and YP to YM to rotate touch screen vertivally and horizontaly
// #ifdef ROTATE_DISPLAY
	#define PIN_P0_TS_XP     0x04000000	// p0.26  ADC0.3  //xr==xp           
	#define PIN_P0_TS_YM     0x02000000	// p0.25  ADC0.2  //yd==ym
	#define PIN_P0_TS_XM     0x01000000	// p0.24  ADC0.1  //xl==xm
	#define PIN_P0_TS_YP     0x00800000	// p0.23  ADC0.0  //yu==yp 
// #else
// 	#define PIN_P0_TS_XM     0x04000000	// p0.26  ADC0.3  //xr==xp           
// 	#define PIN_P0_TS_YP     0x02000000	// p0.25  ADC0.2  //yd==ym
// 	#define PIN_P0_TS_XP     0x01000000	// p0.24  ADC0.1  //xl==xm
// 	#define PIN_P0_TS_YM     0x00800000	// p0.23  ADC0.0  //yu==yp 
// #endif
#define TS_XP_FUNC_GPIO()	{	PINSEL1 &= ~0x00300000;	} //SET PINS AS GPIO
#define TS_YM_FUNC_GPIO()	{	PINSEL1 &= ~0x000C0000;	}
#define TS_XM_FUNC_GPIO()	{	PINSEL1 &= ~0x00030000;	}
#define TS_YP_FUNC_GPIO()	{	PINSEL1 &= ~0x0000C000;	} //

#define TS_XP_FUNC_ADC()	{	PINSEL1 &= ~0x00200000;	PINSEL1 |= 0x00100000;	} //SET PINS AS GPIO
#define TS_YM_FUNC_ADC()	{	PINSEL1 &= ~0x00080000;	PINSEL1 |= 0x00040000;	}
#define TS_XM_FUNC_ADC()	{	PINSEL1 &= ~0x00020000;	PINSEL1 |= 0x00010000;	}
#define TS_YP_FUNC_ADC()	{	PINSEL1 &= ~0x00008000;	PINSEL1 |= 0x00004000;	} //

#define TS_XP_ADC_CHANNEL   (3)   // ADC0.3
#define TS_YM_ADC_CHANNEL   (2)   // ADC0.2
#define TS_XM_ADC_CHANNEL   (1)   // ADC0.1
#define TS_YP_ADC_CHANNEL   (0)   // ADC0.0
//////////// END OF USER MODIFIED SECTION////
#define DIR_IN_TS_XP_PIN()	{	FIO0DIR &= ~PIN_P0_TS_XP;	} //SET DIRECTION
#define DIR_OUT_TS_XP_PIN()	{	FIO0DIR |= PIN_P0_TS_XP;	}
#define DIR_IN_TS_YM_PIN()	{	FIO0DIR &= ~PIN_P0_TS_YM;	} //SET DIRECTION
#define DIR_OUT_TS_YM_PIN()	{	FIO0DIR |= PIN_P0_TS_YM;	}
#define DIR_IN_TS_XM_PIN()	{	FIO0DIR &= ~PIN_P0_TS_XM;	} //SET DIRECTION
#define DIR_OUT_TS_XM_PIN()	{	FIO0DIR |= PIN_P0_TS_XM;	}
#define DIR_IN_TS_YP_PIN()	{	FIO0DIR &= ~PIN_P0_TS_YP;	} //SET DIRECTION
#define DIR_OUT_TS_YP_PIN()	{	FIO0DIR |= PIN_P0_TS_YP;	}

#define B_TS_XP(x)	{	(x == SET) ? (FIO0SET |= PIN_P0_TS_XP) : (FIO0CLR |= PIN_P0_TS_XP);	}
#define B_TS_YM(x)	{	(x == SET) ? (FIO0SET |= PIN_P0_TS_YM) : (FIO0CLR |= PIN_P0_TS_YM);	}
#define B_TS_XM(x)	{	(x == SET) ? (FIO0SET |= PIN_P0_TS_XM) : (FIO0CLR |= PIN_P0_TS_XM);	}
#define B_TS_YP(x)	{	(x == SET) ? (FIO0SET |= PIN_P0_TS_YP) : (FIO0CLR |= PIN_P0_TS_YP);	}

///////////////////////////// END touch screen ////////////////
#define PIN_P0_LED_BLUE     		0x00000020	//led green

//#define P0_LED_BLUE_FUNC_GPIO()	{	PINSEL1 &= ~0x00300000;	} //SET PINS AS GPIO
#define DIR_OUT_LED_BLUE()		{FIO0DIR |= PIN_P0_LED_BLUE; }
#define DIR_IN_LED_BLUE()		{FIO0DIR &= ~PIN_P0_LED_BLUE;}
#define B_LED_BLUE(x)			{	(x == SET) ? (FIO0SET |= PIN_P0_LED_BLUE) : (FIO0CLR |= PIN_P0_LED_BLUE);	}

////////////////////////// for GSM Modem in NG //////////
#define PIN0_POWER_CONTROL	  0x00200000   // for RED LED  P0.21
#define DIR_POWER_CONTROL()		{FIO0DIR |= PIN0_POWER_CONTROL;}
#define GSMPOWER_CONTROL_HIGH()  			{DIR_POWER_CONTROL(); FIO0SET |= PIN0_POWER_CONTROL;}
#define GSMPOWER_CONTROL_LOW() 				{DIR_POWER_CONTROL(); FIO0CLR |= PIN0_POWER_CONTROL;}
//===================End Of GSM ============================

//======================  OUT1 & OUT 3 of Speaker ======================

#define PIN_SPEAKER_BUSY        0x00000080  //p2.7
#define PIN_SPEAKER_FULL        0x00000100  //p2.8

#define DIR_SPEAKER_PIN()			{PINSEL4 &= 0xFFFC3FFF; FIO2DIR |= PIN_SPEAKER_BUSY|PIN_SPEAKER_FULL; }


#define SET_SPEKER_BUSY()		{FIO2SET |= PIN_SPEAKER_BUSY ; }
#define CLR_SPEKER_BUSY()   	 {FIO2CLR |= PIN_SPEAKER_BUSY ; }
#define SET_SPEKER_FULL()      {FIO2SET |= PIN_SPEAKER_FULL  ;} 
#define CLR_SPEKER_FULL()		{FIO2CLR |= PIN_SPEAKER_FULL ;}


//========================================================================



