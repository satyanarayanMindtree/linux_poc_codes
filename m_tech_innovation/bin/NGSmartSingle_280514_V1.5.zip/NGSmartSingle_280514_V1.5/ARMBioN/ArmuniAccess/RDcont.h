
#define SL_EV_NO_EVENT			0
#define SL_EV_CARD_RECEIVED		1
#define SL_EV_DOTL_ALARM		2
#define SL_EV_FORCE_ALARM		3
#define SL_EV_ALARM_LOW			4
#define SL_EV_EGRESS			5
#define SL_EV_DOOR_NOT_OPENED	6
#define SL_EV_SLAVE_RESTART		7
#define SL_EV_TAMPER_HIGH		8
#define SL_EV_TAMPER_LOW		9
#define SL_EV_FIRE_HIGH			10
#define SL_EV_FIRE_LOW			11


#define SL_EV_ERROR				255

#define DR_NORMAL				0
#define DR_EGRESS_OPEN			1
#define DR_ACCESS_OPEN			2
#define DR_TZ_OPEN				3
#define DR_FIRE_OPEN			4
#define DR_USER_OPEN			5
#define DR_USER_CLOSE			6
#define DR_INTRUSION_CLOSE 		7   //F0011 Checking of Intrusion Alarm
#define DR_EXT_RLY_ON			8
#define DR_PC_NORMAL			9	  //ARMF2011
#define DR_PC_USER_OPEN			10	  //ARMF2011
#define DR_PC_USER_CLOSE 		11	  //ARMF2011

//#define DR_FORCE_OPEN_STATUS	10
//#define DR_DOTL_OPEN_STATUS	11




#define ENDI_INPUT_FIRE			0x01
#define ENDI_INPUT_TAMPER		0x02
#define ENDI_INPUT_INTRUSION	0x04
#define INPUT_AUX2				0x08
#define ENDI_INPUT_BATTERY		0x10   //ARMF2009
#define ENDI_INPUT_ACPOWER		0x20   //ARMF2009


/*
#define TAMPER_STATUS		DRStruct[0].FireTamper
#define FIRE_STATUS			DRStruct[1].FireTamper
#define INTRUSION_STATUS 	DRStruct[2].FireTamper
*/
extern unsigned char TAMPER_STATUS,FIRE_STATUS,INTRUSION_STATUS,BATTERY_STATUS,ACPOWER_STATUS;

#define MAX_PIN_READ_TIME_OUT		10

#define SL_RDR_LED_CONTROL		0
#define SL_RDR_BUZ_CONTROL		1
#define SL_RDR_DOTL_CONTROL		2


#define DOOR_CONT_1SEC_INTERRUPT(X){  		\
	if(DRStruct[X].RDOpTimer != 0)			\
		DRStruct[X].RDOpTimer--;			\
	if(DRStruct[X].RDDotlTimer != 0)		\
	{										\
		DRStruct[X].RDDotlTimer--;			\
		if(DRStruct[X].RDDotlTimer == 0)	\
			DRStruct[X].DRChkDOTL = SET;	\
	}                                   	\
	if(DRStruct[X].LastCardTimer != 0)		\
	{                 						\
		DRStruct[X].LastCardTimer--;      	\
		if(DRStruct[X].LastCardTimer == 0)	\
			DRStruct[X].DRLastCardChk = CLR;\
	}  								        \
}

	#ifdef BIO_METRIC
		#define NO_INPUT_VALUE	0x0035				//0000 0000 00110101
	#else
		#define NO_INPUT_VALUE	0x05D5				//0000 0101 11010101
	#endif

extern unsigned char InpChange,F_ChangeInInput;
extern unsigned int PrevInput,CurrentInput;
extern unsigned int olddata;


#define CHECK_SHARED_DOTL(_doorno)	((ReaderInfo[(_doorno/2)*2].SharedDOTL==SET)||(ReaderInfo[((_doorno/2)*2)+1].SharedDOTL==SET))
#define CHECK_FREE_TZ(_doorno)		((ReaderInfo[(_doorno/2)*2].FreeTZEnDis==SET)||(ReaderInfo[((_doorno/2)*2)+1].FreeTZEnDis==SET))


#define PROCESS_INPUT_DEBOUNCE_INTERRUPT()	{				\
			READ_INPUT(CurrentInput);						\
			if(InpChange == 1)								\
			{												\
				if(PrevInput  == CurrentInput)				\
				{											\
					PrevInput = CurrentInput;				\
					InpChange = 0;                    		\
               		CombinedIOInput = CurrentInput; 		\
					IOInput = CombinedIOInput & 0xFF;		\
					IOInput2 = CombinedIOInput / 0x100;		\
					F_ChangeInInput = 1;					\
				}											\
				else										\
				{											\
					PrevInput = CurrentInput;				\
					InpChange = 1; 							\
				}											\
			}												\
			else											\
			{												\
				if(PrevInput  != CurrentInput)				\
				{											\
					PrevInput = CurrentInput;				\
					InpChange = 1; 							\
				}											\
			    else if(CurrentInput != CombinedIOInput)	\
				{ PrevInput = CombinedIOInput;				\
				}											\
			}												\
}

__packed struct READER_STRUCT
{
	unsigned char DOpTime;		//door open time
   	unsigned char DOTLTime;		//door too long	time
   	unsigned char DOTLEn_Dis;	//
   	unsigned char SharedDOTL;
   	unsigned char FacCheck;		// Facility code check
	unsigned char FreeTZEnDis;		// Free Time Zone ENdis
   	unsigned char FreeTZ;			// Free time zone
   	unsigned char PinEnDis;       // Pin Prox enable disable
   	unsigned char APBEnDis;
   	unsigned char RDInOut;			//REader is in or out reader
   	unsigned char AreaNoFrom;			//From Area  Number
   	unsigned char AreaNoTo;			//To Area Number
   	unsigned char DoorNo;    		// Door number which corrosponds to this Reader
	unsigned char SlaveContNo;    // reader is connected to which controller number if controller number is zero then this is connected to rabbit
	unsigned char DeadManZoneEnDis;      //reader wise dead man zone enable/disable.
    unsigned short DMZ_Time;//DMZ time in minutes.//till here 16 Bytes use
	unsigned char DulUsrAth_Rdr;//reader wise duel user auth en/dis.
	unsigned char FirstInUserRule; //reader wise First In User Rule en/dis.
	unsigned char DontDisturb;//reader wise dont disturb enable/disable
	unsigned char DNDTZ;//do not disturb time zone. presently not used.//22 Bytes
	unsigned char DISGrp;		  //DoorInterlock Grp No. 	//ARMF2001: //Implement DIS
	unsigned char CntrolrType;
};
__packed struct SPLCRDFLAG_STRUCT 
{
	unsigned char FirstInUser[64];		//reader wise First in user flag.//first in user owner flag.
	unsigned char DNDCFlag;				//Do not Disturb card flag,toggled.  1 = unit in Do not Disturb mode,0 = not in DNC mode.
	unsigned char DNDZoneFlag;			//Do not Disturb zone flag,toggled.  1 = unit in Do not Disturb mode,0 = not in DNZ mode. 
};

__packed struct CARD_DATA_POLL
{
	unsigned long CardNo;
	unsigned char FCode;
	unsigned char Status;
	unsigned char Door;
};


__packed struct DOOR_CONTROL
{
	unsigned long LastCardNo;
	unsigned int  CardPointer;
	unsigned char FCode;
	unsigned char RDOpTimer;
	unsigned char RDDotlTimer;
	unsigned char DRStatus;		// Normal, AccessOpen, TimeZoneOpen,UserOpen,UserClose,EgressOpen,ForceOpen,FireOpen
	unsigned char ShRdNo;		// this is used for storing reader no in case of shared door case.
	unsigned char DRMCStatus;
	unsigned char DREgressStatus;
	unsigned char Dotl_Alarm;
	unsigned char Force_Alarm;
	unsigned char DRCurrentStatus;
	unsigned char DRChkDOTL;		//Check Dotl Alarm status flag to differenciate DOTL alarm and Fore open alarm
	unsigned char DROpenedChk;	// To check if door is opened after Card door open or egress door open
//	unsigned char FireTamper;
//	unsigned char IntrusionInput;        //F0014
	unsigned char LastCardTimer;
	unsigned char DRLastCardChk;		//Flag to check same card on respective reader
	unsigned char DRControlRdrData;		//Update door control for Reader
	unsigned char SoundType;
	unsigned char SoundTimer;
	unsigned char F_BuzzerOn;
	unsigned char EVENT_DOTL;		// Event based DOTL for Different door
    unsigned char EventOpenTime;		// Time Assigned for DOTL
    unsigned char EventOpenTimeCheck:1 ;		// Time Assigned for DOTL
    unsigned char EventDotlTime;		// Time Assigned for DOTL
	unsigned char ResetAlarm;
};

__packed struct DOOR_ALARM_STATUS
{
	unsigned char DOTLAlarm;
	unsigned char ForceAlarm;
	unsigned char ALDOTLReset;
};

__packed struct READERDATA_STRUCT
{
	unsigned int Pin;
	unsigned char CPin;
	unsigned char PinCount;
	unsigned char PinTimeOut;
	unsigned char F_PinRec;
	CARDNO_DATA_STORAGE_TYPE CardNo;
	unsigned char WCount;
	unsigned long WeigandData;
	unsigned char WeigandExData;
	unsigned char FacCode;
	unsigned char WeigandTimeOut;
	unsigned char F_WeigandStarted;
	unsigned char F_WeigandInterrupt;
	unsigned char F_CardFound;
	unsigned char F_ParityError;
};
extern __packed struct READERDATA_STRUCT ReaderData[MAX_LOCAL_READER];	// Check if this is required for 4DR Controller
__packed struct TRNSCARD_DATA_STRUCT
{
	unsigned char WCount;
	unsigned long WeigandData;
	unsigned char WeigandExData;
};
extern __packed struct TRNSCARD_DATA_STRUCT TransparentCardData;	// 
extern unsigned char AlarmGenerateFlg[40];	//Shivraj
extern unsigned char AlarmACKFlg[40];		//Shivraj

extern __packed struct READER_STRUCT ReaderInfo[MAX_READERS_SUPPORT*2];    // Added to avoid any memory overwrite as this also contains code of 8 door :-(
extern __packed struct DOOR_CONTROL DRStruct[MAX_LOCAL_DOORS+1];			// To avoid memory overwrite 
extern __packed struct DOOR_ALARM_STATUS DoorAlStatus[MAX_LOCAL_DOORS*2];
extern __packed struct SPLCRDFLAG_STRUCT SplCrdFlag;

extern void HandelDoorControlInputs(unsigned char drno);
extern char DoorConditionControl(unsigned char drno,unsigned char opentype,unsigned char time,unsigned char dotltime);
extern void InitialiseDrData(void);
#ifdef SUPPORT_NSERIES2
//extern void DoorInterlockIndicator(unsigned char doorno);
//extern unsigned char DoorInterlockCheck(unsigned char doorno);
#endif
extern unsigned char IOInput;			// This stores final Input after debounce for Input group 1
extern unsigned int CombinedIOInput;
extern unsigned char IOInput2;			// This stores final Input after debounce for Input group 2
extern unsigned char F_SendFireClose,F_RdrOtherSendCommand;
extern unsigned char WeigandOutLEdStatus;	//NGD00077



