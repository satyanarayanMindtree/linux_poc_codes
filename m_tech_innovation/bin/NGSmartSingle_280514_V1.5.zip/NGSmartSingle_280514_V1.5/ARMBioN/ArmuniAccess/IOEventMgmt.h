#ifndef __IOEVENT_H
#define __IOEVENT_H


#define EV_IOCONTROL_ON_IO1				0x0001
#define EV_EMAIL_PATTERN				0x0F00
#define GET_EMAIL_ID(X,Y)				{  X=((IOEventInfo[Y] & EV_EMAIL_PATTERN)/0x100)& 0x000F;   }
/*
#define EV_IOCONTROL_STORE_TRANS		0x0002
#define EV_IOCONTROL_SEND_UDP			0x0004
#define EV_IOCONTROL_DISPLAY			0x0008
#define EV_IOCONTROL_BUZZER_TYPE    0x0030
#define EV_IOCONTROL_ON_SMS         0x0040
#define EV_IOCONTROL_DUMMY         	0x0080
#define EV_IOCONTROL_ON_EXIO        0x0700
*/


#define OP_ON		1
#define OP_OFF		0
#define OP_NOTMAL_CONTROL	1
#define OP_TIMER_CONTROL	2
#define MAX_OUTPUT			8


extern unsigned char GenerateEvent(unsigned char eventno,unsigned char channel);
#define MAX_EVENT_IO		255
extern __packed unsigned short IOEventInfo[MAX_EVENT_IO+1];

#endif
