/*****************************************************************************
 *   rtc.c:  Realtime clock C file for NXP LPC23xx/34xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.12  ver 1.00    Prelimnary version, first Release
 *
*****************************************************************************/
#include "LPC23xx.H"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "type.h"
#include "irq.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "portlcd.h"
#include <string.h>

const char WEEK_DAY[7][4] = {
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat",
};
extern BYTE CWeekDay;
extern SYSInfo SysInfo;
volatile DWORD alarm_on = 0;

/*****************************************************************************
** Function name:		RTCHandler
**
** Descriptions:		RTC interrupt handler, it executes based on the
**				the alarm setting
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void RTCHandler (void) __irq 
{  
  RTC_ILR |= ILR_RTCCIF;		/* clear interrupt flag */
  IENABLE;			/* handles nested interrupt */

  alarm_on = 1;

  IDISABLE;
  VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		RTCInit
**
** Descriptions:		Initialize RTC timer
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void RTCInit(void)
{
  alarm_on = 0;

  /*--- Initialize registers ---*/    
  RTC_AMR = 0;
  RTC_CIIR = 0;
  RTC_CCR = CCR_CLKSRC;		//clock source from 32.7k external crystal 00 APB Bus
//  RTC_PREINT = PREINT_RTC;  this seting is used for APB CLK dividing for RTC CLK.
//  RTC_PREFRAC = PREFRAC_RTC;
//  if ( install_irq( RTC_INT, (void *)RTCHandler, HIGHEST_PRIORITY ) == FALSE )
//  {
//	while ( 1 );		/* very bad happened */
//  }
  return;
}

/*****************************************************************************
** Function name:		RTCStart
**
** Descriptions:		Start RTC timer
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void RTCStart( void ) 
{
  /*--- Start RTC counters ---*/
  RTC_CCR |= CCR_CLKEN;
  RTC_ILR = ILR_RTCCIF;
  return;
}

/*****************************************************************************
** Function name:		RTCStop
**
** Descriptions:		Stop RTC timer
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void RTCStop( void )
{   
  /*--- Stop RTC counters ---*/
  RTC_CCR &= ~CCR_CLKEN;
  return;
} 

/*****************************************************************************
** Function name:		RTC_CTCReset
**
** Descriptions:		Reset RTC clock tick counter
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void RTC_CTCReset( void )
{   
  /*--- Reset CTC ---*/
  RTC_CCR |= CCR_CTCRST;
  return;
}

/*****************************************************************************
** Function name:		RTCSetTime
**
** Descriptions:		Setup RTC timer value
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void SetRTCTimeDate( RTCTime timedate,BYTE weekday ) 
{
	BYTE tempweekday ;
  RTC_SEC = timedate.Time.Secs;
  RTC_MIN = timedate.Time.Min;
  RTC_HOUR = timedate.Time.Hour;
  RTC_DOM = timedate.Date.Day;
  RTC_DOW = weekday;
  RTC_DOY = 365;	   ///check this in datasheet
  RTC_MONTH = timedate.Date.Month;
  RTC_YEAR = timedate.Date.Year;    
	Datetime = RTCGetTime();	//ARMD0214	
	tempweekday = GetWeekDay(CurrentTimeInt);//ARMD0214
	if(tempweekday != weekday)		    
	{
		CWeekDay=tempweekday;
		RTC_DOW=CWeekDay;
	}
  return;
}

/*****************************************************************************
** Function name:		RTCSetAlarm
**
** Descriptions:		Initialize RTC timer
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void RTCSetAlarm( RTCTime Alarm ) 
{   
/*  RTC_ALSEC = Alarm.RTC_Sec;
  RTC_ALMIN = Alarm.RTC_Min;
  RTC_ALHOUR = Alarm.RTC_Hour;
  RTC_ALDOM = Alarm.RTC_Mday;
  RTC_ALDOW = Alarm.RTC_Wday;
  RTC_ALDOY = Alarm.RTC_Yday;
  RTC_ALMON = Alarm.RTC_Mon;
  RTC_ALYEAR = Alarm.RTC_Year;    
*/
  return;
}

/*****************************************************************************
** Function name:		RTCGetTime
**
** Descriptions:		Get RTC timer value
**
** parameters:			None
** Returned value:		The data structure of the RTC time table
** 
*****************************************************************************/
RTCTime RTCGetTime( void ) 
{	
RTCTime LocalTime;
//unsigned char weekday;	

	if(CurrentTimeDt.tm_min != RTC_MIN)
		F_OneMinute = SET;
	if(CurrentTimeDt.tm_hour != RTC_HOUR)
		F_OneHour = SET;
	if(CurrentTimeDt.tm_mday != RTC_DOM)	
		F_OneDay = SET;

  	CurrentTimeDt.tm_sec  = LocalTime.Time.Secs = RTC_SEC;
  	CurrentTimeDt.tm_min  = LocalTime.Time.Min  = RTC_MIN;
  	CurrentTimeDt.tm_hour = LocalTime.Time.Hour = RTC_HOUR;
  	CurrentTimeDt.tm_mday = LocalTime.Date.Day  = RTC_DOM;
  	CurrentTimeDt.tm_wday = CWeekDay 		    = RTC_DOW;
 // LocalTime.RTC_Yday = RTC_DOY;

  	CurrentTimeDt.tm_mon  = LocalTime.Date.Month= RTC_MONTH;
  	LocalTime.Date.Year = RTC_YEAR;
	CurrentTimeDt.tm_year = YEAR_BASE_VALUE + LocalTime.Date.Year;
	CurrentTimeInt = mktime(&CurrentTimeDt);
  	return(LocalTime);    
}

/*****************************************************************************
** Function name:		RTCSetAlarmMask
**
** Descriptions:		Set RTC timer alarm mask
**
** parameters:			Alarm mask setting
** Returned value:		None
** 
*****************************************************************************/
void RTCSetAlarmMask( DWORD AlarmMask ) 
{
  /*--- Set alarm mask ---*/    
  RTC_AMR = AlarmMask;
  return;
}


// Source is taken from following site :-)
//http://prepatsi.monge.free.fr/robotique_privee/TIPE_asservissement/asservissement/asservissement_microb/zer0.droids-corp.org/doxygen/html/time_8h-source.html
//http://prepatsi.monge.free.fr/robotique_privee/TIPE_asservissement/asservissement/asservissement_microb/zer0.droids-corp.org/doxygen/html/time_8c-source.html
// time test site
//http://dan.drydog.com/unixdatetime.html

static struct tm lastTime;

/* convert calendar time (seconds since 1970) to broken-time
   This only works for dates between 01-01-1970 00:00:00 and 
   19-01-2038 03:14:07
   A leap year is ((((year%4)==0) && ((year%100)!=0)) || ((year%400)==0)) 
   but since we have no fancy years between 1970 and 2038 we can do:
*/

#define LEAP_YEAR(year) ((year%4)==0)
//#define LEAPYEAR(year)          (!((year) % 4) && (((year) % 100) || !((year) % 400)))

// convert broken time to calendar time (seconds since 1970)

static const char monthDays[]={31,28,31,30,31,30,31,31,30,31,30,31};

// validate the tm structure
static void CheckTime(struct tm *timeptr) 
{
    // we could do some normalization here, e.g.
    // change 40 october to 9 november
    if (timeptr->tm_sec>59) timeptr->tm_sec=59;
    if (timeptr->tm_min>59) timeptr->tm_min=59;
    if (timeptr->tm_hour>23) timeptr->tm_hour=23;
    if (timeptr->tm_wday>6) timeptr->tm_wday=6;
    if (timeptr->tm_mday<1) timeptr->tm_mday=1;
    	else if (timeptr->tm_mday>31) timeptr->tm_mday=31;
    if (timeptr->tm_mon>11) timeptr->tm_mon=11;
    if (timeptr->tm_year<0) timeptr->tm_year=0;
}

time_t mktime(struct tm *timeptr) 
{
int year,month, i;
long seconds;
	
	year=timeptr->tm_year	;/*PANKAJ+1900*/
	month=timeptr->tm_mon -1;
	CheckTime(timeptr);
// seconds from 1970 till 1 jan 00:00:00 this year	
	seconds= (year-1970)*(60*60*24L*365);

// add extra days for leap years
	for (i=1970; i<year; i++) 
	{
		if (LEAP_YEAR(i)) 
       		seconds+= 60*60*24L;
   	}
    // add days for this year
    for (i=0; i<month; i++) 
	{
      	if (i==1 && LEAP_YEAR(year)) 
	  	{ 
        	seconds+= 60*60*24L*29;
      	} 
	  	else 
	  	{
        	seconds+= 60*60*24L*monthDays[i];
      	}
    }
    seconds+= (timeptr->tm_mday-1)*60*60*24L;
    seconds+= timeptr->tm_hour*60*60;
    seconds+= timeptr->tm_min*60;
    seconds+= timeptr->tm_sec;
    return (seconds);
}

struct tm *gmtime_r(const time_t *timep, struct tm *gettime) 
{
unsigned long epoch=*timep;
unsigned int year;
unsigned char month, monthLength;
unsigned long days;

	lastTime.tm_sec=epoch%60;
	epoch/=60; // now it is minutes
	lastTime.tm_min=epoch%60;
	epoch/=60; // now it is hours
	lastTime.tm_hour=epoch%24;
	epoch/=24; // now it is days
	lastTime.tm_wday=(epoch+4)%7;
	
	year=1970;
	days=0;
	while((days += (LEAP_YEAR(year) ? 366 : 365)) <= epoch) 
	{
	  	year++;
	}
	lastTime.tm_year=year;			/// PANKAJ year-1900;	
	days -= LEAP_YEAR(year) ? 366 : 365;
	epoch -= days; // now it is days in this year, starting at 0
	lastTime.tm_yday=epoch;	
	days=0;
	month=0;
	monthLength=0;
	for (month=0; month<12; month++) {
		if (month==1) { // februari
		  	if (LEAP_YEAR(year)) 
		  	{
		      	monthLength=29;
		  	} 
			else 
		  	{
		      	monthLength=28;
		 	}
		} 
		else 
	  	{
	    	monthLength = monthDays[month];
	  	}	  
	  	if (epoch>=monthLength) 
		{
	    	epoch-=monthLength;
	  	} 
		else 
		{
	      break;
	  	}
	}
	lastTime.tm_mon=month+1;
	lastTime.tm_mday=epoch+1;	
	lastTime.tm_isdst=0;
	memcpy((char*)gettime,(char*)&lastTime,sizeof(lastTime));
	return (&lastTime);
}



unsigned char GetWeekDay(time_t epoch) 
{
	epoch/=60; // now it is minutes
	epoch/=60; // now it is hours
	epoch/=24; // now it is days
	return( (epoch+4)%7);
}

/*****************************************************************************
**                            End Of File
******************************************************************************/

