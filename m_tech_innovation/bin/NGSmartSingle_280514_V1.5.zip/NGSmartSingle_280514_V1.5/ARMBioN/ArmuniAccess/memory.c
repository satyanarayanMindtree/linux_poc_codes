#include <string.h>
#include "LPC23xx.h"			/* LPC23xx/24xx Peripheral Registers	*/
#include "version.h"  
#include "config.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "tranxmgmt.h"
#include "spi.h"
#include "Access.h"  
#include "memory.h"
#include "serial.h"
#include "cardmgmt.h"
#include "memmap.h"
#include "rdcont.h"  
#include "IOEventMgmt.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "userintf.h"  
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "portlcd.h"  
#include <absacc.h>
#include "userIntfGLCD.h"

extern DWORD CARD_DATA_BASE; 
extern SYSInfo SysInfo;
extern struct DOOR_INFO Doorinfo;
extern _TRANSData UExTrnxData;

//int TransReadPtr,TransWritePtr,TotalNosOfTrans,TotalCards;
//=================================================================================================================================================
void IniBatteryVariables(void)
{
	
}
void PrintAccessMemMap(void)
{
		MsgPrint(MSG_MEM,SF_BLOCKS,"# of blocks in flash: ");
		MsgPrint(MSG_MEM,SF_BLOCKSIZE,"# size of block: ");
    	MsgPrint(MSG_MEM,TRANS_DATA_BASE ,"TRANSACTION BASE PAGE ADD \n");
   		 MsgPrint(MSG_MEM,sizeof(struct TRNX_DATA),"TRANSACTION SIZE ");
		MsgPrint(MSG_MEM,APP_DATA_SIZE,"TRANSACTION SIZE APP_DATA_SIZE");
		MsgPrint(MSG_MEM,MAX_TRANS ,"MAX NO OF TRANS  ");
		MsgPrint(MSG_MEM,MAX_TRANS/(PAGE_SIZE / APP_DATA_SIZE),"TOTAL PAGES ");
   		 MsgPrint(MSG_MEM,FL_CARDDATA_PAGE_NO,"CARD BASE PAGE ");
		MsgPrint(MSG_MEM,sizeof(struct CARD_DATA),"CARD SIZE" );
		MsgPrint(MSG_MEM,MAX_NO_OF_CARD,"TOTAL CARD ");
		MsgPrint(MSG_MEM,(sizeof(struct CARD_DATA)*MAX_NO_OF_CARD)/PAGE_SIZE,"TOTAL PAGES ");
    	MsgPrint(MSG_MEM,sizeof(SysInfo),"SYS_INFO ");
    	MsgPrint(MSG_MEM,0,"PrintAccessMemMap");
		MsgPrint(MSG_MEM,MAX_NO_OF_CARD,"MaxCards = ");
		MsgPrint(MSG_MEM,MAX_TRANS,"MAxTrans = ");
}

//=================================================================================================================================================
unsigned char WriteSysInfoToFlash(void)
{
//   unsigned char i,*infoptr;
    MainMem_BuffWrt(0,1,(BYTE *)&SysInfo,sizeof(SysInfo) );
	BuffWrt_MainMem(FL_SYSINFO_PAGE,1);
//    infoptr = (BYTE *) &SysInfo;
    MsgPrint(MSG_MEM,0," CopySysInfoToFlash \n");
	
//	for(i=0;i<sizeof(SysInfo);i++)
//  	printf("%x ",infoptr[i]);
//	printf("\n");

	MsgPrint(MSG_MEM,sizeof(SysInfo),"WriteSysInfoToFlash ");
		return(0);

}
/*--------------------------------------------------------------------------*/


unsigned char ReadSysInfoFromFlash(void)
{
//	unsigned char i,*infoptr;
   	
	
 	MainMem_ReadPage(FL_SYSINFO_PAGE,0,(BYTE *)&SysInfo,sizeof(SysInfo));
//	infoptr = (BYTE *) &SysInfo;
	MsgPrint(MSG_MEM,0," CopyFlashToSysInfo \n");
	MsgPrint(MSG_MEM,sizeof(SysInfo),"ReadSysInfoFromFlash ");
	return(0);
}

//=================================================================================================================================================

unsigned char WriteDoorInfoToFlash(void)
{
//	unsigned char i;
    memcpy (tempwrbuf, (char *)&Doorinfo, sizeof(Doorinfo));			
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,sizeof(Doorinfo));
    BuffWrt_MainMem(FL_DOORINFO_PAGE,1);
    MsgPrint(MSG_MEM,sizeof(Doorinfo)," WriteDoorInfoToFlash \n");
		
	return(0);
}
/*--------------------------------------------------------------------------*/

unsigned char ReadDoorInfoFromFlash(void)
{
//	unsigned char *infoptr;
    MainMem_ReadPage(FL_DOORINFO_PAGE,0,(BYTE *)&Doorinfo,sizeof(Doorinfo));
//    infoptr = (BYTE *)&Doorinfo;
	MsgPrint(MSG_MEM,FL_DOORINFO_PAGE," ReadDoorInfoFromFlash \n");
//	for(i=0;i<sizeof(Doorinfo);i++)
//   	MsgPrint(MSG_MEM,infoptr[i],"Door Info Page  ");
	return(0);
}


/* to reduce size
unsigned char WriteCardDataToFlash1(unsigned int cardpos)
{
//	unsigned char i,*infoptr;
//   unsigned char tempwrbuf[SPIBUFSIZE];
int cardpage;
long memptr;

   cardpage = (int)((long)((long)cardpos * (long) CARD_DATA_BYTES)  /PAGE_SIZE);
   memptr = (long)((long)(cardpos) %  PAGE_SIZE);
   
   MainMem_BuffWrt(0,1,(BYTE *)memptr,PAGE_SIZE );
   BuffWrt_MainMem(FL_CARDDATA_PAGE_NO+cardpage,1);	  
//   xmem2root(tempwrbuf,memptr,256);
//	sf_writeRAM(tempwrbuf,0,256);				     
//   sf_RAMToPage(FL_CARDDATA_PAGE_NO+cardpage);

   memptr = (long)CARD_DATA_BASE+(long)((long)(cardpage+1)*PAGE_SIZE);
   MainMem_BuffWrt(0,1,(BYTE *)memptr,PAGE_SIZE );
   BuffWrt_MainMem(FL_CARDDATA_PAGE_NO+(cardpage+1),1);
//   xmem2root(tempwrbuf,memptr,256);
//   sf_writeRAM(tempwrbuf,0,256);
//   sf_RAMToPage((long)FL_CARDDATA_PAGE_NO + (long)(cardpage+1) );


//	printf(" WriteCardDataToFlash cardpos %d  Ram Page No %d Flash Page no %d   \n",cardpos,cardpage,FL_CARDDATA_PAGE_NO+cardpage);
	MsgPrint(MSG_MEM,cardpos,"WriteCardDataToFlash pos= ");
	MsgPrint(MSG_MEM,cardpage,"WriteCardDataToFlash: RamPage= ");
	MsgPrint(MSG_MEM,cardpage+FL_CARDDATA_PAGE_NO,"WriteCardDataToFlash: FlashPage= ");
	
	return(0);
} */

/*
unsigned char WriteAllCardDataToFlash(void)
{
unsigned int cardmaxflashpage,i;
// 	unsigned char tempwrbuf[256];
unsigned long memptr;
 	cardmaxflashpage = (MAX_NO_OF_CARD * CARD_DATA_BYTES)/PAGE_SIZE;
  	for(i=0;i<cardmaxflashpage;i++)
   	{
   		memptr = CARD_DATA_BASE+(i * PAGE_SIZE) ;
		MainMem_BuffWrt(0,1,(BYTE *)memptr,PAGE_SIZE );
    	BuffWrt_MainMem(FL_CARDDATA_PAGE_NO+i,1);	

//  xmem2root(tempwrbuf,memptr,256);
//		sf_writeRAM(tempwrbuf,0,256);
//	   sf_RAMToPage(FL_CARDDATA_PAGE_NO+i);
   }
	MsgPrint(MSG_MEM,0,"WriteAllCardDataToFlash ");
		return(0);
}	   */

/*--------------------------------------------------------------------------*/
  //this function is can not be used as  internal  ram is not avaliable 
void ReadAllCardDataFromFlash(void)
{
unsigned int cardmaxflashpage,i,temp2;
// 	unsigned char WritePage[PAGE_SIZE];		
//   unsigned long memptr;
   cardmaxflashpage = ( MAX_NO_OF_CARD * CARD_DATA_BYTES)/PAGE_SIZE;
	for(i=0;i<cardmaxflashpage;i++)
	{  	MsgPrint(MSG_MEM,i,"Card Data Page No ");
		MainMem_ReadPage(FL_CARDDATA_PAGE_NO+i,0,(BYTE* )&tempwrbuf,PAGE_SIZE);
			for(temp2 = 0;temp2<sizeof(tempwrbuf);temp2++)
  				MsgPrint(MSG_MEM,tempwrbuf[temp2],"Card Data ");

	
   }
	MsgPrint(MSG_MEM,0,"ReadAllCardDataFromFlash ");
}

/*--------------------------------------------------------------------------*/

// This is to calculate check sum for card data in flash .. this is just a addition of data as integer..
// this is different than char addition

unsigned long GetFlashCardDataChkSum(void)
{
unsigned int cardmaxflashpage,i,*chkint,j;
// 	unsigned char tempwrbuf[PAGE_SIZE];
//   unsigned long memptr;
   unsigned long chksum;
   chksum =CHK_SUM_MOD_VALUE;
   cardmaxflashpage = ((long) MAX_NO_OF_CARD * (long) CARD_DATA_BYTES)/(long)PAGE_SIZE;
	for(i=0;i<cardmaxflashpage;i++)
	{
   		MainMem_ReadPage(FL_CARDDATA_PAGE_NO+i,0,(BYTE *)&tempwrbuf,sizeof(tempwrbuf));
	    chkint = (unsigned int *)tempwrbuf;  // need to check as now we have page of big size compared to rabbit
		for(j=0;j<128;j++)
      	chksum = chksum + chkint[j];
    }
//	MsgPrint(MSG_MEM,chksum,"GetFlashCardDataChkSum chksum =");
   return(chksum);
}

// Following function is used to calculate the checksum of ram data it takes pointer and size of data as input
// this is just a addition of char values.. and initially we add CHK_SUM_MOD_VALUE

//=================================================================================================================================================
unsigned int GetCheckSum(unsigned char *datastr,unsigned int datasize)
{
unsigned int chksum,i;
	chksum = CHK_SUM_MOD_VALUE;
	for(i=0;i<datasize;i++)
		chksum = chksum + datastr[i];
	return(chksum);
}



/*--------------------------------------------------------------------------*/

void TimeZoneBackup(void)
{
 //unsigned char i;
 //unsigned char WritePage[SPIBUFSIZE];
 /* 8 Pages are used from flash for timezone storing.*/
/*         for(i=0;i<8;i++)
         {  //xmem2root(WritePage,TIME_ZONE_BASE+(i*256),256);
         	//sf_writeRAM(WritePage, 0, 256);
            //sf_RAMToPage(TIME_ZONE_PAGE+i);
          }
  */
}
/*--------------------------------------------------------------------------*/	 /*
void TimeZoneRestore(void)
{ 

 unsigned char i;
 unsigned char WritePage[SPIBUFSIZE];
   8 Pages are used from flash for timezone storing.
         for(i=0;i<8;i++)
         { // sf_pageToRAM(TIME_ZONE_PAGE+i);
            //sf_readRAM(WritePage, 0, 256);
            //root2xmem(TIME_ZONE_BASE+(i*256),WritePage,256);
         }

}		    */
/*--------------------------------------------------------------------------*/
/*
Following function is to get time zone from Flash to time zone structure.
*/

int GetTimeZone(unsigned char tzno,_TIMEZONE *timez)
{
//   	unsigned char tempwrbuf[PAGE_SIZE];
	unsigned int tzpageno,tzpageoffset;
	if(MAX_TIME_ZONE<tzno)
		return(-1);
   	tzpageno  = FL_TIME_ZONE_PAGE + (tzno/ MAX_TZ_PER_PAGE);
	tzpageoffset = (tzno%MAX_TZ_PER_PAGE) * TIME_ZONE_BYTES;
	MainMem_ReadPage(tzpageno,0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy((char *)timez,&tempwrbuf[tzpageoffset],TIME_ZONE_BYTES);		
//	DisplayFlashpage(FL_TIME_ZONE_PAGE+ptr);
	return(0);	

}

/*
	
	
   	tzpageno  = tzno/ MAX_TZ_PER_PAGE;

	tzpageoffset = (tzno%MAX_TZ_PER_PAGE) * TIME_ZONE_BYTES;

*/
//=================================================================================================================================================
int SaveTimeZone(unsigned char tzno,_TIMEZONE *timez)
{
//   	unsigned char tempwrbuf[PAGE_SIZE];
	unsigned int tzpageno,tzpageoffset;

	if(MAX_TIME_ZONE<tzno)
		return(-1);
   	tzpageno  = FL_TIME_ZONE_PAGE + (tzno/ MAX_TZ_PER_PAGE);
	tzpageoffset = (tzno%MAX_TZ_PER_PAGE) * TIME_ZONE_BYTES;
	MainMem_ReadPage(tzpageno,0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy(&tempwrbuf[tzpageoffset],(char *)timez,TIME_ZONE_BYTES);		
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,PAGE_SIZE);
    BuffWrt_MainMem(tzpageno,1);	
//	DisplayFlashpage(FL_TIME_ZONE_PAGE+ptr);
	return(0);
}

/*--------------------------------------------------------------------------*/

void xmem2root(BYTE *data,BYTE *buffer,short Length)
{ 
	short i;
  	for ( i = 0; i < Length; i++ )
  	{
		*data = *buffer;
		data++;
		buffer++;
  	}
}


/*--------------------------------------------------------------------------*/

unsigned char DisplayFlashpage(BYTE pageno)
{
	unsigned int i;
//	unsigned char tempwrbuf[SPIBUFSIZE];
    MainMem_ReadPage(pageno,0,(BYTE *)tempwrbuf,sizeof(tempwrbuf));
	MsgPrint(MSG_MEM,pageno," FlashPage No \n");
//   	MsgPrint(MSG_MEM,temp[i],"Flash Data ");
	for(i=0;i<sizeof(tempwrbuf);i++)
	{
		SendAsciiToPC(tempwrbuf[i]);
		TransmitChar(' ');		
	}
	TransmitChar('\n');		
	return(0);				 
}									   


/*--------------------------------------------------------------------------*/
unsigned char WriteModelInfoToFlash(void)
{
    MainMem_BuffWrt(0,1,(BYTE *)&ModelInfo,sizeof(ModelInfo));
	BuffWrt_MainMem(FL_MODEL_SERIAL_NO,1);
	MsgPrint(MSG_MEM,0,"WriteModelInfoToFlash");
	return(0);

}

/*--------------------------------------------------------------------------*/
unsigned char ReadModelInfoFromFlash(void)
{
 	MainMem_ReadPage(FL_MODEL_SERIAL_NO,0,(BYTE *)&ModelInfo,sizeof(ModelInfo));
	MsgPrint(MSG_MEM,0,"ReadModelInfoFromFlash ");
	return(0);
}

/*--------------------------------------------------------------------------*/
/*** BeginHeader ReadReaderInfoFromFlash*/
unsigned char ReadReaderInfoFromFlash(void);    //FA00076 Door setting by reader info command same as 4DR 4RD.
/*** EndHeader */
unsigned char ReadReaderInfoFromFlash(void)
{
    MainMem_ReadPage(FL_NEWREADER_INFO_PAGE_NO,0,(BYTE *)&ReaderInfo,sizeof(ReaderInfo));
	MsgPrint(MSG_MEM,FL_DOORINFO_PAGE," ReadDoorInfoFromFlash \n");
	return(0);
}
//=================================================================================================================================================
/*** BeginHeader WriteDefaultReaderInfo*/
unsigned char WriteDefaultReaderInfo(void);
/*** EndHeader */
unsigned char WriteDefaultReaderInfo(void)
{
unsigned char rdno;
	if( !(InitialiseFlags & DELETE_ALL_DEF_READER_INFO) )	//ARMF0377
		return 0;			
	InitialiseFlags &= ~DELETE_ALL_DEF_READER_INFO;
	for(rdno=0;rdno<MAX_READERS_SUPPORT;rdno++)		 
	{
		ReaderInfo[rdno].DOpTime = 5;
		ReaderInfo[rdno].DOTLTime = 6;
		ReaderInfo[rdno].DOTLEn_Dis = 1;
#ifdef SUPPORT_ONLY_2_DOOR
	//#ifdef BIOLITE_HARDWARE		
		ReaderInfo[rdno].SharedDOTL = SET; //ARMD0307
	//#else
	//	ReaderInfo[rdno].SharedDOTL = CLR;
	//#endif
#else
		ReaderInfo[rdno].SharedDOTL = 1;
#endif
		ReaderInfo[rdno].FacCheck = 1;
		ReaderInfo[rdno].FreeTZEnDis = 0;
		ReaderInfo[rdno].FreeTZ = 7;
		ReaderInfo[rdno].PinEnDis = 0;
		ReaderInfo[rdno].APBEnDis = 0;
        if(rdno%2)
			ReaderInfo[rdno].RDInOut= 2;
		else
			ReaderInfo[rdno].RDInOut = 1;
		ReaderInfo[rdno].AreaNoFrom = 1;
		ReaderInfo[rdno].AreaNoTo = 2;

		ReaderInfo[rdno].DeadManZoneEnDis = 0;
		ReaderInfo[rdno].DMZ_Time = 10;
//		ReaderInfo[rdno].DulUsrAth_Rdr = 0;
//		ReaderInfo[rdno].FirstInUserRule = 0;
//		ReaderInfo[rdno].DontDisturb = 0;
//		ReaderInfo[rdno].DISGrp = 0;
		ReaderInfo[rdno].DNDTZ = 0;
   }
	SplCrdFlag.DNDCFlag = 0;
	SplCrdFlag.DNDZoneFlag = 0;
	memset(SplCrdFlag.FirstInUser,0,sizeof(SplCrdFlag.FirstInUser)) ;
#ifdef SUPPORT_ONLY_2_DOOR			
   	ReaderInfo[0].SlaveContNo = 1;
	ReaderInfo[0].DoorNo = 1;
   	ReaderInfo[1].SlaveContNo = 1;
	ReaderInfo[1].DoorNo = 2;
   	ReaderInfo[2].SlaveContNo = 2;
	ReaderInfo[2].DoorNo = 3;
   	ReaderInfo[3].SlaveContNo = 2;
	ReaderInfo[2].DoorNo = 4;
#endif
	WriteReaderInfoToFlash();
	WriteSplCardFlagInfoToFlash();
	return(0);
}
//=================================================================================================================================================
/*** BeginHeader WriteReaderInfoToFlash*/      // FA00076 Door setting by reader info command same as 4DR 4RD.
unsigned char WriteReaderInfoToFlash(void);
/*** EndHeader */
unsigned char WriteReaderInfoToFlash(void)
{

//   	unsigned char tempwrbuf[PAGE_SIZE];
   	memcpy(tempwrbuf,(char *)&ReaderInfo,sizeof(ReaderInfo));		
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,sizeof(ReaderInfo));
    BuffWrt_MainMem(FL_NEWREADER_INFO_PAGE_NO,1);
	MsgPrint(MSG_MEM,0,"WriteReaderInfoToFlash ");
	return(0);
}
//=================================================================================================================================================
unsigned char ReadBatteryRam(unsigned int start,unsigned int bytes)
{
 	__packed unsigned char *ptr;
	unsigned char buffer[256];
	int i;

	ptr = (unsigned char *) (start + RTC_RAM_BLOCK);
	memcpy(buffer,ptr,255);
	for(i=0;i<=bytes; i++)
	{
		SendAsciiToX(buffer[i],0);
		TransmitChar(' ');
	}
/*	bytes =255;
	ptr = (unsigned char *) (start + BATT_RAM_START_PTR);
	for(i=0;i<=bytes; i++)
	{
		buffer[i] = i;
	}
	bytes =255;
	ptr = (unsigned char *) (start + BATT_RAM_START_PTR);
	memcpy(ptr,buffer,255);
	MsgPrint(MSG_MEM,0,"ReadBatteryRam");
	for(i=0;i<=bytes; i++)
	{
		SendAsciiToX(buffer[i],0);
		TransmitChar(' ');
	}	 */
	return(0);
}
//=================================================================================================================================================
/*** BeginHeader GetAccessLevel*/
int GetAccessLevel(unsigned char alno,struct ACCESS_LEVEL_STR *accesslevel);
/*** EndHeader */
int GetAccessLevel(unsigned char alno,struct ACCESS_LEVEL_STR *accesslevel)
{
unsigned int ptr;
	if(MAX_ACCESS_LEVEL <= alno)
		return(-1);
	ptr = (ACCESS_LEVEL_BYTES*alno)/PAGE_SIZE;
	if(alno >= PAGE_SIZE/ACCESS_LEVEL_BYTES)
		alno = alno - (PAGE_SIZE/ACCESS_LEVEL_BYTES); 
	MainMem_ReadPage(FL_ACCESS_LEVEL_PAGE_NO+ptr,0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy((char *)accesslevel,&tempwrbuf[alno*ACCESS_LEVEL_BYTES],ACCESS_LEVEL_BYTES);
	return(0);
}
//=================================================================================================================================================
/*** BeginHeader StoreAccessLevel*/
int StoreAccessLevel(unsigned char alno,struct ACCESS_LEVEL_STR *accesslevel);
/*** EndHeader */
int StoreAccessLevel(unsigned char alno,struct ACCESS_LEVEL_STR *accesslevel)
{
unsigned int ptr;
	if(MAX_ACCESS_LEVEL < alno)
		return(-1);
	ptr = (ACCESS_LEVEL_BYTES*alno)/PAGE_SIZE;
	if(alno >= PAGE_SIZE/ACCESS_LEVEL_BYTES)
		alno = alno - (PAGE_SIZE/ACCESS_LEVEL_BYTES); 
	MainMem_ReadPage(FL_ACCESS_LEVEL_PAGE_NO+ptr,0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy(&tempwrbuf[alno*ACCESS_LEVEL_BYTES],(char *)accesslevel,ACCESS_LEVEL_BYTES);		
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,PAGE_SIZE);
    BuffWrt_MainMem(FL_ACCESS_LEVEL_PAGE_NO+ptr,1);	
	return(0);
}

//=================================================================================================================================================
#ifdef SUPPORT_NSERIES2
/*** BeginHeader GetAccessMonth*/
int GetAccessMonth(unsigned char amno,struct ACCESS_MONTH_STR *accessmonth);
/*** EndHeader */
int GetAccessMonth(unsigned char amno,struct ACCESS_MONTH_STR *accessmonth)
{
   //xmem2root((unsigned char*)accessmonth,(unsigned long)ExMemAccessMonthBase +((unsigned long)ACCESS_MONTH_BYTES * (unsigned long)amno),ACCESS_MONTH_BYTES);
   unsigned int ptr;
	if(MAX_ACCESS_MONTH_LEVEL <= amno)
		return(-1);
	ptr = (ACCESS_MONTH_BYTES*amno)/PAGE_SIZE;
	if(amno >= PAGE_SIZE/ACCESS_MONTH_BYTES)
		amno = amno - (PAGE_SIZE/ACCESS_MONTH_BYTES); 
	MainMem_ReadPage(FL_ACCESS_MONTH_PAGE_NO+ptr,0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy((char *)accessmonth,&tempwrbuf[amno*ACCESS_MONTH_BYTES],ACCESS_MONTH_BYTES);
	return(0);
}

/*-----------------------------------------------------------------------------*/
/*** BeginHeader StoreAccessMonth*/
int StoreAccessMonth(unsigned char amno,struct ACCESS_MONTH_STR *accessmonth);
/*** EndHeader */
int StoreAccessMonth(unsigned char amno,struct ACCESS_MONTH_STR *accessmonth)
{
	//root2xmem((unsigned long)ExMemAccessMonthBase+(unsigned long)((unsigned long)ACCESS_MONTH_BYTES*(unsigned long)amno),(unsigned char*)accessmonth,ACCESS_MONTH_BYTES);
	unsigned int ptr;
	if(MAX_ACCESS_MONTH_LEVEL < amno)
		return(-1);
	ptr = (ACCESS_MONTH_BYTES*amno)/PAGE_SIZE;
	if(amno >= PAGE_SIZE/ACCESS_MONTH_BYTES)
		amno = amno - (PAGE_SIZE/ACCESS_MONTH_BYTES); 
	MainMem_ReadPage(FL_ACCESS_MONTH_PAGE_NO+ptr,0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy(&tempwrbuf[amno*ACCESS_MONTH_BYTES],(char *)accessmonth,ACCESS_MONTH_BYTES);		
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,PAGE_SIZE);
    BuffWrt_MainMem(FL_ACCESS_MONTH_PAGE_NO+ptr,1);	
	return(0);
}
#endif

//=================================================================================================================================================
int GetHoliday(unsigned char holidayno,unsigned char rdno,_STRHoliday *holiday);
/*** EndHeader */
int GetHoliday(unsigned char holidayno,unsigned char rdno,_STRHoliday *holiday)
{
	if(MAX_READERS<rdno)
		return(-1);	
	if(MAX_HOLIDAY<holidayno)
		return(-1);
//	if(MAX_READERS<8)			  //ARMD0479
//		return(-1);	
	if((MAX_HOLIDAY*2*HOLIDAY_BYTES) > PAGE_SIZE)
		return(-1);		
	MainMem_ReadPage(FL_HOLIDAY_PAGE+(rdno/2),0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy((char *)holiday,&tempwrbuf[((holidayno*HOLIDAY_BYTES) + ((rdno%2)*HOLIDAY_BYTES *MAX_RDR_HOLIDAY)) ], \
			HOLIDAY_BYTES);
	return(0);
}
//=================================================================================================================================================
int StoreHoliday(unsigned char holidayno,unsigned char rdno,_STRHoliday *holiday);
/*** EndHeader */
int StoreHoliday(unsigned char holidayno,unsigned char rdno,_STRHoliday *holiday)
{
//	char tempwrbuf[PAGE_SIZE];
	if(MAX_READERS<rdno)
		return(-1);
//	if(MAX_READERS<8)				 //ARMD0479
//		return(-1);	
	if(MAX_HOLIDAY<holidayno)
		return(-1);	
	if((MAX_HOLIDAY*2*HOLIDAY_BYTES) > PAGE_SIZE)
		return(-1);	
	MainMem_ReadPage(FL_HOLIDAY_PAGE + (rdno/2),0,(BYTE *)tempwrbuf,PAGE_SIZE);
   	memcpy(&tempwrbuf[(holidayno*HOLIDAY_BYTES)+ (rdno%2)*(HOLIDAY_BYTES*MAX_RDR_HOLIDAY) ],(char *)holiday,\
			HOLIDAY_BYTES);		
	MainMem_BuffWrt(0,1,(BYTE *)&tempwrbuf,PAGE_SIZE);
    BuffWrt_MainMem(FL_HOLIDAY_PAGE + (rdno/2),1);	
	return(0);
}
//=================================================================================================================================================
void DelAllHoliday(void)
{
	if( !(InitialiseFlags & DELETE_ALL_HOLIDAY) )	//ARMF0377
		return ;			
	InitialiseFlags &= ~DELETE_ALL_HOLIDAY;
	MainMem_ReadPage(FL_HOLIDAY_PAGE,0,(BYTE* )&tempwrbuf,SPIBUFSIZE);
	memset(tempwrbuf,0,sizeof(tempwrbuf));
	MainMem_BuffWrt(0,1,(BYTE* )tempwrbuf,SPIBUFSIZE);
	BuffWrt_MainMem(FL_HOLIDAY_PAGE,1);
	BuffWrt_MainMem(FL_HOLIDAY_PAGE+1,1);
	BuffWrt_MainMem(FL_HOLIDAY_PAGE+2,1);
	BuffWrt_MainMem(FL_HOLIDAY_PAGE+3,1);
   return;
}

/*--------------------------------------------------------------------------*/
void MaxValues(void)
{
	MaxNoOfCards = MAX_NO_OF_CARD;
	BalCards =  MAX_NO_OF_CARD - TotalCards;
	MaxNoOfTrans = MAX_TRANS - 1;
	BalTransBuffer = MaxNoOfTrans - TotalNosOfTrans;
	
#ifdef BIO_METRIC
#ifdef SUPPORT_SUPREMA
	ENABLE_BIO_COMM();
	if(ReadBioSystemParameter(BIO_SYS_ADDED_TEMPLATES) == 0)
		UsedTemplates = (unsigned int)BioCmdSize;
	else
	{
//		L_DisplayROMStr("Sensor Fail...",16,ROW_USER_ENTRY);
		DisplayBottomStatusIcon(0,"Sensor Fail...",0,0);
		BioSensorFail = 1;
		MakeSound(SOUND_USER_ERROR);
	}
	if(ReadBioSystemParameter(BIO_SYS_AVAIL_TEMPLATES) == 0)
		BalTemplates = (unsigned int)BioCmdSize;
	else
	{
//		L_DisplayROMStr("Sensor Fail...",16,ROW_USER_ENTRY);
		DisplayBottomStatusIcon(0,"Sensor Fail...",0,0);
		BioSensorFail = 1;
		MakeSound(SOUND_USER_ERROR);
	}
	DISABLE_BIO_COMM();
	MaxNoofTemplates = UsedTemplates + BalTemplates;
#endif
#endif

	FirmWareVer[0] = ProdVerStr[0];
	FirmWareVer[1] = ProdVerStr[1];
	FirmWareVer[2] = ProdVerStr[2];
	FirmWareVer[3] = ' ';
	FirmWareVer[4] = MAJOR_VER;
	FirmWareVer[5] = '.';
	FirmWareVer[6] = MINOR_VER;
	FirmWareVer[7] = CONTROLLER_TYPE;
	memcpy(Controllertype,CONTR_TYPE[ReaderInfo[0].CntrolrType],16);
}



/*--------------------------------------------------------------------------*/
/*** BeginHeader WriteIOEventInfoToFlash*/                      //FA00070
unsigned char WriteIOEventInfoToFlash(void);
/*** EndHeader */
unsigned char WriteIOEventInfoToFlash(void)
{
	if(sizeof(IOEventInfo) <= PAGE_SIZE)
	{
		memcpy(tempwrbuf,(BYTE *)&IOEventInfo[0],sizeof(IOEventInfo));	
		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,PAGE_SIZE);
	    BuffWrt_MainMem(FL_EVENT_ID_INFO,1);
		//MsgPrint(MSG_MEM,0,"WriteIOEventInfoToFlash ");
		
//		memcpy(tempwrbuf,(BYTE *)&IOEventInfo[128],256);
//		MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,256);
//	    BuffWrt_MainMem(FL_EVENT_ID_INFO+1,1);
		MsgPrint(MSG_MEM,0,"WriteIOEventInfoToFlash ");
	}
	else
	{
		MsgPrint(MSG_MEM,0,"WriteIOEventInfoToFlash:Error ");
	}
	return 0;
}

/*--------------------------------------------------------------------------*/
/*** BeginHeader ReadIOEventInfoFromFlash*/                      //FA00070
unsigned char ReadIOEventInfoFromFlash(void);
/*** EndHeader */
unsigned char ReadIOEventInfoFromFlash(void)
{
	if(sizeof(IOEventInfo) <= PAGE_SIZE)
	{
	    MainMem_ReadPage(FL_EVENT_ID_INFO,0,(BYTE *)&tempwrbuf,PAGE_SIZE);//ARMF0253
		memcpy((BYTE *)&IOEventInfo[0],tempwrbuf,sizeof(IOEventInfo));

// 	MainMem_ReadPage(FL_EVENT_ID_INFO+1,0,(BYTE *)&tempwrbuf,256);
//	memcpy((BYTE *)&IOEventInfo[128],tempwrbuf,256);
		MsgPrint(MSG_MEM,FL_EVENT_ID_INFO," ReadIOEventInfoFromFlash");
	}
	else
	{
		MsgPrint(MSG_MEM,FL_EVENT_ID_INFO," ReadIOEventInfoFromFlash:Error");
	}
	return 0;

}
//=================================================================================================================================================
/***************** Start of TIME BASED ACTIONS ***********************/
/*** BeginHeader WriteTimeBasedAction*/
unsigned char WriteTimeBasedAction(struct TIME_BASED_ACTION (*pTimeBasedAction)[MAX_TIME_BASED_ACTIONS]);
/*** EndHeader */
unsigned char WriteTimeBasedAction(struct TIME_BASED_ACTION (*pTimeBasedAction)[MAX_TIME_BASED_ACTIONS])	//ARMF0252 
{
//	if(sizeof(TimeBasedAction) <= PAGE_SIZE)
	if(SIZEOF_TIME_BASED_BUFFER <= PAGE_SIZE)
	{
		memcpy(tempwrbuf,(char *)pTimeBasedAction,SIZEOF_TIME_BASED_BUFFER);//ARMF0253
		MainMem_BuffWrt(0,1,(BYTE *)&tempwrbuf,PAGE_SIZE);	//write into temp flash buffer
	    BuffWrt_MainMem(FL_TIME_BASED_ACTION_PAGE,1);		//write into actual flash location
	}
	else
	{	//To Do Write more then 1 page
		MsgPrint(MSG_MEM,0,"WriteTimeBasedAction:Error ");
	}
	return 0;
}
//=================================================================================================================================================
/*** BeginHeader ReadTimeBasedAction*/
unsigned char ReadTimeBasedAction(struct TIME_BASED_ACTION (*pTimeBasedAction)[MAX_TIME_BASED_ACTIONS]);
/*** EndHeader */
unsigned char ReadTimeBasedAction(struct TIME_BASED_ACTION (*pTimeBasedAction)[MAX_TIME_BASED_ACTIONS])	//ARMF0252 
{
//	if(sizeof(TimeBasedAction) <= PAGE_SIZE)
	if(SIZEOF_TIME_BASED_BUFFER <= PAGE_SIZE)
	{
		MainMem_ReadPage(FL_TIME_BASED_ACTION_PAGE ,0,(BYTE *)tempwrbuf,PAGE_SIZE); 	// 	if PAGE_SIZE  528 then problem NGD00066  
		memcpy((char *)pTimeBasedAction ,tempwrbuf ,SIZEOF_TIME_BASED_BUFFER);          // memory garbage data write to other variable issue 
	}																				// So we can do flash 1 & flash2 page Sz 528			
	else
	{	//To Do Read more then 1 page
		MsgPrint(MSG_MEM,0,"ReadTimeBasedAction:Error ");
	}
	return 0;
}
/***************** End of TIME BASED ACTIONS ***********************/
//=================================================================================================================================================
/*** BeginHeader WriteSplCardFlagInfoToFlash*/      
unsigned char WriteSplCardFlagInfoToFlash(void);
/*** EndHeader */
unsigned char WriteSplCardFlagInfoToFlash(void)
{
   	memcpy(tempwrbuf,(char *)&SplCrdFlag,sizeof(SplCrdFlag));		
	MainMem_BuffWrt(0,1,(BYTE *)tempwrbuf,sizeof(SplCrdFlag));
    BuffWrt_MainMem(FL_SPL_CARD_FLAG_PAGE,1);
	MsgPrint(MSG_MEM,0," WriteSplCardFlagInfoToFlash ");
	return(0);
}
//=================================================================================================================================================
/*** BeginHeader ReadSplCardFlagInfoFromFlash*/
unsigned char ReadSplCardFlagInfoFromFlash(void);    
/*** EndHeader */
unsigned char ReadSplCardFlagInfoFromFlash(void)
{
    MainMem_ReadPage(FL_SPL_CARD_FLAG_PAGE,0,(BYTE *)&SplCrdFlag,sizeof(SplCrdFlag));
	MsgPrint(MSG_MEM,FL_SPL_CARD_FLAG_PAGE," ReadSplCardFlagInfoFromFlash \n");
	return(0);
}
//=================================================================================================================================================


