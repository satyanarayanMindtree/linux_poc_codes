#ifndef __TRANXMGMT_H
#define __TRANXMGMT_H


/*** BeginHeader Variables*/
#define NO_TRANS_TO_DELETE	-1
#define NO_TRANS_FOUND		-1

#define PAGE_STATUS_NEW			1
#define PAGE_STATUS_UPDATED		2
#define PAGE_STATUS_SAVED		3
#define PAGE_STATUS_MAX			PAGE_STATUS_SAVED

struct PAGE
{
	unsigned int PageNo;
	unsigned char PageStatus;
	unsigned char Index;   	
	unsigned char PBuffer[PAGE_SIZE];
	unsigned char ChkSum;
};

__packed typedef struct TRNX_DATA	//14
{
	unsigned char Chnl;		 //1
   	unsigned char Event;	 //1
	unsigned long CardNo;	 //4
   	RTCTime Datetime;		 //6
	unsigned char InputType; //1		// this indicates from where we have received card
   	unsigned char CType; 	 //1		// Card Type of that Card
}_TRANSData;

#define APP_DATA_SIZE	sizeof(_TRANSData)

#ifndef IMMEDIATE_WRITE_TRANS
	extern struct PAGE WritePage;
	extern struct PAGE ReadPage;
#endif

//-----------------------
extern unsigned int GetPercentageFull(unsigned int readptr,unsigned int writeptr);
extern unsigned int CheckPagePointersAndUpdate(void);
extern  int ReadCurrentTransaction(_TRANSData *trans);
extern  int ReadDelTrans(_TRANSData trans);
extern  int DelCurrentTrans(void);
extern unsigned int ReadTrans(_TRANSData *trans ,unsigned int readptr);
extern unsigned int WriteTrans(_TRANSData *trans );
extern unsigned int ReadData(unsigned int readindex, BYTE *dataptr);
extern int WriteData(unsigned int writeindex, BYTE *dataptr);
extern int CopyFromNVRAMToBuffer(unsigned int pagenumber, unsigned char *dataptr);
extern int CopyCurrentPageToNVRAM(void);
extern int CopyPageToNVRAM(unsigned int pagenumber,BYTE *dataptr);
extern unsigned int GetLocInPageFromIndex(unsigned int dataindex);
extern unsigned int GetPageNoByDataIndex(unsigned int dataindex);
//extern void StoreCardInTrDB(CARDNO_DATA_STORAGE_TYPE cardno,BYTE channelno,BYTE event);
extern  int DeleteTransaction(void);
void IniTransaction(void);
extern void StoreCardInTrDBFull(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event,unsigned char ctype,unsigned char inputtype);
extern void StoreCardInTrDB(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char channelno,unsigned char event);
extern void SDStoreTransaction(unsigned char port);

extern void HandelSerialSendTrans(_TRANSData trans);
extern	unsigned char F_TrnxMemFull;
extern int PageWriteTimer;
#ifdef IMMEDIATE_WRITE_TRANS
	extern int BadPageNumber;
#endif
extern unsigned char F_BadPage;

#define IMMEDIATE_WRITE_TRANS

#endif  //#ifndef __TRANXMGMT_H




