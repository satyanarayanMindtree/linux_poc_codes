/*****************************************************************************
 *   extint.c:  External interrupt API C file for NXP LPC23xx/24xx 
 *   Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.13  ver 1.00    Prelimnary version, first Release
 *   
 *
*****************************************************************************/
#include "LPC23xx.h"                        /* LPC23xx/24xx definitions */
#include "config.h"
#include "type.h"
#include "irq.h"
#include "rtc.h"
#include "tranxmgmt.h"	
#include "uart.h"
#include "SmartBio.h"
#include "extint.h"
#include "serial.h"
#include "keypad.h"
#include "INOUT.h"


extern volatile DWORD eint0_counter;

extern BYTE F_KeyPressed;
extern BYTE F_WeigandStarted1,F_WeigandStarted2;
extern DWORD WeigandData2,WeigandData1;
extern DWORD MAGFacility1,MAGFacility2;
extern BYTE WCount1,WeigandTimeOut1,WCount2,WeigandTimeOut2;
//extern BYTE FaclityCode1,FaclityCode2;

/*****************************************************************************
** Function name:		EINT0_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT0_Handler (void) __irq 
{ 
BYTE temp1;
  
	EXTINT = EINT0;		/* clear interrupt */
	
	if(!F_WeigandStarted1)
	{  
		WeigandData1 = 0;
		F_WeigandStarted1 = SET;
		WCount1 = 0;
		WeigandTimeOut1 = 0;
		MAGFacility1 = 0;
	}
			  
#ifdef MAGReader
	WCount1 ++;
	if(WCount1 % 5)
	{
		if((WCount1>15) & (WCount1<40))
		{    
			if(!B_MDATA1)
			{  
				MAGFacility1 = MAGFacility1 | 0x80000000;
				MAGFacility1  = MAGFacility1 >>1;
			}
	       	else
	         	MAGFacility1  = MAGFacility1 >>1;
        }

		if((WCount1>40) & (WCount1<80))
		{    
	   		if(!B_MDATA1)
	       	{  
				WeigandData1 = WeigandData1 | 0x80000000;
	         	WeigandData1  = WeigandData1 >> 1;
			}
			else
	         	WeigandData1  = WeigandData1 >> 1;
		}
	}
	WeigandTimeOut1 = 0;
#else
	WCount1 ++;
	temp1 = 5;
	while(1)
	{
		temp1--;
		if(temp1 == 0)
			break;
	}
	if(WigIN_1())
	{
//		Ones++;
		WeigandData1 = WeigandData1 | 0x0000001;
		WeigandData1  = WeigandData1 * 2;
	}
	else
	{  
		WeigandData1  = WeigandData1 * 2;
//		Zero++;
	}
	temp1 = 80;
	while(1)
	{
		temp1--;
		if(temp1 == 0)
			break;
	}

#endif
//  IDISABLE;
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}
/*****************************************************************************
** Function name:		EINT0_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT2_Handler (void) __irq 
{
	EXTINT = EINT2;		/* clear interrupt */
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}
/*****************************************************************************
** Function name:		EINT1_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT1_Handler (void) __irq 
{ 
BYTE temp1;
	EXTINT = EINT1;		/* clear interrupt */
		
//  IENABLE;			// handles nested interrupt 
    if(!F_WeigandStarted2)
	{  WeigandData2 = 0;
		F_WeigandStarted2 = SET;
		WCount2 =0;
		WeigandTimeOut2 = 0;
      MAGFacility2 =0;
   }
   	 
#ifdef MAGReader
 WCount2 ++;
   if(WCount2 %5)
   {
      if((WCount2>15) & (WCount2<40) )
       {    if(!B_MDATA2)
	       	{  MAGFacility2 = MAGFacility2 |0x80000000;
	         	MAGFacility2  = MAGFacility2 >>1;

	         }
	       	else
	         	MAGFacility2  = MAGFacility2 >>1;
        }


   	if((WCount2>40) & (WCount2<80) )
       {    if(!B_MDATA2)
	       	{  WeigandData2 = WeigandData2 |0x80000000;
	         	WeigandData2  = WeigandData2 >>1;

	         }
	       	else
	         	WeigandData2  = WeigandData2 >>1;
        }
   }
   WeigandTimeOut2 = 0;
#else
      WCount2 ++;
	      temp1 = 5;
	      while(1)
	      {
	         temp1--;
	         if(temp1 ==0)
	            break;
	      }
	      if(WigIN_2())
	      {
	      //   Ones++;
	         WeigandData2 = WeigandData2 |0x0000001;
	         WeigandData2  = WeigandData2 *2;

	      }
	      else
	      {  WeigandData2  = WeigandData2 *2;
	      //   Zero++;
	      }
         temp1 = 80;
         while(1)
         {
	         temp1--;
            if(temp1 ==0)
            	break;
         }

#endif

//  IDISABLE;
	VICVectAddr = 0;		/* Acknowledge Interrupt */
}

/*****************************************************************************
** Function name:		EINT3_Handler
**
** Descriptions:		external INT handler
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void EINT3_Handler (void) __irq 
{ 
	EXTINT |= EINT3;	   	/* clear interrupt */
/*	if(IO2_INT_STAT_R == 0x100)
    {
       eint0_counter++;
	IO2_INT_CLR = 0x100;
	IO2_INT_EN_R = 0x100;// Port2.8 is Rising edge. 
//    IENABLE;
//     F_KeyPressed = 1;
//     IDISABLE;
     VICVectAddr = 0;
	
    }

  #ifdef EXNTNT3
  else
  	{
  	EXTINT |= EINT3;	   	// clear interrupt 
  	
 // 	IENABLE;		// handles nested interrupt 
  	eint3_counter++;
	
  	
//    IDISABLE;
    VICVectAddr = 0;		//cknowledge Interrupt 
    }
  #endif											   */
    VICVectAddr = 0;		/* Acknowledge Interrupt */
}
/*****************************************************************************
** Function name:		EINTInit
**
** Descriptions:		Initialize external interrupt pin and
**				install interrupt handler
**
** parameters:			None
** Returned value:		true or false, return false if the interrupt
**				handler can't be installed to the VIC table.
** 
*****************************************************************************/
DWORD EINTInit( void )
{
//PORT 2 PINS USED 15 TO 0:	 0000 0101 0101 0000 0000 0000 0000 1010
	PINSEL4 |= 0x05500000;	/* 55 set P2.10,11,12,13 as EINT0,1,2,3 and 2.8
								P2.2~7 GPIO output */
   
	EXTMODE |= EINT0_EDGE;	/* INT0 edge trigger */
	
	EXTMODE |= EINT1_EDGE;	/* INT1 edge trigger */
   
 //  EXTMODE |= EINT2_EDGE;	/* INT2 edge trigger */
   
 //  EXTMODE |= EINT3_EDGE;	/* INT3 edge trigger */
   
  // IO2_INT_CLR |= 0x100;    /*clear if any interrupt is pending... */
  // IO2_INT_EN_R |= 0x100;	/* Port2.8 is Rising edge. keypad*/
      
	EXTPOLAR = 0;			/* INT3 is falling edge by default */
   
   //IO2_INT_CLR|= 0x0C00;	/* Port2.10, 11, 12, 13 is falling edge. for wiegand CLR */
   //IO2_INT_EN_F |= 0x3C00;	/* Port2.10, 11, 12, 13 is falling edge. for wiegand  */

	if(install_irq(EINT0_INT,(void *)EINT0_Handler,HIGHEST_PRIORITY) == FALSE)
	{
		return (FALSE);
	}
  //INT_EN 1 //enable the pin 2.11 as edge sensing input
	if(install_irq(EINT1_INT,(void *)EINT1_Handler,HIGHEST_PRIORITY) == FALSE)
	{
		return (FALSE);
	}
  //INT_EN 2 //enable the pin 2.12 as edge sensing input
	if ( install_irq(EINT2_INT,(void *)EINT2_Handler,HIGHEST_PRIORITY )==FALSE)
	{
		return (FALSE);
	}
////INT_EN 3 //enable the pin 2.8 as edge sensing input
	if ( install_irq(EINT3_INT,(void *)EINT3_Handler,HIGHEST_PRIORITY )==FALSE)
  {
		return (FALSE);
  }
  return(TRUE);
}




/******************************************************************************
**                            End Of File
******************************************************************************/

