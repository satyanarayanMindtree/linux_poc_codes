//#ifndef Server_Check

#define MAX_SERVER_QUEUE		MAX_READERS
#define MAX_SERVER_TIME_OUT  	4
struct SERVER_QUEUE
{
	WORD SeqNo;		// If Seq no =0 this struct is not in use and is free for further processing.	//2	Bytes
	CARDNO_DATA_STORAGE_TYPE CNo;																	//4
	char ChNo;																						//1
	RTCTime DT;																						//6
	char TimeOut;		// To discard if we do not receive response in 1		    				//1
	char ServerNo;																					//1
	char Event;																						//1
	char CardType;																					//1
	char IpType;																					//1
	char APB;																						//1
	unsigned int SrchCardPtr; // to store cards index pointer which is used for APB storing			//4
};
extern struct SERVER_QUEUE  SerQue[MAX_READERS];

extern char SendMessageToServer(struct USER_CARD_INFO *cardInfo,unsigned char chno,unsigned char event);
extern void ServCheckMainLoop(void);
extern int ServerChkResponseVerify(struct USER_CARD_INFO *servuser,WORD seqno,char chno);
extern void InitServerPara(void);
extern char CheckServerQueueFree(char chno);

//#endif

