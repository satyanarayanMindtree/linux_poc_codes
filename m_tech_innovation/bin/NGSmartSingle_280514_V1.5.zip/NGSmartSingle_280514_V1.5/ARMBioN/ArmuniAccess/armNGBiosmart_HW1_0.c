/*
C File created for Arm Biolite board
*/

#include "config.h"
#include <LPC23xx.h>      // Keil: Register definition file for LPC2378
#include "portdef.h"
#include "type.h"
#include "timer.h"
#include "portdef.h"
#include "serial.h"
//#include "portlcd.h"
#include "INOUT.h"
#include "rdcont.h"
#include "rdpoll.h"
#include "uart.h"
#include "SmartBio.h"

extern void Delay(DWORD cnt);
void SelectIOCS(unsigned char iotype);

extern SYSInfo SysInfo;


void InitialiseIO(void)
{
	B_LCD_E(CLR);						//ARMD0196
	B_LCD_RW(CLR);
	B_LCD_RS(CLR);
	SCS |= 0x00000001;	/* set GPIOx to use Fast I/O */
	BuffOPCS1Latch = DEFAULT_CS1_OUT;
	DIR_IO_OUT_PORT();
	DIR_IO_DEC_PINS();
	BUZZER_OFF();
	BYTE_IO_OUT_PORT(0xFF);
   	DIR_LCD_PORT_BITS();
//PORT 0 PINS USED 31 TO 16 :0001 0000 0010 0000 0000 0000 0011 1100 
 	FIO0DIR |= 0x08000000; 


//select default Wigend as input when SD Card memory is used no interrupt is received on wiegand
// for SD Card bit P4.29

	FIO4DIR |= 0x10000000;

	FIO0CLR |= WG_LATCh_SEL;
		
#ifdef ARM_BIOLITE_HW
		SelectIOCS(CS_OPCS1);
#else
		SelectIOCS(CS_OPCS2);
#endif
	BuffOPCS1Latch = DEFAULT_CS1_OUT;	
	BYTE_IO_OUT_PORT(BuffOPCS1Latch);	
	SelectIOCS(CS_NO_SEL); 
	LED_INT_OFF();
}

// void  PROCESS_INPUT_DEBOUNCE_INTERRUPT(void)
// {				
// 			READ_INPUT(CurrentInput);						
// 			if(InpChange == 1)								
// 			{												
// 				if(PrevInput  == CurrentInput)				
// 				{											
// 					PrevInput = CurrentInput;				
// 					InpChange = 0;                    		
//                		CombinedIOInput = CurrentInput; 		
// 					IOInput = CombinedIOInput & 0xFF;		
// 					IOInput2 = CombinedIOInput / 0x100;		
// 					F_ChangeInInput = 1;					
// 				}											
// 				else										
// 				{											
// 					PrevInput = CurrentInput;				
// 					InpChange = 1; 							
// 				}											
// 			}												
// 			else											
// 			{												
// 				if(PrevInput  != CurrentInput)				
// 				{											
// 					PrevInput = CurrentInput;				
// 					InpChange = 1; 							
// 				}											
// 			    else if(CurrentInput != CombinedIOInput)	
// 				{ PrevInput = CombinedIOInput;				
// 				}											
// 			}												
// }

// 
#ifdef ARM_BIOLITE_HW
//this is for NG
void SelectIOCS(unsigned char iotype)
{
	F_OutPutLock = SET;
	DIR_IO_DEC_PINS();
	Delay(5);
	switch(iotype)
	{
   		case CS_IPCS1:  //this is CS1 in ckt
			FIO1SET |= PIN_P1_CSOP;
			FIO0CLR |= PIN_P0_CSIP;
			DIR_IO_IN_PORT();
			break;
		case CS_OPCS1:  //this is CS3 in ckt
			FIO0SET |= PIN_P0_CSIP;
			FIO1CLR |= PIN_P1_CSOP;
			DIR_IO_OUT_PORT();
			break;
		case CS_NO_SEL:
			FIO0SET |= PIN_P0_CSIP;
			FIO1SET |= PIN_P1_CSOP;
			DIR_IO_OUT_PORT();//default is out port to use with tft
			F_OutPutLock = CLR;
			break;
		default:
			break;
   }
}
#else  
void SelectIOCS(unsigned char iotype)
{
	F_OutPutLock = 1;
	FIO1DIR |= PINO_P1_DEC_ENABLE;  
	DECODER_DISABLE();
	DIR_IO_DEC_PINS();
	Delay(5);
	switch(iotype)
   {
   	case CS_IPCS1:
	FIO1SET |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC1;
	FIO4CLR |=PINO_P4_DEC0;
	FIO1CLR |=PINO_P1_DEC2;
	DIR_IO_IN_PORT();
	break;
   case CS_IPCS2:
	FIO1SET |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC1;
	FIO4SET |=PINO_P4_DEC0;
	FIO1CLR |=PINO_P1_DEC2;
	DIR_IO_IN_PORT();
	break;
   case CS_IPCS3:
	FIO1SET |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC1;
	FIO4CLR |=PINO_P4_DEC0;
	FIO1SET |=PINO_P1_DEC2;
	DIR_IO_IN_PORT();
	break;

   case CS_OPCS1:
	FIO1SET |=PINO_P1_DEC2;
	FIO4SET |=PINO_P4_DEC1;
	FIO4CLR |=PINO_P4_DEC0;	 
	FIO1CLR |=PINO_P1_DEC2;
	DIR_IO_IN_PORT();
   break;
   case CS_OPCS2:
	FIO1SET |=PINO_P1_DEC2;
	FIO4SET |=PINO_P4_DEC1;
	FIO4SET |=PINO_P4_DEC0;
	FIO1CLR |=PINO_P1_DEC2;
	DIR_IO_OUT_PORT();
   break;
   case CS_OPCS3:
	FIO1SET |=PINO_P1_DEC2;
	FIO4CLR |=PINO_P4_DEC1;
	FIO4SET |=PINO_P4_DEC0;
	FIO1CLR |=PINO_P1_DEC2;
	DIR_IO_OUT_PORT();   
	break;
   case CS_BUZZER:
   break;
   case CS_NO_SEL:
	DECODER_ENABLE();
	Delay(1);
	DECODER_DISABLE();
	FIO1SET |=PINO_P1_DEC2;
	FIO4SET |=PINO_P4_DEC0;
	FIO4SET |=PINO_P4_DEC1;
	DIR_IO_IN_PORT();
   	F_OutPutLock = 0;
   	break;
   }
}
#endif
/*** BeginHeader DoorOpen*/
void DoorOpen(unsigned char drno);
/*** EndHeader */
/// Actual Door Open
void DoorOpen(unsigned char drno)
{
   	if(drno >= SysInfo.ControllerMode)
   		return;
    MsgPrint(1,drno,"Door number Open= ");
	DRStruct[drno].DRCurrentStatus = SET;
	switch(drno)
	{
		case 0:
			DOOR_OPEN(1);
			break;		
		case 1:
			DOOR_OPEN(2);
			break;
		default:
			break;
	}
	MsgPrint(1,BuffOPCS1Latch,"BuffOPCS1Latch= ");
}

/*** BeginHeader DoorClose*/
void DoorClose(unsigned char drno);
/*** EndHeader */
// Actual Door Close
void DoorClose(unsigned char drno)
{
   	if(drno >= SysInfo.ControllerMode)
   		return;
    MsgPrint(1,drno,"Door number Close= ");
	if(CHECK_SHARED_DOTL(drno))
		DRStruct[((drno/2)*2)+1].DRCurrentStatus = CLR;	
	DRStruct[drno].DRCurrentStatus = CLR;
	switch(drno)
	{
		case 0:
			DOOR_CLOSE(1);
			break;		
		case 1:
			DOOR_CLOSE(2);
			break;
		default:
			break;
	}
	MsgPrint(1,BuffOPCS1Latch,"BuffOPCS1Latch= ");
}

/*** BeginHeader WeigandLedOn*/
void WeigandLedOn(unsigned char rdno);
/*** EndHeader */
void WeigandLedOn(unsigned char rdno)
{
 	DRStruct[rdno].DRControlRdrData |= (0x1<<SL_RDR_LED_CONTROL);     	 //Set bit
	switch(rdno)
	{   	
//#ifdef ARM_BIOSMART_HW
        case 0:
			//RDR_LED_ON(1);
			LED_INT_ON();
			break;   	
//#endif
		case 1:
			RDR_LED_ON(2);
			break;
		default:
			break;
	}
}

/*** BeginHeader WeigandLedOff*/
void WeigandLedOff(unsigned char rdno);
/*** EndHeader */
void WeigandLedOff(unsigned char rdno)
{	
	DRStruct[rdno].DRControlRdrData &= (~(0x1<<SL_RDR_LED_CONTROL));	//Clear bit
	switch(rdno)
	{   	
//#ifdef ARM_BIOSMART_HW
		case 0:
			//RDR_LED_OFF(1);
			LED_INT_OFF();
			break;  	
//#endif
		case 1:
			RDR_LED_OFF(2);
			break;
		default:
			break;
	}
}

/*** BeginHeader DOTLLedOn*/
void DOTLLedOn(unsigned int rdno);
/*** EndHeader */
void DOTLLedOn(unsigned int rdno)
{
	DRStruct[rdno].DRControlRdrData |= (0x1<<SL_RDR_DOTL_CONTROL);     	 //Set bit
	switch(rdno)
	{   	
		case 0:
			SET_DOTL(1);
			break;
		default:
			break;
	}
}

/*** BeginHeader DOTLLedOff*/
void DOTLLedOff(unsigned int rdno);
/*** EndHeader */
void DOTLLedOff(unsigned int rdno)
{
	DRStruct[rdno].DRControlRdrData &= (~(0x1<<SL_RDR_DOTL_CONTROL));	//Clear bit
	switch(rdno)
	{   	
		case 0:
			CLR_DOTL(1);
			break;
		default:
			break;
	}
}

/*** BeginHeader WeigandBuzOn*/
void WeigandBuzOn(unsigned char rdno);
/*** EndHeader */
void WeigandBuzOn(unsigned char rdno)
{
	DRStruct[rdno].F_BuzzerOn = SET;
	DRStruct[rdno].DRControlRdrData |= (0x1<<SL_RDR_BUZ_CONTROL);			//Set bit  
	switch(rdno)
	{   	
#ifdef ARM_BIOSMART_HW
		case 0:
			RDR_BUZ_ON(1);
			break;   	
#endif
		case 1:
			RDR_BUZ_ON(2);
			break;
		default:
			break;
	}
}

/*** BeginHeader WeigandBuzOff*/
void WeigandBuzOff(unsigned char rdno);
/*** EndHeader */
void WeigandBuzOff(unsigned char rdno)
{
	DRStruct[rdno].F_BuzzerOn = CLR;
	DRStruct[rdno].DRControlRdrData &= (~(0x1<<SL_RDR_BUZ_CONTROL));		//Clear bit
	switch(rdno)
	{   	
#ifdef ARM_BIOSMART_HW
		case 0:
			RDR_BUZ_OFF(1);
			break;   	
#endif
		case 1:
			RDR_BUZ_OFF(2);
			break;
		default:
			break;
	}
}

