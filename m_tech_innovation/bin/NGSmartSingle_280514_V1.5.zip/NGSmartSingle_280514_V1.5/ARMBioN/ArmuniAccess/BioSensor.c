
#include <string.h>
#include "LPC23xx.h"			/* LPC23xx/24xx Peripheral Registers	*/
#include "config.h"
#include "type.h"
#include "irq.h"
#include "uart.h"
#include "smartbio.h"
#include "rtc.h"
#include "spi.h"
#include "serial.h"
#include "access.h"
#include "uart.h"
#include "portlcd.h"
#include "tranxmgmt.h"
#include "userintf.h"
#ifdef BIO_METRIC
	#ifdef SUPPORT_SUPREMA
		#include "supremabio.h"
	#else
		#include "virdibio.h"
	#endif
#endif
#include "wdt.h"
#include "userIntfGLCD.h"
#include "templatesonflash.h"


#ifdef BIO_METRIC
/*---------------------------------------------------------------------------------------*/
/*** BeginHeader EnrollNewFingerID */
BYTE EnrollNewFingerID(CARDNO_DATA_STORAGE_TYPE fingerid,BYTE addtype);
/*** EndHeader */
BYTE EnrollNewFingerID(CARDNO_DATA_STORAGE_TYPE fingerid,BYTE addtype)
{
#ifndef SUPPORT_SUPREMA
BYTE status;
#endif
/*
add type
= 0		Always add new user with finger

= 0x71	this is to add  user with given id if same ID is not present and
			 if ID is present it will add finger new finger at same ID location.
= 0x74	continue ..
= 0x70	Check if provided ID is present .. no enrollment
*/
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	
#ifdef SUPPORT_SUPREMA
	BioCommand = CMD_ENROLL_FINGER_SCAN;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(addtype);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else											//defect X0100
	if(UserFingerNo == 0)
		BioCommand = CMD_ENROLL_FINGER_START;
	else
		BioCommand = CMD_ADD_FINGER_START;

	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for Registering user with ID

  	TransmitCharBio(0);				  			//UFOM ID
	TransmitCharBio(0);

	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

  	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);

  	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
  	TransmitCharBio(0);				  			 
	TransmitCharBio(0);

	TransmitCharBio(0);				  			 
	TransmitCharBio(0);

  	TransmitCharBio(Biochecksum);
 	TransmitCharBio(0);

	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
//	TransmitChar(status);
//	for (i=0;i<20;i=i+1)
//	{
//		TransmitChar(S2Buffer[i]);
//	}
	if(status == 0)
	{
		ClearBioSerBuffer();
		F_BioCheckSum = SET;
		Biochecksum = 0;
		PortObj[SER_BIO_PORT].RxPtr = 0;
		if(UserFingerNo == 0)
			BioCommand = CMD_ENROLL_FINGER_END;
		else
			BioCommand = CMD_ADD_FINGER_END;

		TransmitCharBio(0x02);			  			//start
		TransmitCharBio(BioCommand);			  	//Command for Registering user with ID
	
	  	TransmitCharBio(0);				  			// UFOM ID
		TransmitCharBio(0);
	
		TransmitCharBio((BYTE)(fingerid & 0x00ff));
		TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
		TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
		TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	
	  	TransmitCharBio(0x00);			 			//
		TransmitCharBio(0x00);
		TransmitCharBio(0x00);
		TransmitCharBio(0x00);
	
	  	TransmitCharBio(0);				  			 
		TransmitCharBio(0);
	  	TransmitCharBio(0);				  			 
		TransmitCharBio(0);
	
		TransmitCharBio(0);				  			 
		TransmitCharBio(0);
	
	  	TransmitCharBio(Biochecksum);
	 	TransmitCharBio(0);
/*		FingerWaitTimeOut = 0;
		status = WaitBioResponse();
		TransmitChar(status);
		for (i=0;i<20;i=i+1)
		{
			TransmitChar(S2Buffer[i]);
		}
*/
	}
	else
	{
		F_SerialCommandBio = SET;	//To get timeout while enrollment using main loop
		return(status);
	}
#endif
	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader IdentifyFinger */
BYTE IdentifyFinger(void);
/*** EndHeader */
BYTE IdentifyFinger(void)
{
BYTE sensorfail;

	sensorfail = BioSensorFail;   // as clear finger will reset sensor fail...
	ClearBioSerBuffer();
	BioSensorFail = sensorfail;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_IDENTIFY_FINGER;
#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else											//defect X0100

	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for Identifying finger
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
/*
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	TransmitChar(status);

	for (i=0;i<20;i=i+1)
	{
		TransmitChar(S2Buffer[i]);
	}
*/
#endif

	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader VerifyFinger */
BYTE VerifyFinger(CARDNO_DATA_STORAGE_TYPE fingerid);
/*** EndHeader */
BYTE VerifyFinger(CARDNO_DATA_STORAGE_TYPE fingerid)
{
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_USER_ID_SCAN;
#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else										   //defect X0100
	TransmitCharBio(0x02);			  		   //start
	TransmitCharBio(BioCommand);			  	   //Command for verifying finger with ID
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
/*
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	TransmitChar(status);

	for (i=0;i<20;i=i+1)
	{
		TransmitChar(S2Buffer[i]);
	}
*/
#endif
  	
	FingerWaitTimeOut = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader DeleteBioUserID */
BYTE DeleteBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid);
/*** EndHeader */
BYTE DeleteBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_USER_ID;
#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else										   
	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for deleting user with ID	

	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
		
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
		
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
		
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
		
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
		
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
#endif
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
 		return(status);
}


BYTE DeleteAllBioTemplate(void);
/*** EndHeader */
BYTE DeleteAllBioTemplate(void)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_ALL_TEMPLATE;

	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(0x00));
	TransmitCharBio((BYTE)(0x00));
	TransmitCharBio((BYTE)(0x00));
	TransmitCharBio((BYTE)(0x00));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
 		return(status);
}

/*-------------------------------------------------------------------------------------------------------------*/
// This cimmand is for delete template for user or same can also be used for delete multiple templete for userIDs which start from idstart to idend
// del type will decide what to delete
// DELETE_ONLY_ONE(0x70)*
// DELETE_MULTIPLE_ID(0x71)*
/*** BeginHeader DeleteBioFingerID */
BYTE DeleteBioFingerID(CARDNO_DATA_STORAGE_TYPE idstart,CARDNO_DATA_STORAGE_TYPE idend,BYTE deltype);
/*** EndHeader */
BYTE DeleteBioFingerID(CARDNO_DATA_STORAGE_TYPE idstart,CARDNO_DATA_STORAGE_TYPE idend,BYTE deltype)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_USER_ID;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(idstart & 0x00ff));
	TransmitCharBio((BYTE)((idstart & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((idstart & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((idstart & 0xFF000000) / 0x1000000));

	TransmitCharBio((BYTE)(idend & 0x00ff));
	TransmitCharBio((BYTE)((idend & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((idend & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((idend & 0xFF000000) / 0x1000000));

	TransmitCharBio(deltype);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
 		return(status);
}

/*--------------------------------------------------------------------------------------*/
// This will delete all user IDs from Biometric Reader
/*** BeginHeader DeleteAllBioUserID */
BYTE DeleteAllBioUserID(void);
/*** EndHeader */
BYTE DeleteAllBioUserID(void)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_DELETE_ALL_USER_ID;
#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else
	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  		//Command for delet all user ID
		
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
#endif
	
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(status);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader CheckBioUserID */
BYTE CheckBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid);
/*** EndHeader */
BYTE CheckBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_CHECK_USER_ID;
#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
 	if(status == STATUS_BIO_EXIST_ID)
		return(0);
	else
		return(BioCmdStatus);
#else
	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  		//Command for deleting user with ID
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);

	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_EXIST_ID)
		return(0);
	else
		return((BYTE)BioCmdSize);
#endif

}

/*--------------------------------------------------------------------------------------*/
// THIS COMMAND IS NOT FULLY IMPLEMENTED AS WE GET LIST ALL USER IDS WHICH IS DIFFICULT TO MANAGE
/*** BeginHeader ListBioUserID */
// BYTE ListBioUserID(void);
// /*** EndHeader */
// BYTE ListBioUserID(void)
// {
// BYTE status;
// 	ClearBioSerBuffer();
// 	PortObj[SER_BIO_PORT].RxPtr = 0;
// 	F_BioCheckSum = SET;
// 	Biochecksum = 0;
// 	BioCommand = CMD_LIST_USER_ID;
// 	TransmitCharBio(0x41);
// 	TransmitCharBio(0x01);
// 	TransmitCharBio(0x0);
// 	TransmitCharBio(BioCommand);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	TransmitCharBio(Biochecksum);
// 	TransmitCharBio(0x0A);
// 	FingerWaitTimeOut = 0;
// 	status = WaitBioResponse();
// 	if(status == STATUS_BIO_SUCCESS)
// 		return(0);
// 	else
// 		return(status);
// }

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader WaitBioResponse */
BYTE WaitBioResponse(void);
/*** EndHeader */
BYTE WaitBioResponse(void)
{
static char sensortimeout=0;
	while(1)
	{
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
		if(F_SerialCommandBio == SET)
		{
			if(sensortimeout==1)		// To remove sensor time out message..
				DisplayBottomStatusIcon(0,"                  ",0,0);
			F_SerialCommandBio = CLR;
//			if(F_BIO_COMM == SET)
			{
				ProcessBioSerialResponse();
				break;
			}
		}

		if(FingerWaitTimeOut >= MAX_BIO_TIME_OUT)
		{
			BioCmdStatus = STATUS_BIO_TIME_OUT;
			sensortimeout=1;
//			L_DisplayWelcomeMessage("Sensor TimeOut  ",16,ROW_USER_ENTRY,0);
			DisplayBottomStatusIcon(0,"Sensor TimeOut",0,0);
			break;
		}
	}
	return(BioCmdStatus);
}
/*--------------------------------------------------------------------------------------*/
/*** BeginHeader WaitBioResponse */
BYTE WaitBioResponse_2(void);
/*** EndHeader 
Fn is for Scan finger for geting template of current user 
*/
BYTE WaitBioResponse_2(void)
{
	while(1)
	{
#ifdef ENABLE_WATCHDOG
		WDTFeed();		//Clear watchdog timer
#endif
		if(F_SerialCommandBio == SET)
		{
			F_SerialCommandBio = CLR;
				break;
		}

		if(FingerWaitTimeOut >= MAX_BIO_TIME_OUT)
		{
			BioCmdStatus = STATUS_BIO_TIME_OUT;
			DisplayBottomStatusIcon(0,"Sensor TimeOut",0,0);
			break;
		}
	}
	return(BioCmdStatus);
}


/*--------------------------------------------------------------------------------------*/
/*** BeginHeader TimeWaitBioResponse */
// BYTE TimeWaitBioResponse(WORD time);
// /*** EndHeader */
// BYTE TimeWaitBioResponse(WORD time)
// {
// 	while(1)
// 	{
// 		if(F_SerialCommandBio == SET)
// 		{
// 			F_SerialCommandBio  = CLR;
// //			if(F_BIO_COMM == SET)
// 			{
// 				ProcessBioSerialResponse();
// 				break;
// 			}
// 		}

// 		if(FingerWaitTimeOut >= time)
// 		{
// 			BioCmdStatus = STATUS_BIO_TIME_OUT;
// 			//L_DisplayROMStr("Sensor TimeOut  ",16,ROW_USER_ENTRY);
// 			//L_DisplayWelcomeMessage("Sensor TimeOut  ",16,ROW_USER_ENTRY,0);
// 			DisplayBottomStatusIcon(0,"Sensor TimeOut",0,0);
// 			break;
// 		}
// 	}
// 	return(BioCmdStatus);
// }

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ProcessBioSerialResponse */
void ProcessBioSerialResponse(void);
/*** EndHeader */
void ProcessBioSerialResponse(void)
{
	if(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION] == BioCommand)
	{
		PortObj[SER_BIO_PORT].RxPtr = 0;
#ifdef SUPPORT_SUPREMA
		BioCmdStatus = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+9];
		BioCmdData = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+1] + 			\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+2]*0x100 +		\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+3]*0x10000 +	\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+4]*0x1000000;
		BioCmdSize = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+5] + 			\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+6]*0x100 +		\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+7]*0x10000 + 	\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+8]*0x1000000;
#else
	 	BioCmdStatus = (BYTE)(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+15] + \
					   PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+16]*0x100);	   // for virdi

		BioCmdData = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+3] + \
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+4]*0x100 +\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+5]*0x10000 + \
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+6]*0x1000000;

	  	BioCmdSize = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+7] + \
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+8]*0x100 +\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+9]*0x10000 + \
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+10]*0x1000000;
#endif
	}
//	MsgPrint(MSG_WARNING,BioCmdStatus,"Process Bio Ser Resp=");
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader WriteSystemParameter */// $1lx,100,101, 48/65,=  to set for single template mode or double templatge mode 
BYTE WriteSystemParameter(BYTE paraid,WORD value);
/*** EndHeader */
BYTE WriteSystemParameter(BYTE paraid,WORD value)
{ 
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET ;
	Biochecksum = 0;
	BioCommand = CMD_WRITE_SYS_PARA;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(value&0xFF);
	TransmitCharBio((value/0x100)&0xFF);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(paraid);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ReadBioSystemParameter */
BYTE ReadBioSystemParameter(BYTE para);
/*** EndHeader */
BYTE ReadBioSystemParameter(BYTE para)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_READ_SYS_PARA;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(para);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader CancelBioCommand */
BYTE CancelBioCommand(void);
/*** EndHeader */
BYTE CancelBioCommand(void)
{
BYTE status;
	ClearBioSerBuffer();
	F_BioCheckSum = SET;
	Biochecksum = 0;
	PortObj[SER_BIO_PORT].RxPtr = 0;
	BioCommand = CMD_CANCEL_BIO_RESPONSE;
#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else
	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for canceling previous command
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
#endif
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	if(status == STATUS_BIO_SUCCESS)
	{
//      printf("CancelBioCommand Success 1 %x \n",status);
		PortObj[SER_BIO_PORT].RxPtr = 0;
		FingerWaitTimeOut = 0;
//		Delay(1000);
		status = WaitBioResponse();
		Delay(2000);
		return(0);
	}
	else
	{
//      printf("CancelBioCommand 1 %x \n",status);
		PortObj[SER_BIO_PORT].RxPtr = 0;
		FingerWaitTimeOut = 0;
//		Delay(1000);
		status = WaitBioResponse();
		Delay(2000);
//      printf("CancelBioCommand 2 %x \n",status);
		return(BioCmdStatus);
	}
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader SaveBioSystemParameter */
BYTE SaveBioSystemParameter(void);
/*** EndHeader */
BYTE SaveBioSystemParameter(void)
{
BYTE status;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_SAVE_SYS_PARA;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
	if(status == STATUS_BIO_SUCCESS)
		return(0);
	else
		return(BioCmdStatus);
}

//===========================================
 /*** BeginHeader ReadDownloadTemplate */
BYTE ReadDownloadTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf);
/*** EndHeader */
BYTE ReadDownloadTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf)
{
//BYTE temp1;
//WORD ptrdata;
WORD tempsize;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_READ_BIO_TEMPLATE;
	F_Template_Download = SET;
	F_CriticalSection = SET;

#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio((BYTE)(userID & 0x00ff));
	TransmitCharBio((BYTE)((userID & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((userID & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((userID & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else
	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for canceling previous command
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio((BYTE)(userID & 0x00ff));
	TransmitCharBio((BYTE)((userID & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((userID & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((userID & 0xFF000000) / 0x1000000));
	
	TransmitCharBio(0x00);			 			//
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
#endif

	FingerWaitTimeOut = 0;
#ifndef SUPPORT_SUPREMA
	/*temp1 = */WaitBioResponse();
#endif
	F_Template_Download = CLR;
	FingerWaitTimeOut = 0;
	tempsize = 500;

	if(BioCmdStatus == STATUS_BIO_TIME_OUT)
		return(BioCmdStatus);
	ProcessBioSerialResponse();
#ifndef SUPPORT_SUPREMA
	BioCmdSize = (WORD)(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+11] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+12]*0x100);
#endif
	tempsize = (WORD)BioCmdSize;
	F_CriticalSection = CLR;
	
	if(BioCmdStatus != STATUS_BIO_SUCCESS)
		return(BioCmdStatus);

#ifdef SUPPORT_SUPREMA
	memcpy(tempbuf,&PortObj[SER_BIO_PORT].RxBuffer[(15*fingno)+((fingno-1)*(tempsize+1))],tempsize);
#else
	memcpy(tempbuf,(BYTE *)&PortObj[SER_BIO_PORT].RxBuffer[BIO_REC_PACKET_SIZE],tempsize);
#endif

	FingerWaitTimeOut = 0;
//	ptrdata = 0;
//PRINTF_REMOVE   printf(" BioCmdData = %d BioCmdSize =%d \n",BioCmdData,BioCmdSize);
	PortObj[SER_BIO_PORT].RxPtr = 0;
	return(0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ReadSingleTemplate */
BYTE ReadSingleTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf);
/*** EndHeader */
BYTE ReadSingleTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf)
{
//BYTE temp1;
WORD /*ptrdata,*/tempsize;
#ifdef SUPPORT_SUPREMA
DWORD datasize;
#endif
	ClearBioSerBuffer();
	memset(PortObj[SER_BIO_PORT].RxBuffer,0,PortObj[SER_BIO_PORT].MAXINBUF);
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_EX_READ_BIO_TEMPLATE;
	F_Template_Download = SET;
	F_CriticalSection = SET;

#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio((BYTE)(userID & 0x00ff));
	TransmitCharBio((BYTE)((userID & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((userID & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((userID & 0xFF000000) / 0x1000000));

//	datasize = (long)((fingno-1) *0x10000) + MAX_BIO_TEMPLATE_SIZE;
	datasize = (long)((fingno-1) *0x10000) + SensorTemplateSize;

	TransmitCharBio((BYTE)(datasize & 0x00ff));
	TransmitCharBio((BYTE)((datasize & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((datasize & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((datasize & 0xFF000000) / 0x1000000));

	TransmitCharBio(1);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#else
	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for canceling previous command
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
	TransmitCharBio((BYTE)(userID & 0x00ff));
	TransmitCharBio((BYTE)((userID & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((userID & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((userID & 0xFF000000) / 0x1000000));
/*
UFOM can register 10 fingerprints in 1 user ID, if 10 fingerprints is registered in 1 user ID and to collect all of fingerprint record, please input 0 in Param 2, Command Packet, then ExDatalen of Ack Packet is 56 + (803*10) = 8086. 
However if you want to collect specific record, you should put the fingerprint Number in Param2, the ExDatalen of Ack Packet is always 56 + (803 *1) = 859 

Template download Response:
Receieve packet data + Size of TUserRecord + Size of TFPRecord * No. of fingerprints
20 + 56 + 1*803
*/	
	TransmitCharBio((BYTE)(fingno & 0x00ff));
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	TransmitCharBio(0);				  			 
	TransmitCharBio(0);

	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0);
#endif

	FingerWaitTimeOut = 0;
	/*temp1 = */WaitBioResponse();
	F_Template_Download = CLR;
	FingerWaitTimeOut = 0;
	tempsize = 500;

	if(BioCmdStatus == STATUS_BIO_TIME_OUT)
		return(BioCmdStatus);
	ProcessBioSerialResponse();
#ifndef SUPPORT_SUPREMA
	BioCmdSize = (WORD)(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+11] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+12]*0x100);
#endif
	tempsize = (WORD)BioCmdSize;
	F_CriticalSection = CLR;
	
	if(BioCmdStatus != STATUS_BIO_SUCCESS)
		return(BioCmdStatus);
#ifdef SUPPORT_SUPREMA
	memcpy(tempbuf,(BYTE *)&PortObj[SER_BIO_PORT].RxBuffer[BIO_REC_PACKET_SIZE+BIO_REC_PACKET_SIZE_2],tempsize);
#else
	memcpy(tempbuf,(BYTE *)&PortObj[SER_BIO_PORT].RxBuffer[BIO_REC_PACKET_SIZE],tempsize);
#endif
	FingerWaitTimeOut = 0;	

// Send data received OK command to complete the protocol
	F_BioCheckSum = SET;
	Biochecksum = 0;
//==========================================

#ifdef SUPPORT_SUPREMA
	BioCommand = CMD_EX_READ_BIO_TEMPLATE;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	
	TransmitCharBio(0x83);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
#endif
	return(0);
}

/*** BeginHeader EnrollByBioTemplate */
BYTE EnrollByBioTemplate(CARDNO_DATA_STORAGE_TYPE fingerid,WORD templatesize,BYTE * tempbuf);
/*** EndHeader */
BYTE EnrollByBioTemplate(CARDNO_DATA_STORAGE_TYPE fingerid,WORD templatesize,BYTE * tempbuf)
{
WORD temp1;
#ifndef SUPPORT_SUPREMA
WORD fingerdata;
unsigned int ExDataBiochecksum;
#endif

	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_ENROLL_BIO_TEMPLATE;

#ifdef SUPPORT_SUPREMA
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);

	TransmitCharBio((BYTE)(fingerid & 0x00ff));
	TransmitCharBio((BYTE)((fingerid & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerid & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerid & 0xFF000000) / 0x1000000));

	TransmitCharBio(templatesize & 0x00ff);
	TransmitCharBio(templatesize / 0x100);
	TransmitCharBio(0);
	TransmitCharBio(0);

	TransmitCharBio(0x71);

	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
/*	
	temp1 = WaitBioResponse();
//	printf("EnrollByBioTemplate:WaitBioResponse=%x\n",temp1);
*/
	temp1 = 0;
	while(temp1 < templatesize)
	{
		TransmitCharBio(tempbuf[temp1]);
//		SendAsciiToPC(tempbuf[temp1]);
//		Delay(10);
		temp1++;
	}
	TransmitCharBio(0x0A);
#else
	temp1 = templatesize / MAX_BIO_TEMPLATE_SIZE; 
	if(temp1 >= 2)
		BioCommand = CMD_ADD_BIO_TEMPLATE;

	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  	//Command for canceling previous command
	
	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);
	
//param 1: Userid
	tempbuf[0] = (BYTE)(fingerid & 0x00ff); 
	tempbuf[1] = (BYTE)((fingerid & 0xFF00) / 0x100);
	tempbuf[2] = (BYTE)((fingerid & 0xFF0000) / 0x10000);
	tempbuf[3] = (BYTE)((fingerid & 0xFF000000) / 0x1000000);

	TransmitCharBio(tempbuf[0]);
	TransmitCharBio(tempbuf[1]);
	TransmitCharBio(tempbuf[2]);
	TransmitCharBio(tempbuf[3]);

//param 2: overwrite flag 1=yes, 0=no
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);

/*
//param 3: Size of TUserRecord (56) + Size of TFPRecord(803) * No. of fingerprints(1-10)
- use only 1 fingerprint : TUserRecord(56Byte) + TFPRecord(803Byte)
- use n fingerprints : TUserRecord(56Byte) + TFPRecord(803Byte) + TFPRecord(803Byte) + �
*/
	fingerdata = MAX_BIO_TEMPLATE_SIZE;  
	TransmitCharBio((BYTE)(fingerdata & 0x00ff));
	TransmitCharBio((BYTE)((fingerdata & 0xFF00) / 0x100));
	TransmitCharBio((BYTE)((fingerdata & 0xFF0000) / 0x10000));
	TransmitCharBio((BYTE)((fingerdata & 0xFF000000) / 0x1000000));

	TransmitCharBio(0);				  			 
	TransmitCharBio(0);
	
	TransmitCharBio(Biochecksum);
	temp1 = 0;
	ExDataBiochecksum = 0;
	while(temp1 < fingerdata)
	{
		ExDataBiochecksum = ExDataBiochecksum + tempbuf[temp1];
		temp1++;
	}
	TransmitCharBio((BYTE)ExDataBiochecksum);

	temp1 = 0;
	while(temp1 < fingerdata)
	{
		TransmitCharBio(tempbuf[temp1]);
		temp1++;
	}

#endif
	FingerWaitTimeOut = 0;
	temp1 = WaitBioResponse();
	MsgPrint(1,temp1,"EnrollByBioTemplate= ");

#ifdef SUPPORT_SUPREMA
	if(temp1 == STATUS_BIO_FINGER_FOUND)
	{
// This indicates one more command is pending to come from module which is STATUS_SUCCESSFUL so read same now
		FingerWaitTimeOut = 0;
		PortObj[SER_BIO_PORT].RxPtr = 0;
		temp1 = WaitBioResponse();
	}
//#else
//	FingerWaitTimeOut = 0;
//	PortObj[SER_BIO_PORT].RxPtr = 0;
#endif
	return(temp1);
}

/*** BeginHeader ClearBioSerBuffer */
void ClearBioSerBuffer(void);
/*** EndHeader */
void ClearBioSerBuffer(void)
{
	PortObj[SER_BIO_PORT].RxPtr = 0;
	memset(PortObj[SER_BIO_PORT].RxBuffer,0,PortObj[SER_BIO_PORT].MAXINBUF);
   	FingerWaitTimeOut = 0;
}

/*** BeginHeader VerifyBioTemplateFromHost */
BYTE VerifyBioTemplateFromHost(WORD templatesize,BYTE nooftemp,char (*template)[MAX_BIO_TEMPLATE_SIZE])
{
WORD temp1;
char i;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(nooftemp);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(templatesize & 0x00ff);
	TransmitCharBio(templatesize / 0x100);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
	for(i=0;i<nooftemp;i++)
	{
		temp1 = 0;
		while(temp1 < templatesize)
		{
			TransmitCharBio(template[i][temp1]);
			temp1++;
		}
		TransmitCharBio(0x0A);
	}

	FingerWaitTimeOut = 0;
	return(0);
}




BYTE VerifyBioTemplateFromHost1(WORD templatesize,BYTE nooftemp);//,char *tempbuffer);
// verify card template from smart card  (template from Smart Card Block )
// We need to Modify this funtion As currnently it is for taking template from SD 
// We need any variable to differntiate between whether we have take Template from Smart Card or From SD Card 
//and then modify verify funtion 
BYTE VerifyBioTemplateFromHost1(WORD templatesize,BYTE nooftemp)//,char* tempbuffer)
{
WORD temp1,temp2;
struct SD_TEMPLATE_DATA SDtempdata;
//char i;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
	TransmitCharBio(0x41);// 1,1,4,1,1,1,
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(nooftemp);
//	TransmitCharBio(0x01);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio((BYTE)(templatesize & 0x00ff));
	TransmitCharBio((BYTE)((templatesize & 0xFF00)/0x100));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
//	for(i=0;i<nooftemp;i++)
	{
		temp1 = 1;
		for(temp1=1;temp1<=nooftemp;temp1++)
		{
			ReadTemplateFromSD(CurrentUser.SearchCardPtr,&SDtempdata,temp1);		
			for(temp2=0;temp2<MAX_TEMPLATE_SIZE;temp2++)	   // NG0015 
			{			
				TransmitCharBio(SDtempdata.TData[temp2]);
			}
			TransmitCharBio(0x0A);
		}
	}

	FingerWaitTimeOut = 0;
	return(0);
}

BYTE VerifyBioTemplateFromSD(WORD templatesize,BYTE nooftemp,BYTE Templateinfo,int sdtemplateblock);
// verify card template from SD 
BYTE VerifyBioTemplateFromSD(WORD templatesize,BYTE nooftemp,BYTE Templateinfo,int sdtemplateblock)	  //NG0016
{
WORD temp1,temp2,error,temp4;
struct SD_TEMPLATE_DATA SDtempdata;
//char i;
	error=1;
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
	TransmitCharBio(0x41);// 1,1,4,1,1,1,
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(nooftemp);
//	TransmitCharBio(0x01);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio((BYTE)(templatesize & 0x00ff));
	TransmitCharBio((BYTE)((templatesize & 0xFF00)/0x100));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
//	for(i=0;i<nooftemp;i++)
	{
		temp1 = 1;
		temp4 =0;
		for(temp1=0;temp1<=7;temp1++)
			temp4 += (Templateinfo>>temp1)&0x01;
		
		for(temp1=1;temp1<=temp4;temp1++)
		{
			ReadTemplateFromSD(sdtemplateblock,&SDtempdata,temp1);
			if(SDtempdata.TSZ<MAX_TEMPLATE_SIZE+16)				//NG0007
			{
				for(temp2=0;temp2<templatesize;temp2++)
				{			
					TransmitCharBio(SDtempdata.TData[temp2]);
				}			
				TransmitCharBio(0x0A);
				error=0;
			}
		}		
	}
	if(error==0)
		FingerWaitTimeOut = 0;
	return(error);
}


BYTE VerifyBioTemplateFromSDNew(CARDNO_DATA_STORAGE_TYPE cardno,WORD templatesize,BYTE nooftemp,BYTE Templateinfo,int sdtemplateblock);
// verify card template from SD 
BYTE VerifyBioTemplateFromSDNew(CARDNO_DATA_STORAGE_TYPE cardno,WORD templatesize,BYTE nooftemp,BYTE Templateinfo,int sdtemplateblock)	  //NG0016  NGD00039
{
WORD temp1,temp2,error,temp4;
struct SD_TEMPLATE_DATA SDtempdata;
//char i;
	error=1;

	temp4=0;
	for(temp1=0;temp1<=7;temp1++)
		temp4+= (Templateinfo>>temp1)&0x01;
	temp2=0;
	for(temp1=1;temp1<=temp4;temp1++)
	{
		ReadTemplateFromSD(sdtemplateblock,&SDtempdata,temp1);
		if((SDtempdata.TSZ<MAX_TEMPLATE_SIZE+16)&&(cardno==SDtempdata.CardNo))				//NG0007
		{
			temp2++;		// temp2 contains actual available templates
			templatesize = SDtempdata.TSZ;		// we send what template we get from sensor
		}
	}
	if(temp2==0)
		return(1);		// as no template so do not send any command		
	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
	TransmitCharBio(0x41);// 1,1,4,1,1,1,
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
	TransmitCharBio(temp2);			// We send no of template only for available template
//	TransmitCharBio(0x01);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio((BYTE)(templatesize & 0x00ff));
	TransmitCharBio((BYTE)((templatesize & 0xFF00)/0x100));
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
//	for(i=0;i<nooftemp;i++)
	{
		temp1 = 1;
		temp4 =0;
		for(temp1=0;temp1<=7;temp1++)
			temp4 += (Templateinfo>>temp1)&0x01;
		
		for(temp1=1;temp1<=temp4;temp1++)
		{
			ReadTemplateFromSD(sdtemplateblock,&SDtempdata,temp1);				
			if((SDtempdata.TSZ<MAX_TEMPLATE_SIZE+16)&&(cardno==SDtempdata.CardNo))//NG0007
			{
				for(temp2=0;temp2<templatesize;temp2++)
				{			
					TransmitCharBio(SDtempdata.TData[temp2]);
				}			
				TransmitCharBio(0x0A);
				error=0;
			}
		}		
	}
	if(error==0)
		FingerWaitTimeOut = 0;
	return(error);
}

int GetTemplateFromSDToBuff(CARDNO_DATA_STORAGE_TYPE finder,WORD *tempsz,char *nooftemp,char Templateinfo,int sdtemplateblock,char (*template)[MAX_BIO_TEMPLATE_SIZE])
{		
char temp1,temp4,temp2;
struct SD_TEMPLATE_DATA SDtempdata;
	temp4=0;
	for(temp1=0;temp1<=4;temp1++)
		temp4+= (Templateinfo>>temp1)&0x01;
	temp2=0;
	if(temp4>MAX_NO_OF_SC_TEMPLATES)   	// As we have small template Buffer for SD Card 
		temp4 = MAX_NO_OF_SC_TEMPLATES;
	for(temp1=1;temp1<=temp4;temp1++)
	{
		ReadTemplateFromSD(sdtemplateblock,&SDtempdata,temp1);
		if((SDtempdata.TSZ<MAX_TEMPLATE_SIZE+16)&&(finder==SDtempdata.CardNo))				//NG0007
		{
			memcpy(&template[temp2],SDtempdata.TData,SDtempdata.TSZ+1);			
			temp2++;
			*tempsz = SDtempdata.TSZ;
		}		
	}	
	*nooftemp=temp2;	
	if(temp2==0)
		return(-1);
	return(0);
}


#ifdef SUPPORT_SUPREMA
BYTE ScanBioTemplate(BYTE * tempbuf);
/*** EndHeader */
// fn will verify user finger with  template on sd ..
BYTE ScanBioTemplate(BYTE * tempbuf)
{
WORD /*ptrdata,*/tempsize;
#ifdef SUPPORT_SUPREMA
//DWORD datasize;
#endif
	ClearBioSerBuffer();
	memset(PortObj[SER_BIO_PORT].RxBuffer,0,PortObj[SER_BIO_PORT].MAXINBUF);
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;
	BioCommand = CMD_EX_READ_BIO_TEMPLATE;
	F_Template_Download = 2;
	F_CriticalSection = SET;
	
	BioCommand = CMD_SCAN_TEMPLATE;

	TransmitCharBio(0x41);
	TransmitCharBio(0x01);
	TransmitCharBio(0x0);
	TransmitCharBio(BioCommand);
		
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	TransmitCharBio(0x00);
	
	TransmitCharBio(0x00);
	TransmitCharBio(Biochecksum);
	TransmitCharBio(0x0A);
  
	FingerWaitTimeOut = 0;
	
	WaitBioResponse_2();  //  recive 1st 15 byte it give response of scan success 0x62

// //	ClearBioSerBuffer();
// 	FingerWaitTimeOut = 0;
// 	memset(PortObj[SER_BIO_PORT].RxBuffer,0,PortObj[SER_BIO_PORT].MAXINBUF);
// 	PortObj[SER_BIO_PORT].RxPtr = 0;
// //	F_BioCheckSum = SET;
// 	Biochecksum = 0;
// Modifiacation is done because we recive following data 
//41010021000000000000000062C50A410100214C0000008001000061910A template data(384 byte)

//	WaitBioResponse(); // recive next 15 byte template info and template data 
	F_Template_Download = CLR;
	FingerWaitTimeOut = 0;	
//	ProcessBioSerialResponse();
	if(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION] == BioCommand)
	{
		BioCmdStatus = PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+9+15];
		BioCmdData = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+1+15] + 			\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+2+15]*0x100 +		\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+3+15]*0x10000 +	\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+4+15]*0x1000000;
		BioCmdSize = (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+5+15] + 			\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+6+15]*0x100 +		\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+7+15]*0x10000 + 	\
					 (DWORD)PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+8+15]*0x1000000;
	}
	
	if(BioCmdStatus == STATUS_BIO_TIME_OUT)
		return(1);
#ifndef SUPPORT_SUPREMA
	BioCmdSize = (WORD)(PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+11] + PortObj[SER_BIO_PORT].RxBuffer[BIO_COMMAND_POSITION+12]*0x100);
#endif
	tempsize = (WORD)BioCmdSize;
	F_CriticalSection = CLR;
	
	if(BioCmdStatus != STATUS_BIO_SUCCESS)
		return(1);
#ifdef SUPPORT_SUPREMA
	memcpy(tempbuf,(BYTE *)&PortObj[SER_BIO_PORT].RxBuffer[BIO_REC_PACKET_SIZE+BIO_REC_PACKET_SIZE_2],tempsize);
#else
	memcpy(tempbuf,(BYTE *)&PortObj[SER_BIO_PORT].RxBuffer[BIO_REC_PACKET_SIZE],tempsize);
#endif
// {	
// int i;
// 	for(i=0;i<tempsize;i++)
// 	{
// 		TransmitCharToX((BYTE)tempbuf[i],PC_PORT);
// 	}
// }	
	FingerWaitTimeOut = 0;	

// Send data received OK command to complete the protocol
	F_BioCheckSum = SET;
	Biochecksum = 0;
	  return (0);
}

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader ResetSensorModule */
// BYTE ResetSensorModule(void);
// /*** EndHeader */
// BYTE ResetSensorModule(void)
// {
// BYTE status;
// 	ClearBioSerBuffer();
// 	PortObj[SER_BIO_PORT].RxPtr = 0;
// 	F_BioCheckSum = SET;
// 	Biochecksum = 0;
// 	BioCommand = CMD_RESET_MODULE;
// 	TransmitCharBio(0x41);
// 	TransmitCharBio(0x01);
// 	TransmitCharBio(0x0);
// 	TransmitCharBio(BioCommand);

// 	TransmitCharBio(0); // par1 
// 	TransmitCharBio(0);	
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	
// 	TransmitCharBio(0); // par 2
// 	TransmitCharBio(0);	
// 	TransmitCharBio(0);
// 	TransmitCharBio(0);
// 	
// 	TransmitCharBio(0);  // flag 
// 	
// 	TransmitCharBio(Biochecksum);
// 	TransmitCharBio(0x0A);
// 	FingerWaitTimeOut = 0;
// 	status = WaitBioResponse();
// 	if(status == STATUS_BIO_SUCCESS)
// 		return(0);
// 	else
// 		return(BioCmdStatus);
// }
#endif

#ifndef SUPPORT_SUPREMA
unsigned long ReadBioSystemVersion(void)
{
BYTE status;

	ClearBioSerBuffer();
	PortObj[SER_BIO_PORT].RxPtr = 0;
	F_BioCheckSum = SET;
	Biochecksum = 0;

	BioCommand = CMD_READ_BIO_VER;

	TransmitCharBio(0x02);			  			//start
	TransmitCharBio(BioCommand);			  			//Command for Registering user with ID

  	TransmitCharBio(0);				  			// UFOM ID
	TransmitCharBio(0);

	TransmitCharBio(0);			 				//Parmeter1
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

  	TransmitCharBio(0);			 				//Parmeter2
	TransmitCharBio(0);
	TransmitCharBio(0);
	TransmitCharBio(0);

  	TransmitCharBio(0);				  			 //extrs data length
	TransmitCharBio(0);
  	TransmitCharBio(0);				  			 
	TransmitCharBio(0);

	TransmitCharBio(0);				  			  //error code
	TransmitCharBio(0);

 	TransmitCharBio(Biochecksum);				  //checksum
 	TransmitCharBio(0);							  // extra data checksum
	
	FingerWaitTimeOut = 0;
	status = WaitBioResponse();
 	MsgPrint(MSG_WARNING,BioCmdStatus,"Process Bio Ser Resp=");
	return(status);
}
#endif

void GetBalanceTemplate(void)			//NG0004
{
#ifdef BIO_METRIC
#ifdef SUPPORT_SUPREMA
	ENABLE_BIO_COMM();
	if(ReadBioSystemParameter(BIO_SYS_AVAIL_TEMPLATES) == 0)
		BalTemplates = (unsigned int)BioCmdSize;
	else
	{
		DisplayBottomStatusIcon(0,"Sensor Fail...",0,0);
		BioSensorFail = 1;
		MakeSound(SOUND_USER_ERROR);
	}
	DISABLE_BIO_COMM();
#endif
#endif
	
}

 
#ifdef DISABLE_TEMPLATE			// Functions not in use
/*--------------------------------------------------------------------------------------*/
// BYTE VerifyBioTemplate(WORD fingerid,WORD templatesize)
// {																	1
// WORD temp1;
// 	Serial2ReceiveCount = 0;
// 	F_Serial2CheckSum = 1;
// 	Serial2CheckSum = 0;
// 	BioCommand = CMD_VERIFY_BIO_TEMPLATE;
// 	TransmitChar2(0x41);
// 	TransmitChar2(0x01);
// 	TransmitChar2(0x0);
// 	TransmitChar2(BioCommand);

// 	TransmitChar2(fingerid & 0x00ff);
// 	TransmitChar2(fingerid / 0x100);
// 	TransmitChar2(0);
// 	TransmitChar2(0);

// 	TransmitChar2(templatesize & 0x00ff);
// 	TransmitChar2(templatesize / 0x100);
// 	TransmitChar2(0);
// 	TransmitChar2(0);

// 	TransmitChar2(0);
// 	TransmitChar2(Serial2CheckSum);
// 	TransmitChar2(0x0A);

// 	temp1 = 0;
// 	while(temp1 < BIO_TEMPLATE_SIZE)
// 	{
// 		TransmitChar2(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
// 		SendAsciiToSerial(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
// 		temp1++;
// 	}
// 	TransmitChar2(0x0A);

// 	FingerWaitTimeOut = 0;
// 	temp1 = WaitBioResponse();
// 	if(temp1 == STATUS_BIO_FINGER_FOUND)
// 	{
// 		Serial2ReceiveCount = 0;
// 		F_SerialPort2CommandProxy = CLR;
// 		temp1 = WaitBioResponse();
// 	}
// 	MsgPrint(1,temp1,"VerifyBioTemplate=");
// 	return(temp1);
// }

/*--------------------------------------------------------------------------------------*/
// BYTE IdenifyByBioTemplate(WORD templatesize)
// {
// WORD temp1;
// 	Serial2ReceiveCount = 0;
// 	F_Serial2CheckSum = 1;
// 	Serial2CheckSum = 0;
// 	BioCommand = CMD_IDENTIFY_BY_BIO_TEMPLATE;
// 	TransmitChar2(0x41);
// 	TransmitChar2(0x01);
// 	TransmitChar2(0x0);
// 	TransmitChar2(BioCommand);

// 	TransmitChar2(0);
// 	TransmitChar2(0);
// 	TransmitChar2(0);
// 	TransmitChar2(0);

// 	TransmitChar2(templatesize & 0x00ff);
// 	TransmitChar2(templatesize / 0x100);
// 	TransmitChar2(0);
// 	TransmitChar2(0);

// 	TransmitChar2(0);
// 	TransmitChar2(Serial2CheckSum);
// 	TransmitChar2(0x0A);

// 	temp1 = 0;
// 	while(temp1 < BIO_TEMPLATE_SIZE)
// 	{
// 		TransmitChar2(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
// 		SendAsciiToSerial(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
// 		temp1++;
// 	}
// 	TransmitChar2(0x0A);
// 	FingerWaitTimeOut = 0;
// 	temp1 = WaitBioResponse();
// 	MsgPrint(1,temp1,"IdentifyByBioTemplate=");
// 	MsgPrint(MSG_WARNING,BioCmdData,"BioCmdData=");
// 	return(temp1);
// }

/*--------------------------------------------------------------------------------------*/
// BYTE VerifyBioTemplateFromHost(WORD templatesize)
// {
// WORD temp1;
// 	Serial2ReceiveCount = 0;
// 	F_Serial2CheckSum = SET;
// 	Serial2CheckSum = 0;
// 	BioCommand = CMD_VERIFY_HOST_TEMPLATE_SCAN;
// 	TransmitChar2(0x41);
// 	TransmitChar2(0x01);
// 	TransmitChar2(0x0);
// 	TransmitChar2(BioCommand);

// 	TransmitChar2(0);
// 	TransmitChar2(0);
// 	TransmitChar2(0);
// 	TransmitChar2(0);

// 	TransmitChar2(templatesize & 0x00ff);
// 	TransmitChar2(templatesize / 0x100);
// 	TransmitChar2(0);
// 	TransmitChar2(0);
// 	TransmitChar2(0);
// 	TransmitChar2(Serial2CheckSum);
// 	TransmitChar2(0x0A);

// 	temp1 = 0;
// 	while(temp1 < BIO_TEMPLATE_SIZE)
// 	{
// 		TransmitChar2(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
// 		SendAsciiToSerial(TemplateBuff[TEMPLATE_START_POSITION+temp1]);
// 		temp1++;
// 	}
// 	TransmitChar2(0x0A);

// 	FingerWaitTimeOut = 0;
// 	temp1 = WaitBioResponse();
// 	if(temp1 == STATUS_BIO_FINGER_FOUND)
// 	{
// 		Serial2ReceiveCount = 0;
// 		F_SerialPort2CommandProxy = CLR;
// 		temp1 = WaitBioResponse();
// 	}
// 	MsgPrint(1,temp1,"VerifyBioTemplateFromHost=");
// 	return(temp1);
// }

/*--------------------------------------------------------------------------------------*/
/*** BeginHeader TransmitCharBio1 */
void TransmitCharBio1(BYTE t_data);
/*** EndHeader */
// void TransmitCharBio1(BYTE t_data)
// {
// BYTE a;
// 	if(F_BioCheckSum)
// #ifdef ENABLE_BIOMETRIC
// 		Biochecksum = Biochecksum + t_data;
// #else
// 		Biochecksum = Biochecksum ^ t_data;
// #endif
// 	a = 0;
// 	while(1)
// 	{
// 		if(serCputc(t_data) == 1)
// 			break;
// 		a++;
// 		Delay(100);
// 		if(a > 20)
// 			break;
// 	}
// //	if(DeabugLevel)
// //		printf("%x",t_data);
// }

#endif // DISABLE_TEMPLATE
//===============================================

#endif

