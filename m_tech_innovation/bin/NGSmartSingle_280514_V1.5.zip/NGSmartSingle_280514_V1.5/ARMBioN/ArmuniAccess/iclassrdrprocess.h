#ifndef __ICLASSRDRPROCESS_H 
#define __ICLASSRDRPROCESS_H

#define ERR_SC_LAYOUT_ERROR            ((char)-71)
#define ERR_SC_NO_TEMPLATE             ((char)-72)

#ifdef SUPPORT_ICLASS_RDR
	#undef MAX_NO_OF_SC_TEMPLATES
	#ifdef BIO_METRIC
		#define MAX_NO_OF_SC_TEMPLATES			2
	#else
		#define MAX_NO_OF_SC_TEMPLATES			0
	#endif
#endif

#define MAX_BLOCKS_FOR_CARDINFO			6
#define MAX_BLOCKS_FOR_TEMPLATE			48
#define TOTAL_DATA_BLOCKS_USED			(MAX_BLOCKS_FOR_CARDINFO+MAX_NO_OF_SC_TEMPLATES*MAX_BLOCKS_FOR_TEMPLATE)   // Total Data Size which will get Write on CARD

#define SEC_EMPINFO_READ_KEY           0
#define SEC_CANTEEN_READ_KEY           0
#define SEC_EMPINFO_READ_KEY_TYPE      0
#define SEC_CANTEEN_READ_KEY_TYPE      0

#define SEC_EMPINFO_WRITE_KEY          0
#define SEC_CANTEEN_WRITE_KEY          0
#define SEC_EMPINFO_WRITE_KEY_TYPE     1
#define SEC_CANTEEN_WRITE_KEY_TYPE     1

#define SCB_EMPVALIDITY    				44
#define SCB_EMPNAME        				45
#define SCB_EMPNO          				46

#define SCB_CARDNO            			48
#define SCB_CANTEEN_VDT       			49
#define SCB_BACKUP_EMPVALIDITY      	49
#define SCB_DENT_DT        				50

// card data source  (this can be from Local or from SmartCard)
#define CDATA_SOURCE_NAME				0x0001
#define CDATA_SOURCE_PIN				0x0002
#define CDATA_SOURCE_VALIDITY		0x0004
#define CDATA_SOURCE_TEMPLATE		0x0008
#define CDATA_SOURCE_USER_TYPE 	0x0010     // Card is visitor or normal employee
#define CDATA_SOURCE_ACCESSLEVEL 0x0020

#define ICR_CARD_INFO_DATA_SIZE		40


#define MAX_SC_BLOCKS_FOR_CARDINFO			6 
#define MAX_BIO_TEMPLATE_SIZE						0x200

extern SmartCardData CurrentCard;


extern unsigned char ReadSmartCardAllData(unsigned char rdno);
extern unsigned char ReadSmartCardLayout(void);
extern unsigned char SendWriteCurrentDataToICR(unsigned int len, unsigned char *blockno, unsigned char *senddata);
unsigned char WriteCardDataToICR(struct SMART_CARD_DATA *ccard);
unsigned char WriteICRTemplateData(unsigned char *sblock,unsigned int tempsize,unsigned char *tempdata);
unsigned char AllocateRequiredBlocks(void);

#ifdef BIO_METRIC
//	extern unsigned char BufferTemp[MAX_NO_OF_SC_TEMPLATES][MAX_BIO_TEMPLATE_SIZE]; 
//	extern unsigned char BufferTemp[MAX_BIO_TEMPLATE_SIZE]; 
	extern unsigned char BlockNo[TOTAL_DATA_BLOCKS_USED];
#endif



#endif /* end __ICLASSRDRPROCESS_H */

