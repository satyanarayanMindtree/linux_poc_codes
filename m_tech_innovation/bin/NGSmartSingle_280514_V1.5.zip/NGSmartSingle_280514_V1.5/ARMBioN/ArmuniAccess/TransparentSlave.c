#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "LPC23xx.h"
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "spi.h"
#include "uart.h"
#include "smartbio.h"
#include "rtc.h"
#include "access.h"
#include "tranxmgmt.h" 
#include "userintf.h" 
#include "cardmgmt.h"
#include "memory.h"
#include "rdcont.h"
#include "portlcd.h"
#ifdef ENABLE_SLAVE_SUPPORT            //FA00090
#include "TransparentSlave.h"
#endif
#include "rdpoll.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#ifndef TELNET_TEST
//#define NETWORK_HANDLE (BYTE)(0 - 1)
typedef unsigned short QUEUE_TRANSFER;
extern unsigned short fnPrint (unsigned char *ucToSend, unsigned char ucID,QUEUE_TRANSFER ucLen);
#endif
extern BYTE F_CheckSum;
extern volatile WORD ReceiveCount, ToReceiveCount;
#ifdef ENABLE_SLAVE_SUPPORT
/*** BeginHeader HandleSerialSlaveCmd*/
void HandleSerialSlaveCmd(volatile unsigned char *buffer,unsigned char port);
/*** EndHeader */
void HandleSerialSlaveCmd(volatile unsigned char *buffer,unsigned char port)
{
unsigned int n;							 
	GLOBAL_PORT = port;
	PortObj[SER_TCPIP_PORT].BufPtr = 0;
	PortObj[port].ChkSum = 0;
	PortObj[port].F_ChkSum = SET;

	if(((buffer[0] - CNTRBASEADD) == Doorinfo.PollSlaveNo) || (Doorinfo.PollSlaveNo == 0))
   {
      if(port == SER_TCPIP_PORT)
      {
         //as ethernet so check authentication is done or now else do not allow access
         if(HandleSerialAuthCheck(SECURE_AUTH_ADMIN,port) == 1)
            goto goto_serial_end;
      }	
   	SendCommandToSlave(buffer,ToReceiveCount,port);
   }

goto_serial_end: 
				n=strlen((char *)SlaveSerBuffer);
			   while(n>0) {
	               TransmitCharToX(SlaveSerBuffer[n],GLOBAL_PORT);//ARMD0322
			   n--;
				  }
				  TransmitCharToX(SlaveSerBuffer[n],GLOBAL_PORT);
			   n=0;
			   n=strlen((char *)SlaveSerBuffer);
#ifdef ETHERNET
		SendSerialDataToEthernetPort(1);		//PANKAJXX DataSocketNo
#else
#ifndef TELNET_TEST
		F_CheckSum = CLR;
		PortObj[SER_TCPIP_PORT].F_ChkSum = CLR;
//		fnPrint((BYTE *)PortObj[SER_TCPIP_PORT].Buffer,NETWORK_HANDLE,PortObj[SER_TCPIP_PORT].BufPtr);
		fnPrint((BYTE *)SlaveSerBuffer,NETWORK_HANDLE,SlaveSerPtr);
#endif
#endif 
		F_EthernetReceived = CLR;

}

/*** BeginHeader SendCommandToSlave*/
unsigned char SendCommandToSlave(volatile unsigned char *buffer,unsigned int count,unsigned char port);
/*** EndHeader */
unsigned char SendCommandToSlave(volatile unsigned char *buffer,unsigned int count,unsigned char port)
{
unsigned int i, SlaveRespTime;

  // SER_TRANSP_SLAVE_FLUSH();
 	L_DisplayCharAt1(14,'>');
 	L_DisplayCharAt1(15,'>');
   TransmitCharToX('$',TRANSP_SLAVE_PORT);
	for(i=0;i<count;i++)
		TransmitCharToX(buffer[i],TRANSP_SLAVE_PORT);
   TransmitCharToX(TERMINATOR,TRANSP_SLAVE_PORT);

   SlaveSerPtr = 0;
   F_Slave_DataStart = CLR;
   memset(SlaveSerBuffer,0,sizeof(SlaveSerBuffer));//ARMD0322
   if((buffer[1] == 'j') || (buffer[2] == 'j'))
   	SlaveCMD = 'j';
   if(Doorinfo.SlaveRespMode == 0)         //Wait for response
   {
	   SlaveRespTime = 50;     //Max Response Wait time multiple of 100msecs
	   SlaveWaitTimeOut = 0;
//	   if(WaitForSlaveRespTimeout(SlaveRespTime,buffer[1]) == 0)
	   if(WaitForSlaveRespTimeout(SlaveRespTime) == 0)
	   {
	      L_DisplayCharAt1(14,'<');
	      L_DisplayCharAt1(15,'<');
	      for(i=0;i<=SlaveSerPtr;i++)
	         TransmitCharToX(SlaveSerBuffer[i],port);//ARMD0322
	   }
	   else
	   {
	      L_DisplayCharAt1(14,'?');
	      L_DisplayCharAt1(15,'?');
	      TransmitCharToX('#',port);
	      TransmitCharToX('e',port);
	      TransmitCharToX('5',port);
	      TransmitCharToX(TERMINATOR,port);
	   }
   }
   else if(Doorinfo.SlaveRespMode == 1)        //Wait for slave response in main loop
   {
   	F_WaitForSlaveResponse = SET;
   }
   return 0;
}

//------------------------------------------------------------------------------
/*** BeginHeader WaitForSlaveRespTimeout*/
//unsigned char WaitForSlaveRespTimeout(unsigned int time, unsigned char tempbuff);
unsigned char WaitForSlaveRespTimeout(unsigned int time);
/*** EndHeader */
//unsigned char WaitForSlaveRespTimeout(unsigned int time, unsigned char tempbuff)
unsigned char WaitForSlaveRespTimeout(unsigned int time)
{
//int n;
  // WDTHandleType = WDT_WAIT_SLAVE_RESPONSE;
	while(1)
	{
		if(F_SerialSlaveDataProxy == SET)
		{
			F_SerialSlaveDataProxy = CLR;
			return(0);
		}
		if(SlaveWaitTimeOut >= time)
			return(STATUS_SLAVE_TIME_OUT);
	}
}

//------------------------------------------------------------------------------
/*** BeginHeader WaitForMainloopSlaveResponse*/
//unsigned char WaitForMainloopSlaveResponse(unsigned char tempbuff);
unsigned char WaitForMainloopSlaveResponse(void);
/*** EndHeader */
//unsigned char WaitForMainloopSlaveResponse(unsigned char tempbuff)
unsigned char WaitForMainloopSlaveResponse(void)
{
//int n;
   if(F_SerialSlaveDataProxy == SET)
      F_WaitForSlaveResponse = CLR;
return 0;
}

/*** BeginHeader HandleSlaveSerialData*/
//unsigned char HandleSlaveSerialData(unsigned char serdata,unsigned char buff);
unsigned char HandleSlaveSerialData(unsigned char serdata);
/*** EndHeader */
//unsigned char HandleSlaveSerialData(unsigned char serdata,unsigned char buff)
unsigned char HandleSlaveSerialData(unsigned char serdata)
{

	SlaveWaitTimeOut = 0;
	if(F_Slave_DataStart == CLR)
	{
		if(serdata == '#')
		{
		   memset(SlaveSerBuffer,0x00,sizeof(SlaveSerBuffer));//ARMD0322
			SlaveSerBuffer[0] = '#';
			SlaveSerPtr = 0;
			F_Slave_DataStart = SET;
		}
	}
	else if(F_Slave_DataStart == SET)
	{
		SlaveSerPtr ++;
		if(SlaveSerPtr >= MAX_SLAVE_SER_BUFF)
		{
			F_SerialSlaveDataProxy = SET;
			F_Slave_DataStart = CLR;
         SlaveCMD = 0;
         F_SerialDumpData = CLR;
		}
		else
      {
			SlaveSerBuffer[SlaveSerPtr] = serdata;
//      	if(buff == 'j')
			if(SlaveCMD == 'j')
      		{
	         if(serdata == 'G')
	            F_SerialDumpData = SET;
	         if(F_SerialDumpData == SET)
	         {
	            if((serdata == SLAVE_TERMINATOR) || (serdata == SLAVE_TERMINATOR1))
	            {
                  SlaveCMD = 0;
                  F_SerialSlaveDataProxy = SET;
	               F_Slave_DataStart = CLR;
						F_SerialDumpData = CLR;
	               SlaveSerBuffer[SlaveSerPtr+1] = '\0';
	            }
	         }
	      }
	      else if((serdata == SLAVE_TERMINATOR) || (serdata == SLAVE_TERMINATOR1))
         {
            F_SerialSlaveDataProxy = SET;
            F_Slave_DataStart = CLR;
            F_SerialDumpData = CLR;
            SlaveSerBuffer[SlaveSerPtr+1] = '\0';//ARMD0322
			F_Get_Slave_Data = 0;
         }
		}
	}
	return 0;
}

/*** BeginHeader InitliaseSlaveFlags*/
void InitliaseSlaveFlags(void);
/*** EndHeader */
void InitliaseSlaveFlags(void)	//ARMD0341
{
	PortObj[SER_SLAVE_PORT].RxPtr = 0;
	memset(SlaveSerBuffer,0,sizeof(SlaveSerBuffer));
   	SlaveWaitTimeOut = 0;
   	F_Slave_DataStart = CLR;
	F_SerialSlaveDataProxy = CLR;
	F_SerialCommandProxy = CLR;
	F_EthernetReceived = CLR;
//	UARTInit(0,9600);
	UARTInit(1,9600,0);
	memset((BYTE *)SBuffer, PAGE_SIZE, 0);
}

#endif //ENABLE_SLAVE_SUPPORT

