
#include <string.h>
#include <stdlib.h>
#include "LPC23xx.H"                        
#include "config.h"
#include "portdef.h"
#include "type.h"
#include "uart.h"
#include "SmartBio.h"
#include "rtc.h"
#include "rdcont.h"
#include "serial.h"
#include "rtc.h"
#include "tranxmgmt.h"
#ifdef ENABLE_SLAVE_SUPPORT            //FA00090
#include "TransparentSlave.h"
#endif
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/stackconfig.h"
#include "../../uTaskerV1.4_LPC/Applications/uTaskerV1.4/types.h"
#include "../../uTaskerV1.4_LPC/stack/tcpip.h"
#include "protocol.h"
#include "access.h"
#include "RDPoll.h"






#define SLAVE_CONT_BASE_ADDR	'1'
#define POLL_READER_START_BASE	0
//------------------------------------------------------------------------------
// Response will be
// #<contno>D,status,contno,rdrno,cardno,facilitycode,pending events,
// status = 0   no card/ event in buffer received
// status = 1   card received
// status = 5   egress switch pressed
// statu =  2   DOTL
// status = 3   door forced open
// status = 4	 Alarm Low
// status = 7  system just started

//Valid Events
#define SL_EV_NO_EVENT			0
#define SL_EV_CARD_RECEIVED		1
#define SL_EV_DOTL_ALARM		2
#define SL_EV_FORCE_ALARM		3
#define SL_EV_ALARM_LOW			4
#define SL_EV_EGRESS			5
#define SL_EV_DOOR_NOT_OPENED	6
#define SL_EV_SLAVE_RESTART		7
#define SL_EV_TAMPER_HIGH		8
#define SL_EV_TAMPER_LOW		9
#define SL_EV_DOOR_FIRE			10

//Error events
#define SL_EV_WEI_PARITY_ERROR	254
#define SL_EV_ERROR				255


#define MAX_POLL_RESPONSE_TIME	2

//================================================================================

extern SYSInfo SysInfo;
extern SerPort PortObj[MAX_SER_PORT];
extern CARDNO_DATA_STORAGE_TYPE ReceivedCardNo;
char bufptr1[100];


unsigned char SendResetBufferRdr(unsigned char contid);

#ifdef RDPOLL_INCLUDE
/*** BeginHeader PollNextReader*/
void PollNextReader(void);
/*** EndHeader */
void PollNextReader(void)
{
unsigned char i;
i = 0;
GOTO_PollNextReaderUP:
	PollRdrNo++;
   	i++;
   	if(PollRdrNo >= MAX_POLL_DEVICES)
   	PollRdrNo = 0;
	if((PollDevices[PollRdrNo].EnDis == 1) && (PollDevices[PollRdrNo].Status == DEVICE_RESPONDING))
   	{	// Poll controller if same is enabled
	   	SendPollRdr(PollRdrNo);
		PollResponseTimeOut = 0;
        F_PollSent = SET;
   	}
   	else
   	{
      	if(i < MAX_POLL_DEVICES+1)
	   		goto GOTO_PollNextReaderUP;
      	else
      	{
        	F_RestartPollForAll = SET;
      	}
   	}
}

//------------------------------------------------------------------------------
/*** BeginHeader InitialiseSlave*/
unsigned char InitialiseSlave(void);
/*** EndHeader */
unsigned char InitialiseSlave(void)
{
	InitialiseDeviceStruct();
	F_RestartPollForAll = F_SerialSlaveDataProxy = F_Slave_DataStart = CLR;
	AllSlaveRestartTime = PollRdrNo = SlaveWaitTimeOut = 0;
	PollResponseTimeOut = 0;
	F_PollSent = CLR;
	RestartPollCount = 0;
   	F_RestartPollSelective = CLR;
   	return(0);
}

//------------------------------------------------------------------------------
/*** BeginHeader InitialiseDeviceStruct*/
unsigned char InitialiseDeviceStruct(void);
/*** EndHeader */
unsigned char InitialiseDeviceStruct(void)
{
unsigned char i;
unsigned int contendis;
   	contendis = 0x0001;

	if(SysInfo.ControllerMode == 4)
		SysInfo.ControllerMode = 4;
	else if(SysInfo.ControllerMode == 2)
		SysInfo.ControllerMode = 2;
	else
		SysInfo.ControllerMode = 8;

	if(SysInfo.SlaveType == 1)
		SysInfo.SlaveType = 1;
	else
		SysInfo.SlaveType = 2;

   	for(i=0;i<MAX_POLL_DEVICES;i++)
   	{

		PollDevices[i].ID = i + '1';         	
		if(SysInfo.SlaveType == 1)
		{
			PollDevices[i].Type = 1;
			PollDevices[i].NoRd = 1;	 		//2
			PollDevices[i].RdOffset = i;	//i*2;
		}
		else
		{
			PollDevices[i].Type = 2;
			PollDevices[i].NoRd = 2;	 		//2
			PollDevices[i].RdOffset = i*2;	//i*2;
		}
		PollDevices[i].TimeOut = 10;
      	if(SysInfo.ControllerEnDis  & contendis)
	   		PollDevices[i].EnDis = 1;
      	else
      		PollDevices[i].EnDis = 0;
		PollDevices[i].RCount = 0;
   		PollDevices[i].Status = DEVICE_RESPONDING;
		contendis = contendis << 1;		
   	}
	if(SysInfo.SlaveType == 1)
	{
		for(i=0; i<SysInfo.ControllerMode ;i++)
		{
			ReaderInfo[i].SlaveContNo = i;
		}
//		ReaderInfo[1].SlaveContNo = 1;
//		ReaderInfo[2].SlaveContNo = 2;
//		ReaderInfo[3].SlaveContNo = 3;
//	#ifndef BIO_METRIC
//		ReaderInfo[4].SlaveContNo = 4;
//		ReaderInfo[5].SlaveContNo = 5;
//		ReaderInfo[6].SlaveContNo = 6;
//		ReaderInfo[7].SlaveContNo = 7;
//	#endif	//BIO_METRIC
	}
	else
	{
		for(i=0; i<SysInfo.ControllerMode ;i++)
		{
			ReaderInfo[i].SlaveContNo = i/2;
		}
//		ReaderInfo[0].SlaveContNo = 0;
//		ReaderInfo[1].SlaveContNo = 0;
//		ReaderInfo[2].SlaveContNo = 1;
//		ReaderInfo[3].SlaveContNo = 1;
//	#ifndef BIO_METRIC
//		ReaderInfo[4].SlaveContNo = 2;
//		ReaderInfo[5].SlaveContNo = 2;
//		ReaderInfo[6].SlaveContNo = 3;
//		ReaderInfo[7].SlaveContNo = 3;
//	#endif	//BIO_METRIC
	}
   	return(0);
}
//------------------------------------------------------------------------------
/*** BeginHeader RestartPollForAllDevices*/
void RestartPollForAllDevices(void);
/*** EndHeader */
void RestartPollForAllDevices(void)
{
unsigned char i;
	for(i=0;i<MAX_POLL_DEVICES;i++)
	{
		if((PollDevices[i].Status == DEVICE_NOT_RESPONDING)/*&&(PollDevices[i].EnDis == 1)*/)
		{
			PollDevices[i].Status = DEVICE_RESPONDING;
			PollDevices[i].RCount = 0;
		}
	}
//	printf("***RESTARD ALL POLL \n");
}

/*** BeginHeader RestartPollForSelectDev*/
void RestartPollForSelectDev(void);
/*** EndHeader */
void RestartPollForSelectDev(void)
{
unsigned char i;
	RestartPollCount++;
	if(RestartPollCount >= MAX_POLL_DEVICES)
		RestartPollCount = 0;

	for(i=0;i<MAX_POLL_DEVICES;i++)
	{
		if((PollDevices[RestartPollCount].Status == DEVICE_NOT_RESPONDING) && (PollDevices[RestartPollCount].EnDis == 1))
		{
			PollDevices[RestartPollCount].Status = DEVICE_RESPONDING;
			PollDevices[RestartPollCount].RCount = 0;
//			printf("***RESTARD Sent To %d \n",RestartPollCount);
			break;
		}
		else
		{	
			RestartPollCount++;
			if(RestartPollCount >= MAX_POLL_DEVICES)
				RestartPollCount = 0;
		}
	}
}

//------------------------------------------------------------------------------
/*

Following command is used for reader polling and this also provides us to control some of o/p like led control etc.. 
We will create different command to do different output controls using 
$1li,command type,data1,data2,.....,chksum,enter

command =1   data1 = ignore,     Control by command
command =2   data1 = data to control both Reader .. Control by data1


*/
/*** BeginHeader SendPollRdr*/
unsigned char SendPollRdr(unsigned char contid);
/*** EndHeader */
unsigned char SendPollRdr(unsigned char contid)
{
unsigned char x;

// DRStruct[rdno].DRControlRdrData
	ClearSlaveSerBuffer();
	PortObj[SER_SLAVE_PORT].F_ChkSum = SET;
	PortObj[SER_SLAVE_PORT].ChkSum = 0;
	TransmitCharToX('$',SER_SLAVE_PORT);
//  TransmitCharToX(contid+SLAVE_CONT_BASE_ADDR,SER_SLAVE_PORT);
	TransmitCharToX(PollDevices[contid].ID,SER_SLAVE_PORT);
   	TransmitCharToX('l',SER_SLAVE_PORT);
	TransmitCharToX('i',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX('2',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	if(PollDevices[contid].NoRd == 2)
	{
//		x = DRStruct[contid*2].DRControlRdrData;
//		x = x+ (DRStruct[(contid*2)+1].DRControlRdrData*0x10);
		x = DRStruct[PollDevices[contid].RdOffset].DRControlRdrData;
		x = x + (DRStruct[PollDevices[contid].RdOffset+1].DRControlRdrData*0x10);

	}
	else
		x = DRStruct[PollDevices[contid].RdOffset].DRControlRdrData;

	SendDecimalToPC3CharToX(x,SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
   	return(0);
}

//------------------------------------------------------------------------------
/*** BeginHeader SendDoorOpenRdr*/
unsigned char SendDoorOpenRdr(unsigned char contid,unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno);
/*** EndHeader */
unsigned char SendDoorOpenRdr(unsigned char contid,unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno)
{
	ClearSlaveSerBuffer();
	PortObj[SER_SLAVE_PORT].F_ChkSum = SET;
	PortObj[SER_SLAVE_PORT].ChkSum = 0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
   	TransmitCharToX(contid+'0',SER_SLAVE_PORT);     //anjana 20 Aug
   	TransmitCharToX('l',SER_SLAVE_PORT);
   	TransmitCharToX('O',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX('0',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(HexToAscii(doorno),SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(time,SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(dotltime,SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(channelno+1,SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
	if(WaitForSlaveResponse(3) == 0)
   		return(0);
   	else
   		return(0xff);
}

/*** BeginHeader SendDoorOpenChannel*/
unsigned char SendDoorOpenChannel(unsigned char channelno);
/*** EndHeader */
unsigned char SendDoorOpenChannel(unsigned char channelno)
{
unsigned char contid;
	ClearSlaveSerBuffer();
	if(channelno >= MAX_READERS_SUPPORT)
		return(0xFF);
	contid = ReaderInfo[channelno].SlaveContNo;
	PortObj[SER_SLAVE_PORT].F_ChkSum = SET;
	PortObj[SER_SLAVE_PORT].ChkSum = 0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
   	TransmitCharToX(PollDevices[contid].ID,SER_SLAVE_PORT);     
   	TransmitCharToX('l',SER_SLAVE_PORT);
   	TransmitCharToX('O',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX('0',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	if( PollDevices[contid].NoRd == 2)
	{
   		TransmitCharToX((channelno%2)+'1',SER_SLAVE_PORT);		
	}
	else
		TransmitCharToX('1',SER_SLAVE_PORT);

   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(ReaderInfo[channelno].DOpTime,SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(ReaderInfo[channelno].DOTLTime,SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	if(PollDevices[contid].NoRd == 2)
	{
		TransmitCharToX((channelno%2)+'1',SER_SLAVE_PORT);		
	}
	else
		TransmitCharToX('1',SER_SLAVE_PORT);		
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
	if(WaitForSlaveResponse(3) == 0)
   		return(0);
   	else
   		return(0xff);
}

/*--------------------------------------------------------------------------------------------------------
Slave command	//ARMD0167
$1lR,0,ChannelNo,EventCode,CardNo,DoorOpenTime,DOTLSenseTime,DoorNo,BUZType,Dummy,Chksum,ENT
Whereas,
ChannelNo = 0 or 1
Slave response
#1R,000,6D
--------------------------------------------------------------------------------------------------------*/
/*** BeginHeader SendSlaveDoorControl*/
unsigned char SendSlaveDoorControl(unsigned char channelno,unsigned char eventcode,unsigned char buzzercode);
/*** EndHeader */
unsigned char SendSlaveDoorControl(unsigned char channelno,unsigned char eventcode,unsigned char buzzercode)
{
unsigned char contid;
	ClearSlaveSerBuffer();
	if(channelno >= MAX_READERS_SUPPORT)
		return(0xFF);
	contid = ReaderInfo[channelno].SlaveContNo;
	PortObj[SER_SLAVE_PORT].F_ChkSum = SET;
	PortObj[SER_SLAVE_PORT].ChkSum = 0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
   	TransmitCharToX(PollDevices[contid].ID,SER_SLAVE_PORT);  //send slave id   
   	TransmitCharToX('l',SER_SLAVE_PORT);
   	TransmitCharToX('R',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX('0',SER_SLAVE_PORT);//sub command
   	TransmitCharToX(',',SER_SLAVE_PORT);
	if(PollDevices[contid].NoRd == 2)   //send channel number
	{
   		TransmitCharToX((channelno%2)+'1',SER_SLAVE_PORT);		
	}
	else
		TransmitCharToX('1',SER_SLAVE_PORT);

   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(eventcode,SER_SLAVE_PORT);	//EventCode
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	SendDecimalLongToX(ReceivedCardNo,SER_SLAVE_PORT); //CardNo
   	TransmitCharToX(',',SER_SLAVE_PORT); 
	SendDecimalToPC3CharToX(ReaderInfo[channelno].DOpTime,SER_SLAVE_PORT);	//DoorOpenTime,
   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(ReaderInfo[channelno].DOTLTime,SER_SLAVE_PORT);	//DOTLSenseTime,
   	TransmitCharToX(',',SER_SLAVE_PORT);
	if(PollDevices[contid].NoRd == 2)	//door no.
	{
		TransmitCharToX((channelno%2)+'1',SER_SLAVE_PORT);		
	}
	else
		TransmitCharToX('1',SER_SLAVE_PORT);		
   	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(buzzercode,SER_SLAVE_PORT);	//Sound Type
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(' ',SER_SLAVE_PORT); //dummy space
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);	//checksum
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT); //ENT
	if(WaitForSlaveResponse(3) == 0)
   		return(0);
   	else
   		return(0xff);
}

//==============================================================================
/*** BeginHeader HandleSlaveSerialData*/
//unsigned char HandleSlaveSerialData(unsigned char serdata);
/*** EndHeader */
/*unsigned char HandleSlaveSerialData(unsigned char serdata)
{
   	if(serdata == '#')
   	{
		SlaveWaitTimeOut = 0;
   		SlaveSerBuffer[0] = '#';
      	PortObj[SER_SLAVE_PORT].RxPtr = 0;
      	F_Slave_DataStart = SET;
   	}
   	else if(F_Slave_DataStart == SET)
   	{
		SlaveWaitTimeOut = 0;
   		PortObj[SER_SLAVE_PORT].RxPtr ++;
	   	if(PortObj[SER_SLAVE_PORT].RxPtr >= PortObj[SER_SLAVE_PORT].MAXINBUF)
      	{
			F_SerialSlaveDataProxy = SET;
			F_Slave_DataStart = CLR;
      	}
      	else
		{
         	SlaveSerBuffer[PortObj[SER_SLAVE_PORT].RxPtr] = serdata;
         	if((serdata == SLAVE_TERMINATOR1) || (serdata == SLAVE_TERMINATOR1))
         	{
				F_SerialSlaveDataProxy = SET;
		      	F_Slave_DataStart = CLR;
	         	SlaveSerBuffer[PortObj[SER_SLAVE_PORT].RxPtr+1] = '\0';
         	}
      	}
  	}
	return(0);
}
*/
//------------------------------------------------------------------------------

/*** BeginHeader WaitForSlaveResponse*/
unsigned char WaitForSlaveResponse(unsigned int  time);
/*** EndHeader */
unsigned char WaitForSlaveResponse(unsigned int time)
{
 	while(1)
 	{
     	if(PortObj[SER_SLAVE_PORT].F_SerProxy == SET)
		{
	   		PortObj[SER_SLAVE_PORT].F_SerProxy = CLR;
			return(0);
   		}
     	if(SlaveWaitTimeOut >= time)
      	{
         	return(0xFF);
      	}
 	}
}


//==============================================================================
// Response will be
// #<contno>D,status,channelno,cardno,facilitycode,pending events,
// status = 0   no card/ event in buffer received
// status = 1   card received
// status = 2   egress switch pressed
// statu =  3   DOTL
// status = 4   door forced open
// status = 5	 fire detected
// status = 10  system just started
//#1D,Event Status,Event Door,Event Card No,Event Facility Code,0,chksum,Ent

/*** BeginHeader ProcessRdrPollResponse*/
unsigned char ProcessRdrPollResponse(unsigned char *buffer,unsigned char contno);
/*** EndHeader */
unsigned char ProcessRdrPollResponse(unsigned char *buffer,unsigned char contno)
{
unsigned char status,channelno,rdno,contevent;
unsigned int fcode;
CARDNO_DATA_STORAGE_TYPE cardno;
//	printf("Data Received %s \n",buffer);
	if(((buffer[1] - SLAVE_CONT_BASE_ADDR) == contno) && (buffer[0] == '#'))
	{
		if(GetDataByPosition((unsigned char *)bufptr1,buffer,2) == NULL)	// Read card number
			goto GOTO_RdrPollBadResponseERROR;
	  	status = atoi((char *)bufptr1) & 0x0ff;
		if(status == SL_EV_NO_EVENT)		//As we have received No Event so break and do not do any processing.
			goto GOTO_RdrPollResponseERROR;

		if(GetDataByPosition((unsigned char *)bufptr1,buffer,3) == NULL)	// Read card number
			goto GOTO_RdrPollBadResponseERROR;
		channelno = atoi((char *)bufptr1) & 0x0ff;
//      rdno = POLL_READER_START_BASE + ( (contno*2) + (channelno+1));

		if(PollDevices[contno].NoRd == 2)
		{
			if(channelno <= PollDevices[contno].NoRd)
				rdno = PollDevices[contno].RdOffset + channelno + 1;	// added 1 just to support our design where our reader no started from 1 
			else
				goto GOTO_RdrPollResponseERROR;	
		}
		else
			rdno = PollDevices[contno].RdOffset + 1;	//if not o readers is one then we should treat all readers as channel 1
		if(GetDataByPosition((unsigned char *)bufptr1,buffer,4) == NULL)	// Read card number
			goto GOTO_RdrPollBadResponseERROR;
		cardno = (CARDNO_DATA_STORAGE_TYPE)StrDecToLong((unsigned char *)bufptr1,10);
		if(GetDataByPosition((unsigned char *)bufptr1,buffer,5) == NULL)	// Read card number
			goto GOTO_RdrPollBadResponseERROR;
		fcode = atoi((char *)bufptr1) & 0x0ff;
		if(Doorinfo.CardMask == 16)     						//D0020
      		cardno = cardno & 0x0000FFFF;
		if(Doorinfo.CardMask == 24)     						//D0020
      		cardno = cardno & 0x00FFFFFF;
//		if((DisplayMode == MODE_MEMORY_FULL) || (F_TrnxMemFull == SET))        		 //D0011
//      	goto GOTO_RdrPollResponseERROR;
		switch(status)
		{
      		case SL_EV_NO_EVENT:
         		break;
        	case SL_EV_CARD_RECEIVED:
	         	CurrentUser.RdrNo = rdno;
				ReceivedCardNo = CurrentUser.SearchCard.CardNo = cardno;
				CurrentUser.InputType = INPUT_FROM_SLAVE_POLL;
	         	CurrentUser.FCode = fcode;
		      	ProcessCard(CurrentUser.RdrNo);
         		break;
         	case SL_EV_EGRESS:
				contevent = EVENT_DOOR_OPEN_EGRESS;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		break;
         	case SL_EV_DOTL_ALARM:
				contevent = EVENT_DOTL1_ALARM;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		break;
	        case SL_EV_FORCE_ALARM:
				contevent = EVENT_FORCE1_ALARM;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		break;
         	case SL_EV_ALARM_LOW:
         		contevent = EVENT_DOTL1_ALARM_OFF;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		break;
         	case SL_EV_DOOR_NOT_OPENED:
         		contevent = EVENT_DOOR_NOT_OPEN;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		break;
         	case SL_EV_DOOR_FIRE:
         		contevent = EVENT_FIRE_ALARM_HIGH;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		break;
         	case SL_EV_SLAVE_RESTART:
         		contevent = EVENT_SYSTEM_RESET;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
         		F_UpdateSlaveInfo = SET;
         		break;
         	case SL_EV_TAMPER_LOW:
         		contevent = EVENT_TAMPER_ALARM_LOW;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)1,rdno,contevent,0,0);
         		break;
         	case SL_EV_TAMPER_HIGH:
         		contevent = EVENT_TAMPER_ALARM_HIGH;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)1,rdno,contevent,0,0);
         		break;

			case SL_EV_WEI_PARITY_ERROR:
         		contevent = EVENT_WEI_PARITY_ERROR;
				StoreCardInTrDBFull((CARDNO_DATA_STORAGE_TYPE)cardno,rdno,contevent,0,0);
				break;

         	case SL_EV_ERROR:
				goto GOTO_RdrPollBadResponseERROR;
		}
		if(status != 0)
		{
			if(GetDataByPosition((unsigned char *)bufptr1,buffer,3) == NULL)   // Read card number
				goto GOTO_RdrPollBadResponseERROR;
			channelno = atoi((char *)bufptr1) & 0x0ff;
			rdno = POLL_READER_START_BASE + (((contno) * 2) + (channelno + 1));
	      //printf("Data Received %d RDNO  %d CHNO %d \n",status,rdno,channelno);
		}
	}
	else
	{
		MsgPrint(MSG_SLAVE_COMM,PortObj[SER_SLAVE_PORT].RxPtr,"Not received required data SlaveReceiveCount=");			
GOTO_RdrPollBadResponseERROR:
		MsgPrint(MSG_SLAVE_COMM,status,"Bad data from status=");	
		if(F_SerialSlaveDataProxy)
			MsgPrint(MSG_SLAVE_COMM,1,"F_SerialSlaveDataProxy=");					
		if(BadDataCounter <= 0xFFFE)
			BadDataCounter ++;
		MsgPrint(MSG_SLAVE_COMM,BadDataCounter,"Bad data from Slave BadDataCounter=");	
		if(BadDataDayCounter <= 0xFFFE)
			BadDataDayCounter ++;
	}

GOTO_RdrPollResponseERROR:
	return(0);
}

/*** BeginHeader ClearSlaveSerBuffer */
void ClearSlaveSerBuffer(void) ;
/*** EndHeader */
void ClearSlaveSerBuffer(void)
{
	PortObj[SER_SLAVE_PORT].RxPtr = 0;
	memset(SlaveSerBuffer,0,sizeof(SlaveSerBuffer));
   	SlaveWaitTimeOut = 0;
   	F_Slave_DataStart = CLR;
	F_SerialSlaveDataProxy = CLR;
}
//==============================================================================
// Following function is called in mail loop when poll command is send so that
// we handle poll receive data in mail loop and user can manage the poll response.
// This will not keep system busy while we are polling.
/*** BeginHeader ManagePollResponse*/
void ManagePollResponse(void);
/*** EndHeader */
void ManagePollResponse(void)
{
	if((PollResponseTimeOut >= MAX_POLL_RESPONSE_TIME) && (F_SerialSlaveDataProxy == CLR))
	{
		F_PollSent = CLR;
   		PollDevices[PollRdrNo].RCount ++;
      	if(PollDevices[PollRdrNo].RCount >= 2)
		{	
			PollDevices[PollRdrNo].Status = DEVICE_NOT_RESPONDING;
         	PollDevices[PollRdrNo].ActualStatus = DEVICE_NOT_RESPONDING;
			if(SlaveNoResponseCounter <= 0xFFFE)  
				SlaveNoResponseCounter ++;
			MsgPrint(MSG_SLAVE_COMM,PollRdrNo+1,"Poll Reader No=");
			MsgPrint(MSG_SLAVE_COMM,SlaveNoResponseCounter,"No Response from Slave SlaveNoResponseCounter=");
			if(NoRespDayCounter <= 0xFFFE)  
				NoRespDayCounter++; 
      	}
	}
	else
	{
     	if(F_SerialSlaveDataProxy == SET)
		{
	   		F_SerialSlaveDataProxy = CLR;
			if(VerifyRecChecksum((PortObj[SER_SLAVE_PORT].RxPtr - 4),SlaveSerBuffer) != 0)
			{
				if(BadDataCounter <= 0xFFFE)
					BadDataCounter ++;
				MsgPrint(MSG_SLAVE_COMM,BadDataCounter,"Bad data from Slave BadDataCounter=");	
				if(BadDataDayCounter <= 0xFFFE)
					BadDataDayCounter ++;
				return;			//do not process data if chksum not matched
			}
			ProcessRdrPollResponse((unsigned char*)SlaveSerBuffer,PollRdrNo);
   			F_PollSent = CLR;
         	PollDevices[PollRdrNo].ActualStatus = DEVICE_RESPONDING;
   		}
	}
}
//==============================================================================
/*** BeginHeader InitialiseSlaveController*/
void InitialiseSlaveController(void);
/*** EndHeader */
void InitialiseSlaveController(void)
{
unsigned int i;
   	for(i=0;i<MAX_POLL_DEVICES;i++)
	{
		if(PollDevices[i].EnDis == 1)
   		{	
	   		SendResetBufferRdr(i);
		}
	}
}
//==============================================================================
unsigned char SendResetBufferRdr(unsigned char contid)
{
	ClearSlaveSerBuffer();
	PortObj[SER_SLAVE_PORT].F_ChkSum = SET;
	PortObj[SER_SLAVE_PORT].ChkSum = 0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
//	TransmitCharToX(contid+SLAVE_CONT_BASE_ADDR,SER_SLAVE_PORT);
	TransmitCharToX(PollDevices[contid].ID,SER_SLAVE_PORT);	
   	TransmitCharToX('l',SER_SLAVE_PORT);
	TransmitCharToX('J',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX('1',SER_SLAVE_PORT);
   	TransmitCharToX('2',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCharToX('2',SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
	if(WaitForSlaveResponse(3) == 0)
   		return(0);
   	else
		return(1);
}
//==============================================================================
// This function will add data in to device poll queue so that we cansend data.
//
unsigned char AddToSendQueue(unsigned char channelno,unsigned char cmd,unsigned char data1,unsigned char data2, unsigned char data3,unsigned char data4,unsigned char data5)
{  
   	SendQueue[SendQueueWr].Device = channelno;
   	SendQueue[SendQueueWr].Cmd = cmd;
   	SendQueue[SendQueueWr].Data1 = data1;
   	SendQueue[SendQueueWr].Data2 = data2;
   	SendQueue[SendQueueWr].Data3 = data3;
   	SendQueue[SendQueueWr].Data4 = data4;
	SendQueue[SendQueueWr].Data5 = data5;

	SendQueueWr ++;
	if(SendQueueWr >= MAX_SEND_QUEUE)
		SendQueueWr = 0;
	return(0);
}

// Following function reads data from queue and sends same to Devices
// We have implemented this for future use but rt now used for testing of egress.
// this will mainly get used when we have relay control at devices level
unsigned char SendFromSendQueue(void)
{  
	if(SendQueueWr == SendQueueRd)
		return(1);
	switch(SendQueue[SendQueueRd].Cmd)
	{
		case QUEUE_CMD_WEI_LED_ON:
			if(SendDoorOpenChannel(SendQueue[SendQueueRd].Device) != 0)
				SendDoorOpenChannel(SendQueue[SendQueueRd].Device);
//			if( SendDoorOpenRdr(SendQueue[SendQueueRd].Device,SendQueue[SendQueueRd].Data1,\
//				SendQueue[SendQueueRd].Data2,SendQueue[SendQueueRd].Data2,\
//					SendQueue[SendQueueRd].Data4) !=0)
//				SendDoorOpenRdr(SendQueue[SendQueueRd].Device,SendQueue[SendQueueRd].Data1,\
//					SendQueue[SendQueueRd].Data2,SendQueue[SendQueueRd].Data2,\
//						SendQueue[SendQueueRd].Data4);
			break;
	}
	SendQueueRd ++;
	if(SendQueueRd >= MAX_SEND_QUEUE)
		SendQueueRd = 0;
	return(0);
}

//following function is used to verify received data checksum
unsigned char VerifyRecChecksum(unsigned short datacnt, unsigned char *buffer)
{
unsigned char chksum, rec_chksum;
unsigned short icnt;

	chksum = 0;
	for(icnt=0;icnt<datacnt;icnt++)
		chksum ^= buffer[icnt];
	rec_chksum = AsciiToHex(buffer[datacnt]);
	rec_chksum = (rec_chksum * 16) + AsciiToHex(buffer[datacnt+1]);
	if(chksum != rec_chksum)
	{
		MsgPrint(MSG_SLAVE_COMM,chksum,"Calculated Chksum=");	
		MsgPrint(MSG_SLAVE_COMM,rec_chksum,"Receieved Chksum=");	
		MsgPrint(MSG_SLAVE_COMM,1,"Chksum Error=");	
		return(1);
	}
	else 
		return(0);
}

#ifdef NOT_IN_USE_FUNCTIONS
/*
Following functions are not in use and they may be required if we have 
slave with realy to control door.
*/
//------------------------------------------------------------------------------
// Following command is send to open different type of doors open options
/// 0 ==> Access pen for time
// 1 ==> Door always open
// 2  ==> Door always close
// 3 ==> Make door normal
/*** BeginHeader SendDoorOpenRdrType*/
unsigned char SendDoorOpenRdrType(unsigned char opentype, unsigned char contid,unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno);
/*** EndHeader */
unsigned char SendDoorOpenRdrType(unsigned char opentype, unsigned char contid,unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno)
{
	ClearSlaveSerBuffer();
	PortObj[SER_SLAVE_PORT].F_ChkSum=SET;
	PortObj[SER_SLAVE_PORT].ChkSum=0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
   	TransmitCharToX(contid+'0',SER_SLAVE_PORT);    
   	TransmitCharToX('l',SER_SLAVE_PORT);
   	TransmitCharToX('O',SER_SLAVE_PORT);
	if(opentype == 0)
   	{
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	TransmitCharToX('0',SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	TransmitCharToX(HexToAscii(doorno),SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	SendDecimalToPC3CharToX(time,SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	SendDecimalToPC3CharToX(dotltime,SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	SendDecimalToPC3CharToX(channelno+1,SER_SLAVE_PORT);
   	}
   	else
   	{
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	TransmitCharToX(opentype+'0',SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
   	}
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
	if(WaitForSlaveResponse(3) ==0)
   		return(0);
   	else
   		return(0xff);
}

//------------------------------------------------------------------------------
/*** BeginHeader SendDoorCommand*/
unsigned char SendDoorCommand(unsigned char contid,unsigned char cmdtype, unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno);
/*** EndHeader */
unsigned char SendDoorCommand(unsigned char contid,unsigned char cmdtype,unsigned char doorno,unsigned char time,unsigned char dotltime,unsigned char channelno)
{
	ClearSlaveSerBuffer();
	PortObj[SER_SLAVE_PORT].F_ChkSum=SET;
	PortObj[SER_SLAVE_PORT].ChkSum=0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
   	TransmitCharToX(contid+'0',SER_SLAVE_PORT);     
   	TransmitCharToX('l',SER_SLAVE_PORT);
   	TransmitCharToX('O',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(cmdtype+'0',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCharToX(HexToAscii(doorno),SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
	if(cmdtype==0)
   	{
		SendDecimalToPC3CharToX(time,SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	SendDecimalToPC3CharToX(dotltime,SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	   	SendDecimalToPC3CharToX(channelno+1,SER_SLAVE_PORT);
	   	TransmitCharToX(',',SER_SLAVE_PORT);
	}
	TransmitCheckSumX(SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
	if(WaitForSlaveResponse(3) ==0)
   		return(0);
   	else
   		return(0xff);
}

/*** BeginHeader SendRdrInfoToSlave*/
unsigned char SendRdrInfoToSlave(unsigned char contid,unsigned char rdno);
/*** EndHeader */
unsigned char SendRdrInfoToSlave(unsigned char contid,unsigned char rdno)
{
	ClearSlaveSerBuffer();
	PortObj[SER_SLAVE_PORT].F_ChkSum=SET;
	PortObj[SER_SLAVE_PORT].ChkSum=0;
   	TransmitCharToX('$',SER_SLAVE_PORT);
   	TransmitCharToX(contid+'0',SER_SLAVE_PORT);
   	TransmitCharToX('l',SER_SLAVE_PORT);
   	TransmitCharToX('J',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX('1',SER_SLAVE_PORT);
   	TransmitCharToX('1',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCharToX(rdno-2+'1',SER_SLAVE_PORT);
   	TransmitCharToX(',',SER_SLAVE_PORT);
   	SendDecimalToPC3CharToX(ReaderInfo[rdno].DOpTime,SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	SendDecimalToPC3CharToX(ReaderInfo[rdno].DOTLTime,SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(ReaderInfo[rdno].DOTLEn_Dis==0?'0':'1',SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(ReaderInfo[rdno].SharedDOTL==0?'0':'1',SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(ReaderInfo[rdno].FacCheck==0?'0':'1',SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(ReaderInfo[rdno].PinEnDis==0?'0':'1',SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
	SendDecimalToPC3CharToX(rdno+'1',SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
	TransmitCheckSumX(SER_SLAVE_PORT);
	TransmitCharToX(',',SER_SLAVE_PORT);
   	TransmitCharToX(SLAVE_TERMINATOR1,SER_SLAVE_PORT);
	if(WaitForSlaveResponse(3) ==0)
   		return(0);
	return(1);
}

*----------------------------------------------------------------------------*/
/*** BeginHeader DoorOpenForTime*/
unsigned char DoorOpenForTime11(unsigned char channelno);
/*** EndHeader */
unsigned char DoorOpenForTime11(unsigned char channelno)
{
//	Temp1SecCounter=0;
#ifdef SUPPORT_ONLY_4_DOOR
   if(channelno<=4)
		DoorConditionControl(channelno-1,DR_ACCESS_OPEN,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime);
   else
   	return(0xFF);
#else

   if(channelno>2)
   {
	   if( SendDoorOpenRdr( ReaderInfo[channelno-1].SlaveContNo,ReaderInfo[channelno-1].DoorNo,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime,channelno-3) !=0)
	   	if( SendDoorOpenRdr( ReaderInfo[channelno-1].SlaveContNo,ReaderInfo[channelno-1].DoorNo,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime,channelno-3) !=0)
         	return(0xff);
	}
	else
   {
		DoorConditionControl(channelno-1,DR_ACCESS_OPEN,ReaderInfo[channelno-1].DOpTime,ReaderInfo[channelno-1].DOTLTime);
   }
#endif
	return(0);
}

//==============================================================================================================


#endif
#endif// #ifdef RDPOLL_INCLUDE

