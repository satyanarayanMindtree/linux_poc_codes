/*** BeginHeader SmartCard*/
#define MAX_SMART_SER_BUFF		128

#define SMART_START_RESPONSE_CHAR	'#'
#define SMART_TERMINATOR2			'\n'
#define SMART_TERMINATOR1			'\r'

#define SMART_CARD_COMMAND_POSITION		1
#define ENABLE_SMART_CARD()		{F_SMART_CARD_COMM = SET;}
#define DISABLE_SMART_CARD()	{F_SMART_CARD_COMM= CLR;}

#define MI_OK 	0
#define STATUS_SMART_CARD_SUCCESS			0
#define SMART_CARD_BLOCK_LENGTH				16

#define SMART_CARD_COMM_ERROR				0xFF
#define STATUS_SMART_CARD_COMM_TIME_OUT		0xFE

#define MI_TIME_OUT								((char)-30)
#define SMART_CARD_READ_ERROR					MI_READERR
#define STATUS_SMART_CARD_WRITE_ERROR		MI_WRITEERR

#define MI_ERROR                     	 ((char)-1)
#define MI_NOTAGERR                     ((char)-1)
#define MI_CHK_FAILED                   ((char)-1)
#define MI_CRCERR                       ((char)-2)
#define MI_CHK_COMPERR                  ((char)-2)
#define MI_EMPTY                        ((char)-3)
#define MI_AUTHERR                      ((char)-4)
#define MI_PARITYERR                    ((char)-5)
#define MI_CODEERR                      ((char)-6)

#define MI_SERNRERR                     ((char)-8)
#define MI_KEYERR                       ((char)-9)
#define MI_NOTAUTHERR                   ((char)-10)
#define MI_BITCOUNTERR                  ((char)-11)
#define MI_BYTECOUNTERR                 ((char)-12)
#define MI_IDLE                         ((char)-13)
#define MI_TRANSERR                     ((char)-14)
#define MI_WRITEERR                     ((char)-15)
#define MI_INCRERR                      ((char)-16)
#define MI_DECRERR                      ((char)-17)
#define MI_READERR                      ((char)-18)
#define MI_OVFLERR                      ((char)-19)
#define MI_POLLING                      ((char)-20)
#define MI_FRAMINGERR                   ((char)-21)
#define MI_ACCESSERR                    ((char)-22)
#define MI_UNKNOWN_COMMAND              ((char)-23)
#define MI_COLLERR                      ((char)-24)
#define MI_RESETERR                     ((char)-25)
#define MI_INITERR                      ((char)-25)
#define MI_INTERFACEERR                 ((char)-26)
#define MI_ACCESSTIMEOUT                ((char)-27)
#define MI_NOBITWISEANTICOLL            ((char)-28)
#define MI_QUIT                         ((char)-30)
#define MI_CODINGERR                    ((char)-31)
#define MI_RECBUF_OVERFLOW              ((char)-50)
#define MI_SENDBYTENR                   ((char)-51)
#define MI_CASCLEVEX                    ((char)-52)
#define MI_SENDBUF_OVERFLOW             ((char)-53)
#define MI_BAUDRATE_NOT_SUPPORTED       ((char)-54)
#define MI_SAME_BAUDRATE_REQUIRED       ((char)-55)
#define MI_WRONG_PARAMETER_VALUE        ((char)-60)
#define MI_BAD_VALUE_DATA               ((char)-70)

#ifndef SUPPORT_ICLASS_RDR
#define ERR_SC_LAYOUT_ERROR            ((char)-71)
#define ERR_SC_NO_TEMPLATE             ((char)-72)
#endif

//=====================================================
// Smart card command defination
#define SMART_POLL_CARD		 				'P'
#define SMART_READ_CARD						'R'
#define SMART_WRITE_CARD					'W'
#define SMART_AUTH_READ_BLOCK 			'X'
#define SMART_AUTH_WRITE_BLOCK			'Y'
#define SMART_CARD_HALT_COMMAND			'H'
#define SMART_DECREMENT_BLOCK				'Q'
#define SMART_AUTH_BLOCK					'U'
#define SMART_KEY_SEND						'J'
#define SMART_LED_CONTROL					'o'
#define SMART_CARD_REQUEST					'S'			
#define SMART_REQ_ANTI_SEL_AUTH_CARD		'Z'


//=====================================================


#define POLL_DELAY_TIME                10
#define  SendDelayedPollCommandToSmartCard()	{ if(SCReaderNo ==2 ) \
																SC2_PollTime = POLL_DELAY_TIME -1; \
                                               else \
																SC1_PollTime = POLL_DELAY_TIME -1; \
                                                }
#define  NormalPollCommandToSmartCard()	{ if(SCReaderNo ==2 ) \
																SC2_PollTime = POLL_DELAY_TIME; \
                                               else \
																SC1_PollTime = POLL_DELAY_TIME; \
                                                }

// Location in smart card from where we have to read employee name
#define SMART_EMP_NAME_BLOCK 			0x02

// Poll type to poll reader to get card number when card is shown this is for asynchronous


#define SMART_TERMINATOR2			'\n'
#define SMART_TERMINATOR1			'\r'

#define SMART_CARD_COMMAND_TIMEOUT		10
#define SMART_POLL_TYPE_FOR_CARD_NO		'3'			   //7

// Following variables are used for smartcard polling and will decide which reader has received card
// we should use structure for same but it is giving some problem so i have used variables

extern BYTE SmartCardSerBuffer[MAX_SMART_SER_BUFF];

#define SmartSerBuffer					PortObj[SER_SMART_RD1_PORT].RxBuffer
#define F_SerialSmartCardCommandProxy	PortObj[SER_SMART_RD1_PORT].F_SerProxy		//ARMD0440
#define SerERcvdCnt						PortObj[SER_SMART_RD1_PORT].RxPtr

__packed typedef struct SMART_CARD_DATA
{
	unsigned long CardNo;
	unsigned long CSN;
   	unsigned long EMP_NO; 
   	unsigned char EmpNo[16];   
	unsigned int  Template;
	unsigned char NoOfTemp;
	unsigned char TempPos[4];
   	struct tm VDate;
	unsigned int Pin;
	unsigned char Name[16];
	unsigned char CType;
	unsigned char CLayout;
}SmartCardData;

extern BYTE F_ReceiveSmartCardPortData;	 //F_Receive_SerialPortE_Data
extern BYTE SC1_PollTime,SC1_F_Poll;
extern BYTE  SCReaderNo;

extern void HandleSerialSmartCardReceiveData(char readerno,char *scbuffer);
extern char SendLEDContToSCReader(BYTE type,BYTE time);
extern char SendCommandToSCReader( char *buffer,unsigned char len, char *outstr);
extern char SendKeyToSCReader(BYTE keytype,BYTE sector,BYTE *buffer);
extern char SendKeyToSmartCardReader(BYTE *buffer);
extern void HandleSerSCData(BYTE n,BYTE readerno);
extern void HandleSerialSmartCardData(BYTE n,BYTE *smartpollbuff);
extern char TransmitCharToSmart(BYTE data);
extern char WriteSmartCardBlock(BYTE block, BYTE datalength,BYTE *sdata);
extern char WaitSmartCardResponse(WORD timeout,BYTE scrdnumber);
extern char AuthReadSmartCardBlock(BYTE block,DWORD *cardno,BYTE *rBuffer);
extern void SendHaltToSmartCard(void);
extern char SendSpecialPollCommandSC(BYTE poll,BYTE key, BYTE sector, BYTE block);
extern void SendPollCommandToSmartCard(void);
extern char SmartDecrementBlock(BYTE block,DWORD value);
extern char ReadSmartCardBlock(BYTE block,BYTE *rbuffer);
extern char ReadSmartCardValue(BYTE block, DWORD *value);
extern char AuthSmartCard(BYTE key,BYTE sector,BYTE block);
extern void SmartCardSerialMainLoop(void);
extern void MainLoopPollForSCardRDR(void);	 
extern unsigned char ReadSmartCardDataBlock(unsigned char boffset,unsigned int bsize,unsigned char *buffer,unsigned char clayout);
extern char ReqAntiSelAuthSmartCard(unsigned char key, unsigned char sector,unsigned char block,unsigned long *card);
extern char SMARTReaderNo,SerialECheckSum;

extern void MainLoopPollForIClassRDR(void);
extern unsigned char MainLoopIClassRDR(void);

