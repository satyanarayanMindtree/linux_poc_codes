
#ifndef __SERIAL_H
#define __SERIAL_H



#define EX_ShareDotl    1
#define FaclityCodeChk  2
#define APB_EANABLE     4

#define MSG_ERROR 		0x01
#define MSG_INFO  		0x02
#define MSG_WARNING  	0x04
#define MSG_SMART_CARD 	0x08
#define MSG_MEM			0x10
#define MSG_DOOR_CONT	0x20
#define MSG_SLAVE_COMM	0x40
//#define MSG_DISP_ALL	0xff
#define MSG_DISP_ALWAYS	0x80



//#define TransmitChar  TransmitCharToPC
// serial transmit for  port

//#define TransmitChar  serDputc



//#define SER_PORT_B		0
//#define SER_PORT_C		1
//#define SER_PORT_D      2
//#define SER_PORT_E      3
//#define SER_TCPIP_PORT		10
//#define MAX_NW_TX_BUFF		800

//#define PC_PORT  SER_PORT_D


//unsigned char NWTxBuffer[MAX_NW_TX_BUFF];  Not used as of today



extern char Checksum(WORD ReceiveCount);
extern BYTE AsciiToHex( BYTE temp);
extern BYTE ConvertAsciiToHex(BYTE position);
extern BYTE ConvertAsciiSbuffToHex(BYTE position);
extern void Trnsdata(BYTE count);
extern BYTE SwapChar(BYTE data1);
extern BYTE HexToAscii(BYTE temp);
extern void HandleSerialCmd(unsigned char port);
extern void SendtoEthernet(void);
extern void SendSerialDataToEthernetPort(WORD socketno);
//extern void SetRTCTimeDate(RTCTime Datetime,BYTE weekday);
//extern void HandelSerialUnlockDoor(void);
extern void Hexto5Ascii(WORD tdata);
extern void Hexto3Ascii(BYTE tempdata);
extern void Hexto2Ascii(BYTE tempdata);
extern  WORD FiveAsciiToHex(volatile BYTE *ptr);
extern BYTE ThreeAsciiToHex(volatile BYTE *ptr);
extern WORD HexNoToInteger(BYTE *ptr);
extern void HandelSerialInitialise(void);
extern void HandleAllCardDelete(void);
extern void HandleAllTrnxDelete(void);
extern void HandelSerialMemoryMap(void);
extern void SendIntBCDToPC(WORD data1);
extern void MsgPrint(BYTE msgtype,long msgdata,  BYTE *str);
extern void SendDecimalIntToPC(WORD tdata);
extern void TransmitStrToPC(BYTE *str);
extern short SendBulkTransaction(void);
extern short  SendTransaction(void);
//extern void HandelSerialSendTrans(TrnxData trans);
extern void HandleGetCommands(BYTE command ,unsigned char port);
extern void TransmitCheckSum(void);
extern void TransmitReplyStart(void);
extern void TransmitReplyStartToX(BYTE port);
extern void TransmitChar(BYTE t_data);
extern BYTE SerialAsciiToHex(volatile BYTE *ptr);
extern BYTE SerialDecimalToHex(volatile BYTE *ptr);
extern void SendDecimalToPC(BYTE temp);
extern void SendDecimalToPC3Char(BYTE temp);
extern void SendAsciiToPC(BYTE temp);
extern short DumpAllCardData(void);
//extern void SendCardDataToPC(int pos, CardData);

extern short AddMultipleTestCards(int cardnos);
extern void SendDecimalLongToX(DWORD tdata,BYTE port);
//extern char TransmitCharToX(BYTE t_data,BYTE port);
extern void TransmitCheckSumX(BYTE port);
extern unsigned long StrDecToLong(BYTE *str, BYTE len);
extern void SendIntBCDToX( WORD data1,BYTE port);
extern void MsgPrintX(BYTE msgtype, long msgdata,  BYTE *str,BYTE port);
extern void SendDecimalIntToX(WORD tdata,BYTE port);
extern void TransmitStrToX(BYTE *str,BYTE port);
extern void SendDecimalToPC3CharToX(BYTE temp,BYTE port );
extern void SendDecimalToX(BYTE temp,BYTE port );
extern void SendAsciiToX(BYTE temp,BYTE port);
extern void TransmitNStrToX(BYTE *str,BYTE len,BYTE port);
extern void LongToStr(BYTE *datastr,unsigned long tdata,BYTE dcpt);
extern unsigned long aton(char str[]);
void StrToArr( char *str, BYTE arr[]);//array must be long enough(4bytes of ip)
extern void itoa(int n, char s[]);
long ArrToLong(BYTE arr[]);
void SendDecimalLongToX6digit(DWORD tdata,BYTE port);
extern int check_string(const char *temp1Str,const char *temp2Str,int length);
extern void WORDHextoDeciamal(char* destination,unsigned short source);
extern void LongHextoDeciamal(char* destination,unsigned long source);

#endif





