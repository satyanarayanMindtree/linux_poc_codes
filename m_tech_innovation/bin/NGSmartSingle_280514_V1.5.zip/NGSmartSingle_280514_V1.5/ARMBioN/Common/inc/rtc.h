/*****************************************************************************
 *   rtc.h:  Header file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.13  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __RTC_H 
#define __RTC_H

#define IMSEC		0x00000001
#define IMMIN		0x00000002
#define IMHOUR		0x00000004
#define IMDOM		0x00000008
#define IMDOW		0x00000010
#define IMDOY		0x00000020
#define IMMON		0x00000040
#define IMYEAR		0x00000080

//#define AMRSEC		0x00000001  /* Alarm mask for Seconds */
//#define AMRMIN		0x00000002  /* Alarm mask for Minutes */
//#define AMRHOUR		0x00000004  /* Alarm mask for Hours */
//#define AMRDOM		0x00000008  /* Alarm mask for Day of Month */
//#define AMRDOW		0x00000010  /* Alarm mask for Day of Week */
//#define AMRDOY		0x00000020  /* Alarm mask for Day of Year */
//#define AMRMON		0x00000040  /* Alarm mask for Month */
//#define AMRYEAR		0x00000080  /* Alarm mask for Year */

#define PREINT_RTC	0x000001C8  /* Prescaler value, integer portion, 
				    PCLK = 15Mhz */
#define PREFRAC_RTC	0x000061C0  /* Prescaler value, fraction portion, 
				    PCLK = 15Mhz */
#define ILR_RTCCIF	0x01
#define ILR_RTCALF	0x02
#define CCR_CLKSRC  0x10	/* 32.768 kHz external Crystal RTC CLK reference*/

#define CCR_CLKEN	0x01
#define CCR_CTCRST	0x02
#define CCR_CLKSRC	0x10


/* Non Volatile variables located in 2K RTC SRAM  range 0xE008 4000 to 0xE008 47FF.*/
#define RTC_RAM_BASE       0xE0084000
#define RTC_STAT_BASE       (RTC_RAM_BASE + 1*4)

#define RTC_PACKET(i)   (*(unsigned int *)(RTC_RAM_BASE   + 8*i))


/*------------------------------------------------------------------------*/

//__packed typedef struct DATE_FORMAT
//{
//	  char Day;
//	  char Month;
//	  char Year;
//
//}Date;

//__packed struct TIME_FORMAT
//{
//	  char Secs;
//	  char Min;
//	  char Hour;
//};

//__packed typedef struct DATE_TIME
//{
//	struct TIME_FORMAT Time;
//	struct DATE_FORMAT Date;
//}RTCTime;

typedef long time_t;

__packed struct tm
{
	char tm_sec;                   // Seconds after the minute [0, 59]
	char tm_min;                   // Minutes after the hour [0, 59]
	char tm_hour;                  // Hours since midnight [0, 23]
	char tm_mday;                  // Day of the month [1, 31]
	char tm_mon;                   // Months since January [1, 12]
	int tm_year;                  // Years since 1900
	char tm_wday;                  // Days since Sunday [0, 6]
	int tm_yday;                  // Days since January 1 [0, 365]
	char tm_isdst;                 // Daylight Saving Time flag
};

#define YEAR_BASE_VALUE		2000

extern time_t CurrentTimeInt;
extern struct tm CurrentTimeDt;

extern void RTCHandler (void) __irq;
extern void RTCInit( void );
extern void RTCStart( void );
extern void RTCStop( void );
extern void RTC_CTCReset( void );
extern void SetRTCTimeDate( RTCTime ,BYTE weekday );
extern RTCTime RTCGetTime(void);
extern void RTCSetAlarm( RTCTime );
extern void RTCSetAlarmMask( DWORD AlarmMask );
extern struct tm *gmtime_r(const time_t *timer, struct tm *tmbuf);
extern time_t mktime(struct tm *tmbuf);
extern unsigned char GetWeekDay(time_t epoch);
extern RTCTime Datetime;
extern unsigned char F_OneMinute, F_OneHour, F_OneDay;


#endif /* end __RTC_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/
