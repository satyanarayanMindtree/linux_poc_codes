/* KeyPad  IO definitions */
//0000 0000 0111 1000 0000 0000 0000 0000	
#define KEY_DATA	0x00780000	           /* Data lines mask 1.19 to 1.22            */
//0000 0100 0000 0000 0000 0000 0000 0000	
#define KEY_SEL		0x04000000	            /* Keyboard Output Enable       1.26      */
//0000 1000 0000 0000 0000 0000 0000 0000	
#define KPD_BKLT	0x08000000	            /* Keyboard Back Light Control   1.27    */
extern BYTE KeyPadSenseLogic;
extern void Init_Keypad(void);
extern BYTE KeyScan(void);


//extern int ReadKey(void);


#define MAX_KEY_BUFFER	4

extern void FindKey(void);
extern void HandleKeyBoard(void);
extern volatile BYTE KeyChange,KeyPrePat,KeyRecPat,PreValidKey;
extern volatile BYTE KeyBuff[MAX_KEY_BUFFER+1];
extern volatile BYTE KeyWritePtr,KeyReadPtr;
extern BYTE ReadKeyFromBuffer(void);
extern BYTE KeyMapping(BYTE key);

#define CHECK_KEY_IN_BUFFER()	(KeyWritePtr != KeyReadPtr)
