/**********************  user interface functions **********************************************/

/*** BeginHeader */
#define USEINT_DEF

/*
This is to handel user interface


DisplayMode
DisplaySubMode
DisplayValue

1) Normal Mode
2) GetPin
3) Change Pin
4) AddCard
5) Delete Card
6) SetTime

  Functions
  #1		Change Pin
  #2		Admin Password
  #3		Add Card
  #4		Del Card
  #5		Search Card
  #6		Set Time
  #0		Multiple Functions

#define USEINT_EXT		extern
 

 
This is to handel user interface


DisplayMode
DisplaySubMode
DisplayValue

1) Normal Mode
2) GetPin
3) Change Pin
4) AddCard
5) Delete Card
6) SetTime

  Functions
  #1		Change Pin
  #2		Admin Password
  #3		Add Card
  #4		Del Card
  #5		Search Card
  #6		Set Time
  #0		Multiple Functions

*/


#define ENTER_KEY		0x0A
#define FUNCTION_KEY	0x0B
#define NUMERIC_KEY		0x0c		// this is used just handle numeric key in function call
#define RETURNABLE_FUNCTION_KEY	0x0d
#define TOUCH_KEY1		0x10	//this is touch screen key    20=0x14
#define TOUCH_KEY2		0x11	//this is touch screen key
#define TOUCH_KEY3		0x12	//this is touch screen key
#define TOUCH_KEY4		0x13	//this is touch screen key
#define TOUCH_KEY5		0x14	//this is touch screen key

#define TOUCH_BACK_KEY	TOUCH_KEY5			//NG0001

#define KEYBOARD_CARD_EVENT 0x79
//#define NUMERIC_KEY		(BYTE)0x70		// this is used just handle numeric key in function call
#define WEIGAND_DATA	0x7B
#define EVENT_TIME_OUT	0x7C
#define BIO_EVENT		0x7D
#define INITIALISE_EVENT		0x7E
#define MODE_MEMORY_FULL		0x71
//#define MODE_ADMIN_CARD_FOUND	0xF4 //ARMD0273 
#define MODE_ADMIN_CARD_FOUND	0x74 //ARMD0273 //haresh all no. with first byte as '0xF0' is replaced with '0x70' bec it will not able to jump in switch statement.
#define ACCESS_TYPE_SEL			0x7F
#define EVENT_SUCCESSFUL		0x70

#ifdef EXTENDED_KEYPAD
	#define F1_KEY			0x0C 		//Biolite (IN_OUT Key)       defect X0009
	#define F2_KEY			0x0D		//Biolite (Lunch IN_OUT Key) defect X0010
	#define BELL_KEY		0x0E	    //Biolite (BELL Key)         defect X0011
#endif

#define MODE_BIOMETRIC_DOWNLOAD		0x70

#define FUNCTION_READ_MODE			0x30
#define FUNCTION_READ_NEXT_MODE		0x31
#define FUNCTION_ENTER_MODE			0x32

#define MAX_KEY_IDLE_TIME			10
#define MAX_ADMIN_TIME_OUT			60

#define MAX_FINGER_POLL_TIME_OUT  	15

#define TEVENT_ADDCARD_SEL_ADD_DEL	1

#ifdef BIO_METRIC
#define TEVENT_ADDCARD_DISP_SCORE	2
#define MAX_FINGER_RECHK_COUNT		2 
#endif

#ifdef BIO_METRIC
	#define CONT_BIO_ACCESS					0
	#define CONT_BIO_2DR_ACCESS				1
	#define CONT_BIO_ATTEND					2
	#define CONT_BIO_2DR_ATTEND				3
	#define CONT_BIO_ATT_NOCARD 			4
	#define CONT_BIO_2DR_ATT_NOCARD 		5
	#define CONT_BIO_ATT_SC_NOCARD			6
	#define CONT_BIO_2RD_ATT_SC_NOCARD		7
	#define CONT_DENY_LIST					8 //Deny list
	#define CONT_BIO_NOCHECK  				9 //FA00075 Standalone mode card only
	#define CONT_DENY_LIST_BIO_NOCHK		10

	#define MAX_CONTROLLER_TYPE				CONT_DENY_LIST_BIO_NOCHK
#else  
	#define CONT_SMAART_ACCESS				0
	#define CONT_WEIGAND_ACCESS				1
	#define CONT_SMAART_ATTEND				2
	#define CONT_WEIGAND_ATTEND				3
	#define CONT_SMART_ATT_NOCARD 			4
	#define CONT_WEIGAND_ATT_NOCARD 		5
	#define CONT_SMART_ATT_NOCARD_COMP		6	//Do not check smartcard but check the weigand card
	#define CONT_WEIGAND_ATT_NOCARD_COMP	7   //Do not check smartcard but check the weigand card
	#define CONT_DENY_LIST					8 //Deny list

	#define MAX_CONTROLLER_TYPE				CONT_DENY_LIST
#endif

#ifdef USEINT_DEF
	#define MAX_BAUDRATE		6
	#define  DEFAULT_BAUDRATE 2
	#ifdef BIO_METRIC
		static const char* CONTR_TYPE[MAX_CONTROLLER_TYPE+1]=
		{			
			"Bio Access      ",
			"Bio Access 2 RD ",
			"Bio Att.        ",
			"Bio Att.  2 RD  ",
			"Bio Att.NoChk   ",
			"Bio.Att.NoChk2RD",
			"Bio Att.SCNoChk ",
			"BioAttSCNoChk2RD",
			"Deny List       ",
			"Bio No Check    ",
			"DenyListBioNoChk",   
		};
	#else
		static const char* CONTR_TYPE[MAX_CONTROLLER_TYPE+1][17] = {
			"RS232 Access    ",
			"Wei. Access     ",
			"RS232 Att.      ",
			"Wei. Att.       ",
			"RS232 Att.NoChk ",
			"Wei. Att.NoChk  ",
			"Att.SCNoChk     ",
			"Wei. Att.NoChk  ",
			"Deny List       ",
		   };
	#endif
	#else
		static const char DISPLAY_MODE[21][16];
		static const char BaudStr[6][6];
		static const char CONTROLLER_TYPE[6][17];
#endif

#define MODE_WAIT_FOR_CARD				0
#define MODE_CHANGE_PIN					1
#define MODE_ADMIN_PASSWORD				2
#define MODE_ADD_CARD					3
#define MODE_DEL_CARD					4
#define MODE_SEARCH_CARD				5
#define MODE_SET_TIME_DATA				6
//#define MODE_VERIFY_CARD				7
//#define MODE_DUMMY_CARD				7
#define MODE_ADD_FINGER_TO_ID			7
#define MODE_MENU						8
#define MODE_GRID_VIEW			8	 	 // Grid veiw	 	 
#define MODE_MULTIPLE_FUNCTION			9
#define MODE_MULTI_FUN_DEL_ALL			10
#define MODE_MULTI_FUN_SLAVE_NO_SET		11
#define MODE_ADMIN_ADD					12
#define MODE_SET_IDENTIFY_MODE			13
#define MODE_SET_DOOR_OPEN_TIME			14
#define MODE_SET_SECURITY_LEVEL			15
#define MODE_FACILITY_CODE				16
#define MODE_CONTROLLER_TYPE			17
#define MODE_CARD_ADD_DATA				18
#define MODE_IP_SETTING             	20
#define MODE_DISP_SYS_PARA				21
//#define MODE_BAUDRATE_SETTING			22
#define MODE_SET_SHARED_DOTL			22	
#define MODE_READER_INOUT				23
#define MODE_READER_CONFIG				24		   //ARMD0156
#define MODE_CARD_DIGIT					25
#define MODE_CONTROLLER_NO				26
#define MODE_AUTH_SERVER_SETTING		28
#define MODE_SERIAL_RDR_EN_DIS			30 
#define MODE_DISP_USEFUL_PARA       	31      
#define MODE_WEIGAND_TYPE           	32
#define MODE_BULK_ADD_CARD              33    //Bulk Card Add mode
#define MODE_SET_FIRE_TAMPER			34
#ifdef ENABLE_GSM_GPRS
	#define MODE_GPRS_DIAGNOSIS			35
#endif
#define OUT FACILITY CODE FOR FINGER ACCESS	36
//#ifndef SMART_CARD
#define MODE_MACSECURITY_ENDISABLE     	37
//#endif
#define MODE_WEI_CARD_DISPLAY			38
#define MODE_LAN_TEST					40	//ARMF0502
#define MODE_INTERNET_TEST				41	//ARMF0502
#define SCROLL_IMAGES					45
#define MODE_ADMIN_DEL					46
#define MODE_ADMIN_CHANGE				47
#define MODE_DUA_SEARCH_CARD			48

#define MODE_WRITE_TEMPLATE_TO_CARD		80   

#define MODE_UNKNOWN					250



#define ENTER_ADD_CARD_CONTROLLER	2
//#define MAX_DISPLAY_MODE		MODE_DUA_SEARCH_CARD

#define MODE_CARD_WRITE_ALL_DATA			0
#define MODE_CARD_WRITE_TEMPLATE_DATA		1

#define MAX_DISPLAY_MODE		SCROLL_IMAGES

//#ifdef ENABLE_GSM_GPRS
//#undef MAX_DISPLAY_MODE
//#define MAX_DISPLAY_MODE  MODE_MACSECURITY_ENDISABLE			
//#endif

#define MODE_CARD_FOUND				0x75
#define USER_IDENTIFY_MODE			0x71
#define USER_VERIFY_MODE			0x72
#define USER_VERIFY_BY_HOST_MODE  	0x73

#define BIO_GET_USER_ID_BY_SCAN		0x50
#define BIO_GET_ENROLLED_FINGER_ID	0x51
#define YES_KEY  4
#define NO_KEY	 6

#ifdef SUPPORT_SUPREMA
	#define MAX_FINGERS		8
#else
	#define MAX_FINGERS		8
#endif

#define ENTER_ADD_CARD_SCORE_TIMEOUT	31
#define SMODE_CHECK_ADD_FINGER_TO_ID	12

/*
#define MODE_MULTIPLE_FUNCTION	0
#define MODE_CHANGE_PIN			1
#define MODE_ADMIN_PASSWORD		2
#define MODE_ADD_CARD			3
#define MODE_DEL_CARD			4
#define MODE_SEARCH_CARD		5
#define MODE_SET_TIME_DATA		6
#define MODE_VERIFY_CARD			7

*/

#define POS_TIME_HOUR 0
#define POS_TIME_MIN  1
#define POS_TIME_SEC  2
// #define POS_DATE_DAY  2
// #define POS_DATE_MONTH 3
// #define POS_DATE_YEAR 4

#define POS_DATE_DAY   0
#define POS_DATE_MONTH 1
#define POS_DATE_YEAR  2

#define POS_WEEK_DAY  5
#define MAX_POS_TIME_DATE 5
#define MAX_POS_TIME		 6
#define MAX_POS_DATE		 6
#define POS_IP1  0
#define POS_IP2  1
#define POS_IP3  2
#define MAX_POS  3

#define DI_IP_ADDRESS	0
#define DI_NETMASK		1
#define DI_GATEWAY		2
#define DI_SERVER_IP		3
#define DI_LOCAL_PORT	4
#define DI_PUSH_IP1		5	//ARMF0249
#define DI_PUSH_IP1_PORT	6
#define DI_PUSH_IP2			7
#define DI_PUSH_IP2_PORT	8
#define DI_UDP_IP			9
#define DI_UDP_PORT			10
#define DI_DOMAIN_NAME		11
#define DI_HEATHBEAT_SERVER 12
#define DI_HEATHBEAT_PORT	13			 
#define DI_HEATHBEAT_TIME   14
#define DI_UDP_SERVER_PORT	15
#define DI_AUTH_SERVER_IP1		16
#define DI_AUTH_SERVER_IP2		17
#define DI_AUTH_SERVER_IP1_PORT	18
#define DI_AUTH_SERVER_IP2_PORT	19
#define DI_AUTH_SERVER_EN_DIS	20
					  
#define INOUT_TOGGLE	1

#ifdef  HARDWARE_SI065
#ifdef BIO_METRIC
	#define MAX_CARD_TYPE   5
 static const char* CARD_TYPES[MAX_CARD_TYPE] = {  
			"UID/Card + F    ",		//0
			"UID/Card	Only   ",	//2
			"Card + Finger   ",		//4
			"CardOnly        ",		//6
			"Key/Card + Pin  ",		//10
		};
#else
	#define MAX_CARD_TYPE   4
 static const char* CARD_TYPES[MAX_CARD_TYPE] = {  
	 	"Key/Card Only:  ",		//2
		"NoK CardOnly:   ",		//6
		"Key/Card + Pin  ",		//10
		"Card + Pin    "		//12
		};
#endif
#endif
	
#ifdef HARDWARE_SI065
		#define MAX_POLL_TYPES	4
#else
	#ifdef BIOLITE_HARDWARE
		#ifdef ARM_BIOSMART_HW
			#define MAX_POLL_TYPES	4
		#else
			#define MAX_POLL_TYPES	5	
		#endif
	#else
		#define MAX_POLL_TYPES	3
	#endif	
#endif	

static const char* POLL_TYPES[MAX_POLL_TYPES] = {
	"Normal         ",
	"Identify By Key",
	"Auto Identify  ",
#ifdef HARDWARE_SI065
	"Finger Sense   ",	
#else
	#ifdef BIOLITE_HARDWARE
	"Normal         ",
		#ifdef ARM_BIOLITE_HW
	"Finger Sense   ",	
		#endif  	
	#endif
#endif
 };

#define BIO_POLL_TYPE_NORMAL			0
#define BIO_POLL_TYPE_KEY_IDENTIFY		1
#define BIO_POLL_TYPE_AUTO_IDENTIFY		2
#define BIO_POLL_TYPE_SMART_TEMPLATE	3
#define BIO_POLL_TYPE_FINGER_SENSE 		4	


#ifdef BIO_METRIC
#define MAX_INI_SYS  12
#else
#define MAX_INI_SYS  11
#endif

static const char INI_SYS[MAX_INI_SYS+1][18]	= {
	"Del All Data    ",
	"Del Transaction ",
	"Del All Users   ",
	"Set All Default ",
	"Delete SysInfo  ",
	"Del  TimeZone   ",
	"Del Holiday     ",
	"Del FacilityCode",
	"Del Door info   ",
	"Del Admin IDs   ",
	"Reset System    ",
	"Del Cards Only  ",
#ifdef BIO_METRIC
	"Del All Fingers ",
#endif
};
#define DELALL_DATA			0
#define DEL_TRANSACTION     1
#define DELALL_USER         2
#define DELALL_DEFAULT      3
#define DELALL_SYSINFO      4
#define DELALL_TIMEZONE     5
#define DELALL_HOLIDAY      6
#define DELALL_FACILITY_CODE 7
#define DELALL_DOORINFO     8
#define DELALL_ADMIN_ID     9
#define RESET_SSYSTEM       10
#define DELALL_CARD_ONLY    11
#define DELALL_FINGERS      12

#define MODEM_CONNECTION      			0
#define MODEM_OPERATOR     				  1
#define MODEM_SIGNAL_STRENGTH      	2
#define MODEM_GET_IP      					3
#define MODEM_CONNECT_GPRS      		4
#define MODEM_DISSCONNECT_GPRS      5

#ifdef BIO_METRIC
#define MAX_NO_OF_SC_TEMPLATES		4
#define MAX_SEC_LEVEL		12
static const char* SEC_LEVEL_STR[MAX_SEC_LEVEL]	= {
	"Level:      00 ",
	"Level:      01 ",
	"Level:      02 ",
	"Level:      03 ",
	"Level:      04 ",
	"Level:      05 ",
	"Level:      06 ",
	"Level:      07 ",
	"Level:      08 ",
	"Auto Normal 09 ",
	"Auto Secure 10 ",
	"AutoMSecure 11 ",
};

//==============================================================================
static const char SEC_LEVEL_VAL[MAX_SEC_LEVEL]= {
	0x33,
	0x43,
	0x34,
	0x44,
	0x35,
	0x45,
	0x36,
	0x46,
	0x37,
	0x50,
	0x51,
	0x52,
};

#ifdef EXTENDED_KEYPAD	 
static const char F2_KEY_MODE[5][16] = {
 	"                ",
	"Lunch In Entry  ",		   
	"Lunch Out Entry ",
	" OD In Entry    ",
	" OD Out Entry   ",
};
#endif	//#ifdef EXTENDED_KEYPAD	

#endif	//#ifdef BIO_METRIC

#define MAX_CARD_DIGIT		3
static const char* CARD_DIGIT[MAX_CARD_DIGIT]	= {
	"5 Digit        ",
	"8 Digit        ",
	"10 Digit        ",
};


#ifdef ENABLE_WEIGAND_FUNCTIONS	//ARMD0356 //ARMD0357
#define MAX_WEIGAND_TYPE		8
static const unsigned char WEIGAND_TYPE_NO[MAX_WEIGAND_TYPE] = {	  //ARMD0357
	26,
	32,
	34,
	26|0x80,
	32|0x80,
	34|0x80,
	26|0x40,
	32|0x40,
};

static const char* WEI_TYPE[MAX_WEIGAND_TYPE]	= {
	"Weigand26       ",
	"Weigand32       ",
	"Weigand34       ",
	"Weigand26or Card",
	"Weigand32or Card",
	"Weigand34or Card",
	"26or Transparent",
	"32or Transparent",
};

#endif


#define MAX_READERINOUT_TYPE	6
static const char* READER_IN_OUT[MAX_READERINOUT_TYPE]= {
	"Reader Normal   ",
	"Reader In       ",
	"Reader Out      ",
	"Rdr InOut Toggle",
	"Scheduled InOut ",	 //ARMD0352
	"As Weigand Out  ",					
};
#ifdef INTRUSION_ENDIS
	#define MAX_FIRE_TAMP_MODE		8	//	NGD00007
#else
	#define MAX_FIRE_TAMP_MODE		4	//	NGD00007
#endif
static const char* FIRE_TAMPER_MODE[MAX_FIRE_TAMP_MODE] = {
	"DISABLE ALL     ",
	"ENABLE FIRE     ",
	"ENABLE TAMPER   ",
	"EN FIRE-TAMPER ",
#ifdef INTRUSION_ENDIS
	"ENABLE INTRUSION",
    "EN FIRE,INTRUSN",
    "EN INTRUSN,TAMPER",
    "ENABLE ALL      ",
#endif	
};

#define MAX_NETWORK_TEST	2
static const char NETWORK_TEST[MAX_NETWORK_TEST][16]	= {	//ARMF0502
	"Ping Gateway    ",
	"Ping Internet   "
};



#define BIT_SEARCH_USER_ADMIN		0x01      //only user search menu accessible
#define BIT_USER_ADMIN				0x02      //Add/Del/Serach i.e all user related menus accessible
#define BIT_ADMIN					0x04      //All user related + some unit related menus accessible
#define BIT_SERVICING_ADMIN  		0x08      //unit info related menus
#define BIT_SERVICING_USER_ADMIN	0x10      //unit info + all user related menus
#define BIT_SUPER_ADMIN				0x20      //all menus
#define BIT_IP_SET_ADMIN			0x40		// Just to set IP Address
#define BIT_ANY_ADMIN				0xFF		// ANY ADMIN CAN ACCESS THIS MENU.


extern CARDNO_DATA_STORAGE_TYPE NumericValue;
extern CARDNO_DATA_STORAGE_TYPE DisplayCardNo;
//static BYTE AdminLogOutTimer,IdleKeyCounter;

//unsigned char UserTempData;
extern BYTE UserFingerNo,CurrentKey,UserTimeOut,UserTimeOutEvent,NumericKeyCount;
extern CARDNO_DATA_STORAGE_TYPE  VerifyFingerCardID;
extern BYTE F_VerifyFingerCardID_CNVF;
extern BYTE NextFuncKey;
extern BYTE DispIP[5];
extern volatile unsigned int BacklitOnTime;	

//extern BYTE UserBioMode,UserTempData,DisplaySubMode,DWeekDay,DisplaySubFunction,PinReaderNo,BioReaderNo;
extern BYTE UserBioMode,UserTempData,DWeekDay,DisplaySubFunction,PinReaderNo,BioReaderNo;
extern unsigned char NextDisplayMode,AccessType,AccessType_Timer;
extern unsigned char DeviceOpMode;
extern BYTE AccessTypeMessage[MESSAGE_BYTES+1];
#ifdef BIO_METRIC
extern BYTE FingerRechkCount;		
#ifdef DISP_ENROLL_SCORE
extern BYTE Enroll_Score;                       //A00007
#endif
#endif

#define ENABLE_POLL_BIO
#ifdef ENABLE_POLL_BIO
extern BYTE F_Poll_Bio_Sensor,PollBioSensorTimeOut;
extern BYTE F_FingerUnderPoll;
#endif

extern unsigned char F_GenerateBackKey,BackKeyCounter;



#ifdef EXTENDED_KEYPAD	
	extern BYTE LunchODInOut;
#endif
extern unsigned char AdminLogOutTimer;

extern void HandleDelAllDataKey(BYTE type);
extern void DisplaySysPara(BYTE parano);
extern void HandleUserDispAllPara(BYTE type);
extern void HandleControllerType(BYTE keytype);
extern void HandleMenu(BYTE keytype);
extern void HandleUserVerifyMode(BYTE eventtype);
extern void HandleUserIdentifyMode(BYTE eventtype);
extern void HandleCardData(BYTE keytype);
extern void HandleBaudrateSetting(BYTE keytype);
extern void HandleIpSetting(BYTE keytype);
extern void  ScrollBmpImage(unsigned char key);

extern void HandleAuthServerEnDi(BYTE keytype);
extern void HandleAuthServer1Ip(BYTE keytype);
extern void HandleAuthServer1Port(BYTE keytype);
extern void HandleAuthServer2Port(BYTE keytype);
extern void HandleAuthServer2Ip(BYTE keytype);

extern void HandleAuthServerIpSetting(BYTE keytype);
extern void HandleFacilityCode(BYTE keytype);
extern void HandleDelAllDataKey(BYTE keytype);
extern void HandleAddFingerToId(BYTE keytype);
extern void HandleMultiFuncSlaveNoSet(BYTE keytype);
extern void HandleCardFound(BYTE keytype);
extern void HandleSearchCardKey(BYTE keytype);
extern void HandleDUASearchCard(BYTE keytype);
extern void HandleChangePinKey(BYTE keytype);
extern void HandleDelCardKey(BYTE keytype);
extern void HandleMultipleFunction(BYTE keytype);
extern void HandleSetTimeData(BYTE keytype);
extern void HandleWaitForCardKey(BYTE keytype);
extern void HandleWaitForCardKeyBio(BYTE keytype);
extern void HandleAdminPassword(BYTE keytype);
extern void HandleSecurityLevelMode(BYTE keytype);
extern void HandleDoorTimeMode(BYTE keytype);
extern void HandleIdentifyMode(BYTE keytype);
extern void HandleAddFingerIDEntOK(void);
extern void HandleNumericUserAdminAddDel(void);
extern void HandleUserAdminAddDel(BYTE type);
extern void HandleEnterAddCardKey(void);
extern void HandleAddCardKey(BYTE type);
extern void HandleBioUserEvents(void);
extern BYTE CheckAdminFunction(void);
extern void LCDDisplayTimeData(RTCTime timedate,BYTE blinkpos,BYTE weekday);
extern void HandleUserTimeOutEvents(void);
extern void GenerateUserTimerEvent(BYTE time,BYTE event);
extern void ResetUserTimerEvent(BYTE event);
extern void HandleWeigandEvent(void);
extern void HandleAllModeEvents(BYTE eventtype);
extern void HandleKeyEvent(BYTE key);
extern void IPStrToArray(BYTE *ipaddarray,unsigned long ipadd);
extern void IPArrayToStr(BYTE *ipadd,char *ipstr);
extern void HandleKeyEvent(BYTE key);
//extern void L_DisplayDSUVerNo(void);
extern void HandleReaderInOutType(unsigned char keytype);
extern void HandleReaderConfig(unsigned char keytype);		//ARMD0156
extern void HandleSetFireTamper(unsigned char keytype);		
extern void HandleNewFunctionKey(unsigned char key);
extern void HandleGridView(unsigned char key);
extern void HandleWelcomeMode(unsigned char key);
extern void HandleEventIconMode(unsigned char key);
extern void AskAndVerifyPin(BYTE keytype);
#ifdef BIO_METRIC
extern void HandleAddCardKeyBio(BYTE type);
#endif
#ifndef BIO_METRIC
extern void HandleBulkCardAddDelkey(unsigned char keytype);
#endif
void HandleWaitForAdminCardKey(unsigned char keytype);
void AskAndVerifyPinForAdmin(unsigned char keytype);

#ifdef ENABLE_WEIGAND_FUNCTIONS
void HandleWeigandType(unsigned char keytype);
extern void HandleWeigandType(unsigned char keytype);
extern unsigned char WeiTypeToCount(unsigned char weitype);
#endif
//#ifndef SMART_CARD
extern void HandleServerMACEnDis(unsigned char type);
//#endif
void HandleLANTest(unsigned char keytype);
void HandleInternetTest(unsigned char keytype);
extern void HandleControllerNo(unsigned char keytype);
void HandleCardDigit(unsigned char keytype);
extern void HandleUserDispUsefulPara(unsigned char type);
void GotoPreviousMenu(unsigned char MenuIndex,unsigned char Key);
void HandleSubMenuScroll_2(unsigned char key);
extern void HandleSetTime(unsigned char keytype);
extern void HandleSetDate(unsigned char keytype);
void HandleWeiCardDataDisplay(unsigned char keytype);
void HandleLocalport(BYTE keytype);
void HandleGateway(BYTE keytype);
void HandleSubnetMask(BYTE keytype);
void HandleUDPport(BYTE keytype) ;
void HandlePushServer2Port(BYTE keytype);
void HandlePushServer2IP(BYTE keytype);
void HandlePushServer1Port(BYTE keytype);
void HandlePushServer1IP(BYTE keytype);
void HandleServerIP(BYTE keytype);
void HandleUDPServerIP(BYTE keytype);
void HandleUDPServerPort(BYTE keytype);
void HandleHBTime(BYTE keytype);
void HandleHBServerPort(BYTE keytype);
void HandleHBServerIP(BYTE keytype);
extern void HandleUserAdminAdd(BYTE keytype);
extern void HandleUserAdminDel(BYTE keytype);
extern void HandleUserAdminChange(BYTE keytype);
void HandleDelAllData(BYTE keytype);		
void HandleDelTransaction(BYTE keytype);	
void HandleDelAllUsers(BYTE keytype);		
void HandleSetAllDefault(BYTE keytype);	
void HandleDelSysInfo(BYTE keytype);		
void HandleDelTimeZone(BYTE keytype);		
void HandleDelHoliday(BYTE keytype);		
void HandleDelFacilityCode(BYTE keytype);	
void HandleDelDoorInfo(BYTE keytype);		
void HandleDelAdminIDs(BYTE keytype);		
void HandleResetSystem(BYTE keytype);		
void HandleDelCardsOnly(BYTE keytype);		
void HandleDelAllFingers(BYTE keytype);	
void HandleSetSharedDOTL(unsigned char keytype);
void CheckModemConnection(unsigned char type);
void CheckDisplayOperator(unsigned char type);
void CheckSignalStength(unsigned char type);
void GetModemIP(unsigned char type);
void ConnectGprs(unsigned char type);
void DissconnectGprs(unsigned char type);
extern void HandleCalibrateTouch(unsigned char keytype);
#ifdef INSERT_SDCARD
	extern void HandleDeleteSDTrans(unsigned char keytype);	
#endif
extern void GenerateBackKey(void);

#ifdef SMART_CARD
	#define DIS_INOUT_SERIAL_RDR		0
	#define ENA_IN_SERIAL_RDR			1
	#define ENA_OUT_SERIAL_RDR			2
	#define ENA_INOUT_SERIAL_RDR 		3
#endif
struct stUserIntf	
{
	unsigned char NewModeIndex;
	unsigned char Mode1;//only 3 values DISP_MODE_WELCOME, DISP_MODE_EVENT, DISP_MODE_GRID 
	unsigned char GridSelected;//selected grid no.	(1st scroll menu)
	unsigned char ScrollMenuSelected;//selected sub scroll menu (2nd scroll menu)
	unsigned char SubScrollMenuSelected;//submenu number, might be not required.
	unsigned char ScrollLevel;//scroll level
	unsigned char ReturnFromFunction;
};

extern void CARD_FROM_KEYPAD(void);   
/*** EndHeader */

