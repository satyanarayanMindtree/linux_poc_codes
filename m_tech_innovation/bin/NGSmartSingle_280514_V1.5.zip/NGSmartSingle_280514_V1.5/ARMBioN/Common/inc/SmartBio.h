/******************************************************************
 *****                                                        *****
 *****  Name: easyweb.h                                       *****
 *****  Ver.: 1.0                                             *****
 *****  Date: 07/05/2001                                      *****
 *****  Auth: Andreas Dannenberg                              *****
 *****        HTWK Leipzig                                    *****
 *****        university of applied sciences                  *****
 *****        Germany                                         *****
 *****  Func: header-file for easyweb.c                       *****
 *****                                                        *****
 ******************************************************************/

#ifndef __EASYWEB_H
#define __EASYWEB_H

 
#define SUPPORT_NAME_FROM_FLASH

//#define SMART_USER_INT


//#define ETHERNET
#define DOOR2_ALRM
//#define MAGReader
#ifndef DISP_EVENT_MSGS_FROM_FLASH
#define	WEL_WELCOME				0
#define	WEL_DOOR_OPEN_LONG		1
#define	WEL_DOOR_FORCE_OPEN		2
#define	WEL_DOOR_CLOSE			3
#define	WEL_DOOR_OPEN			4
#define	WEL_FREE_TIME_ZONE		5
#define	WEL_FIRE_ALARM			6
#define WEL_TAMPER_ALARM        7
#define WEL_INTRUSION_ALARM     8
#define WEL_TEMPLATE_READ_WRITE	9
#define WEL_TEMPLATE_WRITE		10
#define WEL_FIRMWARE_UPGRADING	11
#define WEL_DEAD_MAN_ZONE     	12
#define WEL_DUEL_USER_2			13
#endif
#define TX_PACKET_SIZE			114


void InitOsc(void);                              // prototypes
void InitPorts(void);
//void HTTPServer(void);
//void InsertDynamicValues(void);
//unsigned int GetAD7Val(void);
//unsigned int GetTempVal(void);
void DisplayWelcomeMessage(void);
void HandleSoundControl(void);
void MakeSound(unsigned char type);
void ResetVariable(void);
void ProcessCard(unsigned char channel);
void MakeSoundForTimeMainLoop(void);
void MakeSoundForTime(unsigned char ttime,unsigned char stype);


#define HTTP_SEND_PAGE               0x01        // help flag

/**-----------------------------Local structre definations------------------------**/
/*** Beginheader */
#define Bio2000



#ifndef _232BAUD
#define _232BAUD 115200
#endif

#define STRING_BUFFER_LENGTH	450
#define CINBUFSIZE  2047
#define COUTBUFSIZE 31

#define DINBUFSIZE  1023
#define DOUTBUFSIZE 31

#define EINBUFSIZE  1023      //1023
#define EOUTBUFSIZE 31

#define MAX_BAUD_RATE_NO	6

#define MSSG_TMOUT 5000UL
/*----------------------------------------------------------*/
//Output Ports Definations
#define Lock_Dr1		0
#define Lock_Dr2 		1
#define DOTL_ALRM1		2
#define DOTL_ALRM2		3
#define RDR_LED1		4
#define RDR_LED2		5
#define RDR_BUZ1		6
#define RDR_BUZ2		7
//Input Ports Definations
#define Egrs1		0
#define Dotl1		1
#define Egrs2		2
#define Dotl2		3
#define Fire		4
#define Tamper		5
#define Dig1_IN		6
#define Dig2_IN		7
/*----------------------------------------------------------*/
#define		LED_ON		1
#define		LED_OFF		0

#define		START		1
#define		STOP		0
#define		LOW			0
#define		HIGH		1

/*----------------------------------------------------------*/
#define TIMEOUT				1000
#define MAX100mSECCOUNT		10
#define MAX1SEC				10
#define MAX30SEC			30

#define SOUND_CARD_FOUND		30
#define SOUND_USER_MESSAGE		25
#define SOUND_SYS_ERROR			50
#define SOUND_CARD_NOT_FOUND	SOUND_DOUBLE_BEEP
#define SOUND_KEY_PRESS			10
#define SOUND_USER_ERROR		20

#define SOUND_DOUBLE_BEEP		1
#define SOUND_DOUBLE_BEEP_OFF	2

#define TIME_SOUND_DOUBL_BEEP	15
//#define DOOR_CLOSE			4
#define DOOR_CONTINOUS_OPEN		1
#define DOOR_TIME_OPEN			2
#define DOOR_FREE_TIMEZONE		3
#define NORMAL_DOOR_OPERATION	0

#define SOUND_NO_BEEP	0
#define SOUND_ONE_BEEP 	1
#define SOUND_TWO_BEEP	2
#define SOUND_ERR_BEEP	3

/*------------------------------------------------------------------------*/
#define PASS_ADMIN_LOGIN	0xFF
#define PASS_IPSET_LOGIN	0x01

#define TimeZone_Err			-2
#define CARD_FOUND				0
#define VALID_CARD				1
#define TimeZone_OK				3
#define Door_Not_Valid			5
#define Reader_Not_Valid		6
//#define HOLIDAY_NO_ACCESS		7
#define DOTL1_ALARM				8
#define DOTL2_ALARM				9
#define DOTL1_ALARM_OFF			10
#define DOTL2_ALARM_OFF			11
#define FORCE1_ALARM			12
#define FORCE2_ALARM			13
#define SYSTEM_RESET			14
#define APB_Err					15
#define FACLITY_ERR				16

/*----------------------------------------------------------------------------*/
#define EVENT_FACLITY_ERR				0
#define EVENT_VALID_CARD				1
#define EVENT_CARD_NOT_FOUND			2
#define EVENT_Card_Expired				3
#define EVENT_TimeZone_Err				4
#define EVENT_Door_Not_Valid			5
#define EVENT_FINGER_NOT_MATCH			6
#define EVENT_HOLIDAY_NO_ACCESS			7
#define EVENT_DOTL1_ALARM				8
#define EVENT_DOTL2_ALARM				9
#define EVENT_DOTL1_ALARM_OFF			10
#define EVENT_DOTL2_ALARM_OFF			11
#define EVENT_FORCE1_ALARM				12
#define EVENT_FORCE2_ALARM				13
#define EVENT_SYSTEM_RESET				14
#define EVENT_APB_ERROR					15
#define EVENT_PIN_VERIFICATION			16
#define EVENT_INVALID_ACCESS			17				//shree 19Jan09

#define EVENT_LUNCH_IN					18			
#define EVENT_LUNCH_OUT					19			
#define EVENT_DUEL_USER_ACCESS_FAIL		20		//281210-4 //Duel User Fail DUA
#define EVENT_DUEL_USER_2           	21    //ask for 2nd user			
#define EVENT_OD_IN						22			
#define EVENT_OD_OUT					23			
#define EVENT_INVALID_CARD				24   	// Indicates this is invalid smart Card as reading issue in card	
#define EVENT_ADMIN_LOGIN				25
#define EVENT_DOOR_OPEN_EGRESS			26
#define EVENT_SYSTEM_INI				27
//#define EVENT_SPECIAL_CARD			28	//ARMD0274 this event is used to specify Escort Card
#define EVENT_ESCORT_CARD				28	 //ARMD0274 temporarily special card type has given event id
#define EVENT_DOOR_INTER_LOCK			29		//281210-1		// Event Defination DIS
#define EVENT_DOOR_NOT_OPEN				30
#define EVENT_LAST_CARD_ERROR			31

#define EVENT_FINGER_RETRY				33		//FA00070
#define EVENT_DURESS_ACCESS				34		//FA00070
#define EVENT_TIME_BASED_ACTION     	35
#define EVENT_DEAD_MAN_ZONE				36    //201210-1
#define EVENT_OCCUPANCY_FULL			37		//281210-3 //Event Occupancy Full
#define EVENT_INTRUSION_ALARM_HIGH		38				//A00002
#define EVENT_INTRUSION_ALARM_LOW		39				//A00002
#define EVENT_FIRE_ALARM_HIGH			40
#define EVENT_FIRE_ALARM_LOW			41
#define EVENT_TAMPER_ALARM_HIGH			42
#define EVENT_TAMPER_ALARM_LOW			43

#define EVENT_DIFFERENT_ACCESS_1		50
#define EVENT_DIFFERENT_ACCESS_2		51
#define EVENT_DIFFERENT_ACCESS_3		52
#define EVENT_DIFFERENT_ACCESS_4		53
#define EVENT_DIFFERENT_ACCESS_5		54
#define EVENT_DIFFERENT_ACCESS_6		55

#define EVENT_ESCORT_CARD				28	 //ARMD0274 temporarily special card type has given event id
#define EVENT_INTRUSION_CARD			56
#define EVENT_OCCUPANCY_CONTROL_CARD	57
#define EVENT_OVERRIDE_ACCESS_CARD		58
#define EVENT_FIRST_INUSER_CARD			59
#define EVENT_EMERGENCY_CARD			60
#define EVENT_DONOT_DISTURB_CARD		61
#define EVENT_ALERT_CARD				62
#define EVENT_NORMAL_CARD				63
#define EVENT_PHYSICAL_DOOR_CLOSE		68	 // Indicates that actual door is physically opened	 	//ARMF2011
#define EVENT_PHYSICAL_DOOR_OPEN 		69	 // indicates Actual door is physically closed			//ARMF2011
#define EVENT_FIRST_INCARD_NOT_FOUND	70
#define EVENT_DMZ_RESET_CARD			71
#define EVENT_DONOT_DSTRB_MODE		    72
#define EVENT_DONOT_DISTURBZONE_CARD	73
#define EVENT_LOGGING					74		//DA00139
#define EVENT_SPCL_CARD_NOT_FOUND		75
#define EVENT_DR_PC_NORMAL				76		//ARMF2011
#define EVENT_DR_PC_USER_OPEN			77		//ARMF2011
#define EVENT_DR_PC_USER_CLOSE			78		//ARMF2011


#define EVENT_SERVER_CHECK_TIMEOUT		80

#define EVENT_FIRMWARE_UPGRADE			199
#define EVENT_EMPNO_TRNX				200		//shree 12 June
#define EVENT_BAD_TRNX_DATA				201		//
#define EVENT_BAD_PAGE_ERROR			202      //FA00050 This even is generate if bad Page is found. we store pad page number in card number.
#define EVENT_WEI_PARITY_ERROR			203      
#define EVENT_UDP_HEARTBEAT   			250

/*------------------------------------------------------------------------*/
#define C_NEW_COMMAND_GROUP	'l'


#define C_DELETE_DUMP_TRNX	'B'
#define C_ADD_CARD_PIN		'E'
#define C_READ_TRANS		'F'
#define C_ADD_CARD			'G'
#define C_DELETE_CARD		'H'
#define C_SET_TIME_ZONE		'I'
#define C_DOOROPEN_TIM		'J'
#define C_SET_DATE_TIME		'K'
#define C_EVENT_ENABLE		'L'
#define C_INITIALISE		'M'
#define C_STATUS			'N'
#define C_UNLOCK_DOOR		'O'
#define C_HOLIDAY			'P'
#define C_DOWNLOAD_ALL		'Q'
#define C_LOCK_ALLDOOR		'R'
#define C_DEL_TRNX			'S'
#define C_DISPLAY_MEM		'T'
#define C_CARDDELETE		'U'
#define C_TRNXDELETE		'V'
#define C_FIRMWAREVER		'W'
#define C_MEMORY_MAP		'X'
#define C_SEND_TRANS_SEC	'Y'
#define C_GROUPCARD_ADD     'Z'

#define C_ADMIN_USER_ADD		'a'
#define C_ADMIN_USER_DEL		'b'
#define C_ADMIN_USER_DEL_BY_LOC	'c'
#define C_DEABUG_LEVE			'd'
#define C_SET_SLAVE_NO			'e'
#define C_TRNX_STORE	    	'f'
#define C_STATUS_SEC			'g'
#define C_FACILITYCODE			'h'
#define C_CARD_DATA				'i'
#define C_DUMP_TRNX	    		'j'
#define C_PREV_TRNX				'k'
#define C_DELCDARDTODISP		'm'
#define C_SETDIPCONID			'n'
#define C_ADDMESGTODISP			'o'
#define C_CARDINTDISP			'p'
#define C_ADMIN_PASSWORD		'q'
#define C_GET_COMMANDS			'r'
#define C_SEARCH_CARD			's'
#define C_ETHERNETSETTING		't'
#define C_SET_TRANS_READ_PTR	'w'
#define C_SET_TRANS_WRITE_PTR	'x'
#define C_SET_TRANS_TOTAL_PTR	'y'
#define C_CARD_FROM_SERIAL		'z'

#define C_READ_ALL_PTR			'r'			// this is get command read all pointers



#define MAX_SERIAL_BUFFER        1000
#define BUFSIZE					 1000

//Response from Controller
#define TRNXSATION			'J'
#define TRNXSATION_NO_DATA	'G'
#define CARDADDED			'A'
#define CARDDELETE			'D'
#define CARDPRESENT		    'P'
#define CARDNOTPRESENT	    'N'
#define TIMEZONE			'Z'
#define DOOROPENTIM		    'O'
#define DATETIME			'T'
#define INITIALISE		    'I'
#define STATUS		    	'S'
#define UNLOCKDOOR	    	'U'
#define MEMORYMAP		    'M'
#define HOLIDAY	     		'H'
#define LOCKALLDOOR 		'K'
#define DELTRNX		    	'W'
#define DISPLAYMEM	    	'Q'
#define DELETETRNX			'a'
#define CARDBUFF_FULL		'F'
#define VERSION				'f'
#define EVENTS				'E'
#define FALICITYCODE		'h'
#define CARADDATA			'i'
#define NACK				0x15
#define READ_ALL_PTR		'r'
#define SET_PTR_OK			'w'		



#define TERMINATOR			'\r'
#define REPLY_START_CMD		'#'
#define STX					'$'
#define RSTX				'#'
#define ETX					'\r'
#define ETX1				'\n'
#define CNTRBASEADD			'0'
#define GLOBAL_COMMAND		'0'
#define COMMAND_POSITION	1

#define		SET			1
#define		CLR			0

#define CONT_SMAART_ACCESS				0
#define CONT_WEIGAND_ACCESS				1
#define CONT_SMAART_ATTEND				2
#define CONT_WEIGAND_ATTEND				3
#define CONT_SMART_ATT_NOCARD 			4
#define CONT_WEIGAND_ATT_NOCARD 		5
#define CONT_SMART_BIO					6
#define CONT_WEIGAND_ATT_NOCARD_COMP	7      		//Do not check smartcard but check the weigand card
#define CONT_DENY_LIST					8      		//Deny list

#define BIO_GET_USER_ID_BY_SCAN		   0x50
#define BIO_GET_ENROLLED_FINGER_ID	   0x51 
//--------------------------------------------------------------------------------
//#define ADMIN_DATA_BYTES	CARD_DATA_BYTES

#define CARD_DATA_MAX	   MAX_NO_OF_CARD
#define MAX_CARD_PAGE      ((MAX_CARD_ADDRESS /PAGE_SIZE)+1)
#define MAX_CARDP_PERPAGE      ((PAGE_SIZE/CARD_DATA_BYTES))
#define MAX_SYSINFO_PAGE 	8
#define MAX_CARD_ADDRESS	(MAX_NO_OF_CARD * CARD_DATA_BYTES)


/*Serial Flash Memeory Map 1MB Flash of 4095 pages of 264 bytes block.*/
/*Serial Flash Memeory Map page 0 contains History from Page 700 SYSTEM-Card Data Backup*/
#define MaxPageAdd			2048
#define MaxBuffTrnx			(PAGE_SIZE/TRANS_DATA_BYTES)


/* System Info and Card Data Start from Pageno 700 */

/*
#define SYSINFO_PAGE 		1000
#define FL_DOORINFO_PAGE 	1001                
#define ADMIN_DATA_PAGE 	1003              
#define TIME_ZONE_PAGE  	1004             
#define HOLIDAY_PAGE 		1013 				    

#define FL_MESSAGE_PAGE_NO 		1016     			// 2008 to 2012

#define FL_CARDDATA_PAGE_NO  	1040          // Base address for card database

#define FL_CARD_NAME_PAGE_NO	2000   		// Base address for card name

*/
#define MAX_MESSAGE_NO			100

#define ERROR_MESSAGE_BASE    50  //use 50 to 94 for event messages   //FA00084
#define MAX_ERROR_MSGS        45
#define CARD_NAME_BYTES			16
#define MESSAGE_BYTES			16
#define FACLITYCODE_BYTES	1
#define FACILITYCODE_MAX	8
#define DOORINFO_BYTES		sizeof(struct DOOR_INFO)

#define SYSTEM_INFO_BYTES  sizeof(struct SYS_INFO)


#define CARD_DATA_BYTES		sizeof(struct CARD_DATA)
#define TRANS_DATA_BYTES	sizeof(struct TRNX_DATA)

#define DOOR_OPEN_BY_DMZ_CARD 1
// Format for Time Zone :
#define MAX_FIU_GROUPS 64

/*------------------------------------------------------------------------*/


/* CARD Storage format :        8937

Byte	Discription Details
					D7	D6	D5	D4	D3	D2	D1	D0
1	Card number   hex
2
3	Access Level	H APB < ACCESS LEVEL		>
4	Start Date /Pin	MM	MM	MM	DD	DD	DD	DD	DD
5					YY	YY	YY 	YY	YY	YY	YY	MM
6	Expiry Date		MM	MM	MM	DD	DD	DD	DD	DD
7	 				YY	YY	YY	YY	YY	YY	YY	MM


	Card storage Table	Hex			Decimal
	Ist Card number	0AB0h	 		2720
				Card No.
				Access level
				Start Date / Pin
				Expiry Date
	"	"	"	"
	8937th Card number	FFF8h	 	65528
				Card No.
				Access level
				Start Date / Pin
				Expiry Date
				10000h			65536
				*/
/*------------------------------------------------------------------------*/
__packed struct CARD_ACCESS
{	//this can be otimised using bit field.
	unsigned char APB;			 /* 0 indicates door1  ---- 1 indicates door 2 */
	unsigned char Door1;
	unsigned char Door2;
  	unsigned char Holiday;		/* 0 indicates holiday disable 1 indicates check in holiday list */
};

__packed struct CARD_INFO
{  
	unsigned char CType; 					// CType   => 1111 1111    0th bit CNVF , 1st bit No Finger Card Check,
	unsigned char MesgInfo;
	unsigned char Group;
#ifndef NEW_CARD_FORMAT
	unsigned char BirthMonth;
	unsigned char BirthDate;
#endif

};
// This is normal type where for any card we will ask for finger and user is supported by identify mode
#define  UTYPE_CARD_OP_FIN_MUST_VERIFY			(unsigned char) 0x00
// in following selection pin will be over wridden for card and biometric how ever we will check same for keyboard
#define  UTYPE_PIN_ON_FINGER_FAIL				(unsigned char) 0x01     
/*
TIME_FORMAT

DATE_FORMAT*/

/*------------------------------------------------------------------------*/
// PANKAJ we have to add security level for biometric reader

__packed typedef struct CARD_DATA
{
	CARDNO_DATA_STORAGE_TYPE CardNo;   // 4
	struct CARD_ACCESS CardInfo;       // 4
    struct CARD_INFO Info;					//   5
  	WORD CardPin;				             //  2 
	unsigned long ExpDT;                // 4
#ifdef EN_DOORACCESS
	unsigned char DoorAccess;		 //ARMF2002://Implement DoorAccess  //1
#endif
}CardData;

//defect:after FW upgrade user will not able to login
__packed typedef struct ADMIN_CARD_DATA
{
	CARDNO_DATA_STORAGE_TYPE CardNo;
	struct CARD_ACCESS CardInfo;
    struct CARD_INFO Info;
  	WORD CardPin;
	unsigned long ExpDT;
}AdminCardData;

/*------------------------------------------------------------------------*/
#define INPUT_USER_FROM_SMART				0x01
#define INPUT_USER_FROM_WEIGAND				0x02
#define INPUT_USER_FROM_KEYBOARD			0x04
#define INPUT_USER_FROM_FINGER				0x08
#define INPUT_USER_FROM_SMART_FINGER 		0x10

#define INPUT_USER_PIN						0x20
#define INPUT_USER_FAIL_FINGER_PIN			0x40
#define INPUT_USER_FROM_PIN_CARD_WEIGAND 	(0x80 | 0x20)
#define INPUT_USER_FROM_PIN_PROX 			0x80

// card data source  ( this can be from Local or from SmartCard
#define CDATA_SOURCE_NAME			0x0001
#define CDATA_SOURCE_PIN			0x0002
#define CDATA_SOURCE_VALIDITY		0x0004
#define CDATA_SOURCE_TEMPLATE		0x0008
#define CDATA_SOURCE_USER_TYPE 	0x0010     // Card is visitor or normal employee
#define CDATA_SOURCE_ACCESSLEVEL 0x0020
/*--------------------------------------------------------------------------*/
/* Door detail information  */
 //redifne in int flags
__packed struct DOOR_INFO
{
	unsigned char MaxBacklitOnTime;
	WORD  OccupancyCount;    //281210-3
	unsigned char DoorInterlock;     //Door Interlock DIS
	unsigned char FirstInUserRule;   //FIU parameter decleration
	unsigned char DuelUserAuth;   //Duel User Authentication Parameter DUA
	unsigned char BulkAddDelCard;    //Bulk add card mode
	unsigned char EnDisDeadManZone;     // To enable Dead Man Zone need to set this parameter
	WORD DeadManZoneTime; // Time in minuits after it will give buzzer if no card swipe before
	unsigned char EnDisWeigandBits;
	WORD TemplateSize;
	unsigned char UserRestrict;        //shree 23Jan09
	unsigned char PushCloseDelay;        //shree 19Nov
	unsigned char PushConnectTimeout;	//shree 17Nov
	WORD E_InEmpCount;				//shree 18July
	unsigned char EnDisEmpInDispCount;
	unsigned char KeySenseLogic;		//shree 05Feb09 //Dummchr1;
	WORD GPRSTime;     		// after this sec we will connect if this is zero do not conect
	WORD GPRSThreshold;		// After total tansactions count reaches this value we will connect to GPRS
	unsigned char GPRSEnable;
	unsigned char EnDisEMPNoTrnx;
	unsigned char FireType;
	WORD  ControllerNo;
	unsigned char CardDigit;      	// this is to specify 10, digit, 5 digit
	unsigned char CardMask;				// this is to select 16bit or 32 bit card mask..  32 = 32 bit,  16= 16 bit.
	unsigned char AllowKeypadCard;
	unsigned char F2keymode;
	unsigned char Dummy9;
	unsigned char FREETIMEENABLE;
	unsigned char ChkHoliday;
	unsigned char EnDisWeiParity;    //DB037
	unsigned char EnableDuress;
	unsigned char APBEANABLE;
	unsigned char FaclityCode_Chk;
	unsigned char GlobalPinProx;            	// Global Pin Prox reader enable
	unsigned char NoCheckAPBTimer;
	unsigned char SocketCloseTime;            
	unsigned char Dummy5;
	WORD UDPHeartBeat;              /* Door open delay stored which is programmed from pc*/
	unsigned char F_FirstInUser;
	unsigned char PC_D00R1_OPEN;
	unsigned char PC_D00R2_OPEN;
	unsigned char EXTDOTL_EN;
	unsigned char EXTDOTL2_EN;
	unsigned char FREETIMEDOOR1;
	unsigned char FREETIMEDOOR2;
	unsigned char EXShareDotl;	
	unsigned char PINPROXENABLE_DOOR1;
	unsigned char PINPROXENABLE_DOOR2;
	unsigned char EXDOTL_DLY1;	 			/* Door open too long delay stored which is programmed from pc*/
	unsigned char EXDOTL_DLY2;
	unsigned char EXDOP_TIM1;		   	    /* Door open delay stored which is programmed from pc*/
	unsigned char EXDOP_TIM2;
	unsigned char BeepEnable;     	//A00017
	unsigned char FingerRecheck;			//A00006
	unsigned char AnyDualFinger;
    unsigned char DotlEvent;
	unsigned char PollSlaveNo;
	unsigned char EnDisTransparentMode;
	unsigned char SlaveRespMode;
	unsigned char SecurityEnDis;
	unsigned char EnableEmail;
//struct DOOR_SETTING_B Doorseting;
	unsigned char IClassCardType;
	unsigned char BARCCardType;      // Mandar BARC card type specifies parameter.
//	unsigned char DotlEvent;
	unsigned char HeartBeatIP[16];
	WORD  HBPort;
	unsigned char APNUserName[8];
	unsigned char APNPassword[8];
	unsigned char APNType[32];
	unsigned char PDPContext[32];
	unsigned char ModemType;
	unsigned char DontDisturb;//global parameter for do not disturb en/dis.
	WORD  UDPServerPort;
	unsigned char ServerMACAdress[12];
	unsigned char InternetTestIP[16];	//ARMF0502
	unsigned char  TScalibrated;  //touch screen related data
	unsigned short TSoffsetLeft;
	unsigned short TSoffsetRight;
	unsigned short TSoffsetTop;
	unsigned short TSoffsetBottom;
	unsigned short TSdivisorX;
	unsigned short TSdivisorY;
};

__packed struct SYS_MODEL_INFO
{
	unsigned char ModelNo[16];
	unsigned char SerialNo[8];
   	unsigned char MfgDate[8];
   	unsigned char StartDate[8];
	unsigned char MACAddress[8];
	unsigned char Server_MACAddr[6];
   	unsigned int ChkSum;
	unsigned char PrevVersionNo;
};


struct Event_Enbl_Flg
{
	// member list goes here
	unsigned char  DOTL1_EVENT;
/*	   			   DOTL2_EVENT:1,
	   			   FORCE1_EVENT:1,
	   			   FORCE2_EVENT:1,
	   			   Flag1:1,
	   			   Flag2:1,
	   			   Flag3:1,
	   			   Flag4:1;
                  */
};

//=================================================================================

#define INPUT_FIRE		0x01
#define INPUT_TAMPER	0x02
#define INPUT_AUX1		0x04
#define INPUT_AUX2		0x08

#define SC_CT_READER_SELECT		0
#define SC_CT_CSN_NUMBER		1
#define SC_CT_INFO_BLOCK		2
#define SC_CT_TEMPLATE_BLOCK	3

__packed typedef struct SYS_INFO
{
	unsigned char WeigandOutCont;
	unsigned char ControllerMode;			// This is 4 door or 8 door mode.   = 4 means 4 door 4 reader mode    =8 means 4 door and 8 reader mode ( Default 8 reader mode )
	unsigned char SlaveType;				// Slave type to indicate if slave is 2reader or 1 reader =1 indicates 1 reader mode and =2 indicates 2 reader mode ( Default 2 reader mode)
	unsigned char ControllerEnDis;
	unsigned char TransAdjMode;   
	unsigned char AuthIP;
	unsigned char SCKeyType[3];
	unsigned char SCKeySector[3];
	unsigned char TZInOut[4];							// what to do on InOutTimeZone is stored in this .. vaue should be between 1 and 2 only
	unsigned char SCReaderEnDis[2];
	unsigned char SelAccessType;					// This will select different Transaction generation....
	unsigned char TransType[6];           		// this is used to store selection of transaction type message .. 0 indicates this is not enabled...
	unsigned char SCInfoBlock[2];
	unsigned char SCNameBlock[2];
	unsigned char SCTemplateBlock[2];
	unsigned char SCOther1Block;
	unsigned char SCOther2Block;
	unsigned char SCCardNoType;          // different type of card reading formats
	unsigned char SmartCardLayout;		// this is used to specify different smartcard layout
	BYTE InputED;		// Different input enable disable setting
	BYTE LastCardTime;
	BYTE MemMgmt;
	BYTE NameType;  // This to indicate from where to take name or same is enable / disable
	BYTE ControllerType;
	BYTE FacilityCodeNo[8];
	BYTE LOCAL_IP[16];
	BYTE LOCAL_NETMASK[16];
	BYTE LOCAL_GATEWAY[16];
	BYTE SERVER_IP_ADD[16];
	BYTE MySlaveNo;
	unsigned char BlockKeyboard;		// If set to zero it will allow keypad to do all functions , If set to 1 it will just allow to do IP address setting
	unsigned char InOutToggle; 		// controller inout toggle control if this is InOutToggle=0 then for ContInOut =1 and 2 it will not toggle else if InOutToggle=1 will toggle using 0 key
	unsigned char PushEnable; 
	unsigned char TransWriteCheck;       	// To enable Transaction write Check and re-write if this data is set to non zero
	unsigned char PinProxFCode;
	unsigned char EnDisUserMsg;
	unsigned char IdentifyMode;
	unsigned char GlobleMsg;
	unsigned char BannerMsg;
	unsigned char ContInOut;			// this variable is used to specify if we support key board inout
//	0 = No IN/OUT selection 
//	1 = Reader Unit in "IN Entry" mode (Toggled by "0" Key)
//	2 = Reader unit in "OUT Entry" mode (Toggled by "0" Key)
//	3 = Reader Unit in "IN Entry" modeand will go for "OUT Entry" mode for 5secs when "0" Key is pressed
//	4 = Sheduled IN/OUT for set Timezone and reader using parameter 15,16 (Please look at 48th point)
//	5 = weigand out rader.
	unsigned char InOutTimeZone[4];			// If ContInOut =4 then following will store time zone number to toggle
	unsigned char ChkPin;
	unsigned char UDP_IPAdd[16];
	unsigned char PUSH_TCP_ServAdd1[16];
	unsigned char PUSH_TCP_ServAdd2[16];
	unsigned char PushNoOfTrans;      // No of transactions to send in one go
	unsigned char PushThreshold;    	// Threshold to send the transactions
	unsigned char PushTransDelay;		// Delay between two transaction packet send
	unsigned char PushWaitDelay;     // Automatic push wait delay
	unsigned char BioEnrollType;		// different type of enrollment
	unsigned char LOCAL_DOMAINNAME[16];
	unsigned char SystemEventTimer[8];//this is stored in flash
	unsigned char SB_AUTH_ServAdd1[16];		// Auth Server 1 IP address
	unsigned char SB_AUTH_ServAdd2[16];		// Auth Server 2 IP address
	unsigned char ServerAuthType;
	unsigned char ThemeSelectNo;
	unsigned char DispIdealTime;	
	WORD CardDataSource;
	WORD ETH_Port;
	WORD  UDP_PushPort;
	WORD  PUSH_TCP_Port1;
	WORD  PUSH_TCP_Port2;
	WORD ChkSum;
	WORD  SB_AUTH_Port1;					// Auth Server 1 Port
	WORD  SB_AUTH_Port2;					// Auth Server 2 Port
	unsigned int BaudRate[4];		// To specify different baudrates BIO=0,SC1=1 SC2=2, PC =3
	unsigned char EnableAccessDate; 		// NGD00027
	unsigned char EnableSDWrite;			// NGD00033
	unsigned int dummy1;
	unsigned int dummy2;	
	
}SYSInfo;

struct DISPLAY_MESSAGE
{
	unsigned char Msg[16];
};

// in following selection pin will be over wridden for card and biometric how ever we will check same for keyboard
#define UTYPE_PIN_ON_FINGER_FAIL		(unsigned char) 0x01

// in this card is taken from weigand and finger is not at all asked
#define UTYPE_CARD_ONLY_VERIFY			(unsigned char) 0x02

// in this user can not enter card number from key
#define UTYPE_KEYBOARD_NOT_ALLOWED		(unsigned char) 0x04
										
#define UTYPE_CARD_ONLY					(unsigned char) 0x06

#define UTYPE_CHECK_PIN					(unsigned char) 0x08

#define UTYPE_CHECK_CARD_PIN					(unsigned char) 0x0A

#define UTYPE_FINGER_SMARTCARD			(unsigned char) 0x10

#ifdef BIO_METRIC
/*	// #define CHECK_SMART_CARD_CONTROLLER()	((CONT_SMAART_ACCESS==SysInfo.ControllerType)||(CONT_SMAART_ATTEND==SysInfo.ControllerType)||(CONT_SMART_ATT_NOCARD==SysInfo.ControllerType))
	// this is for attendance with no card verification
	
	#define CHECK_ATT_NOCARD()			((CONT_BIO_ATT_NOCARD==SysInfo.ControllerType)||(CONT_BIO_2DR_ATT_NOCARD==SysInfo.ControllerType))
	// this is only card verification and no access level holiday etc...
	#define CHECK_ATT_CARD_ONLY()		((SysInfo.ControllerType == CONT_BIO_ATTEND)||(SysInfo.ControllerType==CONT_BIO_2DR_ATTEND))
	
	#define CHECK_ATT_SC_NOCARD()		((SysInfo.ControllerType == CONT_BIO_ATT_SC_NOCARD)||(SysInfo.ControllerType==CONT_BIO_2RD_ATT_SC_NOCARD))
	// ask finger for both reader
	#define CHECK_TWO_DOOR()			((SysInfo.ControllerType == CONT_BIO_2RD_ATT_SC_NOCARD)||(CONT_BIO_2DR_ACCESS==SysInfo.ControllerType)||(CONT_BIO_2DR_ATTEND==SysInfo.ControllerType)||(CONT_BIO_2DR_ATT_NOCARD==SysInfo.ControllerType))
	
	#define CHECK_DENY_LIST()			(SysInfo.ControllerType == CONT_DENY_LIST)
	
	#define CHECK_BIO_NOCHK()			(SysInfo.ControllerType == CONT_BIO_NOCHECK)
	#define CHECK_DENY_LIST_BIO_NOCHK()	(SysInfo.ControllerType == CONT_DENY_LIST_BIO_NOCHK)  */

	// #define CHECK_SMART_CARD_CONTROLLER()	((CONT_SMAART_ACCESS==SysInfo.ControllerType)||(CONT_SMAART_ATTEND==SysInfo.ControllerType)||(CONT_SMART_ATT_NOCARD==SysInfo.ControllerType))
	// this is for attendance with no card verification
	
	#define CHECK_ATT_NOCARD(X)				((CONT_BIO_ATT_NOCARD==ReaderInfo[X].CntrolrType)||(CONT_BIO_2DR_ATT_NOCARD==ReaderInfo[X].CntrolrType))
	// this is only card verification and no access level holiday etc...
	#define CHECK_ATT_CARD_ONLY(X)			((ReaderInfo[X].CntrolrType == CONT_BIO_ATTEND)||(ReaderInfo[X].CntrolrType==CONT_BIO_2DR_ATTEND))
	
	#define CHECK_ATT_SC_NOCARD(X)			((ReaderInfo[X].CntrolrType == CONT_BIO_ATT_SC_NOCARD)||(ReaderInfo[X].CntrolrType==CONT_BIO_2RD_ATT_SC_NOCARD))
	// ask finger for both reader
	#define CHECK_TWO_DOOR(X)				((ReaderInfo[X].CntrolrType == CONT_BIO_2RD_ATT_SC_NOCARD)||(CONT_BIO_2DR_ACCESS==ReaderInfo[X].CntrolrType)||(CONT_BIO_2DR_ATTEND==ReaderInfo[X].CntrolrType)||(CONT_BIO_2DR_ATT_NOCARD==ReaderInfo[X].CntrolrType))
	
	#define CHECK_DENY_LIST(X)				(ReaderInfo[X].CntrolrType == CONT_DENY_LIST)
	
	#define CHECK_BIO_NOCHK(X)				(ReaderInfo[X].CntrolrType == CONT_BIO_NOCHECK)

	#define CHECK_DENY_LIST_BIO_NOCHK(X)	(ReaderInfo[X].CntrolrType == CONT_DENY_LIST_BIO_NOCHK)  

#else
	#define CHECK_SMART_CARD_CONTROLLER()	((CONT_SMAART_ACCESS == SysInfo.ControllerType) ||			\
											(CONT_SMAART_ATTEND == SysInfo.ControllerType) ||			\
	                                       	((CONT_SMART_ATT_NOCARD_COMP == SysInfo.ControllerType) || 	\
	                                       	(CONT_SMART_ATT_NOCARD == SysInfo.ControllerType)) ||		\
	                                       	(CONT_DENY_LIST == SysInfo.ControllerType))
	
	#define CHECK_ATT_NOCARD(X)				((CONT_WEIGAND_ATT_NOCARD_COMP == ReaderInfo[X].CntrolrType) ||\
											(CONT_SMART_ATT_NOCARD_COMP == ReaderInfo[X].CntrolrType) ||	\
											(CONT_SMART_ATT_NOCARD == ReaderInfo[X].CntrolrType) ||		\
											(CONT_WEIGAND_ATT_NOCARD == ReaderInfo[X].CntrolrType))
	

	#define CHECK_ATT_CARD_ONLY(X)			((ReaderInfo[X].CntrolrType == CONT_WEIGAND_ATTEND) ||(ReaderInfo[X].CntrolrType == CONT_SMAART_ATTEND))
	
	#define CHECK_ATT_SC_NOCARD(X)			(0)
	
	#define CHECK_BIO_NOCHK(X)				(ReaderInfo[X].CntrolrType == CONT_BIO_NOCHECK)
	
	#define CHECK_DENY_LIST(X)				(ReaderInfo[X].CntrolrType == CONT_DENY_LIST)
		
/*	#define CHECK_SMART_CARD_CONTROLLER()	((CONT_SMAART_ACCESS == SysInfo.ControllerType) ||			\
											(CONT_SMAART_ATTEND == SysInfo.ControllerType) ||			\
	                                       	((CONT_SMART_ATT_NOCARD_COMP == SysInfo.ControllerType) || 	\
	                                       	(CONT_SMART_ATT_NOCARD == SysInfo.ControllerType)) ||		\
	                                       	(CONT_DENY_LIST == SysInfo.ControllerType))
	
	#define CHECK_ATT_NOCARD(X)				((CONT_WEIGAND_ATT_NOCARD_COMP == ReaderInfo[X].CntrolrType) ||\
											(CONT_SMART_ATT_NOCARD_COMP == ReaderInfo[X].CntrolrType) ||	\
											(CONT_SMART_ATT_NOCARD == ReaderInfo[X].CntrolrType) ||		\
											(CONT_WEIGAND_ATT_NOCARD == ReaderInfo[X].CntrolrType))
	

	#define CHECK_ATT_CARD_ONLY(X)			((ReaderInfo[X].CntrolrType == CONT_WEIGAND_ATTEND) ||(ReaderInfo[X].CntrolrType == CONT_SMAART_ATTEND))
	
	#define CHECK_ATT_SC_NOCARD(X)			(0)
	
	#define CHECK_BIO_NOCHK(X)				(ReaderInfo[X].CntrolrType == CONT_BIO_NOCHECK)
	
	#define CHECK_DENY_LIST(X)				(ReaderInfo[X].CntrolrType == CONT_DENY_LIST)*/
#endif

#define MAX_SEND_BUFFER		1024

/////////////////////////////////////////////////
//#define GET_ARRAY(XYZ)	{ #define . , 		\  /*replace . with , to make array*/
// 						  XYZ 				\
//						  #undef .			\
//						}
#define PRIMARY_STATIC_IP	"192.168.000.200"
#define PRIMARY_NETMASK		"255.255.255.000"
#define PRIMARY_MY_GATEWAY			"192.168.000.001"
#define PRIMARY_LOCAL_DOMAINNAME	"192.168.000.001"
#define UDP_IP						"192.168.000.003"
#define TCP_DEFAULT_PORT	1234
#define UDP_DEFAULT_PORT	2001
#define TCP_PUSH_SERVER1	"192.168.000.003"
#define TCP_PUSH_SERVER2	"192.168.000.002"
#define TCP_PUSH_PORT1		3001
#define TCP_PUSH_PORT2		3001
#define INTERNET_TEST_IP    "004.002.002.002"   //ARMF0502
#define GET_STRING(X) 		{ #X }
/////////////////////////////////////////////////
//#define MAX_SEND_BUFFER		2048//tcp frame size is 1400 so after this data space is included in received data
__packed typedef struct Ser_Port
{
	unsigned char *Buffer;	//ARMF0249	// Pankaj changed to pointer to save memory...
   	unsigned char *RxBuffer;
   	unsigned int  MAXINBUF;
	unsigned int  MAXOUTBUF;
   	unsigned char F_ChkSum;
   	unsigned char ChkSum;
	unsigned int  BufPtr;
   	unsigned int  RxPtr;
   	unsigned char Poll;
	unsigned char F_SerProxy;
   	unsigned char Type;
}SerPort;

//Page 1 data = New code size, No of pages, Firmware info, Hardware Info, Compile Date, Error Info
__packed struct NEW_FW_INFO
{
   	unsigned int ChkSum;
	unsigned int CodeSz;
	unsigned short NoOfPages;
	unsigned short ErrInfo;
   	unsigned char FWInfo[8];
   	unsigned char HWInfo[8];
   	unsigned char CompileDate[8];
};
extern struct NEW_FW_INFO NewFWInfo;

__packed struct TIME_ZONE_STR
{
	unsigned char StarHours;
	unsigned char StarMin;
	unsigned char EndHours;
	unsigned char EndMin;
};
__packed typedef struct DATE_FORMAT
{
	  char Day;
	  char Month;
	  char Year;

}Date;
__packed struct TIME_FORMAT
{
	  char Secs;
	  char Min;
	  char Hour;
};
__packed typedef struct DATE_TIME	//6
{
	struct TIME_FORMAT Time;   //3
	struct DATE_FORMAT Date;   //3
}RTCTime;
/***************** Start of TIME BASED ACTIONS ***********************/
#define MAX_TIME_BASED_ACTIONS	8
#define TIMED_NO_ACTION			0
#define TIMED_APB_RESET			1
#define TIMED_DOTL_RESET		2
#define TIMED_EVENT_GENERATE	3
__packed struct TIME_BASED_ACTION
{
	unsigned char ActionType;          		//1
	unsigned int  ActionData;              //2
	struct TIME_ZONE_STR TimeAction;       //4
	struct DATE_FORMAT  ActionCompleteDate; //3
	unsigned char Dummy1;                   //1
	unsigned char Dummy2;                   //1
	unsigned int  Dummy3;                   //2
	unsigned int  Dummy4;                   //2
};
//extern struct TIME_BASED_ACTION TimeBasedAction[MAX_TIME_BASED_ACTIONS];
#define SIZEOF_TIME_BASED_BUFFER ( sizeof(struct TIME_BASED_ACTION) * MAX_TIME_BASED_ACTIONS )
/***************** End of TIME BASED ACTIONS ***********************/


extern unsigned int MaxNoOfCards;       //F0018 Add New service menu to display useful system parameters
extern unsigned int MaxNoOfTrans;
extern unsigned char FirmWareVer[8];
extern unsigned int BalCards;
extern unsigned int BalTransBuffer;
extern unsigned char Controllertype[16];

#ifdef BIO_METRIC
	extern unsigned int MaxNoofTemplates;
	extern unsigned int UsedTemplates;
	extern unsigned int BalTemplates;
#endif

extern __packed const BYTE COMPILEDATE[];
extern volatile BYTE SBuffer[BUFSIZE];
extern CardData Carddata;
extern volatile BYTE F_SerialCommandProxy,F_secsend,F_EthernetReceived;
extern int LastCardAddedPtr;	
extern BYTE MySlaveNo,CWeekDay;							    
extern BYTE F_CardFound1,F_CardFound2;
extern BYTE F_Dotl1_Alarm,F_Dotl2_Alarm,F_Facility,F_Door1IsOpen,F_Door2IsOpen,F_LastCardCheck;
extern volatile BYTE F_Receiver_Data ,F_Check_Slave_No,F_Receive_Serial_Data,F_Global_Command,F_Get_Slave_Data;
extern WORD InEmpCount,InEmpCount_Back;
extern BYTE F_Dotl2_set,F_Door1Alarm,F_Door2Alarm,F_TempCounterStart,F_Keyscan,F_FIRE;
extern SerPort PortObj[MAX_SER_PORT];
extern void Delay(DWORD cnt);
extern unsigned char F_FingerSense;


//----------------------Error COdes NG BioSmart ------------------------------------------------------------------------------------------------------------

#define ERROR_INSUFFICIENT_PARAMETER  		 3
#define ERROR_IMPROPER_PARAMETER  			 4
#define ERROR_IMPROPER_TEMPLATESZ  			 8

#define ERROR_SD_WRITE_FAIL   				10
#define ERROR_SD_READ_FAIL  			    11
#define ERROR_MAX_CARD_REACH   				12
#define ERROR_MAX_TEMPLATE_SENSOR   		13
#define ERROR_MAX_TEMPLATE_SD   			14
#define ERROR_ALREADY_TEMPLATE_INSD  		15
#define ERROR_ALREADY_TEMPLATE_INSENSOR  	16
#define ERROR_CARD_ALREADY_EXIST   			17
#define ERROR_ADD_TEMPLATE_STORAGE_TYPE		18
#define ERROR_FAT_FILE_ERR					19	


//----------------------------------------------------------------------------------------------------------------------------------
#endif	//__EASYWEB_H

