/*-------------------- IN OUt interface hardware definitions --------------------*/

/* PINS: 
   
   - OUT_DB1 = P2.2
   - OUT_DB2 = P2.3
   - OUT_DB3 = P2.4
   - OUT_DB4   = P2.5 
   - OUT_DB5  = P2.6
   - OUT_DB6  = P2.7
   - OUT_DB7 = P3.25
   - OUT_DB8  = P3.26                                                              
   - OUT_LATCh_SEL0 = 4.28
   - OUT_LATCh_SEL1 = 4.29

   - IN_DB0 = P0.4
   - IN_DB1 = P0.5
   - IN_DB2 = P0.6
   - IN_DB3 = P0.7
   - IN_DB4   = P0.8 
   - IN_DB5  = P0.9
   - IN_DB6 = P0.23
   - IN_DB7  = P0.24                                                              
   - IN_LATCh_SEL = 1.31
 
   - WG_DB0 = P0.19
   - WG_DB1 = P0.20
   - WG_DB2 = P0.21
   - WG_DB3 = P0.22
   - WG_DB4   = P2.10 
   - WG_DB5  = P2.11
   - WG_DB6 = P0.12
   - WG_DB7  = P0.13                                                              
   - WG_LATCh_SEL = 0.27

 */
 
 
#define OUT_DB0               0x00000004
#define OUT_DB1        	      0x00000008
#define OUT_DB2               0x00000010
#define OUT_DB3      	      0x00000020
#define OUT_DB4        	      0x00000040
#define OUT_DB5               0x00000080
#define OUT_DB6           	  0x02000000
#define OUT_DB7               0x04000000
#define OUT_LATCh_SEL0        0x10000000
#define OUT_LATCh_SEL1        0x20000000
#define OUT_LATCh_SEL2        0x80000000

#define IN_DB0                2   
#define IN_DB1        	      3
#define IN_DB2                4
#define IN_DB3      	      5
#define IN_DB4        	      6
#define IN_DB5                7
#define IN_DB6           	  25
#define IN_DB7                26


#define WG_DB0                19   
#define WG_DB1        	      20
#define WG_DB2                21
#define WG_DB3      	      22
#define WG_DB4        	      10
#define WG_DB5                11
#define WG_DB6           	  12
#define WG_DB7                13
#define WG_LATCh_SEL          0x08000000


//  P1.31 is LCD Back light In SI049  So it should be commented for SI065
#ifndef HARDWARE_SI065 						
 #define INBUFFERENA()	{	IODIR1	|= 0x80000000;\
 							IO1PIN  |= 0x00000000;}		//P1.31
 						
 #define INBUFFERDIS() 	{	IODIR1	|= 0x80000000;\
 							IO1PIN  |= 0x80000000;}	//P1.31
#else 							
	#define INBUFFERENA()	{}		//P1.31
						
	#define INBUFFERDIS() 	{}	//P1.31							
#endif

/* Reading DATA pins                                                          */

/* Extra port PINS: 
   
   - EXT_DB0 = P0.4
   - EXT_DB1 = P0.5
   - EXT_DB2 = P0.6
   - EXT_DB3 = P0.7
   - EXT_DB4 = P0.8
   - EXT_DB5 = P0.9
   - EXT_DB6 = P0.23
   - EXT_DB7 = P0.24
   - EXT_PIN = P2.8
   P0 = 0000 0001 1000 0000 0000 0011 1111 0000 = 0x018003F0

   P0 = 0000 0000 0111 1000 0000 0000 0000 0000	= 0x00780000
   P2 = 0000 0000 0000 0000 0000 1111 0000 0000	= 0x00000F00

   P0 = 0000 0100 0000 0000 0000 0000 0000 0000	= 0x04000000
   P1 = 0111 0000 0000 0000 0000 0000 0000 0000	= 0x70000000

*/
//extern void  InitialiseIO(void);
extern BYTE EGRS_1(void);
extern BYTE DOTLIN_1(void);
extern BYTE EGRS_2(void);
extern BYTE DOTLIN_2(void);
extern BYTE FIREIN(void);
extern BYTE TAMPERIN(void);
extern BYTE DIGITAL_1(void);
extern BYTE DIGITAL_2(void);
extern BYTE WigIN_1(void);
extern BYTE WigIN_2(void);
extern BYTE WigIN_3(void);
extern BYTE WigIN_4(void);
extern void LOCK_1(BYTE data);
extern void LOCK_2(BYTE data);
extern void READER_LED_1(BYTE data); 
extern void READER_LED_2(BYTE data); 
extern void READER_BUZ_1(BYTE data); 
extern void READER_BUZ_2(BYTE data); 
extern void DOTL_BUZ_1(BYTE data); 
extern void DOTL_BUZ_2(BYTE data);


