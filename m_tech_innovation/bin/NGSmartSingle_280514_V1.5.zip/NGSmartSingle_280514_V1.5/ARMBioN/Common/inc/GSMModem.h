#ifndef __GSMMODEM_H
#define __GSMMODEM_H

#ifdef ENABLE_GSM_GPRS

#define MAX_GPRS_BUFFER	1024

extern unsigned char GPRSReInit,ModemTimeOut,GPRSStatus,GPRSIPAddress[20];
extern volatile unsigned char F_ModemDataProxy;
extern unsigned char GPRSSBuffer[MAX_GPRS_BUFFER];
extern unsigned int GPRSReceiveCount;
extern unsigned int GPFSAutoConnectTimer,GPFSInitialiseTimer,GPRSNoDataTime;
extern unsigned char F_GPRSData;
extern unsigned char SignalStrength;
extern unsigned char F_100mSecCounterStart,Temp_100mSec_Time_Counter; 
extern unsigned char F_ReceiveGPRSPortData;
extern char SendWithoutDelay;

//#define MODEM_PORT				PC_PORT
#define MODEM_TERMINATOR1		'\n'
#define MODEM_TERMINATOR2		'\r'

#define STATUS_GPRS_NOTCONNECT		0
#define STATUS_GPRS_CONNECTING		1
#define STATUS_GPRS_CONNECTED_WAIT	2
#define STATUS_GPRS_ERROR				3
#define STATUS_GPRS_CONNECTED			10

#define MAX_GPRS_NO_DATA_TIMEOUT		60
#define MAX_GPRS_INITIALISE_TIMEOUT	60

#define GPRS_OK			0
#define GPRS_FAIL		1
#define GPRS_TIME_OUT	2  //2 and 3 are only used by WaitModemResponse() 
#define GPRS_RECEIVED	3  //

//#define PC_PORT  						SER_PORT_D
//#define SER_MODEM_RDUSED()				SERPCRDUSED()  //PRASOON CHANGE THIS
//#define SER_MODEM_GETC()				SERPCGETC()	  //PRASOON CHANGE THIS
#define SER_MODEM_BAUDRATE() 			SER_PC_BAUDRATE()

//==============================================================================

#define GPRS_1SEC_TIMER_INTERRUPT() { GPFSAutoConnectTimer++;\
					GPFSInitialiseTimer++;  \
					if(GPRSStatus==STATUS_GPRS_CONNECTED) \
               	GPRSNoDataTime++; \
               }
			   
	   
extern void InitialiseModemData(void);	
extern unsigned char ClearModemPort(void);
extern unsigned char InitialiseGPRS(unsigned char reinit);	
extern unsigned char ShutdownGPRS(void);
extern char SendCommandToModem(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout);
extern char SendCommandToModemAndCheck(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata);
extern char SendCommandToModemAndWait(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout);
extern char WaitModemResponse(unsigned int timeout,unsigned char *checkstr);
extern void MainLoopGPRSHandle(void);
extern void AutoConnectGPRS(void);
extern void HandleGPRSDiagnosis(unsigned char keytype);
extern void HandleGPRSDiagnosisType(unsigned char type);
extern unsigned char DisableECHO(void);	
extern unsigned char ChkSignalStrength(void);
extern void DisplaySignalStrength(unsigned char rssi,unsigned char row);
char SendCommandToModemAndCheck_2(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata);
char WaitModemResponse_2(unsigned int timeout,unsigned char *checkstr);
char SendCommandToModemAndCheck_3(unsigned char *senddata,unsigned char len,unsigned char *recdata,unsigned int timeout,unsigned char *chkdata);
char WaitModemResponse_3(unsigned int timeout,unsigned char *checkstr);


#endif //#ifdef ENABLE_GSM_GPRS
#endif//#define __GSMMODEM_


