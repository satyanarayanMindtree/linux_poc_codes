#ifndef __SPLCARDMGNT_H
#define __SPLCARDMGNT_H

extern void SpecialCardLEDBlinkMainLoop(void);
extern unsigned char CheckDoNotDisturbZone(unsigned char TWeekDay, unsigned char rdno);
extern unsigned char Check1stInUseCard(unsigned char Group,unsigned char CrdFound);
extern unsigned char CheckDoNotDisturb(CARDNO_DATA_STORAGE_TYPE cardno,char chno);
extern unsigned char CheckDualUser(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char MesgInfo);
extern void DualUserMainLoopManager(void);
extern void DMZMainLoopManager(void);
extern int ProcessSpecialCard(CARDNO_DATA_STORAGE_TYPE cardno,unsigned char rdno);
extern int ProcessEscortCard(unsigned char rdno);
extern void IncDecInEmpCount(unsigned char readerno);
extern void ValidateInEmpCount(void);
extern void SaveInEmpCount(void);
extern void SpecialCrdBasedErr(void);
extern void GlobalDMZReset(unsigned char rdno);

#endif//SPLCARDMGNT_H




