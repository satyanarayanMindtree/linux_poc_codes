/**********************  biometric command **********************************************/


#define BIO_START_CMD					0x41

#define CMD_ENROLL_FINGER_SCAN			0x05
#define CMD_IDENTIFY_FINGER				0x11
#define CMD_DELETE_USER_ID	  			0x16
#define CMD_DELETE_ALL_USER_ID			0x17
#define CMD_CHECK_USER_ID				0x19
#define CMD_LIST_USER_ID				0x18
#define CMD_VERIFY_USER_ID_SCAN			0x08
#define CMD_SAVE_SYS_PARA				0x02
#define CMD_WRITE_SYS_PARA				0x01
#define CMD_READ_SYS_PARA				0x03
#define CMD_RESET_MODULE				0xD0
#define CMD_READ_BIO_TEMPLATE			0x14
#define CMD_VERIFY_BIO_TEMPLATE			0x10
#define CMD_ENROLL_BIO_TEMPLATE			0x07
#define CMD_IDENTIFY_BY_BIO_TEMPLATE	0x13
#define CMD_VERIFY_HOST_TEMPLATE_SCAN	0x22
#define CMD_EX_READ_BIO_TEMPLATE    	0x89
#define CMD_CANCEL				    	0x60
#define CMD_CANCEL_BIO_RESPONSE 		0x60
#define CMD_SCAN_TEMPLATE				0x21

#define CMD_DELETE_ALL_TEMPLATE 	0x17

#define DELETE_ONLY_ONE					0x70
#define DELETE_MULTIPLE_ID				0x71

#define BIO_SINGLE_ENROLL				0x30
#define BIO_TWO_TEMPLATE_ENROLL			0x41

#define SUPPORTED_TEMPLATE_SZ_1			256
#define SUPPORTED_TEMPLATE_SZ_2			288
#define SUPPORTED_TEMPLATE_SZ_3			320
#define SUPPORTED_TEMPLATE_SZ_4			352
#define SUPPORTED_TEMPLATE_SZ_5			384
#define SUPPORTED_TEMPLATE_SZ_6			1016

#define WAIT_FOR_FINGER					0x50

#define BIO_SYS_REG_SEC_LEVEL			0x66
#define BIO_SYS_TEMPLATE_SIZE			0x64
#define BIO_SYS_ENROLL_TYPE				0x65  	//ARMD0455 //$1lx,101,101(0x65),
#define BIO_SYS_ADDED_TEMPLATES			0x73
#define BIO_SYS_AVAIL_TEMPLATES			0x74

#define STATUS_BIO_FINGER_FOUND			0x62
#define STATUS_BIO_SUCCESS				0x61
#define STATUS_BIO_TIME_OUT				0x6C
#define STATUS_BIO_NOT_FOUND			0x69
#define STATUS_BIO_EXIST_ID				0x6E
#define STATUS_BIO_NOT_MATCH			0x6A
#define STATUS_BIO_COMM_TIME_OUT		0xF1
#define STATUS_BIO_EXIST_FINGER			0x86
#define STATUS_BIO_SCAN_FAIL			0x63
#define STATUS_BIO_TRY_AGAIN			0x6B
#define STATUS_BIO_MEMORY_FULL			0x6D
#define STATUS_BIO_FINGER_LIMIT			0x72
#define STATUS_BIO_INVALID_ID			0x76
#define STATUS_BIO_BUSY					0x80
#define STATUS_BIO_CANCELLED			0x81
#define STATUS_BIO_DURESS_FINGER		0x91		//FA00083
#define STATUS_BIO_FINGER_MATCH_TIMEOUT	0x7A   		//A00009
#define STATUS_BIO_CONTINUE				0x74

#define BIO_COMMAND_POSITION	3
#define BIO_REC_PACKET_SIZE		15
#define BIO_REC_PACKET_SIZE_2	15

#define SUPBIO_DEF
#define ENABLE_BIOMETRIC

#define MAX_BIO_TIME_OUT		50

#define ENABLE_BIO_COMM()	{F_BIO_COMM = SET;}
#define DISABLE_BIO_COMM()	{F_BIO_COMM = CLR;}


#define MAX_BIO_TEMPLATE_SIZE		0x200
#define TEMPLATE_START_POSITION		15

#define  F_BioCheckSum    	PortObj[SER_BIO_PORT].F_ChkSum
#define  Biochecksum  		PortObj[SER_BIO_PORT].ChkSum

#define TransmitCharBio(x)	TransmitCharToX(x,SER_BIO_PORT)
//#define F_SerialCommandBio	PortObj[SER_BIO_PORT].F_SerProxy


/*************************************************************/
/*veriables*/
//static unsigned int BioFlag;
//extern BYTE Bio_Buffer[BIO_BUFFER_LENGTH];
extern BYTE F_SerialCommandBio,F_CheckSum,F_BIO_COMM;
extern BYTE TemplateBuff[MAX_BIO_TEMPLATE_SIZE];  // 512
extern BYTE BioCommand,BioCmdStatus,F_BioCmdresponse;

extern BYTE FingerWaitTimeOut;
//unsigned int ReceiveCountSERPC;
extern unsigned char SensorBioEnrollType;
extern unsigned int SensorTemplateSize;
extern unsigned long BioCmdData,BioCmdSize;
extern BYTE F_Template_Download;
extern BYTE BioSensorFail;
extern BYTE F_CriticalSection;

/*************************************************************/


extern int GetTemplateFromSDToBuff(CARDNO_DATA_STORAGE_TYPE finder,WORD *tempsz,char *nooftemp,char Templateinfo,int sdtemplateblock,char (*template)[MAX_BIO_TEMPLATE_SIZE]);
extern BYTE VerifyBioTemplateFromHost(WORD templatesize,BYTE nooftemp,char (*template)[MAX_BIO_TEMPLATE_SIZE]);
extern BYTE VerifyBioTemplateFromSD(WORD templatesize,BYTE nooftemp,BYTE Templateinfo,int sdtemplateblock);
extern BYTE VerifyBioTemplateFromSDNew(CARDNO_DATA_STORAGE_TYPE cardno,WORD templatesize,BYTE nooftemp,BYTE Templateinfo,int sdtemplateblock);
extern BYTE ScanBioTemplate(BYTE * tempbuf);
extern BYTE IdenifyByBioTemplate(WORD templatesize);
extern BYTE VerifyBioTemplate(WORD fingerid,WORD templatesize);
extern BYTE EnrollByBioTemplate(CARDNO_DATA_STORAGE_TYPE fingerid,WORD templatesize,BYTE * tempbuf);
extern BYTE ReadSingleTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf);
extern BYTE ReadDownloadTemplate(CARDNO_DATA_STORAGE_TYPE userID,BYTE fingno,BYTE *tempbuf);
extern BYTE SaveBioSystemParameter(void);
extern BYTE CancelBioCommand(void);
extern BYTE ReadBioSystemParameter(BYTE para);
extern BYTE WriteSystemParameter(BYTE paraid,WORD value);
extern void TransmitCharPortC(BYTE t_data);
extern void ProcessBioSerialResponse(void);
//extern BYTE TimeWaitBioResponse(WORD time);
extern BYTE WaitBioResponse(void);
//extern BYTE ListBioUserID(void);
extern BYTE CheckBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid);
extern BYTE DeleteAllBioUserID(void);
extern BYTE DeleteBioFingerID(CARDNO_DATA_STORAGE_TYPE idstart,CARDNO_DATA_STORAGE_TYPE idend,BYTE deltype);
extern BYTE DeleteBioUserID(CARDNO_DATA_STORAGE_TYPE fingerid);
extern BYTE VerifyFinger(CARDNO_DATA_STORAGE_TYPE fingerid);
extern BYTE IdentifyFinger(void);
extern BYTE EnrollNewFingerID(CARDNO_DATA_STORAGE_TYPE fingerid,BYTE addtype);
extern void ClearBioSerBuffer(void);
extern BYTE DeleteAllBioTemplate(void);
extern void GetBalanceTemplate(void);

