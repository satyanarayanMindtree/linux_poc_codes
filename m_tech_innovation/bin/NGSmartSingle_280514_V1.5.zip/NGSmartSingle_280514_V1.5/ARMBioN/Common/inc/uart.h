/*****************************************************************************
 *   uart.h:  Header file for NXP LPC23xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.09.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __UART_H 
#define __UART_H

#define IER_RBR		0x01
#define IER_THRE	0x02
#define IER_RLS		0x04

#define IIR_PEND	0x01
#define IIR_RLS		0x03
#define IIR_RDA		0x02
#define IIR_CTI		0x06
#define IIR_THRE	0x01

#define LSR_RDR		0x01
#define LSR_OE		0x02
#define LSR_PE		0x04
#define LSR_FE		0x08
#define LSR_BI		0x10
#define LSR_THRE	0x20
#define LSR_TEMT	0x40
#define LSR_RXFE	0x80
#define BUFSIZE		1000

#define SER_PORT_C			0
#define SER_PORT_D      	1
#define SER_PORT_E      	2
#define SER_PORT_F      	3
#define SER_TCPIP_PORT		4
#define SER_UDP_PORT		5
#define SER_TCPPUSH_PORT	6
#define SER_EMAIL_PORT		7  
#define SER_UDP_PUSH_PORT	8
#define SER_PORT_G			9		  		// Not In use dummy port
#define MAX_SER_PORT		SER_PORT_G+1

#define PORT_TYPE_BIO			1
#define PORT_TYPE_GPRS			2

#define SER_BAUD_BIO			0
#define SER_BAUD_SC1			1
#define SER_BAUD_SC2			2
#define SER_BAUD_PC				3


#define MAX_NW_TX_BUFF		1024

#ifdef SMART_CARD
	#define MODEM_PORT				SER_PORT_F			
	#define PC_PORT						SER_PORT_G
	#define SER_SMART_RD1_PORT 		SER_PORT_C		  	
#else
	#ifdef ENABLE_GSM_GPRS
		#define MODEM_PORT			SER_PORT_D			// In NG Biosmart MOdem Com Port connectin is at COM1 
		#define PC_PORT					SER_PORT_C
		#define SER_SMART_RD1_PORT 	SER_PORT_G		  	
	#else
		#define MODEM_PORT			SER_PORT_G			
		#define PC_PORT					SER_PORT_C
		#define SER_SMART_RD1_PORT 	SER_PORT_G		  	
	#endif
#endif

#define USE_PC_SERIAL_PORT

//====================================================================
#define SER_BIO_PORT            SER_PORT_E

#define SER_BIO_BAUDRATE(x)     UARTInit(SER_PORT_E,x,0)


#ifdef ENABLE_SLAVE_SUPPORT
	#define TRANSP_SLAVE_PORT        SER_PORT_D
	#define TRANSP_SLAVE_GETC()      serDgetc()
	#define TRANSP_SLAVE_BAUDRATE(x) UARTInit(SER_PORT_D,x,0)
#endif

#define BIO_BUFFER_LENGTH		2000

//#define MY_UDP_PORT            2001

/*** EndHeader */


extern int iInterruptLevel;
							   

extern short UARTInit(BYTE portNum,unsigned int Baudrate,BYTE parity);
void UART0Handler(void) __irq;
void UART1Handler(void) __irq;
void UART2Handler(void) __irq;
void UART3Handler(void) __irq;
extern void UARTSend(DWORD portNum, BYTE *BufferPtr, DWORD Length);
extern void UARTSendByte(BYTE portNum, BYTE data);
extern short serDgetc(void);
extern short serCgetc(void);
extern void SerialInt(void);
extern void InitialiseSerialObj(void);
extern char TransmitCharToX(BYTE t_data,BYTE port);
extern unsigned char GLOBAL_PORT;


#endif /* end __UART_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/

