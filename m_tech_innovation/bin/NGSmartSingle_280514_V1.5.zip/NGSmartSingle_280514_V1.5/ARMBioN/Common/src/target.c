/*****************************************************************************
 *   target.c:  Target C file for NXP LPC23xx/24xx Family Microprocessors
 *
 *   Copyright(C) 2006, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2006.07.13  ver 1.00    Prelimnary version, first Release
 *
*****************************************************************************/
#include "LPC23xx.h"
#include "type.h"
#include "irq.h"
#include "target.h"
#include "INOUT.h"


//BYTE PrevInput,InpChange;
//PORTINRD DoorInput;
extern BYTE F_ChangeInInput;
/******************************************************************************
** Function name:		TargetInit
**
** Descriptions:		Initialize the target board; it is called in a necessary 
**						place, change it as needed
**
** parameters:			None
** Returned value:		None
** 
******************************************************************************/
void TargetInit(void)
{
  /* Add your codes here Define all port pin funcnality*/
//
 
//PORT O PINS USED 15 TO 0:1100 0000 0101 0000 0000 0000 0101 1010
//  	PINSEL0 = 0xC050005A;      
//PORT 0 PINS USED 31 TO 16 :0001 0100 0010 0000 0000 0000 0011 1100 
//	PINSEL1 = 0x1420003C; 	   
	PINSEL1 = 0x00114000; //select p0.23,24,26 as adc pin	   
//PORT 1 PINS USED 15 TO 0:	 0100 0000 0001 0101 0000 0001 0000 0101
	PINSEL2 = 0x40150105;
//PORT 1 PINS USED 31 TO 16: 0010 0000 0000 0000 0000 0000 0001 0101
    PINSEL3 = 0x32000005;	 //select p1.30 as adc ;p1.28 as PCAP1.0
//PORT 2 PINS USED 15 TO 0:	 0000 0001 0101 0100 0000 0000 0000 1010
	PINSEL4 = 0x0150000A;  //p2.0,1 = uart1 ; p2.10,11,12=external interrupt others are GPIO
//PORT 2 PINS USED 31 TO 16: 0000 0000 0000 0000 0000 0000 0000 0000
    PINSEL5 = 0x00000000;
//PORT 3 PINS USED 15 TO 0:	 0000 0000 0000 0000 0000 0000 0000 0000
    PINSEL6 = 0x00000000;
//PORT 3 PINS USED 31 TO 16: 0000 0000 0000 0000 0000 0000 0000 0000   
    PINSEL7 = 0x00000000;
//PORT 4 PINS USED 15 TO 0:	 0000 0000 0000 0000 0000 0000 0000 0000
    PINSEL8 = 0x00000000;
//PORT 4 PINS USED 31 TO 16: 0000 0000 0000 0000 0000 0000 0000 0000
    PINSEL9 = 0x00000000;
//ETM INTERFACE SELECTON THROUGH SOFTWARE.
    PINSEL10 = 0x00000000; 

 /*
//Set direction for I/0 1 for output 0 for Input for corresponding port	
//port 0 = 0001 1010 0111 1001 0000 0000 0000 0000	
//Input 4,5,6,7,8,9,23,24 Output 16,19,20,21,22,25,27,28
	FIO0DIR = 0x1A780000;    

//port 1 = 0000 0000 0000 0000 0000 0000 0000 0000	
//Input 19,20,21,22,23
	FIO1DIR = 0x00000000;    

//port 2 = 0000 0000 0000 0000 0011 1001 1111 0000	
//Input 2,3 output 4,5,6,7,8,11,12,13.
	FIO2DIR = 0x000030F0;    

//port 3 = 0000 0110 0000 0000 0000 0000 0000 0000	
//25,26	ARE USED as oputput
	FIO3DIR = 0x06000000;    

//port 4 = 0011 0000 0000 0000 0000 0000 0000 0000	
//28,29 ARE USED as output
	FIO4DIR = 0x30000000;    

//SET EXTERNAL INTERRUPT FOR WIEGAND AND KEYBOARD FOR PORT PINS.
//2 falling Edge interrupt are set on pin 23 and 24  for Wiegand and keyboard.
  IO0_INT_EN_F = 0x01800000;
 */
  return;
}

/******************************************************************************
** Function name:		GPIOResetInit
**
** Descriptions:		Initialize the target board before running the main() 
**				function; User may change it as needed, but may not 
**				deleted it.
**
** parameters:			None
** Returned value:		None
** 
******************************************************************************/
void GPIOResetInit( void )
{
  /* Reset all GPIO pins to default: primary function */
  PINSEL0 = 0x00000000;
  PINSEL1 = 0x00000000;
  PINSEL2 = 0x00000000;
  PINSEL3 = 0x00000000;
  PINSEL4 = 0x00000000;
  PINSEL5 = 0x00000000;
  PINSEL6 = 0x00000000;
  PINSEL7 = 0x00000000;
  PINSEL8 = 0x00000000;
  PINSEL9 = 0x00000000;
  PINSEL10 = 0x00000000;
    
  IO0DIR = 0x00000000;
  IO1DIR = 0x00000000;
  IO0SET = 0x00000000;
  IO1SET = 0x00000000;
    
  FIO0DIR = 0x00000000;	//0=input , 1=output
  FIO1DIR = 0x00000000;
  FIO2DIR = 0x00000000;
  FIO3DIR = 0x00000000;
  FIO4DIR = 0x00000000;
    
  FIO0SET = 0x00000000;
  FIO1SET = 0x00000000;
  FIO2SET = 0x00000000;
  FIO3SET = 0x00000000;
  FIO4SET = 0x00000000;
  return;        
}

/******************************************************************************
** Function name:		ConfigurePLL
**
** Descriptions:		Configure PLL switching to main OSC instead of IRC
**						at power up and wake up from power down. 
**						This routine is used in TargetResetInit() and those
**						examples using power down and wake up such as
**						USB suspend to resume, ethernet WOL, and power management
**						example
** parameters:			None
** Returned value:		None
** 
******************************************************************************/
void ConfigurePLL ( void )
{
  DWORD MValue, NValue;

  if ( PLLSTAT & (1 << 25) )
  {
	PLLCON = 1;			/* Enable PLL, disconnected */
	PLLFEED = 0xaa;
	PLLFEED = 0x55;
  }

  PLLCON = 0;				/* Disable PLL, disconnected */
  PLLFEED = 0xaa;
  PLLFEED = 0x55;
    
  SCS |= 0x20;			/* Enable main OSC */
  while( !(SCS & 0x40) );	/* Wait until main OSC is usable */

  CLKSRCSEL = 0x1;		/* select main OSC, 12MHz, as the PLL clock source */

  PLLCFG = PLL_MValue | (PLL_NValue << 16);
  PLLFEED = 0xaa;
  PLLFEED = 0x55;
      
  PLLCON = 1;				/* Enable PLL, disconnected */
  PLLFEED = 0xaa;
  PLLFEED = 0x55;

  CCLKCFG = CCLKDivValue;	/* Set clock divider */
#if USE_USB
  USBCLKCFG = USBCLKDivValue;		/* usbclk = 288 MHz/6 = 48 MHz */
#endif

  while ( ((PLLSTAT & (1 << 26)) == 0) );	/* Check lock bit status */
    
  MValue = PLLSTAT & 0x00007FFF;
  NValue = (PLLSTAT & 0x00FF0000) >> 16;
  while ((MValue != PLL_MValue) && ( NValue != PLL_NValue) );

  PLLCON = 3;				/* enable and connect */
  PLLFEED = 0xaa;
  PLLFEED = 0x55;
  while ( ((PLLSTAT & (1 << 25)) == 0) );	/* Check connect bit status */
  return;
}

/******************************************************************************
** Function name:		TargetResetInit
**
** Descriptions:		Initialize the target board before running the main() 
**						function; User may change it as needed, but may not 
**						deleted it.
**
** parameters:			None
** Returned value:		None
**it initialises memory accelerator unit,VIC controller and pins selection to perticular peripheral
******************************************************************************/
void TargetResetInit(void)
{
#ifdef __DEBUG_RAM    
  MEMMAP = 0x2;			/* remap to internal RAM */
#endif

#ifdef __DEBUG_FLASH    
  MEMMAP = 0x1;			/* remap to internal flash */
#endif

//#if USE_USB
//  PCONP |= 0x80000000;		/* Turn On USB PCLK */
//#endif
//  /* Configure PLL, switch from IRC to Main OSC */
//  ConfigurePLL();
//
//  /* Set system timers for each component */
//#if (Fpclk / (Fcclk / 4)) == 1
//  PCLKSEL0 = 0x00000000;	/* PCLK is 1/4 CCLK */
//  PCLKSEL1 = 0x00000000;
//#endif
//#if (Fpclk / (Fcclk / 4)) == 2
//  PCLKSEL0 = 0xAAAAAAAA;	/* PCLK is 1/2 CCLK */
//  PCLKSEL1 = 0xAAAAAAAA;	 
//#endif
//#if (Fpclk / (Fcclk / 4)) == 4
//  PCLKSEL0 = 0x55555555;	/* PCLK is the same as CCLK */
//  PCLKSEL1 = 0x55555555;	
//#endif

//  PCLKSEL1 |= PCLK_GPIO_CCLK_1;	//gpio clock is CCLK

  /* Set memory accelerater module*/
  MAMCR = 0;	//disable mem accelarator
#if Fcclk < 20000000
  MAMTIM = 1;
#else
#if Fcclk < 40000000
  MAMTIM = 2;
#else
  MAMTIM = 3; //fetch at 3 CCLK
#endif
#endif
//  MAMCR = 2;
  MAMCR = 0; //ARMD0264 

  GPIOResetInit();

  init_VIC();//VIC initialise
  TargetInit();//pins are selected according to functions
  return;
}

/********************************************************************************************************************************/
// Header:
// File Name: 
// Author:
// Date:
/********************************************************************************************************************************/


 //==============================================
// only 6 inputare used in hardware so make rest clr which indicates no input

#define DEFAULT_NO_INPUT	0xFF		

//BYTE READ_INPUT(void)
//{  
//BYTE x;
//	x = DEFAULT_NO_INPUT;                   
//	x = (IOPIN1 >> 4) & 0x3F;
//	return(x);
//} 
//
//
//#define DEFAULY_OUT_BYTE	0x11
//
//
//#ifdef HARDWARE_DEF_SRC
//
//unsigned char bdata IOInput;
//unsigned char data OutPutByte=DEFAULY_OUT_BYTE;
//
//sbit IN_Egress1	  	= IOInput^0;
//sbit IN_Dotl1		= IOInput^1;
//sbit IN_Egress2	   	= IOInput^2;
//sbit IN_Dotl2		= IOInput^3;
//sbit IN_Fire		= IOInput^4;
//sbit IN_Tamper		= IOInput^5;
//sbit IN_DigIn1		= IOInput^6;
//sbit IN_DigIn2		= IOInput^7;
//
//unsigned char idata CurrentInput,InpChange,PrevInput;
//#else
//extern unsigned char ReadInputIOByte(void);
//extern unsigned char bdata IOInput;
//extern unsigned char data CurrentInput,InpChange,PrevInput,OutPutByte;
//
//extern bit IN_Egress1;
//extern bit IN_Dotl1;   
//extern bit IN_Egress2; 
//extern bit IN_Dotl2;   
//extern bit IN_Fire;    
//extern bit IN_Tamper;  
//extern bit IN_DigIn1;  
//extern bit IN_DigIn2;  
//
//#endif
//

/******************************************************************************
**                            End Of File
******************************************************************************/
